<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="wsj1775.cz.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
 </meta>
 <s id="m-wsj1775-001-p1s0">
  <m id="m-wsj1775-001-p1s0W1-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W2-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W2</LM>
   </w.rf>
   <form>Control</form>
   <lemma>Control-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W3-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W3</LM>
   </w.rf>
   <form>Data</form>
   <lemma>Data-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W4-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W4</LM>
   </w.rf>
   <form>Corp</form>
   <lemma>Corp-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W5-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W6-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W6</LM>
   </w.rf>
   <form>oznámila</form>
   <lemma>oznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W7-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W8-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W9-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W9</LM>
   </w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W10-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W10</LM>
   </w.rf>
   <form>asociaci</form>
   <lemma>asociace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W11-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W11</LM>
   </w.rf>
   <form>leteckých</form>
   <lemma>letecký</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W12-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W12</LM>
   </w.rf>
   <form>dopravců</form>
   <lemma>dopravce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W13-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W13</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W14-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W14</LM>
   </w.rf>
   <form>IATA</form>
   <lemma>IATA-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W15-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W15</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W16-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W16</LM>
   </w.rf>
   <form>udělila</form>
   <lemma>udělit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W17-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W17</LM>
   </w.rf>
   <form>licenci</form>
   <lemma>licence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W18-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W19-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W19</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W20-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W20</LM>
   </w.rf>
   <form>software</form>
   <lemma>software</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W21-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W21</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W22-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W22</LM>
   </w.rf>
   <form>letecký</form>
   <lemma>letecký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W23-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W23</LM>
   </w.rf>
   <form>management</form>
   <lemma>management_,s_^(^DD**manažment)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W24-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W24</LM>
   </w.rf>
   <form>výnosů</form>
   <lemma>výnos</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s0W25-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s0W25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-wsj1775-001-p1s1">
  <m id="m-wsj1775-001-p1s1W1-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W1</LM>
   </w.rf>
   <form>Podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W2-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W2</LM>
   </w.rf>
   <form>zahrnují</form>
   <lemma>zahrnovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W3-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W3</LM>
   </w.rf>
   <form>dohodu</form>
   <lemma>dohoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W4-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W5-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W5</LM>
   </w.rf>
   <form>licenčních</form>
   <lemma>licenční</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W6-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W6</LM>
   </w.rf>
   <form>poplatcích</form>
   <lemma>poplatek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W7-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W8-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W8</LM>
   </w.rf>
   <form>avšak</form>
   <lemma>avšak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W9-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W9</LM>
   </w.rf>
   <form>podrobnosti</form>
   <lemma>podrobnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W10-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W10</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W11-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W11</LM>
   </w.rf>
   <form>prozrazeny</form>
   <lemma>prozradit</lemma>
   <tag>VsTP----X-APP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s1W12-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s1W12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-wsj1775-001-p1s2">
  <m id="m-wsj1775-001-p1s2W1-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W1</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W2-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W2</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W3-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W3</LM>
   </w.rf>
   <form>zabývající</form>
   <lemma>zabývající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W4-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W5-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W5</LM>
   </w.rf>
   <form>počítačovým</form>
   <lemma>počítačový</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W6-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W6</LM>
   </w.rf>
   <form>vybavením</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W7-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W8-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W8</LM>
   </w.rf>
   <form>finančními</form>
   <lemma>finanční</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W9-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W9</LM>
   </w.rf>
   <form>službami</form>
   <lemma>služba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W10-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W10</LM>
   </w.rf>
   <form>uvedla</form>
   <lemma>uvést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W11-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W12-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W13-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W13</LM>
   </w.rf>
   <form>obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W14-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W14</LM>
   </w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W15-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W15</LM>
   </w.rf>
   <form>IATA</form>
   <lemma>IATA-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W16-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W16</LM>
   </w.rf>
   <form>prodá</form>
   <lemma>prodat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W17-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W17</LM>
   </w.rf>
   <form>přístup</form>
   <lemma>přístup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W18-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W18</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W19-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W19</LM>
   </w.rf>
   <form>balíčku</form>
   <lemma>balíček</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W20-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W20</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP3----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W21-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W21</LM>
   </w.rf>
   <form>180</form>
   <lemma>180</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W22-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W22</LM>
   </w.rf>
   <form>členským</form>
   <lemma>členský</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W23-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W23</LM>
   </w.rf>
   <form>leteckým</form>
   <lemma>letecký</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W24-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W24</LM>
   </w.rf>
   <form>společnostem</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W25-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W25</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W26-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W26</LM>
   </w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W27-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W27</LM>
   </w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s2W28-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s2W28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-wsj1775-001-p1s3">
  <m id="m-wsj1775-001-p1s3W1-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W2-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W2</LM>
   </w.rf>
   <form>Control</form>
   <lemma>Control-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W3-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W3</LM>
   </w.rf>
   <form>Data</form>
   <lemma>Data-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W4-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W4</LM>
   </w.rf>
   <form>získá</form>
   <lemma>získat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W5-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W5</LM>
   </w.rf>
   <form>příjem</form>
   <lemma>příjem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W6-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W6</LM>
   </w.rf>
   <form>úměrný</form>
   <lemma>úměrný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W7-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W7</LM>
   </w.rf>
   <form>počtu</form>
   <lemma>počet</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W8-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W8</LM>
   </w.rf>
   <form>pasažérů</form>
   <lemma>pasažér</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W9-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W10-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W10</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W11-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W11</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W12-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W12</LM>
   </w.rf>
   <form>softwarem</form>
   <lemma>software</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W13-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W13</LM>
   </w.rf>
   <form>obslouženi</form>
   <lemma>obsloužit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W14-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W15-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W15</LM>
   </w.rf>
   <form>sdělila</form>
   <lemma>sdělit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W16-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W16</LM>
   </w.rf>
   <form>asociace</form>
   <lemma>asociace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W17-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W17</LM>
   </w.rf>
   <form>IATA</form>
   <lemma>IATA-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s3W18-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s3W18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-wsj1775-001-p1s4">
  <m id="m-wsj1775-001-p1s4W1-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W1</LM>
   </w.rf>
   <form>Balíček</form>
   <lemma>balíček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W2-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W2</LM>
   </w.rf>
   <form>pomůže</form>
   <lemma>pomoci</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W3-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W3</LM>
   </w.rf>
   <form>přepravcům</form>
   <lemma>přepravce</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W4-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W4</LM>
   </w.rf>
   <form>řešit</form>
   <lemma>řešit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W5-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W5</LM>
   </w.rf>
   <form>cenové</form>
   <lemma>cenový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W6-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W6</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W7-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W8-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W8</LM>
   </w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W9-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W10-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W10</LM>
   </w.rf>
   <form>reagovat</form>
   <lemma>reagovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W11-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W12-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W12</LM>
   </w.rf>
   <form>slevy</form>
   <lemma>sleva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W13-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W13</LM>
   </w.rf>
   <form>nabízené</form>
   <lemma>nabízený_^(*2t)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W14-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W14</LM>
   </w.rf>
   <form>konkurencí</form>
   <lemma>konkurence</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W15-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W16-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W16</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W17-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W17</LM>
   </w.rf>
   <form>stanovit</form>
   <lemma>stanovit_^(určit)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W18-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W18</LM>
   </w.rf>
   <form>optimální</form>
   <lemma>optimální</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W19-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W19</LM>
   </w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W20-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W20</LM>
   </w.rf>
   <form>sedadel</form>
   <lemma>sedadlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W21-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W21</LM>
   </w.rf>
   <form>prodávaných</form>
   <lemma>prodávaný_^(*2t)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W22-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W22</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W23-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W23</LM>
   </w.rf>
   <form>danou</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W24-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W24</LM>
   </w.rf>
   <form>cenu</form>
   <lemma>cena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-wsj1775-001-p1s4W25-Ta">
   <src.rf>tagger-a</src.rf>
   <w.rf>
    <LM>w#w-wsj1775-001-p1s4W25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
