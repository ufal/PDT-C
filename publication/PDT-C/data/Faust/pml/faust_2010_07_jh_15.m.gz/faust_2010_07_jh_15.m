<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="faust_2010_07_jh_15.w.gz" />
  </references>
 </head>
 <s id="s-jh_15-SCzechM-p1527-s1-w2">
  <m id="jh_15-SCzechM-p1527-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1527-s1-w1</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1527-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1527-s1-w2</LM>
   </w.rf>
   <form>nelámej</form>
   <lemma>lámat</lemma>
   <tag>Vi-S---2--N-I--</tag>
  </m>
  <m id="jh_15-SCzechM-p1527-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1527-s1-w3</LM>
   </w.rf>
   <form>lásku</form>
   <lemma>láska</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1529-s1-w1">
  <m id="jh_15-SCzechM-p1529-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w6</LM>
   </w.rf>
   <form>Nashledanou</form>
   <lemma>nashledanou</lemma>
   <tag>TT------------6</tag>
  </m>
  <m id="jh_15-SCzechM-p1529-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1529-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1530-s1-w1">
  <m id="jh_15-SCzechM-p1530-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1530-s1-w1</LM>
   </w.rf>
   <form>budoucno</form>
   <lemma>budoucno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1531-s1-w7">
  <m id="jh_15-SCzechM-p1531-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w5</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w8</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w11</LM>
   </w.rf>
   <form>čem</form>
   <lemma>co-1</lemma>
   <tag>PQ--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w12</LM>
   </w.rf>
   <form>mluvím</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1531-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1531-s1-w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1533-s1-w1">
  <m id="jh_15-SCzechM-p1533-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1533-s1-w1</LM>
   </w.rf>
   <form>budování</form>
   <lemma>budování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1533-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1533-s1-w2</LM>
   </w.rf>
   <form>partnerství</form>
   <lemma>partnerství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1533-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1533-s1-w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1537-s1-w3">
  <m id="jh_15-SCzechM-p1537-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w1</LM>
   </w.rf>
   <form>Veřejný</form>
   <lemma>veřejný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w2</LM>
   </w.rf>
   <form>NASDAQ</form>
   <lemma>NASDAQ-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w4</LM>
   </w.rf>
   <form>INTC</form>
   <lemma>INTC-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w5</LM>
   </w.rf>
   <form>SEHK</form>
   <lemma>SEHK-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w6</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w7</LM>
   </w.rf>
   <form>4335</form>
   <lemma>4335</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w8</LM>
   </w.rf>
   <form>Euronext</form>
   <lemma>Euronext_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1537-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1537-s1-w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1538-s1-w4">
  <m id="jh_15-SCzechM-p1538-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w1</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w2</LM>
   </w.rf>
   <form>civilista</form>
   <lemma>civilista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w3</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w5</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w6</LM>
   </w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w8</LM>
   </w.rf>
   <form>zraněno</form>
   <lemma>zranit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w10</LM>
   </w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w12</LM>
   </w.rf>
   <form>potyčce</form>
   <lemma>potyčka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w14</LM>
   </w.rf>
   <form>policisty</form>
   <lemma>policista</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w16</LM>
   </w.rf>
   <form>odstraňování</form>
   <lemma>odstraňování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w17</LM>
   </w.rf>
   <form>bezpečnostního</form>
   <lemma>bezpečnostní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w18</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w19">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w19</LM>
   </w.rf>
   <form>poblíž</form>
   <lemma>poblíž-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w20">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w20</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w21">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w21</LM>
   </w.rf>
   <form>Pattan</form>
   <lemma>Pattan_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w22">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w23">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w23</LM>
   </w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w24">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w24</LM>
   </w.rf>
   <form>Džamú</form>
   <lemma>Džamú_;G</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w25">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w26">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w26</LM>
   </w.rf>
   <form>Kašmír</form>
   <lemma>Kašmír_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1538-s1-w27">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1538-s1-w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1539-s1-w2">
  <m id="jh_15-SCzechM-p1539-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w1</LM>
   </w.rf>
   <form>FreeLotto</form>
   <lemma>FreeLotto_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w3</LM>
   </w.rf>
   <form>volná</form>
   <lemma>volný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w4</LM>
   </w.rf>
   <form>loterijní</form>
   <lemma>loterijní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w5</LM>
   </w.rf>
   <form>hra</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w6</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w7</LM>
   </w.rf>
   <form>sdruženými</form>
   <lemma>sdružený_^(*3it)</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w8</LM>
   </w.rf>
   <form>sázkami</form>
   <lemma>sázka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w9</LM>
   </w.rf>
   <form>sponzorovaná</form>
   <lemma>sponzorovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w11</LM>
   </w.rf>
   <form>reklamy</form>
   <lemma>reklama</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1539-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1539-s1-w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1542-s1-w1">
  <m id="jh_15-SCzechM-p1542-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w1</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w2</LM>
   </w.rf>
   <form>spondylolistézu</form>
   <lemma>spondylolistéza</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w5</LM>
   </w.rf>
   <form>meziobratlové</form>
   <lemma>meziobratlový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w6</LM>
   </w.rf>
   <form>otvory</form>
   <lemma>otvor</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w8</LM>
   </w.rf>
   <form>široce</form>
   <lemma>široce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w9</LM>
   </w.rf>
   <form>otevřené</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1542-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1542-s1-w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1543-s1-w21">
  <m id="jh_15-SCzechM-p1543-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w4</LM>
   </w.rf>
   <form>Vánocích</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w5</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w6</LM>
   </w.rf>
   <form>volno</form>
   <lemma>volno-2</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w8</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w9</LM>
   </w.rf>
   <form>Silvestra</form>
   <lemma>silvestr</lemma>
   <tag>NNIS4-----A---1</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w11</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w12</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w15</LM>
   </w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w16</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w17</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w18</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w19">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w19</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w20">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w20</LM>
   </w.rf>
   <form>bouře</form>
   <lemma>bouře</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w21">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w22">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w22</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w23">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w23</LM>
   </w.rf>
   <form>deště</form>
   <lemma>déšť</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w24">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w25">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w25</LM>
   </w.rf>
   <form>blesků</form>
   <lemma>blesk</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1543-s1-w26">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1543-s1-w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1544-s1-w2">
  <m id="jh_15-SCzechM-p1544-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1544-s1-w1</LM>
   </w.rf>
   <form>servisní</form>
   <lemma>servisní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1544-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1544-s1-w2</LM>
   </w.rf>
   <form>nádoba</form>
   <lemma>nádoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1544-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1544-s1-w3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1544-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1544-s1-w4</LM>
   </w.rf>
   <form>olej</form>
   <lemma>olej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1546-s1-w1">
  <m id="jh_15-SCzechM-p1546-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w1</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w3</LM>
   </w.rf>
   <form>nemůžeš</form>
   <lemma>moci</lemma>
   <tag>VB-S---2P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w4</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w5</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w6</LM>
   </w.rf>
   <form>lásku</form>
   <lemma>láska</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1546-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1546-s1-w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1551-s1-w1">
  <m id="jh_15-SCzechM-p1551-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1551-s1-w1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1551-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1551-s1-w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1551-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1551-s1-w3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1551-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1551-s1-w4</LM>
   </w.rf>
   <form>Sečuánu</form>
   <lemma>Sečuán_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1551-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1551-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1552-s1-w3">
  <m id="jh_15-SCzechM-p1552-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1552-s1-w1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1552-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1552-s1-w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1552-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1552-s1-w3</LM>
   </w.rf>
   <form>máš</form>
   <lemma>mít</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1552-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1552-s1-w4</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1553-s1-w1">
  <m id="jh_15-SCzechM-p1553-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1553-s1-w1</LM>
   </w.rf>
   <form>vydláždit</form>
   <lemma>vydláždit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1553-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1553-s1-w2</LM>
   </w.rf>
   <form>vertikálně</form>
   <lemma>vertikálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1554-s1-w3">
  <m id="jh_15-SCzechM-p1554-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1554-s1-w1</LM>
   </w.rf>
   <form>Dobrou</form>
   <lemma>dobrý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1554-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1554-s1-w2</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1554-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1554-s1-w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1554-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1554-s1-w4</LM>
   </w.rf>
   <form>zatim</form>
   <lemma>zatim_,h_^(^GC**zatím)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1554-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1554-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1556-s1-w8">
  <m id="jh_15-SCzechM-p1556-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w1</LM>
   </w.rf>
   <form>Napůl</form>
   <lemma>napůl</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w2</LM>
   </w.rf>
   <form>Číňan</form>
   <lemma>Číňan_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w3</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w6</LM>
   </w.rf>
   <form>úžasné</form>
   <lemma>úžasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w7</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w8</LM>
   </w.rf>
   <form>Viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w10</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w11</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w12</LM>
   </w.rf>
   <form>obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w13</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w15</LM>
   </w.rf>
   <form>různými</form>
   <lemma>různý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w16</LM>
   </w.rf>
   <form>výrazy</form>
   <lemma>výraz</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w18</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w19">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w20">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w21">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w21</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w22">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w22</LM>
   </w.rf>
   <form>dívám</form>
   <lemma>dívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w23">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w23</LM>
   </w.rf>
   <form>znova</form>
   <lemma>znova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w24">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w25">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w26">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w26</LM>
   </w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w27">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w27</LM>
   </w.rf>
   <form>roztomilý</form>
   <lemma>roztomilý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1556-s1-w28">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1556-s1-w28</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1557-s1-w7">
  <m id="jh_15-SCzechM-p1557-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w2</LM>
   </w.rf>
   <form>PAM</form>
   <lemma>PAM-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w4</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w6</LM>
   </w.rf>
   <form>ničemu</form>
   <lemma>nic</lemma>
   <tag>PY--3----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w7</LM>
   </w.rf>
   <form>nepřichytává</form>
   <lemma>přichytávat_^(*4at)_(*4it)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1557-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1557-s1-w8</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1559-s1-w2">
  <m id="jh_15-SCzechM-p1559-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1559-s1-w1</LM>
   </w.rf>
   <form>Rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1559-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1559-s1-w2</LM>
   </w.rf>
   <form>lížu</form>
   <lemma>lízat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="jh_15-SCzechM-p1559-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1559-s1-w3</LM>
   </w.rf>
   <form>tvou</form>
   <lemma>tvůj</lemma>
   <tag>PSFS4-S2------1</tag>
  </m>
  <m id="jh_15-SCzechM-p1559-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1559-s1-w4</LM>
   </w.rf>
   <form>buchtu</form>
   <lemma>buchta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1559-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1559-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1562-s1-w7">
  <m id="jh_15-SCzechM-p1562-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w2</LM>
   </w.rf>
   <form>dluhy</form>
   <lemma>dluh</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w5</LM>
   </w.rf>
   <form>podnik</form>
   <lemma>podnik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w6</LM>
   </w.rf>
   <form>výhodou</form>
   <lemma>výhoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w8</LM>
   </w.rf>
   <form>zvyšují</form>
   <lemma>zvyšovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1562-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1562-s1-w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1570-s1-w1">
  <m id="jh_15-SCzechM-p1570-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w3</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w5</LM>
   </w.rf>
   <form>začít</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w6</LM>
   </w.rf>
   <form>vyprávění</form>
   <lemma>vyprávění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w8</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS6---------1</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w9</LM>
   </w.rf>
   <form>rodině</form>
   <lemma>rodina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w11</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w12</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w13</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w14</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w16</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w17</LM>
   </w.rf>
   <form>mladším</form>
   <lemma>mladý</lemma>
   <tag>AAMS7----2A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1570-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1570-s1-w18</LM>
   </w.rf>
   <form>bratrem</form>
   <lemma>bratr</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1571-s1-w1">
  <m id="jh_15-SCzechM-p1571-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w1</LM>
   </w.rf>
   <form>Vítejte</form>
   <lemma>vítat</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w2</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w3</LM>
   </w.rf>
   <form>plní</form>
   <lemma>plný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w4</LM>
   </w.rf>
   <form>členové</form>
   <lemma>člen-2</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w6</LM>
   </w.rf>
   <form>Mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w7</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1571-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1571-s1-w8</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1574-s1-w6">
  <m id="jh_15-SCzechM-p1574-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w2</LM>
   </w.rf>
   <form>pomozte</form>
   <lemma>pomoci</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w5</LM>
   </w.rf>
   <form>jasné</form>
   <lemma>jasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w7</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w9</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w10</LM>
   </w.rf>
   <form>zákazníka</form>
   <lemma>zákazník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1574-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1574-s1-w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1575-s1-w1">
  <m id="jh_15-SCzechM-p1575-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w1</LM>
   </w.rf>
   <form>Používají</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w2</LM>
   </w.rf>
   <form>techniku</form>
   <lemma>technika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w3</LM>
   </w.rf>
   <form>jménem</form>
   <lemma>jméno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w4</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w5</LM>
   </w.rf>
   <form>míchaný</form>
   <lemma>míchaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w6</LM>
   </w.rf>
   <form>sortiment</form>
   <lemma>sortiment</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w7</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1575-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1575-s1-w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1578-s1-w1">
  <m id="jh_15-SCzechM-p1578-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1578-s1-w1</LM>
   </w.rf>
   <form>Miluju</form>
   <lemma>milovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1578-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1578-s1-w2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1578-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1578-s1-w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1579-s1-w1">
  <m id="jh_15-SCzechM-p1579-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1579-s1-w1</LM>
   </w.rf>
   <form>Nejsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1579-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1579-s1-w2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1579-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1579-s1-w3</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1579-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1579-s1-w4</LM>
   </w.rf>
   <form>jistý</form>
   <lemma>jistý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1579-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1579-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1580-s1-w3">
  <m id="jh_15-SCzechM-p1580-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1580-s1-w1</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1580-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1580-s1-w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1580-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1580-s1-w3</LM>
   </w.rf>
   <form>děje</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1581-s1-w2">
  <m id="jh_15-SCzechM-p1581-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1581-s1-w1</LM>
   </w.rf>
   <form>rozhodovací</form>
   <lemma>rozhodovací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1581-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1581-s1-w2</LM>
   </w.rf>
   <form>proces</form>
   <lemma>proces</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1585-s1-w1">
  <m id="jh_15-SCzechM-p1585-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w1</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w5</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w6</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w7</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1585-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1585-s1-w8</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1586-s1-w4">
  <m id="jh_15-SCzechM-p1586-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w1</LM>
   </w.rf>
   <form>ZPRAVODAJ</form>
   <lemma>zpravodaj-1_^(tiskovina;_zpravodajství)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w2</LM>
   </w.rf>
   <form>ZDARMA</form>
   <lemma>zdarma</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w4</LM>
   </w.rf>
   <form>Držte</form>
   <lemma>držet</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w5</LM>
   </w.rf>
   <form>krok</form>
   <lemma>krok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w7</LM>
   </w.rf>
   <form>nejnovějším</form>
   <lemma>nový</lemma>
   <tag>AAIS7----3A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w8</LM>
   </w.rf>
   <form>vývojem</form>
   <lemma>vývoj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w10</LM>
   </w.rf>
   <form>LED</form>
   <lemma>LED-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w11</LM>
   </w.rf>
   <form>průmyslu</form>
   <lemma>průmysl</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w13</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w15</LM>
   </w.rf>
   <form>předplatíte</form>
   <lemma>předplatit</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w16</LM>
   </w.rf>
   <form>Joliet</form>
   <lemma>Joliet-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w17</LM>
   </w.rf>
   <form>Priority</form>
   <lemma>Priority-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1586-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1586-s1-w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1587-s1-w1">
  <m id="jh_15-SCzechM-p1587-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1587-s1-w1</LM>
   </w.rf>
   <form>zachraň</form>
   <lemma>zachránit</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1587-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1587-s1-w2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1588-s1-w5">
  <m id="jh_15-SCzechM-p1588-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1588-s1-w1</LM>
   </w.rf>
   <form>Ahoj</form>
   <lemma>ahoj</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1588-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1588-s1-w2</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1588-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1588-s1-w3</LM>
   </w.rf>
   <form>Dobrou</form>
   <lemma>dobrý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1588-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1588-s1-w4</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1588-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1588-s1-w5</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1589-s1-w3">
  <m id="jh_15-SCzechM-p1589-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1589-s1-w1</LM>
   </w.rf>
   <form>Dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1589-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1589-s1-w2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1589-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1589-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1589-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1589-s1-w4</LM>
   </w.rf>
   <form>madam</form>
   <lemma>madam</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1589-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1589-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1591-s1-w13">
  <m id="jh_15-SCzechM-p1591-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w1</LM>
   </w.rf>
   <form>Ahoj</form>
   <lemma>ahoj</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w2</LM>
   </w.rf>
   <form>Agáto</form>
   <lemma>Agáta_;Y</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w6</LM>
   </w.rf>
   <form>jmenuješ</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---2P-AAB--</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w7</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w8</LM>
   </w.rf>
   <form>Jéje</form>
   <lemma>jéje</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w10</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w13</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1591-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1591-s1-w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1592-s1-w2">
  <m id="jh_15-SCzechM-p1592-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1592-s1-w1</LM>
   </w.rf>
   <form>nejčernější</form>
   <lemma>černý_;o</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1592-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1592-s1-w2</LM>
   </w.rf>
   <form>mrak</form>
   <lemma>mrak</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1595-s1-w1">
  <m id="jh_15-SCzechM-p1595-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1595-s1-w1</LM>
   </w.rf>
   <form>fotky</form>
   <lemma>fotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1595-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1595-s1-w2</LM>
   </w.rf>
   <form>masturbujících</form>
   <lemma>masturbující_^(*5ovat)</lemma>
   <tag>AGFP2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1595-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1595-s1-w3</LM>
   </w.rf>
   <form>dívek</form>
   <lemma>dívka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1598-s1-w2">
  <m id="jh_15-SCzechM-p1598-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1598-s1-w1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1598-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1598-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1598-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1598-s1-w3</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1598-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1598-s1-w4</LM>
   </w.rf>
   <form>Henrik</form>
   <lemma>Henrik_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1598-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1598-s1-w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1599-s1-w3">
  <m id="jh_15-SCzechM-p1599-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1599-s1-w1</LM>
   </w.rf>
   <form>Také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1599-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1599-s1-w2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1599-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1599-s1-w3</LM>
   </w.rf>
   <form>miluji</form>
   <lemma>milovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="jh_15-SCzechM-p1599-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1599-s1-w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1600-s1-w1">
  <m id="jh_15-SCzechM-p1600-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1600-s1-w1</LM>
   </w.rf>
   <form>Bože</form>
   <lemma>bůh</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1600-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1600-s1-w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1600-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1600-s1-w3</LM>
   </w.rf>
   <form>střez</form>
   <lemma>stříci_^(se_chránit_se_před...)</lemma>
   <tag>Vi-S---2--A-I--</tag>
  </m>
  <m id="jh_15-SCzechM-p1600-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1600-s1-w4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1600-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1600-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1604-s1-w3">
  <m id="jh_15-SCzechM-p1604-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1604-s1-w1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1604-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1604-s1-w2</LM>
   </w.rf>
   <form>vůlí</form>
   <lemma>vůle</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1604-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1604-s1-w3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1604-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1604-s1-w4</LM>
   </w.rf>
   <form>tvé</form>
   <lemma>tvůj</lemma>
   <tag>PSFS6-S2------1</tag>
  </m>
  <m id="jh_15-SCzechM-p1604-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1604-s1-w5</LM>
   </w.rf>
   <form>mysli</form>
   <lemma>mysl</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1605-s1-w1">
  <m id="jh_15-SCzechM-p1605-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1605-s1-w1</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1605-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1605-s1-w2</LM>
   </w.rf>
   <form>minulé</form>
   <lemma>minulý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1605-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1605-s1-w3</LM>
   </w.rf>
   <form>aktualizace</form>
   <lemma>aktualizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1605-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1605-s1-w4</LM>
   </w.rf>
   <form>neznámý</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1611-s1-w2">
  <m id="jh_15-SCzechM-p1611-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1611-s1-w1</LM>
   </w.rf>
   <form>oranžová</form>
   <lemma>oranžový_;o</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1611-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1611-s1-w2</LM>
   </w.rf>
   <form>barva</form>
   <lemma>barva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1612-s1-w1">
  <m id="jh_15-SCzechM-p1612-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w1</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w3</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w5</LM>
   </w.rf>
   <form>alternativy</form>
   <lemma>alternativa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w7</LM>
   </w.rf>
   <form>mezinárodního</form>
   <lemma>mezinárodní</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w8</LM>
   </w.rf>
   <form>marketingového</form>
   <lemma>marketingový</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w9</LM>
   </w.rf>
   <form>manažera</form>
   <lemma>manažer-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w13</LM>
   </w.rf>
   <form>rozhoduje</form>
   <lemma>rozhodovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w15</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w16</LM>
   </w.rf>
   <form>vstoupit</form>
   <lemma>vstoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w18</LM>
   </w.rf>
   <form>zahraniční</form>
   <lemma>zahraniční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w19">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w19</LM>
   </w.rf>
   <form>trhy</form>
   <lemma>trh</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1612-s1-w20">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1612-s1-w20</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1613-s1-w1">
  <m id="jh_15-SCzechM-p1613-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1613-s1-w1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1613-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1613-s1-w2</LM>
   </w.rf>
   <form>mými</form>
   <lemma>můj</lemma>
   <tag>PSXP7-S1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1613-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1613-s1-w3</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1614-s1-w7">
  <m id="jh_15-SCzechM-p1614-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w1</LM>
   </w.rf>
   <form>Ahoj</form>
   <lemma>ahoj</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w2</LM>
   </w.rf>
   <form>Hemade</form>
   <lemma>Hemad_;Y</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w4</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w5</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w7</LM>
   </w.rf>
   <form>chyběl</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w9</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w10</LM>
   </w.rf>
   <form>nepřijedeš</form>
   <lemma>přijet</lemma>
   <tag>VB-S---2P-NAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w12</LM>
   </w.rf>
   <form>Ameriky</form>
   <lemma>Amerika_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w14</LM>
   </w.rf>
   <form>Hamim</form>
   <lemma>Hami-2_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1614-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1614-s1-w15</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1616-s1-w1">
  <m id="jh_15-SCzechM-p1616-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w1</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1616-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1616-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w3</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSIP1-P2-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1616-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w4</LM>
   </w.rf>
   <form>sny</form>
   <lemma>sen-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1616-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w5</LM>
   </w.rf>
   <form>splní</form>
   <lemma>splnit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="jh_15-SCzechM-p1616-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1616-s1-w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1618-s1-w1">
  <m id="jh_15-SCzechM-p1618-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1618-s1-w1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1618-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1618-s1-w2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1618-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1618-s1-w3</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1618-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1618-s1-w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1620-s1-w1">
  <m id="jh_15-SCzechM-p1620-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1620-s1-w1</LM>
   </w.rf>
   <form>změnit</form>
   <lemma>změnit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1620-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1620-s1-w2</LM>
   </w.rf>
   <form>formát</form>
   <lemma>formát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1620-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1620-s1-w3</LM>
   </w.rf>
   <form>zobrazení</form>
   <lemma>zobrazení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1620-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1620-s1-w4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1620-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1620-s1-w5</LM>
   </w.rf>
   <form>obrázky</form>
   <lemma>obrázek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1622-s1-w2">
  <m id="jh_15-SCzechM-p1622-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w1</LM>
   </w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w3">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w3</LM>
   </w.rf>
   <form>zvýšit</form>
   <lemma>zvýšit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w4">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w4</LM>
   </w.rf>
   <form>veřejné</form>
   <lemma>veřejný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w5">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w5</LM>
   </w.rf>
   <form>povědomí</form>
   <lemma>povědomí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w6">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w7">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w7</LM>
   </w.rf>
   <form>důležitosti</form>
   <lemma>důležitost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w8">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w8</LM>
   </w.rf>
   <form>hongkongského</form>
   <lemma>hongkongský</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w9">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w9</LM>
   </w.rf>
   <form>dědictví</form>
   <lemma>dědictví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w10">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w11">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w11</LM>
   </w.rf>
   <form>vzdělávat</form>
   <lemma>vzdělávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w12">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w12</LM>
   </w.rf>
   <form>budoucí</form>
   <lemma>budoucí</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w13">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w13</LM>
   </w.rf>
   <form>generace</form>
   <lemma>generace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w14">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w15">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w15</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w16">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w17">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w18">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w18</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSNS4-P1-------</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w19">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w19</LM>
   </w.rf>
   <form>dědictví</form>
   <lemma>dědictví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w20">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w20</LM>
   </w.rf>
   <form>staraly</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="jh_15-SCzechM-p1622-s1-w21">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1622-s1-w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-jh_15-SCzechM-p1623-s1-w1">
  <m id="jh_15-SCzechM-p1623-s1-w1">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1623-s1-w1</LM>
   </w.rf>
   <form>Pomsta</form>
   <lemma>pomsta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="jh_15-SCzechM-p1623-s1-w2">
   <w.rf>
    <LM>w#w-jh_15-SCzechM-p1623-s1-w2</LM>
   </w.rf>
   <form>Padlých</form>
   <lemma>padlý_^(*2nout)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
 </s>
</mdata>
