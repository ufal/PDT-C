<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="faust_2010_07_es_05.w.gz" />
  </references>
 </head>
 <s id="s-es_05-SCzechM-p0434-s1-w7">
  <m id="es_05-SCzechM-p0434-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w1</LM>
   </w.rf>
   <form>především</form>
   <lemma>především-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w3</LM>
   </w.rf>
   <form>spojený</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w5</LM>
   </w.rf>
   <form>riziko</form>
   <lemma>riziko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0434-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0434-s1-w7</LM>
   </w.rf>
   <form>způsobený</form>
   <lemma>způsobený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0435-s1-w2">
  <m id="es_05-SCzechM-p0435-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w1</LM>
   </w.rf>
   <form>Zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w3</LM>
   </w.rf>
   <form>blahopřání</form>
   <lemma>blahopřání_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w5</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w6</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w7</LM>
   </w.rf>
   <form>přinese</form>
   <lemma>přinést</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w8</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w9</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0435-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0435-s1-w10</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0436-s1-w12">
  <m id="es_05-SCzechM-p0436-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w1</LM>
   </w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w3</LM>
   </w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--3----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w4</LM>
   </w.rf>
   <form>neuváženým</form>
   <lemma>uvážený_^(*2t)_(*3it)</lemma>
   <tag>AANP3----1N----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w5</LM>
   </w.rf>
   <form>slovům</form>
   <lemma>slovo</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w7</LM>
   </w.rf>
   <form>smutný</form>
   <lemma>smutný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w8</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w9</LM>
   </w.rf>
   <form>dlouhou</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w10</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w13</LM>
   </w.rf>
   <form>nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w14</LM>
   </w.rf>
   <form>obtěžovat</form>
   <lemma>obtěžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w15</LM>
   </w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w18</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w20</LM>
   </w.rf>
   <form>nechám</form>
   <lemma>nechat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w21</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w22</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0436-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0436-s1-w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0443-s1-w1">
  <m id="es_05-SCzechM-p0443-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0443-s1-w1</LM>
   </w.rf>
   <form>Vývoj</form>
   <lemma>vývoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0443-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0443-s1-w2</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0443-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0443-s1-w3</LM>
   </w.rf>
   <form>technologie</form>
   <lemma>technologie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0447-s1-w1">
  <m id="es_05-SCzechM-p0447-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0447-s1-w1</LM>
   </w.rf>
   <form>chybíš</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0447-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0447-s1-w2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0448-s1-w2">
  <m id="es_05-SCzechM-p0448-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w1</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0448-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0448-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0448-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w4</LM>
   </w.rf>
   <form>šílenství</form>
   <lemma>šílenství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0448-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w5</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0448-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0448-s1-w6</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0454-s1-w7">
  <m id="es_05-SCzechM-p0454-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w1</LM>
   </w.rf>
   <form>47</form>
   <lemma>47</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w2</LM>
   </w.rf>
   <form>milionů</form>
   <lemma>milion`1000000_,s_^(^DD**milión)</lemma>
   <tag>CzIP2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w5</LM>
   </w.rf>
   <form>ostatky</form>
   <lemma>ostatek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w6</LM>
   </w.rf>
   <form>Idy</form>
   <lemma>Ida_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w8</LM>
   </w.rf>
   <form>nejúplnější</form>
   <lemma>úplný</lemma>
   <tag>AAFS7----3A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w9</LM>
   </w.rf>
   <form>kostrou</form>
   <lemma>kostra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w10</LM>
   </w.rf>
   <form>primáta</form>
   <lemma>primát-2</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w12</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w13</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w15</LM>
   </w.rf>
   <form>nalezena</form>
   <lemma>naleznout</lemma>
   <tag>VsQW----X-APP-1</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w17</LM>
   </w.rf>
   <form>Kostra</form>
   <lemma>kostra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w18</LM>
   </w.rf>
   <form>mladé</form>
   <lemma>mladý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w19</LM>
   </w.rf>
   <form>samice</form>
   <lemma>samice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w20</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w21</LM>
   </w.rf>
   <form>nalezena</form>
   <lemma>naleznout</lemma>
   <tag>VsQW----X-APP-1</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0454-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0454-s1-w23</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0459-s1-w2">
  <m id="es_05-SCzechM-p0459-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w1</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w3</LM>
   </w.rf>
   <form>15</form>
   <lemma>15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w4</LM>
   </w.rf>
   <form>Pěší</form>
   <lemma>pěší</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w5</LM>
   </w.rf>
   <form>hlídka</form>
   <lemma>hlídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w9</LM>
   </w.rf>
   <form>zjistila</form>
   <lemma>zjistit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w11</LM>
   </w.rf>
   <form>zkontrolovala</form>
   <lemma>zkontrolovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w12</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w13</LM>
   </w.rf>
   <form>činu</form>
   <lemma>čin</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w14</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w15</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w16</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w18</LM>
   </w.rf>
   <form>obvyklém</form>
   <lemma>obvyklý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w19</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0459-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0459-s1-w20</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0463-s1-w2">
  <m id="es_05-SCzechM-p0463-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0463-s1-w1</LM>
   </w.rf>
   <form>zeštíhlovací</form>
   <lemma>zeštíhlovací_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0463-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0463-s1-w2</LM>
   </w.rf>
   <form>masáž</form>
   <lemma>masáž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0467-s1-w8">
  <m id="es_05-SCzechM-p0467-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w1</LM>
   </w.rf>
   <form>Kódovací</form>
   <lemma>kódovací_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w2</LM>
   </w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w3</LM>
   </w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w4</LM>
   </w.rf>
   <form>používat</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w5</LM>
   </w.rf>
   <form>delší</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIS4----2A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w6</LM>
   </w.rf>
   <form>blok</form>
   <lemma>blok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w9</LM>
   </w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w10</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w11</LM>
   </w.rf>
   <form>kratších</form>
   <lemma>krátký</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w12</LM>
   </w.rf>
   <form>bloků</form>
   <lemma>blok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w13</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w14</LM>
   </w.rf>
   <form>lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w15</LM>
   </w.rf>
   <form>rozlišit</form>
   <lemma>rozlišit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w16</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w18</LM>
   </w.rf>
   <form>Počet</form>
   <lemma>počet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w19</LM>
   </w.rf>
   <form>pásem</form>
   <lemma>pás_^(pruh_[zejm._tkaniny])</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w20</LM>
   </w.rf>
   <form>rozsahů</form>
   <lemma>rozsah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w21</LM>
   </w.rf>
   <form>stupnice</form>
   <lemma>stupnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w23</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w24</LM>
   </w.rf>
   <form>kratší</form>
   <lemma>krátký</lemma>
   <tag>AAIP4----2A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w26</LM>
   </w.rf>
   <form>delší</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIP4----2A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w27</LM>
   </w.rf>
   <form>bloky</form>
   <lemma>blok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w28</LM>
   </w.rf>
   <form>liší</form>
   <lemma>lišit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0467-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0467-s1-w29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0469-s1-w3">
  <m id="es_05-SCzechM-p0469-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w1</LM>
   </w.rf>
   <form>vývoj</form>
   <lemma>vývoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w2</LM>
   </w.rf>
   <form>zásad</form>
   <lemma>zásada</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w5</LM>
   </w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w6</LM>
   </w.rf>
   <form>tvorbu</form>
   <lemma>tvorba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0469-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0469-s1-w7</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0475-s1-w1">
  <m id="es_05-SCzechM-p0475-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0475-s1-w1</LM>
   </w.rf>
   <form>událost</form>
   <lemma>událost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0475-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0475-s1-w2</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP2-P1-------</tag>
  </m>
  <m id="es_05-SCzechM-p0475-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0475-s1-w3</LM>
   </w.rf>
   <form>snů</form>
   <lemma>sen-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0476-s1-w2">
  <m id="es_05-SCzechM-p0476-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0476-s1-w1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0476-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0476-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0476-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0476-s1-w3</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="es_05-SCzechM-p0476-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0476-s1-w4</LM>
   </w.rf>
   <form>kniha</form>
   <lemma>kniha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0480-s1-w1">
  <m id="es_05-SCzechM-p0480-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0480-s1-w1</LM>
   </w.rf>
   <form>Ministerstvo</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0480-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0480-s1-w2</LM>
   </w.rf>
   <form>vnitra</form>
   <lemma>vnitro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0481-s1-w2">
  <m id="es_05-SCzechM-p0481-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w1</LM>
   </w.rf>
   <form>EFT</form>
   <lemma>EFT-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w3</LM>
   </w.rf>
   <form>celosvětová</form>
   <lemma>celosvětový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w4</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w5</LM>
   </w.rf>
   <form>zabývající</form>
   <lemma>zabývající_^(*4t)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w7</LM>
   </w.rf>
   <form>marketingem</form>
   <lemma>marketing</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w9</LM>
   </w.rf>
   <form>elektronickém</form>
   <lemma>elektronický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w10</LM>
   </w.rf>
   <form>obchodování</form>
   <lemma>obchodování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w11</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w12</LM>
   </w.rf>
   <form>spotřebiteli</form>
   <lemma>spotřebitel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w14</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w15</LM>
   </w.rf>
   <form>využívá</form>
   <lemma>využívat_^(*3t)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w16</LM>
   </w.rf>
   <form>širokou</form>
   <lemma>široký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w17</LM>
   </w.rf>
   <form>základnu</form>
   <lemma>základna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w18</LM>
   </w.rf>
   <form>jednotlivých</form>
   <lemma>jednotlivý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w19</LM>
   </w.rf>
   <form>členských</form>
   <lemma>členský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w20</LM>
   </w.rf>
   <form>poboček</form>
   <lemma>pobočka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w21</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w22</LM>
   </w.rf>
   <form>prodeji</form>
   <lemma>prodej_^(akt_prodeje_zboží)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w23</LM>
   </w.rf>
   <form>značkových</form>
   <lemma>značkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w24</LM>
   </w.rf>
   <form>osobních</form>
   <lemma>osobní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w25</LM>
   </w.rf>
   <form>produktů</form>
   <lemma>produkt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w26</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w27</LM>
   </w.rf>
   <form>poskytování</form>
   <lemma>poskytování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w28</LM>
   </w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w29</LM>
   </w.rf>
   <form>unikátních</form>
   <lemma>unikátní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w30">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w30</LM>
   </w.rf>
   <form>služeb</form>
   <lemma>služba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w31">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w31</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w32">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w32</LM>
   </w.rf>
   <form>Sídlo</form>
   <lemma>sídlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w33">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w33</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w34">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w34</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w35">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w35</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w36">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w36</LM>
   </w.rf>
   <form>jižní</form>
   <lemma>jižní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w37">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w37</LM>
   </w.rf>
   <form>Kalifornii</form>
   <lemma>Kalifornie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w38">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w38</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w39">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w39</LM>
   </w.rf>
   <form>členové</form>
   <lemma>člen-2</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w40">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w40</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w41">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w41</LM>
   </w.rf>
   <form>poskytují</form>
   <lemma>poskytovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w42">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w42</LM>
   </w.rf>
   <form>služby</form>
   <lemma>služba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w43">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w43</LM>
   </w.rf>
   <form>především</form>
   <lemma>především-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w44">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w44</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w45">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w45</LM>
   </w.rf>
   <form>Asii</form>
   <lemma>Asie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w46">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w46</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w47">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w47</LM>
   </w.rf>
   <form>východní</form>
   <lemma>východní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w48">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w48</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w49">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w49</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w50">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w50</LM>
   </w.rf>
   <form>Latinské</form>
   <lemma>latinský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w51">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w51</LM>
   </w.rf>
   <form>Americe</form>
   <lemma>Amerika_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0481-s1-w52">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0481-s1-w52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0482-s1-w2">
  <m id="es_05-SCzechM-p0482-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0482-s1-w1</LM>
   </w.rf>
   <form>Celní</form>
   <lemma>celní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0482-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0482-s1-w2</LM>
   </w.rf>
   <form>poplatky</form>
   <lemma>poplatek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0483-s1-w3">
  <m id="es_05-SCzechM-p0483-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w1</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w2</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w3</LM>
   </w.rf>
   <form>číst</form>
   <lemma>číst</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w5</LM>
   </w.rf>
   <form>jelenovi</form>
   <lemma>jelen</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w6</LM>
   </w.rf>
   <form>milu</form>
   <lemma>milu_^(druh_jelena)</lemma>
   <tag>NNMXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0483-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0483-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0489-s1-w5">
  <m id="es_05-SCzechM-p0489-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w4</LM>
   </w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w5</LM>
   </w.rf>
   <form>volá</form>
   <lemma>volat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w10</LM>
   </w.rf>
   <form>lesa</form>
   <lemma>les</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0489-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0489-s1-w11</LM>
   </w.rf>
   <form>ozývá</form>
   <lemma>ozývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0491-s1-w1">
  <m id="es_05-SCzechM-p0491-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w1</LM>
   </w.rf>
   <form>R</form>
   <lemma>R-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w2</LM>
   </w.rf>
   <form>2012</form>
   <lemma>2012</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w8</LM>
   </w.rf>
   <form>Mládeži</form>
   <lemma>mládež</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w9</LM>
   </w.rf>
   <form>nepřístupno</form>
   <lemma>přístupný</lemma>
   <tag>ACNS------N----</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w10</LM>
   </w.rf>
   <form>Pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w11</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0491-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0491-s1-w12</LM>
   </w.rf>
   <form>dospělé</form>
   <lemma>dospělý-2</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0492-s1-w1">
  <m id="es_05-SCzechM-p0492-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w1</LM>
   </w.rf>
   <form>Můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w3</LM>
   </w.rf>
   <form>požádat</form>
   <lemma>požádat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w5</LM>
   </w.rf>
   <form>abys</form>
   <lemma>aby</lemma>
   <tag>J,-----------s-</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w7</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w8</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w9</LM>
   </w.rf>
   <form>vykouřila</form>
   <lemma>vykouřit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0492-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0492-s1-w10</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0493-s1-w3">
  <m id="es_05-SCzechM-p0493-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0493-s1-w1</LM>
   </w.rf>
   <form>Smrtící</form>
   <lemma>smrtící</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0493-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0493-s1-w2</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0493-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0493-s1-w3</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0496-s1-w2">
  <m id="es_05-SCzechM-p0496-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w1</LM>
   </w.rf>
   <form>Lvi</form>
   <lemma>lev</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w3</LM>
   </w.rf>
   <form>jediné</form>
   <lemma>jediný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w4</LM>
   </w.rf>
   <form>kočky</form>
   <lemma>kočka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w7</LM>
   </w.rf>
   <form>žijí</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w9</LM>
   </w.rf>
   <form>skupinách</form>
   <lemma>skupina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w11</LM>
   </w.rf>
   <form>tzv</form>
   <lemma>takzvaný</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w13</LM>
   </w.rf>
   <form>smečkách</form>
   <lemma>smečka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w15</LM>
   </w.rf>
   <form>Smečky</form>
   <lemma>smečka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w16</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w17</LM>
   </w.rf>
   <form>rodinné</form>
   <lemma>rodinný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w18</LM>
   </w.rf>
   <form>celky</form>
   <lemma>celek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w20</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w21</LM>
   </w.rf>
   <form>mohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w22</LM>
   </w.rf>
   <form>obsahovat</form>
   <lemma>obsahovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w23</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w24</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w25</LM>
   </w.rf>
   <form>samce</form>
   <lemma>samec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w27</LM>
   </w.rf>
   <form>přibližně</form>
   <lemma>přibližně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w28</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w29</LM>
   </w.rf>
   <form>samic</form>
   <lemma>samice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w30">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w30</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w31">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w31</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w32">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w32</LM>
   </w.rf>
   <form>mláďata</form>
   <lemma>mládě</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0496-s1-w33">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0496-s1-w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0497-s1-w4">
  <m id="es_05-SCzechM-p0497-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w2</LM>
   </w.rf>
   <form>státě</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w3</LM>
   </w.rf>
   <form>Maine</form>
   <lemma>Maine_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w4</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w5</LM>
   </w.rf>
   <form>jedovatí</form>
   <lemma>jedovatý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w6</LM>
   </w.rf>
   <form>hadi</form>
   <lemma>had</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="es_05-SCzechM-p0497-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0497-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0499-s1-w1">
  <m id="es_05-SCzechM-p0499-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0499-s1-w1</LM>
   </w.rf>
   <form>vytvořit</form>
   <lemma>vytvořit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0499-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0499-s1-w2</LM>
   </w.rf>
   <form>popis</form>
   <lemma>popis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0499-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0499-s1-w3</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0500-s1-w4">
  <m id="es_05-SCzechM-p0500-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w1</LM>
   </w.rf>
   <form>Dalším</form>
   <lemma>další</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w2</LM>
   </w.rf>
   <form>problémem</form>
   <lemma>problém</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w3</LM>
   </w.rf>
   <form>globalizace</form>
   <lemma>globalizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w5</LM>
   </w.rf>
   <form>vědomí</form>
   <lemma>vědomí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w8</LM>
   </w.rf>
   <form>ekonomická</form>
   <lemma>ekonomický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w9</LM>
   </w.rf>
   <form>liberalizace</form>
   <lemma>liberalizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w10</LM>
   </w.rf>
   <form>prohloubila</form>
   <lemma>prohloubit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w11</LM>
   </w.rf>
   <form>rozdíly</form>
   <lemma>rozdíl</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w12</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w13</LM>
   </w.rf>
   <form>bohatými</form>
   <lemma>bohatý</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w15</LM>
   </w.rf>
   <form>chudými</form>
   <lemma>chudý-1</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w16</LM>
   </w.rf>
   <form>zeměmi</form>
   <lemma>země</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w18</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w19</LM>
   </w.rf>
   <form>bohatými</form>
   <lemma>bohatý</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w21</LM>
   </w.rf>
   <form>chudými</form>
   <lemma>chudý-1</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w23</LM>
   </w.rf>
   <form>zemích</form>
   <lemma>země</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w24</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w25</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w26</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w27</LM>
   </w.rf>
   <form>liberalizací</form>
   <lemma>liberalizace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w28</LM>
   </w.rf>
   <form>prošly</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0500-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0500-s1-w29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0501-s1-w1">
  <m id="es_05-SCzechM-p0501-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0501-s1-w1</LM>
   </w.rf>
   <form>brnkni</form>
   <lemma>brnknout</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0501-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0501-s1-w2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0502-s1-w2">
  <m id="es_05-SCzechM-p0502-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w1</LM>
   </w.rf>
   <form>http</form>
   <lemma>http_^(Hypertext_transfer_protocol)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w3</LM>
   </w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w4</LM>
   </w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w5</LM>
   </w.rf>
   <form>www</form>
   <lemma>www_^(world_wide_web)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w7</LM>
   </w.rf>
   <form>GarysWine</form>
   <lemma>GarysWine-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w9</LM>
   </w.rf>
   <form>com</form>
   <lemma>com-3_^(doména)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w10</LM>
   </w.rf>
   <form>Gary</form>
   <lemma>Gary-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w11</LM>
   </w.rf>
   <form>Fisch</form>
   <lemma>Fisch_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w12</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w13</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w14</LM>
   </w.rf>
   <form>Gary</form>
   <lemma>Gary-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w15</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w16</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w17</LM>
   </w.rf>
   <form>Wine</form>
   <lemma>Wine-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w18</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w19</LM>
   </w.rf>
   <form>Marketplace</form>
   <lemma>Marketplace-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w20</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w21</LM>
   </w.rf>
   <form>New</form>
   <lemma>New-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w22</LM>
   </w.rf>
   <form>Jersey</form>
   <lemma>Jersey-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w23</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w24</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w25</LM>
   </w.rf>
   <form>komisí</form>
   <lemma>komise</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w26</LM>
   </w.rf>
   <form>znalců</form>
   <lemma>znalec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w27</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w28</LM>
   </w.rf>
   <form>Billa</form>
   <lemma>Bill_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w29</LM>
   </w.rf>
   <form>Terlata</form>
   <lemma>Terlat_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w30">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w31">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w31</LM>
   </w.rf>
   <form>zúčastní</form>
   <lemma>zúčastnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w32">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w32</LM>
   </w.rf>
   <form>dvojitého</form>
   <lemma>dvojitý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w33">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w33</LM>
   </w.rf>
   <form>slepého</form>
   <lemma>slepý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w34">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w34</LM>
   </w.rf>
   <form>testu</form>
   <lemma>test</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w35">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w35</LM>
   </w.rf>
   <form>vín</form>
   <lemma>víno</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w36">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w36</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w37">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w37</LM>
   </w.rf>
   <form>Napa</form>
   <lemma>Napa-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w38">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w38</LM>
   </w.rf>
   <form>Valley</form>
   <lemma>Valley-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0502-s1-w39">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0502-s1-w39</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0503-s1-w1">
  <m id="es_05-SCzechM-p0503-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0503-s1-w1</LM>
   </w.rf>
   <form>poslat</form>
   <lemma>poslat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0503-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0503-s1-w2</LM>
   </w.rf>
   <form>e</form>
   <lemma>e-2_^(e-mail)</lemma>
   <tag>S2--------A----</tag>
  </m>
  <m id="es_05-SCzechM-p0503-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0503-s1-w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0503-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0503-s1-w4</LM>
   </w.rf>
   <form>mail</form>
   <lemma>mail</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0504-s1-w1">
  <m id="es_05-SCzechM-p0504-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0504-s1-w1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0508-s1-w5">
  <m id="es_05-SCzechM-p0508-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w1</LM>
   </w.rf>
   <form>Dodávka</form>
   <lemma>dodávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0508-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w2</LM>
   </w.rf>
   <form>následujícím</form>
   <lemma>následující_^(*5ovat)</lemma>
   <tag>AGMP3-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0508-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w3</LM>
   </w.rf>
   <form>příjemcům</form>
   <lemma>příjemce</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0508-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0508-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w5</LM>
   </w.rf>
   <form>opozdila</form>
   <lemma>opozdit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0508-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0508-s1-w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0510-s1-w3">
  <m id="es_05-SCzechM-p0510-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w2</LM>
   </w.rf>
   <form>Sony</form>
   <lemma>Sony_;m</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w3</LM>
   </w.rf>
   <form>prozradila</form>
   <lemma>prozradit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w5</LM>
   </w.rf>
   <form>časopise</form>
   <lemma>časopis</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w6</LM>
   </w.rf>
   <form>PlayStation</form>
   <lemma>PlayStation-1_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w7</LM>
   </w.rf>
   <form>datum</form>
   <lemma>datum-1_^(kalendářní)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w8</LM>
   </w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w9</LM>
   </w.rf>
   <form>dílu</form>
   <lemma>díl_^(jeden_díl_[z_celku])</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0510-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0510-s1-w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0512-s1-w1">
  <m id="es_05-SCzechM-p0512-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0512-s1-w1</LM>
   </w.rf>
   <form>stadium</form>
   <lemma>stadium_,s_^(^DD**stádium)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0512-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0512-s1-w2</LM>
   </w.rf>
   <form>semenáčku</form>
   <lemma>semenáček</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0513-s1-w3">
  <m id="es_05-SCzechM-p0513-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w1</LM>
   </w.rf>
   <form>Radostné</form>
   <lemma>radostný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0513-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w2</LM>
   </w.rf>
   <form>vánoce</form>
   <lemma>vánoce_,i_^(^DS**Vánoce)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0513-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0513-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w4</LM>
   </w.rf>
   <form>šťastný</form>
   <lemma>šťastný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0513-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w5</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0513-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0513-s1-w6</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0515-s1-w1">
  <m id="es_05-SCzechM-p0515-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w2</LM>
   </w.rf>
   <form>Forcht</form>
   <lemma>Forcht_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w3</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w4</LM>
   </w.rf>
   <form>1994</form>
   <lemma>1994</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w6</LM>
   </w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w7</LM>
   </w.rf>
   <form>navrhují</form>
   <lemma>navrhovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w10</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w11</LM>
   </w.rf>
   <form>výuka</form>
   <lemma>výuka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w12</LM>
   </w.rf>
   <form>etiky</form>
   <lemma>etika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w14</LM>
   </w.rf>
   <form>významu</form>
   <lemma>význam</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w15</LM>
   </w.rf>
   <form>informačních</form>
   <lemma>informační</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w16</LM>
   </w.rf>
   <form>technologií</form>
   <lemma>technologie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w17</LM>
   </w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w18</LM>
   </w.rf>
   <form>omezit</form>
   <lemma>omezit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w19</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w20</LM>
   </w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w22</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w24</LM>
   </w.rf>
   <form>vytváření</form>
   <lemma>vytváření_^(*2t)_(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w26</LM>
   </w.rf>
   <form>distribuce</form>
   <lemma>distribuce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0515-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0515-s1-w27</LM>
   </w.rf>
   <form>virů</form>
   <lemma>vir-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0517-s1-w1">
  <m id="es_05-SCzechM-p0517-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0517-s1-w1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0517-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0517-s1-w2</LM>
   </w.rf>
   <form>úspěchem</form>
   <lemma>úspěch</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0518-s1-w3">
  <m id="es_05-SCzechM-p0518-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w1</LM>
   </w.rf>
   <form>Dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w4</LM>
   </w.rf>
   <form>drahý</form>
   <lemma>drahý</lemma>
   <tag>AAMS5----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w5</LM>
   </w.rf>
   <form>příteli</form>
   <lemma>přítel</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w7</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w10</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w11</LM>
   </w.rf>
   <form>částka</form>
   <lemma>částka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w12</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w14</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w15</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w16</LM>
   </w.rf>
   <form>dáš</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---2P-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w17</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w19</LM>
   </w.rf>
   <form>koupím</form>
   <lemma>koupit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w22</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="es_05-SCzechM-p0518-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0518-s1-w23</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ty</lemma>
   <tag>PH-S3--2-------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0520-s1-w1">
  <m id="es_05-SCzechM-p0520-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0520-s1-w1</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0520-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0520-s1-w2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0525-s1-w1">
  <m id="es_05-SCzechM-p0525-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0525-s1-w1</LM>
   </w.rf>
   <form>nepřizpůsobivost</form>
   <lemma>přizpůsobivost_^(*3ý)</lemma>
   <tag>NNFS1-----N----</tag>
  </m>
  <m id="es_05-SCzechM-p0525-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0525-s1-w2</LM>
   </w.rf>
   <form>rezervace</form>
   <lemma>rezervace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0526-s1-w6">
  <m id="es_05-SCzechM-p0526-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w2</LM>
   </w.rf>
   <form>uživatelské</form>
   <lemma>uživatelský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w3</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w5</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w6</LM>
   </w.rf>
   <form>používáno</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w8</LM>
   </w.rf>
   <form>Vyberte</form>
   <lemma>vybrat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w10</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w11</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0526-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0526-s1-w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0528-s1-w4">
  <m id="es_05-SCzechM-p0528-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0528-s1-w1</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0528-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0528-s1-w2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0528-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0528-s1-w3</LM>
   </w.rf>
   <form>tebe</form>
   <lemma>ty</lemma>
   <tag>PP-S4--2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0528-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0528-s1-w4</LM>
   </w.rf>
   <form>čekám</form>
   <lemma>čekat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0533-s1-w1">
  <m id="es_05-SCzechM-p0533-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0533-s1-w1</LM>
   </w.rf>
   <form>ošukat</form>
   <lemma>ošukat_,h</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="es_05-SCzechM-p0533-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0533-s1-w2</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0534-s1-w1">
  <m id="es_05-SCzechM-p0534-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0534-s1-w1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0535-s1-w1">
  <m id="es_05-SCzechM-p0535-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w1</LM>
   </w.rf>
   <form>Odkazuje</form>
   <lemma>odkazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0535-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0535-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w3</LM>
   </w.rf>
   <form>aktivní</form>
   <lemma>aktivní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0535-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w4</LM>
   </w.rf>
   <form>ovládací</form>
   <lemma>ovládací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0535-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w5</LM>
   </w.rf>
   <form>prvek</form>
   <lemma>prvek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0535-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0535-s1-w6</LM>
   </w.rf>
   <form>objektu</form>
   <lemma>objekt</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0538-s1-w8">
  <m id="es_05-SCzechM-p0538-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w1</LM>
   </w.rf>
   <form>Dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w4</LM>
   </w.rf>
   <form>šťastný</form>
   <lemma>šťastný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w5</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w6</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w7</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w8</LM>
   </w.rf>
   <form>Doufám</form>
   <lemma>doufat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w12</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w13</LM>
   </w.rf>
   <form>sezóna</form>
   <lemma>sezóna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w14</LM>
   </w.rf>
   <form>dovolených</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w15</LM>
   </w.rf>
   <form>vydařila</form>
   <lemma>vydařit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w16">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w17">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w17</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w18">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w18</LM>
   </w.rf>
   <form>aktualizujeme</form>
   <lemma>aktualizovat</lemma>
   <tag>VB-P---1P-AAB--</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w19">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w19</LM>
   </w.rf>
   <form>kontaktní</form>
   <lemma>kontaktní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w20">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w20</LM>
   </w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w21">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w22">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w22</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w23">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w23</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w24">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w24</LM>
   </w.rf>
   <form>obchod</form>
   <lemma>obchod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w25">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w25</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w26">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w26</LM>
   </w.rf>
   <form>adresu</form>
   <lemma>adresa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w27">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w27</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w28">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w28</LM>
   </w.rf>
   <form>Serkos</form>
   <lemma>Serkos-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w29">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w29</LM>
   </w.rf>
   <form>Bikes</form>
   <lemma>Bikes-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w30">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w30</LM>
   </w.rf>
   <form>Kinetoy</form>
   <lemma>Kinetoy-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w31">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w31</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w32">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w32</LM>
   </w.rf>
   <form>Atény</form>
   <lemma>Atény_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w33">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w33</LM>
   </w.rf>
   <form>10555</form>
   <lemma>10555</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w34">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w34</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w35">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w35</LM>
   </w.rf>
   <form>Řecko</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w36">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w36</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w37">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w37</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w38">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w38</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w39">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w39</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w40">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w40</LM>
   </w.rf>
   <form>prodej</form>
   <lemma>prodej_^(akt_prodeje_zboží)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w41">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w41</LM>
   </w.rf>
   <form>kompletních</form>
   <lemma>kompletní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w42">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w42</LM>
   </w.rf>
   <form>kol</form>
   <lemma>kolo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w43">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w43</LM>
   </w.rf>
   <form>BMX</form>
   <lemma>BMX-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w44">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w44</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w45">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w45</LM>
   </w.rf>
   <form>částí</form>
   <lemma>část</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w46">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w46</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w47">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w47</LM>
   </w.rf>
   <form>příslušenství</form>
   <lemma>příslušenství</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w48">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w48</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w49">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w49</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="es_05-SCzechM-p0538-s1-w50">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0538-s1-w50</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0539-s1-w1">
  <m id="es_05-SCzechM-p0539-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w1</LM>
   </w.rf>
   <form>Buďte</form>
   <lemma>být</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w2</LM>
   </w.rf>
   <form>změnou</form>
   <lemma>změna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w4</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w5</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w7</LM>
   </w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0539-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0539-s1-w8</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0542-s1-w3">
  <m id="es_05-SCzechM-p0542-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w2</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w3</LM>
   </w.rf>
   <form>Manažer</form>
   <lemma>manažer-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w4</LM>
   </w.rf>
   <form>prodeje</form>
   <lemma>prodej_^(akt_prodeje_zboží)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w6</LM>
   </w.rf>
   <form>služeb</form>
   <lemma>služba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w7">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w7</LM>
   </w.rf>
   <form>zákazníkům</form>
   <lemma>zákazník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w8">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w9">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w9</LM>
   </w.rf>
   <form>manažer</form>
   <lemma>manažer-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w10">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w10</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w11">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w11</LM>
   </w.rf>
   <form>styk</form>
   <lemma>styk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w12">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w13">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w13</LM>
   </w.rf>
   <form>významnými</form>
   <lemma>významný</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w14">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w14</LM>
   </w.rf>
   <form>zákazníky</form>
   <lemma>zákazník</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0542-s1-w15">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0542-s1-w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0545-s1-w3">
  <m id="es_05-SCzechM-p0545-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w1</LM>
   </w.rf>
   <form>Síla</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0545-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w2</LM>
   </w.rf>
   <form>přilnavosti</form>
   <lemma>přilnavost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0545-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0545-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w4</LM>
   </w.rf>
   <form>Gekoni</form>
   <lemma>gekon</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="es_05-SCzechM-p0545-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w5</LM>
   </w.rf>
   <form>čelí</form>
   <lemma>čelit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0545-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0545-s1-w6</LM>
   </w.rf>
   <form>konkurenci</form>
   <lemma>konkurence</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0547-s1-w1">
  <m id="es_05-SCzechM-p0547-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0547-s1-w1</LM>
   </w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="es_05-SCzechM-p0547-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0547-s1-w2</LM>
   </w.rf>
   <form>stěnami</form>
   <lemma>stěna</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0553-s1-w1">
  <m id="es_05-SCzechM-p0553-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0553-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="es_05-SCzechM-p0553-s1-w3">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w3</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="es_05-SCzechM-p0553-s1-w4">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="es_05-SCzechM-p0553-s1-w5">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="es_05-SCzechM-p0553-s1-w6">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0553-s1-w6</LM>
   </w.rf>
   <form>milá</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="s-es_05-SCzechM-p0554-s1-w2">
  <m id="es_05-SCzechM-p0554-s1-w1">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0554-s1-w1</LM>
   </w.rf>
   <form>tvůj</form>
   <lemma>tvůj</lemma>
   <tag>PSYS1-S2-------</tag>
  </m>
  <m id="es_05-SCzechM-p0554-s1-w2">
   <w.rf>
    <LM>w#w-es_05-SCzechM-p0554-s1-w2</LM>
   </w.rf>
   <form>legrační</form>
   <lemma>legrační</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
 </s>
</mdata>
