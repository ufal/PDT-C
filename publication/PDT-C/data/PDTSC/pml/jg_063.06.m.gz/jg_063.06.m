<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_063.06.w.gz" />
  </references>
 </head>
 <s id="m063-d1e2270-x2">
  <m id="m063-d1t2277-1">
   <w.rf>
    <LM>w#w-d1t2277-1</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2277-2">
   <w.rf>
    <LM>w#w-d1t2277-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2277-3">
   <w.rf>
    <LM>w#w-d1t2277-3</LM>
   </w.rf>
   <form>vycházce</form>
   <lemma>vycházka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d1e2270-x2-195">
   <w.rf>
    <LM>w#w-d1e2270-x2-195</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2285-4">
   <w.rf>
    <LM>w#w-d1t2285-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2289-5">
   <w.rf>
    <LM>w#w-d1t2289-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2289-6">
   <w.rf>
    <LM>w#w-d1t2289-6</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m063-d1t2289-1">
   <w.rf>
    <LM>w#w-d1t2289-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m063-d1t2289-3">
   <w.rf>
    <LM>w#w-d1t2289-3</LM>
   </w.rf>
   <form>Lochotín</form>
   <lemma>Lochotín_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2270-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2270-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2282-x2">
  <m id="m063-d1t2298-2">
   <w.rf>
    <LM>w#w-d1t2298-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2298-3">
   <w.rf>
    <LM>w#w-d1t2298-3</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m063-d-id119289-punct">
   <w.rf>
    <LM>w#w-d-id119289-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2298-6">
   <w.rf>
    <LM>w#w-d1t2298-6</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m063-d1t2298-8">
   <w.rf>
    <LM>w#w-d1t2298-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m063-d1t2298-9">
   <w.rf>
    <LM>w#w-d1t2298-9</LM>
   </w.rf>
   <form>fotil</form>
   <lemma>fotit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m063-d1e2282-x2-198">
   <w.rf>
    <LM>w#w-d1e2282-x2-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-197">
  <m id="m063-d1t2309-2">
   <w.rf>
    <LM>w#w-d1t2309-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m063-d1t2309-3">
   <w.rf>
    <LM>w#w-d1t2309-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2309-4">
   <w.rf>
    <LM>w#w-d1t2309-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2309-5">
   <w.rf>
    <LM>w#w-d1t2309-5</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d-id119574-punct">
   <w.rf>
    <LM>w#w-d-id119574-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2309-7">
   <w.rf>
    <LM>w#w-d1t2309-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m063-d1t2309-8">
   <w.rf>
    <LM>w#w-d1t2309-8</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2309-9">
   <w.rf>
    <LM>w#w-d1t2309-9</LM>
   </w.rf>
   <form>huňáče</form>
   <lemma>huňáč-2</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m063-d1t2309-10">
   <w.rf>
    <LM>w#w-d1t2309-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2309-11">
   <w.rf>
    <LM>w#w-d1t2309-11</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d-id119685-punct">
   <w.rf>
    <LM>w#w-d-id119685-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m063-d1t2313-1">
   <w.rf>
    <LM>w#w-d1t2313-1</LM>
   </w.rf>
   <form>kabáty</form>
   <lemma>kabát</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2282-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2282-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2316-x2">
  <m id="m063-d1t2319-1">
   <w.rf>
    <LM>w#w-d1t2319-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2319-2">
   <w.rf>
    <LM>w#w-d1t2319-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2319-3">
   <w.rf>
    <LM>w#w-d1t2319-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m063-d1t2319-5">
   <w.rf>
    <LM>w#w-d1t2319-5</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m063-d1t2319-6">
   <w.rf>
    <LM>w#w-d1t2319-6</LM>
   </w.rf>
   <form>vaší</form>
   <lemma>váš</lemma>
   <tag>PSFS2-P2-------</tag>
  </m>
  <m id="m063-d1t2319-7">
   <w.rf>
    <LM>w#w-d1t2319-7</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m063-d-id119943-punct">
   <w.rf>
    <LM>w#w-d-id119943-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2320-x2">
  <m id="m063-d1t2323-1">
   <w.rf>
    <LM>w#w-d1t2323-1</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m063-d1t2323-2">
   <w.rf>
    <LM>w#w-d1t2323-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2323-4">
   <w.rf>
    <LM>w#w-d1t2323-4</LM>
   </w.rf>
   <form>Honzík</form>
   <lemma>Honzík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m063-d1e2320-x2-204">
   <w.rf>
    <LM>w#w-d1e2320-x2-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-205">
  <m id="m063-d1t2331-6">
   <w.rf>
    <LM>w#w-d1t2331-6</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2331-7">
   <w.rf>
    <LM>w#w-d1t2331-7</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m063-d1t2334-1">
   <w.rf>
    <LM>w#w-d1t2334-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2334-2">
   <w.rf>
    <LM>w#w-d1t2334-2</LM>
   </w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-205-207">
   <w.rf>
    <LM>w#w-205-207</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m063-205-206">
   <w.rf>
    <LM>w#w-205-206</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2341-x2">
  <m id="m063-d1t2344-2">
   <w.rf>
    <LM>w#w-d1t2344-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m063-d1t2344-4">
   <w.rf>
    <LM>w#w-d1t2344-4</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2344-3">
   <w.rf>
    <LM>w#w-d1t2344-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d-id120461-punct">
   <w.rf>
    <LM>w#w-d-id120461-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2346-x2">
  <m id="m063-d1t2353-1">
   <w.rf>
    <LM>w#w-d1t2353-1</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2353-2">
   <w.rf>
    <LM>w#w-d1t2353-2</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2353-6">
   <w.rf>
    <LM>w#w-d1t2353-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2353-7">
   <w.rf>
    <LM>w#w-d1t2353-7</LM>
   </w.rf>
   <form>úřadě</form>
   <lemma>úřad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m063-d-id120643-punct">
   <w.rf>
    <LM>w#w-d-id120643-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2353-9">
   <w.rf>
    <LM>w#w-d1t2353-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m063-d1t2353-11">
   <w.rf>
    <LM>w#w-d1t2353-11</LM>
   </w.rf>
   <form>pořádně</form>
   <lemma>pořádně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2353-12">
   <w.rf>
    <LM>w#w-d1t2353-12</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m063-d1t2353-10">
   <w.rf>
    <LM>w#w-d1t2353-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m063-d-m-d1e2346-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2346-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2358-x2">
  <m id="m063-d1t2361-8">
   <w.rf>
    <LM>w#w-d1t2361-8</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m063-d1t2361-5">
   <w.rf>
    <LM>w#w-d1t2361-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m063-d1t2361-6">
   <w.rf>
    <LM>w#w-d1t2361-6</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2361-7">
   <w.rf>
    <LM>w#w-d1t2361-7</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m063-d1e2358-x2-338">
   <w.rf>
    <LM>w#w-d1e2358-x2-338</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2361-4">
   <w.rf>
    <LM>w#w-d1t2361-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d-id120917-punct">
   <w.rf>
    <LM>w#w-d-id120917-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2362-x2">
  <m id="m063-d1e2362-x2-775">
   <w.rf>
    <LM>w#w-d1e2362-x2-775</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1e2362-x2-776">
   <w.rf>
    <LM>w#w-d1e2362-x2-776</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m063-d1e2362-x2-777">
   <w.rf>
    <LM>w#w-d1e2362-x2-777</LM>
   </w.rf>
   <form>mrňata</form>
   <lemma>mrně</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m063-d1e2362-x2-778">
   <w.rf>
    <LM>w#w-d1e2362-x2-778</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1e2362-x2-779">
   <w.rf>
    <LM>w#w-d1e2362-x2-779</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1e2362-x2-780">
   <w.rf>
    <LM>w#w-d1e2362-x2-780</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m063-d1e2362-x2-781">
   <w.rf>
    <LM>w#w-d1e2362-x2-781</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-782">
  <m id="m063-d1t2371-1">
   <w.rf>
    <LM>w#w-d1t2371-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2373-1">
   <w.rf>
    <LM>w#w-d1t2373-1</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m063-d1t2373-2">
   <w.rf>
    <LM>w#w-d1t2373-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m063-d1t2373-3">
   <w.rf>
    <LM>w#w-d1t2373-3</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2362-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2362-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2377-x2">
  <m id="m063-d1t2384-1">
   <w.rf>
    <LM>w#w-d1t2384-1</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m063-d1t2384-2">
   <w.rf>
    <LM>w#w-d1t2384-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m063-d1t2384-4">
   <w.rf>
    <LM>w#w-d1t2384-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m063-d1t2384-5">
   <w.rf>
    <LM>w#w-d1t2384-5</LM>
   </w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m063-d1t2384-6">
   <w.rf>
    <LM>w#w-d1t2384-6</LM>
   </w.rf>
   <form>procházky</form>
   <lemma>procházka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m063-d1t2384-7">
   <w.rf>
    <LM>w#w-d1t2384-7</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d-id121729-punct">
   <w.rf>
    <LM>w#w-d-id121729-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2385-x2">
  <m id="m063-d1t2388-4">
   <w.rf>
    <LM>w#w-d1t2388-4</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m063-d1t2388-6">
   <w.rf>
    <LM>w#w-d1t2388-6</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2388-7">
   <w.rf>
    <LM>w#w-d1t2388-7</LM>
   </w.rf>
   <form>držíme</form>
   <lemma>držet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2390-1">
   <w.rf>
    <LM>w#w-d1t2390-1</LM>
   </w.rf>
   <form>dodneška</form>
   <lemma>dodneška</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2400-2">
   <w.rf>
    <LM>w#w-d1t2400-2</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1e2385-x2-220">
   <w.rf>
    <LM>w#w-d1e2385-x2-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-221">
  <m id="m063-d1t2390-4">
   <w.rf>
    <LM>w#w-d1t2390-4</LM>
   </w.rf>
   <form>Klepu</form>
   <lemma>klepat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m063-d-m-d1e2385-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2385-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2393-x3">
  <m id="m063-d1t2404-1">
   <w.rf>
    <LM>w#w-d1t2404-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2404-2">
   <w.rf>
    <LM>w#w-d1t2404-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2404-3">
   <w.rf>
    <LM>w#w-d1t2404-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m063-d-m-d1e2393-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2393-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2405-x2">
  <m id="m063-d1t2412-4">
   <w.rf>
    <LM>w#w-d1t2412-4</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m063-d1t2412-1">
   <w.rf>
    <LM>w#w-d1t2412-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2412-2">
   <w.rf>
    <LM>w#w-d1t2412-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m063-d1t2412-3">
   <w.rf>
    <LM>w#w-d1t2412-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2412-5">
   <w.rf>
    <LM>w#w-d1t2412-5</LM>
   </w.rf>
   <form>černobílé</form>
   <lemma>černobílý_;o</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m063-d1t2412-9">
   <w.rf>
    <LM>w#w-d1t2412-9</LM>
   </w.rf>
   <form>fotky</form>
   <lemma>fotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m063-d1e2405-x2-224">
   <w.rf>
    <LM>w#w-d1e2405-x2-224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1e2405-x2-245">
   <w.rf>
    <LM>w#w-d1e2405-x2-245</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m063-d1t2416-2">
   <w.rf>
    <LM>w#w-d1t2416-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2416-1">
   <w.rf>
    <LM>w#w-d1t2416-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2416-3">
   <w.rf>
    <LM>w#w-d1t2416-3</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jedno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d-id122391-punct">
   <w.rf>
    <LM>w#w-d-id122391-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2416-6">
   <w.rf>
    <LM>w#w-d1t2416-6</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m063-d1t2416-8">
   <w.rf>
    <LM>w#w-d1t2416-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2416-7">
   <w.rf>
    <LM>w#w-d1t2416-7</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m063-d1e2405-x2-225">
   <w.rf>
    <LM>w#w-d1e2405-x2-225</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-226">
  <m id="m063-d1t2423-4">
   <w.rf>
    <LM>w#w-d1t2423-4</LM>
   </w.rf>
   <form>Černobílá</form>
   <lemma>černobílý_;o</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m063-d1t2423-9">
   <w.rf>
    <LM>w#w-d1t2423-9</LM>
   </w.rf>
   <form>barva</form>
   <lemma>barva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2423-1">
   <w.rf>
    <LM>w#w-d1t2423-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2423-2">
   <w.rf>
    <LM>w#w-d1t2423-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m063-d1t2423-5">
   <w.rf>
    <LM>w#w-d1t2423-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2423-7">
   <w.rf>
    <LM>w#w-d1t2423-7</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2423-6">
   <w.rf>
    <LM>w#w-d1t2423-6</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d-m-d1e2405-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2405-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2428-x2">
  <m id="m063-d1t2431-1">
   <w.rf>
    <LM>w#w-d1t2431-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m063-d1t2431-2">
   <w.rf>
    <LM>w#w-d1t2431-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2431-3">
   <w.rf>
    <LM>w#w-d1t2431-3</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m063-d1t2431-4">
   <w.rf>
    <LM>w#w-d1t2431-4</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2431-5">
   <w.rf>
    <LM>w#w-d1t2431-5</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m063-d-id122779-punct">
   <w.rf>
    <LM>w#w-d-id122779-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2432-x2">
  <m id="m063-d1t2439-1">
   <w.rf>
    <LM>w#w-d1t2439-1</LM>
   </w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m063-d1e2432-x2-232">
   <w.rf>
    <LM>w#w-d1e2432-x2-232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2441-1">
   <w.rf>
    <LM>w#w-d1t2441-1</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m063-d1t2448-5">
   <w.rf>
    <LM>w#w-d1t2448-5</LM>
   </w.rf>
   <form>Honzíka</form>
   <lemma>Honzík_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m063-d1t2441-2">
   <w.rf>
    <LM>w#w-d1t2441-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m063-d1t2441-3">
   <w.rf>
    <LM>w#w-d1t2441-3</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m063-d1t2446-2">
   <w.rf>
    <LM>w#w-d1t2446-2</LM>
   </w.rf>
   <form>Janičku</form>
   <lemma>Janička_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m063-d1e2432-x2-236">
   <w.rf>
    <LM>w#w-d1e2432-x2-236</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2453-x2">
  <m id="m063-d1t2456-2">
   <w.rf>
    <LM>w#w-d1t2456-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m063-d1t2456-3">
   <w.rf>
    <LM>w#w-d1t2456-3</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m063-d1t2456-4">
   <w.rf>
    <LM>w#w-d1t2456-4</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m063-d-id123208-punct">
   <w.rf>
    <LM>w#w-d-id123208-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2457-x2">
  <m id="m063-d1t2460-4">
   <w.rf>
    <LM>w#w-d1t2460-4</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2460-5">
   <w.rf>
    <LM>w#w-d1t2460-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2460-6">
   <w.rf>
    <LM>w#w-d1t2460-6</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1e2457-x2-239">
   <w.rf>
    <LM>w#w-d1e2457-x2-239</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2462-1">
   <w.rf>
    <LM>w#w-d1t2462-1</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m063-d1t2462-3">
   <w.rf>
    <LM>w#w-d1t2462-3</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m063-d1t2464-1">
   <w.rf>
    <LM>w#w-d1t2464-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m063-d1t2464-2">
   <w.rf>
    <LM>w#w-d1t2464-2</LM>
   </w.rf>
   <form>jedenácti</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m063-d1t2464-3">
   <w.rf>
    <LM>w#w-d1t2464-3</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m063-d1e2457-x2-240">
   <w.rf>
    <LM>w#w-d1e2457-x2-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-241">
  <m id="m063-d1t2466-2">
   <w.rf>
    <LM>w#w-d1t2466-2</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2468-1">
   <w.rf>
    <LM>w#w-d1t2468-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2468-2">
   <w.rf>
    <LM>w#w-d1t2468-2</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m063-d1t2468-3">
   <w.rf>
    <LM>w#w-d1t2468-3</LM>
   </w.rf>
   <form>věk</form>
   <lemma>věk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m063-241-242">
   <w.rf>
    <LM>w#w-241-242</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2473-1">
   <w.rf>
    <LM>w#w-d1t2473-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2473-2">
   <w.rf>
    <LM>w#w-d1t2473-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m063-d1t2473-3">
   <w.rf>
    <LM>w#w-d1t2473-3</LM>
   </w.rf>
   <form>88</form>
   <lemma>88</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-d1t2473-4">
   <w.rf>
    <LM>w#w-d1t2473-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m063-241-244">
   <w.rf>
    <LM>w#w-241-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-245">
  <m id="m063-d1t2477-2">
   <w.rf>
    <LM>w#w-d1t2477-2</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2477-4">
   <w.rf>
    <LM>w#w-d1t2477-4</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2477-3">
   <w.rf>
    <LM>w#w-d1t2477-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2477-5">
   <w.rf>
    <LM>w#w-d1t2477-5</LM>
   </w.rf>
   <form>pohyblivá</form>
   <lemma>pohyblivý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m063-245-249">
   <w.rf>
    <LM>w#w-245-249</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2484-1">
   <w.rf>
    <LM>w#w-d1t2484-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m063-d1t2484-3">
   <w.rf>
    <LM>w#w-d1t2484-3</LM>
   </w.rf>
   <form>zvládá</form>
   <lemma>zvládat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2484-2">
   <w.rf>
    <LM>w#w-d1t2484-2</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m063-245-250">
   <w.rf>
    <LM>w#w-245-250</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-252">
  <m id="m063-d1t2488-1">
   <w.rf>
    <LM>w#w-d1t2488-1</LM>
   </w.rf>
   <form>Pracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2486-1">
   <w.rf>
    <LM>w#w-d1t2486-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2486-2">
   <w.rf>
    <LM>w#w-d1t2486-2</LM>
   </w.rf>
   <form>chatě</form>
   <lemma>chata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d-id123894-punct">
   <w.rf>
    <LM>w#w-d-id123894-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2488-3">
   <w.rf>
    <LM>w#w-d1t2488-3</LM>
   </w.rf>
   <form>okopává</form>
   <lemma>okopávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-252-254">
   <w.rf>
    <LM>w#w-252-254</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2492-1">
   <w.rf>
    <LM>w#w-d1t2492-1</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2492-2">
   <w.rf>
    <LM>w#w-d1t2492-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m063-d1t2492-5">
   <w.rf>
    <LM>w#w-d1t2492-5</LM>
   </w.rf>
   <form>obstará</form>
   <lemma>obstarat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m063-d1t2490-1">
   <w.rf>
    <LM>w#w-d1t2490-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m063-d1t2490-2">
   <w.rf>
    <LM>w#w-d1t2490-2</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m063-252-258">
   <w.rf>
    <LM>w#w-252-258</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-259">
  <m id="m063-d1t2492-6">
   <w.rf>
    <LM>w#w-d1t2492-6</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2494-1">
   <w.rf>
    <LM>w#w-d1t2494-1</LM>
   </w.rf>
   <form>pomáhá</form>
   <lemma>pomáhat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2492-7">
   <w.rf>
    <LM>w#w-d1t2492-7</LM>
   </w.rf>
   <form>sestře</form>
   <lemma>sestra</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m063-d1t2494-2">
   <w.rf>
    <LM>w#w-d1t2494-2</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2494-3">
   <w.rf>
    <LM>w#w-d1t2494-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m063-d1t2494-4">
   <w.rf>
    <LM>w#w-d1t2494-4</LM>
   </w.rf>
   <form>nákupem</form>
   <lemma>nákup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m063-259-248">
   <w.rf>
    <LM>w#w-259-248</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2494-7">
   <w.rf>
    <LM>w#w-d1t2494-7</LM>
   </w.rf>
   <form>běžně</form>
   <lemma>běžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2494-6">
   <w.rf>
    <LM>w#w-d1t2494-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m063-d1t2494-10">
   <w.rf>
    <LM>w#w-d1t2494-10</LM>
   </w.rf>
   <form>donese</form>
   <lemma>donést</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m063-259-246">
   <w.rf>
    <LM>w#w-259-246</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-247">
  <m id="m063-d1t2497-1">
   <w.rf>
    <LM>w#w-d1t2497-1</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2497-2">
   <w.rf>
    <LM>w#w-d1t2497-2</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m063-d1t2497-3">
   <w.rf>
    <LM>w#w-d1t2497-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2497-4">
   <w.rf>
    <LM>w#w-d1t2497-4</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m063-d-m-d1e2457-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2457-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2503-x2">
  <m id="m063-d1t2506-1">
   <w.rf>
    <LM>w#w-d1t2506-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2506-2">
   <w.rf>
    <LM>w#w-d1t2506-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2506-3">
   <w.rf>
    <LM>w#w-d1t2506-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d-m-d1e2503-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2503-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2507-x2">
  <m id="m063-d1t2510-2">
   <w.rf>
    <LM>w#w-d1t2510-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2510-1">
   <w.rf>
    <LM>w#w-d1t2510-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2518-1">
   <w.rf>
    <LM>w#w-d1t2518-1</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2518-2">
   <w.rf>
    <LM>w#w-d1t2518-2</LM>
   </w.rf>
   <form>úžasné</form>
   <lemma>úžasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m063-d1e2507-x2-261">
   <w.rf>
    <LM>w#w-d1e2507-x2-261</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-262">
  <m id="m063-d1t2516-7">
   <w.rf>
    <LM>w#w-d1t2516-7</LM>
   </w.rf>
   <form>Nedovedu</form>
   <lemma>dovést</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m063-d1t2516-5">
   <w.rf>
    <LM>w#w-d1t2516-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m063-d1t2516-8">
   <w.rf>
    <LM>w#w-d1t2516-8</LM>
   </w.rf>
   <form>představit</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m063-d1t2516-2">
   <w.rf>
    <LM>w#w-d1t2516-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2516-3">
   <w.rf>
    <LM>w#w-d1t2516-3</LM>
   </w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m063-d1t2516-4">
   <w.rf>
    <LM>w#w-d1t2516-4</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m063-d1t2516-13">
   <w.rf>
    <LM>w#w-d1t2516-13</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m063-d1t2516-10">
   <w.rf>
    <LM>w#w-d1t2516-10</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2516-12">
   <w.rf>
    <LM>w#w-d1t2516-12</LM>
   </w.rf>
   <form>zvládat</form>
   <lemma>zvládat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m063-262-263">
   <w.rf>
    <LM>w#w-262-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2528-x2">
  <m id="m063-d1t2533-1">
   <w.rf>
    <LM>w#w-d1t2533-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m063-d1t2533-2">
   <w.rf>
    <LM>w#w-d1t2533-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m063-d1t2533-3">
   <w.rf>
    <LM>w#w-d1t2533-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1e2528-x2-814">
   <w.rf>
    <LM>w#w-d1e2528-x2-814</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m063-d1t2533-5">
   <w.rf>
    <LM>w#w-d1t2533-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d1t2533-6">
   <w.rf>
    <LM>w#w-d1t2533-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2533-7">
   <w.rf>
    <LM>w#w-d1t2533-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m063-d1t2533-8">
   <w.rf>
    <LM>w#w-d1t2533-8</LM>
   </w.rf>
   <form>vyprávět</form>
   <lemma>vyprávět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m063-d-id125034-punct">
   <w.rf>
    <LM>w#w-d-id125034-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2528-x4">
  <m id="m063-d1t2537-2">
   <w.rf>
    <LM>w#w-d1t2537-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2537-3">
   <w.rf>
    <LM>w#w-d1t2537-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2537-4">
   <w.rf>
    <LM>w#w-d1t2537-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d-m-d1e2528-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2528-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2538-x2">
  <m id="m063-d1t2541-2">
   <w.rf>
    <LM>w#w-d1t2541-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2541-3">
   <w.rf>
    <LM>w#w-d1t2541-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2541-4">
   <w.rf>
    <LM>w#w-d1t2541-4</LM>
   </w.rf>
   <form>vyčerpali</form>
   <lemma>vyčerpat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m063-d1t2541-5">
   <w.rf>
    <LM>w#w-d1t2541-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d1t2541-6">
   <w.rf>
    <LM>w#w-d1t2541-6</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m063-d-m-d1e2538-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2538-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2544-x2">
  <m id="m063-d1t2547-3">
   <w.rf>
    <LM>w#w-d1t2547-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m063-d1t2547-2">
   <w.rf>
    <LM>w#w-d1t2547-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2547-4">
   <w.rf>
    <LM>w#w-d1t2547-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m063-d1t2547-5">
   <w.rf>
    <LM>w#w-d1t2547-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m063-d-m-d1e2544-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2544-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2548-x2">
  <m id="m063-d1t2551-1">
   <w.rf>
    <LM>w#w-d1t2551-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-d-m-d1e2548-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2548-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2558-x2">
  <m id="m063-d1t2561-1">
   <w.rf>
    <LM>w#w-d1t2561-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m063-d1t2561-2">
   <w.rf>
    <LM>w#w-d1t2561-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2561-3">
   <w.rf>
    <LM>w#w-d1t2561-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2561-4">
   <w.rf>
    <LM>w#w-d1t2561-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m063-d1t2561-5">
   <w.rf>
    <LM>w#w-d1t2561-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d-id125612-punct">
   <w.rf>
    <LM>w#w-d-id125612-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2562-x2">
  <m id="m063-d1t2569-2">
   <w.rf>
    <LM>w#w-d1t2569-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2569-3">
   <w.rf>
    <LM>w#w-d1t2569-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2569-4">
   <w.rf>
    <LM>w#w-d1t2569-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2569-5">
   <w.rf>
    <LM>w#w-d1t2569-5</LM>
   </w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m063-d1e2562-x2-269">
   <w.rf>
    <LM>w#w-d1e2562-x2-269</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2576-1">
   <w.rf>
    <LM>w#w-d1t2576-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2576-2">
   <w.rf>
    <LM>w#w-d1t2576-2</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m063-d1t2576-3">
   <w.rf>
    <LM>w#w-d1t2576-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2576-4">
   <w.rf>
    <LM>w#w-d1t2576-4</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2562-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2562-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2583-x2">
  <m id="m063-d1e2583-x2-826">
   <w.rf>
    <LM>w#w-d1e2583-x2-826</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m063-d1t2588-2">
   <w.rf>
    <LM>w#w-d1t2588-2</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m063-d1t2588-3">
   <w.rf>
    <LM>w#w-d1t2588-3</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1t2588-5">
   <w.rf>
    <LM>w#w-d1t2588-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2588-6">
   <w.rf>
    <LM>w#w-d1t2588-6</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1e2583-x2-280">
   <w.rf>
    <LM>w#w-d1e2583-x2-280</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2596-2">
   <w.rf>
    <LM>w#w-d1t2596-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2596-3">
   <w.rf>
    <LM>w#w-d1t2596-3</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m063-d1t2596-4">
   <w.rf>
    <LM>w#w-d1t2596-4</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m063-d1t2596-5">
   <w.rf>
    <LM>w#w-d1t2596-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2598-1">
   <w.rf>
    <LM>w#w-d1t2598-1</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m063-d1t2598-7">
   <w.rf>
    <LM>w#w-d1t2598-7</LM>
   </w.rf>
   <form>Jirkova</form>
   <lemma>Jirkův_;Y_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m063-d1t2598-9">
   <w.rf>
    <LM>w#w-d1t2598-9</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d1e2583-x2-261">
   <w.rf>
    <LM>w#w-d1e2583-x2-261</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2609-3">
   <w.rf>
    <LM>w#w-d1t2609-3</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m063-d1t2609-9">
   <w.rf>
    <LM>w#w-d1t2609-9</LM>
   </w.rf>
   <form>snacha</form>
   <lemma>snacha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2604-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2604-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2604-x3">
  <m id="m063-d1t2613-1">
   <w.rf>
    <LM>w#w-d1t2613-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2613-2">
   <w.rf>
    <LM>w#w-d1t2613-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2613-3">
   <w.rf>
    <LM>w#w-d1t2613-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2613-4">
   <w.rf>
    <LM>w#w-d1t2613-4</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d-id126694-punct">
   <w.rf>
    <LM>w#w-d-id126694-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2614-x2">
  <m id="m063-d1t2617-2">
   <w.rf>
    <LM>w#w-d1t2617-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2617-3">
   <w.rf>
    <LM>w#w-d1t2617-3</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2617-4">
   <w.rf>
    <LM>w#w-d1t2617-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2617-5">
   <w.rf>
    <LM>w#w-d1t2617-5</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m063-d1t2617-6">
   <w.rf>
    <LM>w#w-d1t2617-6</LM>
   </w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-d1e2614-x2-296">
   <w.rf>
    <LM>w#w-d1e2614-x2-296</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-301">
  <m id="m063-301-837">
   <w.rf>
    <LM>w#w-301-837</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-301-838">
   <w.rf>
    <LM>w#w-301-838</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-301-839">
   <w.rf>
    <LM>w#w-301-839</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-301-840">
   <w.rf>
    <LM>w#w-301-840</LM>
   </w.rf>
   <form>pamatuje</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-301-841">
   <w.rf>
    <LM>w#w-301-841</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-842">
  <m id="m063-d1t2623-1">
   <w.rf>
    <LM>w#w-d1t2623-1</LM>
   </w.rf>
   <form>Brali</form>
   <lemma>brát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m063-d1t2621-6">
   <w.rf>
    <LM>w#w-d1t2621-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2619-5">
   <w.rf>
    <LM>w#w-d1t2619-5</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-297-302">
   <w.rf>
    <LM>w#w-297-302</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2619-6">
   <w.rf>
    <LM>w#w-d1t2619-6</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-301-303">
   <w.rf>
    <LM>w#w-301-303</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2619-7">
   <w.rf>
    <LM>w#w-d1t2619-7</LM>
   </w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m063-301-306">
   <w.rf>
    <LM>w#w-301-306</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-307">
  <m id="m063-d1t2628-9">
   <w.rf>
    <LM>w#w-d1t2628-9</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2628-7">
   <w.rf>
    <LM>w#w-d1t2628-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m063-307-308">
   <w.rf>
    <LM>w#w-307-308</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m063-d1t2632-1">
   <w.rf>
    <LM>w#w-d1t2632-1</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2632-2">
   <w.rf>
    <LM>w#w-d1t2632-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m063-d1t2632-3">
   <w.rf>
    <LM>w#w-d1t2632-3</LM>
   </w.rf>
   <form>data</form>
   <lemma>datum-1_^(kalendářní)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2614-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2614-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2641-x2">
  <m id="m063-d1t2646-2">
   <w.rf>
    <LM>w#w-d1t2646-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2646-3">
   <w.rf>
    <LM>w#w-d1t2646-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2646-5">
   <w.rf>
    <LM>w#w-d1t2646-5</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2646-7">
   <w.rf>
    <LM>w#w-d1t2646-7</LM>
   </w.rf>
   <form>oslavě</form>
   <lemma>oslava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d1e2641-x2-6">
   <w.rf>
    <LM>w#w-d1e2641-x2-6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-7">
  <m id="m063-d1t2648-3">
   <w.rf>
    <LM>w#w-d1t2648-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2657-2">
   <w.rf>
    <LM>w#w-d1t2657-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m063-d-id128037-punct">
   <w.rf>
    <LM>w#w-d-id128037-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2657-4">
   <w.rf>
    <LM>w#w-d1t2657-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m063-d1t2657-5">
   <w.rf>
    <LM>w#w-d1t2657-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2657-6">
   <w.rf>
    <LM>w#w-d1t2657-6</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2657-7">
   <w.rf>
    <LM>w#w-d1t2657-7</LM>
   </w.rf>
   <form>slavilo</form>
   <lemma>slavit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m063-7-848">
   <w.rf>
    <LM>w#w-7-848</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-849">
  <m id="m063-d1t2655-2">
   <w.rf>
    <LM>w#w-d1t2655-2</LM>
   </w.rf>
   <form>Nejspíš</form>
   <lemma>nejspíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m063-7-9">
   <w.rf>
    <LM>w#w-7-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-7-10">
   <w.rf>
    <LM>w#w-7-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2655-9">
   <w.rf>
    <LM>w#w-d1t2655-9</LM>
   </w.rf>
   <form>oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-7-11">
   <w.rf>
    <LM>w#w-7-11</LM>
   </w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PK--2----------</tag>
  </m>
  <m id="m063-d1t2655-5">
   <w.rf>
    <LM>w#w-d1t2655-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2655-6">
   <w.rf>
    <LM>w#w-d1t2655-6</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m063-d1t2655-7">
   <w.rf>
    <LM>w#w-d1t2655-7</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m063-d-id127947-punct">
   <w.rf>
    <LM>w#w-d-id127947-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2655-11">
   <w.rf>
    <LM>w#w-d1t2655-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m063-d1t2655-12">
   <w.rf>
    <LM>w#w-d1t2655-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2655-13">
   <w.rf>
    <LM>w#w-d1t2655-13</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2655-14">
   <w.rf>
    <LM>w#w-d1t2655-14</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m063-d-m-d1e2641-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2641-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2660-x3">
  <m id="m063-d1t2669-1">
   <w.rf>
    <LM>w#w-d1t2669-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m063-d1t2669-2">
   <w.rf>
    <LM>w#w-d1t2669-2</LM>
   </w.rf>
   <form>nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m063-d-m-d1e2660-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2660-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2670-x2">
  <m id="m063-d1t2675-1">
   <w.rf>
    <LM>w#w-d1t2675-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m063-d1t2675-2">
   <w.rf>
    <LM>w#w-d1t2675-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m063-d1t2679-2">
   <w.rf>
    <LM>w#w-d1t2679-2</LM>
   </w.rf>
   <form>slavíme</form>
   <lemma>slavit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m063-d1t2681-1">
   <w.rf>
    <LM>w#w-d1t2681-1</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1t2681-2">
   <w.rf>
    <LM>w#w-d1t2681-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d1e2670-x2-14">
   <w.rf>
    <LM>w#w-d1e2670-x2-14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2675-10">
   <w.rf>
    <LM>w#w-d1t2675-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m063-d1t2675-11">
   <w.rf>
    <LM>w#w-d1t2675-11</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m063-d1t2675-13">
   <w.rf>
    <LM>w#w-d1t2675-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m063-d1t2675-14">
   <w.rf>
    <LM>w#w-d1t2675-14</LM>
   </w.rf>
   <form>rodině</form>
   <lemma>rodina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m063-d1t2675-12">
   <w.rf>
    <LM>w#w-d1t2675-12</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m063-d-m-d1e2670-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2670-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2687-x2">
  <m id="m063-d1t2690-1">
   <w.rf>
    <LM>w#w-d1t2690-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2690-2">
   <w.rf>
    <LM>w#w-d1t2690-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2690-4">
   <w.rf>
    <LM>w#w-d1t2690-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m063-d1t2690-5">
   <w.rf>
    <LM>w#w-d1t2690-5</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m063-d1t2690-6">
   <w.rf>
    <LM>w#w-d1t2690-6</LM>
   </w.rf>
   <form>snacha</form>
   <lemma>snacha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d-id128821-punct">
   <w.rf>
    <LM>w#w-d-id128821-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2691-x2">
  <m id="m063-d1t2698-5">
   <w.rf>
    <LM>w#w-d1t2698-5</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m063-d1t2698-4">
   <w.rf>
    <LM>w#w-d1t2698-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2698-2">
   <w.rf>
    <LM>w#w-d1t2698-2</LM>
   </w.rf>
   <form>Šárka</form>
   <lemma>Šárka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m063-d-m-d1e2691-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2691-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m063-d1e2703-x2">
  <m id="m063-d1t2706-1">
   <w.rf>
    <LM>w#w-d1t2706-1</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m063-d-id129093-punct">
   <w.rf>
    <LM>w#w-d-id129093-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m063-d1t2706-3">
   <w.rf>
    <LM>w#w-d1t2706-3</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m063-d1t2706-4">
   <w.rf>
    <LM>w#w-d1t2706-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m063-d1t2706-5">
   <w.rf>
    <LM>w#w-d1t2706-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m063-d1t2706-6">
   <w.rf>
    <LM>w#w-d1t2706-6</LM>
   </w.rf>
   <form>vaším</form>
   <lemma>váš</lemma>
   <tag>PSZS7-P2-------</tag>
  </m>
  <m id="m063-d1t2706-7">
   <w.rf>
    <LM>w#w-d1t2706-7</LM>
   </w.rf>
   <form>synem</form>
   <lemma>syn</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m063-d1t2706-8">
   <w.rf>
    <LM>w#w-d1t2706-8</LM>
   </w.rf>
   <form>poznali</form>
   <lemma>poznat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m063-d-id129188-punct">
   <w.rf>
    <LM>w#w-d-id129188-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
