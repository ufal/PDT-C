<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ep_121.09.w.gz" />
  </references>
 </head>
 <s id="m121-d1e1862-x2">
  <m id="m121-d1t1865-1">
   <w.rf>
    <LM>w#w-d1t1865-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m121-d1t1865-2">
   <w.rf>
    <LM>w#w-d1t1865-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m121-d-m-d1e1862-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1862-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1866-x2">
  <m id="m121-d1t1871-1">
   <w.rf>
    <LM>w#w-d1t1871-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t1871-2">
   <w.rf>
    <LM>w#w-d1t1871-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1871-3">
   <w.rf>
    <LM>w#w-d1t1871-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1871-4">
   <w.rf>
    <LM>w#w-d1t1871-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m121-d1t1871-5">
   <w.rf>
    <LM>w#w-d1t1871-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d-id162443-punct">
   <w.rf>
    <LM>w#w-d-id162443-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1866-x4">
  <m id="m121-d1t1875-4">
   <w.rf>
    <LM>w#w-d1t1875-4</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1875-5">
   <w.rf>
    <LM>w#w-d1t1875-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1875-8">
   <w.rf>
    <LM>w#w-d1t1875-8</LM>
   </w.rf>
   <form>Studená</form>
   <lemma>Studená_;G_;Y_^(*1ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id162589-punct">
   <w.rf>
    <LM>w#w-d-id162589-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1875-12">
   <w.rf>
    <LM>w#w-d1t1875-12</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1875-13">
   <w.rf>
    <LM>w#w-d1t1875-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1875-14">
   <w.rf>
    <LM>w#w-d1t1875-14</LM>
   </w.rf>
   <form>sjíždíme</form>
   <lemma>sjíždět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d-m-d1e1866-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1866-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1876-x2">
  <m id="m121-d1t1881-2">
   <w.rf>
    <LM>w#w-d1t1881-2</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1881-3">
   <w.rf>
    <LM>w#w-d1t1881-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1881-11">
   <w.rf>
    <LM>w#w-d1t1881-11</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m121-d1t1881-12">
   <w.rf>
    <LM>w#w-d1t1881-12</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m121-d1t1881-13">
   <w.rf>
    <LM>w#w-d1t1881-13</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id162798-punct">
   <w.rf>
    <LM>w#w-d-id162798-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1881-7">
   <w.rf>
    <LM>w#w-d1t1881-7</LM>
   </w.rf>
   <form>slaví</form>
   <lemma>slavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1881-8">
   <w.rf>
    <LM>w#w-d1t1881-8</LM>
   </w.rf>
   <form>osmdesátiny</form>
   <lemma>osmdesátiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d1e1876-x2-378">
   <w.rf>
    <LM>w#w-d1e1876-x2-378</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1885-1">
   <w.rf>
    <LM>w#w-d1t1885-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1885-2">
   <w.rf>
    <LM>w#w-d1t1885-2</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1885-3">
   <w.rf>
    <LM>w#w-d1t1885-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1885-4">
   <w.rf>
    <LM>w#w-d1t1885-4</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1e1876-x2-239">
   <w.rf>
    <LM>w#w-d1e1876-x2-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-240">
  <m id="m121-d1t1885-7">
   <w.rf>
    <LM>w#w-d1t1885-7</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1885-6">
   <w.rf>
    <LM>w#w-d1t1885-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1885-9">
   <w.rf>
    <LM>w#w-d1t1885-9</LM>
   </w.rf>
   <form>šťastné</form>
   <lemma>šťastný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m121-d1t1885-10">
   <w.rf>
    <LM>w#w-d1t1885-10</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m121-d-id163104-punct">
   <w.rf>
    <LM>w#w-d-id163104-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1885-12">
   <w.rf>
    <LM>w#w-d1t1885-12</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1885-13">
   <w.rf>
    <LM>w#w-d1t1885-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1885-14">
   <w.rf>
    <LM>w#w-d1t1885-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1885-18">
   <w.rf>
    <LM>w#w-d1t1885-18</LM>
   </w.rf>
   <form>sjeli</form>
   <lemma>sjet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m121-d1t1885-19">
   <w.rf>
    <LM>w#w-d1t1885-19</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t1885-20">
   <w.rf>
    <LM>w#w-d1t1885-20</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1885-21">
   <w.rf>
    <LM>w#w-d1t1885-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1885-22">
   <w.rf>
    <LM>w#w-d1t1885-22</LM>
   </w.rf>
   <form>oslavili</form>
   <lemma>oslavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m121-d1t1885-23">
   <w.rf>
    <LM>w#w-d1t1885-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1885-25">
   <w.rf>
    <LM>w#w-d1t1885-25</LM>
   </w.rf>
   <form>osmdesátiny</form>
   <lemma>osmdesátiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d1e1876-x2-249">
   <w.rf>
    <LM>w#w-d1e1876-x2-249</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-250">
  <m id="m121-d1t1887-1">
   <w.rf>
    <LM>w#w-d1t1887-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1887-2">
   <w.rf>
    <LM>w#w-d1t1887-2</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1887-4">
   <w.rf>
    <LM>w#w-d1t1887-4</LM>
   </w.rf>
   <form>vloni</form>
   <lemma>vloni_,s_^(^DD**loni)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1887-3">
   <w.rf>
    <LM>w#w-d1t1887-3</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-250-383">
   <w.rf>
    <LM>w#w-250-383</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1887-9">
   <w.rf>
    <LM>w#w-d1t1887-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1887-10">
   <w.rf>
    <LM>w#w-d1t1887-10</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m121-d1t1887-11">
   <w.rf>
    <LM>w#w-d1t1887-11</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-id163540-punct">
   <w.rf>
    <LM>w#w-d-id163540-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1887-14">
   <w.rf>
    <LM>w#w-d1t1887-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1887-15">
   <w.rf>
    <LM>w#w-d1t1887-15</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m121-d1t1887-16">
   <w.rf>
    <LM>w#w-d1t1887-16</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1887-17">
   <w.rf>
    <LM>w#w-d1t1887-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1887-19">
   <w.rf>
    <LM>w#w-d1t1887-19</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1887-18">
   <w.rf>
    <LM>w#w-d1t1887-18</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d1t1887-21">
   <w.rf>
    <LM>w#w-d1t1887-21</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1887-25">
   <w.rf>
    <LM>w#w-d1t1887-25</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1887-26">
   <w.rf>
    <LM>w#w-d1t1887-26</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-m-d1e1876-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1876-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1888-x2">
  <m id="m121-d1t1891-1">
   <w.rf>
    <LM>w#w-d1t1891-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1891-2">
   <w.rf>
    <LM>w#w-d1t1891-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1891-3">
   <w.rf>
    <LM>w#w-d1t1891-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m121-d1t1891-4">
   <w.rf>
    <LM>w#w-d1t1891-4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m121-d1t1891-5">
   <w.rf>
    <LM>w#w-d1t1891-5</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1891-6">
   <w.rf>
    <LM>w#w-d1t1891-6</LM>
   </w.rf>
   <form>osobností</form>
   <lemma>osobnost</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-d-id163896-punct">
   <w.rf>
    <LM>w#w-d-id163896-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1892-x2">
  <m id="m121-d1t1895-1">
   <w.rf>
    <LM>w#w-d1t1895-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1895-2">
   <w.rf>
    <LM>w#w-d1t1895-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1895-3">
   <w.rf>
    <LM>w#w-d1t1895-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1895-4">
   <w.rf>
    <LM>w#w-d1t1895-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m121-d1t1895-5">
   <w.rf>
    <LM>w#w-d1t1895-5</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m121-d1t1895-6">
   <w.rf>
    <LM>w#w-d1t1895-6</LM>
   </w.rf>
   <form>osobností</form>
   <lemma>osobnost</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-d-id164051-punct">
   <w.rf>
    <LM>w#w-d-id164051-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1895-8">
   <w.rf>
    <LM>w#w-d1t1895-8</LM>
   </w.rf>
   <form>vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1895-10">
   <w.rf>
    <LM>w#w-d1t1895-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1895-9">
   <w.rf>
    <LM>w#w-d1t1895-9</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1897-1">
   <w.rf>
    <LM>w#w-d1t1897-1</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1897-2">
   <w.rf>
    <LM>w#w-d1t1897-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1897-3">
   <w.rf>
    <LM>w#w-d1t1897-3</LM>
   </w.rf>
   <form>jejích</form>
   <lemma>jeho</lemma>
   <tag>P9XP6FS3-------</tag>
  </m>
  <m id="m121-d1t1897-4">
   <w.rf>
    <LM>w#w-d1t1897-4</LM>
   </w.rf>
   <form>šlépějích</form>
   <lemma>šlépěj</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m121-d1t1897-5">
   <w.rf>
    <LM>w#w-d1t1897-5</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m121-d1t1897-6">
   <w.rf>
    <LM>w#w-d1t1897-6</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1e1892-x2-259">
   <w.rf>
    <LM>w#w-d1e1892-x2-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-260">
  <m id="m121-d1t1897-10">
   <w.rf>
    <LM>w#w-d1t1897-10</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1897-11">
   <w.rf>
    <LM>w#w-d1t1897-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1897-12">
   <w.rf>
    <LM>w#w-d1t1897-12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m121-d1t1897-13">
   <w.rf>
    <LM>w#w-d1t1897-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1897-14">
   <w.rf>
    <LM>w#w-d1t1897-14</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1897-15">
   <w.rf>
    <LM>w#w-d1t1897-15</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1897-16">
   <w.rf>
    <LM>w#w-d1t1897-16</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1899-1">
   <w.rf>
    <LM>w#w-d1t1899-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1899-2">
   <w.rf>
    <LM>w#w-d1t1899-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1899-3">
   <w.rf>
    <LM>w#w-d1t1899-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1899-5">
   <w.rf>
    <LM>w#w-d1t1899-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1899-6">
   <w.rf>
    <LM>w#w-d1t1899-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m121-d1t1899-7">
   <w.rf>
    <LM>w#w-d1t1899-7</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m121-d1t1899-4">
   <w.rf>
    <LM>w#w-d1t1899-4</LM>
   </w.rf>
   <form>nahlédla</form>
   <lemma>nahlédnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m121-260-261">
   <w.rf>
    <LM>w#w-260-261</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-262">
  <m id="m121-d1t1899-9">
   <w.rf>
    <LM>w#w-d1t1899-9</LM>
   </w.rf>
   <form>Mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1899-10">
   <w.rf>
    <LM>w#w-d1t1899-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-262-68">
   <w.rf>
    <LM>w#w-262-68</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m121-d1t1899-12">
   <w.rf>
    <LM>w#w-d1t1899-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1899-14">
   <w.rf>
    <LM>w#w-d1t1899-14</LM>
   </w.rf>
   <form>Jindřichově</form>
   <lemma>Jindřichův_;Y_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m121-d1t1899-15">
   <w.rf>
    <LM>w#w-d1t1899-15</LM>
   </w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m121-d1t1899-11">
   <w.rf>
    <LM>w#w-d1t1899-11</LM>
   </w.rf>
   <form>chodívali</form>
   <lemma>chodívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1899-17">
   <w.rf>
    <LM>w#w-d1t1899-17</LM>
   </w.rf>
   <form>navštěvovat</form>
   <lemma>navštěvovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1899-18">
   <w.rf>
    <LM>w#w-d1t1899-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1899-19">
   <w.rf>
    <LM>w#w-d1t1899-19</LM>
   </w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d-id164742-punct">
   <w.rf>
    <LM>w#w-d-id164742-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1899-28">
   <w.rf>
    <LM>w#w-d1t1899-28</LM>
   </w.rf>
   <form>ač</form>
   <lemma>ač-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-262-69">
   <w.rf>
    <LM>w#w-262-69</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1899-30">
   <w.rf>
    <LM>w#w-d1t1899-30</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-262-70">
   <w.rf>
    <LM>w#w-262-70</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1899-29">
   <w.rf>
    <LM>w#w-d1t1899-29</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-262-71">
   <w.rf>
    <LM>w#w-262-71</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1899-31">
   <w.rf>
    <LM>w#w-d1t1899-31</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1899-32">
   <w.rf>
    <LM>w#w-d1t1899-32</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1899-33">
   <w.rf>
    <LM>w#w-d1t1899-33</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m121-262-124">
   <w.rf>
    <LM>w#w-262-124</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1899-26">
   <w.rf>
    <LM>w#w-d1t1899-26</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1899-34">
   <w.rf>
    <LM>w#w-d1t1899-34</LM>
   </w.rf>
   <form>zdálo</form>
   <lemma>zdát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1899-35">
   <w.rf>
    <LM>w#w-d1t1899-35</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1899-37">
   <w.rf>
    <LM>w#w-d1t1899-37</LM>
   </w.rf>
   <form>vrchol</form>
   <lemma>vrchol</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1899-38">
   <w.rf>
    <LM>w#w-d1t1899-38</LM>
   </w.rf>
   <form>možnosti</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t1899-39">
   <w.rf>
    <LM>w#w-d1t1899-39</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1899-40">
   <w.rf>
    <LM>w#w-d1t1899-40</LM>
   </w.rf>
   <form>lidem</form>
   <lemma>lidé</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m121-262-398">
   <w.rf>
    <LM>w#w-262-398</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-399">
  <m id="m121-d1t1903-2">
   <w.rf>
    <LM>w#w-d1t1903-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1903-4">
   <w.rf>
    <LM>w#w-d1t1903-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1903-3">
   <w.rf>
    <LM>w#w-d1t1903-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1903-5">
   <w.rf>
    <LM>w#w-d1t1903-5</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m121-d1t1903-6">
   <w.rf>
    <LM>w#w-d1t1903-6</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-399-401">
   <w.rf>
    <LM>w#w-399-401</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1903-7">
   <w.rf>
    <LM>w#w-d1t1903-7</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1903-8">
   <w.rf>
    <LM>w#w-d1t1903-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1903-10">
   <w.rf>
    <LM>w#w-d1t1903-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1903-12">
   <w.rf>
    <LM>w#w-d1t1903-12</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1903-13">
   <w.rf>
    <LM>w#w-d1t1903-13</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1903-14">
   <w.rf>
    <LM>w#w-d1t1903-14</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-262-136">
   <w.rf>
    <LM>w#w-262-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1892-x3">
  <m id="m121-d1t1903-17">
   <w.rf>
    <LM>w#w-d1t1903-17</LM>
   </w.rf>
   <form>Poslání</form>
   <lemma>poslání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1903-18">
   <w.rf>
    <LM>w#w-d1t1903-18</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1903-22">
   <w.rf>
    <LM>w#w-d1t1903-22</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t1903-23">
   <w.rf>
    <LM>w#w-d1t1903-23</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m121-d1t1903-24">
   <w.rf>
    <LM>w#w-d1t1903-24</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t1903-25">
   <w.rf>
    <LM>w#w-d1t1903-25</LM>
   </w.rf>
   <form>vedlo</form>
   <lemma>vést</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1903-26">
   <w.rf>
    <LM>w#w-d1t1903-26</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m121-d1t1906-1">
   <w.rf>
    <LM>w#w-d1t1906-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1906-3">
   <w.rf>
    <LM>w#w-d1t1906-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1906-4">
   <w.rf>
    <LM>w#w-d1t1906-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1906-5">
   <w.rf>
    <LM>w#w-d1t1906-5</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m121-d1t1906-7">
   <w.rf>
    <LM>w#w-d1t1906-7</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id165484-punct">
   <w.rf>
    <LM>w#w-d-id165484-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1906-9">
   <w.rf>
    <LM>w#w-d1t1906-9</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m121-d1t1906-10">
   <w.rf>
    <LM>w#w-d1t1906-10</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t1906-11">
   <w.rf>
    <LM>w#w-d1t1906-11</LM>
   </w.rf>
   <form>ovlivnila</form>
   <lemma>ovlivnit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1e1892-x3-407">
   <w.rf>
    <LM>w#w-d1e1892-x3-407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-408">
  <m id="m121-d1t1908-2">
   <w.rf>
    <LM>w#w-d1t1908-2</LM>
   </w.rf>
   <form>Nejen</form>
   <lemma>nejen</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1908-4">
   <w.rf>
    <LM>w#w-d1t1908-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1908-5">
   <w.rf>
    <LM>w#w-d1t1908-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1908-6">
   <w.rf>
    <LM>w#w-d1t1908-6</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d-id165648-punct">
   <w.rf>
    <LM>w#w-d-id165648-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1908-8">
   <w.rf>
    <LM>w#w-d1t1908-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1908-11">
   <w.rf>
    <LM>w#w-d1t1908-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1908-10">
   <w.rf>
    <LM>w#w-d1t1908-10</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1908-12">
   <w.rf>
    <LM>w#w-d1t1908-12</LM>
   </w.rf>
   <form>osobnost</form>
   <lemma>osobnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1e1892-x3-137">
   <w.rf>
    <LM>w#w-d1e1892-x3-137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1908-13">
   <w.rf>
    <LM>w#w-d1t1908-13</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1908-14">
   <w.rf>
    <LM>w#w-d1t1908-14</LM>
   </w.rf>
   <form>autoritu</form>
   <lemma>autorita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1908-15">
   <w.rf>
    <LM>w#w-d1t1908-15</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1908-16">
   <w.rf>
    <LM>w#w-d1t1908-16</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1908-18">
   <w.rf>
    <LM>w#w-d1t1908-18</LM>
   </w.rf>
   <form>širokou</form>
   <lemma>široký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1908-17">
   <w.rf>
    <LM>w#w-d1t1908-17</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-408-409">
   <w.rf>
    <LM>w#w-408-409</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-411">
  <m id="m121-d1t1908-19">
   <w.rf>
    <LM>w#w-d1t1908-19</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1908-20">
   <w.rf>
    <LM>w#w-d1t1908-20</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1908-21">
   <w.rf>
    <LM>w#w-d1t1908-21</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1908-22">
   <w.rf>
    <LM>w#w-d1t1908-22</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m121-d1t1908-23">
   <w.rf>
    <LM>w#w-d1t1908-23</LM>
   </w.rf>
   <form>uznával</form>
   <lemma>uznávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1908-24">
   <w.rf>
    <LM>w#w-d1t1908-24</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1908-25">
   <w.rf>
    <LM>w#w-d1t1908-25</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m121-d1t1908-26">
   <w.rf>
    <LM>w#w-d1t1908-26</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m121-d1t1908-27">
   <w.rf>
    <LM>w#w-d1t1908-27</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m121-d1t1908-28">
   <w.rf>
    <LM>w#w-d1t1908-28</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1908-29">
   <w.rf>
    <LM>w#w-d1t1908-29</LM>
   </w.rf>
   <form>rády</form>
   <lemma>rád-1</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m121-138-139">
   <w.rf>
    <LM>w#w-138-139</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-138">
  <m id="m121-d1t1910-1">
   <w.rf>
    <LM>w#w-d1t1910-1</LM>
   </w.rf>
   <form>Škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id166029-punct">
   <w.rf>
    <LM>w#w-d-id166029-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1910-3">
   <w.rf>
    <LM>w#w-d1t1910-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1910-4">
   <w.rf>
    <LM>w#w-d1t1910-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m121-d1t1910-5">
   <w.rf>
    <LM>w#w-d1t1910-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1910-6">
   <w.rf>
    <LM>w#w-d1t1910-6</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1910-8">
   <w.rf>
    <LM>w#w-d1t1910-8</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1910-9">
   <w.rf>
    <LM>w#w-d1t1910-9</LM>
   </w.rf>
   <form>nese</form>
   <lemma>nést</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d-id166146-punct">
   <w.rf>
    <LM>w#w-d-id166146-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1910-11">
   <w.rf>
    <LM>w#w-d1t1910-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1910-12">
   <w.rf>
    <LM>w#w-d1t1910-12</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1910-13">
   <w.rf>
    <LM>w#w-d1t1910-13</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1910-15">
   <w.rf>
    <LM>w#w-d1t1910-15</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1910-16">
   <w.rf>
    <LM>w#w-d1t1910-16</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1910-17">
   <w.rf>
    <LM>w#w-d1t1910-17</LM>
   </w.rf>
   <form>skončit</form>
   <lemma>skončit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d-m-d1e1892-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1892-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1917-x2">
  <m id="m121-d1t1920-1">
   <w.rf>
    <LM>w#w-d1t1920-1</LM>
   </w.rf>
   <form>Podívejme</form>
   <lemma>podívat</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m121-d1t1920-2">
   <w.rf>
    <LM>w#w-d1t1920-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1920-3">
   <w.rf>
    <LM>w#w-d1t1920-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1920-4">
   <w.rf>
    <LM>w#w-d1t1920-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1920-5">
   <w.rf>
    <LM>w#w-d1t1920-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1917-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1917-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1921-x2">
  <m id="m121-d1t1926-1">
   <w.rf>
    <LM>w#w-d1t1926-1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1926-2">
   <w.rf>
    <LM>w#w-d1t1926-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1926-3">
   <w.rf>
    <LM>w#w-d1t1926-3</LM>
   </w.rf>
   <form>naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m121-d1t1926-4">
   <w.rf>
    <LM>w#w-d1t1926-4</LM>
   </w.rf>
   <form>pražští</form>
   <lemma>pražský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m121-d1t1926-11">
   <w.rf>
    <LM>w#w-d1t1926-11</LM>
   </w.rf>
   <form>známí</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m121-d1e1921-x2-418">
   <w.rf>
    <LM>w#w-d1e1921-x2-418</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-419">
  <m id="m121-d1t1926-15">
   <w.rf>
    <LM>w#w-d1t1926-15</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1926-14">
   <w.rf>
    <LM>w#w-d1t1926-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1926-16">
   <w.rf>
    <LM>w#w-d1t1926-16</LM>
   </w.rf>
   <form>opravit</form>
   <lemma>opravit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d-id166685-punct">
   <w.rf>
    <LM>w#w-d-id166685-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1926-19">
   <w.rf>
    <LM>w#w-d1t1926-19</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1926-18">
   <w.rf>
    <LM>w#w-d1t1926-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1926-20">
   <w.rf>
    <LM>w#w-d1t1926-20</LM>
   </w.rf>
   <form>doslova</form>
   <lemma>doslova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1926-21">
   <w.rf>
    <LM>w#w-d1t1926-21</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m121-d1e1921-x2-155">
   <w.rf>
    <LM>w#w-d1e1921-x2-155</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-156">
  <m id="m121-d1t1930-1">
   <w.rf>
    <LM>w#w-d1t1930-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1930-2">
   <w.rf>
    <LM>w#w-d1t1930-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1930-3">
   <w.rf>
    <LM>w#w-d1t1930-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1930-4">
   <w.rf>
    <LM>w#w-d1t1930-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1930-5">
   <w.rf>
    <LM>w#w-d1t1930-5</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m121-d1t1930-6">
   <w.rf>
    <LM>w#w-d1t1930-6</LM>
   </w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m121-d-id166903-punct">
   <w.rf>
    <LM>w#w-d-id166903-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1932-3">
   <w.rf>
    <LM>w#w-d1t1932-3</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1932-2">
   <w.rf>
    <LM>w#w-d1t1932-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1932-4">
   <w.rf>
    <LM>w#w-d1t1932-4</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1932-5">
   <w.rf>
    <LM>w#w-d1t1932-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1932-7">
   <w.rf>
    <LM>w#w-d1t1932-7</LM>
   </w.rf>
   <form>Silvestra</form>
   <lemma>Silvestr_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m121-d1t1932-10">
   <w.rf>
    <LM>w#w-d1t1932-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1932-11">
   <w.rf>
    <LM>w#w-d1t1932-11</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1932-12">
   <w.rf>
    <LM>w#w-d1t1932-12</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m121-d1t1932-16">
   <w.rf>
    <LM>w#w-d1t1932-16</LM>
   </w.rf>
   <form>zajímavých</form>
   <lemma>zajímavý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m121-d1t1932-13">
   <w.rf>
    <LM>w#w-d1t1932-13</LM>
   </w.rf>
   <form>příležitostech</form>
   <lemma>příležitost</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m121-d1t1932-15">
   <w.rf>
    <LM>w#w-d1t1932-15</LM>
   </w.rf>
   <form>rodin</form>
   <lemma>rodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-156-425">
   <w.rf>
    <LM>w#w-156-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-427">
  <m id="m121-d1t1932-18">
   <w.rf>
    <LM>w#w-d1t1932-18</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1932-19">
   <w.rf>
    <LM>w#w-d1t1932-19</LM>
   </w.rf>
   <form>svatby</form>
   <lemma>svatba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d1t1932-24">
   <w.rf>
    <LM>w#w-d1t1932-24</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m121-d1t1932-27">
   <w.rf>
    <LM>w#w-d1t1932-27</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m121-d1t1932-26">
   <w.rf>
    <LM>w#w-d1t1932-26</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-d1t1932-21">
   <w.rf>
    <LM>w#w-d1t1932-21</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1932-28">
   <w.rf>
    <LM>w#w-d1t1932-28</LM>
   </w.rf>
   <form>vzájemně</form>
   <lemma>vzájemně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1932-22">
   <w.rf>
    <LM>w#w-d1t1932-22</LM>
   </w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1932-23">
   <w.rf>
    <LM>w#w-d1t1932-23</LM>
   </w.rf>
   <form>slavívali</form>
   <lemma>slavívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-158-159">
   <w.rf>
    <LM>w#w-158-159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-158">
  <m id="m121-d1t1937-2">
   <w.rf>
    <LM>w#w-d1t1937-2</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1937-4">
   <w.rf>
    <LM>w#w-d1t1937-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-5">
   <w.rf>
    <LM>w#w-d1t1937-5</LM>
   </w.rf>
   <form>přítel</form>
   <lemma>přítel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1937-7">
   <w.rf>
    <LM>w#w-d1t1937-7</LM>
   </w.rf>
   <form>Břetislav</form>
   <lemma>Břetislav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-158-450">
   <w.rf>
    <LM>w#w-158-450</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-9">
   <w.rf>
    <LM>w#w-d1t1937-9</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t1937-10">
   <w.rf>
    <LM>w#w-d1t1937-10</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m121-d1t1937-11">
   <w.rf>
    <LM>w#w-d1t1937-11</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-13">
   <w.rf>
    <LM>w#w-d1t1937-13</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1937-14">
   <w.rf>
    <LM>w#w-d1t1937-14</LM>
   </w.rf>
   <form>Nouza</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-158-189">
   <w.rf>
    <LM>w#w-158-189</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-16">
   <w.rf>
    <LM>w#w-d1t1937-16</LM>
   </w.rf>
   <form>známý</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m121-d1t1937-18">
   <w.rf>
    <LM>w#w-d1t1937-18</LM>
   </w.rf>
   <form>pražský</form>
   <lemma>pražský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m121-d1t1937-17">
   <w.rf>
    <LM>w#w-d1t1937-17</LM>
   </w.rf>
   <form>imunolog</form>
   <lemma>imunolog</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d-id167606-punct">
   <w.rf>
    <LM>w#w-d-id167606-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-20">
   <w.rf>
    <LM>w#w-d1t1937-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1937-21">
   <w.rf>
    <LM>w#w-d1t1937-21</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-22">
   <w.rf>
    <LM>w#w-d1t1937-22</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m121-158-451">
   <w.rf>
    <LM>w#w-158-451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-452">
  <m id="m121-d1t1937-24">
   <w.rf>
    <LM>w#w-d1t1937-24</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1937-25">
   <w.rf>
    <LM>w#w-d1t1937-25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-26">
   <w.rf>
    <LM>w#w-d1t1937-26</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1937-29">
   <w.rf>
    <LM>w#w-d1t1937-29</LM>
   </w.rf>
   <form>Břetislava</form>
   <lemma>Břetislav_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-d-id167765-punct">
   <w.rf>
    <LM>w#w-d-id167765-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-32">
   <w.rf>
    <LM>w#w-d1t1937-32</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1937-34">
   <w.rf>
    <LM>w#w-d1t1937-34</LM>
   </w.rf>
   <form>Zdeny</form>
   <lemma>Zdena_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t1937-36">
   <w.rf>
    <LM>w#w-d1t1937-36</LM>
   </w.rf>
   <form>sedí</form>
   <lemma>sedět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-37">
   <w.rf>
    <LM>w#w-d1t1937-37</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1937-38">
   <w.rf>
    <LM>w#w-d1t1937-38</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d-id167870-punct">
   <w.rf>
    <LM>w#w-d-id167870-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-40">
   <w.rf>
    <LM>w#w-d1t1937-40</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m121-d1t1937-41">
   <w.rf>
    <LM>w#w-d1t1937-41</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1937-42">
   <w.rf>
    <LM>w#w-d1t1937-42</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1937-43">
   <w.rf>
    <LM>w#w-d1t1937-43</LM>
   </w.rf>
   <form>vloni</form>
   <lemma>vloni_,s_^(^DD**loni)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1937-44">
   <w.rf>
    <LM>w#w-d1t1937-44</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-452-453">
   <w.rf>
    <LM>w#w-452-453</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-456">
  <m id="m121-d1t1937-46">
   <w.rf>
    <LM>w#w-d1t1937-46</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1937-47">
   <w.rf>
    <LM>w#w-d1t1937-47</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS2--3-------</tag>
  </m>
  <m id="m121-d1t1937-48">
   <w.rf>
    <LM>w#w-d1t1937-48</LM>
   </w.rf>
   <form>sedí</form>
   <lemma>sedět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1937-50">
   <w.rf>
    <LM>w#w-d1t1937-50</LM>
   </w.rf>
   <form>Alena</form>
   <lemma>Alena_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id168052-punct">
   <w.rf>
    <LM>w#w-d-id168052-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1937-53">
   <w.rf>
    <LM>w#w-d1t1937-53</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m121-d1t1937-54">
   <w.rf>
    <LM>w#w-d1t1937-54</LM>
   </w.rf>
   <form>přítelkyně</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-158-190">
   <w.rf>
    <LM>w#w-158-190</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1939-1">
   <w.rf>
    <LM>w#w-d1t1939-1</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1939-3">
   <w.rf>
    <LM>w#w-d1t1939-3</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-d1t1939-4">
   <w.rf>
    <LM>w#w-d1t1939-4</LM>
   </w.rf>
   <form>Nouzy</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-456-457">
   <w.rf>
    <LM>w#w-456-457</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-458">
  <m id="m121-d1t1939-7">
   <w.rf>
    <LM>w#w-d1t1939-7</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1939-8">
   <w.rf>
    <LM>w#w-d1t1939-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1939-9">
   <w.rf>
    <LM>w#w-d1t1939-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1939-10">
   <w.rf>
    <LM>w#w-d1t1939-10</LM>
   </w.rf>
   <form>zmínila</form>
   <lemma>zmínit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d-id168235-punct">
   <w.rf>
    <LM>w#w-d-id168235-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1939-26">
   <w.rf>
    <LM>w#w-d1t1939-26</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1939-27">
   <w.rf>
    <LM>w#w-d1t1939-27</LM>
   </w.rf>
   <form>Nouza</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1939-24">
   <w.rf>
    <LM>w#w-d1t1939-24</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1939-12">
   <w.rf>
    <LM>w#w-d1t1939-12</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m121-d1t1939-13">
   <w.rf>
    <LM>w#w-d1t1939-13</LM>
   </w.rf>
   <form>pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1939-18">
   <w.rf>
    <LM>w#w-d1t1939-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1939-20">
   <w.rf>
    <LM>w#w-d1t1939-20</LM>
   </w.rf>
   <form>modré</form>
   <lemma>modrý_;o</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1939-21">
   <w.rf>
    <LM>w#w-d1t1939-21</LM>
   </w.rf>
   <form>košili</form>
   <lemma>košile</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-458-459">
   <w.rf>
    <LM>w#w-458-459</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1939-16">
   <w.rf>
    <LM>w#w-d1t1939-16</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m121-d1t1939-17">
   <w.rf>
    <LM>w#w-d1t1939-17</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1e1921-x3-188">
   <w.rf>
    <LM>w#w-d1e1921-x3-188</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1921-x3">
  <m id="m121-d1t1941-4">
   <w.rf>
    <LM>w#w-d1t1941-4</LM>
   </w.rf>
   <form>Dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1941-5">
   <w.rf>
    <LM>w#w-d1t1941-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1941-6">
   <w.rf>
    <LM>w#w-d1t1941-6</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d-id168595-punct">
   <w.rf>
    <LM>w#w-d-id168595-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1941-8">
   <w.rf>
    <LM>w#w-d1t1941-8</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1941-9">
   <w.rf>
    <LM>w#w-d1t1941-9</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1941-10">
   <w.rf>
    <LM>w#w-d1t1941-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1941-11">
   <w.rf>
    <LM>w#w-d1t1941-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1941-12">
   <w.rf>
    <LM>w#w-d1t1941-12</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1e1921-x3-210">
   <w.rf>
    <LM>w#w-d1e1921-x3-210</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-211">
  <m id="m121-d1t1945-2">
   <w.rf>
    <LM>w#w-d1t1945-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1945-3">
   <w.rf>
    <LM>w#w-d1t1945-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1945-4">
   <w.rf>
    <LM>w#w-d1t1945-4</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m121-d1t1945-5">
   <w.rf>
    <LM>w#w-d1t1945-5</LM>
   </w.rf>
   <form>dar</form>
   <lemma>dar</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d-id168783-punct">
   <w.rf>
    <LM>w#w-d-id168783-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1945-9">
   <w.rf>
    <LM>w#w-d1t1945-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1945-10">
   <w.rf>
    <LM>w#w-d1t1945-10</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1945-11">
   <w.rf>
    <LM>w#w-d1t1945-11</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDMP4----------</tag>
  </m>
  <m id="m121-d1t1945-12">
   <w.rf>
    <LM>w#w-d1t1945-12</LM>
   </w.rf>
   <form>přátele</form>
   <lemma>přítel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m121-d-id168885-punct">
   <w.rf>
    <LM>w#w-d-id168885-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1945-16">
   <w.rf>
    <LM>w#w-d1t1945-16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t1945-17">
   <w.rf>
    <LM>w#w-d1t1945-17</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m121-d1t1945-18">
   <w.rf>
    <LM>w#w-d1t1945-18</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1945-20">
   <w.rf>
    <LM>w#w-d1t1945-20</LM>
   </w.rf>
   <form>dojít</form>
   <lemma>dojít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d1t1945-22">
   <w.rf>
    <LM>w#w-d1t1945-22</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t1945-23">
   <w.rf>
    <LM>w#w-d1t1945-23</LM>
   </w.rf>
   <form>každým</form>
   <lemma>každý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m121-d1t1945-24">
   <w.rf>
    <LM>w#w-d1t1945-24</LM>
   </w.rf>
   <form>problémem</form>
   <lemma>problém</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m121-211-467">
   <w.rf>
    <LM>w#w-211-467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-468">
  <m id="m121-d1t1945-26">
   <w.rf>
    <LM>w#w-d1t1945-26</LM>
   </w.rf>
   <form>Doslova</form>
   <lemma>doslova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1945-27">
   <w.rf>
    <LM>w#w-d1t1945-27</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1945-28">
   <w.rf>
    <LM>w#w-d1t1945-28</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m121-d-id169120-punct">
   <w.rf>
    <LM>w#w-d-id169120-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1945-30">
   <w.rf>
    <LM>w#w-d1t1945-30</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1945-31">
   <w.rf>
    <LM>w#w-d1t1945-31</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m121-d1t1945-32">
   <w.rf>
    <LM>w#w-d1t1945-32</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1945-33">
   <w.rf>
    <LM>w#w-d1t1945-33</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1945-34">
   <w.rf>
    <LM>w#w-d1t1945-34</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t1945-35">
   <w.rf>
    <LM>w#w-d1t1945-35</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1945-36">
   <w.rf>
    <LM>w#w-d1t1945-36</LM>
   </w.rf>
   <form>zatelefonovat</form>
   <lemma>zatelefonovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d1e1921-x4-212">
   <w.rf>
    <LM>w#w-d1e1921-x4-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1921-x4">
  <m id="m121-d1t1948-2">
   <w.rf>
    <LM>w#w-d1t1948-2</LM>
   </w.rf>
   <form>Zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d1t1948-3">
   <w.rf>
    <LM>w#w-d1t1948-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1948-5">
   <w.rf>
    <LM>w#w-d1t1948-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t1948-7">
   <w.rf>
    <LM>w#w-d1t1948-7</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1948-8">
   <w.rf>
    <LM>w#w-d1t1948-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1948-6">
   <w.rf>
    <LM>w#w-d1t1948-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1e1921-x4-213">
   <w.rf>
    <LM>w#w-d1e1921-x4-213</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1948-9">
   <w.rf>
    <LM>w#w-d1t1948-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1948-10">
   <w.rf>
    <LM>w#w-d1t1948-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1948-11">
   <w.rf>
    <LM>w#w-d1t1948-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1948-12">
   <w.rf>
    <LM>w#w-d1t1948-12</LM>
   </w.rf>
   <form>nezmínila</form>
   <lemma>zmínit</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m121-d1e1921-x4-214">
   <w.rf>
    <LM>w#w-d1e1921-x4-214</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1e1921-x4-478">
   <w.rf>
    <LM>w#w-d1e1921-x4-478</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1948-15">
   <w.rf>
    <LM>w#w-d1t1948-15</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1948-16">
   <w.rf>
    <LM>w#w-d1t1948-16</LM>
   </w.rf>
   <form>Nouza</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1948-18">
   <w.rf>
    <LM>w#w-d1t1948-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1948-19">
   <w.rf>
    <LM>w#w-d1t1948-19</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1948-20">
   <w.rf>
    <LM>w#w-d1t1948-20</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1948-35">
   <w.rf>
    <LM>w#w-d1t1948-35</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1948-36">
   <w.rf>
    <LM>w#w-d1t1948-36</LM>
   </w.rf>
   <form>spřátelili</form>
   <lemma>spřátelit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m121-d1t1948-37">
   <w.rf>
    <LM>w#w-d1t1948-37</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1948-38">
   <w.rf>
    <LM>w#w-d1t1948-38</LM>
   </w.rf>
   <form>gymnáziu</form>
   <lemma>gymnázium</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-d1t1948-39">
   <w.rf>
    <LM>w#w-d1t1948-39</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1948-41">
   <w.rf>
    <LM>w#w-d1t1948-41</LM>
   </w.rf>
   <form>Jindřichově</form>
   <lemma>Jindřichův_;Y_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m121-d1t1948-42">
   <w.rf>
    <LM>w#w-d1t1948-42</LM>
   </w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m121-d1e1921-x4-479">
   <w.rf>
    <LM>w#w-d1e1921-x4-479</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-480">
  <m id="m121-d1t1952-1">
   <w.rf>
    <LM>w#w-d1t1952-1</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m121-d1t1952-2">
   <w.rf>
    <LM>w#w-d1t1952-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1952-4">
   <w.rf>
    <LM>w#w-d1t1952-4</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m121-d1t1952-5">
   <w.rf>
    <LM>w#w-d1t1952-5</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t1952-3">
   <w.rf>
    <LM>w#w-d1t1952-3</LM>
   </w.rf>
   <form>lékaři</form>
   <lemma>lékař</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m121-d1e1921-x5-244">
   <w.rf>
    <LM>w#w-d1e1921-x5-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1921-x5">
  <m id="m121-d1t1952-7">
   <w.rf>
    <LM>w#w-d1t1952-7</LM>
   </w.rf>
   <form>Studovali</form>
   <lemma>studovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1952-9">
   <w.rf>
    <LM>w#w-d1t1952-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1952-10">
   <w.rf>
    <LM>w#w-d1t1952-10</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m121-d1t1952-11">
   <w.rf>
    <LM>w#w-d1t1952-11</LM>
   </w.rf>
   <form>fakultách</form>
   <lemma>fakulta</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m121-d-id170124-punct">
   <w.rf>
    <LM>w#w-d-id170124-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1952-14">
   <w.rf>
    <LM>w#w-d1t1952-14</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1952-15">
   <w.rf>
    <LM>w#w-d1t1952-15</LM>
   </w.rf>
   <form>Nouza</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1952-17">
   <w.rf>
    <LM>w#w-d1t1952-17</LM>
   </w.rf>
   <form>studoval</form>
   <lemma>studovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1952-19">
   <w.rf>
    <LM>w#w-d1t1952-19</LM>
   </w.rf>
   <form>Pražskou</form>
   <lemma>pražský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1952-20">
   <w.rf>
    <LM>w#w-d1t1952-20</LM>
   </w.rf>
   <form>univerzitu</form>
   <lemma>univerzita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1952-22">
   <w.rf>
    <LM>w#w-d1t1952-22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1954-1">
   <w.rf>
    <LM>w#w-d1t1954-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1954-2">
   <w.rf>
    <LM>w#w-d1t1954-2</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1954-3">
   <w.rf>
    <LM>w#w-d1t1954-3</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1954-4">
   <w.rf>
    <LM>w#w-d1t1954-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1954-6">
   <w.rf>
    <LM>w#w-d1t1954-6</LM>
   </w.rf>
   <form>Olomouci</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1e1921-x5-492">
   <w.rf>
    <LM>w#w-d1e1921-x5-492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-493">
  <m id="m121-d1t1954-10">
   <w.rf>
    <LM>w#w-d1t1954-10</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1954-9">
   <w.rf>
    <LM>w#w-d1t1954-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1956-1">
   <w.rf>
    <LM>w#w-d1t1956-1</LM>
   </w.rf>
   <form>přešel</form>
   <lemma>přejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1956-2">
   <w.rf>
    <LM>w#w-d1t1956-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1956-3">
   <w.rf>
    <LM>w#w-d1t1956-3</LM>
   </w.rf>
   <form>Vojenskou</form>
   <lemma>vojenský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1956-4">
   <w.rf>
    <LM>w#w-d1t1956-4</LM>
   </w.rf>
   <form>univerzitu</form>
   <lemma>univerzita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1956-5">
   <w.rf>
    <LM>w#w-d1t1956-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1956-7">
   <w.rf>
    <LM>w#w-d1t1956-7</LM>
   </w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m121-d1t1956-8">
   <w.rf>
    <LM>w#w-d1t1956-8</LM>
   </w.rf>
   <form>Králové</form>
   <lemma>Králové_;G_^(Dvůr_Králové)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-493-494">
   <w.rf>
    <LM>w#w-493-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-495">
  <m id="m121-d1t1958-4">
   <w.rf>
    <LM>w#w-d1t1958-4</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m121-d1t1958-7">
   <w.rf>
    <LM>w#w-d1t1958-7</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m121-d1t1958-8">
   <w.rf>
    <LM>w#w-d1t1958-8</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t1958-9">
   <w.rf>
    <LM>w#w-d1t1958-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1958-12">
   <w.rf>
    <LM>w#w-d1t1958-12</LM>
   </w.rf>
   <form>vzájemně</form>
   <lemma>vzájemně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1958-13">
   <w.rf>
    <LM>w#w-d1t1958-13</LM>
   </w.rf>
   <form>přátelili</form>
   <lemma>přátelit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1e1921-x6-273">
   <w.rf>
    <LM>w#w-d1e1921-x6-273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1921-x6">
  <m id="m121-d1t1961-2">
   <w.rf>
    <LM>w#w-d1t1961-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m121-d1t1961-3">
   <w.rf>
    <LM>w#w-d1t1961-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1961-5">
   <w.rf>
    <LM>w#w-d1t1961-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1961-4">
   <w.rf>
    <LM>w#w-d1t1961-4</LM>
   </w.rf>
   <form>našla</form>
   <lemma>najít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1961-6">
   <w.rf>
    <LM>w#w-d1t1961-6</LM>
   </w.rf>
   <form>cestu</form>
   <lemma>cesta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1961-7">
   <w.rf>
    <LM>w#w-d1t1961-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m121-d1t1961-8">
   <w.rf>
    <LM>w#w-d1t1961-8</LM>
   </w.rf>
   <form>ženě</form>
   <lemma>žena</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m121-d1t1961-11">
   <w.rf>
    <LM>w#w-d1t1961-11</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-d1t1961-12">
   <w.rf>
    <LM>w#w-d1t1961-12</LM>
   </w.rf>
   <form>Nouzy</form>
   <lemma>Nouza_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-d1e1921-x6-504">
   <w.rf>
    <LM>w#w-d1e1921-x6-504</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-505">
  <m id="m121-d1t1963-2">
   <w.rf>
    <LM>w#w-d1t1963-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1963-1">
   <w.rf>
    <LM>w#w-d1t1963-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1963-3">
   <w.rf>
    <LM>w#w-d1t1963-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-id171021-punct">
   <w.rf>
    <LM>w#w-d-id171021-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1963-7">
   <w.rf>
    <LM>w#w-d1t1963-7</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m121-d1t1963-6">
   <w.rf>
    <LM>w#w-d1t1963-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1963-8">
   <w.rf>
    <LM>w#w-d1t1963-8</LM>
   </w.rf>
   <form>též</form>
   <lemma>též</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1963-10">
   <w.rf>
    <LM>w#w-d1t1963-10</LM>
   </w.rf>
   <form>Alena</form>
   <lemma>Alena_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id171125-punct">
   <w.rf>
    <LM>w#w-d-id171125-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1963-13">
   <w.rf>
    <LM>w#w-d1t1963-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1963-14">
   <w.rf>
    <LM>w#w-d1t1963-14</LM>
   </w.rf>
   <form>stejný</form>
   <lemma>stejný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m121-d1t1963-15">
   <w.rf>
    <LM>w#w-d1t1963-15</LM>
   </w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1963-16">
   <w.rf>
    <LM>w#w-d1t1963-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1963-17">
   <w.rf>
    <LM>w#w-d1t1963-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1963-18">
   <w.rf>
    <LM>w#w-d1t1963-18</LM>
   </w.rf>
   <form>zubní</form>
   <lemma>zubní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t1963-19">
   <w.rf>
    <LM>w#w-d1t1963-19</LM>
   </w.rf>
   <form>laborantka</form>
   <lemma>laborantka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-505-506">
   <w.rf>
    <LM>w#w-505-506</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-507">
  <m id="m121-d1t1963-22">
   <w.rf>
    <LM>w#w-d1t1963-22</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1963-23">
   <w.rf>
    <LM>w#w-d1t1963-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1963-24">
   <w.rf>
    <LM>w#w-d1t1963-24</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1963-25">
   <w.rf>
    <LM>w#w-d1t1963-25</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1963-27">
   <w.rf>
    <LM>w#w-d1t1963-27</LM>
   </w.rf>
   <form>kuriózní</form>
   <lemma>kuriózní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-m-d1e1921-x6-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1921-x6-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1964-x2">
  <m id="m121-d1t1969-1">
   <w.rf>
    <LM>w#w-d1t1969-1</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1969-2">
   <w.rf>
    <LM>w#w-d1t1969-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1969-3">
   <w.rf>
    <LM>w#w-d1t1969-3</LM>
   </w.rf>
   <form>rády</form>
   <lemma>rád-1</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m121-d-m-d1e1964-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1964-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1974-x2">
  <m id="m121-d1t1977-1">
   <w.rf>
    <LM>w#w-d1t1977-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1977-2">
   <w.rf>
    <LM>w#w-d1t1977-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1977-3">
   <w.rf>
    <LM>w#w-d1t1977-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1977-4">
   <w.rf>
    <LM>w#w-d1t1977-4</LM>
   </w.rf>
   <form>vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d-id171588-punct">
   <w.rf>
    <LM>w#w-d-id171588-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1978-x2">
  <m id="m121-d1t1981-2">
   <w.rf>
    <LM>w#w-d1t1981-2</LM>
   </w.rf>
   <form>Vídáváme</form>
   <lemma>vídávat_^(*4at)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1981-3">
   <w.rf>
    <LM>w#w-d1t1981-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1981-4">
   <w.rf>
    <LM>w#w-d1t1981-4</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1981-5">
   <w.rf>
    <LM>w#w-d1t1981-5</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d-id171727-punct">
   <w.rf>
    <LM>w#w-d-id171727-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1981-8">
   <w.rf>
    <LM>w#w-d1t1981-8</LM>
   </w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m121-d1t1981-7">
   <w.rf>
    <LM>w#w-d1t1981-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1981-9">
   <w.rf>
    <LM>w#w-d1t1981-9</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1981-10">
   <w.rf>
    <LM>w#w-d1t1981-10</LM>
   </w.rf>
   <form>příležitost</form>
   <lemma>příležitost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1e1978-x2-281">
   <w.rf>
    <LM>w#w-d1e1978-x2-281</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1981-12">
   <w.rf>
    <LM>w#w-d1t1981-12</LM>
   </w.rf>
   <form>rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t1981-13">
   <w.rf>
    <LM>w#w-d1t1981-13</LM>
   </w.rf>
   <form>oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1e1978-x2-327">
   <w.rf>
    <LM>w#w-d1e1978-x2-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-329">
  <m id="m121-d1t1983-1">
   <w.rf>
    <LM>w#w-d1t1983-1</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1983-2">
   <w.rf>
    <LM>w#w-d1t1983-2</LM>
   </w.rf>
   <form>zítra</form>
   <lemma>zítra</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1983-3">
   <w.rf>
    <LM>w#w-d1t1983-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t1983-4">
   <w.rf>
    <LM>w#w-d1t1983-4</LM>
   </w.rf>
   <form>jedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1983-5">
   <w.rf>
    <LM>w#w-d1t1983-5</LM>
   </w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d1t1983-6">
   <w.rf>
    <LM>w#w-d1t1983-6</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d-id171971-punct">
   <w.rf>
    <LM>w#w-d-id171971-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1983-9">
   <w.rf>
    <LM>w#w-d1t1983-9</LM>
   </w.rf>
   <form>chceme</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1983-10">
   <w.rf>
    <LM>w#w-d1t1983-10</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1983-11">
   <w.rf>
    <LM>w#w-d1t1983-11</LM>
   </w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1985-1">
   <w.rf>
    <LM>w#w-d1t1985-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1985-2">
   <w.rf>
    <LM>w#w-d1t1985-2</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-d1t1985-3">
   <w.rf>
    <LM>w#w-d1t1985-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1985-5">
   <w.rf>
    <LM>w#w-d1t1985-5</LM>
   </w.rf>
   <form>Sardínii</form>
   <lemma>Sardínie_;G_,s_^(^DD**Sardinie)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-329-330">
   <w.rf>
    <LM>w#w-329-330</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-331">
  <m id="m121-d1t1985-10">
   <w.rf>
    <LM>w#w-d1t1985-10</LM>
   </w.rf>
   <form>Vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1985-11">
   <w.rf>
    <LM>w#w-d1t1985-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1985-12">
   <w.rf>
    <LM>w#w-d1t1985-12</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d-m-d1e1978-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1978-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1986-x2">
  <m id="m121-d1t1989-2">
   <w.rf>
    <LM>w#w-d1t1989-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1989-3">
   <w.rf>
    <LM>w#w-d1t1989-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1989-4">
   <w.rf>
    <LM>w#w-d1t1989-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t1989-5">
   <w.rf>
    <LM>w#w-d1t1989-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1986-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1986-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1990-x2">
  <m id="m121-d1t2001-2">
   <w.rf>
    <LM>w#w-d1t2001-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2001-3">
   <w.rf>
    <LM>w#w-d1t2001-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t2001-4">
   <w.rf>
    <LM>w#w-d1t2001-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m121-d1t2001-5">
   <w.rf>
    <LM>w#w-d1t2001-5</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t1995-4">
   <w.rf>
    <LM>w#w-d1t1995-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1995-5">
   <w.rf>
    <LM>w#w-d1t1995-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1995-9">
   <w.rf>
    <LM>w#w-d1t1995-9</LM>
   </w.rf>
   <form>slavnostní</form>
   <lemma>slavnostní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m121-d1t1995-10">
   <w.rf>
    <LM>w#w-d1t1995-10</LM>
   </w.rf>
   <form>okamžik</form>
   <lemma>okamžik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d-id172580-punct">
   <w.rf>
    <LM>w#w-d-id172580-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1997-1">
   <w.rf>
    <LM>w#w-d1t1997-1</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2001-6">
   <w.rf>
    <LM>w#w-d1t2001-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t2001-7">
   <w.rf>
    <LM>w#w-d1t2001-7</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1997-5">
   <w.rf>
    <LM>w#w-d1t1997-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1997-6">
   <w.rf>
    <LM>w#w-d1t1997-6</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t1997-7">
   <w.rf>
    <LM>w#w-d1t1997-7</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1997-10">
   <w.rf>
    <LM>w#w-d1t1997-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t1997-12">
   <w.rf>
    <LM>w#w-d1t1997-12</LM>
   </w.rf>
   <form>České</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m121-d1t1997-13">
   <w.rf>
    <LM>w#w-d1t1997-13</LM>
   </w.rf>
   <form>asociace</form>
   <lemma>asociace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t1997-14">
   <w.rf>
    <LM>w#w-d1t1997-14</LM>
   </w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-d-id172817-punct">
   <w.rf>
    <LM>w#w-d-id172817-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1999-1">
   <w.rf>
    <LM>w#w-d1t1999-1</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m121-d1t1999-4">
   <w.rf>
    <LM>w#w-d1t1999-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1999-2">
   <w.rf>
    <LM>w#w-d1t1999-2</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1999-3">
   <w.rf>
    <LM>w#w-d1t1999-3</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m121-d1t1999-6">
   <w.rf>
    <LM>w#w-d1t1999-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1999-7">
   <w.rf>
    <LM>w#w-d1t1999-7</LM>
   </w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1999-8">
   <w.rf>
    <LM>w#w-d1t1999-8</LM>
   </w.rf>
   <form>založit</form>
   <lemma>založit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d-id172959-punct">
   <w.rf>
    <LM>w#w-d-id172959-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2004-1">
   <w.rf>
    <LM>w#w-d1t2004-1</LM>
   </w.rf>
   <form>ocenění</form>
   <lemma>ocenění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-d1t2004-3">
   <w.rf>
    <LM>w#w-d1t2004-3</LM>
   </w.rf>
   <form>Florence</form>
   <lemma>Florence-2_;Y</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m121-d1t2006-1">
   <w.rf>
    <LM>w#w-d1t2006-1</LM>
   </w.rf>
   <form>Nachtigalové</form>
   <lemma>Nachtigalová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t2001-9">
   <w.rf>
    <LM>w#w-d1t2001-9</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t2001-10">
   <w.rf>
    <LM>w#w-d1t2001-10</LM>
   </w.rf>
   <form>celoživotní</form>
   <lemma>celoživotní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t2001-11">
   <w.rf>
    <LM>w#w-d1t2001-11</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1e1990-x3-313">
   <w.rf>
    <LM>w#w-d1e1990-x3-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-550">
  <m id="m121-d1t1999-10">
   <w.rf>
    <LM>w#w-d1t1999-10</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1999-11">
   <w.rf>
    <LM>w#w-d1t1999-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1999-12">
   <w.rf>
    <LM>w#w-d1t1999-12</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m121-d1e1990-x2-549">
   <w.rf>
    <LM>w#w-d1e1990-x2-549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1999-15">
   <w.rf>
    <LM>w#w-d1t1999-15</LM>
   </w.rf>
   <form>založily</form>
   <lemma>založit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m121-d1t1999-14">
   <w.rf>
    <LM>w#w-d1t1999-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1999-17">
   <w.rf>
    <LM>w#w-d1t1999-17</LM>
   </w.rf>
   <form>Českou</form>
   <lemma>český</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1999-18">
   <w.rf>
    <LM>w#w-d1t1999-18</LM>
   </w.rf>
   <form>asociaci</form>
   <lemma>asociace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1999-19">
   <w.rf>
    <LM>w#w-d1t1999-19</LM>
   </w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-550-567">
   <w.rf>
    <LM>w#w-550-567</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1990-x3">
  <m id="m121-d1t2008-2">
   <w.rf>
    <LM>w#w-d1t2008-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t2008-3">
   <w.rf>
    <LM>w#w-d1t2008-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2008-4">
   <w.rf>
    <LM>w#w-d1t2008-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m121-d1t2008-5">
   <w.rf>
    <LM>w#w-d1t2008-5</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id173474-punct">
   <w.rf>
    <LM>w#w-d-id173474-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2008-7">
   <w.rf>
    <LM>w#w-d1t2008-7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m121-d1t2008-8">
   <w.rf>
    <LM>w#w-d1t2008-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t2010-2">
   <w.rf>
    <LM>w#w-d1t2010-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t2010-3">
   <w.rf>
    <LM>w#w-d1t2010-3</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m121-d1t2010-4">
   <w.rf>
    <LM>w#w-d1t2010-4</LM>
   </w.rf>
   <form>slavnostní</form>
   <lemma>slavnostní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m121-d1t2010-5">
   <w.rf>
    <LM>w#w-d1t2010-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t2008-9">
   <w.rf>
    <LM>w#w-d1t2008-9</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t2008-10">
   <w.rf>
    <LM>w#w-d1t2008-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2010-1">
   <w.rf>
    <LM>w#w-d1t2010-1</LM>
   </w.rf>
   <form>poblahopřát</form>
   <lemma>poblahopřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d1e1990-x3-576">
   <w.rf>
    <LM>w#w-d1e1990-x3-576</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-577">
  <m id="m121-d1t2012-1">
   <w.rf>
    <LM>w#w-d1t2012-1</LM>
   </w.rf>
   <form>Velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2012-2">
   <w.rf>
    <LM>w#w-d1t2012-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t2012-3">
   <w.rf>
    <LM>w#w-d1t2012-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m121-d1t2012-4">
   <w.rf>
    <LM>w#w-d1t2012-4</LM>
   </w.rf>
   <form>považuji</form>
   <lemma>považovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m121-d-id173709-punct">
   <w.rf>
    <LM>w#w-d-id173709-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2012-6">
   <w.rf>
    <LM>w#w-d1t2012-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t2012-7">
   <w.rf>
    <LM>w#w-d1t2012-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t2012-10">
   <w.rf>
    <LM>w#w-d1t2012-10</LM>
   </w.rf>
   <form>zdravotnictví</form>
   <lemma>zdravotnictví</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m121-d1t2012-14">
   <w.rf>
    <LM>w#w-d1t2012-14</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t2012-16">
   <w.rf>
    <LM>w#w-d1t2012-16</LM>
   </w.rf>
   <form>asociaci</form>
   <lemma>asociace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m121-d1t2012-9">
   <w.rf>
    <LM>w#w-d1t2012-9</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t2012-11">
   <w.rf>
    <LM>w#w-d1t2012-11</LM>
   </w.rf>
   <form>dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t2012-12">
   <w.rf>
    <LM>w#w-d1t2012-12</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m121-d1t2012-13">
   <w.rf>
    <LM>w#w-d1t2012-13</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-577-578">
   <w.rf>
    <LM>w#w-577-578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-579">
  <m id="m121-d1t2012-21">
   <w.rf>
    <LM>w#w-d1t2012-21</LM>
   </w.rf>
   <form>Žila</form>
   <lemma>žít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t2012-19">
   <w.rf>
    <LM>w#w-d1t2012-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t2012-20">
   <w.rf>
    <LM>w#w-d1t2012-20</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m121-d1t2012-22">
   <w.rf>
    <LM>w#w-d1t2012-22</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m121-d1t2012-23">
   <w.rf>
    <LM>w#w-d1t2012-23</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m121-d-id173991-punct">
   <w.rf>
    <LM>w#w-d-id173991-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2014-1">
   <w.rf>
    <LM>w#w-d1t2014-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t2014-2">
   <w.rf>
    <LM>w#w-d1t2014-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t2014-3">
   <w.rf>
    <LM>w#w-d1t2014-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t2014-4">
   <w.rf>
    <LM>w#w-d1t2014-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m121-d1t2014-5">
   <w.rf>
    <LM>w#w-d1t2014-5</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t2014-6">
   <w.rf>
    <LM>w#w-d1t2014-6</LM>
   </w.rf>
   <form>stala</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t2014-7">
   <w.rf>
    <LM>w#w-d1t2014-7</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t2014-8">
   <w.rf>
    <LM>w#w-d1t2014-8</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id174132-punct">
   <w.rf>
    <LM>w#w-d-id174132-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2014-10">
   <w.rf>
    <LM>w#w-d1t2014-10</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m121-d1t2014-11">
   <w.rf>
    <LM>w#w-d1t2014-11</LM>
   </w.rf>
   <form>povznese</form>
   <lemma>povznést</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m121-d1t2014-12">
   <w.rf>
    <LM>w#w-d1t2014-12</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t2014-13">
   <w.rf>
    <LM>w#w-d1t2014-13</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t2017-1">
   <w.rf>
    <LM>w#w-d1t2017-1</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2017-2">
   <w.rf>
    <LM>w#w-d1t2017-2</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m121-d1t2017-3">
   <w.rf>
    <LM>w#w-d1t2017-3</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t2017-4">
   <w.rf>
    <LM>w#w-d1t2017-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-579-580">
   <w.rf>
    <LM>w#w-579-580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-582">
  <m id="m121-d1t2017-6">
   <w.rf>
    <LM>w#w-d1t2017-6</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t2017-7">
   <w.rf>
    <LM>w#w-d1t2017-7</LM>
   </w.rf>
   <form>pocit</form>
   <lemma>pocit</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d-id174321-punct">
   <w.rf>
    <LM>w#w-d-id174321-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2017-9">
   <w.rf>
    <LM>w#w-d1t2017-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t2017-10">
   <w.rf>
    <LM>w#w-d1t2017-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t2017-11">
   <w.rf>
    <LM>w#w-d1t2017-11</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m121-d1t2017-12">
   <w.rf>
    <LM>w#w-d1t2017-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t2017-13">
   <w.rf>
    <LM>w#w-d1t2017-13</LM>
   </w.rf>
   <form>zdařilo</form>
   <lemma>zdařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m121-d1e1990-x3-327">
   <w.rf>
    <LM>w#w-d1e1990-x3-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-328">
  <m id="m121-d1t2019-1">
   <w.rf>
    <LM>w#w-d1t2019-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2019-2">
   <w.rf>
    <LM>w#w-d1t2019-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2019-3">
   <w.rf>
    <LM>w#w-d1t2019-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t2019-4">
   <w.rf>
    <LM>w#w-d1t2019-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2019-5">
   <w.rf>
    <LM>w#w-d1t2019-5</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id174500-punct">
   <w.rf>
    <LM>w#w-d-id174500-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2019-7">
   <w.rf>
    <LM>w#w-d1t2019-7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m121-d1t2019-8">
   <w.rf>
    <LM>w#w-d1t2019-8</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2019-9">
   <w.rf>
    <LM>w#w-d1t2019-9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t2019-10">
   <w.rf>
    <LM>w#w-d1t2019-10</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2019-11">
   <w.rf>
    <LM>w#w-d1t2019-11</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t2019-13">
   <w.rf>
    <LM>w#w-d1t2019-13</LM>
   </w.rf>
   <form>vysokoškolské</form>
   <lemma>vysokoškolský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m121-d1t2019-14">
   <w.rf>
    <LM>w#w-d1t2019-14</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-d-id174633-punct">
   <w.rf>
    <LM>w#w-d-id174633-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t2019-16">
   <w.rf>
    <LM>w#w-d1t2019-16</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t2019-17">
   <w.rf>
    <LM>w#w-d1t2019-17</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m121-d1t2019-18">
   <w.rf>
    <LM>w#w-d1t2019-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t2019-19">
   <w.rf>
    <LM>w#w-d1t2019-19</LM>
   </w.rf>
   <form>nemohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m121-d1e1990-x4-339">
   <w.rf>
    <LM>w#w-d1e1990-x4-339</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1990-x4">
  <m id="m121-d1t2021-1">
   <w.rf>
    <LM>w#w-d1t2021-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2021-2">
   <w.rf>
    <LM>w#w-d1t2021-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t2021-3">
   <w.rf>
    <LM>w#w-d1t2021-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2021-4">
   <w.rf>
    <LM>w#w-d1t2021-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>ošetřovatelství</form>
   <lemma>ošetřovatelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t2021-5">
   <w.rf>
    <LM>w#w-d1t2021-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t2021-6">
   <w.rf>
    <LM>w#w-d1t2021-6</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t2021-7">
   <w.rf>
    <LM>w#w-d1t2021-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t2021-8">
   <w.rf>
    <LM>w#w-d1t2021-8</LM>
   </w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t2021-9">
   <w.rf>
    <LM>w#w-d1t2021-9</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t2023-1">
   <w.rf>
    <LM>w#w-d1t2023-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t2023-2">
   <w.rf>
    <LM>w#w-d1t2023-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t2023-3">
   <w.rf>
    <LM>w#w-d1t2023-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m121-d1t2023-4">
   <w.rf>
    <LM>w#w-d1t2023-4</LM>
   </w.rf>
   <form>vším</form>
   <lemma>všechen</lemma>
   <tag>PLZS7----------</tag>
  </m>
  <m id="m121-d1t2023-5">
   <w.rf>
    <LM>w#w-d1t2023-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t2023-6">
   <w.rf>
    <LM>w#w-d1t2023-6</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t2023-7">
   <w.rf>
    <LM>w#w-d1t2023-7</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t2023-8">
   <w.rf>
    <LM>w#w-d1t2023-8</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1990-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1990-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e2024-x2">
  <m id="m121-d1t2027-1">
   <w.rf>
    <LM>w#w-d1t2027-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m121-d1t2027-2">
   <w.rf>
    <LM>w#w-d1t2027-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m121-d1t2027-3">
   <w.rf>
    <LM>w#w-d1t2027-3</LM>
   </w.rf>
   <form>ocenění</form>
   <lemma>ocenění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-d1t2027-4">
   <w.rf>
    <LM>w#w-d1t2027-4</LM>
   </w.rf>
   <form>předával</form>
   <lemma>předávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d-id175107-punct">
   <w.rf>
    <LM>w#w-d-id175107-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
