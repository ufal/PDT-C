<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_125.10.w.gz" />
  </references>
 </head>
 <s id="m125-49">
  <m id="m125-d1t1725-17">
   <w.rf>
    <LM>w#w-d1t1725-17</LM>
   </w.rf>
   <form>Buďto</form>
   <lemma>buďto</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1725-19">
   <w.rf>
    <LM>w#w-d1t1725-19</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m125-d1t1725-20">
   <w.rf>
    <LM>w#w-d1t1725-20</LM>
   </w.rf>
   <form>poslouchala</form>
   <lemma>poslouchat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m125-d1t1725-21">
   <w.rf>
    <LM>w#w-d1t1725-21</LM>
   </w.rf>
   <form>hudbu</form>
   <lemma>hudba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d-id158801-punct">
   <w.rf>
    <LM>w#w-d-id158801-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1725-23">
   <w.rf>
    <LM>w#w-d1t1725-23</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m125-d1t1725-24">
   <w.rf>
    <LM>w#w-d1t1725-24</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1725-25">
   <w.rf>
    <LM>w#w-d1t1725-25</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m125-d-id158856-punct">
   <w.rf>
    <LM>w#w-d-id158856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1725-27">
   <w.rf>
    <LM>w#w-d1t1725-27</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1725-28">
   <w.rf>
    <LM>w#w-d1t1725-28</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m125-d1t1725-29">
   <w.rf>
    <LM>w#w-d1t1725-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1725-30">
   <w.rf>
    <LM>w#w-d1t1725-30</LM>
   </w.rf>
   <form>dívala</form>
   <lemma>dívat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m125-d1t1725-31">
   <w.rf>
    <LM>w#w-d1t1725-31</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1725-32">
   <w.rf>
    <LM>w#w-d1t1725-32</LM>
   </w.rf>
   <form>televizi</form>
   <lemma>televize</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m125-d-id158958-punct">
   <w.rf>
    <LM>w#w-d-id158958-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1725-34">
   <w.rf>
    <LM>w#w-d1t1725-34</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1725-35">
   <w.rf>
    <LM>w#w-d1t1725-35</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1725-36">
   <w.rf>
    <LM>w#w-d1t1725-36</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1725-37">
   <w.rf>
    <LM>w#w-d1t1725-37</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m125-d1t1725-38">
   <w.rf>
    <LM>w#w-d1t1725-38</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m125-49-64">
   <w.rf>
    <LM>w#w-49-64</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-47">
  <m id="m125-d1t1727-2">
   <w.rf>
    <LM>w#w-d1t1727-2</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1727-3">
   <w.rf>
    <LM>w#w-d1t1727-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1727-4">
   <w.rf>
    <LM>w#w-d1t1727-4</LM>
   </w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m125-d1t1727-5">
   <w.rf>
    <LM>w#w-d1t1727-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1t1727-6">
   <w.rf>
    <LM>w#w-d1t1727-6</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m125-d1t1727-7">
   <w.rf>
    <LM>w#w-d1t1727-7</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m125-d1t1727-8">
   <w.rf>
    <LM>w#w-d1t1727-8</LM>
   </w.rf>
   <form>lidmi</form>
   <lemma>lidé</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m125-47-67">
   <w.rf>
    <LM>w#w-47-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-45">
  <m id="m125-d1t1727-10">
   <w.rf>
    <LM>w#w-d1t1727-10</LM>
   </w.rf>
   <form>Spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d1t1727-12">
   <w.rf>
    <LM>w#w-d1t1727-12</LM>
   </w.rf>
   <form>pacientů</form>
   <lemma>pacient</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m125-d-id159239-punct">
   <w.rf>
    <LM>w#w-d-id159239-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1727-14">
   <w.rf>
    <LM>w#w-d1t1727-14</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m125-d1t1727-15">
   <w.rf>
    <LM>w#w-d1t1727-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1727-16">
   <w.rf>
    <LM>w#w-d1t1727-16</LM>
   </w.rf>
   <form>vrací</form>
   <lemma>vracet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m125-d-id159295-punct">
   <w.rf>
    <LM>w#w-d-id159295-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1727-18">
   <w.rf>
    <LM>w#w-d1t1727-18</LM>
   </w.rf>
   <form>znám</form>
   <lemma>znát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-45-74">
   <w.rf>
    <LM>w#w-45-74</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1729-1">
   <w.rf>
    <LM>w#w-d1t1729-1</LM>
   </w.rf>
   <form>hovořim</form>
   <lemma>hovořit</lemma>
   <tag>VB-S---1P-AAI-6</tag>
  </m>
  <m id="m125-d1t1729-2">
   <w.rf>
    <LM>w#w-d1t1729-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m125-d1t1729-3">
   <w.rf>
    <LM>w#w-d1t1729-3</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m125-d1t1729-4">
   <w.rf>
    <LM>w#w-d1t1729-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1729-5">
   <w.rf>
    <LM>w#w-d1t1729-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1729-6">
   <w.rf>
    <LM>w#w-d1t1729-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1729-7">
   <w.rf>
    <LM>w#w-d1t1729-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1t1729-8">
   <w.rf>
    <LM>w#w-d1t1729-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m125-d1t1729-9">
   <w.rf>
    <LM>w#w-d1t1729-9</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1729-10">
   <w.rf>
    <LM>w#w-d1t1729-10</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m125-d-m-d1e1718-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1718-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1731-x2">
  <m id="m125-d1t1734-1">
   <w.rf>
    <LM>w#w-d1t1734-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m125-d-m-d1e1731-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1731-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1735-x2">
  <m id="m125-d1t1740-2">
   <w.rf>
    <LM>w#w-d1t1740-2</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m125-d1t1740-3">
   <w.rf>
    <LM>w#w-d1t1740-3</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d-m-d1e1735-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1735-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1735-x3">
  <m id="m125-d1t1742-1">
   <w.rf>
    <LM>w#w-d1t1742-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d-m-d1e1735-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1735-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1743-x2">
  <m id="m125-d1t1748-3">
   <w.rf>
    <LM>w#w-d1t1748-3</LM>
   </w.rf>
   <form>Podívejte</form>
   <lemma>podívat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m125-d1t1748-4">
   <w.rf>
    <LM>w#w-d1t1748-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d-id159830-punct">
   <w.rf>
    <LM>w#w-d-id159830-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1748-6">
   <w.rf>
    <LM>w#w-d1t1748-6</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1748-9">
   <w.rf>
    <LM>w#w-d1t1748-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1748-10">
   <w.rf>
    <LM>w#w-d1t1748-10</LM>
   </w.rf>
   <form>úplná</form>
   <lemma>úplný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m125-d1t1748-11">
   <w.rf>
    <LM>w#w-d1t1748-11</LM>
   </w.rf>
   <form>nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1e1743-x2-4">
   <w.rf>
    <LM>w#w-d1e1743-x2-4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1750-1">
   <w.rf>
    <LM>w#w-d1t1750-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1750-2">
   <w.rf>
    <LM>w#w-d1t1750-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1750-3">
   <w.rf>
    <LM>w#w-d1t1750-3</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m125-d1t1750-4">
   <w.rf>
    <LM>w#w-d1t1750-4</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1750-5">
   <w.rf>
    <LM>w#w-d1t1750-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1750-6">
   <w.rf>
    <LM>w#w-d1t1750-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m125-d1t1750-7">
   <w.rf>
    <LM>w#w-d1t1750-7</LM>
   </w.rf>
   <form>pravnučka</form>
   <lemma>pravnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-113-143">
   <w.rf>
    <LM>w#w-113-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-142">
  <m id="m125-d1t1752-1">
   <w.rf>
    <LM>w#w-d1t1752-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1752-2">
   <w.rf>
    <LM>w#w-d1t1752-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1752-3">
   <w.rf>
    <LM>w#w-d1t1752-3</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1752-5">
   <w.rf>
    <LM>w#w-d1t1752-5</LM>
   </w.rf>
   <form>Markéta</form>
   <lemma>Markéta_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1754-1">
   <w.rf>
    <LM>w#w-d1t1754-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1754-2">
   <w.rf>
    <LM>w#w-d1t1754-2</LM>
   </w.rf>
   <form>pravnučka</form>
   <lemma>pravnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1754-4">
   <w.rf>
    <LM>w#w-d1t1754-4</LM>
   </w.rf>
   <form>Eliška</form>
   <lemma>Eliška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d-id160230-punct">
   <w.rf>
    <LM>w#w-d-id160230-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1754-7">
   <w.rf>
    <LM>w#w-d1t1754-7</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS3----------</tag>
  </m>
  <m id="m125-d1t1754-8">
   <w.rf>
    <LM>w#w-d1t1754-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1754-9">
   <w.rf>
    <LM>w#w-d1t1754-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1754-16">
   <w.rf>
    <LM>w#w-d1t1754-16</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m125-d1t1754-17">
   <w.rf>
    <LM>w#w-d1t1754-17</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m125-d1t1754-18">
   <w.rf>
    <LM>w#w-d1t1754-18</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m125-142-144">
   <w.rf>
    <LM>w#w-142-144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-112">
  <m id="m125-d1t1759-2">
   <w.rf>
    <LM>w#w-d1t1759-2</LM>
   </w.rf>
   <form>Markéta</form>
   <lemma>Markéta_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1759-5">
   <w.rf>
    <LM>w#w-d1t1759-5</LM>
   </w.rf>
   <form>vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m125-d1t1759-6">
   <w.rf>
    <LM>w#w-d1t1759-6</LM>
   </w.rf>
   <form>filosofii</form>
   <lemma>filosofie_,s_^(^DD**filozofie)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-112-152">
   <w.rf>
    <LM>w#w-112-152</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1759-7">
   <w.rf>
    <LM>w#w-d1t1759-7</LM>
   </w.rf>
   <form>dějiny</form>
   <lemma>dějiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m125-d1t1759-8">
   <w.rf>
    <LM>w#w-d1t1759-8</LM>
   </w.rf>
   <form>umění</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m125-d1t1759-9">
   <w.rf>
    <LM>w#w-d1t1759-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1759-10">
   <w.rf>
    <LM>w#w-d1t1759-10</LM>
   </w.rf>
   <form>angličtinu</form>
   <lemma>angličtina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d1t1759-11">
   <w.rf>
    <LM>w#w-d1t1759-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1759-13">
   <w.rf>
    <LM>w#w-d1t1759-13</LM>
   </w.rf>
   <form>Masarykově</form>
   <lemma>Masarykův_;Y_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m125-d1t1759-14">
   <w.rf>
    <LM>w#w-d1t1759-14</LM>
   </w.rf>
   <form>univerzitě</form>
   <lemma>univerzita</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m125-d1t1759-15">
   <w.rf>
    <LM>w#w-d1t1759-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1759-16">
   <w.rf>
    <LM>w#w-d1t1759-16</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m125-d-id160678-punct">
   <w.rf>
    <LM>w#w-d-id160678-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1759-19">
   <w.rf>
    <LM>w#w-d1t1759-19</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-112-20">
   <w.rf>
    <LM>w#w-112-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1759-27">
   <w.rf>
    <LM>w#w-d1t1759-27</LM>
   </w.rf>
   <form>spojení</form>
   <lemma>spojení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m125-d1t1759-22">
   <w.rf>
    <LM>w#w-d1t1759-22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1759-24">
   <w.rf>
    <LM>w#w-d1t1759-24</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m125-d1t1759-20">
   <w.rf>
    <LM>w#w-d1t1759-20</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1759-28">
   <w.rf>
    <LM>w#w-d1t1759-28</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m125-112-153">
   <w.rf>
    <LM>w#w-112-153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1743-x3">
  <m id="m125-d1t1761-2">
   <w.rf>
    <LM>w#w-d1t1761-2</LM>
   </w.rf>
   <form>Pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m125-d1t1761-3">
   <w.rf>
    <LM>w#w-d1t1761-3</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m125-d1t1761-4">
   <w.rf>
    <LM>w#w-d1t1761-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m125-d1t1761-5">
   <w.rf>
    <LM>w#w-d1t1761-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1e1743-x3-157">
   <w.rf>
    <LM>w#w-d1e1743-x3-157</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1761-6">
   <w.rf>
    <LM>w#w-d1t1761-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m125-d1t1761-7">
   <w.rf>
    <LM>w#w-d1t1761-7</LM>
   </w.rf>
   <form>mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m125-d1t1761-8">
   <w.rf>
    <LM>w#w-d1t1761-8</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m125-d1e1743-x3-158">
   <w.rf>
    <LM>w#w-d1e1743-x3-158</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1761-9">
   <w.rf>
    <LM>w#w-d1t1761-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1761-11">
   <w.rf>
    <LM>w#w-d1t1761-11</LM>
   </w.rf>
   <form>Historickém</form>
   <lemma>historický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m125-d1t1761-12">
   <w.rf>
    <LM>w#w-d1t1761-12</LM>
   </w.rf>
   <form>ústavu</form>
   <lemma>ústav</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m125-d1t1761-13">
   <w.rf>
    <LM>w#w-d1t1761-13</LM>
   </w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m125-d1t1761-14">
   <w.rf>
    <LM>w#w-d1t1761-14</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m125-d1t1761-15">
   <w.rf>
    <LM>w#w-d1t1761-15</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m125-d1e1743-x3-159">
   <w.rf>
    <LM>w#w-d1e1743-x3-159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-111">
  <m id="m125-d1t1763-3">
   <w.rf>
    <LM>w#w-d1t1763-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1763-4">
   <w.rf>
    <LM>w#w-d1t1763-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1763-5">
   <w.rf>
    <LM>w#w-d1t1763-5</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m125-d1t1763-6">
   <w.rf>
    <LM>w#w-d1t1763-6</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m125-d1t1763-7">
   <w.rf>
    <LM>w#w-d1t1763-7</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m125-d1t1763-8">
   <w.rf>
    <LM>w#w-d1t1763-8</LM>
   </w.rf>
   <form>holčička</form>
   <lemma>holčička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-111-162">
   <w.rf>
    <LM>w#w-111-162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-110">
  <m id="m125-d1t1763-10">
   <w.rf>
    <LM>w#w-d1t1763-10</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m125-d1t1763-11">
   <w.rf>
    <LM>w#w-d1t1763-11</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m125-d1t1763-12">
   <w.rf>
    <LM>w#w-d1t1763-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1763-13">
   <w.rf>
    <LM>w#w-d1t1763-13</LM>
   </w.rf>
   <form>profesorem</form>
   <lemma>profesor</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m125-d1t1763-14">
   <w.rf>
    <LM>w#w-d1t1763-14</LM>
   </w.rf>
   <form>češtiny</form>
   <lemma>čeština</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m125-d1t1763-15">
   <w.rf>
    <LM>w#w-d1t1763-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1763-16">
   <w.rf>
    <LM>w#w-d1t1763-16</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m125-d1t1763-17">
   <w.rf>
    <LM>w#w-d1t1763-17</LM>
   </w.rf>
   <form>literatury</form>
   <lemma>literatura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m125-d1t1763-18">
   <w.rf>
    <LM>w#w-d1t1763-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1763-19">
   <w.rf>
    <LM>w#w-d1t1763-19</LM>
   </w.rf>
   <form>univerzitě</form>
   <lemma>univerzita</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m125-d1t1765-1">
   <w.rf>
    <LM>w#w-d1t1765-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m125-d1t1765-3">
   <w.rf>
    <LM>w#w-d1t1765-3</LM>
   </w.rf>
   <form>Pardubicích</form>
   <lemma>Pardubice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m125-d-m-d1e1743-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1743-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1766-x2">
  <m id="m125-d1t1769-2">
   <w.rf>
    <LM>w#w-d1t1769-2</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m125-d1t1769-3">
   <w.rf>
    <LM>w#w-d1t1769-3</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m125-d1t1769-4">
   <w.rf>
    <LM>w#w-d1t1769-4</LM>
   </w.rf>
   <form>pravnoučat</form>
   <lemma>pravnouče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m125-d-id161555-punct">
   <w.rf>
    <LM>w#w-d-id161555-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1770-x2">
  <m id="m125-d1t1773-1">
   <w.rf>
    <LM>w#w-d1t1773-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1773-2">
   <w.rf>
    <LM>w#w-d1t1773-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1773-3">
   <w.rf>
    <LM>w#w-d1t1773-3</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m125-d1t1773-4">
   <w.rf>
    <LM>w#w-d1t1773-4</LM>
   </w.rf>
   <form>pravnučku</form>
   <lemma>pravnučka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d1e1770-x2-47">
   <w.rf>
    <LM>w#w-d1e1770-x2-47</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1773-7">
   <w.rf>
    <LM>w#w-d1t1773-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m125-d1t1773-8">
   <w.rf>
    <LM>w#w-d1t1773-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1773-11">
   <w.rf>
    <LM>w#w-d1t1773-11</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1773-9">
   <w.rf>
    <LM>w#w-d1t1773-9</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1773-10">
   <w.rf>
    <LM>w#w-d1t1773-10</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m125-d1e1770-x2-49">
   <w.rf>
    <LM>w#w-d1e1770-x2-49</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-50">
  <m id="m125-d1t1775-1">
   <w.rf>
    <LM>w#w-d1t1775-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1775-2">
   <w.rf>
    <LM>w#w-d1t1775-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1775-4">
   <w.rf>
    <LM>w#w-d1t1775-4</LM>
   </w.rf>
   <form>Zuzanka</form>
   <lemma>Zuzanka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d-id161866-punct">
   <w.rf>
    <LM>w#w-d-id161866-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1777-1">
   <w.rf>
    <LM>w#w-d1t1777-1</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1777-3">
   <w.rf>
    <LM>w#w-d1t1777-3</LM>
   </w.rf>
   <form>Ondry</form>
   <lemma>Ondra_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m125-50-51">
   <w.rf>
    <LM>w#w-50-51</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-184">
  <m id="m125-d1t1779-2">
   <w.rf>
    <LM>w#w-d1t1779-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1779-4">
   <w.rf>
    <LM>w#w-d1t1779-4</LM>
   </w.rf>
   <form>kouzelné</form>
   <lemma>kouzelný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m125-d1t1779-5">
   <w.rf>
    <LM>w#w-d1t1779-5</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-184-91">
   <w.rf>
    <LM>w#w-184-91</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-6">
   <w.rf>
    <LM>w#w-d1t1779-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1779-9">
   <w.rf>
    <LM>w#w-d1t1779-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1779-8">
   <w.rf>
    <LM>w#w-d1t1779-8</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1779-10">
   <w.rf>
    <LM>w#w-d1t1779-10</LM>
   </w.rf>
   <form>rozrůstá</form>
   <lemma>rozrůstat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d-id162133-punct">
   <w.rf>
    <LM>w#w-d-id162133-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-12">
   <w.rf>
    <LM>w#w-d1t1779-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1779-16">
   <w.rf>
    <LM>w#w-d1t1779-16</LM>
   </w.rf>
   <form>ohromný</form>
   <lemma>ohromný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m125-d1t1779-17">
   <w.rf>
    <LM>w#w-d1t1779-17</LM>
   </w.rf>
   <form>smysl</form>
   <lemma>smysl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m125-184-92">
   <w.rf>
    <LM>w#w-184-92</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1779-18">
   <w.rf>
    <LM>w#w-d1t1779-18</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-d1t1779-19">
   <w.rf>
    <LM>w#w-d1t1779-19</LM>
   </w.rf>
   <form>dobrou</form>
   <lemma>dobrý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m125-d1t1779-20">
   <w.rf>
    <LM>w#w-d1t1779-20</LM>
   </w.rf>
   <form>rodinou</form>
   <lemma>rodina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m125-d-id162281-punct">
   <w.rf>
    <LM>w#w-d-id162281-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-22">
   <w.rf>
    <LM>w#w-d1t1779-22</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-d1t1779-23">
   <w.rf>
    <LM>w#w-d1t1779-23</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m125-d-id162321-punct">
   <w.rf>
    <LM>w#w-d-id162321-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-25">
   <w.rf>
    <LM>w#w-d1t1779-25</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-d1t1779-26">
   <w.rf>
    <LM>w#w-d1t1779-26</LM>
   </w.rf>
   <form>vnuky</form>
   <lemma>vnuk</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m125-d-id162361-punct">
   <w.rf>
    <LM>w#w-d-id162361-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-28">
   <w.rf>
    <LM>w#w-d1t1779-28</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-d1t1779-29">
   <w.rf>
    <LM>w#w-d1t1779-29</LM>
   </w.rf>
   <form>pravnuky</form>
   <lemma>pravnuk</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m125-d1t1779-30">
   <w.rf>
    <LM>w#w-d1t1779-30</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1779-31">
   <w.rf>
    <LM>w#w-d1t1779-31</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m125-d-id162432-punct">
   <w.rf>
    <LM>w#w-d-id162432-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1779-33">
   <w.rf>
    <LM>w#w-d1t1779-33</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1779-34">
   <w.rf>
    <LM>w#w-d1t1779-34</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m125-d1t1779-35">
   <w.rf>
    <LM>w#w-d1t1779-35</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m125-d1t1779-36">
   <w.rf>
    <LM>w#w-d1t1779-36</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m125-d1t1779-37">
   <w.rf>
    <LM>w#w-d1t1779-37</LM>
   </w.rf>
   <form>nadarmo</form>
   <lemma>nadarmo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-184-103">
   <w.rf>
    <LM>w#w-184-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-83">
  <m id="m125-d1t1784-1">
   <w.rf>
    <LM>w#w-d1t1784-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m125-d1t1784-2">
   <w.rf>
    <LM>w#w-d1t1784-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1784-3">
   <w.rf>
    <LM>w#w-d1t1784-3</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m125-d-id162589-punct">
   <w.rf>
    <LM>w#w-d-id162589-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1784-5">
   <w.rf>
    <LM>w#w-d1t1784-5</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m125-d1t1784-6">
   <w.rf>
    <LM>w#w-d1t1784-6</LM>
   </w.rf>
   <form>žijou</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1784-7">
   <w.rf>
    <LM>w#w-d1t1784-7</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m125-d1t1784-8">
   <w.rf>
    <LM>w#w-d1t1784-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1784-9">
   <w.rf>
    <LM>w#w-d1t1784-9</LM>
   </w.rf>
   <form>uměním</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m125-d1t1784-10">
   <w.rf>
    <LM>w#w-d1t1784-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1784-11">
   <w.rf>
    <LM>w#w-d1t1784-11</LM>
   </w.rf>
   <form>vědou</form>
   <lemma>věda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m125-d-id162707-punct">
   <w.rf>
    <LM>w#w-d-id162707-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1784-13">
   <w.rf>
    <LM>w#w-d1t1784-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1784-14">
   <w.rf>
    <LM>w#w-d1t1784-14</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1784-15">
   <w.rf>
    <LM>w#w-d1t1784-15</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m125-d1t1784-16">
   <w.rf>
    <LM>w#w-d1t1784-16</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m125-83-1056">
   <w.rf>
    <LM>w#w-83-1056</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1784-23">
   <w.rf>
    <LM>w#w-d1t1784-23</LM>
   </w.rf>
   <form>zpravidla</form>
   <lemma>zpravidla</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1784-19">
   <w.rf>
    <LM>w#w-d1t1784-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1784-20">
   <w.rf>
    <LM>w#w-d1t1784-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1t1784-21">
   <w.rf>
    <LM>w#w-d1t1784-21</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m125-d1t1784-24">
   <w.rf>
    <LM>w#w-d1t1784-24</LM>
   </w.rf>
   <form>zapomíná</form>
   <lemma>zapomínat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-83-107">
   <w.rf>
    <LM>w#w-83-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-90">
  <m id="m125-d1t1786-2">
   <w.rf>
    <LM>w#w-d1t1786-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1786-3">
   <w.rf>
    <LM>w#w-d1t1786-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1786-4">
   <w.rf>
    <LM>w#w-d1t1786-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m125-d1t1786-5">
   <w.rf>
    <LM>w#w-d1t1786-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1786-6">
   <w.rf>
    <LM>w#w-d1t1786-6</LM>
   </w.rf>
   <form>vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m125-d-id163003-punct">
   <w.rf>
    <LM>w#w-d-id163003-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1786-11">
   <w.rf>
    <LM>w#w-d1t1786-11</LM>
   </w.rf>
   <form>paměť</form>
   <lemma>paměť</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m125-d1t1786-12">
   <w.rf>
    <LM>w#w-d1t1786-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1786-14">
   <w.rf>
    <LM>w#w-d1t1786-14</LM>
   </w.rf>
   <form>rodinné</form>
   <lemma>rodinný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m125-d1t1786-15">
   <w.rf>
    <LM>w#w-d1t1786-15</LM>
   </w.rf>
   <form>tradice</form>
   <lemma>tradice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m125-d1t1786-9">
   <w.rf>
    <LM>w#w-d1t1786-9</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1786-16">
   <w.rf>
    <LM>w#w-d1t1786-16</LM>
   </w.rf>
   <form>žijou</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1786-17">
   <w.rf>
    <LM>w#w-d1t1786-17</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-90-120">
   <w.rf>
    <LM>w#w-90-120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-79">
  <m id="m125-d1t1786-21">
   <w.rf>
    <LM>w#w-d1t1786-21</LM>
   </w.rf>
   <form>Pokládám</form>
   <lemma>pokládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1786-20">
   <w.rf>
    <LM>w#w-d1t1786-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m125-d1t1786-22">
   <w.rf>
    <LM>w#w-d1t1786-22</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1t1786-23">
   <w.rf>
    <LM>w#w-d1t1786-23</LM>
   </w.rf>
   <form>nesmírně</form>
   <lemma>smírně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m125-d1t1786-24">
   <w.rf>
    <LM>w#w-d1t1786-24</LM>
   </w.rf>
   <form>kladné</form>
   <lemma>kladný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m125-d1t1786-25">
   <w.rf>
    <LM>w#w-d1t1786-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m125-79-125">
   <w.rf>
    <LM>w#w-79-125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1790-1">
   <w.rf>
    <LM>w#w-d1t1790-1</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1790-2">
   <w.rf>
    <LM>w#w-d1t1790-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m125-79-1244">
   <w.rf>
    <LM>w#w-79-1244</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1790-3">
   <w.rf>
    <LM>w#w-d1t1790-3</LM>
   </w.rf>
   <form>radostné</form>
   <lemma>radostný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m125-79-129">
   <w.rf>
    <LM>w#w-79-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-128">
  <m id="m125-d1t1790-9">
   <w.rf>
    <LM>w#w-d1t1790-9</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1790-6">
   <w.rf>
    <LM>w#w-d1t1790-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1790-7">
   <w.rf>
    <LM>w#w-d1t1790-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m125-d1t1790-8">
   <w.rf>
    <LM>w#w-d1t1790-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m125-d1t1790-10">
   <w.rf>
    <LM>w#w-d1t1790-10</LM>
   </w.rf>
   <form>plno</form>
   <lemma>plno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m125-d1t1790-11">
   <w.rf>
    <LM>w#w-d1t1790-11</LM>
   </w.rf>
   <form>starostí</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m125-d1t1790-12">
   <w.rf>
    <LM>w#w-d1t1790-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1790-13">
   <w.rf>
    <LM>w#w-d1t1790-13</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m125-d-id163518-punct">
   <w.rf>
    <LM>w#w-d-id163518-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1790-15">
   <w.rf>
    <LM>w#w-d1t1790-15</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m125-d1t1790-16">
   <w.rf>
    <LM>w#w-d1t1790-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1790-17">
   <w.rf>
    <LM>w#w-d1t1790-17</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m125-d1t1790-18">
   <w.rf>
    <LM>w#w-d1t1790-18</LM>
   </w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m125-d-id163589-punct">
   <w.rf>
    <LM>w#w-d-id163589-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1790-20">
   <w.rf>
    <LM>w#w-d1t1790-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m125-d1t1790-21">
   <w.rf>
    <LM>w#w-d1t1790-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m125-d1t1790-22">
   <w.rf>
    <LM>w#w-d1t1790-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m125-d1t1790-23">
   <w.rf>
    <LM>w#w-d1t1790-23</LM>
   </w.rf>
   <form>vším</form>
   <lemma>všechen</lemma>
   <tag>PLZS7----------</tag>
  </m>
  <m id="m125-d-m-d1e1770-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1770-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1791-x2">
  <m id="m125-d1t1794-1">
   <w.rf>
    <LM>w#w-d1t1794-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m125-d1t1794-2">
   <w.rf>
    <LM>w#w-d1t1794-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m125-d1t1794-3">
   <w.rf>
    <LM>w#w-d1t1794-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1t1794-4">
   <w.rf>
    <LM>w#w-d1t1794-4</LM>
   </w.rf>
   <form>rozhovor</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m125-d-m-d1e1791-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1791-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1795-x2">
  <m id="m125-d1t1798-1">
   <w.rf>
    <LM>w#w-d1t1798-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m125-d1t1798-2">
   <w.rf>
    <LM>w#w-d1t1798-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1798-3">
   <w.rf>
    <LM>w#w-d1t1798-3</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m125-d-id163874-punct">
   <w.rf>
    <LM>w#w-d-id163874-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m125-d1t1798-5">
   <w.rf>
    <LM>w#w-d1t1798-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m125-d1t1798-6">
   <w.rf>
    <LM>w#w-d1t1798-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m125-d1t1798-7">
   <w.rf>
    <LM>w#w-d1t1798-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m125-d1t1798-8">
   <w.rf>
    <LM>w#w-d1t1798-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m125-d1t1798-9">
   <w.rf>
    <LM>w#w-d1t1798-9</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m125-d1t1798-10">
   <w.rf>
    <LM>w#w-d1t1798-10</LM>
   </w.rf>
   <form>povídala</form>
   <lemma>povídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m125-d1e1795-x2-144">
   <w.rf>
    <LM>w#w-d1e1795-x2-144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-143">
  <m id="m125-d1t1800-1">
   <w.rf>
    <LM>w#w-d1t1800-1</LM>
   </w.rf>
   <form>Mějte</form>
   <lemma>mít</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m125-d1t1800-2">
   <w.rf>
    <LM>w#w-d1t1800-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m125-d1t1800-3">
   <w.rf>
    <LM>w#w-d1t1800-3</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m125-d-m-d1e1795-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1795-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1801-x2">
  <m id="m125-d1e1801-x2-1066">
   <w.rf>
    <LM>w#w-d1e1801-x2-1066</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1e1801-x2-1067">
   <w.rf>
    <LM>w#w-d1e1801-x2-1067</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d-m-d1e1801-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1801-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m125-d1e1805-x2">
  <m id="m125-d1e1805-x2-1068">
   <w.rf>
    <LM>w#w-d1e1805-x2-1068</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m125-d1e1805-x2-1069">
   <w.rf>
    <LM>w#w-d1e1805-x2-1069</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m125-d-m-d1e1805-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1805-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
