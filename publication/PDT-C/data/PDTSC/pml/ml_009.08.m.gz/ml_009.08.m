<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_009.08.w.gz" />
  </references>
 </head>
 <s id="m009-1366">
  <m id="m009-d1t2234-1">
   <w.rf>
    <LM>w#w-d1t2234-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2234-2">
   <w.rf>
    <LM>w#w-d1t2234-2</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2234-3">
   <w.rf>
    <LM>w#w-d1t2234-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t2234-4">
   <w.rf>
    <LM>w#w-d1t2234-4</LM>
   </w.rf>
   <form>ubývaly</form>
   <lemma>ubývat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m009-d1t2234-5">
   <w.rf>
    <LM>w#w-d1t2234-5</LM>
   </w.rf>
   <form>síly</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m009-d-id138170">
   <w.rf>
    <LM>w#w-d-id138170</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2234-7">
   <w.rf>
    <LM>w#w-d1t2234-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2234-8">
   <w.rf>
    <LM>w#w-d1t2234-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2234-9">
   <w.rf>
    <LM>w#w-d1t2234-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2234-10">
   <w.rf>
    <LM>w#w-d1t2234-10</LM>
   </w.rf>
   <form>nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2234-11">
   <w.rf>
    <LM>w#w-d1t2234-11</LM>
   </w.rf>
   <form>kamarádovi</form>
   <lemma>kamarád</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m009-1488-66">
   <w.rf>
    <LM>w#w-1488-66</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-68">
  <m id="m009-d1t2234-14">
   <w.rf>
    <LM>w#w-d1t2234-14</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2234-15">
   <w.rf>
    <LM>w#w-d1t2234-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2234-16">
   <w.rf>
    <LM>w#w-d1t2234-16</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m009-d1t2234-17">
   <w.rf>
    <LM>w#w-d1t2234-17</LM>
   </w.rf>
   <form>devět</form>
   <lemma>devět`9</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2234-19">
   <w.rf>
    <LM>w#w-d1t2234-19</LM>
   </w.rf>
   <form>úlů</form>
   <lemma>úl</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m009-d1t2234-20">
   <w.rf>
    <LM>w#w-d1t2234-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2234-21">
   <w.rf>
    <LM>w#w-d1t2234-21</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2234-22">
   <w.rf>
    <LM>w#w-d1t2234-22</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2234-23">
   <w.rf>
    <LM>w#w-d1t2234-23</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m009-1488-1587">
   <w.rf>
    <LM>w#w-1488-1587</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-1488-1588">
   <w.rf>
    <LM>w#w-1488-1588</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2234-24">
   <w.rf>
    <LM>w#w-d1t2234-24</LM>
   </w.rf>
   <form>Dej</form>
   <lemma>dát-1</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m009-d1t2234-25">
   <w.rf>
    <LM>w#w-d1t2234-25</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t2234-26">
   <w.rf>
    <LM>w#w-d1t2234-26</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2234-29">
   <w.rf>
    <LM>w#w-d1t2234-29</LM>
   </w.rf>
   <form>pivo</form>
   <lemma>pivo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m009-d-id137749">
   <w.rf>
    <LM>w#w-d-id137749</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-1488-1684">
   <w.rf>
    <LM>w#w-1488-1684</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2235-x2">
  <m id="m009-d1t2240-1">
   <w.rf>
    <LM>w#w-d1t2240-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2240-2">
   <w.rf>
    <LM>w#w-d1t2240-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2240-3">
   <w.rf>
    <LM>w#w-d1t2240-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m009-d1t2240-4">
   <w.rf>
    <LM>w#w-d1t2240-4</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2240-5">
   <w.rf>
    <LM>w#w-d1t2240-5</LM>
   </w.rf>
   <form>devět</form>
   <lemma>devět`9</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2240-6">
   <w.rf>
    <LM>w#w-d1t2240-6</LM>
   </w.rf>
   <form>úlů</form>
   <lemma>úl</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m009-d1t2240-7">
   <w.rf>
    <LM>w#w-d1t2240-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m009-d1t2240-8">
   <w.rf>
    <LM>w#w-d1t2240-8</LM>
   </w.rf>
   <form>včelami</form>
   <lemma>včela</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m009-d-id138550">
   <w.rf>
    <LM>w#w-d-id138550</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2235-x3">
  <m id="m009-d1t2242-1">
   <w.rf>
    <LM>w#w-d1t2242-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t2242-2">
   <w.rf>
    <LM>w#w-d1t2242-2</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m009-d1t2242-3">
   <w.rf>
    <LM>w#w-d1t2242-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2242-4">
   <w.rf>
    <LM>w#w-d1t2242-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2242-5">
   <w.rf>
    <LM>w#w-d1t2242-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2242-6">
   <w.rf>
    <LM>w#w-d1t2242-6</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id138744">
   <w.rf>
    <LM>w#w-d-id138744</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2244-x2">
  <m id="m009-d1t2247-1">
   <w.rf>
    <LM>w#w-d1t2247-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id138822">
   <w.rf>
    <LM>w#w-d-id138822</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-1874">
  <m id="m009-d1t2247-3">
   <w.rf>
    <LM>w#w-d1t2247-3</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2247-4">
   <w.rf>
    <LM>w#w-d1t2247-4</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id138791">
   <w.rf>
    <LM>w#w-d-id138791</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2248-x2">
  <m id="m009-d1t2251-1">
   <w.rf>
    <LM>w#w-d1t2251-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t2251-2">
   <w.rf>
    <LM>w#w-d1t2251-2</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m009-d1t2251-3">
   <w.rf>
    <LM>w#w-d1t2251-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2251-4">
   <w.rf>
    <LM>w#w-d1t2251-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2251-5">
   <w.rf>
    <LM>w#w-d1t2251-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2251-6">
   <w.rf>
    <LM>w#w-d1t2251-6</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id138899">
   <w.rf>
    <LM>w#w-d-id138899</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2252-x2">
  <m id="m009-d1t2255-1">
   <w.rf>
    <LM>w#w-d1t2255-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2255-2">
   <w.rf>
    <LM>w#w-d1t2255-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t2255-3">
   <w.rf>
    <LM>w#w-d1t2255-3</LM>
   </w.rf>
   <form>nerozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m009-d1e2252-x2-1934">
   <w.rf>
    <LM>w#w-d1e2252-x2-1934</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-1935">
  <m id="m009-d1t2257-4">
   <w.rf>
    <LM>w#w-d1t2257-4</LM>
   </w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m009-d1t2257-5">
   <w.rf>
    <LM>w#w-d1t2257-5</LM>
   </w.rf>
   <form>včelami</form>
   <lemma>včela</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m009-d1t2257-6">
   <w.rf>
    <LM>w#w-d1t2257-6</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m009-d1t2257-1">
   <w.rf>
    <LM>w#w-d1t2257-1</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2257-2">
   <w.rf>
    <LM>w#w-d1t2257-2</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-1935-1975">
   <w.rf>
    <LM>w#w-1935-1975</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2257-8">
   <w.rf>
    <LM>w#w-d1t2257-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m009-d1t2257-9">
   <w.rf>
    <LM>w#w-d1t2257-9</LM>
   </w.rf>
   <form>včelami</form>
   <lemma>včela</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m009-d1t2257-10">
   <w.rf>
    <LM>w#w-d1t2257-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2257-11">
   <w.rf>
    <LM>w#w-d1t2257-11</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2257-12">
   <w.rf>
    <LM>w#w-d1t2257-12</LM>
   </w.rf>
   <form>zábavy</form>
   <lemma>zábava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id139045">
   <w.rf>
    <LM>w#w-d-id139045</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2258-x2">
  <m id="m009-d1t2263-1">
   <w.rf>
    <LM>w#w-d1t2263-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2263-2">
   <w.rf>
    <LM>w#w-d1t2263-2</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2263-3">
   <w.rf>
    <LM>w#w-d1t2263-3</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d1t2263-4">
   <w.rf>
    <LM>w#w-d1t2263-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2263-5">
   <w.rf>
    <LM>w#w-d1t2263-5</LM>
   </w.rf>
   <form>koníčka</form>
   <lemma>koníček-2</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m009-d-id139338">
   <w.rf>
    <LM>w#w-d-id139338</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2268-x2">
  <m id="m009-d1t2271-2">
   <w.rf>
    <LM>w#w-d1t2271-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2271-4">
   <w.rf>
    <LM>w#w-d1t2271-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2271-5">
   <w.rf>
    <LM>w#w-d1t2271-5</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m009-d1t2271-3">
   <w.rf>
    <LM>w#w-d1t2271-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2271-6">
   <w.rf>
    <LM>w#w-d1t2271-6</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d-id139588">
   <w.rf>
    <LM>w#w-d-id139588</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2271-8">
   <w.rf>
    <LM>w#w-d1t2271-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2271-9">
   <w.rf>
    <LM>w#w-d1t2271-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t2271-10">
   <w.rf>
    <LM>w#w-d1t2271-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2271-11">
   <w.rf>
    <LM>w#w-d1t2271-11</LM>
   </w.rf>
   <form>vede</form>
   <lemma>vést</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d-id139487">
   <w.rf>
    <LM>w#w-d-id139487</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2272-x2">
  <m id="m009-d1t2275-1">
   <w.rf>
    <LM>w#w-d1t2275-1</LM>
   </w.rf>
   <form>Pobodaly</form>
   <lemma>pobodat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m009-d1t2275-2">
   <w.rf>
    <LM>w#w-d1t2275-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m009-d1t2275-3">
   <w.rf>
    <LM>w#w-d1t2275-3</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id139752">
   <w.rf>
    <LM>w#w-d-id139752</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2276-x2">
  <m id="m009-d1t2279-3">
   <w.rf>
    <LM>w#w-d1t2279-3</LM>
   </w.rf>
   <form>Pobodají</form>
   <lemma>pobodat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m009-d1e2276-x2-2119">
   <w.rf>
    <LM>w#w-d1e2276-x2-2119</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2279-4">
   <w.rf>
    <LM>w#w-d1t2279-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2279-5">
   <w.rf>
    <LM>w#w-d1t2279-5</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m009-d1t2279-6">
   <w.rf>
    <LM>w#w-d1t2279-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2279-7">
   <w.rf>
    <LM>w#w-d1t2279-7</LM>
   </w.rf>
   <form>nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m009-d1e2276-x2-2120">
   <w.rf>
    <LM>w#w-d1e2276-x2-2120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-2121">
  <m id="m009-d1t2279-8">
   <w.rf>
    <LM>w#w-d1t2279-8</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2279-9">
   <w.rf>
    <LM>w#w-d1t2279-9</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2279-10">
   <w.rf>
    <LM>w#w-d1t2279-10</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2281-1">
   <w.rf>
    <LM>w#w-d1t2281-1</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2281-2">
   <w.rf>
    <LM>w#w-d1t2281-2</LM>
   </w.rf>
   <form>žihadel</form>
   <lemma>žihadlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m009-d1t2281-3">
   <w.rf>
    <LM>w#w-d1t2281-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2281-4">
   <w.rf>
    <LM>w#w-d1t2281-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2281-5">
   <w.rf>
    <LM>w#w-d1t2281-5</LM>
   </w.rf>
   <form>neuteču</form>
   <lemma>utéci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m009-2121-2132">
   <w.rf>
    <LM>w#w-2121-2132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2283-1">
   <w.rf>
    <LM>w#w-d1t2283-1</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m009-d1t2283-2">
   <w.rf>
    <LM>w#w-d1t2283-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2283-3">
   <w.rf>
    <LM>w#w-d1t2283-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2283-4">
   <w.rf>
    <LM>w#w-d1t2283-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m009-d1t2283-5">
   <w.rf>
    <LM>w#w-d1t2283-5</LM>
   </w.rf>
   <form>nedělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m009-2121-2134">
   <w.rf>
    <LM>w#w-2121-2134</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2283-6">
   <w.rf>
    <LM>w#w-d1t2283-6</LM>
   </w.rf>
   <form>včelařím</form>
   <lemma>včelařit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2283-7">
   <w.rf>
    <LM>w#w-d1t2283-7</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léta</lemma>
   <tag>NNNP4-----A---2</tag>
  </m>
  <m id="m009-2121-2136">
   <w.rf>
    <LM>w#w-2121-2136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-2137">
  <m id="m009-d1t2283-9">
   <w.rf>
    <LM>w#w-d1t2283-9</LM>
   </w.rf>
   <form>Padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m009-d1t2283-10">
   <w.rf>
    <LM>w#w-d1t2283-10</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m009-d1t2283-11">
   <w.rf>
    <LM>w#w-d1t2283-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2283-12">
   <w.rf>
    <LM>w#w-d1t2283-12</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2283-13">
   <w.rf>
    <LM>w#w-d1t2283-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2283-14">
   <w.rf>
    <LM>w#w-d1t2283-14</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m009-d1t2283-15">
   <w.rf>
    <LM>w#w-d1t2283-15</LM>
   </w.rf>
   <form>kuklu</form>
   <lemma>kukla</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d1t2283-16">
   <w.rf>
    <LM>w#w-d1t2283-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2283-17">
   <w.rf>
    <LM>w#w-d1t2283-17</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m009-d-id140274">
   <w.rf>
    <LM>w#w-d-id140274</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2283-19">
   <w.rf>
    <LM>w#w-d1t2283-19</LM>
   </w.rf>
   <form>dělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2283-20">
   <w.rf>
    <LM>w#w-d1t2283-20</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2283-21">
   <w.rf>
    <LM>w#w-d1t2283-21</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2283-22">
   <w.rf>
    <LM>w#w-d1t2283-22</LM>
   </w.rf>
   <form>kukly</form>
   <lemma>kukla</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id139798">
   <w.rf>
    <LM>w#w-d-id139798</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2284-x2">
  <m id="m009-d1t2289-1">
   <w.rf>
    <LM>w#w-d1t2289-1</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2289-2">
   <w.rf>
    <LM>w#w-d1t2289-2</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id140426">
   <w.rf>
    <LM>w#w-d-id140426</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2289-4">
   <w.rf>
    <LM>w#w-d1t2289-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2289-5">
   <w.rf>
    <LM>w#w-d1t2289-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2289-6">
   <w.rf>
    <LM>w#w-d1t2289-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2289-7">
   <w.rf>
    <LM>w#w-d1t2289-7</LM>
   </w.rf>
   <form>bouřkovo</form>
   <lemma>bouřkovo-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id140490">
   <w.rf>
    <LM>w#w-d-id140490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2297-1">
   <w.rf>
    <LM>w#w-d1t2297-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2297-4">
   <w.rf>
    <LM>w#w-d1t2297-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2297-3">
   <w.rf>
    <LM>w#w-d1t2297-3</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m009-d1t2297-5">
   <w.rf>
    <LM>w#w-d1t2297-5</LM>
   </w.rf>
   <form>zlé</form>
   <lemma>zlý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m009-d-id140641">
   <w.rf>
    <LM>w#w-d-id140641</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2297-7">
   <w.rf>
    <LM>w#w-d1t2297-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2299-1">
   <w.rf>
    <LM>w#w-d1t2299-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2299-3">
   <w.rf>
    <LM>w#w-d1t2299-3</LM>
   </w.rf>
   <form>kuklu</form>
   <lemma>kukla</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d1t2299-2">
   <w.rf>
    <LM>w#w-d1t2299-2</LM>
   </w.rf>
   <form>vezmu</form>
   <lemma>vzít</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m009-d1e2284-x2-2358">
   <w.rf>
    <LM>w#w-d1e2284-x2-2358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-2334">
  <m id="m009-d1t2299-5">
   <w.rf>
    <LM>w#w-d1t2299-5</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2299-6">
   <w.rf>
    <LM>w#w-d1t2299-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m009-d1t2299-8">
   <w.rf>
    <LM>w#w-d1t2299-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2299-9">
   <w.rf>
    <LM>w#w-d1t2299-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2299-10">
   <w.rf>
    <LM>w#w-d1t2299-10</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m009-d1t2299-11">
   <w.rf>
    <LM>w#w-d1t2299-11</LM>
   </w.rf>
   <form>vzal</form>
   <lemma>vzít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d-id140826">
   <w.rf>
    <LM>w#w-d-id140826</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2299-12">
   <w.rf>
    <LM>w#w-d1t2299-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2299-14">
   <w.rf>
    <LM>w#w-d1t2299-14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2299-15">
   <w.rf>
    <LM>w#w-d1t2299-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2299-16">
   <w.rf>
    <LM>w#w-d1t2299-16</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2299-17">
   <w.rf>
    <LM>w#w-d1t2299-17</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d-id140884">
   <w.rf>
    <LM>w#w-d-id140884</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2301-1">
   <w.rf>
    <LM>w#w-d1t2301-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2301-2">
   <w.rf>
    <LM>w#w-d1t2301-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2301-3">
   <w.rf>
    <LM>w#w-d1t2301-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t2301-4">
   <w.rf>
    <LM>w#w-d1t2301-4</LM>
   </w.rf>
   <form>bál</form>
   <lemma>bát-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d-id140963">
   <w.rf>
    <LM>w#w-d-id140963</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2301-6">
   <w.rf>
    <LM>w#w-d1t2301-6</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m009-d1t2301-7">
   <w.rf>
    <LM>w#w-d1t2301-7</LM>
   </w.rf>
   <form>nedostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m009-d1t2301-8">
   <w.rf>
    <LM>w#w-d1t2301-8</LM>
   </w.rf>
   <form>žihadlo</form>
   <lemma>žihadlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m009-d1t2301-9">
   <w.rf>
    <LM>w#w-d1t2301-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2301-10">
   <w.rf>
    <LM>w#w-d1t2301-10</LM>
   </w.rf>
   <form>nátisku</form>
   <lemma>nátisk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m009-d-id141050">
   <w.rf>
    <LM>w#w-d-id141050</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2305-1">
   <w.rf>
    <LM>w#w-d1t2305-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2305-2">
   <w.rf>
    <LM>w#w-d1t2305-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t2305-3">
   <w.rf>
    <LM>w#w-d1t2305-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2305-5">
   <w.rf>
    <LM>w#w-d1t2305-5</LM>
   </w.rf>
   <form>neoteklo</form>
   <lemma>otéci</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m009-d1e2294-x2-2314">
   <w.rf>
    <LM>w#w-d1e2294-x2-2314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-2315">
  <m id="m009-d1t2305-7">
   <w.rf>
    <LM>w#w-d1t2305-7</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2305-8">
   <w.rf>
    <LM>w#w-d1t2305-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2305-9">
   <w.rf>
    <LM>w#w-d1t2305-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2305-10">
   <w.rf>
    <LM>w#w-d1t2305-10</LM>
   </w.rf>
   <form>kuklu</form>
   <lemma>kukla</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d1t2305-11">
   <w.rf>
    <LM>w#w-d1t2305-11</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2305-12">
   <w.rf>
    <LM>w#w-d1t2305-12</LM>
   </w.rf>
   <form>nebral</form>
   <lemma>brát</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m009-d-id141242">
   <w.rf>
    <LM>w#w-d-id141242</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2305-14">
   <w.rf>
    <LM>w#w-d1t2305-14</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2305-15">
   <w.rf>
    <LM>w#w-d1t2305-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2305-16">
   <w.rf>
    <LM>w#w-d1t2305-16</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m009-d1t2305-17">
   <w.rf>
    <LM>w#w-d1t2305-17</LM>
   </w.rf>
   <form>včelách</form>
   <lemma>včela</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m009-d1t2305-18">
   <w.rf>
    <LM>w#w-d1t2305-18</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2305-19">
   <w.rf>
    <LM>w#w-d1t2305-19</LM>
   </w.rf>
   <form>kukly</form>
   <lemma>kukla</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-2315-2324">
   <w.rf>
    <LM>w#w-2315-2324</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-2325">
  <m id="m009-d1t2308-7">
   <w.rf>
    <LM>w#w-d1t2308-7</LM>
   </w.rf>
   <form>Včelařina</form>
   <lemma>včelařina_,h</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d1t2308-2">
   <w.rf>
    <LM>w#w-d1t2308-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m009-d1t2308-4">
   <w.rf>
    <LM>w#w-d1t2308-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m009-d1t2308-5">
   <w.rf>
    <LM>w#w-d1t2308-5</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m009-d1t2308-6">
   <w.rf>
    <LM>w#w-d1t2308-6</LM>
   </w.rf>
   <form>láska</form>
   <lemma>láska</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d1t2308-8">
   <w.rf>
    <LM>w#w-d1t2308-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2308-9">
   <w.rf>
    <LM>w#w-d1t2308-9</LM>
   </w.rf>
   <form>vyrobil</form>
   <lemma>vyrobit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2308-10">
   <w.rf>
    <LM>w#w-d1t2308-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2308-11">
   <w.rf>
    <LM>w#w-d1t2308-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2308-12">
   <w.rf>
    <LM>w#w-d1t2308-12</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2308-13">
   <w.rf>
    <LM>w#w-d1t2308-13</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-2325-2492">
   <w.rf>
    <LM>w#w-2325-2492</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2308-14">
   <w.rf>
    <LM>w#w-d1t2308-14</LM>
   </w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2308-15">
   <w.rf>
    <LM>w#w-d1t2308-15</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2308-16">
   <w.rf>
    <LM>w#w-d1t2308-16</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2308-17">
   <w.rf>
    <LM>w#w-d1t2308-17</LM>
   </w.rf>
   <form>metráků</form>
   <lemma>metrák</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m009-d1t2308-18">
   <w.rf>
    <LM>w#w-d1t2308-18</LM>
   </w.rf>
   <form>medu</form>
   <lemma>med</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m009-2325-2495">
   <w.rf>
    <LM>w#w-2325-2495</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-1393">
  <m id="m009-d1t2310-1">
   <w.rf>
    <LM>w#w-d1t2310-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2310-2">
   <w.rf>
    <LM>w#w-d1t2310-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2310-5">
   <w.rf>
    <LM>w#w-d1t2310-5</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t2310-4">
   <w.rf>
    <LM>w#w-d1t2310-4</LM>
   </w.rf>
   <form>medu</form>
   <lemma>med</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m009-d-id141612_2">
   <w.rf>
    <LM>w#w-d-id141612_2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2317-x2">
  <m id="m009-d1t2320-1">
   <w.rf>
    <LM>w#w-d1t2320-1</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2320-4">
   <w.rf>
    <LM>w#w-d1t2320-4</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t2320-2">
   <w.rf>
    <LM>w#w-d1t2320-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m009-d1t2320-3">
   <w.rf>
    <LM>w#w-d1t2320-3</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d-id141816">
   <w.rf>
    <LM>w#w-d-id141816</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2321-x2">
  <m id="m009-d1t2326-5">
   <w.rf>
    <LM>w#w-d1t2326-5</LM>
   </w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2326-3">
   <w.rf>
    <LM>w#w-d1t2326-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2326-4">
   <w.rf>
    <LM>w#w-d1t2326-4</LM>
   </w.rf>
   <form>podzim</form>
   <lemma>podzim</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d1t2330-3">
   <w.rf>
    <LM>w#w-d1t2330-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2330-4">
   <w.rf>
    <LM>w#w-d1t2330-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2330-2">
   <w.rf>
    <LM>w#w-d1t2330-2</LM>
   </w.rf>
   <form>nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2330-5">
   <w.rf>
    <LM>w#w-d1t2330-5</LM>
   </w.rf>
   <form>devatery</form>
   <lemma>devaterý`9</lemma>
   <tag>CdFP4----------</tag>
  </m>
  <m id="m009-d1t2332-1">
   <w.rf>
    <LM>w#w-d1t2332-1</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d1e2321-x2-129">
   <w.rf>
    <LM>w#w-d1e2321-x2-129</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2332-2">
   <w.rf>
    <LM>w#w-d1t2332-2</LM>
   </w.rf>
   <form>standardní</form>
   <lemma>standardní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m009-d1t2332-3">
   <w.rf>
    <LM>w#w-d1t2332-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1e2321-x2-30">
   <w.rf>
    <LM>w#w-d1e2321-x2-30</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1e2321-x2-29">
   <w.rf>
    <LM>w#w-d1e2321-x2-29</LM>
   </w.rf>
   <form>dlouhodělečky</form>
   <lemma>dlouhodělečka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d1e2321-x2-31">
   <w.rf>
    <LM>w#w-d1e2321-x2-31</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d-id142354">
   <w.rf>
    <LM>w#w-d-id142354</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2335-2">
   <w.rf>
    <LM>w#w-d1t2335-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2335-3">
   <w.rf>
    <LM>w#w-d1t2335-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2335-5">
   <w.rf>
    <LM>w#w-d1t2335-5</LM>
   </w.rf>
   <form>záložní</form>
   <lemma>záložní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m009-d1t2335-6">
   <w.rf>
    <LM>w#w-d1t2335-6</LM>
   </w.rf>
   <form>včelstva</form>
   <lemma>včelstvo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m009-d1e2321-x2-128">
   <w.rf>
    <LM>w#w-d1e2321-x2-128</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1e2321-x2-32">
   <w.rf>
    <LM>w#w-d1e2321-x2-32</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-33">
  <m id="m009-d1t2339-2">
   <w.rf>
    <LM>w#w-d1t2339-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2339-3">
   <w.rf>
    <LM>w#w-d1t2339-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m009-d1t2339-4">
   <w.rf>
    <LM>w#w-d1t2339-4</LM>
   </w.rf>
   <form>devatera</form>
   <lemma>devatero`9</lemma>
   <tag>CjNS2----------</tag>
  </m>
  <m id="m009-d1t2339-5">
   <w.rf>
    <LM>w#w-d1t2339-5</LM>
   </w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m009-d1t2339-6">
   <w.rf>
    <LM>w#w-d1t2339-6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t2339-7">
   <w.rf>
    <LM>w#w-d1t2339-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2341-1">
   <w.rf>
    <LM>w#w-d1t2341-1</LM>
   </w.rf>
   <form>troje</form>
   <lemma>trojí</lemma>
   <tag>CdXP1---------1</tag>
  </m>
  <m id="m009-d1t2341-2">
   <w.rf>
    <LM>w#w-d1t2341-2</LM>
   </w.rf>
   <form>uhynuly</form>
   <lemma>uhynout</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m009-d-id142606">
   <w.rf>
    <LM>w#w-d-id142606</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2341-4">
   <w.rf>
    <LM>w#w-d1t2341-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2341-5">
   <w.rf>
    <LM>w#w-d1t2341-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2341-7">
   <w.rf>
    <LM>w#w-d1t2341-7</LM>
   </w.rf>
   <form>Plzeňském</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m009-d1t2341-9">
   <w.rf>
    <LM>w#w-d1t2341-9</LM>
   </w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m009-d1e2321-x2-136">
   <w.rf>
    <LM>w#w-d1e2321-x2-136</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2343-1">
   <w.rf>
    <LM>w#w-d1t2343-1</LM>
   </w.rf>
   <form>nemoc</form>
   <lemma>nemoc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d1t2343-2">
   <w.rf>
    <LM>w#w-d1t2343-2</LM>
   </w.rf>
   <form>včel</form>
   <lemma>včela</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m009-d1e2321-x2-137">
   <w.rf>
    <LM>w#w-d1e2321-x2-137</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-138">
  <m id="m009-d1t2343-5">
   <w.rf>
    <LM>w#w-d1t2343-5</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m009-d1t2343-6">
   <w.rf>
    <LM>w#w-d1t2343-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2343-7">
   <w.rf>
    <LM>w#w-d1t2343-7</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m009-d1t2343-8">
   <w.rf>
    <LM>w#w-d1t2343-8</LM>
   </w.rf>
   <form>nemoc</form>
   <lemma>nemoc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d-id142821">
   <w.rf>
    <LM>w#w-d-id142821</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2343-13">
   <w.rf>
    <LM>w#w-d1t2343-13</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m009-d1t2343-14">
   <w.rf>
    <LM>w#w-d1t2343-14</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2343-15">
   <w.rf>
    <LM>w#w-d1t2343-15</LM>
   </w.rf>
   <form>zdravé</form>
   <lemma>zdravý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m009-d-id142902">
   <w.rf>
    <LM>w#w-d-id142902</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2343-17">
   <w.rf>
    <LM>w#w-d1t2343-17</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2345-1">
   <w.rf>
    <LM>w#w-d1t2345-1</LM>
   </w.rf>
   <form>napadá</form>
   <lemma>napadat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2345-2">
   <w.rf>
    <LM>w#w-d1t2345-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m009-d1t2345-3">
   <w.rf>
    <LM>w#w-d1t2345-3</LM>
   </w.rf>
   <form>cizopasník</form>
   <lemma>cizopasník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m009-138-278">
   <w.rf>
    <LM>w#w-138-278</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-262_2">
  <m id="m009-d1t2345-8">
   <w.rf>
    <LM>w#w-d1t2345-8</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2345-9">
   <w.rf>
    <LM>w#w-d1t2345-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2345-5">
   <w.rf>
    <LM>w#w-d1t2345-5</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2345-6">
   <w.rf>
    <LM>w#w-d1t2345-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2345-7">
   <w.rf>
    <LM>w#w-d1t2345-7</LM>
   </w.rf>
   <form>klíště</form>
   <lemma>klíště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m009-262_2-283">
   <w.rf>
    <LM>w#w-262_2-283</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2345-10">
   <w.rf>
    <LM>w#w-d1t2345-10</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m009-d1t2345-11">
   <w.rf>
    <LM>w#w-d1t2345-11</LM>
   </w.rf>
   <form>brouček</form>
   <lemma>brouček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m009-d1t2345-12">
   <w.rf>
    <LM>w#w-d1t2345-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2348-1">
   <w.rf>
    <LM>w#w-d1t2348-1</LM>
   </w.rf>
   <form>špendlíková</form>
   <lemma>špendlíkový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m009-d1t2348-2">
   <w.rf>
    <LM>w#w-d1t2348-2</LM>
   </w.rf>
   <form>hlavička</form>
   <lemma>hlavička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-262_2-44">
   <w.rf>
    <LM>w#w-262_2-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-45">
  <m id="m009-d1t2350-1">
   <w.rf>
    <LM>w#w-d1t2350-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m009-d1t2350-2">
   <w.rf>
    <LM>w#w-d1t2350-2</LM>
   </w.rf>
   <form>napadá</form>
   <lemma>napadat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2350-3">
   <w.rf>
    <LM>w#w-d1t2350-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m009-d1t2350-4">
   <w.rf>
    <LM>w#w-d1t2350-4</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d1t2350-5">
   <w.rf>
    <LM>w#w-d1t2350-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2350-9">
   <w.rf>
    <LM>w#w-d1t2350-9</LM>
   </w.rf>
   <form>umoří</form>
   <lemma>umořit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m009-262_2-285">
   <w.rf>
    <LM>w#w-262_2-285</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m009-d-id142926">
   <w.rf>
    <LM>w#w-d-id142926</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2353-x2">
  <m id="m009-d1t2358-1">
   <w.rf>
    <LM>w#w-d1t2358-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2358-2">
   <w.rf>
    <LM>w#w-d1t2358-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2358-3">
   <w.rf>
    <LM>w#w-d1t2358-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2358-4">
   <w.rf>
    <LM>w#w-d1t2358-4</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2358-5">
   <w.rf>
    <LM>w#w-d1t2358-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1e2353-x2-301">
   <w.rf>
    <LM>w#w-d1e2353-x2-301</LM>
   </w.rf>
   <form>troje</form>
   <lemma>trojí</lemma>
   <tag>CdXP4---------1</tag>
  </m>
  <m id="m009-d-id143390">
   <w.rf>
    <LM>w#w-d-id143390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2353-x3">
  <m id="m009-d1t2362-1">
   <w.rf>
    <LM>w#w-d1t2362-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2362-2">
   <w.rf>
    <LM>w#w-d1t2362-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2362-3">
   <w.rf>
    <LM>w#w-d1t2362-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2362-4">
   <w.rf>
    <LM>w#w-d1t2362-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m009-d1t2362-5">
   <w.rf>
    <LM>w#w-d1t2362-5</LM>
   </w.rf>
   <form>lék</form>
   <lemma>lék</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m009-d-id143564">
   <w.rf>
    <LM>w#w-d-id143564</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2363-x2">
  <m id="m009-d1t2366-1">
   <w.rf>
    <LM>w#w-d1t2366-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id143611">
   <w.rf>
    <LM>w#w-d-id143611</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2367-x3">
  <m id="m009-d1t2374-1">
   <w.rf>
    <LM>w#w-d1t2374-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2374-2">
   <w.rf>
    <LM>w#w-d1t2374-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2374-3">
   <w.rf>
    <LM>w#w-d1t2374-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2374-4">
   <w.rf>
    <LM>w#w-d1t2374-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m009-d1t2374-5">
   <w.rf>
    <LM>w#w-d1t2374-5</LM>
   </w.rf>
   <form>lék</form>
   <lemma>lék</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m009-d-id143808">
   <w.rf>
    <LM>w#w-d-id143808</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2375-x2">
  <m id="m009-d1t2378-1">
   <w.rf>
    <LM>w#w-d1t2378-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2378-2">
   <w.rf>
    <LM>w#w-d1t2378-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t2378-3">
   <w.rf>
    <LM>w#w-d1t2378-3</LM>
   </w.rf>
   <form>nerozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m009-d1e2375-x2-420">
   <w.rf>
    <LM>w#w-d1e2375-x2-420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-421">
  <m id="m009-d1t2380-1">
   <w.rf>
    <LM>w#w-d1t2380-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2380-3">
   <w.rf>
    <LM>w#w-d1t2380-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2380-4">
   <w.rf>
    <LM>w#w-d1t2380-4</LM>
   </w.rf>
   <form>jara</form>
   <lemma>jaro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m009-d1t2380-2">
   <w.rf>
    <LM>w#w-d1t2380-2</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m009-d1t2380-5">
   <w.rf>
    <LM>w#w-d1t2380-5</LM>
   </w.rf>
   <form>čekat</form>
   <lemma>čekat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d-id143992">
   <w.rf>
    <LM>w#w-d-id143992</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2380-7">
   <w.rf>
    <LM>w#w-d1t2380-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2380-8">
   <w.rf>
    <LM>w#w-d1t2380-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2380-9">
   <w.rf>
    <LM>w#w-d1t2380-9</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m009-d1t2380-10">
   <w.rf>
    <LM>w#w-d1t2380-10</LM>
   </w.rf>
   <form>lítat</form>
   <lemma>lítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-421-488">
   <w.rf>
    <LM>w#w-421-488</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-489">
  <m id="m009-d1t2380-13">
   <w.rf>
    <LM>w#w-d1t2380-13</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2380-14">
   <w.rf>
    <LM>w#w-d1t2380-14</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d-id144097">
   <w.rf>
    <LM>w#w-d-id144097</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2380-16">
   <w.rf>
    <LM>w#w-d1t2380-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2380-17">
   <w.rf>
    <LM>w#w-d1t2380-17</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2380-18">
   <w.rf>
    <LM>w#w-d1t2380-18</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-489-57">
   <w.rf>
    <LM>w#w-489-57</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m009-489-58">
   <w.rf>
    <LM>w#w-489-58</LM>
   </w.rf>
   <form>oddělky</form>
   <lemma>oddělek_^(umělý_včelí_roj;;část_trsu)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m009-d1t2382-1">
   <w.rf>
    <LM>w#w-d1t2382-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2382-2">
   <w.rf>
    <LM>w#w-d1t2382-2</LM>
   </w.rf>
   <form>šestery</form>
   <lemma>šesterý`6_^(*3)</lemma>
   <tag>CdFP4----------</tag>
  </m>
  <m id="m009-d1t2382-3">
   <w.rf>
    <LM>w#w-d1t2382-3</LM>
   </w.rf>
   <form>včely</form>
   <lemma>včela</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-d-id144201">
   <w.rf>
    <LM>w#w-d-id144201</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2382-5">
   <w.rf>
    <LM>w#w-d1t2382-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2382-6">
   <w.rf>
    <LM>w#w-d1t2382-6</LM>
   </w.rf>
   <form>uvidím</form>
   <lemma>uvidět</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m009-d-id144241">
   <w.rf>
    <LM>w#w-d-id144241</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2382-8">
   <w.rf>
    <LM>w#w-d1t2382-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2384-2">
   <w.rf>
    <LM>w#w-d1t2384-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2384-5">
   <w.rf>
    <LM>w#w-d1t2384-5</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m009-d1t2384-3">
   <w.rf>
    <LM>w#w-d1t2384-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2384-4">
   <w.rf>
    <LM>w#w-d1t2384-4</LM>
   </w.rf>
   <form>jara</form>
   <lemma>jaro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m009-d1t2384-6">
   <w.rf>
    <LM>w#w-d1t2384-6</LM>
   </w.rf>
   <form>vypadat</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d-id143855">
   <w.rf>
    <LM>w#w-d-id143855</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2397-x3">
  <m id="m009-d1t2404-1">
   <w.rf>
    <LM>w#w-d1t2404-1</LM>
   </w.rf>
   <form>Prodával</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2404-2">
   <w.rf>
    <LM>w#w-d1t2404-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t2404-3">
   <w.rf>
    <LM>w#w-d1t2404-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2404-4">
   <w.rf>
    <LM>w#w-d1t2404-4</LM>
   </w.rf>
   <form>med</form>
   <lemma>med</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d-id144645">
   <w.rf>
    <LM>w#w-d-id144645</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2405-x2">
  <m id="m009-d1t2408-4">
   <w.rf>
    <LM>w#w-d1t2408-4</LM>
   </w.rf>
   <form>Prodával</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2408-5">
   <w.rf>
    <LM>w#w-d1t2408-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2408-6">
   <w.rf>
    <LM>w#w-d1t2408-6</LM>
   </w.rf>
   <form>med</form>
   <lemma>med</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d1t2410-1">
   <w.rf>
    <LM>w#w-d1t2410-1</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léto</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m009-d-id144818">
   <w.rf>
    <LM>w#w-d-id144818</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2410-3">
   <w.rf>
    <LM>w#w-d1t2410-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2410-4">
   <w.rf>
    <LM>w#w-d1t2410-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2410-5">
   <w.rf>
    <LM>w#w-d1t2410-5</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m009-d1t2410-6">
   <w.rf>
    <LM>w#w-d1t2410-6</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2410-7">
   <w.rf>
    <LM>w#w-d1t2410-7</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2410-8">
   <w.rf>
    <LM>w#w-d1t2410-8</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1t2410-9">
   <w.rf>
    <LM>w#w-d1t2410-9</LM>
   </w.rf>
   <form>metráků</form>
   <lemma>metrák</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m009-d1e2405-x2-659">
   <w.rf>
    <LM>w#w-d1e2405-x2-659</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-660">
  <m id="m009-d1t2410-12">
   <w.rf>
    <LM>w#w-d1t2410-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2410-13">
   <w.rf>
    <LM>w#w-d1t2410-13</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-660-670">
   <w.rf>
    <LM>w#w-660-670</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2410-14">
   <w.rf>
    <LM>w#w-d1t2410-14</LM>
   </w.rf>
   <form>prodat</form>
   <lemma>prodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m009-d1t2410-15">
   <w.rf>
    <LM>w#w-d1t2410-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d-id145008">
   <w.rf>
    <LM>w#w-d-id145008</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2410-18">
   <w.rf>
    <LM>w#w-d1t2410-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2410-19">
   <w.rf>
    <LM>w#w-d1t2410-19</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2410-20">
   <w.rf>
    <LM>w#w-d1t2410-20</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m009-d1t2410-21">
   <w.rf>
    <LM>w#w-d1t2410-21</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-660-162">
   <w.rf>
    <LM>w#w-660-162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-164">
  <m id="m009-d-id145094">
   <w.rf>
    <LM>w#w-d-id145094</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2410-23">
   <w.rf>
    <LM>w#w-d1t2410-23</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2410-24">
   <w.rf>
    <LM>w#w-d1t2410-24</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2410-25">
   <w.rf>
    <LM>w#w-d1t2410-25</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2410-26">
   <w.rf>
    <LM>w#w-d1t2410-26</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d1t2410-27">
   <w.rf>
    <LM>w#w-d1t2410-27</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m009-660-671">
   <w.rf>
    <LM>w#w-660-671</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-164-176">
   <w.rf>
    <LM>w#w-164-176</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2412-2">
   <w.rf>
    <LM>w#w-d1t2412-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2412-3">
   <w.rf>
    <LM>w#w-d1t2412-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2412-1">
   <w.rf>
    <LM>w#w-d1t2412-1</LM>
   </w.rf>
   <form>vozil</form>
   <lemma>vozit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2412-4">
   <w.rf>
    <LM>w#w-d1t2412-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2412-5">
   <w.rf>
    <LM>w#w-d1t2412-5</LM>
   </w.rf>
   <form>dílen</form>
   <lemma>dílna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m009-164-76">
   <w.rf>
    <LM>w#w-164-76</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-77">
  <m id="m009-d1t2412-7">
   <w.rf>
    <LM>w#w-d1t2412-7</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m009-d1t2412-10">
   <w.rf>
    <LM>w#w-d1t2412-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m009-d1t2412-11">
   <w.rf>
    <LM>w#w-d1t2412-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2412-12">
   <w.rf>
    <LM>w#w-d1t2412-12</LM>
   </w.rf>
   <form>odvezli</form>
   <lemma>odvézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m009-d1t2412-13">
   <w.rf>
    <LM>w#w-d1t2412-13</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2412-14">
   <w.rf>
    <LM>w#w-d1t2412-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2412-15">
   <w.rf>
    <LM>w#w-d1t2412-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2412-16">
   <w.rf>
    <LM>w#w-d1t2412-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2412-17">
   <w.rf>
    <LM>w#w-d1t2412-17</LM>
   </w.rf>
   <form>nabídli</form>
   <lemma>nabídnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m009-d1t2412-18">
   <w.rf>
    <LM>w#w-d1t2412-18</LM>
   </w.rf>
   <form>kamarádům</form>
   <lemma>kamarád</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m009-d-id145444">
   <w.rf>
    <LM>w#w-d-id145444</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2412-20">
   <w.rf>
    <LM>w#w-d1t2412-20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2414-1">
   <w.rf>
    <LM>w#w-d1t2414-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2414-2">
   <w.rf>
    <LM>w#w-d1t2414-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2414-3">
   <w.rf>
    <LM>w#w-d1t2414-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2414-4">
   <w.rf>
    <LM>w#w-d1t2414-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t2414-5">
   <w.rf>
    <LM>w#w-d1t2414-5</LM>
   </w.rf>
   <form>úspěchem</form>
   <lemma>úspěch</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m009-d1t2414-6">
   <w.rf>
    <LM>w#w-d1t2414-6</LM>
   </w.rf>
   <form>prodal</form>
   <lemma>prodat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d-id144692">
   <w.rf>
    <LM>w#w-d-id144692</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2415-x2">
  <m id="m009-d1t2420-1">
   <w.rf>
    <LM>w#w-d1t2420-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m009-d1t2420-2">
   <w.rf>
    <LM>w#w-d1t2420-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t2420-3">
   <w.rf>
    <LM>w#w-d1t2420-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2420-4">
   <w.rf>
    <LM>w#w-d1t2420-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m009-d1t2426-1">
   <w.rf>
    <LM>w#w-d1t2426-1</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d1e2415-x2-738">
   <w.rf>
    <LM>w#w-d1e2415-x2-738</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2426-2">
   <w.rf>
    <LM>w#w-d1t2426-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2426-3">
   <w.rf>
    <LM>w#w-d1t2426-3</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t2426-4">
   <w.rf>
    <LM>w#w-d1t2426-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2426-5">
   <w.rf>
    <LM>w#w-d1t2426-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m009-d1t2426-6">
   <w.rf>
    <LM>w#w-d1t2426-6</LM>
   </w.rf>
   <form>dodat</form>
   <lemma>dodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m009-d-id145830">
   <w.rf>
    <LM>w#w-d-id145830</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2421-x4">
  <m id="m009-d1t2428-1">
   <w.rf>
    <LM>w#w-d1t2428-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1e2421-x4-751">
   <w.rf>
    <LM>w#w-d1e2421-x4-751</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2428-2">
   <w.rf>
    <LM>w#w-d1t2428-2</LM>
   </w.rf>
   <form>děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id145848">
   <w.rf>
    <LM>w#w-d-id145848</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2429-x2">
  <m id="m009-d1t2432-1">
   <w.rf>
    <LM>w#w-d1t2432-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d-id145940">
   <w.rf>
    <LM>w#w-d-id145940</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2432-3">
   <w.rf>
    <LM>w#w-d1t2432-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2432-4">
   <w.rf>
    <LM>w#w-d1t2432-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2432-5">
   <w.rf>
    <LM>w#w-d1t2432-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2432-6">
   <w.rf>
    <LM>w#w-d1t2432-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t2432-7">
   <w.rf>
    <LM>w#w-d1t2432-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m009-d-id145910">
   <w.rf>
    <LM>w#w-d-id145910</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2433-x2">
  <m id="m009-d1t2436-2">
   <w.rf>
    <LM>w#w-d1t2436-2</LM>
   </w.rf>
   <form>Jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2436-3">
   <w.rf>
    <LM>w#w-d1t2436-3</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id146063">
   <w.rf>
    <LM>w#w-d-id146063</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2437-x2">
  <m id="m009-d1t2440-1">
   <w.rf>
    <LM>w#w-d1t2440-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d-id146163">
   <w.rf>
    <LM>w#w-d-id146163</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2441-x2">
  <m id="m009-d1t2444-1">
   <w.rf>
    <LM>w#w-d1t2444-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m009-d1t2444-2">
   <w.rf>
    <LM>w#w-d1t2444-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t2444-3">
   <w.rf>
    <LM>w#w-d1t2444-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2444-4">
   <w.rf>
    <LM>w#w-d1t2444-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id146309">
   <w.rf>
    <LM>w#w-d-id146309</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2445-x2">
  <m id="m009-d1t2448-2">
   <w.rf>
    <LM>w#w-d1t2448-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2448-4">
   <w.rf>
    <LM>w#w-d1t2448-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2448-5">
   <w.rf>
    <LM>w#w-d1t2448-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2448-6">
   <w.rf>
    <LM>w#w-d1t2448-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t2448-8">
   <w.rf>
    <LM>w#w-d1t2448-8</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m009-d1t2448-9">
   <w.rf>
    <LM>w#w-d1t2448-9</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m009-d1t2448-12">
   <w.rf>
    <LM>w#w-d1t2448-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2448-15">
   <w.rf>
    <LM>w#w-d1t2448-15</LM>
   </w.rf>
   <form>Klabavy</form>
   <lemma>Klabava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-d-id146571">
   <w.rf>
    <LM>w#w-d-id146571</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2450-2">
   <w.rf>
    <LM>w#w-d1t2450-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2450-3">
   <w.rf>
    <LM>w#w-d1t2450-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2450-4">
   <w.rf>
    <LM>w#w-d1t2450-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m009-d1t2450-5">
   <w.rf>
    <LM>w#w-d1t2450-5</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m009-d1t2450-6">
   <w.rf>
    <LM>w#w-d1t2450-6</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m009-d1t2450-8">
   <w.rf>
    <LM>w#w-d1t2450-8</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t2450-9">
   <w.rf>
    <LM>w#w-d1t2450-9</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1e2445-x2-937">
   <w.rf>
    <LM>w#w-d1e2445-x2-937</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-938">
  <m id="m009-d1t2450-11">
   <w.rf>
    <LM>w#w-d1t2450-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2450-12">
   <w.rf>
    <LM>w#w-d1t2450-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2450-13">
   <w.rf>
    <LM>w#w-d1t2450-13</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m009-d-id146755">
   <w.rf>
    <LM>w#w-d-id146755</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2450-15">
   <w.rf>
    <LM>w#w-d1t2450-15</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2452-1">
   <w.rf>
    <LM>w#w-d1t2452-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2452-2">
   <w.rf>
    <LM>w#w-d1t2452-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2452-3">
   <w.rf>
    <LM>w#w-d1t2452-3</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m009-d1t2452-4">
   <w.rf>
    <LM>w#w-d1t2452-4</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d-id146837">
   <w.rf>
    <LM>w#w-d-id146837</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t2452-6">
   <w.rf>
    <LM>w#w-d1t2452-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t2452-7">
   <w.rf>
    <LM>w#w-d1t2452-7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2452-15">
   <w.rf>
    <LM>w#w-d1t2452-15</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-938-196">
   <w.rf>
    <LM>w#w-938-196</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2452-11">
   <w.rf>
    <LM>w#w-d1t2452-11</LM>
   </w.rf>
   <form>Klabavě</form>
   <lemma>Klabava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m009-938-1031">
   <w.rf>
    <LM>w#w-938-1031</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2456-2">
   <w.rf>
    <LM>w#w-d1t2456-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2456-3">
   <w.rf>
    <LM>w#w-d1t2456-3</LM>
   </w.rf>
   <form>vdova</form>
   <lemma>vdova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-938-1032">
   <w.rf>
    <LM>w#w-938-1032</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-1033">
  <m id="m009-d1t2456-4">
   <w.rf>
    <LM>w#w-d1t2456-4</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m009-d1t2456-5">
   <w.rf>
    <LM>w#w-d1t2456-5</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m009-d1t2456-8">
   <w.rf>
    <LM>w#w-d1t2456-8</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t2456-9">
   <w.rf>
    <LM>w#w-d1t2456-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2456-10">
   <w.rf>
    <LM>w#w-d1t2456-10</LM>
   </w.rf>
   <form>správě</form>
   <lemma>správa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m009-d1t2456-11">
   <w.rf>
    <LM>w#w-d1t2456-11</LM>
   </w.rf>
   <form>dráhy</form>
   <lemma>dráha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m009-1033-1043">
   <w.rf>
    <LM>w#w-1033-1043</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-1044_2">
  <m id="m009-d1t2459-2">
   <w.rf>
    <LM>w#w-d1t2459-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2459-3">
   <w.rf>
    <LM>w#w-d1t2459-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2459-4">
   <w.rf>
    <LM>w#w-d1t2459-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t2459-5">
   <w.rf>
    <LM>w#w-d1t2459-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t2459-6">
   <w.rf>
    <LM>w#w-d1t2459-6</LM>
   </w.rf>
   <form>pracovním</form>
   <lemma>pracovní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m009-d1t2459-7">
   <w.rf>
    <LM>w#w-d1t2459-7</LM>
   </w.rf>
   <form>úboru</form>
   <lemma>úbor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m009-d1t2461-1">
   <w.rf>
    <LM>w#w-d1t2461-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t2461-2">
   <w.rf>
    <LM>w#w-d1t2461-2</LM>
   </w.rf>
   <form>takového</form>
   <lemma>takový</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m009-d1t2461-3">
   <w.rf>
    <LM>w#w-d1t2461-3</LM>
   </w.rf>
   <form>psíka</form>
   <lemma>psík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m009-d1t2461-4">
   <w.rf>
    <LM>w#w-d1t2461-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t2461-5">
   <w.rf>
    <LM>w#w-d1t2461-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-1044_2-1256">
   <w.rf>
    <LM>w#w-1044_2-1256</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2445-x3">
  <m id="m009-d1t2465-3">
   <w.rf>
    <LM>w#w-d1t2465-3</LM>
   </w.rf>
   <form>Umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2465-2">
   <w.rf>
    <LM>w#w-d1t2465-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t2465-4">
   <w.rf>
    <LM>w#w-d1t2465-4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t2465-5">
   <w.rf>
    <LM>w#w-d1t2465-5</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m009-d1t2465-6">
   <w.rf>
    <LM>w#w-d1t2465-6</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m009-d1e2445-x3-212">
   <w.rf>
    <LM>w#w-d1e2445-x3-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-214">
  <m id="m009-d1t2467-2">
   <w.rf>
    <LM>w#w-d1t2467-2</LM>
   </w.rf>
   <form>Ochrnul</form>
   <lemma>ochrnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1t2467-3">
   <w.rf>
    <LM>w#w-d1t2467-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t2467-4">
   <w.rf>
    <LM>w#w-d1t2467-4</LM>
   </w.rf>
   <form>zadní</form>
   <lemma>zadní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m009-d1t2467-7">
   <w.rf>
    <LM>w#w-d1t2467-7</LM>
   </w.rf>
   <form>nohy</form>
   <lemma>noha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m009-214-128">
   <w.rf>
    <LM>w#w-214-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
