<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_983.02.w.gz" />
  </references>
 </head>
 <s id="m983-13808_03-550">
  <m id="m983-d1t858-18">
   <w.rf>
    <LM>w#w-d1t858-18</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t858-19">
   <w.rf>
    <LM>w#w-d1t858-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t858-20">
   <w.rf>
    <LM>w#w-d1t858-20</LM>
   </w.rf>
   <form>myslela</form>
   <lemma>myslit</lemma>
   <tag>VpQW----R-AAI-1</tag>
  </m>
  <m id="m983-d-id80451">
   <w.rf>
    <LM>w#w-d-id80451</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1e704-x9-7414">
   <w.rf>
    <LM>w#w-d1e704-x9-7414</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t861-2">
   <w.rf>
    <LM>w#w-d1t861-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m983-d1t861-3">
   <w.rf>
    <LM>w#w-d1t861-3</LM>
   </w.rf>
   <form>nepřijmuli</form>
   <lemma>přijmout</lemma>
   <tag>VpMP----R-NAP-1</tag>
  </m>
  <m id="m983-d1e704-x9-7420">
   <w.rf>
    <LM>w#w-d1e704-x9-7420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-7423">
  <m id="m983-d1t861-6">
   <w.rf>
    <LM>w#w-d1t861-6</LM>
   </w.rf>
   <form>Neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m983-7423-555">
   <w.rf>
    <LM>w#w-7423-555</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t861-8">
   <w.rf>
    <LM>w#w-d1t861-8</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t861-10">
   <w.rf>
    <LM>w#w-d1t861-10</LM>
   </w.rf>
   <form>žádnou</form>
   <lemma>žádný</lemma>
   <tag>PWFS4----------</tag>
  </m>
  <m id="m983-d1t863-1">
   <w.rf>
    <LM>w#w-d1t863-1</LM>
   </w.rf>
   <form>poddůstojnickou</form>
   <lemma>poddůstojnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m983-d1t863-2">
   <w.rf>
    <LM>w#w-d1t863-2</LM>
   </w.rf>
   <form>hodnost</form>
   <lemma>hodnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1e704-x9-7418">
   <w.rf>
    <LM>w#w-d1e704-x9-7418</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t863-4">
   <w.rf>
    <LM>w#w-d1t863-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m983-d1t863-6">
   <w.rf>
    <LM>w#w-d1t863-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t865-1">
   <w.rf>
    <LM>w#w-d1t865-1</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t865-2">
   <w.rf>
    <LM>w#w-d1t865-2</LM>
   </w.rf>
   <form>nevýhoda</form>
   <lemma>nevýhoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d-id80885">
   <w.rf>
    <LM>w#w-d-id80885</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t865-4">
   <w.rf>
    <LM>w#w-d1t865-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t865-6">
   <w.rf>
    <LM>w#w-d1t865-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t865-7">
   <w.rf>
    <LM>w#w-d1t865-7</LM>
   </w.rf>
   <form>absolutně</form>
   <lemma>absolutně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t865-8">
   <w.rf>
    <LM>w#w-d1t865-8</LM>
   </w.rf>
   <form>neovládala</form>
   <lemma>ovládat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m983-d1t865-5">
   <w.rf>
    <LM>w#w-d1t865-5</LM>
   </w.rf>
   <form>administrativu</form>
   <lemma>administrativa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-7423-556">
   <w.rf>
    <LM>w#w-7423-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-557">
  <m id="m983-d1t867-3">
   <w.rf>
    <LM>w#w-d1t867-3</LM>
   </w.rf>
   <form>Uměla</form>
   <lemma>umět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t867-2">
   <w.rf>
    <LM>w#w-d1t867-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t867-4">
   <w.rf>
    <LM>w#w-d1t867-4</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t867-5">
   <w.rf>
    <LM>w#w-d1t867-5</LM>
   </w.rf>
   <form>řídit</form>
   <lemma>řídit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d-id81062">
   <w.rf>
    <LM>w#w-d-id81062</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t867-7">
   <w.rf>
    <LM>w#w-d1t867-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t867-8">
   <w.rf>
    <LM>w#w-d1t867-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t867-9">
   <w.rf>
    <LM>w#w-d1t867-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t867-11">
   <w.rf>
    <LM>w#w-d1t867-11</LM>
   </w.rf>
   <form>vše</form>
   <lemma>všechen</lemma>
   <tag>PLNS1---------1</tag>
  </m>
  <m id="m983-7423-7433">
   <w.rf>
    <LM>w#w-7423-7433</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-7434">
  <m id="m983-d1t878-1">
   <w.rf>
    <LM>w#w-d1t878-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t878-2">
   <w.rf>
    <LM>w#w-d1t878-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t880-1">
   <w.rf>
    <LM>w#w-d1t880-1</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d-id81294">
   <w.rf>
    <LM>w#w-d-id81294</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-7434-7445">
   <w.rf>
    <LM>w#w-7434-7445</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t880-3">
   <w.rf>
    <LM>w#w-d1t880-3</LM>
   </w.rf>
   <form>jedu</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t880-4">
   <w.rf>
    <LM>w#w-d1t880-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t880-5">
   <w.rf>
    <LM>w#w-d1t880-5</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d-id81349">
   <w.rf>
    <LM>w#w-d-id81349</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t880-7">
   <w.rf>
    <LM>w#w-d1t880-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t880-8">
   <w.rf>
    <LM>w#w-d1t880-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t880-9">
   <w.rf>
    <LM>w#w-d1t880-9</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t880-12">
   <w.rf>
    <LM>w#w-d1t880-12</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1t880-13">
   <w.rf>
    <LM>w#w-d1t880-13</LM>
   </w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m983-d1t880-14">
   <w.rf>
    <LM>w#w-d1t880-14</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m983-d1t880-15">
   <w.rf>
    <LM>w#w-d1t880-15</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d1t882-1">
   <w.rf>
    <LM>w#w-d1t882-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m983-d1t882-2">
   <w.rf>
    <LM>w#w-d1t882-2</LM>
   </w.rf>
   <form>vybrat</form>
   <lemma>vybrat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m983-d1t882-3">
   <w.rf>
    <LM>w#w-d1t882-3</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m983-d1t882-4">
   <w.rf>
    <LM>w#w-d1t882-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d-id81555">
   <w.rf>
    <LM>w#w-d-id81555</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e704-x10">
  <m id="m983-d1t889-4">
   <w.rf>
    <LM>w#w-d1t889-4</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSIP1-S1-------</tag>
  </m>
  <m id="m983-d1t889-5">
   <w.rf>
    <LM>w#w-d1t889-5</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m983-d1t889-6">
   <w.rf>
    <LM>w#w-d1t889-6</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t889-7">
   <w.rf>
    <LM>w#w-d1t889-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t889-8">
   <w.rf>
    <LM>w#w-d1t889-8</LM>
   </w.rf>
   <form>uplynuly</form>
   <lemma>uplynout</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d-id81708">
   <w.rf>
    <LM>w#w-d-id81708</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t889-10">
   <w.rf>
    <LM>w#w-d1t889-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t889-11">
   <w.rf>
    <LM>w#w-d1t889-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t891-1">
   <w.rf>
    <LM>w#w-d1t891-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t891-2">
   <w.rf>
    <LM>w#w-d1t891-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m983-d1t891-4">
   <w.rf>
    <LM>w#w-d1t891-4</LM>
   </w.rf>
   <form>mými</form>
   <lemma>můj</lemma>
   <tag>PSXP7-S1-------</tag>
  </m>
  <m id="m983-d1t891-5">
   <w.rf>
    <LM>w#w-d1t891-5</LM>
   </w.rf>
   <form>dalšími</form>
   <lemma>další</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m983-d1t895-1">
   <w.rf>
    <LM>w#w-d1t895-1</LM>
   </w.rf>
   <form>kolegyněmi</form>
   <lemma>kolegyně</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m983-d1t889-12">
   <w.rf>
    <LM>w#w-d1t889-12</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d-id81907">
   <w.rf>
    <LM>w#w-d-id81907</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t895-3">
   <w.rf>
    <LM>w#w-d1t895-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t895-4">
   <w.rf>
    <LM>w#w-d1t895-4</LM>
   </w.rf>
   <form>půjdem</form>
   <lemma>jít</lemma>
   <tag>VB-P---1F-AAI-6</tag>
  </m>
  <m id="m983-d1t895-5">
   <w.rf>
    <LM>w#w-d1t895-5</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t895-6">
   <w.rf>
    <LM>w#w-d1t895-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t895-7">
   <w.rf>
    <LM>w#w-d1t895-7</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1e704-x10-7615">
   <w.rf>
    <LM>w#w-d1e704-x10-7615</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-7618">
  <m id="m983-d1t897-1">
   <w.rf>
    <LM>w#w-d1t897-1</LM>
   </w.rf>
   <form>Chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t897-2">
   <w.rf>
    <LM>w#w-d1t897-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t897-3">
   <w.rf>
    <LM>w#w-d1t897-3</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t897-4">
   <w.rf>
    <LM>w#w-d1t897-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t900-1">
   <w.rf>
    <LM>w#w-d1t900-1</LM>
   </w.rf>
   <form>Libanonu</form>
   <lemma>Libanon_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1t900-2">
   <w.rf>
    <LM>w#w-d1t900-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t900-3">
   <w.rf>
    <LM>w#w-d1t900-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t900-4">
   <w.rf>
    <LM>w#w-d1t900-4</LM>
   </w.rf>
   <form>Sýrie</form>
   <lemma>Sýrie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d-id82152">
   <w.rf>
    <LM>w#w-d-id82152</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t900-7">
   <w.rf>
    <LM>w#w-d1t900-7</LM>
   </w.rf>
   <form>jízdu</form>
   <lemma>jízda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1t900-8">
   <w.rf>
    <LM>w#w-d1t900-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t900-9">
   <w.rf>
    <LM>w#w-d1t900-9</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t900-10">
   <w.rf>
    <LM>w#w-d1t900-10</LM>
   </w.rf>
   <form>zadarmo</form>
   <lemma>zadarmo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-7618-583">
   <w.rf>
    <LM>w#w-7618-583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-584">
  <m id="m983-d1t904-1">
   <w.rf>
    <LM>w#w-d1t904-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t904-2">
   <w.rf>
    <LM>w#w-d1t904-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t904-3">
   <w.rf>
    <LM>w#w-d1t904-3</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t904-4">
   <w.rf>
    <LM>w#w-d1t904-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t904-5">
   <w.rf>
    <LM>w#w-d1t904-5</LM>
   </w.rf>
   <form>příjemnější</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m983-d1t904-6">
   <w.rf>
    <LM>w#w-d1t904-6</LM>
   </w.rf>
   <form>klima</form>
   <lemma>klima</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m983-d-id82366">
   <w.rf>
    <LM>w#w-d-id82366</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t904-8">
   <w.rf>
    <LM>w#w-d1t904-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t904-9">
   <w.rf>
    <LM>w#w-d1t904-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t904-11">
   <w.rf>
    <LM>w#w-d1t904-11</LM>
   </w.rf>
   <form>Egyptě</form>
   <lemma>Egypt_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m983-d1t904-12">
   <w.rf>
    <LM>w#w-d1t904-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t904-15">
   <w.rf>
    <LM>w#w-d1t904-15</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t904-13">
   <w.rf>
    <LM>w#w-d1t904-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t904-14">
   <w.rf>
    <LM>w#w-d1t904-14</LM>
   </w.rf>
   <form>úmorné</form>
   <lemma>úmorný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m983-d-id82499">
   <w.rf>
    <LM>w#w-d-id82499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e704-x11">
  <m id="m983-d1t913-3">
   <w.rf>
    <LM>w#w-d1t913-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t913-4">
   <w.rf>
    <LM>w#w-d1t913-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t913-5">
   <w.rf>
    <LM>w#w-d1t913-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t913-6">
   <w.rf>
    <LM>w#w-d1t913-6</LM>
   </w.rf>
   <form>sbalená</form>
   <lemma>sbalený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d-id82667">
   <w.rf>
    <LM>w#w-d-id82667</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t913-8">
   <w.rf>
    <LM>w#w-d1t913-8</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t913-9">
   <w.rf>
    <LM>w#w-d1t913-9</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t913-13">
   <w.rf>
    <LM>w#w-d1t913-13</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m983-d1t913-14">
   <w.rf>
    <LM>w#w-d1t913-14</LM>
   </w.rf>
   <form>představená</form>
   <lemma>představená-2_^(*3ý-2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1e704-x11-592">
   <w.rf>
    <LM>w#w-d1e704-x11-592</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-593">
  <m id="m983-d1t913-16">
   <w.rf>
    <LM>w#w-d1t913-16</LM>
   </w.rf>
   <form>Říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m983-d1e704-x11-7750">
   <w.rf>
    <LM>w#w-d1e704-x11-7750</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1e704-x11-7752">
   <w.rf>
    <LM>w#w-d1e704-x11-7752</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t915-1">
   <w.rf>
    <LM>w#w-d1t915-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m983-d1t915-2">
   <w.rf>
    <LM>w#w-d1t915-2</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1t915-3">
   <w.rf>
    <LM>w#w-d1t915-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t915-4">
   <w.rf>
    <LM>w#w-d1t915-4</LM>
   </w.rf>
   <form>výcvikového</form>
   <lemma>výcvikový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m983-d1t915-5">
   <w.rf>
    <LM>w#w-d1t915-5</LM>
   </w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m983-d-id82915">
   <w.rf>
    <LM>w#w-d-id82915</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t915-7">
   <w.rf>
    <LM>w#w-d1t915-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t915-8">
   <w.rf>
    <LM>w#w-d1t915-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m983-d1t915-9">
   <w.rf>
    <LM>w#w-d1t915-9</LM>
   </w.rf>
   <form>přijata</form>
   <lemma>přijmout</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m983-d-id82963">
   <w.rf>
    <LM>w#w-d-id82963</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1e704-x11-7754">
   <w.rf>
    <LM>w#w-d1e704-x11-7754</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e704-x12">
  <m id="m983-d1t921-4">
   <w.rf>
    <LM>w#w-d1t921-4</LM>
   </w.rf>
   <form>Sbalená</form>
   <lemma>sbalený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t921-5">
   <w.rf>
    <LM>w#w-d1t921-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t921-6">
   <w.rf>
    <LM>w#w-d1t921-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1e704-x12-8021">
   <w.rf>
    <LM>w#w-d1e704-x12-8021</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t923-1">
   <w.rf>
    <LM>w#w-d1t923-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t923-2">
   <w.rf>
    <LM>w#w-d1t923-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t923-3">
   <w.rf>
    <LM>w#w-d1t923-3</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t926-2">
   <w.rf>
    <LM>w#w-d1t926-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t926-4">
   <w.rf>
    <LM>w#w-d1t926-4</LM>
   </w.rf>
   <form>výcvikového</form>
   <lemma>výcvikový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m983-d1t926-5">
   <w.rf>
    <LM>w#w-d1t926-5</LM>
   </w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m983-d-id83233">
   <w.rf>
    <LM>w#w-d-id83233</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t926-7">
   <w.rf>
    <LM>w#w-d1t926-7</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1e704-x12-8023">
   <w.rf>
    <LM>w#w-d1e704-x12-8023</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t926-8">
   <w.rf>
    <LM>w#w-d1t926-8</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t926-9">
   <w.rf>
    <LM>w#w-d1t926-9</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t930-1">
   <w.rf>
    <LM>w#w-d1t930-1</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m983-d1t930-2">
   <w.rf>
    <LM>w#w-d1t930-2</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d1e704-x12-599">
   <w.rf>
    <LM>w#w-d1e704-x12-599</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-600">
  <m id="m983-d1t932-2">
   <w.rf>
    <LM>w#w-d1t932-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t932-3">
   <w.rf>
    <LM>w#w-d1t932-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t932-4">
   <w.rf>
    <LM>w#w-d1t932-4</LM>
   </w.rf>
   <form>tehdá</form>
   <lemma>tehdá_,h_^(^GC**tehdy)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t932-5">
   <w.rf>
    <LM>w#w-d1t932-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t932-6">
   <w.rf>
    <LM>w#w-d1t932-6</LM>
   </w.rf>
   <form>Jihoafričanky</form>
   <lemma>Jihoafričanka_;E_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d-id83440">
   <w.rf>
    <LM>w#w-d-id83440</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t932-8">
   <w.rf>
    <LM>w#w-d1t932-8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m983-d1t932-9">
   <w.rf>
    <LM>w#w-d1t932-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t932-10">
   <w.rf>
    <LM>w#w-d1t932-10</LM>
   </w.rf>
   <form>připravovaly</form>
   <lemma>připravovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1e704-x12-8024">
   <w.rf>
    <LM>w#w-d1e704-x12-8024</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t932-11">
   <w.rf>
    <LM>w#w-d1t932-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t932-12">
   <w.rf>
    <LM>w#w-d1t932-12</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t934-1">
   <w.rf>
    <LM>w#w-d1t934-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>úřednické</form>
   <lemma>úřednický</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m983-d1t936-2">
   <w.rf>
    <LM>w#w-d1t936-2</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m983-d1e704-x12-8025">
   <w.rf>
    <LM>w#w-d1e704-x12-8025</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-8028">
  <m id="m983-d1t936-6">
   <w.rf>
    <LM>w#w-d1t936-6</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t936-7">
   <w.rf>
    <LM>w#w-d1t936-7</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m983-d1t936-8">
   <w.rf>
    <LM>w#w-d1t936-8</LM>
   </w.rf>
   <form>jednotku</form>
   <lemma>jednotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d-id83677">
   <w.rf>
    <LM>w#w-d-id83677</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t939-1">
   <w.rf>
    <LM>w#w-d1t939-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t939-2">
   <w.rf>
    <LM>w#w-d1t939-2</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t939-3">
   <w.rf>
    <LM>w#w-d1t939-3</LM>
   </w.rf>
   <form>důstojnice</form>
   <lemma>důstojnice_^(*3ík)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d1t941-1">
   <w.rf>
    <LM>w#w-d1t941-1</LM>
   </w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t941-2">
   <w.rf>
    <LM>w#w-d1t941-2</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1t941-4">
   <w.rf>
    <LM>w#w-d1t941-4</LM>
   </w.rf>
   <form>hodnost</form>
   <lemma>hodnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d-id83812">
   <w.rf>
    <LM>w#w-d-id83812</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-8028-8040">
   <w.rf>
    <LM>w#w-8028-8040</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t945-3">
   <w.rf>
    <LM>w#w-d1t945-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t945-4">
   <w.rf>
    <LM>w#w-d1t945-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t945-5">
   <w.rf>
    <LM>w#w-d1t945-5</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m983-d1t945-6">
   <w.rf>
    <LM>w#w-d1t945-6</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-8028-8044">
   <w.rf>
    <LM>w#w-8028-8044</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-8045">
  <m id="m983-d1t947-3">
   <w.rf>
    <LM>w#w-d1t947-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t947-4">
   <w.rf>
    <LM>w#w-d1t947-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m983-d1t947-5">
   <w.rf>
    <LM>w#w-d1t947-5</LM>
   </w.rf>
   <form>zbylo</form>
   <lemma>zbýt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m983-d1t947-6">
   <w.rf>
    <LM>w#w-d1t947-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t947-7">
   <w.rf>
    <LM>w#w-d1t947-7</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t947-8">
   <w.rf>
    <LM>w#w-d1t947-8</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m983-8045-613">
   <w.rf>
    <LM>w#w-8045-613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-614">
  <m id="m983-d1t949-2">
   <w.rf>
    <LM>w#w-d1t949-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t949-4">
   <w.rf>
    <LM>w#w-d1t949-4</LM>
   </w.rf>
   <form>kurzu</form>
   <lemma>kurz</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m983-8045-612">
   <w.rf>
    <LM>w#w-8045-612</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t949-6">
   <w.rf>
    <LM>w#w-d1t949-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t949-7">
   <w.rf>
    <LM>w#w-d1t949-7</LM>
   </w.rf>
   <form>jediná</form>
   <lemma>jediný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t949-8">
   <w.rf>
    <LM>w#w-d1t949-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t949-9">
   <w.rf>
    <LM>w#w-d1t949-9</LM>
   </w.rf>
   <form>Československa</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m983-614-615">
   <w.rf>
    <LM>w#w-614-615</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-616">
  <m id="m983-d1t949-11">
   <w.rf>
    <LM>w#w-d1t949-11</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t949-12">
   <w.rf>
    <LM>w#w-d1t949-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t949-13">
   <w.rf>
    <LM>w#w-d1t949-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t949-15">
   <w.rf>
    <LM>w#w-d1t949-15</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m983-d1t949-16">
   <w.rf>
    <LM>w#w-d1t949-16</LM>
   </w.rf>
   <form>Kypřanka</form>
   <lemma>Kypřanka_;E_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d-id84304">
   <w.rf>
    <LM>w#w-d-id84304</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t949-18">
   <w.rf>
    <LM>w#w-d1t949-18</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m983-d1t949-19">
   <w.rf>
    <LM>w#w-d1t949-19</LM>
   </w.rf>
   <form>Egypťanka</form>
   <lemma>Egypťanka_;E_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d-id84344">
   <w.rf>
    <LM>w#w-d-id84344</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t952-6">
   <w.rf>
    <LM>w#w-d1t952-6</LM>
   </w.rf>
   <form>Palestinky</form>
   <lemma>Palestinka_;E</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d1t952-10">
   <w.rf>
    <LM>w#w-d1t952-10</LM>
   </w.rf>
   <form>německého</form>
   <lemma>německý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m983-d1t952-11">
   <w.rf>
    <LM>w#w-d1t952-11</LM>
   </w.rf>
   <form>původu</form>
   <lemma>původ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1t954-1">
   <w.rf>
    <LM>w#w-d1t954-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t956-1">
   <w.rf>
    <LM>w#w-d1t956-1</LM>
   </w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m983-8045-8057">
   <w.rf>
    <LM>w#w-8045-8057</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t956-2">
   <w.rf>
    <LM>w#w-d1t956-2</LM>
   </w.rf>
   <form>Angličanky</form>
   <lemma>Angličanka_;E_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-8045-8058">
   <w.rf>
    <LM>w#w-8045-8058</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-8059">
  <m id="m983-d1t960-5">
   <w.rf>
    <LM>w#w-d1t960-5</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t958-2">
   <w.rf>
    <LM>w#w-d1t958-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m983-d1t958-1">
   <w.rf>
    <LM>w#w-d1t958-1</LM>
   </w.rf>
   <form>zbylo</form>
   <lemma>zbýt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m983-d1t958-3">
   <w.rf>
    <LM>w#w-d1t958-3</LM>
   </w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m983-d1t960-1">
   <w.rf>
    <LM>w#w-d1t960-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t960-4">
   <w.rf>
    <LM>w#w-d1t960-4</LM>
   </w.rf>
   <form>absolvovaly</form>
   <lemma>absolvovat</lemma>
   <tag>VpTP----R-AAB--</tag>
  </m>
  <m id="m983-d1t960-3">
   <w.rf>
    <LM>w#w-d1t960-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d-id82972">
   <w.rf>
    <LM>w#w-d-id82972</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e963-x2">
  <m id="m983-d1t968-2">
   <w.rf>
    <LM>w#w-d1t968-2</LM>
   </w.rf>
   <form>Získala</form>
   <lemma>získat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t968-3">
   <w.rf>
    <LM>w#w-d1t968-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m983-d1t968-4">
   <w.rf>
    <LM>w#w-d1t968-4</LM>
   </w.rf>
   <form>hodnost</form>
   <lemma>hodnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d-id84894">
   <w.rf>
    <LM>w#w-d-id84894</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e963-x5">
  <m id="m983-d1t985-2">
   <w.rf>
    <LM>w#w-d1t985-2</LM>
   </w.rf>
   <form>Napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t985-3">
   <w.rf>
    <LM>w#w-d1t985-3</LM>
   </w.rf>
   <form>podporučík</form>
   <lemma>podporučík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m983-d-id85018">
   <w.rf>
    <LM>w#w-d-id85018</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t985-9">
   <w.rf>
    <LM>w#w-d1t985-9</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m983-d1t985-11">
   <w.rf>
    <LM>w#w-d1t985-11</LM>
   </w.rf>
   <form>hvězdičku</form>
   <lemma>hvězdička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1e963-x5-629">
   <w.rf>
    <LM>w#w-d1e963-x5-629</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-630">
  <m id="m983-d1t991-2">
   <w.rf>
    <LM>w#w-d1t991-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t993-1">
   <w.rf>
    <LM>w#w-d1t993-1</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m983-d1t993-2">
   <w.rf>
    <LM>w#w-d1t993-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m983-d1t993-3">
   <w.rf>
    <LM>w#w-d1t993-3</LM>
   </w.rf>
   <form>automaticky</form>
   <lemma>automaticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1e963-x5-8346">
   <w.rf>
    <LM>w#w-d1e963-x5-8346</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t993-4">
   <w.rf>
    <LM>w#w-d1t993-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t993-5">
   <w.rf>
    <LM>w#w-d1t993-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m983-d1t993-6">
   <w.rf>
    <LM>w#w-d1t993-6</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m983-d1t993-8">
   <w.rf>
    <LM>w#w-d1t993-8</LM>
   </w.rf>
   <form>nezadal</form>
   <lemma>zadat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m983-d1e963-x5-8347">
   <w.rf>
    <LM>w#w-d1e963-x5-8347</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m983-d1t997-3">
   <w.rf>
    <LM>w#w-d1t997-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m983-d1t997-4">
   <w.rf>
    <LM>w#w-d1t997-4</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m983-d1e963-x5-8348">
   <w.rf>
    <LM>w#w-d1e963-x5-8348</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t999-1">
   <w.rf>
    <LM>w#w-d1t999-1</LM>
   </w.rf>
   <form>poručíka</form>
   <lemma>poručík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m983-d-id84962">
   <w.rf>
    <LM>w#w-d-id84962</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e988-x2">
  <m id="m983-d1t1006-4">
   <w.rf>
    <LM>w#w-d1t1006-4</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1006-5">
   <w.rf>
    <LM>w#w-d1t1006-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m983-d1t1006-6">
   <w.rf>
    <LM>w#w-d1t1006-6</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1006-12">
   <w.rf>
    <LM>w#w-d1t1006-12</LM>
   </w.rf>
   <form>1944</form>
   <lemma>1944</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m983-d1e988-x2-643">
   <w.rf>
    <LM>w#w-d1e988-x2-643</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-644">
  <m id="m983-d1t1006-15">
   <w.rf>
    <LM>w#w-d1t1006-15</LM>
   </w.rf>
   <form>Napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1008-6">
   <w.rf>
    <LM>w#w-d1t1008-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1e988-x2-640">
   <w.rf>
    <LM>w#w-d1e988-x2-640</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1e988-x2-641">
   <w.rf>
    <LM>w#w-d1e988-x2-641</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m983-d1t1008-4">
   <w.rf>
    <LM>w#w-d1t1008-4</LM>
   </w.rf>
   <form>1943</form>
   <lemma>1943</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m983-d1t1008-7">
   <w.rf>
    <LM>w#w-d1t1008-7</LM>
   </w.rf>
   <form>absolvovala</form>
   <lemma>absolvovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m983-d1t1010-2">
   <w.rf>
    <LM>w#w-d1t1010-2</LM>
   </w.rf>
   <form>kurz</form>
   <lemma>kurz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m983-d1t1012-1">
   <w.rf>
    <LM>w#w-d1t1012-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1012-2">
   <w.rf>
    <LM>w#w-d1t1012-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1e988-x2-642">
   <w.rf>
    <LM>w#w-d1e988-x2-642</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m983-d1t1012-3">
   <w.rf>
    <LM>w#w-d1t1012-3</LM>
   </w.rf>
   <form>1944</form>
   <lemma>1944</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m983-d1t1012-5">
   <w.rf>
    <LM>w#w-d1t1012-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1012-6">
   <w.rf>
    <LM>w#w-d1t1012-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1012-8">
   <w.rf>
    <LM>w#w-d1t1012-8</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m983-d1t1012-9">
   <w.rf>
    <LM>w#w-d1t1012-9</LM>
   </w.rf>
   <form>hvězdička</form>
   <lemma>hvězdička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1e988-x2-279">
   <w.rf>
    <LM>w#w-d1e988-x2-279</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-281">
  <m id="m983-d1t1012-11">
   <w.rf>
    <LM>w#w-d1t1012-11</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m983-d1t1012-12">
   <w.rf>
    <LM>w#w-d1t1012-12</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m983-d1t1012-13">
   <w.rf>
    <LM>w#w-d1t1012-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1012-14">
   <w.rf>
    <LM>w#w-d1t1012-14</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1012-15">
   <w.rf>
    <LM>w#w-d1t1012-15</LM>
   </w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-281-646">
   <w.rf>
    <LM>w#w-281-646</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1012-17">
   <w.rf>
    <LM>w#w-d1t1012-17</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1012-18">
   <w.rf>
    <LM>w#w-d1t1012-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1012-19">
   <w.rf>
    <LM>w#w-d1t1012-19</LM>
   </w.rf>
   <form>demobilizovala</form>
   <lemma>demobilizovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m983-281-291">
   <w.rf>
    <LM>w#w-281-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-292">
  <m id="m983-d1t1017-1">
   <w.rf>
    <LM>w#w-d1t1017-1</LM>
   </w.rf>
   <form>Převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t1017-2">
   <w.rf>
    <LM>w#w-d1t1017-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m983-d1t1019-1">
   <w.rf>
    <LM>w#w-d1t1019-1</LM>
   </w.rf>
   <form>československá</form>
   <lemma>československý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t1019-2">
   <w.rf>
    <LM>w#w-d1t1019-2</LM>
   </w.rf>
   <form>vojenská</form>
   <lemma>vojenský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t1019-3">
   <w.rf>
    <LM>w#w-d1t1019-3</LM>
   </w.rf>
   <form>mise</form>
   <lemma>mise</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1t1019-4">
   <w.rf>
    <LM>w#w-d1t1019-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1019-5">
   <w.rf>
    <LM>w#w-d1t1019-5</LM>
   </w.rf>
   <form>Jeruzalémě</form>
   <lemma>Jeruzalém_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m983-d-id86393">
   <w.rf>
    <LM>w#w-d-id86393</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1025-4">
   <w.rf>
    <LM>w#w-d1t1025-4</LM>
   </w.rf>
   <form>demobilizovaly</form>
   <lemma>demobilizovat</lemma>
   <tag>VpTP----R-AAB--</tag>
  </m>
  <m id="m983-d1t1025-1">
   <w.rf>
    <LM>w#w-d1t1025-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1025-5">
   <w.rf>
    <LM>w#w-d1t1025-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1025-7">
   <w.rf>
    <LM>w#w-d1t1025-7</LM>
   </w.rf>
   <form>britské</form>
   <lemma>britský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m983-d1t1025-8">
   <w.rf>
    <LM>w#w-d1t1025-8</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-292-303">
   <w.rf>
    <LM>w#w-292-303</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1028-1">
   <w.rf>
    <LM>w#w-d1t1028-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1028-2">
   <w.rf>
    <LM>w#w-d1t1028-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1028-3">
   <w.rf>
    <LM>w#w-d1t1028-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m983-d1t1028-5">
   <w.rf>
    <LM>w#w-d1t1028-5</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1028-4">
   <w.rf>
    <LM>w#w-d1t1028-4</LM>
   </w.rf>
   <form>povýšili</form>
   <lemma>povýšit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m983-d1t1028-6">
   <w.rf>
    <LM>w#w-d1t1028-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1028-7">
   <w.rf>
    <LM>w#w-d1t1028-7</LM>
   </w.rf>
   <form>nadporučíka</form>
   <lemma>nadporučík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m983-d-id86730">
   <w.rf>
    <LM>w#w-d-id86730</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1029-x2">
  <m id="m983-d1t1032-2">
   <w.rf>
    <LM>w#w-d1t1032-2</LM>
   </w.rf>
   <form>Zůstanu</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m983-d1t1032-3">
   <w.rf>
    <LM>w#w-d1t1032-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1032-4">
   <w.rf>
    <LM>w#w-d1t1032-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m983-d1t1032-5">
   <w.rf>
    <LM>w#w-d1t1032-5</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-d-id86859">
   <w.rf>
    <LM>w#w-d-id86859</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1029-x3">
  <m id="m983-d1t1040-1">
   <w.rf>
    <LM>w#w-d1t1040-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m983-d1t1040-2">
   <w.rf>
    <LM>w#w-d1t1040-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m983-d1t1040-3">
   <w.rf>
    <LM>w#w-d1t1040-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1040-6">
   <w.rf>
    <LM>w#w-d1t1040-6</LM>
   </w.rf>
   <form>poručice</form>
   <lemma>poručice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1t1043-1">
   <w.rf>
    <LM>w#w-d1t1043-1</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1043-3">
   <w.rf>
    <LM>w#w-d1t1043-3</LM>
   </w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m983-d1e1029-x3-399">
   <w.rf>
    <LM>w#w-d1e1029-x3-399</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1046-x2">
  <m id="m983-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1053-1">
   <w.rf>
    <LM>w#w-d1t1053-1</LM>
   </w.rf>
   <form>řidiček</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m983-d1t1053-2">
   <w.rf>
    <LM>w#w-d1t1053-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1053-3">
   <w.rf>
    <LM>w#w-d1t1053-3</LM>
   </w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t1053-4">
   <w.rf>
    <LM>w#w-d1t1053-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1e1046-x2-490">
   <w.rf>
    <LM>w#w-d1e1046-x2-490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1053-5">
   <w.rf>
    <LM>w#w-d1t1053-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1053-6">
   <w.rf>
    <LM>w#w-d1t1053-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1053-7">
   <w.rf>
    <LM>w#w-d1t1053-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1053-9">
   <w.rf>
    <LM>w#w-d1t1053-9</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m983-d1t1053-10">
   <w.rf>
    <LM>w#w-d1t1053-10</LM>
   </w.rf>
   <form>profese</form>
   <lemma>profese</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1e1046-x2-657">
   <w.rf>
    <LM>w#w-d1e1046-x2-657</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-658">
  <m id="m983-d1t1057-8">
   <w.rf>
    <LM>w#w-d1t1057-8</LM>
   </w.rf>
   <form>Jezdily</form>
   <lemma>jezdit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1057-7">
   <w.rf>
    <LM>w#w-d1t1057-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1057-9">
   <w.rf>
    <LM>w#w-d1t1057-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1057-10">
   <w.rf>
    <LM>w#w-d1t1057-10</LM>
   </w.rf>
   <form>přístavů</form>
   <lemma>přístav</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m983-d1t1057-11">
   <w.rf>
    <LM>w#w-d1t1057-11</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1057-12">
   <w.rf>
    <LM>w#w-d1t1057-12</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m983-d1t1057-13">
   <w.rf>
    <LM>w#w-d1t1057-13</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d-id87650">
   <w.rf>
    <LM>w#w-d-id87650</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1046-x3">
  <m id="m983-d1t1064-1">
   <w.rf>
    <LM>w#w-d1t1064-1</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1062-3">
   <w.rf>
    <LM>w#w-d1t1062-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1062-4">
   <w.rf>
    <LM>w#w-d1t1062-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1064-2">
   <w.rf>
    <LM>w#w-d1t1064-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1064-3">
   <w.rf>
    <LM>w#w-d1t1064-3</LM>
   </w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m983-d1t1068-3">
   <w.rf>
    <LM>w#w-d1t1068-3</LM>
   </w.rf>
   <form>odvážet</form>
   <lemma>odvážet_^(něco_někam_např._autem)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1t1068-2">
   <w.rf>
    <LM>w#w-d1t1068-2</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d1t1068-4">
   <w.rf>
    <LM>w#w-d1t1068-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1068-5">
   <w.rf>
    <LM>w#w-d1t1068-5</LM>
   </w.rf>
   <form>Port</form>
   <lemma>Port-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m983-d1e1046-x3-663">
   <w.rf>
    <LM>w#w-d1e1046-x3-663</LM>
   </w.rf>
   <form>Saidu</form>
   <lemma>Said_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1e1046-x3-620">
   <w.rf>
    <LM>w#w-d1e1046-x3-620</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1068-6">
   <w.rf>
    <LM>w#w-d1t1068-6</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1068-7">
   <w.rf>
    <LM>w#w-d1t1068-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m983-d1t1070-1">
   <w.rf>
    <LM>w#w-d1t1070-1</LM>
   </w.rf>
   <form>dovážely</form>
   <lemma>dovážet_^(z_ciziny)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1070-5">
   <w.rf>
    <LM>w#w-d1t1070-5</LM>
   </w.rf>
   <form>americké</form>
   <lemma>americký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m983-d1t1070-2">
   <w.rf>
    <LM>w#w-d1t1070-2</LM>
   </w.rf>
   <form>lodě</form>
   <lemma>loď</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d-id87985">
   <w.rf>
    <LM>w#w-d-id87985</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1070-6">
   <w.rf>
    <LM>w#w-d1t1070-6</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1070-7">
   <w.rf>
    <LM>w#w-d1t1070-7</LM>
   </w.rf>
   <form>dočky</form>
   <lemma>dočka_,h_^(auto_Dodge)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m983-d1t1073-1">
   <w.rf>
    <LM>w#w-d1t1073-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1075-2">
   <w.rf>
    <LM>w#w-d1t1075-2</LM>
   </w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m983-d1t1075-3">
   <w.rf>
    <LM>w#w-d1t1075-3</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d-id88151">
   <w.rf>
    <LM>w#w-d-id88151</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1046-x4">
  <m id="m983-d1t1079-3">
   <w.rf>
    <LM>w#w-d1t1079-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1079-4">
   <w.rf>
    <LM>w#w-d1t1079-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1079-5">
   <w.rf>
    <LM>w#w-d1t1079-5</LM>
   </w.rf>
   <form>zbrusu</form>
   <lemma>zbrusu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1079-6">
   <w.rf>
    <LM>w#w-d1t1079-6</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m983-d1t1079-7">
   <w.rf>
    <LM>w#w-d1t1079-7</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1e1046-x4-669">
   <w.rf>
    <LM>w#w-d1e1046-x4-669</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-670">
  <m id="m983-d1t1081-5">
   <w.rf>
    <LM>w#w-d1t1081-5</LM>
   </w.rf>
   <form>Typy</form>
   <lemma>typ</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t1081-3">
   <w.rf>
    <LM>w#w-d1t1081-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1081-6">
   <w.rf>
    <LM>w#w-d1t1081-6</LM>
   </w.rf>
   <form>střídaly</form>
   <lemma>střídat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1e1046-x4-877">
   <w.rf>
    <LM>w#w-d1e1046-x4-877</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1081-9">
   <w.rf>
    <LM>w#w-d1t1081-9</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1081-10">
   <w.rf>
    <LM>w#w-d1t1081-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1081-11">
   <w.rf>
    <LM>w#w-d1t1081-11</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1081-12">
   <w.rf>
    <LM>w#w-d1t1081-12</LM>
   </w.rf>
   <form>Bedfordy</form>
   <lemma>Bedford_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d-id88454">
   <w.rf>
    <LM>w#w-d-id88454</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1081-15">
   <w.rf>
    <LM>w#w-d1t1081-15</LM>
   </w.rf>
   <form>anglické</form>
   <lemma>anglický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m983-d1t1081-16">
   <w.rf>
    <LM>w#w-d1t1081-16</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1e1046-x4-878">
   <w.rf>
    <LM>w#w-d1e1046-x4-878</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1081-17">
   <w.rf>
    <LM>w#w-d1t1081-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1083-2">
   <w.rf>
    <LM>w#w-d1t1083-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1083-1">
   <w.rf>
    <LM>w#w-d1t1083-1</LM>
   </w.rf>
   <form>Fordy</form>
   <lemma>Ford-2_;m</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t1083-3">
   <w.rf>
    <LM>w#w-d1t1083-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1083-4">
   <w.rf>
    <LM>w#w-d1t1083-4</LM>
   </w.rf>
   <form>Ameriky</form>
   <lemma>Amerika_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d1e1046-x4-881">
   <w.rf>
    <LM>w#w-d1e1046-x4-881</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1088-3">
   <w.rf>
    <LM>w#w-d1t1088-3</LM>
   </w.rf>
   <form>anglické</form>
   <lemma>anglický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m983-d1t1088-1">
   <w.rf>
    <LM>w#w-d1t1088-1</LM>
   </w.rf>
   <form>Austiny</form>
   <lemma>Austin-1_;m_^(vozidlo)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-670-671">
   <w.rf>
    <LM>w#w-670-671</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-672">
  <m id="m983-d1t1088-7">
   <w.rf>
    <LM>w#w-d1t1088-7</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1088-5">
   <w.rf>
    <LM>w#w-d1t1088-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1088-6">
   <w.rf>
    <LM>w#w-d1t1088-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t1090-1">
   <w.rf>
    <LM>w#w-d1t1090-1</LM>
   </w.rf>
   <form>trapné</form>
   <lemma>trapný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m983-d-id88748">
   <w.rf>
    <LM>w#w-d-id88748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1090-3">
   <w.rf>
    <LM>w#w-d1t1090-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1090-4">
   <w.rf>
    <LM>w#w-d1t1090-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1090-5">
   <w.rf>
    <LM>w#w-d1t1090-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1090-6">
   <w.rf>
    <LM>w#w-d1t1090-6</LM>
   </w.rf>
   <form>nevěděly</form>
   <lemma>vědět</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m983-d-id88819">
   <w.rf>
    <LM>w#w-d-id88819</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1090-8">
   <w.rf>
    <LM>w#w-d1t1090-8</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1090-9">
   <w.rf>
    <LM>w#w-d1t1090-9</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m983-d1t1090-10">
   <w.rf>
    <LM>w#w-d1t1090-10</LM>
   </w.rf>
   <form>startéry</form>
   <lemma>startér-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-672-673">
   <w.rf>
    <LM>w#w-672-673</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-674">
  <m id="m983-d1t1096-2">
   <w.rf>
    <LM>w#w-d1t1096-2</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m983-d1t1096-3">
   <w.rf>
    <LM>w#w-d1t1096-3</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m983-d1t1096-4">
   <w.rf>
    <LM>w#w-d1t1096-4</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m983-d1t1096-5">
   <w.rf>
    <LM>w#w-d1t1096-5</LM>
   </w.rf>
   <form>druh</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1096-6">
   <w.rf>
    <LM>w#w-d1t1096-6</LM>
   </w.rf>
   <form>vozu</form>
   <lemma>vůz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1e1046-x4-887">
   <w.rf>
    <LM>w#w-d1e1046-x4-887</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-890">
  <m id="m983-d1t1101-1">
   <w.rf>
    <LM>w#w-d1t1101-1</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1105-3">
   <w.rf>
    <LM>w#w-d1t1105-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1105-2">
   <w.rf>
    <LM>w#w-d1t1105-2</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t1107-1">
   <w.rf>
    <LM>w#w-d1t1107-1</LM>
   </w.rf>
   <form>tvrdé</form>
   <lemma>tvrdý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m983-d-id89210">
   <w.rf>
    <LM>w#w-d-id89210</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1107-4">
   <w.rf>
    <LM>w#w-d1t1107-4</LM>
   </w.rf>
   <form>nezajeté</form>
   <lemma>zajetý_^(*1)</lemma>
   <tag>AAIP1----1N----</tag>
  </m>
  <m id="m983-890-683">
   <w.rf>
    <LM>w#w-890-683</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-684">
  <m id="m983-d1t1112-6">
   <w.rf>
    <LM>w#w-d1t1112-6</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m983-d-id89362">
   <w.rf>
    <LM>w#w-d-id89362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1112-8">
   <w.rf>
    <LM>w#w-d1t1112-8</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1112-9">
   <w.rf>
    <LM>w#w-d1t1112-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m983-d1t1112-10">
   <w.rf>
    <LM>w#w-d1t1112-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1112-11">
   <w.rf>
    <LM>w#w-d1t1112-11</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m983-d1t1112-12">
   <w.rf>
    <LM>w#w-d1t1112-12</LM>
   </w.rf>
   <form>zná</form>
   <lemma>znát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m983-684-685">
   <w.rf>
    <LM>w#w-684-685</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-686">
  <m id="m983-d1t1116-4">
   <w.rf>
    <LM>w#w-d1t1116-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Suezský</form>
   <lemma>suezský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m983-d1t1116-5">
   <w.rf>
    <LM>w#w-d1t1116-5</LM>
   </w.rf>
   <form>kanál</form>
   <lemma>kanál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1116-6">
   <w.rf>
    <LM>w#w-d1t1116-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1116-7">
   <w.rf>
    <LM>w#w-d1t1116-7</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m983-d1t1116-8">
   <w.rf>
    <LM>w#w-d1t1116-8</LM>
   </w.rf>
   <form>straně</form>
   <lemma>strana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-890-903">
   <w.rf>
    <LM>w#w-890-903</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1118-1">
   <w.rf>
    <LM>w#w-d1t1118-1</LM>
   </w.rf>
   <form>sladkovodní</form>
   <lemma>sladkovodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m983-d1t1118-2">
   <w.rf>
    <LM>w#w-d1t1118-2</LM>
   </w.rf>
   <form>kanál</form>
   <lemma>kanál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1118-4">
   <w.rf>
    <LM>w#w-d1t1118-4</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m983-d1t1118-5">
   <w.rf>
    <LM>w#w-d1t1118-5</LM>
   </w.rf>
   <form>straně</form>
   <lemma>strana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-686-687">
   <w.rf>
    <LM>w#w-686-687</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-688">
  <m id="m983-d1t1120-1">
   <w.rf>
    <LM>w#w-d1t1120-1</LM>
   </w.rf>
   <form>Silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-688-689">
   <w.rf>
    <LM>w#w-688-689</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1120-2">
   <w.rf>
    <LM>w#w-d1t1120-2</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1122-1">
   <w.rf>
    <LM>w#w-d1t1122-1</LM>
   </w.rf>
   <form>rovná</form>
   <lemma>rovný_^(přímý,_stejný,_spravedlivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t1122-2">
   <w.rf>
    <LM>w#w-d1t1122-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1122-3">
   <w.rf>
    <LM>w#w-d1t1122-3</LM>
   </w.rf>
   <form>čára</form>
   <lemma>čára_^(linie)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d-id89800">
   <w.rf>
    <LM>w#w-d-id89800</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1122-5">
   <w.rf>
    <LM>w#w-d1t1122-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1122-6">
   <w.rf>
    <LM>w#w-d1t1122-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1122-7">
   <w.rf>
    <LM>w#w-d1t1122-7</LM>
   </w.rf>
   <form>vešly</form>
   <lemma>vejít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d1t1122-8">
   <w.rf>
    <LM>w#w-d1t1122-8</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m983-d1t1122-9">
   <w.rf>
    <LM>w#w-d1t1122-9</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d-id89886">
   <w.rf>
    <LM>w#w-d-id89886</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1046-x5">
  <m id="m983-d1t1127-3">
   <w.rf>
    <LM>w#w-d1t1127-3</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1127-4">
   <w.rf>
    <LM>w#w-d1t1127-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1127-6">
   <w.rf>
    <LM>w#w-d1t1127-6</LM>
   </w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m983-d1t1127-7">
   <w.rf>
    <LM>w#w-d1t1127-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1127-8">
   <w.rf>
    <LM>w#w-d1t1127-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m983-d1t1127-9">
   <w.rf>
    <LM>w#w-d1t1127-9</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m983-d-id90051">
   <w.rf>
    <LM>w#w-d-id90051</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1127-11">
   <w.rf>
    <LM>w#w-d1t1127-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1129-2">
   <w.rf>
    <LM>w#w-d1t1129-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m983-d1t1129-1">
   <w.rf>
    <LM>w#w-d1t1129-1</LM>
   </w.rf>
   <form>holky</form>
   <lemma>holka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d1t1129-3">
   <w.rf>
    <LM>w#w-d1t1129-3</LM>
   </w.rf>
   <form>nezvládly</form>
   <lemma>zvládnout</lemma>
   <tag>VpTP----R-NAP-1</tag>
  </m>
  <m id="m983-d1e1046-x5-1075">
   <w.rf>
    <LM>w#w-d1e1046-x5-1075</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1129-4">
   <w.rf>
    <LM>w#w-d1t1129-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1129-7">
   <w.rf>
    <LM>w#w-d1t1129-7</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m983-d1t1129-8">
   <w.rf>
    <LM>w#w-d1t1129-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1131-1">
   <w.rf>
    <LM>w#w-d1t1131-1</LM>
   </w.rf>
   <form>rutinované</form>
   <lemma>rutinovaný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m983-d1t1131-2">
   <w.rf>
    <LM>w#w-d1t1131-2</LM>
   </w.rf>
   <form>řidičky</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m983-d-id90234">
   <w.rf>
    <LM>w#w-d-id90234</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1133-1">
   <w.rf>
    <LM>w#w-d1t1133-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1133-2">
   <w.rf>
    <LM>w#w-d1t1133-2</LM>
   </w.rf>
   <form>zřítily</form>
   <lemma>zřítit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d1t1133-3">
   <w.rf>
    <LM>w#w-d1t1133-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1133-4">
   <w.rf>
    <LM>w#w-d1t1133-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1133-6">
   <w.rf>
    <LM>w#w-d1t1133-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Suezského</form>
   <lemma>suezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m983-d1t1133-7">
   <w.rf>
    <LM>w#w-d1t1133-7</LM>
   </w.rf>
   <form>kanálu</form>
   <lemma>kanál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1e1046-x5-695">
   <w.rf>
    <LM>w#w-d1e1046-x5-695</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-696">
  <m id="m983-d1t1133-9">
   <w.rf>
    <LM>w#w-d1t1133-9</LM>
   </w.rf>
   <form>Naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1138-1">
   <w.rf>
    <LM>w#w-d1t1138-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m983-d1t1138-2">
   <w.rf>
    <LM>w#w-d1t1138-2</LM>
   </w.rf>
   <form>přežily</form>
   <lemma>přežít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d1e1046-x5-1077">
   <w.rf>
    <LM>w#w-d1e1046-x5-1077</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1138-3">
   <w.rf>
    <LM>w#w-d1t1138-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1138-4">
   <w.rf>
    <LM>w#w-d1t1138-4</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t1138-5">
   <w.rf>
    <LM>w#w-d1t1138-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1138-6">
   <w.rf>
    <LM>w#w-d1t1138-6</LM>
   </w.rf>
   <form>zůstaly</form>
   <lemma>zůstat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d-id90567">
   <w.rf>
    <LM>w#w-d-id90567</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1139-x2">
  <m id="m983-d1t1144-1">
   <w.rf>
    <LM>w#w-d1t1144-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m983-d1t1144-2">
   <w.rf>
    <LM>w#w-d1t1144-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m983-d1t1144-3">
   <w.rf>
    <LM>w#w-d1t1144-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1144-4">
   <w.rf>
    <LM>w#w-d1t1144-4</LM>
   </w.rf>
   <form>podřízených</form>
   <lemma>podřízený_^(*4dit)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m983-d-id90704">
   <w.rf>
    <LM>w#w-d-id90704</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1145-x2">
  <m id="m983-d1t1152-2">
   <w.rf>
    <LM>w#w-d1t1152-2</LM>
   </w.rf>
   <form>Konvoj</form>
   <lemma>konvoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1152-3">
   <w.rf>
    <LM>w#w-d1t1152-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1152-5">
   <w.rf>
    <LM>w#w-d1t1152-5</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1152-4">
   <w.rf>
    <LM>w#w-d1t1152-4</LM>
   </w.rf>
   <form>skládal</form>
   <lemma>skládat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m983-d1e1145-x2-1204">
   <w.rf>
    <LM>w#w-d1e1145-x2-1204</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1152-8">
   <w.rf>
    <LM>w#w-d1t1152-8</LM>
   </w.rf>
   <form>třiceti</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m983-d1t1152-9">
   <w.rf>
    <LM>w#w-d1t1152-9</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1152-10">
   <w.rf>
    <LM>w#w-d1t1152-10</LM>
   </w.rf>
   <form>padesáti</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m983-d1t1152-11">
   <w.rf>
    <LM>w#w-d1t1152-11</LM>
   </w.rf>
   <form>vozů</form>
   <lemma>vůz</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m983-d-id90957">
   <w.rf>
    <LM>w#w-d-id90957</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1145-x3">
  <m id="m983-d1t1156-3">
   <w.rf>
    <LM>w#w-d1t1156-3</LM>
   </w.rf>
   <form>Vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m983-d1t1156-4">
   <w.rf>
    <LM>w#w-d1t1156-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1156-6">
   <w.rf>
    <LM>w#w-d1t1156-6</LM>
   </w.rf>
   <form>vyloďovaly</form>
   <lemma>vyloďovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1156-8">
   <w.rf>
    <LM>w#w-d1t1156-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1156-10">
   <w.rf>
    <LM>w#w-d1t1156-10</LM>
   </w.rf>
   <form>Port</form>
   <lemma>Port-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m983-d1e1145-x3-703">
   <w.rf>
    <LM>w#w-d1e1145-x3-703</LM>
   </w.rf>
   <form>Saidu</form>
   <lemma>Said_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1e1145-x3-1299">
   <w.rf>
    <LM>w#w-d1e1145-x3-1299</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1156-11">
   <w.rf>
    <LM>w#w-d1t1156-11</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1156-12">
   <w.rf>
    <LM>w#w-d1t1156-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1156-13">
   <w.rf>
    <LM>w#w-d1t1156-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1156-14">
   <w.rf>
    <LM>w#w-d1t1156-14</LM>
   </w.rf>
   <form>Suezu</form>
   <lemma>Suez_;G_;m</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m983-d-id91194">
   <w.rf>
    <LM>w#w-d-id91194</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1159-2">
   <w.rf>
    <LM>w#w-d1t1159-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1159-5">
   <w.rf>
    <LM>w#w-d1t1159-5</LM>
   </w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m983-d1t1159-4">
   <w.rf>
    <LM>w#w-d1t1159-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1159-3">
   <w.rf>
    <LM>w#w-d1t1159-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m983-d1t1159-7">
   <w.rf>
    <LM>w#w-d1t1159-7</LM>
   </w.rf>
   <form>dovážet</form>
   <lemma>dovážet_^(z_ciziny)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1t1159-9">
   <w.rf>
    <LM>w#w-d1t1159-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1161-1">
   <w.rf>
    <LM>w#w-d1t1161-1</LM>
   </w.rf>
   <form>dílen</form>
   <lemma>dílna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m983-d1e1145-x3-1301">
   <w.rf>
    <LM>w#w-d1e1145-x3-1301</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1161-2">
   <w.rf>
    <LM>w#w-d1t1161-2</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1161-3">
   <w.rf>
    <LM>w#w-d1t1161-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m983-d1t1161-4">
   <w.rf>
    <LM>w#w-d1t1161-4</LM>
   </w.rf>
   <form>adaptovali</form>
   <lemma>adaptovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m983-d1t1161-5">
   <w.rf>
    <LM>w#w-d1t1161-5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m983-d1t1161-6">
   <w.rf>
    <LM>w#w-d1t1161-6</LM>
   </w.rf>
   <form>poušť</form>
   <lemma>poušť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d-id91460">
   <w.rf>
    <LM>w#w-d-id91460</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1145-x4">
  <m id="m983-d1t1165-2">
   <w.rf>
    <LM>w#w-d1t1165-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1165-3">
   <w.rf>
    <LM>w#w-d1t1165-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m983-d1t1165-4">
   <w.rf>
    <LM>w#w-d1t1165-4</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m983-d1t1165-5">
   <w.rf>
    <LM>w#w-d1t1165-5</LM>
   </w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m983-d1t1165-6">
   <w.rf>
    <LM>w#w-d1t1165-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1167-2">
   <w.rf>
    <LM>w#w-d1t1167-2</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m983-d1t1167-1">
   <w.rf>
    <LM>w#w-d1t1167-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1167-3">
   <w.rf>
    <LM>w#w-d1t1167-3</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m983-d1e1145-x4-482">
   <w.rf>
    <LM>w#w-d1e1145-x4-482</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1169-1">
   <w.rf>
    <LM>w#w-d1t1169-1</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1169-2">
   <w.rf>
    <LM>w#w-d1t1169-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1169-3">
   <w.rf>
    <LM>w#w-d1t1169-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m983-d1e1145-x4-1489">
   <w.rf>
    <LM>w#w-d1e1145-x4-1489</LM>
   </w.rf>
   <form>dokončily</form>
   <lemma>dokončit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d1e1145-x4-715">
   <w.rf>
    <LM>w#w-d1e1145-x4-715</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-716">
  <m id="m983-d1t1174-6">
   <w.rf>
    <LM>w#w-d1t1174-6</LM>
   </w.rf>
   <form>Dennodenně</form>
   <lemma>dennodenně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1176-1">
   <w.rf>
    <LM>w#w-d1t1176-1</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m983-d1t1176-2">
   <w.rf>
    <LM>w#w-d1t1176-2</LM>
   </w.rf>
   <form>samou</form>
   <lemma>samý</lemma>
   <tag>PLFS4----------</tag>
  </m>
  <m id="m983-d1t1176-3">
   <w.rf>
    <LM>w#w-d1t1176-3</LM>
   </w.rf>
   <form>cestu</form>
   <lemma>cesta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1t1176-4">
   <w.rf>
    <LM>w#w-d1t1176-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1176-6">
   <w.rf>
    <LM>w#w-d1t1176-6</LM>
   </w.rf>
   <form>Port</form>
   <lemma>Port-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m983-716-717">
   <w.rf>
    <LM>w#w-716-717</LM>
   </w.rf>
   <form>Saidu</form>
   <lemma>Said_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d-id91666">
   <w.rf>
    <LM>w#w-d-id91666</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1145-x5">
  <m id="m983-d1t1180-4">
   <w.rf>
    <LM>w#w-d1t1180-4</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1180-7">
   <w.rf>
    <LM>w#w-d1t1180-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1180-8">
   <w.rf>
    <LM>w#w-d1t1180-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1180-9">
   <w.rf>
    <LM>w#w-d1t1180-9</LM>
   </w.rf>
   <form>zavázaly</form>
   <lemma>zavázat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m983-d-id92098">
   <w.rf>
    <LM>w#w-d-id92098</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1180-11">
   <w.rf>
    <LM>w#w-d1t1180-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1180-12">
   <w.rf>
    <LM>w#w-d1t1180-12</LM>
   </w.rf>
   <form>zůstaneme</form>
   <lemma>zůstat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m983-d1t1185-2">
   <w.rf>
    <LM>w#w-d1t1185-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1185-3">
   <w.rf>
    <LM>w#w-d1t1185-3</LM>
   </w.rf>
   <form>dálném</form>
   <lemma>dálný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m983-d1t1185-4">
   <w.rf>
    <LM>w#w-d1t1185-4</LM>
   </w.rf>
   <form>východě</form>
   <lemma>východ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m983-d1t1180-13">
   <w.rf>
    <LM>w#w-d1t1180-13</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1180-14">
   <w.rf>
    <LM>w#w-d1t1180-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1182-1">
   <w.rf>
    <LM>w#w-d1t1182-1</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d1t1182-2">
   <w.rf>
    <LM>w#w-d1t1182-2</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d-id92224">
   <w.rf>
    <LM>w#w-d-id92224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1145-x7">
  <m id="m983-d1t1189-2">
   <w.rf>
    <LM>w#w-d1t1189-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1189-3">
   <w.rf>
    <LM>w#w-d1t1189-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1189-4">
   <w.rf>
    <LM>w#w-d1t1189-4</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1191-1">
   <w.rf>
    <LM>w#w-d1t1191-1</LM>
   </w.rf>
   <form>západní</form>
   <lemma>západní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m983-d1t1191-2">
   <w.rf>
    <LM>w#w-d1t1191-2</LM>
   </w.rf>
   <form>armáda</form>
   <lemma>armáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1t1195-1">
   <w.rf>
    <LM>w#w-d1t1195-1</LM>
   </w.rf>
   <form>postupovala</form>
   <lemma>postupovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d-id92550">
   <w.rf>
    <LM>w#w-d-id92550</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1200-1">
   <w.rf>
    <LM>w#w-d1t1200-1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Rommel</form>
   <lemma>Rommel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m983-d1t1200-2">
   <w.rf>
    <LM>w#w-d1t1200-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1195-3">
   <w.rf>
    <LM>w#w-d1t1195-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1198-1">
   <w.rf>
    <LM>w#w-d1t1198-1</LM>
   </w.rf>
   <form>Africe</form>
   <lemma>Afrika_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-d1t1200-3">
   <w.rf>
    <LM>w#w-d1t1200-3</LM>
   </w.rf>
   <form>vzdal</form>
   <lemma>vzdát</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m983-d1t1200-4">
   <w.rf>
    <LM>w#w-d1t1200-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1200-6">
   <w.rf>
    <LM>w#w-d1t1200-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1200-5">
   <w.rf>
    <LM>w#w-d1t1200-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1200-7">
   <w.rf>
    <LM>w#w-d1t1200-7</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m983-d1t1200-8">
   <w.rf>
    <LM>w#w-d1t1200-8</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m983-d1t1200-9">
   <w.rf>
    <LM>w#w-d1t1200-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m983-d1t1200-10">
   <w.rf>
    <LM>w#w-d1t1200-10</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1e1145-x7-1780">
   <w.rf>
    <LM>w#w-d1e1145-x7-1780</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-1783">
  <m id="m983-d1t1202-1">
   <w.rf>
    <LM>w#w-d1t1202-1</LM>
   </w.rf>
   <form>Některá</form>
   <lemma>některý</lemma>
   <tag>PZNP1----------</tag>
  </m>
  <m id="m983-d1t1202-2">
   <w.rf>
    <LM>w#w-d1t1202-2</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m983-d1t1202-3">
   <w.rf>
    <LM>w#w-d1t1202-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m983-d1t1202-5">
   <w.rf>
    <LM>w#w-d1t1202-5</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1202-4">
   <w.rf>
    <LM>w#w-d1t1202-4</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t1202-6">
   <w.rf>
    <LM>w#w-d1t1202-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1202-7">
   <w.rf>
    <LM>w#w-d1t1202-7</LM>
   </w.rf>
   <form>Itálie</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d-id92822">
   <w.rf>
    <LM>w#w-d-id92822</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1202-9">
   <w.rf>
    <LM>w#w-d1t1202-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m983-d1t1204-1">
   <w.rf>
    <LM>w#w-d1t1204-1</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m983-d1t1204-2">
   <w.rf>
    <LM>w#w-d1t1204-2</LM>
   </w.rf>
   <form>fronta</form>
   <lemma>fronta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m983-d1t1204-3">
   <w.rf>
    <LM>w#w-d1t1204-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1204-4">
   <w.rf>
    <LM>w#w-d1t1204-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d-id92904">
   <w.rf>
    <LM>w#w-d-id92904</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1206-2">
   <w.rf>
    <LM>w#w-d1t1206-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m983-d1t1206-3">
   <w.rf>
    <LM>w#w-d1t1206-3</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m983-d1t1206-4">
   <w.rf>
    <LM>w#w-d1t1206-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m983-d1t1206-6">
   <w.rf>
    <LM>w#w-d1t1206-6</LM>
   </w.rf>
   <form>zkysly</form>
   <lemma>zkysnout</lemma>
   <tag>VpTP----R-AAP-1</tag>
  </m>
  <m id="m983-d1t1206-7">
   <w.rf>
    <LM>w#w-d1t1206-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m983-d1t1206-9">
   <w.rf>
    <LM>w#w-d1t1206-9</LM>
   </w.rf>
   <form>poušti</form>
   <lemma>poušť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m983-d1t1206-10">
   <w.rf>
    <LM>w#w-d1t1206-10</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1208-2">
   <w.rf>
    <LM>w#w-d1t1208-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1208-3">
   <w.rf>
    <LM>w#w-d1t1208-3</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d-id93133">
   <w.rf>
    <LM>w#w-d-id93133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1209-x2">
  <m id="m983-d1t1214-1">
   <w.rf>
    <LM>w#w-d1t1214-1</LM>
   </w.rf>
   <form>Nemáte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m983-d1t1214-2">
   <w.rf>
    <LM>w#w-d1t1214-2</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m983-d1t1214-3">
   <w.rf>
    <LM>w#w-d1t1214-3</LM>
   </w.rf>
   <form>historku</form>
   <lemma>historka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1t1216-1">
   <w.rf>
    <LM>w#w-d1t1216-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m983-d1t1216-2">
   <w.rf>
    <LM>w#w-d1t1216-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m983-d1t1216-3">
   <w.rf>
    <LM>w#w-d1t1216-3</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m983-d-id93302">
   <w.rf>
    <LM>w#w-d-id93302</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1217-x2">
  <m id="m983-d1t1224-1">
   <w.rf>
    <LM>w#w-d1t1224-1</LM>
   </w.rf>
   <form>Historku</form>
   <lemma>historka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m983-d1e1217-x2-2324">
   <w.rf>
    <LM>w#w-d1e1217-x2-2324</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1229-x2">
  <m id="m983-d1e1229-x2-742">
   <w.rf>
    <LM>w#w-d1e1229-x2-742</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m983-d1e1229-x2-741">
   <w.rf>
    <LM>w#w-d1e1229-x2-741</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m983-d1t1236-1">
   <w.rf>
    <LM>w#w-d1t1236-1</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m983-d1t1236-2">
   <w.rf>
    <LM>w#w-d1t1236-2</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m983-d1e1229-x2-2361">
   <w.rf>
    <LM>w#w-d1e1229-x2-2361</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1249-4">
   <w.rf>
    <LM>w#w-d1t1249-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m983-d1e1244-x2-2413">
   <w.rf>
    <LM>w#w-d1e1244-x2-2413</LM>
   </w.rf>
   <form>nemohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m983-d1e1229-x2-2430">
   <w.rf>
    <LM>w#w-d1e1229-x2-2430</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m983-d1t1249-1">
   <w.rf>
    <LM>w#w-d1t1249-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1249-2">
   <w.rf>
    <LM>w#w-d1t1249-2</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m983-d1t1249-3">
   <w.rf>
    <LM>w#w-d1t1249-3</LM>
   </w.rf>
   <form>monotónní</form>
   <lemma>monotónní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m983-d-id93564">
   <w.rf>
    <LM>w#w-d-id93564</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m983-13808_03-d1e1251-x2">
  <m id="m983-d1t1256-1">
   <w.rf>
    <LM>w#w-d1t1256-1</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m983-d1t1256-2">
   <w.rf>
    <LM>w#w-d1t1256-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m983-d1t1256-3">
   <w.rf>
    <LM>w#w-d1t1256-3</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS7----------</tag>
  </m>
  <m id="m983-d1t1256-4">
   <w.rf>
    <LM>w#w-d1t1256-4</LM>
   </w.rf>
   <form>řidičkou</form>
   <lemma>řidička_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m983-d1e1251-x2-2471">
   <w.rf>
    <LM>w#w-d1e1251-x2-2471</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m983-d1t1256-5">
   <w.rf>
    <LM>w#w-d1t1256-5</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m983-d1t1258-1">
   <w.rf>
    <LM>w#w-d1t1258-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m983-d1t1258-2">
   <w.rf>
    <LM>w#w-d1t1258-2</LM>
   </w.rf>
   <form>menšího</form>
   <lemma>malý</lemma>
   <tag>AAIS2----2A----</tag>
  </m>
  <m id="m983-d1t1258-3">
   <w.rf>
    <LM>w#w-d1t1258-3</LM>
   </w.rf>
   <form>vzrůstu</form>
   <lemma>vzrůst-2</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m983-d-id93949">
   <w.rf>
    <LM>w#w-d-id93949</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
