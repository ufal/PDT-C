<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_045.05.w.gz" />
  </references>
 </head>
 <s id="m045-759">
  <m id="m045-d1t1373-2">
   <w.rf>
    <LM>w#w-d1t1373-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-759-778">
   <w.rf>
    <LM>w#w-759-778</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m045-d-id96623-punct">
   <w.rf>
    <LM>w#w-d-id96623-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1373-8">
   <w.rf>
    <LM>w#w-d1t1373-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1373-9">
   <w.rf>
    <LM>w#w-d1t1373-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1373-10">
   <w.rf>
    <LM>w#w-d1t1373-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1373-11">
   <w.rf>
    <LM>w#w-d1t1373-11</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m045-d1e1342-x3-779">
   <w.rf>
    <LM>w#w-d1e1342-x3-779</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-780">
  <m id="m045-d1t1373-15">
   <w.rf>
    <LM>w#w-d1t1373-15</LM>
   </w.rf>
   <form>Naposled</form>
   <lemma>naposled</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-780-47">
   <w.rf>
    <LM>w#w-780-47</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1373-13">
   <w.rf>
    <LM>w#w-d1t1373-13</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m045-d1t1373-14">
   <w.rf>
    <LM>w#w-d1t1373-14</LM>
   </w.rf>
   <form>viděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d-id96756-punct">
   <w.rf>
    <LM>w#w-d-id96756-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1373-17">
   <w.rf>
    <LM>w#w-d1t1373-17</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1373-18">
   <w.rf>
    <LM>w#w-d1t1373-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1373-19">
   <w.rf>
    <LM>w#w-d1t1373-19</LM>
   </w.rf>
   <form>odjížděla</form>
   <lemma>odjíždět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1373-20">
   <w.rf>
    <LM>w#w-d1t1373-20</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m045-d1t1373-22">
   <w.rf>
    <LM>w#w-d1t1373-22</LM>
   </w.rf>
   <form>Německa</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m045-d1t1373-24">
   <w.rf>
    <LM>w#w-d1t1373-24</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m045-d1t1373-25">
   <w.rf>
    <LM>w#w-d1t1373-25</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m045-780-49">
   <w.rf>
    <LM>w#w-780-49</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1375-2">
   <w.rf>
    <LM>w#w-d1t1375-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1375-1">
   <w.rf>
    <LM>w#w-d1t1375-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1375-3">
   <w.rf>
    <LM>w#w-d1t1375-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1375-4">
   <w.rf>
    <LM>w#w-d1t1375-4</LM>
   </w.rf>
   <form>rakvi</form>
   <lemma>rakev</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m045-780-50">
   <w.rf>
    <LM>w#w-780-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-51">
  <m id="m045-51-451">
   <w.rf>
    <LM>w#w-51-451</LM>
   </w.rf>
   <form>Sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1375-7">
   <w.rf>
    <LM>w#w-d1t1375-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1375-8">
   <w.rf>
    <LM>w#w-d1t1375-8</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m045-d1t1375-9">
   <w.rf>
    <LM>w#w-d1t1375-9</LM>
   </w.rf>
   <form>sháněla</form>
   <lemma>shánět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1375-10">
   <w.rf>
    <LM>w#w-d1t1375-10</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>koňak</form>
   <lemma>koňak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m045-d-id97123-punct">
   <w.rf>
    <LM>w#w-d-id97123-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1377-7">
   <w.rf>
    <LM>w#w-d1t1377-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1377-8">
   <w.rf>
    <LM>w#w-d1t1377-8</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m045-d1t1377-9">
   <w.rf>
    <LM>w#w-d1t1377-9</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m045-d1t1377-10">
   <w.rf>
    <LM>w#w-d1t1377-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1377-11">
   <w.rf>
    <LM>w#w-d1t1377-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1377-12">
   <w.rf>
    <LM>w#w-d1t1377-12</LM>
   </w.rf>
   <form>pomohlo</form>
   <lemma>pomoci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m045-51-58">
   <w.rf>
    <LM>w#w-51-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-55">
  <m id="m045-d1t1377-2">
   <w.rf>
    <LM>w#w-d1t1377-2</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m045-d1t1377-3">
   <w.rf>
    <LM>w#w-d1t1377-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m045-d1t1377-1">
   <w.rf>
    <LM>w#w-d1t1377-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1377-4">
   <w.rf>
    <LM>w#w-d1t1377-4</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m045-d1t1377-5">
   <w.rf>
    <LM>w#w-d1t1377-5</LM>
   </w.rf>
   <form>sehnat</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m045-55-56">
   <w.rf>
    <LM>w#w-55-56</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-57">
  <m id="m045-d1t1377-13">
   <w.rf>
    <LM>w#w-d1t1377-13</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1377-14">
   <w.rf>
    <LM>w#w-d1t1377-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1377-15">
   <w.rf>
    <LM>w#w-d1t1377-15</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m045-d1t1377-16">
   <w.rf>
    <LM>w#w-d1t1377-16</LM>
   </w.rf>
   <form>sehnalo</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m045-d-id97286-punct">
   <w.rf>
    <LM>w#w-d-id97286-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1377-18">
   <w.rf>
    <LM>w#w-d1t1377-18</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1377-20">
   <w.rf>
    <LM>w#w-d1t1377-20</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1377-21">
   <w.rf>
    <LM>w#w-d1t1377-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1377-22">
   <w.rf>
    <LM>w#w-d1t1377-22</LM>
   </w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m045-d1t1377-23">
   <w.rf>
    <LM>w#w-d1t1377-23</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m045-d1t1377-19">
   <w.rf>
    <LM>w#w-d1t1377-19</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m045-57-60">
   <w.rf>
    <LM>w#w-57-60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-61">
  <m id="m045-d1t1377-25">
   <w.rf>
    <LM>w#w-d1t1377-25</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1377-26">
   <w.rf>
    <LM>w#w-d1t1377-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1377-27">
   <w.rf>
    <LM>w#w-d1t1377-27</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1377-28">
   <w.rf>
    <LM>w#w-d1t1377-28</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m045-d1t1379-1">
   <w.rf>
    <LM>w#w-d1t1379-1</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1379-2">
   <w.rf>
    <LM>w#w-d1t1379-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1379-3">
   <w.rf>
    <LM>w#w-d1t1379-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1379-4">
   <w.rf>
    <LM>w#w-d1t1379-4</LM>
   </w.rf>
   <form>naplakala</form>
   <lemma>naplakat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d-m-d1e1342-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1342-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1380-x2">
  <m id="m045-d1t1383-1">
   <w.rf>
    <LM>w#w-d1t1383-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1383-2">
   <w.rf>
    <LM>w#w-d1t1383-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m045-d1t1383-3">
   <w.rf>
    <LM>w#w-d1t1383-3</LM>
   </w.rf>
   <form>mrzí</form>
   <lemma>mrzet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m045-d1e1380-x2-63">
   <w.rf>
    <LM>w#w-d1e1380-x2-63</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-64">
  <m id="m045-d1t1383-4">
   <w.rf>
    <LM>w#w-d1t1383-4</LM>
   </w.rf>
   <form>Jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m045-d1t1383-5">
   <w.rf>
    <LM>w#w-d1t1383-5</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1383-6">
   <w.rf>
    <LM>w#w-d1t1383-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1383-7">
   <w.rf>
    <LM>w#w-d1t1383-7</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m045-d1t1383-8">
   <w.rf>
    <LM>w#w-d1t1383-8</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d-id97706-punct">
   <w.rf>
    <LM>w#w-d-id97706-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1380-x3">
  <m id="m045-d1t1385-1">
   <w.rf>
    <LM>w#w-d1t1385-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m045-d1t1385-2">
   <w.rf>
    <LM>w#w-d1t1385-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1385-3">
   <w.rf>
    <LM>w#w-d1t1385-3</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m045-d1t1385-4">
   <w.rf>
    <LM>w#w-d1t1385-4</LM>
   </w.rf>
   <form>jistě</form>
   <lemma>jistě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1385-5">
   <w.rf>
    <LM>w#w-d1t1385-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m045-d-m-d1e1380-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1380-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1386-x2">
  <m id="m045-d1t1391-1">
   <w.rf>
    <LM>w#w-d1t1391-1</LM>
   </w.rf>
   <form>Ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m045-d1t1391-2">
   <w.rf>
    <LM>w#w-d1t1391-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1391-3">
   <w.rf>
    <LM>w#w-d1t1391-3</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m045-d1t1391-4">
   <w.rf>
    <LM>w#w-d1t1391-4</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1e1386-x2-73">
   <w.rf>
    <LM>w#w-d1e1386-x2-73</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-74">
  <m id="m045-d1t1391-8">
   <w.rf>
    <LM>w#w-d1t1391-8</LM>
   </w.rf>
   <form>Kdokoliv</form>
   <lemma>kdokoliv</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m045-d1t1391-9">
   <w.rf>
    <LM>w#w-d1t1391-9</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m045-74-75">
   <w.rf>
    <LM>w#w-74-75</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1391-10">
   <w.rf>
    <LM>w#w-d1t1391-10</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m045-d1t1391-11">
   <w.rf>
    <LM>w#w-d1t1391-11</LM>
   </w.rf>
   <form>pohostila</form>
   <lemma>pohostit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-74-76">
   <w.rf>
    <LM>w#w-74-76</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-77">
  <m id="m045-d1t1391-13">
   <w.rf>
    <LM>w#w-d1t1391-13</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1391-14">
   <w.rf>
    <LM>w#w-d1t1391-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1391-15">
   <w.rf>
    <LM>w#w-d1t1391-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1393-1">
   <w.rf>
    <LM>w#w-d1t1393-1</LM>
   </w.rf>
   <form>žebrák</form>
   <lemma>žebrák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d-id98114-punct">
   <w.rf>
    <LM>w#w-d-id98114-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1393-3">
   <w.rf>
    <LM>w#w-d1t1393-3</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1393-4">
   <w.rf>
    <LM>w#w-d1t1393-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1393-5">
   <w.rf>
    <LM>w#w-d1t1393-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1393-6">
   <w.rf>
    <LM>w#w-d1t1393-6</LM>
   </w.rf>
   <form>příbuzný</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d-id98184-punct">
   <w.rf>
    <LM>w#w-d-id98184-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1393-8">
   <w.rf>
    <LM>w#w-d1t1393-8</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1393-9">
   <w.rf>
    <LM>w#w-d1t1393-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1393-10">
   <w.rf>
    <LM>w#w-d1t1393-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1393-11">
   <w.rf>
    <LM>w#w-d1t1393-11</LM>
   </w.rf>
   <form>soused</form>
   <lemma>soused</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d-id98255-punct">
   <w.rf>
    <LM>w#w-d-id98255-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1393-13">
   <w.rf>
    <LM>w#w-d1t1393-13</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1393-14">
   <w.rf>
    <LM>w#w-d1t1393-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1393-15">
   <w.rf>
    <LM>w#w-d1t1393-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1393-16">
   <w.rf>
    <LM>w#w-d1t1393-16</LM>
   </w.rf>
   <form>kdokoliv</form>
   <lemma>kdokoliv</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m045-77-78">
   <w.rf>
    <LM>w#w-77-78</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1395-1">
   <w.rf>
    <LM>w#w-d1t1395-1</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m045-d1t1395-3">
   <w.rf>
    <LM>w#w-d1t1395-3</LM>
   </w.rf>
   <form>pohostila</form>
   <lemma>pohostit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-77-79">
   <w.rf>
    <LM>w#w-77-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-80">
  <m id="m045-d1t1400-1">
   <w.rf>
    <LM>w#w-d1t1400-1</LM>
   </w.rf>
   <form>Listonoš</form>
   <lemma>listonoš</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-80-81">
   <w.rf>
    <LM>w#w-80-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1400-2">
   <w.rf>
    <LM>w#w-d1t1400-2</LM>
   </w.rf>
   <form>kdykoliv</form>
   <lemma>kdykoliv_,s_^(^DD**kdykoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1400-3">
   <w.rf>
    <LM>w#w-d1t1400-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1400-4">
   <w.rf>
    <LM>w#w-d1t1400-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m045-d1t1400-5">
   <w.rf>
    <LM>w#w-d1t1400-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m045-d1t1400-6">
   <w.rf>
    <LM>w#w-d1t1400-6</LM>
   </w.rf>
   <form>zastavil</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m045-80-82">
   <w.rf>
    <LM>w#w-80-82</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1402-1">
   <w.rf>
    <LM>w#w-d1t1402-1</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1402-2">
   <w.rf>
    <LM>w#w-d1t1402-2</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m045-d1t1402-3">
   <w.rf>
    <LM>w#w-d1t1402-3</LM>
   </w.rf>
   <form>polévku</form>
   <lemma>polévka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m045-d1t1402-4">
   <w.rf>
    <LM>w#w-d1t1402-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1402-5">
   <w.rf>
    <LM>w#w-d1t1402-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m045-d1t1402-6">
   <w.rf>
    <LM>w#w-d1t1402-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m045-d1t1402-7">
   <w.rf>
    <LM>w#w-d1t1402-7</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m045-80-83">
   <w.rf>
    <LM>w#w-80-83</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-84">
  <m id="m045-d1t1402-12">
   <w.rf>
    <LM>w#w-d1t1402-12</LM>
   </w.rf>
   <form>Dokázala</form>
   <lemma>dokázat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d1t1404-1">
   <w.rf>
    <LM>w#w-d1t1404-1</LM>
   </w.rf>
   <form>každému</form>
   <lemma>každý</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m045-d1t1404-2">
   <w.rf>
    <LM>w#w-d1t1404-2</LM>
   </w.rf>
   <form>posloužit</form>
   <lemma>posloužit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m045-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1406-1">
   <w.rf>
    <LM>w#w-d1t1406-1</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m045-d1t1406-2">
   <w.rf>
    <LM>w#w-d1t1406-2</LM>
   </w.rf>
   <form>politovat</form>
   <lemma>politovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m045-84-86">
   <w.rf>
    <LM>w#w-84-86</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-88">
  <m id="m045-d1t1408-1">
   <w.rf>
    <LM>w#w-d1t1408-1</LM>
   </w.rf>
   <form>Koukala</form>
   <lemma>koukat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d-id98840-punct">
   <w.rf>
    <LM>w#w-d-id98840-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1408-3">
   <w.rf>
    <LM>w#w-d1t1408-3</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m045-88-89">
   <w.rf>
    <LM>w#w-88-89</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m045-d1t1408-5">
   <w.rf>
    <LM>w#w-d1t1408-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m045-d1t1408-6">
   <w.rf>
    <LM>w#w-d1t1408-6</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m045-d-m-d1e1386-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1386-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1409-x2">
  <m id="m045-d1t1412-1">
   <w.rf>
    <LM>w#w-d1t1412-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1412-2">
   <w.rf>
    <LM>w#w-d1t1412-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1412-3">
   <w.rf>
    <LM>w#w-d1t1412-3</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m045-d-m-d1e1409-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1409-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1413-x2">
  <m id="m045-d1t1416-1">
   <w.rf>
    <LM>w#w-d1t1416-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d-m-d1e1413-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1413-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1417-x2">
  <m id="m045-d1t1420-1">
   <w.rf>
    <LM>w#w-d1t1420-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m045-d1t1420-2">
   <w.rf>
    <LM>w#w-d1t1420-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m045-d1t1420-3">
   <w.rf>
    <LM>w#w-d1t1420-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1420-4">
   <w.rf>
    <LM>w#w-d1t1420-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m045-d1t1420-5">
   <w.rf>
    <LM>w#w-d1t1420-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1420-6">
   <w.rf>
    <LM>w#w-d1t1420-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m045-d-id99218-punct">
   <w.rf>
    <LM>w#w-d-id99218-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1421-x2">
  <m id="m045-d1t1426-1">
   <w.rf>
    <LM>w#w-d1t1426-1</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1426-2">
   <w.rf>
    <LM>w#w-d1t1426-2</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m045-d1t1426-3">
   <w.rf>
    <LM>w#w-d1t1426-3</LM>
   </w.rf>
   <form>společný</form>
   <lemma>společný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m045-d1t1426-4">
   <w.rf>
    <LM>w#w-d1t1426-4</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m045-d-id99345-punct">
   <w.rf>
    <LM>w#w-d-id99345-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1426-6">
   <w.rf>
    <LM>w#w-d1t1426-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m045-d1t1426-7">
   <w.rf>
    <LM>w#w-d1t1426-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m045-d1t1426-8">
   <w.rf>
    <LM>w#w-d1t1426-8</LM>
   </w.rf>
   <form>vybavujete</form>
   <lemma>vybavovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m045-d-m-d1e1421-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1421-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1429-x2">
  <m id="m045-d1t1436-1">
   <w.rf>
    <LM>w#w-d1t1436-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1436-2">
   <w.rf>
    <LM>w#w-d1t1436-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1436-3">
   <w.rf>
    <LM>w#w-d1t1436-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1436-5">
   <w.rf>
    <LM>w#w-d1t1436-5</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m045-d1t1436-4">
   <w.rf>
    <LM>w#w-d1t1436-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-d-id99629-punct">
   <w.rf>
    <LM>w#w-d-id99629-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1438-1">
   <w.rf>
    <LM>w#w-d1t1438-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1e1429-x2-102">
   <w.rf>
    <LM>w#w-d1e1429-x2-102</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m045-d1t1438-3">
   <w.rf>
    <LM>w#w-d1t1438-3</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1438-4">
   <w.rf>
    <LM>w#w-d1t1438-4</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1t1438-5">
   <w.rf>
    <LM>w#w-d1t1438-5</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1438-6">
   <w.rf>
    <LM>w#w-d1t1438-6</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m045-d1t1438-7">
   <w.rf>
    <LM>w#w-d1t1438-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1438-8">
   <w.rf>
    <LM>w#w-d1t1438-8</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m045-d1e1429-x2-103">
   <w.rf>
    <LM>w#w-d1e1429-x2-103</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1e1429-x2-104">
   <w.rf>
    <LM>w#w-d1e1429-x2-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-105">
  <m id="m045-d1t1440-3">
   <w.rf>
    <LM>w#w-d1t1440-3</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m045-d1t1440-2">
   <w.rf>
    <LM>w#w-d1t1440-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1440-5">
   <w.rf>
    <LM>w#w-d1t1440-5</LM>
   </w.rf>
   <form>malinký</form>
   <lemma>malinký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m045-d1t1440-4">
   <w.rf>
    <LM>w#w-d1t1440-4</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m045-105-106">
   <w.rf>
    <LM>w#w-105-106</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-107">
  <m id="m045-d1t1445-2">
   <w.rf>
    <LM>w#w-d1t1445-2</LM>
   </w.rf>
   <form>Nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1445-5">
   <w.rf>
    <LM>w#w-d1t1445-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m045-d1t1445-6">
   <w.rf>
    <LM>w#w-d1t1445-6</LM>
   </w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m045-d1t1445-3">
   <w.rf>
    <LM>w#w-d1t1445-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1445-4">
   <w.rf>
    <LM>w#w-d1t1445-4</LM>
   </w.rf>
   <form>nosila</form>
   <lemma>nosit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1445-7">
   <w.rf>
    <LM>w#w-d1t1445-7</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1445-8">
   <w.rf>
    <LM>w#w-d1t1445-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1445-12">
   <w.rf>
    <LM>w#w-d1t1445-12</LM>
   </w.rf>
   <form>špína</form>
   <lemma>špína</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1445-10">
   <w.rf>
    <LM>w#w-d1t1445-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1445-11">
   <w.rf>
    <LM>w#w-d1t1445-11</LM>
   </w.rf>
   <form>nosila</form>
   <lemma>nosit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1445-9">
   <w.rf>
    <LM>w#w-d1t1445-9</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1445-13">
   <w.rf>
    <LM>w#w-d1t1445-13</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-107-108">
   <w.rf>
    <LM>w#w-107-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-109">
  <m id="m045-d1t1447-2">
   <w.rf>
    <LM>w#w-d1t1447-2</LM>
   </w.rf>
   <form>Muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d1t1449-1">
   <w.rf>
    <LM>w#w-d1t1449-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1449-3">
   <w.rf>
    <LM>w#w-d1t1449-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1449-5">
   <w.rf>
    <LM>w#w-d1t1449-5</LM>
   </w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m045-109-110">
   <w.rf>
    <LM>w#w-109-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-111">
  <m id="m045-d1t1449-10">
   <w.rf>
    <LM>w#w-d1t1449-10</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1449-9">
   <w.rf>
    <LM>w#w-d1t1449-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m045-d1t1449-11">
   <w.rf>
    <LM>w#w-d1t1449-11</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1t1449-12">
   <w.rf>
    <LM>w#w-d1t1449-12</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1449-15">
   <w.rf>
    <LM>w#w-d1t1449-15</LM>
   </w.rf>
   <form>hlídat</form>
   <lemma>hlídat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1t1449-14">
   <w.rf>
    <LM>w#w-d1t1449-14</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-111-112">
   <w.rf>
    <LM>w#w-111-112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1449-17">
   <w.rf>
    <LM>w#w-d1t1449-17</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1449-18">
   <w.rf>
    <LM>w#w-d1t1449-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1449-19">
   <w.rf>
    <LM>w#w-d1t1449-19</LM>
   </w.rf>
   <form>vyprala</form>
   <lemma>vyprat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-111-113">
   <w.rf>
    <LM>w#w-111-113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-114">
  <m id="m045-d1t1453-1">
   <w.rf>
    <LM>w#w-d1t1453-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1453-2">
   <w.rf>
    <LM>w#w-d1t1453-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1453-4">
   <w.rf>
    <LM>w#w-d1t1453-4</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m045-d1t1453-3">
   <w.rf>
    <LM>w#w-d1t1453-3</LM>
   </w.rf>
   <form>pračka</form>
   <lemma>pračka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-114-115">
   <w.rf>
    <LM>w#w-114-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-116">
  <m id="m045-d1t1453-9">
   <w.rf>
    <LM>w#w-d1t1453-9</LM>
   </w.rf>
   <form>Pralo</form>
   <lemma>prát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1453-8">
   <w.rf>
    <LM>w#w-d1t1453-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1453-10">
   <w.rf>
    <LM>w#w-d1t1453-10</LM>
   </w.rf>
   <form>ručně</form>
   <lemma>ručně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m045-116-117">
   <w.rf>
    <LM>w#w-116-117</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1453-13">
   <w.rf>
    <LM>w#w-d1t1453-13</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1453-14">
   <w.rf>
    <LM>w#w-d1t1453-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1453-15">
   <w.rf>
    <LM>w#w-d1t1453-15</LM>
   </w.rf>
   <form>hřála</form>
   <lemma>hřát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1453-16">
   <w.rf>
    <LM>w#w-d1t1453-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1453-17">
   <w.rf>
    <LM>w#w-d1t1453-17</LM>
   </w.rf>
   <form>kamnech</form>
   <lemma>kamna</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m045-d1e1429-x3-132">
   <w.rf>
    <LM>w#w-d1e1429-x3-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-133">
  <m id="m045-d1t1453-20">
   <w.rf>
    <LM>w#w-d1t1453-20</LM>
   </w.rf>
   <form>Aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1453-25">
   <w.rf>
    <LM>w#w-d1t1453-25</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m045-d1t1453-26">
   <w.rf>
    <LM>w#w-d1t1453-26</LM>
   </w.rf>
   <form>ohlídala</form>
   <lemma>ohlídat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d1t1453-22">
   <w.rf>
    <LM>w#w-d1t1453-22</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-d-id100787-punct">
   <w.rf>
    <LM>w#w-d-id100787-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1453-28">
   <w.rf>
    <LM>w#w-d1t1453-28</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1453-29">
   <w.rf>
    <LM>w#w-d1t1453-29</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1453-32">
   <w.rf>
    <LM>w#w-d1t1453-32</LM>
   </w.rf>
   <form>udělala</form>
   <lemma>udělat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d1t1453-31">
   <w.rf>
    <LM>w#w-d1t1453-31</LM>
   </w.rf>
   <form>prádlo</form>
   <lemma>prádlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m045-133-142">
   <w.rf>
    <LM>w#w-133-142</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-143">
  <m id="m045-d1t1458-2">
   <w.rf>
    <LM>w#w-d1t1458-2</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1458-3">
   <w.rf>
    <LM>w#w-d1t1458-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1458-4">
   <w.rf>
    <LM>w#w-d1t1458-4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1458-5">
   <w.rf>
    <LM>w#w-d1t1458-5</LM>
   </w.rf>
   <form>výborná</form>
   <lemma>výborný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m045-143-144">
   <w.rf>
    <LM>w#w-143-144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-145">
  <m id="m045-d1t1458-6">
   <w.rf>
    <LM>w#w-d1t1458-6</LM>
   </w.rf>
   <form>Kdykoliv</form>
   <lemma>kdykoliv_,s_^(^DD**kdykoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1458-7">
   <w.rf>
    <LM>w#w-d1t1458-7</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d-id101007-punct">
   <w.rf>
    <LM>w#w-d-id101007-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1458-10">
   <w.rf>
    <LM>w#w-d1t1458-10</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1458-11">
   <w.rf>
    <LM>w#w-d1t1458-11</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m045-d1t1458-12">
   <w.rf>
    <LM>w#w-d1t1458-12</LM>
   </w.rf>
   <form>přinesla</form>
   <lemma>přinést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-145-149">
   <w.rf>
    <LM>w#w-145-149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-150">
  <m id="m045-d1t1460-1">
   <w.rf>
    <LM>w#w-d1t1460-1</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m045-d1t1460-2">
   <w.rf>
    <LM>w#w-d1t1460-2</LM>
   </w.rf>
   <form>cíchy</form>
   <lemma>cícha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-d-id101118-punct">
   <w.rf>
    <LM>w#w-d-id101118-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1460-4">
   <w.rf>
    <LM>w#w-d1t1460-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m045-d1t1460-5">
   <w.rf>
    <LM>w#w-d1t1460-5</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m045-d1t1462-1">
   <w.rf>
    <LM>w#w-d1t1462-1</LM>
   </w.rf>
   <form>naposled</form>
   <lemma>naposled</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1462-2">
   <w.rf>
    <LM>w#w-d1t1462-2</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d-id101190-punct">
   <w.rf>
    <LM>w#w-d-id101190-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1462-5">
   <w.rf>
    <LM>w#w-d1t1462-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1462-7">
   <w.rf>
    <LM>w#w-d1t1462-7</LM>
   </w.rf>
   <form>teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1462-6">
   <w.rf>
    <LM>w#w-d1t1462-6</LM>
   </w.rf>
   <form>loni</form>
   <lemma>loni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1462-8">
   <w.rf>
    <LM>w#w-d1t1462-8</LM>
   </w.rf>
   <form>dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m045-d1t1462-9">
   <w.rf>
    <LM>w#w-d1t1462-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m045-d1t1462-10">
   <w.rf>
    <LM>w#w-d1t1462-10</LM>
   </w.rf>
   <form>sběru</form>
   <lemma>sběr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m045-d-m-d1e1429-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1429-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1478-x2">
  <m id="m045-d1t1481-1">
   <w.rf>
    <LM>w#w-d1t1481-1</LM>
   </w.rf>
   <form>Vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m045-d1t1481-2">
   <w.rf>
    <LM>w#w-d1t1481-2</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1481-3">
   <w.rf>
    <LM>w#w-d1t1481-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1481-4">
   <w.rf>
    <LM>w#w-d1t1481-4</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m045-d-id101555-punct">
   <w.rf>
    <LM>w#w-d-id101555-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1481-6">
   <w.rf>
    <LM>w#w-d1t1481-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1481-7">
   <w.rf>
    <LM>w#w-d1t1481-7</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m045-d1t1481-8">
   <w.rf>
    <LM>w#w-d1t1481-8</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d-id101611-punct">
   <w.rf>
    <LM>w#w-d-id101611-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1482-x2">
  <m id="m045-d1t1485-1">
   <w.rf>
    <LM>w#w-d1t1485-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1e1482-x2-156">
   <w.rf>
    <LM>w#w-d1e1482-x2-156</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1485-2">
   <w.rf>
    <LM>w#w-d1t1485-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1485-3">
   <w.rf>
    <LM>w#w-d1t1485-3</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m045-d1t1485-4">
   <w.rf>
    <LM>w#w-d1t1485-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m045-d-m-d1e1482-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1482-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1486-x2">
  <m id="m045-d1t1489-1">
   <w.rf>
    <LM>w#w-d1t1489-1</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m045-d-id101802-punct">
   <w.rf>
    <LM>w#w-d-id101802-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1489-3">
   <w.rf>
    <LM>w#w-d1t1489-3</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1489-4">
   <w.rf>
    <LM>w#w-d1t1489-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1489-5">
   <w.rf>
    <LM>w#w-d1t1489-5</LM>
   </w.rf>
   <form>poznali</form>
   <lemma>poznat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m045-d-id101857-punct">
   <w.rf>
    <LM>w#w-d-id101857-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1490-x2">
  <m id="m045-d1t1495-2">
   <w.rf>
    <LM>w#w-d1t1495-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1495-3">
   <w.rf>
    <LM>w#w-d1t1495-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1495-5">
   <w.rf>
    <LM>w#w-d1t1495-5</LM>
   </w.rf>
   <form>dohozené</form>
   <lemma>dohozený_^(*4dit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m045-d1e1490-x2-161">
   <w.rf>
    <LM>w#w-d1e1490-x2-161</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-162">
  <m id="m045-d1t1499-1">
   <w.rf>
    <LM>w#w-d1t1499-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m045-d1t1499-2">
   <w.rf>
    <LM>w#w-d1t1499-2</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d1t1499-3">
   <w.rf>
    <LM>w#w-d1t1499-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1499-4">
   <w.rf>
    <LM>w#w-d1t1499-4</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1499-5">
   <w.rf>
    <LM>w#w-d1t1499-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1499-6">
   <w.rf>
    <LM>w#w-d1t1499-6</LM>
   </w.rf>
   <form>bratranec</form>
   <lemma>bratranec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d1t1499-7">
   <w.rf>
    <LM>w#w-d1t1499-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m045-d1t1499-8">
   <w.rf>
    <LM>w#w-d1t1499-8</LM>
   </w.rf>
   <form>sestřenicí</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m045-162-163">
   <w.rf>
    <LM>w#w-162-163</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-165">
  <m id="m045-d1t1499-11">
   <w.rf>
    <LM>w#w-d1t1499-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1499-10">
   <w.rf>
    <LM>w#w-d1t1499-10</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m045-d1t1499-9">
   <w.rf>
    <LM>w#w-d1t1499-9</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1499-12">
   <w.rf>
    <LM>w#w-d1t1499-12</LM>
   </w.rf>
   <form>nemělo</form>
   <lemma>mít</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m045-d1t1499-13">
   <w.rf>
    <LM>w#w-d1t1499-13</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d-id102264-punct">
   <w.rf>
    <LM>w#w-d-id102264-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1499-17">
   <w.rf>
    <LM>w#w-d1t1499-17</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1499-18">
   <w.rf>
    <LM>w#w-d1t1499-18</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1499-19">
   <w.rf>
    <LM>w#w-d1t1499-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-165-166">
   <w.rf>
    <LM>w#w-165-166</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1500-x2">
  <m id="m045-d1t1503-1">
   <w.rf>
    <LM>w#w-d1t1503-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1503-2">
   <w.rf>
    <LM>w#w-d1t1503-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m045-d1t1503-3">
   <w.rf>
    <LM>w#w-d1t1503-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m045-d1e1500-x2-171">
   <w.rf>
    <LM>w#w-d1e1500-x2-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1504-x2">
  <m id="m045-d1t1507-1">
   <w.rf>
    <LM>w#w-d1t1507-1</LM>
   </w.rf>
   <form>Babičky</form>
   <lemma>babička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m045-d1t1507-2">
   <w.rf>
    <LM>w#w-d1t1507-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m045-d1t1507-3">
   <w.rf>
    <LM>w#w-d1t1507-3</LM>
   </w.rf>
   <form>daly</form>
   <lemma>dát-1</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m045-d1t1507-4">
   <w.rf>
    <LM>w#w-d1t1507-4</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1e1504-x2-180">
   <w.rf>
    <LM>w#w-d1e1504-x2-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-181">
  <m id="m045-d1t1507-10">
   <w.rf>
    <LM>w#w-d1t1507-10</LM>
   </w.rf>
   <form>Táta</form>
   <lemma>táta</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m045-d1t1507-11">
   <w.rf>
    <LM>w#w-d1t1507-11</LM>
   </w.rf>
   <form>postavil</form>
   <lemma>postavit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m045-d1t1507-12">
   <w.rf>
    <LM>w#w-d1t1507-12</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m045-d-id102695-punct">
   <w.rf>
    <LM>w#w-d-id102695-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1509-1">
   <w.rf>
    <LM>w#w-d1t1509-1</LM>
   </w.rf>
   <form>potřeboval</form>
   <lemma>potřebovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1509-2">
   <w.rf>
    <LM>w#w-d1t1509-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1509-3">
   <w.rf>
    <LM>w#w-d1t1509-3</LM>
   </w.rf>
   <form>ženit</form>
   <lemma>ženit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1t1509-4">
   <w.rf>
    <LM>w#w-d1t1509-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m045-d1t1509-6">
   <w.rf>
    <LM>w#w-d1t1509-6</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m045-d1t1509-5">
   <w.rf>
    <LM>w#w-d1t1509-5</LM>
   </w.rf>
   <form>potřeboval</form>
   <lemma>potřebovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1509-7">
   <w.rf>
    <LM>w#w-d1t1509-7</LM>
   </w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m045-d1t1509-8">
   <w.rf>
    <LM>w#w-d1t1509-8</LM>
   </w.rf>
   <form>sílu</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m045-181-182">
   <w.rf>
    <LM>w#w-181-182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-183">
  <m id="m045-d1t1513-1">
   <w.rf>
    <LM>w#w-d1t1513-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1513-2">
   <w.rf>
    <LM>w#w-d1t1513-2</LM>
   </w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m045-d1t1513-4">
   <w.rf>
    <LM>w#w-d1t1513-4</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m045-d1t1513-5">
   <w.rf>
    <LM>w#w-d1t1513-5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d1t1513-6">
   <w.rf>
    <LM>w#w-d1t1513-6</LM>
   </w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m045-d1t1513-7">
   <w.rf>
    <LM>w#w-d1t1513-7</LM>
   </w.rf>
   <form>síla</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m045-d1t1513-8">
   <w.rf>
    <LM>w#w-d1t1513-8</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-183-184">
   <w.rf>
    <LM>w#w-183-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-186">
  <m id="m045-d1t1513-10">
   <w.rf>
    <LM>w#w-d1t1513-10</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m045-d1t1513-11">
   <w.rf>
    <LM>w#w-d1t1513-11</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m045-d1t1515-1">
   <w.rf>
    <LM>w#w-d1t1515-1</LM>
   </w.rf>
   <form>dojil</form>
   <lemma>dojit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1515-2">
   <w.rf>
    <LM>w#w-d1t1515-2</LM>
   </w.rf>
   <form>krávy</form>
   <lemma>kráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-186-187">
   <w.rf>
    <LM>w#w-186-187</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-190">
  <m id="m045-d1t1515-3">
   <w.rf>
    <LM>w#w-d1t1515-3</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d1t1515-4">
   <w.rf>
    <LM>w#w-d1t1515-4</LM>
   </w.rf>
   <form>dojičky</form>
   <lemma>dojička_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m045-d1t1515-5">
   <w.rf>
    <LM>w#w-d1t1515-5</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m045-d1t1515-6">
   <w.rf>
    <LM>w#w-d1t1515-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m045-d1t1515-7">
   <w.rf>
    <LM>w#w-d1t1515-7</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-190-191">
   <w.rf>
    <LM>w#w-190-191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-193">
  <m id="m045-d1t1518-1">
   <w.rf>
    <LM>w#w-d1t1518-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m045-d1t1518-2">
   <w.rf>
    <LM>w#w-d1t1518-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m045-d1t1518-3">
   <w.rf>
    <LM>w#w-d1t1518-3</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1518-4">
   <w.rf>
    <LM>w#w-d1t1518-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1518-5">
   <w.rf>
    <LM>w#w-d1t1518-5</LM>
   </w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m045-193-194">
   <w.rf>
    <LM>w#w-193-194</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-196">
  <m id="m045-d1t1518-7">
   <w.rf>
    <LM>w#w-d1t1518-7</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m045-d1t1518-8">
   <w.rf>
    <LM>w#w-d1t1518-8</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m045-d1t1518-9">
   <w.rf>
    <LM>w#w-d1t1518-9</LM>
   </w.rf>
   <form>sekal</form>
   <lemma>sekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d-id103273-punct">
   <w.rf>
    <LM>w#w-d-id103273-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1518-11">
   <w.rf>
    <LM>w#w-d1t1518-11</LM>
   </w.rf>
   <form>hrabal</form>
   <lemma>hrabat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1e1521-x2-206">
   <w.rf>
    <LM>w#w-d1e1521-x2-206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1526-1">
   <w.rf>
    <LM>w#w-d1t1526-1</LM>
   </w.rf>
   <form>pěstoval</form>
   <lemma>pěstovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1526-2">
   <w.rf>
    <LM>w#w-d1t1526-2</LM>
   </w.rf>
   <form>husy</form>
   <lemma>husa</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-d-id103474-punct">
   <w.rf>
    <LM>w#w-d-id103474-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1526-4">
   <w.rf>
    <LM>w#w-d1t1526-4</LM>
   </w.rf>
   <form>kuřata</form>
   <lemma>kuře</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m045-d-id103498-punct">
   <w.rf>
    <LM>w#w-d-id103498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m045-d1t1526-6">
   <w.rf>
    <LM>w#w-d1t1526-6</LM>
   </w.rf>
   <form>slepice</form>
   <lemma>slepice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m045-d1e1521-x2-215">
   <w.rf>
    <LM>w#w-d1e1521-x2-215</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1521-x3">
  <m id="m045-d1t1528-1">
   <w.rf>
    <LM>w#w-d1t1528-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m045-d-m-d1e1521-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1521-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1529-x2">
  <m id="m045-d1t1532-1">
   <w.rf>
    <LM>w#w-d1t1532-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m045-d1t1532-2">
   <w.rf>
    <LM>w#w-d1t1532-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m045-d1t1532-3">
   <w.rf>
    <LM>w#w-d1t1532-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1532-4">
   <w.rf>
    <LM>w#w-d1t1532-4</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m045-d1t1532-5">
   <w.rf>
    <LM>w#w-d1t1532-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m045-d1t1532-6">
   <w.rf>
    <LM>w#w-d1t1532-6</LM>
   </w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m045-d1t1532-7">
   <w.rf>
    <LM>w#w-d1t1532-7</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m045-d-m-d1e1529-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1529-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1539-x2">
  <m id="m045-d1t1542-1">
   <w.rf>
    <LM>w#w-d1t1542-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m045-220-221">
   <w.rf>
    <LM>w#w-220-221</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-220">
  <m id="m045-d1t1542-3">
   <w.rf>
    <LM>w#w-d1t1542-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m045-d1t1542-4">
   <w.rf>
    <LM>w#w-d1t1542-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m045-d1t1542-5">
   <w.rf>
    <LM>w#w-d1t1542-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m045-d1t1542-6">
   <w.rf>
    <LM>w#w-d1t1542-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m045-d1t1542-7">
   <w.rf>
    <LM>w#w-d1t1542-7</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m045-d-id103863-punct">
   <w.rf>
    <LM>w#w-d-id103863-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1543-x2">
  <m id="m045-d1t1546-1">
   <w.rf>
    <LM>w#w-d1t1546-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d-m-d1e1543-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1543-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m045-d1e1547-x2">
  <m id="m045-d1t1550-1">
   <w.rf>
    <LM>w#w-d1t1550-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m045-d1t1550-2">
   <w.rf>
    <LM>w#w-d1t1550-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m045-d1t1550-3">
   <w.rf>
    <LM>w#w-d1t1550-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m045-d1t1550-4">
   <w.rf>
    <LM>w#w-d1t1550-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m045-d-id104055-punct">
   <w.rf>
    <LM>w#w-d-id104055-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
