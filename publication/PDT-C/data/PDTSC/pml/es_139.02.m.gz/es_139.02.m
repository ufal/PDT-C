<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_139.02.w.gz" />
  </references>
 </head>
 <s id="m139-d1e829-x2">
  <m id="m139-d1t832-1">
   <w.rf>
    <LM>w#w-d1t832-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t832-2">
   <w.rf>
    <LM>w#w-d1t832-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t832-3">
   <w.rf>
    <LM>w#w-d1t832-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t832-4">
   <w.rf>
    <LM>w#w-d1t832-4</LM>
   </w.rf>
   <form>sraz</form>
   <lemma>sraz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t832-6">
   <w.rf>
    <LM>w#w-d1t832-6</LM>
   </w.rf>
   <form>naposled</form>
   <lemma>naposled</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d-id77652-punct">
   <w.rf>
    <LM>w#w-d-id77652-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e833-x2">
  <m id="m139-d1t840-1">
   <w.rf>
    <LM>w#w-d1t840-1</LM>
   </w.rf>
   <form>Naposledy</form>
   <lemma>naposledy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t842-1">
   <w.rf>
    <LM>w#w-d1t842-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t844-1">
   <w.rf>
    <LM>w#w-d1t844-1</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t847-1">
   <w.rf>
    <LM>w#w-d1t847-1</LM>
   </w.rf>
   <form>sraz</form>
   <lemma>sraz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t849-1">
   <w.rf>
    <LM>w#w-d1t849-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t849-2">
   <w.rf>
    <LM>w#w-d1t849-2</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m139-d1t849-3">
   <w.rf>
    <LM>w#w-d1t849-3</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m139-d-id77867-punct">
   <w.rf>
    <LM>w#w-d-id77867-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t849-5">
   <w.rf>
    <LM>w#w-d1t849-5</LM>
   </w.rf>
   <form>loni</form>
   <lemma>loni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t849-6">
   <w.rf>
    <LM>w#w-d1t849-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t849-7">
   <w.rf>
    <LM>w#w-d1t849-7</LM>
   </w.rf>
   <form>nevyšlo</form>
   <lemma>vyjít</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m139-d-id77922-punct">
   <w.rf>
    <LM>w#w-d-id77922-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t851-1">
   <w.rf>
    <LM>w#w-d1t851-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t851-2">
   <w.rf>
    <LM>w#w-d1t851-2</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t851-3">
   <w.rf>
    <LM>w#w-d1t851-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t851-4">
   <w.rf>
    <LM>w#w-d1t851-4</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t851-5">
   <w.rf>
    <LM>w#w-d1t851-5</LM>
   </w.rf>
   <form>naplánováno</form>
   <lemma>naplánovat</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m139-d1t851-6">
   <w.rf>
    <LM>w#w-d1t851-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t851-7">
   <w.rf>
    <LM>w#w-d1t851-7</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t851-8">
   <w.rf>
    <LM>w#w-d1t851-8</LM>
   </w.rf>
   <form>víkend</form>
   <lemma>víkend</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t851-9">
   <w.rf>
    <LM>w#w-d1t851-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t851-10">
   <w.rf>
    <LM>w#w-d1t851-10</LM>
   </w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1e833-x2-343">
   <w.rf>
    <LM>w#w-d1e833-x2-343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-342">
  <m id="m139-d1t853-2">
   <w.rf>
    <LM>w#w-d1t853-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t853-4">
   <w.rf>
    <LM>w#w-d1t853-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t853-5">
   <w.rf>
    <LM>w#w-d1t853-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t853-6">
   <w.rf>
    <LM>w#w-d1t853-6</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS7----------</tag>
  </m>
  <m id="m139-d1t853-7">
   <w.rf>
    <LM>w#w-d1t853-7</LM>
   </w.rf>
   <form>spolužačkou</form>
   <lemma>spolužačka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m139-d1t855-1">
   <w.rf>
    <LM>w#w-d1t855-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t853-3">
   <w.rf>
    <LM>w#w-d1t853-3</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t855-2">
   <w.rf>
    <LM>w#w-d1t855-2</LM>
   </w.rf>
   <form>organizujeme</form>
   <lemma>organizovat</lemma>
   <tag>VB-P---1P-AAB--</tag>
  </m>
  <m id="m139-d-id78252-punct">
   <w.rf>
    <LM>w#w-d-id78252-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t857-1">
   <w.rf>
    <LM>w#w-d1t857-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t857-2">
   <w.rf>
    <LM>w#w-d1t857-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t857-3">
   <w.rf>
    <LM>w#w-d1t857-3</LM>
   </w.rf>
   <form>zůstaly</form>
   <lemma>zůstat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m139-d1t862-1">
   <w.rf>
    <LM>w#w-d1t862-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t862-3">
   <w.rf>
    <LM>w#w-d1t862-3</LM>
   </w.rf>
   <form>Kolíně</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1t862-5">
   <w.rf>
    <LM>w#w-d1t862-5</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m139-d1t862-6">
   <w.rf>
    <LM>w#w-d1t862-6</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m139-342-350">
   <w.rf>
    <LM>w#w-342-350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-349">
  <m id="m139-d1t864-2">
   <w.rf>
    <LM>w#w-d1t864-2</LM>
   </w.rf>
   <form>Ostatním</form>
   <lemma>ostatní</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m139-d1t864-3">
   <w.rf>
    <LM>w#w-d1t864-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t864-4">
   <w.rf>
    <LM>w#w-d1t864-4</LM>
   </w.rf>
   <form>musíme</form>
   <lemma>muset</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t866-1">
   <w.rf>
    <LM>w#w-d1t866-1</LM>
   </w.rf>
   <form>písemně</form>
   <lemma>písemně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t868-1">
   <w.rf>
    <LM>w#w-d1t868-1</LM>
   </w.rf>
   <form>oznámit</form>
   <lemma>oznámit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m139-349-352">
   <w.rf>
    <LM>w#w-349-352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-351">
  <m id="m139-d1t868-3">
   <w.rf>
    <LM>w#w-d1t868-3</LM>
   </w.rf>
   <form>Doufám</form>
   <lemma>doufat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d-id78567-punct">
   <w.rf>
    <LM>w#w-d-id78567-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t868-5">
   <w.rf>
    <LM>w#w-d1t868-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t868-6">
   <w.rf>
    <LM>w#w-d1t868-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t868-7">
   <w.rf>
    <LM>w#w-d1t868-7</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t868-8">
   <w.rf>
    <LM>w#w-d1t868-8</LM>
   </w.rf>
   <form>sejdem</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP-6</tag>
  </m>
  <m id="m139-d-m-d1e833-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e833-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e869-x2">
  <m id="m139-d1t872-1">
   <w.rf>
    <LM>w#w-d1t872-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t872-2">
   <w.rf>
    <LM>w#w-d1t872-2</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m139-d1t872-3">
   <w.rf>
    <LM>w#w-d1t872-3</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m139-d1t872-4">
   <w.rf>
    <LM>w#w-d1t872-4</LM>
   </w.rf>
   <form>sraz</form>
   <lemma>sraz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-d1t872-5">
   <w.rf>
    <LM>w#w-d1t872-5</LM>
   </w.rf>
   <form>vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d-id78768-punct">
   <w.rf>
    <LM>w#w-d-id78768-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e873-x2">
  <m id="m139-d1t880-3">
   <w.rf>
    <LM>w#w-d1t880-3</LM>
   </w.rf>
   <form>Vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t880-4">
   <w.rf>
    <LM>w#w-d1t880-4</LM>
   </w.rf>
   <form>pokaždé</form>
   <lemma>pokaždé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t880-5">
   <w.rf>
    <LM>w#w-d1t880-5</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1e873-x2-376">
   <w.rf>
    <LM>w#w-d1e873-x2-376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-375">
  <m id="m139-d1t880-9">
   <w.rf>
    <LM>w#w-d1t880-9</LM>
   </w.rf>
   <form>Dáme</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m139-d1t880-8">
   <w.rf>
    <LM>w#w-d1t880-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t880-10">
   <w.rf>
    <LM>w#w-d1t880-10</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m139-d1t880-11">
   <w.rf>
    <LM>w#w-d1t880-11</LM>
   </w.rf>
   <form>dobrého</form>
   <lemma>dobrý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m139-d1t880-13">
   <w.rf>
    <LM>w#w-d1t880-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m139-d1t880-14">
   <w.rf>
    <LM>w#w-d1t880-14</LM>
   </w.rf>
   <form>jídlu</form>
   <lemma>jídlo</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m139-d-id79058-punct">
   <w.rf>
    <LM>w#w-d-id79058-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t880-16">
   <w.rf>
    <LM>w#w-d1t880-16</LM>
   </w.rf>
   <form>připijem</form>
   <lemma>připít</lemma>
   <tag>VB-P---1P-AAP-6</tag>
  </m>
  <m id="m139-d1t880-17">
   <w.rf>
    <LM>w#w-d1t880-17</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t880-20">
   <w.rf>
    <LM>w#w-d1t880-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t880-21">
   <w.rf>
    <LM>w#w-d1t880-21</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t880-22">
   <w.rf>
    <LM>w#w-d1t880-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t880-23">
   <w.rf>
    <LM>w#w-d1t880-23</LM>
   </w.rf>
   <form>vypravuje</form>
   <lemma>vypravovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-375-387">
   <w.rf>
    <LM>w#w-375-387</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t882-2">
   <w.rf>
    <LM>w#w-d1t882-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m139-d1t882-3">
   <w.rf>
    <LM>w#w-d1t882-3</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m139-d1t882-4">
   <w.rf>
    <LM>w#w-d1t882-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t882-5">
   <w.rf>
    <LM>w#w-d1t882-5</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m139-d1t882-6">
   <w.rf>
    <LM>w#w-d1t882-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t882-7">
   <w.rf>
    <LM>w#w-d1t882-7</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-375-377">
   <w.rf>
    <LM>w#w-375-377</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t882-8">
   <w.rf>
    <LM>w#w-d1t882-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t882-9">
   <w.rf>
    <LM>w#w-d1t882-9</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t882-10">
   <w.rf>
    <LM>w#w-d1t882-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t882-11">
   <w.rf>
    <LM>w#w-d1t882-11</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m139-d1t882-12">
   <w.rf>
    <LM>w#w-d1t882-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t882-13">
   <w.rf>
    <LM>w#w-d1t882-13</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m139-d1t882-14">
   <w.rf>
    <LM>w#w-d1t882-14</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-375-378">
   <w.rf>
    <LM>w#w-375-378</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t884-1">
   <w.rf>
    <LM>w#w-d1t884-1</LM>
   </w.rf>
   <form>potkalo</form>
   <lemma>potkat</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m139-375-379">
   <w.rf>
    <LM>w#w-375-379</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-364">
  <m id="m139-d1t884-3">
   <w.rf>
    <LM>w#w-d1t884-3</LM>
   </w.rf>
   <form>Ukážeme</form>
   <lemma>ukázat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m139-d1t884-4">
   <w.rf>
    <LM>w#w-d1t884-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t884-5">
   <w.rf>
    <LM>w#w-d1t884-5</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t884-6">
   <w.rf>
    <LM>w#w-d1t884-6</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m139-d-id79504-punct">
   <w.rf>
    <LM>w#w-d-id79504-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t884-8">
   <w.rf>
    <LM>w#w-d1t884-8</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t884-9">
   <w.rf>
    <LM>w#w-d1t884-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t884-10">
   <w.rf>
    <LM>w#w-d1t884-10</LM>
   </w.rf>
   <form>vnoučat</form>
   <lemma>vnouče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m139-d-id79569-punct">
   <w.rf>
    <LM>w#w-d-id79569-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-365">
  <m id="m139-d1t889-3">
   <w.rf>
    <LM>w#w-d1t889-3</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t889-4">
   <w.rf>
    <LM>w#w-d1t889-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t889-5">
   <w.rf>
    <LM>w#w-d1t889-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t889-6">
   <w.rf>
    <LM>w#w-d1t889-6</LM>
   </w.rf>
   <form>samá</form>
   <lemma>samý</lemma>
   <tag>PLNP1----------</tag>
  </m>
  <m id="m139-d1t889-7">
   <w.rf>
    <LM>w#w-d1t889-7</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m139-d-id79701-punct">
   <w.rf>
    <LM>w#w-d-id79701-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t889-9">
   <w.rf>
    <LM>w#w-d1t889-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t889-10">
   <w.rf>
    <LM>w#w-d1t889-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m139-d1t889-11">
   <w.rf>
    <LM>w#w-d1t889-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t889-14">
   <w.rf>
    <LM>w#w-d1t889-14</LM>
   </w.rf>
   <form>ženské</form>
   <lemma>ženský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m139-d1t889-15">
   <w.rf>
    <LM>w#w-d1t889-15</LM>
   </w.rf>
   <form>řeči</form>
   <lemma>řeč</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-id79818-punct">
   <w.rf>
    <LM>w#w-d-id79818-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t889-17">
   <w.rf>
    <LM>w#w-d1t889-17</LM>
   </w.rf>
   <form>povídání</form>
   <lemma>povídání_^(*3at)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e873-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e873-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e896-x2">
  <m id="m139-d1t899-1">
   <w.rf>
    <LM>w#w-d1t899-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m139-d1t899-2">
   <w.rf>
    <LM>w#w-d1t899-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t899-3">
   <w.rf>
    <LM>w#w-d1t899-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t899-4">
   <w.rf>
    <LM>w#w-d1t899-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m139-d1t899-5">
   <w.rf>
    <LM>w#w-d1t899-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d-id79973-punct">
   <w.rf>
    <LM>w#w-d-id79973-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e900-x2">
  <m id="m139-d1t903-3">
   <w.rf>
    <LM>w#w-d1t903-3</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t903-4">
   <w.rf>
    <LM>w#w-d1t903-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m139-d1t903-5">
   <w.rf>
    <LM>w#w-d1t903-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t905-1">
   <w.rf>
    <LM>w#w-d1t905-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t905-2">
   <w.rf>
    <LM>w#w-d1t905-2</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m139-d1t905-3">
   <w.rf>
    <LM>w#w-d1t905-3</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m139-d1t905-6">
   <w.rf>
    <LM>w#w-d1t905-6</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d-id80222-punct">
   <w.rf>
    <LM>w#w-d-id80222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-416">
  <m id="m139-d1t907-2">
   <w.rf>
    <LM>w#w-d1t907-2</LM>
   </w.rf>
   <form>Vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t907-3">
   <w.rf>
    <LM>w#w-d1t907-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t907-4">
   <w.rf>
    <LM>w#w-d1t907-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d-id80277-punct">
   <w.rf>
    <LM>w#w-d-id80277-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t907-6">
   <w.rf>
    <LM>w#w-d1t907-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t907-7">
   <w.rf>
    <LM>w#w-d1t907-7</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m139-d1t907-8">
   <w.rf>
    <LM>w#w-d1t907-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t907-9">
   <w.rf>
    <LM>w#w-d1t907-9</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m139-d1t907-10">
   <w.rf>
    <LM>w#w-d1t907-10</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m139-416-428">
   <w.rf>
    <LM>w#w-416-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-427">
  <m id="m139-d1t911-2">
   <w.rf>
    <LM>w#w-d1t911-2</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m139-d1t911-3">
   <w.rf>
    <LM>w#w-d1t911-3</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-id80437-punct">
   <w.rf>
    <LM>w#w-d-id80437-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t911-5">
   <w.rf>
    <LM>w#w-d1t911-5</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m139-d1t914-2">
   <w.rf>
    <LM>w#w-d1t914-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t914-1">
   <w.rf>
    <LM>w#w-d1t914-1</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t914-3">
   <w.rf>
    <LM>w#w-d1t914-3</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m139-d1t916-1">
   <w.rf>
    <LM>w#w-d1t916-1</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m139-d-id80536-punct">
   <w.rf>
    <LM>w#w-d-id80536-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t916-4">
   <w.rf>
    <LM>w#w-d1t916-4</LM>
   </w.rf>
   <form>říkaly</form>
   <lemma>říkat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-427-436">
   <w.rf>
    <LM>w#w-427-436</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-427-437">
   <w.rf>
    <LM>w#w-427-437</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t916-5">
   <w.rf>
    <LM>w#w-d1t916-5</LM>
   </w.rf>
   <form>Té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m139-d1t916-6">
   <w.rf>
    <LM>w#w-d1t916-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t916-7">
   <w.rf>
    <LM>w#w-d1t916-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t918-1">
   <w.rf>
    <LM>w#w-d1t918-1</LM>
   </w.rf>
   <form>sedmnáct</form>
   <lemma>sedmnáct`17</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m139-427-598">
   <w.rf>
    <LM>w#w-427-598</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-427-439">
   <w.rf>
    <LM>w#w-427-439</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-599">
  <m id="m139-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>Tipovaly</form>
   <lemma>tipovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t922-3">
   <w.rf>
    <LM>w#w-d1t922-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m139-d1t922-5">
   <w.rf>
    <LM>w#w-d1t922-5</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m139-427-440">
   <w.rf>
    <LM>w#w-427-440</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-417">
  <m id="m139-d1t933-1">
   <w.rf>
    <LM>w#w-d1t933-1</LM>
   </w.rf>
   <form>Svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t935-1">
   <w.rf>
    <LM>w#w-d1t935-1</LM>
   </w.rf>
   <form>proběhla</form>
   <lemma>proběhnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m139-d1t935-2">
   <w.rf>
    <LM>w#w-d1t935-2</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t935-3">
   <w.rf>
    <LM>w#w-d1t935-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t935-4">
   <w.rf>
    <LM>w#w-d1t935-4</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m139-d-id80881-punct">
   <w.rf>
    <LM>w#w-d-id80881-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t935-6">
   <w.rf>
    <LM>w#w-d1t935-6</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t935-7">
   <w.rf>
    <LM>w#w-d1t935-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t935-8">
   <w.rf>
    <LM>w#w-d1t935-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t935-9">
   <w.rf>
    <LM>w#w-d1t935-9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t935-10">
   <w.rf>
    <LM>w#w-d1t935-10</LM>
   </w.rf>
   <form>babičku</form>
   <lemma>babička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id80968-punct">
   <w.rf>
    <LM>w#w-d-id80968-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t940-1">
   <w.rf>
    <LM>w#w-d1t940-1</LM>
   </w.rf>
   <form>tetu</form>
   <lemma>teta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id81010-punct">
   <w.rf>
    <LM>w#w-d-id81010-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t940-3">
   <w.rf>
    <LM>w#w-d1t940-3</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m139-d1t940-4">
   <w.rf>
    <LM>w#w-d1t940-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m139-d1t940-5">
   <w.rf>
    <LM>w#w-d1t940-5</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t940-6">
   <w.rf>
    <LM>w#w-d1t940-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t940-7">
   <w.rf>
    <LM>w#w-d1t940-7</LM>
   </w.rf>
   <form>svědka</form>
   <lemma>svědek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m139-417-454">
   <w.rf>
    <LM>w#w-417-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-453">
  <m id="m139-d1t942-2">
   <w.rf>
    <LM>w#w-d1t942-2</LM>
   </w.rf>
   <form>Příští</form>
   <lemma>příští</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t942-3">
   <w.rf>
    <LM>w#w-d1t942-3</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t942-4">
   <w.rf>
    <LM>w#w-d1t942-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t942-5">
   <w.rf>
    <LM>w#w-d1t942-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t942-6">
   <w.rf>
    <LM>w#w-d1t942-6</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m139-d1t944-1">
   <w.rf>
    <LM>w#w-d1t944-1</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m139-d1t946-1">
   <w.rf>
    <LM>w#w-d1t946-1</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m139-d-id81266-punct">
   <w.rf>
    <LM>w#w-d-id81266-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t946-5">
   <w.rf>
    <LM>w#w-d1t946-5</LM>
   </w.rf>
   <form>uteklo</form>
   <lemma>utéci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m139-d1t946-4">
   <w.rf>
    <LM>w#w-d1t946-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d-m-d1e900-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e900-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e947-x2">
  <m id="m139-d1t950-1">
   <w.rf>
    <LM>w#w-d1t950-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t950-2">
   <w.rf>
    <LM>w#w-d1t950-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t950-3">
   <w.rf>
    <LM>w#w-d1t950-3</LM>
   </w.rf>
   <form>poznala</form>
   <lemma>poznat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1t950-4">
   <w.rf>
    <LM>w#w-d1t950-4</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8MS4----------</tag>
  </m>
  <m id="m139-d1t950-5">
   <w.rf>
    <LM>w#w-d1t950-5</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m139-d-id81452-punct">
   <w.rf>
    <LM>w#w-d-id81452-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e951-x2">
  <m id="m139-d1t958-3">
   <w.rf>
    <LM>w#w-d1t958-3</LM>
   </w.rf>
   <form>Poznali</form>
   <lemma>poznat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t958-4">
   <w.rf>
    <LM>w#w-d1t958-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t958-5">
   <w.rf>
    <LM>w#w-d1t958-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t958-6">
   <w.rf>
    <LM>w#w-d1t958-6</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t958-7">
   <w.rf>
    <LM>w#w-d1t958-7</LM>
   </w.rf>
   <form>prozaicky</form>
   <lemma>prozaicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t958-8">
   <w.rf>
    <LM>w#w-d1t958-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t958-9">
   <w.rf>
    <LM>w#w-d1t958-9</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m139-d1t958-10">
   <w.rf>
    <LM>w#w-d1t958-10</LM>
   </w.rf>
   <form>taneční</form>
   <lemma>taneční-1</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m139-d1t958-11">
   <w.rf>
    <LM>w#w-d1t958-11</LM>
   </w.rf>
   <form>zábavě</form>
   <lemma>zábava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d-id81701-punct">
   <w.rf>
    <LM>w#w-d-id81701-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t958-13">
   <w.rf>
    <LM>w#w-d1t958-13</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t958-14">
   <w.rf>
    <LM>w#w-d1t958-14</LM>
   </w.rf>
   <form>pocházel</form>
   <lemma>pocházet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t960-1">
   <w.rf>
    <LM>w#w-d1t960-1</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m139-d1t962-1">
   <w.rf>
    <LM>w#w-d1t962-1</LM>
   </w.rf>
   <form>sousední</form>
   <lemma>sousední</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m139-d1t965-1">
   <w.rf>
    <LM>w#w-d1t965-1</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1e951-x2-465">
   <w.rf>
    <LM>w#w-d1e951-x2-465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-464">
  <m id="m139-d1t965-5">
   <w.rf>
    <LM>w#w-d1t965-5</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m139-d1t965-6">
   <w.rf>
    <LM>w#w-d1t965-6</LM>
   </w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m139-d1t965-8">
   <w.rf>
    <LM>w#w-d1t965-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m139-d1t965-9">
   <w.rf>
    <LM>w#w-d1t965-9</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m139-d1t965-7">
   <w.rf>
    <LM>w#w-d1t965-7</LM>
   </w.rf>
   <form>přicházeli</form>
   <lemma>přicházet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t965-10">
   <w.rf>
    <LM>w#w-d1t965-10</LM>
   </w.rf>
   <form>tancovat</form>
   <lemma>tancovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m139-d-id81952-punct">
   <w.rf>
    <LM>w#w-d-id81952-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t967-2">
   <w.rf>
    <LM>w#w-d1t967-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t967-3">
   <w.rf>
    <LM>w#w-d1t967-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t967-4">
   <w.rf>
    <LM>w#w-d1t967-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t969-1">
   <w.rf>
    <LM>w#w-d1t969-1</LM>
   </w.rf>
   <form>seznámení</form>
   <lemma>seznámení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m139-d1t973-1">
   <w.rf>
    <LM>w#w-d1t973-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t973-2">
   <w.rf>
    <LM>w#w-d1t973-2</LM>
   </w.rf>
   <form>tanci</form>
   <lemma>tanec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d-m-d1e951-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e951-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e980-x2">
  <m id="m139-d1t983-1">
   <w.rf>
    <LM>w#w-d1t983-1</LM>
   </w.rf>
   <form>Zamilovali</form>
   <lemma>zamilovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t983-2">
   <w.rf>
    <LM>w#w-d1t983-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t983-3">
   <w.rf>
    <LM>w#w-d1t983-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t983-4">
   <w.rf>
    <LM>w#w-d1t983-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t983-5">
   <w.rf>
    <LM>w#w-d1t983-5</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m139-d1t983-6">
   <w.rf>
    <LM>w#w-d1t983-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t983-7">
   <w.rf>
    <LM>w#w-d1t983-7</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m139-d1t983-8">
   <w.rf>
    <LM>w#w-d1t983-8</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d-id82268-punct">
   <w.rf>
    <LM>w#w-d-id82268-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e984-x2">
  <m id="m139-d1t993-1">
   <w.rf>
    <LM>w#w-d1t993-1</LM>
   </w.rf>
   <form>Úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t993-2">
   <w.rf>
    <LM>w#w-d1t993-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t993-3">
   <w.rf>
    <LM>w#w-d1t993-3</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m139-d1t993-4">
   <w.rf>
    <LM>w#w-d1t993-4</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t993-5">
   <w.rf>
    <LM>w#w-d1t993-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t993-6">
   <w.rf>
    <LM>w#w-d1t993-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t993-7">
   <w.rf>
    <LM>w#w-d1t993-7</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m139-d1e984-x2-522">
   <w.rf>
    <LM>w#w-d1e984-x2-522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-482">
  <m id="m139-d1t993-9">
   <w.rf>
    <LM>w#w-d1t993-9</LM>
   </w.rf>
   <form>Potkávali</form>
   <lemma>potkávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t993-10">
   <w.rf>
    <LM>w#w-d1t993-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t993-11">
   <w.rf>
    <LM>w#w-d1t993-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d-id82551-punct">
   <w.rf>
    <LM>w#w-d-id82551-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t998-1">
   <w.rf>
    <LM>w#w-d1t998-1</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m139-d1t998-2">
   <w.rf>
    <LM>w#w-d1t998-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t998-3">
   <w.rf>
    <LM>w#w-d1t998-3</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t998-4">
   <w.rf>
    <LM>w#w-d1t998-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t998-5">
   <w.rf>
    <LM>w#w-d1t998-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t998-6">
   <w.rf>
    <LM>w#w-d1t998-6</LM>
   </w.rf>
   <form>kina</form>
   <lemma>kino</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m139-482-526">
   <w.rf>
    <LM>w#w-482-526</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-483">
  <m id="m139-d1t1000-3">
   <w.rf>
    <LM>w#w-d1t1000-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1000-4">
   <w.rf>
    <LM>w#w-d1t1000-4</LM>
   </w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1t1000-5">
   <w.rf>
    <LM>w#w-d1t1000-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1000-7">
   <w.rf>
    <LM>w#w-d1t1000-7</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1000-8">
   <w.rf>
    <LM>w#w-d1t1000-8</LM>
   </w.rf>
   <form>vyplynulo</form>
   <lemma>vyplynout</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m139-d-id82811-punct">
   <w.rf>
    <LM>w#w-d-id82811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1004-1">
   <w.rf>
    <LM>w#w-d1t1004-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1004-2">
   <w.rf>
    <LM>w#w-d1t1004-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1004-3">
   <w.rf>
    <LM>w#w-d1t1004-3</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1004-4">
   <w.rf>
    <LM>w#w-d1t1004-4</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1004-5">
   <w.rf>
    <LM>w#w-d1t1004-5</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m139-d1t1004-6">
   <w.rf>
    <LM>w#w-d1t1004-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1004-7">
   <w.rf>
    <LM>w#w-d1t1004-7</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1004-8">
   <w.rf>
    <LM>w#w-d1t1004-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m139-d-id82962-punct">
   <w.rf>
    <LM>w#w-d-id82962-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1004-10">
   <w.rf>
    <LM>w#w-d1t1004-10</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1004-11">
   <w.rf>
    <LM>w#w-d1t1004-11</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1004-12">
   <w.rf>
    <LM>w#w-d1t1004-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1004-13">
   <w.rf>
    <LM>w#w-d1t1004-13</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-483-531">
   <w.rf>
    <LM>w#w-483-531</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-484">
  <m id="m139-d1t1011-1">
   <w.rf>
    <LM>w#w-d1t1011-1</LM>
   </w.rf>
   <form>Vydrželi</form>
   <lemma>vydržet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1011-2">
   <w.rf>
    <LM>w#w-d1t1011-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1011-3">
   <w.rf>
    <LM>w#w-d1t1011-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m139-d1t1011-4">
   <w.rf>
    <LM>w#w-d1t1011-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m139-d1t1011-5">
   <w.rf>
    <LM>w#w-d1t1011-5</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-d-id83153-punct">
   <w.rf>
    <LM>w#w-d-id83153-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1013-1">
   <w.rf>
    <LM>w#w-d1t1013-1</LM>
   </w.rf>
   <form>psali</form>
   <lemma>psát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-484-536">
   <w.rf>
    <LM>w#w-484-536</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1011-11">
   <w.rf>
    <LM>w#w-d1t1011-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-484-533">
   <w.rf>
    <LM>w#w-484-533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-485">
  <m id="m139-d1t1015-8">
   <w.rf>
    <LM>w#w-d1t1015-8</LM>
   </w.rf>
   <form>Vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m139-d1t1015-7">
   <w.rf>
    <LM>w#w-d1t1015-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d-id83359-punct">
   <w.rf>
    <LM>w#w-d-id83359-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1017-2">
   <w.rf>
    <LM>w#w-d1t1017-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1017-3">
   <w.rf>
    <LM>w#w-d1t1017-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1017-4">
   <w.rf>
    <LM>w#w-d1t1017-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1017-7">
   <w.rf>
    <LM>w#w-d1t1017-7</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m139-d1t1017-5">
   <w.rf>
    <LM>w#w-d1t1017-5</LM>
   </w.rf>
   <form>1958</form>
   <lemma>1958</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m139-d-id83460-punct">
   <w.rf>
    <LM>w#w-d-id83460-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-485-642">
   <w.rf>
    <LM>w#w-485-642</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1019-2">
   <w.rf>
    <LM>w#w-d1t1019-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1019-3">
   <w.rf>
    <LM>w#w-d1t1019-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1028-1">
   <w.rf>
    <LM>w#w-d1t1028-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-485-545">
   <w.rf>
    <LM>w#w-485-545</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-485-546">
   <w.rf>
    <LM>w#w-485-546</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m139-d1t1030-1">
   <w.rf>
    <LM>w#w-d1t1030-1</LM>
   </w.rf>
   <form>1961</form>
   <lemma>1961</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m139-d-id83647-punct">
   <w.rf>
    <LM>w#w-d-id83647-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1032-2">
   <w.rf>
    <LM>w#w-d1t1032-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1032-5">
   <w.rf>
    <LM>w#w-d1t1032-5</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m139-d1t1032-6">
   <w.rf>
    <LM>w#w-d1t1032-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>známost</form>
   <lemma>známost-2_^(*5ý-2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1032-7">
   <w.rf>
    <LM>w#w-d1t1032-7</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1032-3">
   <w.rf>
    <LM>w#w-d1t1032-3</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1032-8">
   <w.rf>
    <LM>w#w-d1t1032-8</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t1032-9">
   <w.rf>
    <LM>w#w-d1t1032-9</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d-m-d1e984-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e984-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1039-x2">
  <m id="m139-d1t1042-1">
   <w.rf>
    <LM>w#w-d1t1042-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1042-2">
   <w.rf>
    <LM>w#w-d1t1042-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1042-3">
   <w.rf>
    <LM>w#w-d1t1042-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1042-4">
   <w.rf>
    <LM>w#w-d1t1042-4</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t1042-5">
   <w.rf>
    <LM>w#w-d1t1042-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t1042-6">
   <w.rf>
    <LM>w#w-d1t1042-6</LM>
   </w.rf>
   <form>užila</form>
   <lemma>užít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d-id83926-punct">
   <w.rf>
    <LM>w#w-d-id83926-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1043-x2">
  <m id="m139-d1t1054-1">
   <w.rf>
    <LM>w#w-d1t1054-1</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1057-1">
   <w.rf>
    <LM>w#w-d1t1057-1</LM>
   </w.rf>
   <form>obyčejně</form>
   <lemma>obyčejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1e1043-x2-22">
   <w.rf>
    <LM>w#w-d1e1043-x2-22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-21">
  <m id="m139-d1t1057-3">
   <w.rf>
    <LM>w#w-d1t1057-3</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1057-4">
   <w.rf>
    <LM>w#w-d1t1057-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1057-5">
   <w.rf>
    <LM>w#w-d1t1057-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1057-6">
   <w.rf>
    <LM>w#w-d1t1057-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m139-d1t1057-7">
   <w.rf>
    <LM>w#w-d1t1057-7</LM>
   </w.rf>
   <form>hostině</form>
   <lemma>hostina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-21-26">
   <w.rf>
    <LM>w#w-21-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-20">
  <m id="m139-d1t1061-1">
   <w.rf>
    <LM>w#w-d1t1061-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1061-2">
   <w.rf>
    <LM>w#w-d1t1061-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1061-3">
   <w.rf>
    <LM>w#w-d1t1061-3</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1061-4">
   <w.rf>
    <LM>w#w-d1t1061-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m139-d1t1061-5">
   <w.rf>
    <LM>w#w-d1t1061-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1061-6">
   <w.rf>
    <LM>w#w-d1t1061-6</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m139-20-29">
   <w.rf>
    <LM>w#w-20-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-19">
  <m id="m139-d1t1065-2">
   <w.rf>
    <LM>w#w-d1t1065-2</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1065-3">
   <w.rf>
    <LM>w#w-d1t1065-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1065-4">
   <w.rf>
    <LM>w#w-d1t1065-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1065-5">
   <w.rf>
    <LM>w#w-d1t1065-5</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1065-6">
   <w.rf>
    <LM>w#w-d1t1065-6</LM>
   </w.rf>
   <form>zatančili</form>
   <lemma>zatančit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1065-7">
   <w.rf>
    <LM>w#w-d1t1065-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1065-8">
   <w.rf>
    <LM>w#w-d1t1065-8</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m139-d1t1065-9">
   <w.rf>
    <LM>w#w-d1t1065-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1065-10">
   <w.rf>
    <LM>w#w-d1t1065-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1065-11">
   <w.rf>
    <LM>w#w-d1t1065-11</LM>
   </w.rf>
   <form>bratrancem</form>
   <lemma>bratranec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m139-d-id84477-punct">
   <w.rf>
    <LM>w#w-d-id84477-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1065-13">
   <w.rf>
    <LM>w#w-d1t1065-13</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m139-d1t1067-1">
   <w.rf>
    <LM>w#w-d1t1067-1</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1067-2">
   <w.rf>
    <LM>w#w-d1t1067-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1067-3">
   <w.rf>
    <LM>w#w-d1t1067-3</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m139-d1t1067-4">
   <w.rf>
    <LM>w#w-d1t1067-4</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m139-d1t1067-7">
   <w.rf>
    <LM>w#w-d1t1067-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1067-8">
   <w.rf>
    <LM>w#w-d1t1067-8</LM>
   </w.rf>
   <form>mládence</form>
   <lemma>mládenec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m139-d-id84634-punct">
   <w.rf>
    <LM>w#w-d-id84634-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1067-10">
   <w.rf>
    <LM>w#w-d1t1067-10</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m139-d1t1067-11">
   <w.rf>
    <LM>w#w-d1t1067-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1067-12">
   <w.rf>
    <LM>w#w-d1t1067-12</LM>
   </w.rf>
   <form>družičku</form>
   <lemma>družička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-19-34">
   <w.rf>
    <LM>w#w-19-34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-18">
  <m id="m139-d1t1070-1">
   <w.rf>
    <LM>w#w-d1t1070-1</LM>
   </w.rf>
   <form>Proběhlo</form>
   <lemma>proběhnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m139-d1t1070-2">
   <w.rf>
    <LM>w#w-d1t1070-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1070-3">
   <w.rf>
    <LM>w#w-d1t1070-3</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1072-1">
   <w.rf>
    <LM>w#w-d1t1072-1</LM>
   </w.rf>
   <form>obyčejně</form>
   <lemma>obyčejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d-id84808-punct">
   <w.rf>
    <LM>w#w-d-id84808-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1072-4">
   <w.rf>
    <LM>w#w-d1t1072-4</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m139-d1t1072-3">
   <w.rf>
    <LM>w#w-d1t1072-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1072-5">
   <w.rf>
    <LM>w#w-d1t1072-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m139-d-m-d1e1043-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1043-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1075-x2">
  <m id="m139-d1t1078-1">
   <w.rf>
    <LM>w#w-d1t1078-1</LM>
   </w.rf>
   <form>Chystáte</form>
   <lemma>chystat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1078-2">
   <w.rf>
    <LM>w#w-d1t1078-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1078-3">
   <w.rf>
    <LM>w#w-d1t1078-3</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m139-d1t1078-4">
   <w.rf>
    <LM>w#w-d1t1078-4</LM>
   </w.rf>
   <form>zlatou</form>
   <lemma>zlatý-1_^(atribut;_z._řetízek,_poklad,...)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m139-d1t1078-5">
   <w.rf>
    <LM>w#w-d1t1078-5</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id85003-punct">
   <w.rf>
    <LM>w#w-d-id85003-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1079-x2">
  <m id="m139-d1t1086-4">
   <w.rf>
    <LM>w#w-d1t1086-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1086-5">
   <w.rf>
    <LM>w#w-d1t1086-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1088-1">
   <w.rf>
    <LM>w#w-d1t1088-1</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m139-d1t1088-2">
   <w.rf>
    <LM>w#w-d1t1088-2</LM>
   </w.rf>
   <form>dožijeme</form>
   <lemma>dožít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m139-d1e1079-x2-48">
   <w.rf>
    <LM>w#w-d1e1079-x2-48</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1093-1">
   <w.rf>
    <LM>w#w-d1t1093-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1093-2">
   <w.rf>
    <LM>w#w-d1t1093-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1093-3">
   <w.rf>
    <LM>w#w-d1t1093-3</LM>
   </w.rf>
   <form>příští</form>
   <lemma>příští</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t1093-4">
   <w.rf>
    <LM>w#w-d1t1093-4</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1e1079-x2-49">
   <w.rf>
    <LM>w#w-d1e1079-x2-49</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d-id85268-punct">
   <w.rf>
    <LM>w#w-d-id85268-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1093-6">
   <w.rf>
    <LM>w#w-d1t1093-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1093-7">
   <w.rf>
    <LM>w#w-d1t1093-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1095-2">
   <w.rf>
    <LM>w#w-d1t1095-2</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m139-d1t1095-4">
   <w.rf>
    <LM>w#w-d1t1095-4</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m139-d1t1095-5">
   <w.rf>
    <LM>w#w-d1t1095-5</LM>
   </w.rf>
   <form>rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m139-d1t1095-6">
   <w.rf>
    <LM>w#w-d1t1095-6</LM>
   </w.rf>
   <form>oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1097-1">
   <w.rf>
    <LM>w#w-d1t1097-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1097-2">
   <w.rf>
    <LM>w#w-d1t1097-2</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m139-d1t1097-3">
   <w.rf>
    <LM>w#w-d1t1097-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1097-4">
   <w.rf>
    <LM>w#w-d1t1097-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1099-1">
   <w.rf>
    <LM>w#w-d1t1099-1</LM>
   </w.rf>
   <form>vnoučaty</form>
   <lemma>vnouče</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1079-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1079-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1102-x2">
  <m id="m139-d1t1105-1">
   <w.rf>
    <LM>w#w-d1t1105-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1105-2">
   <w.rf>
    <LM>w#w-d1t1105-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1105-3">
   <w.rf>
    <LM>w#w-d1t1105-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m139-d1t1105-4">
   <w.rf>
    <LM>w#w-d1t1105-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d-id85624-punct">
   <w.rf>
    <LM>w#w-d-id85624-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1106-x2">
  <m id="m139-d1t1113-2">
   <w.rf>
    <LM>w#w-d1t1113-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1113-3">
   <w.rf>
    <LM>w#w-d1t1113-3</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1113-4">
   <w.rf>
    <LM>w#w-d1t1113-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1113-10">
   <w.rf>
    <LM>w#w-d1t1113-10</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1113-5">
   <w.rf>
    <LM>w#w-d1t1113-5</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1113-6">
   <w.rf>
    <LM>w#w-d1t1113-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1113-7">
   <w.rf>
    <LM>w#w-d1t1113-7</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-d1t1113-8">
   <w.rf>
    <LM>w#w-d1t1113-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1113-9">
   <w.rf>
    <LM>w#w-d1t1113-9</LM>
   </w.rf>
   <form>motorce</form>
   <lemma>motorka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1e1106-x2-60">
   <w.rf>
    <LM>w#w-d1e1106-x2-60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-59">
  <m id="m139-d1t1115-3">
   <w.rf>
    <LM>w#w-d1t1115-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1115-2">
   <w.rf>
    <LM>w#w-d1t1115-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1115-4">
   <w.rf>
    <LM>w#w-d1t1115-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1115-6">
   <w.rf>
    <LM>w#w-d1t1115-6</LM>
   </w.rf>
   <form>Krkonoších</form>
   <lemma>Krkonoše_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m139-59-62">
   <w.rf>
    <LM>w#w-59-62</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-61">
  <m id="m139-d1t1115-9">
   <w.rf>
    <LM>w#w-d1t1115-9</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m139-61-70">
   <w.rf>
    <LM>w#w-61-70</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1115-10">
   <w.rf>
    <LM>w#w-d1t1115-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1115-11">
   <w.rf>
    <LM>w#w-d1t1115-11</LM>
   </w.rf>
   <form>jakou</form>
   <lemma>jaký</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m139-d1t1115-12">
   <w.rf>
    <LM>w#w-d1t1115-12</LM>
   </w.rf>
   <form>skálu</form>
   <lemma>skála</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1t1115-13">
   <w.rf>
    <LM>w#w-d1t1115-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1115-14">
   <w.rf>
    <LM>w#w-d1t1115-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1115-15">
   <w.rf>
    <LM>w#w-d1t1115-15</LM>
   </w.rf>
   <form>vylezli</form>
   <lemma>vylézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d-id86072-punct">
   <w.rf>
    <LM>w#w-d-id86072-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1115-17">
   <w.rf>
    <LM>w#w-d1t1115-17</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1115-18">
   <w.rf>
    <LM>w#w-d1t1115-18</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m139-d1t1115-19">
   <w.rf>
    <LM>w#w-d1t1115-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1115-20">
   <w.rf>
    <LM>w#w-d1t1115-20</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1115-21">
   <w.rf>
    <LM>w#w-d1t1115-21</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-61-678">
   <w.rf>
    <LM>w#w-61-678</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-679">
  <m id="m139-d1t1117-1">
   <w.rf>
    <LM>w#w-d1t1117-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1117-2">
   <w.rf>
    <LM>w#w-d1t1117-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1117-3">
   <w.rf>
    <LM>w#w-d1t1117-3</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1117-4">
   <w.rf>
    <LM>w#w-d1t1117-4</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-3</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1122-2">
   <w.rf>
    <LM>w#w-d1t1122-2</LM>
   </w.rf>
   <form>Petrových</form>
   <lemma>Petrův_;Y_^(*2)_(*2o)</lemma>
   <tag>AUIP2M---------</tag>
  </m>
  <m id="m139-d1t1122-3">
   <w.rf>
    <LM>w#w-d1t1122-3</LM>
   </w.rf>
   <form>kamenů</form>
   <lemma>kámen</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m139-d1t1122-5">
   <w.rf>
    <LM>w#w-d1t1122-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1122-6">
   <w.rf>
    <LM>w#w-d1t1122-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1122-7">
   <w.rf>
    <LM>w#w-d1t1122-7</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1122-8">
   <w.rf>
    <LM>w#w-d1t1122-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1122-9">
   <w.rf>
    <LM>w#w-d1t1122-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1122-10">
   <w.rf>
    <LM>w#w-d1t1122-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1122-11">
   <w.rf>
    <LM>w#w-d1t1122-11</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m139-d-m-d1e1106-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1106-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1130-x2">
  <m id="m139-d1t1133-1">
   <w.rf>
    <LM>w#w-d1t1133-1</LM>
   </w.rf>
   <form>Jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1133-2">
   <w.rf>
    <LM>w#w-d1t1133-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1133-3">
   <w.rf>
    <LM>w#w-d1t1133-3</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t1133-4">
   <w.rf>
    <LM>w#w-d1t1133-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1133-5">
   <w.rf>
    <LM>w#w-d1t1133-5</LM>
   </w.rf>
   <form>hor</form>
   <lemma>hora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m139-d-id86543-punct">
   <w.rf>
    <LM>w#w-d-id86543-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1134-x2">
  <m id="m139-d1t1141-1">
   <w.rf>
    <LM>w#w-d1t1141-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1141-2">
   <w.rf>
    <LM>w#w-d1t1141-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1141-3">
   <w.rf>
    <LM>w#w-d1t1141-3</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1141-4">
   <w.rf>
    <LM>w#w-d1t1141-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1141-5">
   <w.rf>
    <LM>w#w-d1t1141-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1141-6">
   <w.rf>
    <LM>w#w-d1t1141-6</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1141-7">
   <w.rf>
    <LM>w#w-d1t1141-7</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m139-d1t1143-1">
   <w.rf>
    <LM>w#w-d1t1143-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1143-2">
   <w.rf>
    <LM>w#w-d1t1143-2</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m139-d1t1143-3">
   <w.rf>
    <LM>w#w-d1t1143-3</LM>
   </w.rf>
   <form>podnikovou</form>
   <lemma>podnikový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m139-d1t1143-4">
   <w.rf>
    <LM>w#w-d1t1143-4</LM>
   </w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1e1134-x2-77">
   <w.rf>
    <LM>w#w-d1e1134-x2-77</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-76">
  <m id="m139-d1t1148-2">
   <w.rf>
    <LM>w#w-d1t1148-2</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-3">
   <w.rf>
    <LM>w#w-d1t1148-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-4">
   <w.rf>
    <LM>w#w-d1t1148-4</LM>
   </w.rf>
   <form>nelyžuju</form>
   <lemma>lyžovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m139-d-id86882-punct">
   <w.rf>
    <LM>w#w-d-id86882-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1148-7">
   <w.rf>
    <LM>w#w-d1t1148-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-8">
   <w.rf>
    <LM>w#w-d1t1148-8</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m139-d1t1148-9">
   <w.rf>
    <LM>w#w-d1t1148-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1148-10">
   <w.rf>
    <LM>w#w-d1t1148-10</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-76-685">
   <w.rf>
    <LM>w#w-76-685</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-686">
  <m id="m139-d1t1148-13">
   <w.rf>
    <LM>w#w-d1t1148-13</LM>
   </w.rf>
   <form>Užili</form>
   <lemma>užít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1148-14">
   <w.rf>
    <LM>w#w-d1t1148-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1148-15">
   <w.rf>
    <LM>w#w-d1t1148-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1148-16">
   <w.rf>
    <LM>w#w-d1t1148-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-12">
   <w.rf>
    <LM>w#w-d1t1148-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1148-19">
   <w.rf>
    <LM>w#w-d1t1148-19</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-17">
   <w.rf>
    <LM>w#w-d1t1148-17</LM>
   </w.rf>
   <form>lyžování</form>
   <lemma>lyžování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m139-d1t1148-20">
   <w.rf>
    <LM>w#w-d1t1148-20</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1148-21">
   <w.rf>
    <LM>w#w-d1t1148-21</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m139-d-id87125-punct">
   <w.rf>
    <LM>w#w-d-id87125-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1148-23">
   <w.rf>
    <LM>w#w-d1t1148-23</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1148-24">
   <w.rf>
    <LM>w#w-d1t1148-24</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1148-25">
   <w.rf>
    <LM>w#w-d1t1148-25</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1148-28">
   <w.rf>
    <LM>w#w-d1t1148-28</LM>
   </w.rf>
   <form>vnoučaty</form>
   <lemma>vnouče</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m139-76-82">
   <w.rf>
    <LM>w#w-76-82</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1148-26">
   <w.rf>
    <LM>w#w-d1t1148-26</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1148-27">
   <w.rf>
    <LM>w#w-d1t1148-27</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1150-1">
   <w.rf>
    <LM>w#w-d1t1150-1</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m139-d-m-d1e1134-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1134-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1155-x2">
  <m id="m139-d1t1158-1">
   <w.rf>
    <LM>w#w-d1t1158-1</LM>
   </w.rf>
   <form>Spávali</form>
   <lemma>spávat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1158-2">
   <w.rf>
    <LM>w#w-d1t1158-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1158-3">
   <w.rf>
    <LM>w#w-d1t1158-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1158-4">
   <w.rf>
    <LM>w#w-d1t1158-4</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1158-5">
   <w.rf>
    <LM>w#w-d1t1158-5</LM>
   </w.rf>
   <form>stanem</form>
   <lemma>stan</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m139-d-id87400-punct">
   <w.rf>
    <LM>w#w-d-id87400-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1159-x2">
  <m id="m139-d1t1166-2">
   <w.rf>
    <LM>w#w-d1t1166-2</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1166-3">
   <w.rf>
    <LM>w#w-d1t1166-3</LM>
   </w.rf>
   <form>stanem</form>
   <lemma>stan</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m139-d1t1166-4">
   <w.rf>
    <LM>w#w-d1t1166-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1166-5">
   <w.rf>
    <LM>w#w-d1t1166-5</LM>
   </w.rf>
   <form>nespávali</form>
   <lemma>spávat_^(*3t)</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m139-d1e1159-x2-96">
   <w.rf>
    <LM>w#w-d1e1159-x2-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-95">
  <m id="m139-d1t1166-7">
   <w.rf>
    <LM>w#w-d1t1166-7</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1166-8">
   <w.rf>
    <LM>w#w-d1t1166-8</LM>
   </w.rf>
   <form>stanem</form>
   <lemma>stan</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m139-d1t1166-9">
   <w.rf>
    <LM>w#w-d1t1166-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1166-10">
   <w.rf>
    <LM>w#w-d1t1166-10</LM>
   </w.rf>
   <form>spala</form>
   <lemma>spát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1166-11">
   <w.rf>
    <LM>w#w-d1t1166-11</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1168-5">
   <w.rf>
    <LM>w#w-d1t1168-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1168-1">
   <w.rf>
    <LM>w#w-d1t1168-1</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1168-2">
   <w.rf>
    <LM>w#w-d1t1168-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1168-3">
   <w.rf>
    <LM>w#w-d1t1168-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m139-d1t1168-4">
   <w.rf>
    <LM>w#w-d1t1168-4</LM>
   </w.rf>
   <form>1970</form>
   <lemma>1970</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m139-d1t1170-1">
   <w.rf>
    <LM>w#w-d1t1170-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1170-2">
   <w.rf>
    <LM>w#w-d1t1170-2</LM>
   </w.rf>
   <form>tehdejší</form>
   <lemma>tehdejší</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m139-d1t1170-4">
   <w.rf>
    <LM>w#w-d1t1170-4</LM>
   </w.rf>
   <form>Jugoslávii</form>
   <lemma>Jugoslávie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d-id87802-punct">
   <w.rf>
    <LM>w#w-d-id87802-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1173-1">
   <w.rf>
    <LM>w#w-d1t1173-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1173-2">
   <w.rf>
    <LM>w#w-d1t1173-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1173-3">
   <w.rf>
    <LM>w#w-d1t1173-3</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1173-5">
   <w.rf>
    <LM>w#w-d1t1173-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1173-6">
   <w.rf>
    <LM>w#w-d1t1173-6</LM>
   </w.rf>
   <form>podnikový</form>
   <lemma>podnikový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t1175-1">
   <w.rf>
    <LM>w#w-d1t1175-1</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t1175-2">
   <w.rf>
    <LM>w#w-d1t1175-2</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m139-95-102">
   <w.rf>
    <LM>w#w-95-102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-93">
  <m id="m139-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1177-1">
   <w.rf>
    <LM>w#w-d1t1177-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1179-3">
   <w.rf>
    <LM>w#w-d1t1179-3</LM>
   </w.rf>
   <form>vyměnil</form>
   <lemma>vyměnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m139-d1t1179-2">
   <w.rf>
    <LM>w#w-d1t1179-2</LM>
   </w.rf>
   <form>turnus</form>
   <lemma>turnus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-d-id88059-punct">
   <w.rf>
    <LM>w#w-d-id88059-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1181-1">
   <w.rf>
    <LM>w#w-d1t1181-1</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m139-d1t1181-2">
   <w.rf>
    <LM>w#w-d1t1181-2</LM>
   </w.rf>
   <form>turnus</form>
   <lemma>turnus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-d1t1181-3">
   <w.rf>
    <LM>w#w-d1t1181-3</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t1181-4">
   <w.rf>
    <LM>w#w-d1t1181-4</LM>
   </w.rf>
   <form>postavil</form>
   <lemma>postavit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m139-d-id88146-punct">
   <w.rf>
    <LM>w#w-d-id88146-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1181-6">
   <w.rf>
    <LM>w#w-d1t1181-6</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1181-7">
   <w.rf>
    <LM>w#w-d1t1181-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1181-8">
   <w.rf>
    <LM>w#w-d1t1181-8</LM>
   </w.rf>
   <form>tímhle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m139-d1t1181-9">
   <w.rf>
    <LM>w#w-d1t1181-9</LM>
   </w.rf>
   <form>zkušenosti</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t1181-10">
   <w.rf>
    <LM>w#w-d1t1181-10</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m139-93-107">
   <w.rf>
    <LM>w#w-93-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-94">
  <m id="m139-d1t1183-2">
   <w.rf>
    <LM>w#w-d1t1183-2</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1186-1">
   <w.rf>
    <LM>w#w-d1t1186-1</LM>
   </w.rf>
   <form>stanem</form>
   <lemma>stan</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m139-d1t1186-2">
   <w.rf>
    <LM>w#w-d1t1186-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1186-3">
   <w.rf>
    <LM>w#w-d1t1186-3</LM>
   </w.rf>
   <form>bojím</form>
   <lemma>bát-1</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1190-1">
   <w.rf>
    <LM>w#w-d1t1190-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1190-2">
   <w.rf>
    <LM>w#w-d1t1190-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1190-3">
   <w.rf>
    <LM>w#w-d1t1190-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m139-d1t1190-4">
   <w.rf>
    <LM>w#w-d1t1190-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1190-5">
   <w.rf>
    <LM>w#w-d1t1190-5</LM>
   </w.rf>
   <form>zima</form>
   <lemma>zima-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d-m-d1e1159-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1159-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-125">
  <m id="m139-d1t1200-1">
   <w.rf>
    <LM>w#w-d1t1200-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m139-d1t1200-2">
   <w.rf>
    <LM>w#w-d1t1200-2</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t1200-3">
   <w.rf>
    <LM>w#w-d1t1200-3</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1200-4">
   <w.rf>
    <LM>w#w-d1t1200-4</LM>
   </w.rf>
   <form>nejraději</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m139-d-id88559-punct">
   <w.rf>
    <LM>w#w-d-id88559-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1201-x2">
  <m id="m139-d1t1208-3">
   <w.rf>
    <LM>w#w-d1t1208-3</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1208-4">
   <w.rf>
    <LM>w#w-d1t1208-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1208-5">
   <w.rf>
    <LM>w#w-d1t1208-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1210-2">
   <w.rf>
    <LM>w#w-d1t1210-2</LM>
   </w.rf>
   <form>Krkonoš</form>
   <lemma>Krkonoše_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m139-d1e1201-x2-141">
   <w.rf>
    <LM>w#w-d1e1201-x2-141</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
