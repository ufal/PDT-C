<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_027.01.w.gz" />
  </references>
 </head>
 <s id="m027-d1e284-x2">
  <m id="m027-d1t287-1">
   <w.rf>
    <LM>w#w-d1t287-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t287-4">
   <w.rf>
    <LM>w#w-d1t287-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t287-2">
   <w.rf>
    <LM>w#w-d1t287-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t287-5">
   <w.rf>
    <LM>w#w-d1t287-5</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m027-d1t287-6">
   <w.rf>
    <LM>w#w-d1t287-6</LM>
   </w.rf>
   <form>vzpomínku</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1e284-x2-742">
   <w.rf>
    <LM>w#w-d1e284-x2-742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-744_1">
  <m id="m027-d1t287-9">
   <w.rf>
    <LM>w#w-d1t287-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t287-10">
   <w.rf>
    <LM>w#w-d1t287-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t287-11">
   <w.rf>
    <LM>w#w-d1t287-11</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t287-12">
   <w.rf>
    <LM>w#w-d1t287-12</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d1t287-13">
   <w.rf>
    <LM>w#w-d1t287-13</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id65563-punct">
   <w.rf>
    <LM>w#w-d-id65563-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t287-19">
   <w.rf>
    <LM>w#w-d1t287-19</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t287-16">
   <w.rf>
    <LM>w#w-d1t287-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t287-17">
   <w.rf>
    <LM>w#w-d1t287-17</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m027-d1t287-21">
   <w.rf>
    <LM>w#w-d1t287-21</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t287-22">
   <w.rf>
    <LM>w#w-d1t287-22</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id65689-punct">
   <w.rf>
    <LM>w#w-d-id65689-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t287-24">
   <w.rf>
    <LM>w#w-d1t287-24</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t287-25">
   <w.rf>
    <LM>w#w-d1t287-25</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t287-26">
   <w.rf>
    <LM>w#w-d1t287-26</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m027-d1t287-27">
   <w.rf>
    <LM>w#w-d1t287-27</LM>
   </w.rf>
   <form>zapomněla</form>
   <lemma>zapomenout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m027-d1t287-28">
   <w.rf>
    <LM>w#w-d1t287-28</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t287-29">
   <w.rf>
    <LM>w#w-d1t287-29</LM>
   </w.rf>
   <form>návsi</form>
   <lemma>náves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-744_1-24">
   <w.rf>
    <LM>w#w-744_1-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-26">
  <m id="m027-d1t287-30">
   <w.rf>
    <LM>w#w-d1t287-30</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t287-31">
   <w.rf>
    <LM>w#w-d1t287-31</LM>
   </w.rf>
   <form>podobné</form>
   <lemma>podobný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m027-d1t287-32">
   <w.rf>
    <LM>w#w-d1t287-32</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e284-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e284-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e300-x2">
  <m id="m027-d1t305-1">
   <w.rf>
    <LM>w#w-d1t305-1</LM>
   </w.rf>
   <form>Vzpomínek</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d1t305-3">
   <w.rf>
    <LM>w#w-d1t305-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t305-4">
   <w.rf>
    <LM>w#w-d1t305-4</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d1t305-2">
   <w.rf>
    <LM>w#w-d1t305-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t305-5">
   <w.rf>
    <LM>w#w-d1t305-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e300-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e300-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e306-x2">
  <m id="m027-d1t309-1">
   <w.rf>
    <LM>w#w-d1t309-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m027-d1t309-2">
   <w.rf>
    <LM>w#w-d1t309-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t309-3">
   <w.rf>
    <LM>w#w-d1t309-3</LM>
   </w.rf>
   <form>sourozenců</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m027-d-id66239-punct">
   <w.rf>
    <LM>w#w-d-id66239-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e310-x2">
  <m id="m027-d1t313-2">
   <w.rf>
    <LM>w#w-d1t313-2</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t313-3">
   <w.rf>
    <LM>w#w-d1t313-3</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnMS4----------</tag>
  </m>
  <m id="m027-d1t313-4">
   <w.rf>
    <LM>w#w-d1t313-4</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m027-d1e310-x2-50">
   <w.rf>
    <LM>w#w-d1e310-x2-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-52">
  <m id="m027-d1t313-9">
   <w.rf>
    <LM>w#w-d1t313-9</LM>
   </w.rf>
   <form>Narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d1t313-7">
   <w.rf>
    <LM>w#w-d1t313-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d-id66419-punct">
   <w.rf>
    <LM>w#w-d-id66419-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t313-11">
   <w.rf>
    <LM>w#w-d1t313-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t313-12">
   <w.rf>
    <LM>w#w-d1t313-12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t313-13">
   <w.rf>
    <LM>w#w-d1t313-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t313-14">
   <w.rf>
    <LM>w#w-d1t313-14</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1t313-15">
   <w.rf>
    <LM>w#w-d1t313-15</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d-id66485-punct">
   <w.rf>
    <LM>w#w-d-id66485-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t313-17">
   <w.rf>
    <LM>w#w-d1t313-17</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t313-19">
   <w.rf>
    <LM>w#w-d1t313-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t313-20">
   <w.rf>
    <LM>w#w-d1t313-20</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t313-21">
   <w.rf>
    <LM>w#w-d1t313-21</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m027-d1t313-22">
   <w.rf>
    <LM>w#w-d1t313-22</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d1t313-23">
   <w.rf>
    <LM>w#w-d1t313-23</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m027-d1e310-x2-756">
   <w.rf>
    <LM>w#w-d1e310-x2-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-758">
  <m id="m027-d1t313-29">
   <w.rf>
    <LM>w#w-d1t313-29</LM>
   </w.rf>
   <form>Narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d1t313-28">
   <w.rf>
    <LM>w#w-d1t313-28</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t313-24">
   <w.rf>
    <LM>w#w-d1t313-24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t313-25">
   <w.rf>
    <LM>w#w-d1t313-25</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d1t313-26">
   <w.rf>
    <LM>w#w-d1t313-26</LM>
   </w.rf>
   <form>1953</form>
   <lemma>1953</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m027-d-m-d1e310-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e310-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e322-x2">
  <m id="m027-d1t325-1">
   <w.rf>
    <LM>w#w-d1t325-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t325-3">
   <w.rf>
    <LM>w#w-d1t325-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t325-4">
   <w.rf>
    <LM>w#w-d1t325-4</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d-id66874-punct">
   <w.rf>
    <LM>w#w-d-id66874-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t325-6">
   <w.rf>
    <LM>w#w-d1t325-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t325-7">
   <w.rf>
    <LM>w#w-d1t325-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t325-8">
   <w.rf>
    <LM>w#w-d1t325-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t325-9">
   <w.rf>
    <LM>w#w-d1t325-9</LM>
   </w.rf>
   <form>stěhovali</form>
   <lemma>stěhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t325-10">
   <w.rf>
    <LM>w#w-d1t325-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t325-13">
   <w.rf>
    <LM>w#w-d1t325-13</LM>
   </w.rf>
   <form>Litohlav</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e322-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e322-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e326-x2">
  <m id="m027-d1t329-1">
   <w.rf>
    <LM>w#w-d1t329-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t329-2">
   <w.rf>
    <LM>w#w-d1t329-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t329-3">
   <w.rf>
    <LM>w#w-d1t329-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m027-d-id67117-punct">
   <w.rf>
    <LM>w#w-d-id67117-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e330-x2">
  <m id="m027-d1t333-1">
   <w.rf>
    <LM>w#w-d1t333-1</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m027-d1t333-2">
   <w.rf>
    <LM>w#w-d1t333-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t333-4">
   <w.rf>
    <LM>w#w-d1t333-4</LM>
   </w.rf>
   <form>Vlastík</form>
   <lemma>Vlastík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id67243-punct">
   <w.rf>
    <LM>w#w-d-id67243-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t333-8">
   <w.rf>
    <LM>w#w-d1t333-8</LM>
   </w.rf>
   <form>Vlastimil</form>
   <lemma>Vlastimil_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e330-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e330-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e334-x2">
  <m id="m027-d1t339-1">
   <w.rf>
    <LM>w#w-d1t339-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e334-x2-82">
   <w.rf>
    <LM>w#w-d1e334-x2-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-84_1">
  <m id="m027-d1t339-3">
   <w.rf>
    <LM>w#w-d1t339-3</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t339-4">
   <w.rf>
    <LM>w#w-d1t339-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m027-d1t339-5">
   <w.rf>
    <LM>w#w-d1t339-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t339-6">
   <w.rf>
    <LM>w#w-d1t339-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m027-d1t339-7">
   <w.rf>
    <LM>w#w-d1t339-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t339-8">
   <w.rf>
    <LM>w#w-d1t339-8</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m027-d1t339-9">
   <w.rf>
    <LM>w#w-d1t339-9</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m027-d-id67473-punct">
   <w.rf>
    <LM>w#w-d-id67473-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e341-x2">
  <m id="m027-d1t344-2">
   <w.rf>
    <LM>w#w-d1t344-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t344-3">
   <w.rf>
    <LM>w#w-d1t344-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t344-4">
   <w.rf>
    <LM>w#w-d1t344-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1e341-x2-794">
   <w.rf>
    <LM>w#w-d1e341-x2-794</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t346-2">
   <w.rf>
    <LM>w#w-d1t346-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t346-3">
   <w.rf>
    <LM>w#w-d1t346-3</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m027-d1t346-4">
   <w.rf>
    <LM>w#w-d1t346-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t346-5">
   <w.rf>
    <LM>w#w-d1t346-5</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t346-6">
   <w.rf>
    <LM>w#w-d1t346-6</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m027-d1t346-7">
   <w.rf>
    <LM>w#w-d1t346-7</LM>
   </w.rf>
   <form>podívám</form>
   <lemma>podívat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m027-d1e341-x2-810">
   <w.rf>
    <LM>w#w-d1e341-x2-810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-812">
  <m id="m027-812-862">
   <w.rf>
    <LM>w#w-812-862</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-812-860">
   <w.rf>
    <LM>w#w-812-860</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-812-858">
   <w.rf>
    <LM>w#w-812-858</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-812-856">
   <w.rf>
    <LM>w#w-812-856</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-812-854">
   <w.rf>
    <LM>w#w-812-854</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-812-852">
   <w.rf>
    <LM>w#w-812-852</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m027-812-850">
   <w.rf>
    <LM>w#w-812-850</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m027-812-848">
   <w.rf>
    <LM>w#w-812-848</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-812-846">
   <w.rf>
    <LM>w#w-812-846</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-812-844">
   <w.rf>
    <LM>w#w-812-844</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-812-842">
   <w.rf>
    <LM>w#w-812-842</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-812-840">
   <w.rf>
    <LM>w#w-812-840</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-812-864">
   <w.rf>
    <LM>w#w-812-864</LM>
   </w.rf>
   <form>„</form>
   <lemma>„</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-812-838">
   <w.rf>
    <LM>w#w-812-838</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-812-836">
   <w.rf>
    <LM>w#w-812-836</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-812-834">
   <w.rf>
    <LM>w#w-812-834</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-812-832">
   <w.rf>
    <LM>w#w-812-832</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-812-830">
   <w.rf>
    <LM>w#w-812-830</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m027-812-828">
   <w.rf>
    <LM>w#w-812-828</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-812-826">
   <w.rf>
    <LM>w#w-812-826</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-812-824">
   <w.rf>
    <LM>w#w-812-824</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-812-822">
   <w.rf>
    <LM>w#w-812-822</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-812-820">
   <w.rf>
    <LM>w#w-812-820</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m027-812-818">
   <w.rf>
    <LM>w#w-812-818</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m027-d1t370-1">
   <w.rf>
    <LM>w#w-d1t370-1</LM>
   </w.rf>
   <form>tmavé</form>
   <lemma>tmavý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m027-812-816">
   <w.rf>
    <LM>w#w-812-816</LM>
   </w.rf>
   <form>oči</form>
   <lemma>oko-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-812-866">
   <w.rf>
    <LM>w#w-812-866</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-812-814">
   <w.rf>
    <LM>w#w-812-814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e375-x2">
  <m id="m027-d1t378-8">
   <w.rf>
    <LM>w#w-d1t378-8</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t378-7">
   <w.rf>
    <LM>w#w-d1t378-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1e375-x2-112">
   <w.rf>
    <LM>w#w-d1e375-x2-112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e375-x2-114">
   <w.rf>
    <LM>w#w-d1e375-x2-114</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t378-3">
   <w.rf>
    <LM>w#w-d1t378-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t378-2">
   <w.rf>
    <LM>w#w-d1t378-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t378-4">
   <w.rf>
    <LM>w#w-d1t378-4</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t378-5">
   <w.rf>
    <LM>w#w-d1t378-5</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d1t378-6">
   <w.rf>
    <LM>w#w-d1t378-6</LM>
   </w.rf>
   <form>miminko</form>
   <lemma>miminko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e375-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e375-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e387-x2">
  <m id="m027-d1t390-1">
   <w.rf>
    <LM>w#w-d1t390-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t390-2">
   <w.rf>
    <LM>w#w-d1t390-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t390-3">
   <w.rf>
    <LM>w#w-d1t390-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d1e387-x2-132">
   <w.rf>
    <LM>w#w-d1e387-x2-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-134">
  <m id="m027-d1t390-6">
   <w.rf>
    <LM>w#w-d1t390-6</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t390-7">
   <w.rf>
    <LM>w#w-d1t390-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t390-8">
   <w.rf>
    <LM>w#w-d1t390-8</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t390-9">
   <w.rf>
    <LM>w#w-d1t390-9</LM>
   </w.rf>
   <form>malinký</form>
   <lemma>malinký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d-id68749-punct">
   <w.rf>
    <LM>w#w-d-id68749-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t390-14">
   <w.rf>
    <LM>w#w-d1t390-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t392-1">
   <w.rf>
    <LM>w#w-d1t392-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t392-2">
   <w.rf>
    <LM>w#w-d1t392-2</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t392-5">
   <w.rf>
    <LM>w#w-d1t392-5</LM>
   </w.rf>
   <form>nejútlejší</form>
   <lemma>útlý</lemma>
   <tag>AANS4----3A----</tag>
  </m>
  <m id="m027-d1t392-6">
   <w.rf>
    <LM>w#w-d1t392-6</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d1t390-15">
   <w.rf>
    <LM>w#w-d1t390-15</LM>
   </w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m027-d1t390-18">
   <w.rf>
    <LM>w#w-d1t390-18</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m027-d1t390-17">
   <w.rf>
    <LM>w#w-d1t390-17</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e387-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e387-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e393-x2">
  <m id="m027-d1t396-1">
   <w.rf>
    <LM>w#w-d1t396-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1e393-x2-888">
   <w.rf>
    <LM>w#w-d1e393-x2-888</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-890">
  <m id="m027-d1t396-4">
   <w.rf>
    <LM>w#w-d1t396-4</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m027-d1t396-5">
   <w.rf>
    <LM>w#w-d1t396-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t396-6">
   <w.rf>
    <LM>w#w-d1t396-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t396-7">
   <w.rf>
    <LM>w#w-d1t396-7</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e393-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e393-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e397-x2">
  <m id="m027-d1t400-1">
   <w.rf>
    <LM>w#w-d1t400-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1e397-x2-892">
   <w.rf>
    <LM>w#w-d1e397-x2-892</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t400-2">
   <w.rf>
    <LM>w#w-d1t400-2</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e397-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e397-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e401-x3">
  <m id="m027-d1t408-1">
   <w.rf>
    <LM>w#w-d1t408-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m027-d1t408-2">
   <w.rf>
    <LM>w#w-d1t408-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t408-3">
   <w.rf>
    <LM>w#w-d1t408-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t408-4">
   <w.rf>
    <LM>w#w-d1t408-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-id69384-punct">
   <w.rf>
    <LM>w#w-d-id69384-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e409-x2">
  <m id="m027-d1t412-2">
   <w.rf>
    <LM>w#w-d1t412-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t412-3">
   <w.rf>
    <LM>w#w-d1t412-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t412-4">
   <w.rf>
    <LM>w#w-d1t412-4</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t412-5">
   <w.rf>
    <LM>w#w-d1t412-5</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m027-d1t412-6">
   <w.rf>
    <LM>w#w-d1t412-6</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d1e409-x2-900">
   <w.rf>
    <LM>w#w-d1e409-x2-900</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t412-7">
   <w.rf>
    <LM>w#w-d1t412-7</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id69554-punct">
   <w.rf>
    <LM>w#w-d-id69554-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t412-9">
   <w.rf>
    <LM>w#w-d1t412-9</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t412-10">
   <w.rf>
    <LM>w#w-d1t412-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t412-11">
   <w.rf>
    <LM>w#w-d1t412-11</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d1e409-x2-902">
   <w.rf>
    <LM>w#w-d1e409-x2-902</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t412-12">
   <w.rf>
    <LM>w#w-d1t412-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t412-13">
   <w.rf>
    <LM>w#w-d1t412-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t412-14">
   <w.rf>
    <LM>w#w-d1t412-14</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t412-15">
   <w.rf>
    <LM>w#w-d1t412-15</LM>
   </w.rf>
   <form>mračím</form>
   <lemma>mračit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e409-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e409-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e418-x3">
  <m id="m027-d1t427-3">
   <w.rf>
    <LM>w#w-d1t427-3</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t427-2">
   <w.rf>
    <LM>w#w-d1t427-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t427-4">
   <w.rf>
    <LM>w#w-d1t427-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t427-5">
   <w.rf>
    <LM>w#w-d1t427-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t427-6">
   <w.rf>
    <LM>w#w-d1t427-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m027-d1t427-7">
   <w.rf>
    <LM>w#w-d1t427-7</LM>
   </w.rf>
   <form>pouti</form>
   <lemma>pouť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-m-d1e418-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e418-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e428-x2">
  <m id="m027-d1t431-5">
   <w.rf>
    <LM>w#w-d1t431-5</LM>
   </w.rf>
   <form>Mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t431-4">
   <w.rf>
    <LM>w#w-d1t431-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t431-6">
   <w.rf>
    <LM>w#w-d1t431-6</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t431-7">
   <w.rf>
    <LM>w#w-d1t431-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t433-1">
   <w.rf>
    <LM>w#w-d1t433-1</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m027-d1t433-2">
   <w.rf>
    <LM>w#w-d1t433-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e428-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e428-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e434-x2">
  <m id="m027-d1t439-3">
   <w.rf>
    <LM>w#w-d1t439-3</LM>
   </w.rf>
   <form>Nejsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m027-d1t439-2">
   <w.rf>
    <LM>w#w-d1t439-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1t439-4">
   <w.rf>
    <LM>w#w-d1t439-4</LM>
   </w.rf>
   <form>jistá</form>
   <lemma>jistý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e434-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e434-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e434-x3">
  <m id="m027-d1t441-1">
   <w.rf>
    <LM>w#w-d1t441-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t441-2">
   <w.rf>
    <LM>w#w-d1t441-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t441-3">
   <w.rf>
    <LM>w#w-d1t441-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t441-4">
   <w.rf>
    <LM>w#w-d1t441-4</LM>
   </w.rf>
   <form>mračíte</form>
   <lemma>mračit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d-id70236-punct">
   <w.rf>
    <LM>w#w-d-id70236-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e442-x2">
  <m id="m027-d1t447-2">
   <w.rf>
    <LM>w#w-d1t447-2</LM>
   </w.rf>
   <form>Prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t447-4">
   <w.rf>
    <LM>w#w-d1t447-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t447-5">
   <w.rf>
    <LM>w#w-d1t447-5</LM>
   </w.rf>
   <form>mračím</form>
   <lemma>mračit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e442-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e442-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e450-x3">
  <m id="m027-d1t459-1">
   <w.rf>
    <LM>w#w-d1t459-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m027-d1t459-2">
   <w.rf>
    <LM>w#w-d1t459-2</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-m-d1e450-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e450-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e460-x2">
  <m id="m027-d1t463-2">
   <w.rf>
    <LM>w#w-d1t463-2</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t463-3">
   <w.rf>
    <LM>w#w-d1t463-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t463-4">
   <w.rf>
    <LM>w#w-d1t463-4</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t463-5">
   <w.rf>
    <LM>w#w-d1t463-5</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t463-6">
   <w.rf>
    <LM>w#w-d1t463-6</LM>
   </w.rf>
   <form>mračila</form>
   <lemma>mračit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e460-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e460-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e470-x2">
  <m id="m027-d1e470-x2-1038">
   <w.rf>
    <LM>w#w-d1e470-x2-1038</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e470-x2-1036">
   <w.rf>
    <LM>w#w-d1e470-x2-1036</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1e470-x2-1034">
   <w.rf>
    <LM>w#w-d1e470-x2-1034</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1e470-x2-1032">
   <w.rf>
    <LM>w#w-d1e470-x2-1032</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d1e470-x2-1028">
   <w.rf>
    <LM>w#w-d1e470-x2-1028</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-1030">
  <m id="m027-d1e470-x2-1022">
   <w.rf>
    <LM>w#w-d1e470-x2-1022</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1e470-x2-1020">
   <w.rf>
    <LM>w#w-d1e470-x2-1020</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1e470-x2-1018">
   <w.rf>
    <LM>w#w-d1e470-x2-1018</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m027-d1e470-x2-1016">
   <w.rf>
    <LM>w#w-d1e470-x2-1016</LM>
   </w.rf>
   <form>pouti</form>
   <lemma>pouť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-1030-1122">
   <w.rf>
    <LM>w#w-1030-1122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m027-d1t481-6">
   <w.rf>
    <LM>w#w-d1t481-6</LM>
   </w.rf>
   <form>svátečně</form>
   <lemma>svátečně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t481-7">
   <w.rf>
    <LM>w#w-d1t481-7</LM>
   </w.rf>
   <form>oblečení</form>
   <lemma>oblečený_^(*5éci)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-1030-1124">
   <w.rf>
    <LM>w#w-1030-1124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-1098">
  <m id="m027-d1t483-1">
   <w.rf>
    <LM>w#w-d1t483-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t483-2">
   <w.rf>
    <LM>w#w-d1t483-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t483-4">
   <w.rf>
    <LM>w#w-d1t483-4</LM>
   </w.rf>
   <form>šaty</form>
   <lemma>šaty</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1t483-5">
   <w.rf>
    <LM>w#w-d1t483-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t483-7">
   <w.rf>
    <LM>w#w-d1t483-7</LM>
   </w.rf>
   <form>vyšívaným</form>
   <lemma>vyšívaný_^(*2t)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m027-d1t483-6">
   <w.rf>
    <LM>w#w-d1t483-6</LM>
   </w.rf>
   <form>límečkem</form>
   <lemma>límeček</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d-id71260-punct">
   <w.rf>
    <LM>w#w-d-id71260-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t485-3">
   <w.rf>
    <LM>w#w-d1t485-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t485-5">
   <w.rf>
    <LM>w#w-d1t485-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t485-4">
   <w.rf>
    <LM>w#w-d1t485-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t485-6">
   <w.rf>
    <LM>w#w-d1t485-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t485-7">
   <w.rf>
    <LM>w#w-d1t485-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t485-8">
   <w.rf>
    <LM>w#w-d1t485-8</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m027-d1t485-9">
   <w.rf>
    <LM>w#w-d1t485-9</LM>
   </w.rf>
   <form>slavnosti</form>
   <lemma>slavnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-1098-180">
   <w.rf>
    <LM>w#w-1098-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-182">
  <m id="m027-d1t485-16">
   <w.rf>
    <LM>w#w-d1t485-16</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t485-19">
   <w.rf>
    <LM>w#w-d1t485-19</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t485-21">
   <w.rf>
    <LM>w#w-d1t485-21</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t485-22">
   <w.rf>
    <LM>w#w-d1t485-22</LM>
   </w.rf>
   <form>pouti</form>
   <lemma>pouť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id71545-punct">
   <w.rf>
    <LM>w#w-d-id71545-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t485-24">
   <w.rf>
    <LM>w#w-d1t485-24</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t485-26">
   <w.rf>
    <LM>w#w-d1t485-26</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t485-28">
   <w.rf>
    <LM>w#w-d1t485-28</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m027-d1t485-30">
   <w.rf>
    <LM>w#w-d1t485-30</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t485-31">
   <w.rf>
    <LM>w#w-d1t485-31</LM>
   </w.rf>
   <form>poutě</form>
   <lemma>pouť</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-d1t485-32">
   <w.rf>
    <LM>w#w-d1t485-32</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t485-33">
   <w.rf>
    <LM>w#w-d1t485-33</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-182-184">
   <w.rf>
    <LM>w#w-182-184</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m027-d1t485-35">
   <w.rf>
    <LM>w#w-d1t485-35</LM>
   </w.rf>
   <form>vršíčku</form>
   <lemma>vršíček_,e</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m027-d1t485-40">
   <w.rf>
    <LM>w#w-d1t485-40</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t485-43">
   <w.rf>
    <LM>w#w-d1t485-43</LM>
   </w.rf>
   <form>Litohlavech</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m027-d-id71727-punct">
   <w.rf>
    <LM>w#w-d-id71727-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t485-37">
   <w.rf>
    <LM>w#w-d1t485-37</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t485-38">
   <w.rf>
    <LM>w#w-d1t485-38</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t485-39">
   <w.rf>
    <LM>w#w-d1t485-39</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-1098-1130">
   <w.rf>
    <LM>w#w-1098-1130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-1132">
  <m id="m027-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t487-1">
   <w.rf>
    <LM>w#w-d1t487-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t487-3">
   <w.rf>
    <LM>w#w-d1t487-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t487-4">
   <w.rf>
    <LM>w#w-d1t487-4</LM>
   </w.rf>
   <form>slavná</form>
   <lemma>slavný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t487-5">
   <w.rf>
    <LM>w#w-d1t487-5</LM>
   </w.rf>
   <form>pouť</form>
   <lemma>pouť</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e478-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e478-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e500-x2">
  <m id="m027-d1t503-3">
   <w.rf>
    <LM>w#w-d1t503-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t503-4">
   <w.rf>
    <LM>w#w-d1t503-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t503-2">
   <w.rf>
    <LM>w#w-d1t503-2</LM>
   </w.rf>
   <form>kostelíček</form>
   <lemma>kostelíček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d-id72241-punct">
   <w.rf>
    <LM>w#w-d-id72241-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t503-7">
   <w.rf>
    <LM>w#w-d1t503-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t505-1">
   <w.rf>
    <LM>w#w-d1t505-1</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t505-2">
   <w.rf>
    <LM>w#w-d1t505-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m027-d1t505-3">
   <w.rf>
    <LM>w#w-d1t505-3</LM>
   </w.rf>
   <form>kostelíčkem</form>
   <lemma>kostelíček</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1t505-4">
   <w.rf>
    <LM>w#w-d1t505-4</LM>
   </w.rf>
   <form>bývaly</form>
   <lemma>bývat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t505-6">
   <w.rf>
    <LM>w#w-d1t505-6</LM>
   </w.rf>
   <form>poutě</form>
   <lemma>pouť</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-d1e500-x2-208">
   <w.rf>
    <LM>w#w-d1e500-x2-208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-210">
  <m id="m027-d1t505-8">
   <w.rf>
    <LM>w#w-d1t505-8</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t505-9">
   <w.rf>
    <LM>w#w-d1t505-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t505-10">
   <w.rf>
    <LM>w#w-d1t505-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t505-11">
   <w.rf>
    <LM>w#w-d1t505-11</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t505-12">
   <w.rf>
    <LM>w#w-d1t505-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t505-14">
   <w.rf>
    <LM>w#w-d1t505-14</LM>
   </w.rf>
   <form>pouti</form>
   <lemma>pouť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-m-d1e500-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e500-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e509-x2">
  <m id="m027-d1t512-1">
   <w.rf>
    <LM>w#w-d1t512-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t512-2">
   <w.rf>
    <LM>w#w-d1t512-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t512-3">
   <w.rf>
    <LM>w#w-d1t512-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t512-4">
   <w.rf>
    <LM>w#w-d1t512-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t512-5">
   <w.rf>
    <LM>w#w-d1t512-5</LM>
   </w.rf>
   <form>poutě</form>
   <lemma>pouť</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d-id72610-punct">
   <w.rf>
    <LM>w#w-d-id72610-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e513-x2">
  <m id="m027-d1t516-3">
   <w.rf>
    <LM>w#w-d1t516-3</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t516-4">
   <w.rf>
    <LM>w#w-d1t516-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t518-2">
   <w.rf>
    <LM>w#w-d1t518-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t518-4">
   <w.rf>
    <LM>w#w-d1t518-4</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m027-d-id72846-punct">
   <w.rf>
    <LM>w#w-d-id72846-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t518-8">
   <w.rf>
    <LM>w#w-d1t518-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t518-9">
   <w.rf>
    <LM>w#w-d1t518-9</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m027-d1t518-11">
   <w.rf>
    <LM>w#w-d1t518-11</LM>
   </w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1e513-x2-1160">
   <w.rf>
    <LM>w#w-d1e513-x2-1160</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t518-14">
   <w.rf>
    <LM>w#w-d1t518-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t518-15">
   <w.rf>
    <LM>w#w-d1t518-15</LM>
   </w.rf>
   <form>posvícení</form>
   <lemma>posvícení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d1t518-17">
   <w.rf>
    <LM>w#w-d1t518-17</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t518-18">
   <w.rf>
    <LM>w#w-d1t518-18</LM>
   </w.rf>
   <form>příbuzným</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m027-d1t518-19">
   <w.rf>
    <LM>w#w-d1t518-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t518-20">
   <w.rf>
    <LM>w#w-d1t518-20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-m-d1e513-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e513-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e519-x2">
  <m id="m027-d1t522-1">
   <w.rf>
    <LM>w#w-d1t522-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e519-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e519-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e523-x2">
  <m id="m027-d1t526-1">
   <w.rf>
    <LM>w#w-d1t526-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e523-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e523-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e527-x2">
  <m id="m027-d1t530-1">
   <w.rf>
    <LM>w#w-d1t530-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t530-2">
   <w.rf>
    <LM>w#w-d1t530-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t530-3">
   <w.rf>
    <LM>w#w-d1t530-3</LM>
   </w.rf>
   <form>jmenují</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---3P-AAB--</tag>
  </m>
  <m id="m027-d1t530-4">
   <w.rf>
    <LM>w#w-d1t530-4</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m027-d1t530-5">
   <w.rf>
    <LM>w#w-d1t530-5</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d-id73312-punct">
   <w.rf>
    <LM>w#w-d-id73312-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e531-x2">
  <m id="m027-d1t536-1">
   <w.rf>
    <LM>w#w-d1t536-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t536-2">
   <w.rf>
    <LM>w#w-d1t536-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t536-3">
   <w.rf>
    <LM>w#w-d1t536-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m027-d1t536-5">
   <w.rf>
    <LM>w#w-d1t536-5</LM>
   </w.rf>
   <form>Vlasta</form>
   <lemma>Vlasta_;Y_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t536-6">
   <w.rf>
    <LM>w#w-d1t536-6</LM>
   </w.rf>
   <form>Pelcová</form>
   <lemma>Pelcová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t536-8">
   <w.rf>
    <LM>w#w-d1t536-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t536-9">
   <w.rf>
    <LM>w#w-d1t536-9</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t536-10">
   <w.rf>
    <LM>w#w-d1t536-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t536-12">
   <w.rf>
    <LM>w#w-d1t536-12</LM>
   </w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t536-13">
   <w.rf>
    <LM>w#w-d1t536-13</LM>
   </w.rf>
   <form>Pelc</form>
   <lemma>Pelc_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e531-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e531-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e543-x3">
  <m id="m027-d1t550-1">
   <w.rf>
    <LM>w#w-d1t550-1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m027-d1t550-2">
   <w.rf>
    <LM>w#w-d1t550-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d-id73750-punct">
   <w.rf>
    <LM>w#w-d-id73750-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e551-x2">
  <m id="m027-d1t554-2">
   <w.rf>
    <LM>w#w-d1t554-2</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t554-3">
   <w.rf>
    <LM>w#w-d1t554-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t554-4">
   <w.rf>
    <LM>w#w-d1t554-4</LM>
   </w.rf>
   <form>vyučená</form>
   <lemma>vyučený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t554-5">
   <w.rf>
    <LM>w#w-d1t554-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>modistka</form>
   <lemma>modistka_^(*2a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id73898-punct">
   <w.rf>
    <LM>w#w-d-id73898-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t556-2">
   <w.rf>
    <LM>w#w-d1t556-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t556-3">
   <w.rf>
    <LM>w#w-d1t556-3</LM>
   </w.rf>
   <form>šila</form>
   <lemma>šít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t556-4">
   <w.rf>
    <LM>w#w-d1t556-4</LM>
   </w.rf>
   <form>klobouky</form>
   <lemma>klobouk</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1e551-x2-276">
   <w.rf>
    <LM>w#w-d1e551-x2-276</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t558-1">
   <w.rf>
    <LM>w#w-d1t558-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t558-2">
   <w.rf>
    <LM>w#w-d1t558-2</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t558-3">
   <w.rf>
    <LM>w#w-d1t558-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t558-4">
   <w.rf>
    <LM>w#w-d1t558-4</LM>
   </w.rf>
   <form>vyučený</form>
   <lemma>vyučený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1t558-5">
   <w.rf>
    <LM>w#w-d1t558-5</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e551-x2-1208">
   <w.rf>
    <LM>w#w-d1e551-x2-1208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-1210">
  <m id="m027-d1t560-1">
   <w.rf>
    <LM>w#w-d1t560-1</LM>
   </w.rf>
   <form>Vyučil</form>
   <lemma>vyučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d1t560-2">
   <w.rf>
    <LM>w#w-d1t560-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t560-3">
   <w.rf>
    <LM>w#w-d1t560-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t560-5">
   <w.rf>
    <LM>w#w-d1t560-5</LM>
   </w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-2_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-1210-1216">
   <w.rf>
    <LM>w#w-1210-1216</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-1210-292">
   <w.rf>
    <LM>w#w-1210-292</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t560-17">
   <w.rf>
    <LM>w#w-d1t560-17</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t560-14">
   <w.rf>
    <LM>w#w-d1t560-14</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m027-d1t560-15">
   <w.rf>
    <LM>w#w-d1t560-15</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d1t560-18">
   <w.rf>
    <LM>w#w-d1t560-18</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m027-d1t560-20">
   <w.rf>
    <LM>w#w-d1t560-20</LM>
   </w.rf>
   <form>Škodovce</form>
   <lemma>Škodovka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id74390-punct">
   <w.rf>
    <LM>w#w-d-id74390-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t560-23">
   <w.rf>
    <LM>w#w-d1t560-23</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t560-24">
   <w.rf>
    <LM>w#w-d1t560-24</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t560-25">
   <w.rf>
    <LM>w#w-d1t560-25</LM>
   </w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-1210-1218">
   <w.rf>
    <LM>w#w-1210-1218</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t560-26">
   <w.rf>
    <LM>w#w-d1t560-26</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t560-27">
   <w.rf>
    <LM>w#w-d1t560-27</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t560-28">
   <w.rf>
    <LM>w#w-d1t560-28</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t560-29">
   <w.rf>
    <LM>w#w-d1t560-29</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t560-30">
   <w.rf>
    <LM>w#w-d1t560-30</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t562-1">
   <w.rf>
    <LM>w#w-d1t562-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t562-2">
   <w.rf>
    <LM>w#w-d1t562-2</LM>
   </w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-1210-1220">
   <w.rf>
    <LM>w#w-1210-1220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-1222">
  <m id="m027-d1t562-3">
   <w.rf>
    <LM>w#w-d1t562-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t562-4">
   <w.rf>
    <LM>w#w-d1t562-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t562-6">
   <w.rf>
    <LM>w#w-d1t562-6</LM>
   </w.rf>
   <form>dílny</form>
   <lemma>dílna</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-d1t562-7">
   <w.rf>
    <LM>w#w-d1t562-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t562-8">
   <w.rf>
    <LM>w#w-d1t562-8</LM>
   </w.rf>
   <form>opravu</form>
   <lemma>oprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t562-9">
   <w.rf>
    <LM>w#w-d1t562-9</LM>
   </w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-1222-1232">
   <w.rf>
    <LM>w#w-1222-1232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t576-2">
   <w.rf>
    <LM>w#w-d1t576-2</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t576-1">
   <w.rf>
    <LM>w#w-d1t576-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t576-3">
   <w.rf>
    <LM>w#w-d1t576-3</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t576-4">
   <w.rf>
    <LM>w#w-d1t576-4</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-1222-1234">
   <w.rf>
    <LM>w#w-1222-1234</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e573-x2">
  <m id="m027-d1t576-5">
   <w.rf>
    <LM>w#w-d1t576-5</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t576-6">
   <w.rf>
    <LM>w#w-d1t576-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t576-7">
   <w.rf>
    <LM>w#w-d1t576-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t576-8">
   <w.rf>
    <LM>w#w-d1t576-8</LM>
   </w.rf>
   <form>jmenovalo</form>
   <lemma>jmenovat</lemma>
   <tag>VpNS----R-AAB--</tag>
  </m>
  <m id="m027-d1t576-10">
   <w.rf>
    <LM>w#w-d1t576-10</LM>
   </w.rf>
   <form>Železniční</form>
   <lemma>železniční</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m027-d1t576-11">
   <w.rf>
    <LM>w#w-d1t576-11</LM>
   </w.rf>
   <form>opravny</form>
   <lemma>opravna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d1t576-12">
   <w.rf>
    <LM>w#w-d1t576-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t576-13">
   <w.rf>
    <LM>w#w-d1t576-13</LM>
   </w.rf>
   <form>strojírny</form>
   <lemma>strojírna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d1e573-x2-1236">
   <w.rf>
    <LM>w#w-d1e573-x2-1236</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e573-x2-302">
   <w.rf>
    <LM>w#w-d1e573-x2-302</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t576-16">
   <w.rf>
    <LM>w#w-d1t576-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t576-17">
   <w.rf>
    <LM>w#w-d1t576-17</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t576-18">
   <w.rf>
    <LM>w#w-d1t576-18</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t576-19">
   <w.rf>
    <LM>w#w-d1t576-19</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t576-20">
   <w.rf>
    <LM>w#w-d1t576-20</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t576-21">
   <w.rf>
    <LM>w#w-d1t576-21</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t576-22">
   <w.rf>
    <LM>w#w-d1t576-22</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e573-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e573-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e580-x2">
  <m id="m027-d1t583-2">
   <w.rf>
    <LM>w#w-d1t583-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t583-1">
   <w.rf>
    <LM>w#w-d1t583-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t583-4">
   <w.rf>
    <LM>w#w-d1t583-4</LM>
   </w.rf>
   <form>naživu</form>
   <lemma>naživu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-id75252-punct">
   <w.rf>
    <LM>w#w-d-id75252-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e584-x2">
  <m id="m027-d1t587-1">
   <w.rf>
    <LM>w#w-d1t587-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d-id75329-punct">
   <w.rf>
    <LM>w#w-d-id75329-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t587-4">
   <w.rf>
    <LM>w#w-d1t587-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t587-5">
   <w.rf>
    <LM>w#w-d1t587-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t587-7">
   <w.rf>
    <LM>w#w-d1t587-7</LM>
   </w.rf>
   <form>naživu</form>
   <lemma>naživu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e584-x2-1266">
   <w.rf>
    <LM>w#w-d1e584-x2-1266</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
