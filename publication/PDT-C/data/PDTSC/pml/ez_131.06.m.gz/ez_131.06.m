<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_131.06.w.gz" />
  </references>
 </head>
 <s id="m131-d1e1103-x2">
  <m id="m131-d1t1106-2">
   <w.rf>
    <LM>w#w-d1t1106-2</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1106-3">
   <w.rf>
    <LM>w#w-d1t1106-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1106-4">
   <w.rf>
    <LM>w#w-d1t1106-4</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m131-d1t1106-5">
   <w.rf>
    <LM>w#w-d1t1106-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d-id113131-punct">
   <w.rf>
    <LM>w#w-d-id113131-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1107-x2">
  <m id="m131-d1t1110-1">
   <w.rf>
    <LM>w#w-d1t1110-1</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m131-d1t1110-2">
   <w.rf>
    <LM>w#w-d1t1110-2</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1t1110-3">
   <w.rf>
    <LM>w#w-d1t1110-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1110-4">
   <w.rf>
    <LM>w#w-d1t1110-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1110-6">
   <w.rf>
    <LM>w#w-d1t1110-6</LM>
   </w.rf>
   <form>Alsaska</form>
   <lemma>Alsasko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m131-d-id113287-punct">
   <w.rf>
    <LM>w#w-d-id113287-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1110-9">
   <w.rf>
    <LM>w#w-d1t1110-9</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m131-d1t1110-10">
   <w.rf>
    <LM>w#w-d1t1110-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1110-11">
   <w.rf>
    <LM>w#w-d1t1110-11</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m131-d1t1110-12">
   <w.rf>
    <LM>w#w-d1t1110-12</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1110-13">
   <w.rf>
    <LM>w#w-d1t1110-13</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1e1107-x2-527">
   <w.rf>
    <LM>w#w-d1e1107-x2-527</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-528">
  <m id="m131-d1t1118-2">
   <w.rf>
    <LM>w#w-d1t1118-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1118-4">
   <w.rf>
    <LM>w#w-d1t1118-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1118-5">
   <w.rf>
    <LM>w#w-d1t1118-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m131-d1t1118-6">
   <w.rf>
    <LM>w#w-d1t1118-6</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m131-d1t1121-1">
   <w.rf>
    <LM>w#w-d1t1121-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1121-2">
   <w.rf>
    <LM>w#w-d1t1121-2</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m131-d1t1121-3">
   <w.rf>
    <LM>w#w-d1t1121-3</LM>
   </w.rf>
   <form>kolega</form>
   <lemma>kolega</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m131-528-529">
   <w.rf>
    <LM>w#w-528-529</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1121-4">
   <w.rf>
    <LM>w#w-d1t1121-4</LM>
   </w.rf>
   <form>farář</form>
   <lemma>farář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m131-d1t1121-5">
   <w.rf>
    <LM>w#w-d1t1121-5</LM>
   </w.rf>
   <form>luterské</form>
   <lemma>luterský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m131-d1t1121-6">
   <w.rf>
    <LM>w#w-d1t1121-6</LM>
   </w.rf>
   <form>církve</form>
   <lemma>církev</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-d-id113611-punct">
   <w.rf>
    <LM>w#w-d-id113611-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1121-8">
   <w.rf>
    <LM>w#w-d1t1121-8</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m131-d1t1121-9">
   <w.rf>
    <LM>w#w-d1t1121-9</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1121-10">
   <w.rf>
    <LM>w#w-d1t1121-10</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m131-d1t1121-11">
   <w.rf>
    <LM>w#w-d1t1121-11</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m131-d1t1121-12">
   <w.rf>
    <LM>w#w-d1t1121-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1121-14">
   <w.rf>
    <LM>w#w-d1t1121-14</LM>
   </w.rf>
   <form>Alsasku</form>
   <lemma>Alsasko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m131-d1t1121-16">
   <w.rf>
    <LM>w#w-d1t1121-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1123-2">
   <w.rf>
    <LM>w#w-d1t1123-2</LM>
   </w.rf>
   <form>pozvali</form>
   <lemma>pozvat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1123-3">
   <w.rf>
    <LM>w#w-d1t1123-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m131-d1t1123-4">
   <w.rf>
    <LM>w#w-d1t1123-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-528-561">
   <w.rf>
    <LM>w#w-528-561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-562">
  <m id="m131-d1t1123-6">
   <w.rf>
    <LM>w#w-d1t1123-6</LM>
   </w.rf>
   <form>Seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1123-7">
   <w.rf>
    <LM>w#w-d1t1123-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1123-8">
   <w.rf>
    <LM>w#w-d1t1123-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1123-9">
   <w.rf>
    <LM>w#w-d1t1123-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m131-d1t1123-10">
   <w.rf>
    <LM>w#w-d1t1123-10</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m131-d1t1125-3">
   <w.rf>
    <LM>w#w-d1t1125-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1125-5">
   <w.rf>
    <LM>w#w-d1t1125-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d1t1125-4">
   <w.rf>
    <LM>w#w-d1t1125-4</LM>
   </w.rf>
   <form>1969</form>
   <lemma>1969</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d1t1125-6">
   <w.rf>
    <LM>w#w-d1t1125-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1125-7">
   <w.rf>
    <LM>w#w-d1t1125-7</LM>
   </w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m131-d1t1125-8">
   <w.rf>
    <LM>w#w-d1t1125-8</LM>
   </w.rf>
   <form>církevní</form>
   <lemma>církevní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m131-d1t1125-9">
   <w.rf>
    <LM>w#w-d1t1125-9</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d-id114052-punct">
   <w.rf>
    <LM>w#w-d-id114052-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1127-1">
   <w.rf>
    <LM>w#w-d1t1127-1</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m131-d1t1127-2">
   <w.rf>
    <LM>w#w-d1t1127-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1127-3">
   <w.rf>
    <LM>w#w-d1t1127-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1127-4">
   <w.rf>
    <LM>w#w-d1t1127-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m131-d1t1127-5">
   <w.rf>
    <LM>w#w-d1t1127-5</LM>
   </w.rf>
   <form>manželské</form>
   <lemma>manželský</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m131-d1t1127-6">
   <w.rf>
    <LM>w#w-d1t1127-6</LM>
   </w.rf>
   <form>páry</form>
   <lemma>pár-2</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m131-d1t1127-7">
   <w.rf>
    <LM>w#w-d1t1127-7</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1127-8">
   <w.rf>
    <LM>w#w-d1t1127-8</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m131-d1t1127-9">
   <w.rf>
    <LM>w#w-d1t1127-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1127-12">
   <w.rf>
    <LM>w#w-d1t1127-12</LM>
   </w.rf>
   <form>Locarnu</form>
   <lemma>Locarno_;G</lemma>
   <tag>NNNS6-----A---1</tag>
  </m>
  <m id="m131-562-578">
   <w.rf>
    <LM>w#w-562-578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1107-x3">
  <m id="m131-d1t1134-2">
   <w.rf>
    <LM>w#w-d1t1134-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1134-4">
   <w.rf>
    <LM>w#w-d1t1134-4</LM>
   </w.rf>
   <form>uplynulo</form>
   <lemma>uplynout</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m131-d1t1134-5">
   <w.rf>
    <LM>w#w-d1t1134-5</LM>
   </w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d1t1134-6">
   <w.rf>
    <LM>w#w-d1t1134-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m131-d-id114380-punct">
   <w.rf>
    <LM>w#w-d-id114380-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1136-1">
   <w.rf>
    <LM>w#w-d1t1136-1</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m131-d1t1136-2">
   <w.rf>
    <LM>w#w-d1t1136-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1136-3">
   <w.rf>
    <LM>w#w-d1t1136-3</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m131-d1t1136-4">
   <w.rf>
    <LM>w#w-d1t1136-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m131-d-id114498-punct">
   <w.rf>
    <LM>w#w-d-id114498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1136-6">
   <w.rf>
    <LM>w#w-d1t1136-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m131-d1t1136-7">
   <w.rf>
    <LM>w#w-d1t1136-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m131-d1e1107-x3-581">
   <w.rf>
    <LM>w#w-d1e1107-x3-581</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1136-9">
   <w.rf>
    <LM>w#w-d1t1136-9</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m131-d1t1136-10">
   <w.rf>
    <LM>w#w-d1t1136-10</LM>
   </w.rf>
   <form>uplynul</form>
   <lemma>uplynout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m131-d1e1107-x3-579">
   <w.rf>
    <LM>w#w-d1e1107-x3-579</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-580">
  <m id="m131-d1t1138-5">
   <w.rf>
    <LM>w#w-d1t1138-5</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1138-2">
   <w.rf>
    <LM>w#w-d1t1138-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1138-3">
   <w.rf>
    <LM>w#w-d1t1138-3</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1138-9">
   <w.rf>
    <LM>w#w-d1t1138-9</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1138-7">
   <w.rf>
    <LM>w#w-d1t1138-7</LM>
   </w.rf>
   <form>báli</form>
   <lemma>bát-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1138-6">
   <w.rf>
    <LM>w#w-d1t1138-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1138-10">
   <w.rf>
    <LM>w#w-d1t1138-10</LM>
   </w.rf>
   <form>psát</form>
   <lemma>psát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m131-580-582">
   <w.rf>
    <LM>w#w-580-582</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1140-2">
   <w.rf>
    <LM>w#w-d1t1140-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1140-3">
   <w.rf>
    <LM>w#w-d1t1140-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1140-4">
   <w.rf>
    <LM>w#w-d1t1140-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m131-d1t1140-5">
   <w.rf>
    <LM>w#w-d1t1140-5</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1140-6">
   <w.rf>
    <LM>w#w-d1t1140-6</LM>
   </w.rf>
   <form>představu</form>
   <lemma>představa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m131-580-117">
   <w.rf>
    <LM>w#w-580-117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-580-118">
   <w.rf>
    <LM>w#w-580-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-580-119">
   <w.rf>
    <LM>w#w-580-119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-584">
  <m id="m131-d1t1144-2">
   <w.rf>
    <LM>w#w-d1t1144-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1144-3">
   <w.rf>
    <LM>w#w-d1t1144-3</LM>
   </w.rf>
   <form>revoluci</form>
   <lemma>revoluce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1144-4">
   <w.rf>
    <LM>w#w-d1t1144-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1144-7">
   <w.rf>
    <LM>w#w-d1t1144-7</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1144-5">
   <w.rf>
    <LM>w#w-d1t1144-5</LM>
   </w.rf>
   <form>navázali</form>
   <lemma>navázat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1144-8">
   <w.rf>
    <LM>w#w-d1t1144-8</LM>
   </w.rf>
   <form>styk</form>
   <lemma>styk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m131-584-123">
   <w.rf>
    <LM>w#w-584-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-124">
  <m id="m131-d1t1144-10">
   <w.rf>
    <LM>w#w-d1t1144-10</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m131-d-id115075-punct">
   <w.rf>
    <LM>w#w-d-id115075-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1144-12">
   <w.rf>
    <LM>w#w-d1t1144-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1144-14">
   <w.rf>
    <LM>w#w-d1t1144-14</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m131-d1t1144-13">
   <w.rf>
    <LM>w#w-d1t1144-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-124-125">
   <w.rf>
    <LM>w#w-124-125</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1144-15">
   <w.rf>
    <LM>w#w-d1t1144-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1144-16">
   <w.rf>
    <LM>w#w-d1t1144-16</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d-id115161-punct">
   <w.rf>
    <LM>w#w-d-id115161-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1144-18">
   <w.rf>
    <LM>w#w-d1t1144-18</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m131-124-126">
   <w.rf>
    <LM>w#w-124-126</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-124-127">
   <w.rf>
    <LM>w#w-124-127</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1144-19">
   <w.rf>
    <LM>w#w-d1t1144-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1144-20">
   <w.rf>
    <LM>w#w-d1t1144-20</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d-id115216-punct">
   <w.rf>
    <LM>w#w-d-id115216-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1144-22">
   <w.rf>
    <LM>w#w-d1t1144-22</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1147-1">
   <w.rf>
    <LM>w#w-d1t1147-1</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m131-d1t1147-2">
   <w.rf>
    <LM>w#w-d1t1147-2</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1147-3">
   <w.rf>
    <LM>w#w-d1t1147-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m131-d1t1147-4">
   <w.rf>
    <LM>w#w-d1t1147-4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m131-d1t1147-5">
   <w.rf>
    <LM>w#w-d1t1147-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1147-6">
   <w.rf>
    <LM>w#w-d1t1147-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m131-d1t1147-7">
   <w.rf>
    <LM>w#w-d1t1147-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m131-d1t1147-8">
   <w.rf>
    <LM>w#w-d1t1147-8</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m131-584-605">
   <w.rf>
    <LM>w#w-584-605</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1107-x4">
  <m id="m131-d1t1147-11">
   <w.rf>
    <LM>w#w-d1t1147-11</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1147-12">
   <w.rf>
    <LM>w#w-d1t1147-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1147-14">
   <w.rf>
    <LM>w#w-d1t1147-14</LM>
   </w.rf>
   <form>úžasní</form>
   <lemma>úžasný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m131-d1t1147-15">
   <w.rf>
    <LM>w#w-d1t1147-15</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m131-d1t1149-1">
   <w.rf>
    <LM>w#w-d1t1149-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1149-4">
   <w.rf>
    <LM>w#w-d1t1149-4</LM>
   </w.rf>
   <form>Alsasko</form>
   <lemma>Alsasko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m131-d1t1149-6">
   <w.rf>
    <LM>w#w-d1t1149-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1149-7">
   <w.rf>
    <LM>w#w-d1t1149-7</LM>
   </w.rf>
   <form>nádherné</form>
   <lemma>nádherný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m131-d1e1107-x4-606">
   <w.rf>
    <LM>w#w-d1e1107-x4-606</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1151-1">
   <w.rf>
    <LM>w#w-d1t1151-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1151-2">
   <w.rf>
    <LM>w#w-d1t1151-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1151-3">
   <w.rf>
    <LM>w#w-d1t1151-3</LM>
   </w.rf>
   <form>fotila</form>
   <lemma>fotit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1151-4">
   <w.rf>
    <LM>w#w-d1t1151-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1151-5">
   <w.rf>
    <LM>w#w-d1t1151-5</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m131-d1t1151-6">
   <w.rf>
    <LM>w#w-d1t1151-6</LM>
   </w.rf>
   <form>kroku</form>
   <lemma>krok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m131-d1e1107-x4-607">
   <w.rf>
    <LM>w#w-d1e1107-x4-607</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-608">
  <m id="m131-d1t1151-8">
   <w.rf>
    <LM>w#w-d1t1151-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1151-9">
   <w.rf>
    <LM>w#w-d1t1151-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m131-d1t1151-10">
   <w.rf>
    <LM>w#w-d1t1151-10</LM>
   </w.rf>
   <form>fascinovalo</form>
   <lemma>fascinovat</lemma>
   <tag>VpNS----R-AAB--</tag>
  </m>
  <m id="m131-608-613">
   <w.rf>
    <LM>w#w-608-613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-614">
  <m id="m131-d1t1153-1">
   <w.rf>
    <LM>w#w-d1t1153-1</LM>
   </w.rf>
   <form>Domy</form>
   <lemma>dům</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m131-614-135">
   <w.rf>
    <LM>w#w-614-135</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1153-2">
   <w.rf>
    <LM>w#w-d1t1153-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1153-3">
   <w.rf>
    <LM>w#w-d1t1153-3</LM>
   </w.rf>
   <form>venku</form>
   <lemma>venku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1153-4">
   <w.rf>
    <LM>w#w-d1t1153-4</LM>
   </w.rf>
   <form>úžasně</form>
   <lemma>úžasně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1153-5">
   <w.rf>
    <LM>w#w-d1t1153-5</LM>
   </w.rf>
   <form>uchované</form>
   <lemma>uchovaný_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m131-d-id115856-punct">
   <w.rf>
    <LM>w#w-d-id115856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1153-7">
   <w.rf>
    <LM>w#w-d1t1153-7</LM>
   </w.rf>
   <form>každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m131-d1t1153-8">
   <w.rf>
    <LM>w#w-d1t1153-8</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1t1153-9">
   <w.rf>
    <LM>w#w-d1t1153-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1153-10">
   <w.rf>
    <LM>w#w-d1t1153-10</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m131-d1t1153-11">
   <w.rf>
    <LM>w#w-d1t1153-11</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1t1155-1">
   <w.rf>
    <LM>w#w-d1t1155-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1155-2">
   <w.rf>
    <LM>w#w-d1t1155-2</LM>
   </w.rf>
   <form>vevnitř</form>
   <lemma>vevnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-614-140">
   <w.rf>
    <LM>w#w-614-140</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1155-3">
   <w.rf>
    <LM>w#w-d1t1155-3</LM>
   </w.rf>
   <form>komfort</form>
   <lemma>komfort</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m131-d-id115998-punct">
   <w.rf>
    <LM>w#w-d-id115998-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1155-5">
   <w.rf>
    <LM>w#w-d1t1155-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1155-6">
   <w.rf>
    <LM>w#w-d1t1155-6</LM>
   </w.rf>
   <form>stylový</form>
   <lemma>stylový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m131-d-m-d1e1107-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1107-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1156-x2">
  <m id="m131-d1t1159-1">
   <w.rf>
    <LM>w#w-d1t1159-1</LM>
   </w.rf>
   <form>Cestujete</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m131-d1t1159-2">
   <w.rf>
    <LM>w#w-d1t1159-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m131-d-id116122-punct">
   <w.rf>
    <LM>w#w-d-id116122-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1160-x2">
  <m id="m131-d1t1163-1">
   <w.rf>
    <LM>w#w-d1t1163-1</LM>
   </w.rf>
   <form>Strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1e1160-x2-616">
   <w.rf>
    <LM>w#w-d1e1160-x2-616</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-617">
  <m id="m131-d1t1165-2">
   <w.rf>
    <LM>w#w-d1t1165-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m131-d1t1165-3">
   <w.rf>
    <LM>w#w-d1t1165-3</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m131-d1t1165-4">
   <w.rf>
    <LM>w#w-d1t1165-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d-m-d1e1160-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1160-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1168-x2">
  <m id="m131-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1171-2">
   <w.rf>
    <LM>w#w-d1t1171-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m131-d1t1171-3">
   <w.rf>
    <LM>w#w-d1t1171-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1171-4">
   <w.rf>
    <LM>w#w-d1t1171-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1171-5">
   <w.rf>
    <LM>w#w-d1t1171-5</LM>
   </w.rf>
   <form>zahraničí</form>
   <lemma>zahraničí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m131-d1t1171-6">
   <w.rf>
    <LM>w#w-d1t1171-6</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d-id116431-punct">
   <w.rf>
    <LM>w#w-d-id116431-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1172-x2">
  <m id="m131-d1t1179-1">
   <w.rf>
    <LM>w#w-d1t1179-1</LM>
   </w.rf>
   <form>Úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1179-2">
   <w.rf>
    <LM>w#w-d1t1179-2</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1179-3">
   <w.rf>
    <LM>w#w-d1t1179-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1179-4">
   <w.rf>
    <LM>w#w-d1t1179-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1181-1">
   <w.rf>
    <LM>w#w-d1t1181-1</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1181-3">
   <w.rf>
    <LM>w#w-d1t1181-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1181-5">
   <w.rf>
    <LM>w#w-d1t1181-5</LM>
   </w.rf>
   <form>NDR</form>
   <lemma>NDR-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m131-d1e1172-x2-631">
   <w.rf>
    <LM>w#w-d1e1172-x2-631</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-632">
  <m id="m131-d1t1188-2">
   <w.rf>
    <LM>w#w-d1t1188-2</LM>
   </w.rf>
   <form>Poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1188-3">
   <w.rf>
    <LM>w#w-d1t1188-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1188-4">
   <w.rf>
    <LM>w#w-d1t1188-4</LM>
   </w.rf>
   <form>viděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1188-5">
   <w.rf>
    <LM>w#w-d1t1188-5</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m131-d1t1188-7">
   <w.rf>
    <LM>w#w-d1t1188-7</LM>
   </w.rf>
   <form>Balt</form>
   <lemma>Balt_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m131-d1t1190-1">
   <w.rf>
    <LM>w#w-d1t1190-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1190-2">
   <w.rf>
    <LM>w#w-d1t1190-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d1t1190-3">
   <w.rf>
    <LM>w#w-d1t1190-3</LM>
   </w.rf>
   <form>1965</form>
   <lemma>1965</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d-id116905-punct">
   <w.rf>
    <LM>w#w-d-id116905-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1190-6">
   <w.rf>
    <LM>w#w-d1t1190-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1190-7">
   <w.rf>
    <LM>w#w-d1t1190-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1190-8">
   <w.rf>
    <LM>w#w-d1t1190-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1192-1">
   <w.rf>
    <LM>w#w-d1t1192-1</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m131-d1t1192-2">
   <w.rf>
    <LM>w#w-d1t1192-2</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m131-d1t1192-3">
   <w.rf>
    <LM>w#w-d1t1192-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1192-4">
   <w.rf>
    <LM>w#w-d1t1192-4</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m131-d1t1192-5">
   <w.rf>
    <LM>w#w-d1t1192-5</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m131-d1t1192-6">
   <w.rf>
    <LM>w#w-d1t1192-6</LM>
   </w.rf>
   <form>těhotná</form>
   <lemma>těhotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m131-d1t1192-7">
   <w.rf>
    <LM>w#w-d1t1192-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m131-d1t1192-8">
   <w.rf>
    <LM>w#w-d1t1192-8</LM>
   </w.rf>
   <form>dcerou</form>
   <lemma>dcera</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m131-d1e1172-x2-629">
   <w.rf>
    <LM>w#w-d1e1172-x2-629</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-630">
  <m id="m131-d1t1192-11">
   <w.rf>
    <LM>w#w-d1t1192-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1192-12">
   <w.rf>
    <LM>w#w-d1t1192-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1192-13">
   <w.rf>
    <LM>w#w-d1t1192-13</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m131-d1t1192-14">
   <w.rf>
    <LM>w#w-d1t1192-14</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m131-d1t1192-15">
   <w.rf>
    <LM>w#w-d1t1192-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1192-16">
   <w.rf>
    <LM>w#w-d1t1192-16</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m131-d-id117211-punct">
   <w.rf>
    <LM>w#w-d-id117211-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1192-18">
   <w.rf>
    <LM>w#w-d1t1192-18</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m131-d1t1192-19">
   <w.rf>
    <LM>w#w-d1t1192-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1192-20">
   <w.rf>
    <LM>w#w-d1t1192-20</LM>
   </w.rf>
   <form>viděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-630-633">
   <w.rf>
    <LM>w#w-630-633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-634">
  <m id="m131-d1t1196-2">
   <w.rf>
    <LM>w#w-d1t1196-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1196-3">
   <w.rf>
    <LM>w#w-d1t1196-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1196-4">
   <w.rf>
    <LM>w#w-d1t1196-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1196-5">
   <w.rf>
    <LM>w#w-d1t1196-5</LM>
   </w.rf>
   <form>strávili</form>
   <lemma>strávit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1196-6">
   <w.rf>
    <LM>w#w-d1t1196-6</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m131-d1t1196-7">
   <w.rf>
    <LM>w#w-d1t1196-7</LM>
   </w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m131-d-id117399-punct">
   <w.rf>
    <LM>w#w-d-id117399-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1196-9">
   <w.rf>
    <LM>w#w-d1t1196-9</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1196-10">
   <w.rf>
    <LM>w#w-d1t1196-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1196-11">
   <w.rf>
    <LM>w#w-d1t1196-11</LM>
   </w.rf>
   <form>zima</form>
   <lemma>zima-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d-id117454-punct">
   <w.rf>
    <LM>w#w-d-id117454-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1196-13">
   <w.rf>
    <LM>w#w-d1t1196-13</LM>
   </w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1196-14">
   <w.rf>
    <LM>w#w-d1t1196-14</LM>
   </w.rf>
   <form>mráz</form>
   <lemma>mráz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m131-634-635">
   <w.rf>
    <LM>w#w-634-635</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1199-1">
   <w.rf>
    <LM>w#w-d1t1199-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1199-2">
   <w.rf>
    <LM>w#w-d1t1199-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1199-3">
   <w.rf>
    <LM>w#w-d1t1199-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1199-4">
   <w.rf>
    <LM>w#w-d1t1199-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m131-d-m-d1e1172-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1172-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1206-x2">
  <m id="m131-d1t1209-2">
   <w.rf>
    <LM>w#w-d1t1209-2</LM>
   </w.rf>
   <form>Umíte</form>
   <lemma>umět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m131-d1t1209-3">
   <w.rf>
    <LM>w#w-d1t1209-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m131-d1t1209-4">
   <w.rf>
    <LM>w#w-d1t1209-4</LM>
   </w.rf>
   <form>cizí</form>
   <lemma>cizí</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m131-d1t1209-5">
   <w.rf>
    <LM>w#w-d1t1209-5</LM>
   </w.rf>
   <form>jazyk</form>
   <lemma>jazyk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m131-d-id117695-punct">
   <w.rf>
    <LM>w#w-d-id117695-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1210-x2">
  <m id="m131-d1t1213-3">
   <w.rf>
    <LM>w#w-d1t1213-3</LM>
   </w.rf>
   <form>Domluvím</form>
   <lemma>domluvit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m131-d1t1213-4">
   <w.rf>
    <LM>w#w-d1t1213-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1213-5">
   <w.rf>
    <LM>w#w-d1t1213-5</LM>
   </w.rf>
   <form>německy</form>
   <lemma>německy_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1213-6">
   <w.rf>
    <LM>w#w-d1t1213-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1213-7">
   <w.rf>
    <LM>w#w-d1t1213-7</LM>
   </w.rf>
   <form>francouzsky</form>
   <lemma>francouzsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1e1210-x2-648">
   <w.rf>
    <LM>w#w-d1e1210-x2-648</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1215-1">
   <w.rf>
    <LM>w#w-d1t1215-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1215-2">
   <w.rf>
    <LM>w#w-d1t1215-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1215-4">
   <w.rf>
    <LM>w#w-d1t1215-4</LM>
   </w.rf>
   <form>jedu</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1215-3">
   <w.rf>
    <LM>w#w-d1t1215-3</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1215-6">
   <w.rf>
    <LM>w#w-d1t1215-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1215-8">
   <w.rf>
    <LM>w#w-d1t1215-8</LM>
   </w.rf>
   <form>Itálie</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-d1t1215-10">
   <w.rf>
    <LM>w#w-d1t1215-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1215-13">
   <w.rf>
    <LM>w#w-d1t1215-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1215-15">
   <w.rf>
    <LM>w#w-d1t1215-15</LM>
   </w.rf>
   <form>Chorvatska</form>
   <lemma>Chorvatsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m131-d1e1210-x2-649">
   <w.rf>
    <LM>w#w-d1e1210-x2-649</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1215-17">
   <w.rf>
    <LM>w#w-d1t1215-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1215-18">
   <w.rf>
    <LM>w#w-d1t1215-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1215-20">
   <w.rf>
    <LM>w#w-d1t1215-20</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1215-19">
   <w.rf>
    <LM>w#w-d1t1215-19</LM>
   </w.rf>
   <form>snažím</form>
   <lemma>snažit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1e1210-x2-650">
   <w.rf>
    <LM>w#w-d1e1210-x2-650</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1215-22">
   <w.rf>
    <LM>w#w-d1t1215-22</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m131-d1t1215-23">
   <w.rf>
    <LM>w#w-d1t1215-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1215-21">
   <w.rf>
    <LM>w#w-d1t1215-21</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1215-24">
   <w.rf>
    <LM>w#w-d1t1215-24</LM>
   </w.rf>
   <form>domluvila</form>
   <lemma>domluvit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m131-d1e1210-x2-651">
   <w.rf>
    <LM>w#w-d1e1210-x2-651</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-652">
  <m id="m131-d1t1219-1">
   <w.rf>
    <LM>w#w-d1t1219-1</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1219-2">
   <w.rf>
    <LM>w#w-d1t1219-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1219-3">
   <w.rf>
    <LM>w#w-d1t1219-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1219-4">
   <w.rf>
    <LM>w#w-d1t1219-4</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1219-5">
   <w.rf>
    <LM>w#w-d1t1219-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1219-6">
   <w.rf>
    <LM>w#w-d1t1219-6</LM>
   </w.rf>
   <form>maďarsky</form>
   <lemma>maďarsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d-id118336-punct">
   <w.rf>
    <LM>w#w-d-id118336-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1219-8">
   <w.rf>
    <LM>w#w-d1t1219-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1219-9">
   <w.rf>
    <LM>w#w-d1t1219-9</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1219-10">
   <w.rf>
    <LM>w#w-d1t1219-10</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m131-d1t1219-12">
   <w.rf>
    <LM>w#w-d1t1219-12</LM>
   </w.rf>
   <form>Maďarsko</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m131-652-653">
   <w.rf>
    <LM>w#w-652-653</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-654">
  <m id="m131-d1t1226-2">
   <w.rf>
    <LM>w#w-d1t1226-2</LM>
   </w.rf>
   <form>Francouzštinu</form>
   <lemma>francouzština</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m131-d1t1226-3">
   <w.rf>
    <LM>w#w-d1t1226-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1226-4">
   <w.rf>
    <LM>w#w-d1t1226-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1226-5">
   <w.rf>
    <LM>w#w-d1t1226-5</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m131-d1t1226-6">
   <w.rf>
    <LM>w#w-d1t1226-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m131-d1t1226-7">
   <w.rf>
    <LM>w#w-d1t1226-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1226-8">
   <w.rf>
    <LM>w#w-d1t1226-8</LM>
   </w.rf>
   <form>gymnáziu</form>
   <lemma>gymnázium</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m131-654-655">
   <w.rf>
    <LM>w#w-654-655</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1230-1">
   <w.rf>
    <LM>w#w-d1t1230-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1230-3">
   <w.rf>
    <LM>w#w-d1t1230-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1230-4">
   <w.rf>
    <LM>w#w-d1t1230-4</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d1t1230-5">
   <w.rf>
    <LM>w#w-d1t1230-5</LM>
   </w.rf>
   <form>1953</form>
   <lemma>1953</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d1t1230-7">
   <w.rf>
    <LM>w#w-d1t1230-7</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m131-d1t1230-2">
   <w.rf>
    <LM>w#w-d1t1230-2</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1230-8">
   <w.rf>
    <LM>w#w-d1t1230-8</LM>
   </w.rf>
   <form>absolutně</form>
   <lemma>absolutně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1230-9">
   <w.rf>
    <LM>w#w-d1t1230-9</LM>
   </w.rf>
   <form>žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m131-d1t1230-10">
   <w.rf>
    <LM>w#w-d1t1230-10</LM>
   </w.rf>
   <form>šance</form>
   <lemma>šance</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d-id118762-punct">
   <w.rf>
    <LM>w#w-d-id118762-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1230-12">
   <w.rf>
    <LM>w#w-d1t1230-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1230-13">
   <w.rf>
    <LM>w#w-d1t1230-13</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m131-654-673">
   <w.rf>
    <LM>w#w-654-673</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1230-14">
   <w.rf>
    <LM>w#w-d1t1230-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1230-17">
   <w.rf>
    <LM>w#w-d1t1230-17</LM>
   </w.rf>
   <form>Paříže</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-654-672">
   <w.rf>
    <LM>w#w-654-672</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1210-x3">
  <m id="m131-d1t1232-1">
   <w.rf>
    <LM>w#w-d1t1232-1</LM>
   </w.rf>
   <form>Mysleli</form>
   <lemma>myslit</lemma>
   <tag>VpMP----R-AAI-1</tag>
  </m>
  <m id="m131-d1t1232-2">
   <w.rf>
    <LM>w#w-d1t1232-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1232-3">
   <w.rf>
    <LM>w#w-d1t1232-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m131-d-id118921-punct">
   <w.rf>
    <LM>w#w-d-id118921-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1232-5">
   <w.rf>
    <LM>w#w-d1t1232-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1232-8">
   <w.rf>
    <LM>w#w-d1t1232-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1232-9">
   <w.rf>
    <LM>w#w-d1t1232-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1232-6">
   <w.rf>
    <LM>w#w-d1t1232-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1232-7">
   <w.rf>
    <LM>w#w-d1t1232-7</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m131-d1t1232-10">
   <w.rf>
    <LM>w#w-d1t1232-10</LM>
   </w.rf>
   <form>nepodíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m131-d-id119023-punct">
   <w.rf>
    <LM>w#w-d-id119023-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1232-12">
   <w.rf>
    <LM>w#w-d1t1232-12</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1232-13">
   <w.rf>
    <LM>w#w-d1t1232-13</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m131-d1t1232-14">
   <w.rf>
    <LM>w#w-d1t1232-14</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1e1210-x3-175">
   <w.rf>
    <LM>w#w-d1e1210-x3-175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1234-1">
   <w.rf>
    <LM>w#w-d1t1234-1</LM>
   </w.rf>
   <form>jakmile</form>
   <lemma>jakmile</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1234-2">
   <w.rf>
    <LM>w#w-d1t1234-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1234-3">
   <w.rf>
    <LM>w#w-d1t1234-3</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d-id119134-punct">
   <w.rf>
    <LM>w#w-d-id119134-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1234-5">
   <w.rf>
    <LM>w#w-d1t1234-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1234-6">
   <w.rf>
    <LM>w#w-d1t1234-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1234-8">
   <w.rf>
    <LM>w#w-d1t1234-8</LM>
   </w.rf>
   <form>Paříže</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-d-m-d1e1210-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1210-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1241-x2">
  <m id="m131-d1t1244-1">
   <w.rf>
    <LM>w#w-d1t1244-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m131-d1t1244-2">
   <w.rf>
    <LM>w#w-d1t1244-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m131-d1t1244-3">
   <w.rf>
    <LM>w#w-d1t1244-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1244-5">
   <w.rf>
    <LM>w#w-d1t1244-5</LM>
   </w.rf>
   <form>Paříži</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1244-7">
   <w.rf>
    <LM>w#w-d1t1244-7</LM>
   </w.rf>
   <form>navštívila</form>
   <lemma>navštívit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m131-d-id119342-punct">
   <w.rf>
    <LM>w#w-d-id119342-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1245-x2">
  <m id="m131-d1t1250-2">
   <w.rf>
    <LM>w#w-d1t1250-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1250-4">
   <w.rf>
    <LM>w#w-d1t1250-4</LM>
   </w.rf>
   <form>Paříži</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1250-6">
   <w.rf>
    <LM>w#w-d1t1250-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1250-7">
   <w.rf>
    <LM>w#w-d1t1250-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1250-8">
   <w.rf>
    <LM>w#w-d1t1250-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1250-9">
   <w.rf>
    <LM>w#w-d1t1250-9</LM>
   </w.rf>
   <form>třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m131-d1t1250-10">
   <w.rf>
    <LM>w#w-d1t1250-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1250-11">
   <w.rf>
    <LM>w#w-d1t1250-11</LM>
   </w.rf>
   <form>navštívila</form>
   <lemma>navštívit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m131-d1t1250-12">
   <w.rf>
    <LM>w#w-d1t1250-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1250-13">
   <w.rf>
    <LM>w#w-d1t1250-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1250-14">
   <w.rf>
    <LM>w#w-d1t1250-14</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m131-d1e1245-x2-688">
   <w.rf>
    <LM>w#w-d1e1245-x2-688</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1250-15">
   <w.rf>
    <LM>w#w-d1t1250-15</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m131-d1t1250-16">
   <w.rf>
    <LM>w#w-d1t1250-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1250-17">
   <w.rf>
    <LM>w#w-d1t1250-17</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m131-d1e1245-x2-689">
   <w.rf>
    <LM>w#w-d1e1245-x2-689</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-690">
  <m id="m131-d1t1254-1">
   <w.rf>
    <LM>w#w-d1t1254-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1254-2">
   <w.rf>
    <LM>w#w-d1t1254-2</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1254-3">
   <w.rf>
    <LM>w#w-d1t1254-3</LM>
   </w.rf>
   <form>podrobné</form>
   <lemma>podrobný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m131-d1t1254-4">
   <w.rf>
    <LM>w#w-d1t1254-4</LM>
   </w.rf>
   <form>prohlídky</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-d1t1254-7">
   <w.rf>
    <LM>w#w-d1t1254-7</LM>
   </w.rf>
   <form>Louvru</form>
   <lemma>Louvre_;G_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m131-d1t1256-2">
   <w.rf>
    <LM>w#w-d1t1256-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1259-1">
   <w.rf>
    <LM>w#w-d1t1259-1</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m131-d1t1259-2">
   <w.rf>
    <LM>w#w-d1t1259-2</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m131-d1t1259-3">
   <w.rf>
    <LM>w#w-d1t1259-3</LM>
   </w.rf>
   <form>galerie</form>
   <lemma>galerie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-690-691">
   <w.rf>
    <LM>w#w-690-691</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-692">
  <m id="m131-d1t1259-7">
   <w.rf>
    <LM>w#w-d1t1259-7</LM>
   </w.rf>
   <form>Prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1259-6">
   <w.rf>
    <LM>w#w-d1t1259-6</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m131-692-713">
   <w.rf>
    <LM>w#w-692-713</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-714">
  <m id="m131-d1t1263-1">
   <w.rf>
    <LM>w#w-d1t1263-1</LM>
   </w.rf>
   <form>Poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1263-2">
   <w.rf>
    <LM>w#w-d1t1263-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1263-3">
   <w.rf>
    <LM>w#w-d1t1263-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1263-4">
   <w.rf>
    <LM>w#w-d1t1263-4</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1263-5">
   <w.rf>
    <LM>w#w-d1t1263-5</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m131-d1t1263-7">
   <w.rf>
    <LM>w#w-d1t1263-7</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1263-8">
   <w.rf>
    <LM>w#w-d1t1263-8</LM>
   </w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m131-d1t1263-9">
   <w.rf>
    <LM>w#w-d1t1263-9</LM>
   </w.rf>
   <form>spolužačky</form>
   <lemma>spolužačka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m131-d-id120132-punct">
   <w.rf>
    <LM>w#w-d-id120132-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1263-11">
   <w.rf>
    <LM>w#w-d1t1263-11</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m131-d1t1263-12">
   <w.rf>
    <LM>w#w-d1t1263-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1263-13">
   <w.rf>
    <LM>w#w-d1t1263-13</LM>
   </w.rf>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1263-15">
   <w.rf>
    <LM>w#w-d1t1263-15</LM>
   </w.rf>
   <form>fráninu</form>
   <lemma>fránina_,l</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m131-d1t1263-16">
   <w.rf>
    <LM>w#w-d1t1263-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1263-17">
   <w.rf>
    <LM>w#w-d1t1263-17</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-714-719">
   <w.rf>
    <LM>w#w-714-719</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-720">
  <m id="m131-d1t1265-1">
   <w.rf>
    <LM>w#w-d1t1265-1</LM>
   </w.rf>
   <form>Bydlely</form>
   <lemma>bydlet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1265-2">
   <w.rf>
    <LM>w#w-d1t1265-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1265-3">
   <w.rf>
    <LM>w#w-d1t1265-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m131-d1t1265-5">
   <w.rf>
    <LM>w#w-d1t1265-5</LM>
   </w.rf>
   <form>Formuli</form>
   <lemma>formule</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1265-6">
   <w.rf>
    <LM>w#w-d1t1265-6</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d1t1267-2">
   <w.rf>
    <LM>w#w-d1t1267-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1267-3">
   <w.rf>
    <LM>w#w-d1t1267-3</LM>
   </w.rf>
   <form>zíraly</form>
   <lemma>zírat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1267-4">
   <w.rf>
    <LM>w#w-d1t1267-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1267-5">
   <w.rf>
    <LM>w#w-d1t1267-5</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1267-6">
   <w.rf>
    <LM>w#w-d1t1267-6</LM>
   </w.rf>
   <form>neskutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m131-720-740">
   <w.rf>
    <LM>w#w-720-740</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1245-x3">
  <m id="m131-d1t1267-8">
   <w.rf>
    <LM>w#w-d1t1267-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1267-9">
   <w.rf>
    <LM>w#w-d1t1267-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1267-10">
   <w.rf>
    <LM>w#w-d1t1267-10</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1269-1">
   <w.rf>
    <LM>w#w-d1t1269-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1269-4">
   <w.rf>
    <LM>w#w-d1t1269-4</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>1990</form>
   <lemma>1990</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m131-d1e1245-x3-741">
   <w.rf>
    <LM>w#w-d1e1245-x3-741</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-742">
  <m id="m131-d1t1280-3">
   <w.rf>
    <LM>w#w-d1t1280-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1280-2">
   <w.rf>
    <LM>w#w-d1t1280-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1278-2">
   <w.rf>
    <LM>w#w-d1t1278-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m131-d1t1278-5">
   <w.rf>
    <LM>w#w-d1t1278-5</LM>
   </w.rf>
   <form>Versailles</form>
   <lemma>Versailles_;G</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m131-742-743">
   <w.rf>
    <LM>w#w-742-743</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-744">
  <m id="m131-d1t1280-5">
   <w.rf>
    <LM>w#w-d1t1280-5</LM>
   </w.rf>
   <form>Podruhé</form>
   <lemma>podruhé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1280-6">
   <w.rf>
    <LM>w#w-d1t1280-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1280-7">
   <w.rf>
    <LM>w#w-d1t1280-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1280-8">
   <w.rf>
    <LM>w#w-d1t1280-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1280-10">
   <w.rf>
    <LM>w#w-d1t1280-10</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-2_^(mat._operace;_1_plus_1,_též_plus_dva_stupně)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m131-d1t1280-9">
   <w.rf>
    <LM>w#w-d1t1280-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-744-212">
   <w.rf>
    <LM>w#w-744-212</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1280-11">
   <w.rf>
    <LM>w#w-d1t1280-11</LM>
   </w.rf>
   <form>zámcích</form>
   <lemma>zámek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m131-d1t1280-12">
   <w.rf>
    <LM>w#w-d1t1280-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1280-15">
   <w.rf>
    <LM>w#w-d1t1280-15</LM>
   </w.rf>
   <form>Loiře</form>
   <lemma>Loira_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-744-745">
   <w.rf>
    <LM>w#w-744-745</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-746">
  <m id="m131-d1t1282-3">
   <w.rf>
    <LM>w#w-d1t1282-3</LM>
   </w.rf>
   <form>Potřetí</form>
   <lemma>potřetí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1282-4">
   <w.rf>
    <LM>w#w-d1t1282-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1282-5">
   <w.rf>
    <LM>w#w-d1t1282-5</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1282-6">
   <w.rf>
    <LM>w#w-d1t1282-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1282-8">
   <w.rf>
    <LM>w#w-d1t1282-8</LM>
   </w.rf>
   <form>Bretaně</form>
   <lemma>Bretaň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-746-747">
   <w.rf>
    <LM>w#w-746-747</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1282-10">
   <w.rf>
    <LM>w#w-d1t1282-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1282-11">
   <w.rf>
    <LM>w#w-d1t1282-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1282-12">
   <w.rf>
    <LM>w#w-d1t1282-12</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m131-d1t1282-14">
   <w.rf>
    <LM>w#w-d1t1282-14</LM>
   </w.rf>
   <form>Paříž</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m131-d-id121132-punct">
   <w.rf>
    <LM>w#w-d-id121132-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1282-18">
   <w.rf>
    <LM>w#w-d1t1282-18</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1282-19">
   <w.rf>
    <LM>w#w-d1t1282-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1282-20">
   <w.rf>
    <LM>w#w-d1t1282-20</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m131-d1t1282-21">
   <w.rf>
    <LM>w#w-d1t1282-21</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1282-22">
   <w.rf>
    <LM>w#w-d1t1282-22</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m131-d1t1282-23">
   <w.rf>
    <LM>w#w-d1t1282-23</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d-m-d1e1245-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1245-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1289-x2">
  <m id="m131-d1t1292-1">
   <w.rf>
    <LM>w#w-d1t1292-1</LM>
   </w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m131-d1t1292-2">
   <w.rf>
    <LM>w#w-d1t1292-2</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d-m-d1e1289-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1289-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1299-x2">
  <m id="m131-d1t1302-1">
   <w.rf>
    <LM>w#w-d1t1302-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1302-2">
   <w.rf>
    <LM>w#w-d1t1302-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1302-3">
   <w.rf>
    <LM>w#w-d1t1302-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m131-d1t1302-4">
   <w.rf>
    <LM>w#w-d1t1302-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1302-6">
   <w.rf>
    <LM>w#w-d1t1302-6</LM>
   </w.rf>
   <form>Benátkách</form>
   <lemma>Benátky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m131-d1t1304-1">
   <w.rf>
    <LM>w#w-d1t1304-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m131-d1t1304-2">
   <w.rf>
    <LM>w#w-d1t1304-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1304-3">
   <w.rf>
    <LM>w#w-d1t1304-3</LM>
   </w.rf>
   <form>dvaceti</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m131-d1t1304-4">
   <w.rf>
    <LM>w#w-d1t1304-4</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m131-d1e1299-x2-763">
   <w.rf>
    <LM>w#w-d1e1299-x2-763</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-764">
  <m id="m131-d1t1304-6">
   <w.rf>
    <LM>w#w-d1t1304-6</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1304-7">
   <w.rf>
    <LM>w#w-d1t1304-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1304-8">
   <w.rf>
    <LM>w#w-d1t1304-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1304-9">
   <w.rf>
    <LM>w#w-d1t1304-9</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1304-10">
   <w.rf>
    <LM>w#w-d1t1304-10</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1304-11">
   <w.rf>
    <LM>w#w-d1t1304-11</LM>
   </w.rf>
   <form>revoluci</form>
   <lemma>revoluce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-764-765">
   <w.rf>
    <LM>w#w-764-765</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-766">
  <m id="m131-d1t1306-2">
   <w.rf>
    <LM>w#w-d1t1306-2</LM>
   </w.rf>
   <form>Přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m131-d1t1306-1">
   <w.rf>
    <LM>w#w-d1t1306-1</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m131-d1t1306-3">
   <w.rf>
    <LM>w#w-d1t1306-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1306-4">
   <w.rf>
    <LM>w#w-d1t1306-4</LM>
   </w.rf>
   <form>fantastické</form>
   <lemma>fantastický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m131-d-id121710-punct">
   <w.rf>
    <LM>w#w-d-id121710-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1306-6">
   <w.rf>
    <LM>w#w-d1t1306-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1306-7">
   <w.rf>
    <LM>w#w-d1t1306-7</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m131-d1t1306-8">
   <w.rf>
    <LM>w#w-d1t1306-8</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1t1306-9">
   <w.rf>
    <LM>w#w-d1t1306-9</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m131-d1t1306-11">
   <w.rf>
    <LM>w#w-d1t1306-11</LM>
   </w.rf>
   <form>Zlína</form>
   <lemma>Zlín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m131-d1t1306-13">
   <w.rf>
    <LM>w#w-d1t1306-13</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1306-15">
   <w.rf>
    <LM>w#w-d1t1306-15</LM>
   </w.rf>
   <form>Baťů</form>
   <lemma>Baťa_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m131-d1t1306-17">
   <w.rf>
    <LM>w#w-d1t1306-17</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m131-d1t1306-18">
   <w.rf>
    <LM>w#w-d1t1306-18</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1308-1">
   <w.rf>
    <LM>w#w-d1t1308-1</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1306-19">
   <w.rf>
    <LM>w#w-d1t1306-19</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-766-767">
   <w.rf>
    <LM>w#w-766-767</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-768">
  <m id="m131-d1t1313-1">
   <w.rf>
    <LM>w#w-d1t1313-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m131-d1t1313-2">
   <w.rf>
    <LM>w#w-d1t1313-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1313-3">
   <w.rf>
    <LM>w#w-d1t1313-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1313-4">
   <w.rf>
    <LM>w#w-d1t1313-4</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1313-5">
   <w.rf>
    <LM>w#w-d1t1313-5</LM>
   </w.rf>
   <form>nevěřili</form>
   <lemma>věřit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m131-d-id122036-punct">
   <w.rf>
    <LM>w#w-d-id122036-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1313-7">
   <w.rf>
    <LM>w#w-d1t1313-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1313-9">
   <w.rf>
    <LM>w#w-d1t1313-9</LM>
   </w.rf>
   <form>Benátky</form>
   <lemma>Benátky_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m131-d1t1313-11">
   <w.rf>
    <LM>w#w-d1t1313-11</LM>
   </w.rf>
   <form>uvidíme</form>
   <lemma>uvidět</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m131-768-769">
   <w.rf>
    <LM>w#w-768-769</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-770">
  <m id="m131-d1t1317-2">
   <w.rf>
    <LM>w#w-d1t1317-2</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1317-3">
   <w.rf>
    <LM>w#w-d1t1317-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1317-4">
   <w.rf>
    <LM>w#w-d1t1317-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1317-6">
   <w.rf>
    <LM>w#w-d1t1317-6</LM>
   </w.rf>
   <form>Itálii</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1317-8">
   <w.rf>
    <LM>w#w-d1t1317-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m131-d1t1317-9">
   <w.rf>
    <LM>w#w-d1t1317-9</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m131-d1t1317-10">
   <w.rf>
    <LM>w#w-d1t1317-10</LM>
   </w.rf>
   <form>snachou</form>
   <lemma>snacha</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m131-d-id122275-punct">
   <w.rf>
    <LM>w#w-d-id122275-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1317-12">
   <w.rf>
    <LM>w#w-d1t1317-12</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m131-d1t1317-14">
   <w.rf>
    <LM>w#w-d1t1317-14</LM>
   </w.rf>
   <form>umí</form>
   <lemma>umět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m131-d1t1317-15">
   <w.rf>
    <LM>w#w-d1t1317-15</LM>
   </w.rf>
   <form>italsky</form>
   <lemma>italsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-770-794">
   <w.rf>
    <LM>w#w-770-794</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1299-x3">
  <m id="m131-d1t1319-1">
   <w.rf>
    <LM>w#w-d1t1319-1</LM>
   </w.rf>
   <form>Prostřednímu</form>
   <lemma>prostřední</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m131-d1t1319-2">
   <w.rf>
    <LM>w#w-d1t1319-2</LM>
   </w.rf>
   <form>synovi</form>
   <lemma>syn</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m131-d1t1319-5">
   <w.rf>
    <LM>w#w-d1t1319-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1e1299-x3-804">
   <w.rf>
    <LM>w#w-d1e1299-x3-804</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1319-9">
   <w.rf>
    <LM>w#w-d1t1319-9</LM>
   </w.rf>
   <form>kupodivu</form>
   <lemma>kupodivu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1319-4">
   <w.rf>
    <LM>w#w-d1t1319-4</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m131-d1t1319-7">
   <w.rf>
    <LM>w#w-d1t1319-7</LM>
   </w.rf>
   <form>získat</form>
   <lemma>získat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m131-d1t1319-8">
   <w.rf>
    <LM>w#w-d1t1319-8</LM>
   </w.rf>
   <form>stipendium</form>
   <lemma>stipendium</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m131-d1e1299-x3-820">
   <w.rf>
    <LM>w#w-d1e1299-x3-820</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-821">
  <m id="m131-d1t1323-7">
   <w.rf>
    <LM>w#w-d1t1323-7</LM>
   </w.rf>
   <form>Seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1323-5">
   <w.rf>
    <LM>w#w-d1t1323-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1323-10">
   <w.rf>
    <LM>w#w-d1t1323-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1323-11">
   <w.rf>
    <LM>w#w-d1t1323-11</LM>
   </w.rf>
   <form>kurzu</form>
   <lemma>kurz</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m131-d1t1323-12">
   <w.rf>
    <LM>w#w-d1t1323-12</LM>
   </w.rf>
   <form>italštiny</form>
   <lemma>italština</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m131-d-id122790-punct">
   <w.rf>
    <LM>w#w-d-id122790-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1323-14">
   <w.rf>
    <LM>w#w-d1t1323-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1323-15">
   <w.rf>
    <LM>w#w-d1t1323-15</LM>
   </w.rf>
   <form>italské</form>
   <lemma>italský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m131-d1t1323-16">
   <w.rf>
    <LM>w#w-d1t1323-16</LM>
   </w.rf>
   <form>ambasádě</form>
   <lemma>ambasáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-821-84">
   <w.rf>
    <LM>w#w-821-84</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-823">
  <m id="m131-d1t1328-2">
   <w.rf>
    <LM>w#w-d1t1328-2</LM>
   </w.rf>
   <form>Jakmile</form>
   <lemma>jakmile</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1328-3">
   <w.rf>
    <LM>w#w-d1t1328-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1328-4">
   <w.rf>
    <LM>w#w-d1t1328-4</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m131-d-id122932-punct">
   <w.rf>
    <LM>w#w-d-id122932-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1328-6">
   <w.rf>
    <LM>w#w-d1t1328-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1328-7">
   <w.rf>
    <LM>w#w-d1t1328-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1328-8">
   <w.rf>
    <LM>w#w-d1t1328-8</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-823-824">
   <w.rf>
    <LM>w#w-823-824</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-825">
  <m id="m131-d1t1328-13">
   <w.rf>
    <LM>w#w-d1t1328-13</LM>
   </w.rf>
   <form>Vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m131-d1t1328-12">
   <w.rf>
    <LM>w#w-d1t1328-12</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m131-d1t1328-11">
   <w.rf>
    <LM>w#w-d1t1328-11</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1328-14">
   <w.rf>
    <LM>w#w-d1t1328-14</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m131-d1t1328-15">
   <w.rf>
    <LM>w#w-d1t1328-15</LM>
   </w.rf>
   <form>osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m131-d1t1328-16">
   <w.rf>
    <LM>w#w-d1t1328-16</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m131-825-826">
   <w.rf>
    <LM>w#w-825-826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-827">
  <m id="m131-d1t1330-3">
   <w.rf>
    <LM>w#w-d1t1330-3</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1330-2">
   <w.rf>
    <LM>w#w-d1t1330-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1330-4">
   <w.rf>
    <LM>w#w-d1t1330-4</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m131-827-828">
   <w.rf>
    <LM>w#w-827-828</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-829">
  <m id="m131-d1t1330-6">
   <w.rf>
    <LM>w#w-d1t1330-6</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m131-d1t1330-7">
   <w.rf>
    <LM>w#w-d1t1330-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1330-8">
   <w.rf>
    <LM>w#w-d1t1330-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1330-9">
   <w.rf>
    <LM>w#w-d1t1330-9</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m131-d1t1330-10">
   <w.rf>
    <LM>w#w-d1t1330-10</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m131-d1t1330-12">
   <w.rf>
    <LM>w#w-d1t1330-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1330-13">
   <w.rf>
    <LM>w#w-d1t1330-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1330-14">
   <w.rf>
    <LM>w#w-d1t1330-14</LM>
   </w.rf>
   <form>zpáteční</form>
   <lemma>zpáteční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m131-d1t1330-15">
   <w.rf>
    <LM>w#w-d1t1330-15</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m131-d1t1332-1">
   <w.rf>
    <LM>w#w-d1t1332-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1332-2">
   <w.rf>
    <LM>w#w-d1t1332-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1332-3">
   <w.rf>
    <LM>w#w-d1t1332-3</LM>
   </w.rf>
   <form>zastavili</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m131-d1t1332-4">
   <w.rf>
    <LM>w#w-d1t1332-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1332-6">
   <w.rf>
    <LM>w#w-d1t1332-6</LM>
   </w.rf>
   <form>Benátkách</form>
   <lemma>Benátky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m131-829-1171">
   <w.rf>
    <LM>w#w-829-1171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-1172">
  <m id="m131-d1t1332-10">
   <w.rf>
    <LM>w#w-d1t1332-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m131-d1t1332-11">
   <w.rf>
    <LM>w#w-d1t1332-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1332-12">
   <w.rf>
    <LM>w#w-d1t1332-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1332-13">
   <w.rf>
    <LM>w#w-d1t1332-13</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1332-14">
   <w.rf>
    <LM>w#w-d1t1332-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m131-d1t1332-16">
   <w.rf>
    <LM>w#w-d1t1332-16</LM>
   </w.rf>
   <form>Benátkách</form>
   <lemma>Benátky_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m131-829-830">
   <w.rf>
    <LM>w#w-829-830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1333-x2">
  <m id="m131-d1t1336-1">
   <w.rf>
    <LM>w#w-d1t1336-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m131-d1t1336-2">
   <w.rf>
    <LM>w#w-d1t1336-2</LM>
   </w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m131-d1t1336-3">
   <w.rf>
    <LM>w#w-d1t1336-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m131-d1t1336-4">
   <w.rf>
    <LM>w#w-d1t1336-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1336-5">
   <w.rf>
    <LM>w#w-d1t1336-5</LM>
   </w.rf>
   <form>navštívila</form>
   <lemma>navštívit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m131-d-id123737-punct">
   <w.rf>
    <LM>w#w-d-id123737-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-d1e1337-x2">
  <m id="m131-d1t1340-2">
   <w.rf>
    <LM>w#w-d1t1340-2</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1340-3">
   <w.rf>
    <LM>w#w-d1t1340-3</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m131-d-id123845-punct">
   <w.rf>
    <LM>w#w-d-id123845-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1340-5">
   <w.rf>
    <LM>w#w-d1t1340-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m131-d1t1342-2">
   <w.rf>
    <LM>w#w-d1t1342-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m131-d1t1342-3">
   <w.rf>
    <LM>w#w-d1t1342-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m131-d1t1342-1">
   <w.rf>
    <LM>w#w-d1t1342-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1342-4">
   <w.rf>
    <LM>w#w-d1t1342-4</LM>
   </w.rf>
   <form>zastávka</form>
   <lemma>zastávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m131-d1t1342-5">
   <w.rf>
    <LM>w#w-d1t1342-5</LM>
   </w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m131-d1e1337-x2-849">
   <w.rf>
    <LM>w#w-d1e1337-x2-849</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m131-850">
  <m id="m131-d1t1342-8">
   <w.rf>
    <LM>w#w-d1t1342-8</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m131-d1t1342-9">
   <w.rf>
    <LM>w#w-d1t1342-9</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m131-d1t1342-10">
   <w.rf>
    <LM>w#w-d1t1342-10</LM>
   </w.rf>
   <form>svatého</form>
   <lemma>svatý-1</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m131-d1t1342-11">
   <w.rf>
    <LM>w#w-d1t1342-11</LM>
   </w.rf>
   <form>Marka</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m131-d-id124074-punct">
   <w.rf>
    <LM>w#w-d-id124074-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m131-d1t1342-13">
   <w.rf>
    <LM>w#w-d1t1342-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m131-d1t1342-14">
   <w.rf>
    <LM>w#w-d1t1342-14</LM>
   </w.rf>
   <form>dovnitř</form>
   <lemma>dovnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1342-15">
   <w.rf>
    <LM>w#w-d1t1342-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m131-d1t1342-16">
   <w.rf>
    <LM>w#w-d1t1342-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m131-d1t1342-17">
   <w.rf>
    <LM>w#w-d1t1342-17</LM>
   </w.rf>
   <form>nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m131-d1t1342-18">
   <w.rf>
    <LM>w#w-d1t1342-18</LM>
   </w.rf>
   <form>nedostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m131-d1e1337-x2-847">
   <w.rf>
    <LM>w#w-d1e1337-x2-847</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
