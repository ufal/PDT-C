<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_784.04.w.gz" />
  </references>
 </head>
 <s id="m784-27638_04-1419">
  <m id="m784-d1t1434-10">
   <w.rf>
    <LM>w#w-d1t1434-10</LM>
   </w.rf>
   <form>Zběžně</form>
   <lemma>zběžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1434-11">
   <w.rf>
    <LM>w#w-d1t1434-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1434-12">
   <w.rf>
    <LM>w#w-d1t1434-12</LM>
   </w.rf>
   <form>prošli</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t1437-1">
   <w.rf>
    <LM>w#w-d1t1437-1</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e1397-x6-1548">
   <w.rf>
    <LM>w#w-d1e1397-x6-1548</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1437-2">
   <w.rf>
    <LM>w#w-d1t1437-2</LM>
   </w.rf>
   <form>prohlídli</form>
   <lemma>prohlídnout_,h_^(^GC*6édnout)</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m784-d1t1437-3">
   <w.rf>
    <LM>w#w-d1t1437-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1437-4">
   <w.rf>
    <LM>w#w-d1t1437-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1437-5">
   <w.rf>
    <LM>w#w-d1t1437-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1437-8">
   <w.rf>
    <LM>w#w-d1t1437-8</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1437-7">
   <w.rf>
    <LM>w#w-d1t1437-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1437-9">
   <w.rf>
    <LM>w#w-d1t1437-9</LM>
   </w.rf>
   <form>manželce</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m784-d1e1397-x6-1552">
   <w.rf>
    <LM>w#w-d1e1397-x6-1552</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d-id102482">
   <w.rf>
    <LM>w#w-d-id102482</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1437-12">
   <w.rf>
    <LM>w#w-d1t1437-12</LM>
   </w.rf>
   <form>Jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1437-13">
   <w.rf>
    <LM>w#w-d1t1437-13</LM>
   </w.rf>
   <form>nakoupit</form>
   <lemma>nakoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d-id102537">
   <w.rf>
    <LM>w#w-d-id102537</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1397-x6-1555">
   <w.rf>
    <LM>w#w-d1e1397-x6-1555</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1397-x7">
  <m id="m784-d1t1441-1">
   <w.rf>
    <LM>w#w-d1t1441-1</LM>
   </w.rf>
   <form>Manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t1441-2">
   <w.rf>
    <LM>w#w-d1t1441-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t1441-3">
   <w.rf>
    <LM>w#w-d1t1441-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t1441-4">
   <w.rf>
    <LM>w#w-d1t1441-4</LM>
   </w.rf>
   <form>žhavá</form>
   <lemma>žhavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m784-d1t1441-5">
   <w.rf>
    <LM>w#w-d1t1441-5</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1441-6">
   <w.rf>
    <LM>w#w-d1t1441-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1441-7">
   <w.rf>
    <LM>w#w-d1t1441-7</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m784-d1t1441-8">
   <w.rf>
    <LM>w#w-d1t1441-8</LM>
   </w.rf>
   <form>krámech</form>
   <lemma>krám</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m784-d1e1397-x7-1671">
   <w.rf>
    <LM>w#w-d1e1397-x7-1671</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1443-1">
   <w.rf>
    <LM>w#w-d1t1443-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1443-5">
   <w.rf>
    <LM>w#w-d1t1443-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1443-2">
   <w.rf>
    <LM>w#w-d1t1443-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1443-3">
   <w.rf>
    <LM>w#w-d1t1443-3</LM>
   </w.rf>
   <form>žádném</form>
   <lemma>žádný</lemma>
   <tag>PWZS6----------</tag>
  </m>
  <m id="m784-d1t1443-4">
   <w.rf>
    <LM>w#w-d1t1443-4</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t1443-6">
   <w.rf>
    <LM>w#w-d1t1443-6</LM>
   </w.rf>
   <form>nepřipustil</form>
   <lemma>připustit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d-id102790">
   <w.rf>
    <LM>w#w-d-id102790</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1443-8">
   <w.rf>
    <LM>w#w-d1t1443-8</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1443-9">
   <w.rf>
    <LM>w#w-d1t1443-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1443-10">
   <w.rf>
    <LM>w#w-d1t1443-10</LM>
   </w.rf>
   <form>chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1443-11">
   <w.rf>
    <LM>w#w-d1t1443-11</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m784-d1e1397-x7-1675">
   <w.rf>
    <LM>w#w-d1e1397-x7-1675</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1676">
  <m id="m784-d1t1445-1">
   <w.rf>
    <LM>w#w-d1t1445-1</LM>
   </w.rf>
   <form>Koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t1445-2">
   <w.rf>
    <LM>w#w-d1t1445-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1445-3">
   <w.rf>
    <LM>w#w-d1t1445-3</LM>
   </w.rf>
   <form>mikrovlnnou</form>
   <lemma>mikrovlnný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d1t1445-4">
   <w.rf>
    <LM>w#w-d1t1445-4</LM>
   </w.rf>
   <form>troubu</form>
   <lemma>trouba-2_^(na_pečení;_roura)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-1676-1688">
   <w.rf>
    <LM>w#w-1676-1688</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1450-1">
   <w.rf>
    <LM>w#w-d1t1450-1</LM>
   </w.rf>
   <form>sedl</form>
   <lemma>sednout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m784-d1t1450-2">
   <w.rf>
    <LM>w#w-d1t1450-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1450-3">
   <w.rf>
    <LM>w#w-d1t1450-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1450-4">
   <w.rf>
    <LM>w#w-d1t1450-4</LM>
   </w.rf>
   <form>obrazně</form>
   <lemma>obrazně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1450-5">
   <w.rf>
    <LM>w#w-d1t1450-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1450-6">
   <w.rf>
    <LM>w#w-d1t1450-6</LM>
   </w.rf>
   <form>obrubník</form>
   <lemma>obrubník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t1450-7">
   <w.rf>
    <LM>w#w-d1t1450-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1450-10">
   <w.rf>
    <LM>w#w-d1t1450-10</LM>
   </w.rf>
   <form>posvačil</form>
   <lemma>posvačit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1450-11">
   <w.rf>
    <LM>w#w-d1t1450-11</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t1450-12">
   <w.rf>
    <LM>w#w-d1t1450-12</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-1676-1693">
   <w.rf>
    <LM>w#w-1676-1693</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1694">
  <m id="m784-d1t1452-2">
   <w.rf>
    <LM>w#w-d1t1452-2</LM>
   </w.rf>
   <form>Nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1452-3">
   <w.rf>
    <LM>w#w-d1t1452-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1452-6">
   <w.rf>
    <LM>w#w-d1t1452-6</LM>
   </w.rf>
   <form>nešel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-1694-1706">
   <w.rf>
    <LM>w#w-1694-1706</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1452-7">
   <w.rf>
    <LM>w#w-d1t1452-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1456-1">
   <w.rf>
    <LM>w#w-d1t1456-1</LM>
   </w.rf>
   <form>nepociťuju</form>
   <lemma>pociťovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m784-d1t1456-2">
   <w.rf>
    <LM>w#w-d1t1456-2</LM>
   </w.rf>
   <form>potřebu</form>
   <lemma>potřeba-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t1456-3">
   <w.rf>
    <LM>w#w-d1t1456-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1456-4">
   <w.rf>
    <LM>w#w-d1t1456-4</LM>
   </w.rf>
   <form>pohybovat</form>
   <lemma>pohybovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1456-5">
   <w.rf>
    <LM>w#w-d1t1456-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1456-6">
   <w.rf>
    <LM>w#w-d1t1456-6</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-1694-1707">
   <w.rf>
    <LM>w#w-1694-1707</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1456-7">
   <w.rf>
    <LM>w#w-d1t1456-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1456-8">
   <w.rf>
    <LM>w#w-d1t1456-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m784-d1t1456-9">
   <w.rf>
    <LM>w#w-d1t1456-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1456-11">
   <w.rf>
    <LM>w#w-d1t1456-11</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t1456-12">
   <w.rf>
    <LM>w#w-d1t1456-12</LM>
   </w.rf>
   <form>mysli</form>
   <lemma>mysl</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m784-d-id103451">
   <w.rf>
    <LM>w#w-d-id103451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1397-x8">
  <m id="m784-d1t1463-1">
   <w.rf>
    <LM>w#w-d1t1463-1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1463-2">
   <w.rf>
    <LM>w#w-d1t1463-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1465-1">
   <w.rf>
    <LM>w#w-d1t1465-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1465-2">
   <w.rf>
    <LM>w#w-d1t1465-2</LM>
   </w.rf>
   <form>x</form>
   <lemma>x-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m784-d1t1465-3">
   <w.rf>
    <LM>w#w-d1t1465-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m784-d1t1465-4">
   <w.rf>
    <LM>w#w-d1t1465-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1465-5">
   <w.rf>
    <LM>w#w-d1t1465-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1465-6">
   <w.rf>
    <LM>w#w-d1t1465-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1465-7">
   <w.rf>
    <LM>w#w-d1t1465-7</LM>
   </w.rf>
   <form>služebně</form>
   <lemma>služebně-1_^(*3ý-1)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1465-8">
   <w.rf>
    <LM>w#w-d1t1465-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1465-9">
   <w.rf>
    <LM>w#w-d1t1465-9</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t1465-10">
   <w.rf>
    <LM>w#w-d1t1465-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1465-11">
   <w.rf>
    <LM>w#w-d1t1465-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t1465-12">
   <w.rf>
    <LM>w#w-d1t1465-12</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m784-d1t1465-13">
   <w.rf>
    <LM>w#w-d1t1465-13</LM>
   </w.rf>
   <form>chovali</form>
   <lemma>chovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1465-14">
   <w.rf>
    <LM>w#w-d1t1465-14</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1465-15">
   <w.rf>
    <LM>w#w-d1t1465-15</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d-id103758">
   <w.rf>
    <LM>w#w-d-id103758</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1466-x2">
  <m id="m784-d1t1473-1">
   <w.rf>
    <LM>w#w-d1t1473-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1473-2">
   <w.rf>
    <LM>w#w-d1t1473-2</LM>
   </w.rf>
   <form>takzvaných</form>
   <lemma>takzvaný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m784-d1t1473-3">
   <w.rf>
    <LM>w#w-d1t1473-3</LM>
   </w.rf>
   <form>kádrových</form>
   <lemma>kádrový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m784-d1t1473-4">
   <w.rf>
    <LM>w#w-d1t1473-4</LM>
   </w.rf>
   <form>materiálech</form>
   <lemma>materiál</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m784-d1t1475-1">
   <w.rf>
    <LM>w#w-d1t1475-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1475-2">
   <w.rf>
    <LM>w#w-d1t1475-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1475-3">
   <w.rf>
    <LM>w#w-d1t1475-3</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1475-4">
   <w.rf>
    <LM>w#w-d1t1475-4</LM>
   </w.rf>
   <form>veden</form>
   <lemma>vést</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m784-d1t1475-5">
   <w.rf>
    <LM>w#w-d1t1475-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1477-1">
   <w.rf>
    <LM>w#w-d1t1477-1</LM>
   </w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t1477-2">
   <w.rf>
    <LM>w#w-d1t1477-2</LM>
   </w.rf>
   <form>židovského</form>
   <lemma>židovský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m784-d1t1477-3">
   <w.rf>
    <LM>w#w-d1t1477-3</LM>
   </w.rf>
   <form>původu</form>
   <lemma>původ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e1466-x2-1785">
   <w.rf>
    <LM>w#w-d1e1466-x2-1785</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1482-1">
   <w.rf>
    <LM>w#w-d1t1482-1</LM>
   </w.rf>
   <form>nepůsobilo</form>
   <lemma>působit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1482-2">
   <w.rf>
    <LM>w#w-d1t1482-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m784-d1t1482-3">
   <w.rf>
    <LM>w#w-d1t1482-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1482-4">
   <w.rf>
    <LM>w#w-d1t1482-4</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1482-5">
   <w.rf>
    <LM>w#w-d1t1482-5</LM>
   </w.rf>
   <form>potíže</form>
   <lemma>potíž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m784-d-id104100">
   <w.rf>
    <LM>w#w-d-id104100</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1483-x2">
  <m id="m784-d1t1486-1">
   <w.rf>
    <LM>w#w-d1t1486-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e1483-x2-1872">
   <w.rf>
    <LM>w#w-d1e1483-x2-1872</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1486-4">
   <w.rf>
    <LM>w#w-d1t1486-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1486-5">
   <w.rf>
    <LM>w#w-d1t1486-5</LM>
   </w.rf>
   <form>kádrových</form>
   <lemma>kádrový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m784-d1t1486-6">
   <w.rf>
    <LM>w#w-d1t1486-6</LM>
   </w.rf>
   <form>materiálech</form>
   <lemma>materiál</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m784-d1t1486-3">
   <w.rf>
    <LM>w#w-d1t1486-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1486-7">
   <w.rf>
    <LM>w#w-d1t1486-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1486-8">
   <w.rf>
    <LM>w#w-d1t1486-8</LM>
   </w.rf>
   <form>veden</form>
   <lemma>vést</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m784-d1e1483-x2-1877">
   <w.rf>
    <LM>w#w-d1e1483-x2-1877</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1486-9">
   <w.rf>
    <LM>w#w-d1t1486-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1486-10">
   <w.rf>
    <LM>w#w-d1t1486-10</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1486-11">
   <w.rf>
    <LM>w#w-d1t1486-11</LM>
   </w.rf>
   <form>stoprocentně</form>
   <lemma>stoprocentně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1e1483-x2-1879">
   <w.rf>
    <LM>w#w-d1e1483-x2-1879</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1486-12">
   <w.rf>
    <LM>w#w-d1t1486-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1486-13">
   <w.rf>
    <LM>w#w-d1t1486-13</LM>
   </w.rf>
   <form>politický</form>
   <lemma>politický</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t1486-14">
   <w.rf>
    <LM>w#w-d1t1486-14</LM>
   </w.rf>
   <form>vězeň</form>
   <lemma>vězeň</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e1483-x2-1880">
   <w.rf>
    <LM>w#w-d1e1483-x2-1880</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1881">
  <m id="m784-d1t1488-2">
   <w.rf>
    <LM>w#w-d1t1488-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1488-3">
   <w.rf>
    <LM>w#w-d1t1488-3</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-1881-1433">
   <w.rf>
    <LM>w#w-1881-1433</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1488-8">
   <w.rf>
    <LM>w#w-d1t1488-8</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1490-1">
   <w.rf>
    <LM>w#w-d1t1490-1</LM>
   </w.rf>
   <form>působení</form>
   <lemma>působení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1t1490-2">
   <w.rf>
    <LM>w#w-d1t1490-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1490-3">
   <w.rf>
    <LM>w#w-d1t1490-3</LM>
   </w.rf>
   <form>armádě</form>
   <lemma>armáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t1492-1">
   <w.rf>
    <LM>w#w-d1t1492-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1492-2">
   <w.rf>
    <LM>w#w-d1t1492-2</LM>
   </w.rf>
   <form>vstoupil</form>
   <lemma>vstoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1492-3">
   <w.rf>
    <LM>w#w-d1t1492-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1492-4">
   <w.rf>
    <LM>w#w-d1t1492-4</LM>
   </w.rf>
   <form>komunistické</form>
   <lemma>komunistický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m784-d1t1492-5">
   <w.rf>
    <LM>w#w-d1t1492-5</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-1881-1894">
   <w.rf>
    <LM>w#w-1881-1894</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1497-2">
   <w.rf>
    <LM>w#w-d1t1497-2</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m784-d1t1497-3">
   <w.rf>
    <LM>w#w-d1t1497-3</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d-id104730">
   <w.rf>
    <LM>w#w-d-id104730</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1497-5">
   <w.rf>
    <LM>w#w-d1t1497-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1497-7">
   <w.rf>
    <LM>w#w-d1t1497-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t1497-8">
   <w.rf>
    <LM>w#w-d1t1497-8</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m784-d1t1497-9">
   <w.rf>
    <LM>w#w-d1t1497-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1497-10">
   <w.rf>
    <LM>w#w-d1t1497-10</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m784-d1t1497-11">
   <w.rf>
    <LM>w#w-d1t1497-11</LM>
   </w.rf>
   <form>chyb</form>
   <lemma>chyba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-d-id104149">
   <w.rf>
    <LM>w#w-d-id104149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1498-x2">
  <m id="m784-d1t1503-2">
   <w.rf>
    <LM>w#w-d1t1503-2</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1503-3">
   <w.rf>
    <LM>w#w-d1t1503-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1503-4">
   <w.rf>
    <LM>w#w-d1t1503-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1503-5">
   <w.rf>
    <LM>w#w-d1t1503-5</LM>
   </w.rf>
   <form>vstoupil</form>
   <lemma>vstoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1e1498-x2-1913">
   <w.rf>
    <LM>w#w-d1e1498-x2-1913</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1498-x3">
  <m id="m784-d1t1505-2">
   <w.rf>
    <LM>w#w-d1t1505-2</LM>
   </w.rf>
   <form>Vstoupil</form>
   <lemma>vstoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1505-3">
   <w.rf>
    <LM>w#w-d1t1505-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1505-4">
   <w.rf>
    <LM>w#w-d1t1505-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1505-5">
   <w.rf>
    <LM>w#w-d1t1505-5</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id105038">
   <w.rf>
    <LM>w#w-d-id105038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1512-1">
   <w.rf>
    <LM>w#w-d1t1512-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1514-1">
   <w.rf>
    <LM>w#w-d1t1514-1</LM>
   </w.rf>
   <form>agitace</form>
   <lemma>agitace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t1514-2">
   <w.rf>
    <LM>w#w-d1t1514-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t1514-3">
   <w.rf>
    <LM>w#w-d1t1514-3</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m784-d1e1498-x3-1440">
   <w.rf>
    <LM>w#w-d1e1498-x3-1440</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1441">
  <m id="m784-d1t1518-2">
   <w.rf>
    <LM>w#w-d1t1518-2</LM>
   </w.rf>
   <form>Sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m784-d1t1518-3">
   <w.rf>
    <LM>w#w-d1t1518-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1518-4">
   <w.rf>
    <LM>w#w-d1t1518-4</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1518-5">
   <w.rf>
    <LM>w#w-d1t1518-5</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m784-d1t1518-6">
   <w.rf>
    <LM>w#w-d1t1518-6</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m784-d1t1518-7">
   <w.rf>
    <LM>w#w-d1t1518-7</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d-id105309">
   <w.rf>
    <LM>w#w-d-id105309</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1518-9">
   <w.rf>
    <LM>w#w-d1t1518-9</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1520-1">
   <w.rf>
    <LM>w#w-d1t1520-1</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1520-2">
   <w.rf>
    <LM>w#w-d1t1520-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1520-3">
   <w.rf>
    <LM>w#w-d1t1520-3</LM>
   </w.rf>
   <form>dobou</form>
   <lemma>doba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m784-1441-1442">
   <w.rf>
    <LM>w#w-1441-1442</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1443">
  <m id="m784-d1t1525-2">
   <w.rf>
    <LM>w#w-d1t1525-2</LM>
   </w.rf>
   <form>Uvědomil</form>
   <lemma>uvědomit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1525-3">
   <w.rf>
    <LM>w#w-d1t1525-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1525-4">
   <w.rf>
    <LM>w#w-d1t1525-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d-id105486">
   <w.rf>
    <LM>w#w-d-id105486</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1525-6">
   <w.rf>
    <LM>w#w-d1t1525-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1525-7">
   <w.rf>
    <LM>w#w-d1t1525-7</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m784-d1t1525-8">
   <w.rf>
    <LM>w#w-d1t1525-8</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1525-9">
   <w.rf>
    <LM>w#w-d1t1525-9</LM>
   </w.rf>
   <form>zachránili</form>
   <lemma>zachránit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t1527-3">
   <w.rf>
    <LM>w#w-d1t1527-3</LM>
   </w.rf>
   <form>ruští</form>
   <lemma>ruský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m784-d1t1527-4">
   <w.rf>
    <LM>w#w-d1t1527-4</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t1527-5">
   <w.rf>
    <LM>w#w-d1t1527-5</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id105630">
   <w.rf>
    <LM>w#w-d-id105630</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1509-x3">
  <m id="m784-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>Nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1531-2">
   <w.rf>
    <LM>w#w-d1t1531-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1531-7">
   <w.rf>
    <LM>w#w-d1t1531-7</LM>
   </w.rf>
   <form>věcech</form>
   <lemma>věc</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m784-d-id105764">
   <w.rf>
    <LM>w#w-d-id105764</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1531-9">
   <w.rf>
    <LM>w#w-d1t1531-9</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m784-d1t1531-10">
   <w.rf>
    <LM>w#w-d1t1531-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1531-11">
   <w.rf>
    <LM>w#w-d1t1531-11</LM>
   </w.rf>
   <form>děly</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1536-1">
   <w.rf>
    <LM>w#w-d1t1536-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1536-2">
   <w.rf>
    <LM>w#w-d1t1536-2</LM>
   </w.rf>
   <form>hranicemi</form>
   <lemma>hranice</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m784-d1t1536-3">
   <w.rf>
    <LM>w#w-d1t1536-3</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS2-P1-------</tag>
  </m>
  <m id="m784-d1t1536-4">
   <w.rf>
    <LM>w#w-d1t1536-4</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1e1509-x3-2197">
   <w.rf>
    <LM>w#w-d1e1509-x3-2197</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-2198">
  <m id="m784-d1t1538-1">
   <w.rf>
    <LM>w#w-d1t1538-1</LM>
   </w.rf>
   <form>Nedovedl</form>
   <lemma>dovést</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1t1538-2">
   <w.rf>
    <LM>w#w-d1t1538-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1538-3">
   <w.rf>
    <LM>w#w-d1t1538-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1538-7">
   <w.rf>
    <LM>w#w-d1t1538-7</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1538-6">
   <w.rf>
    <LM>w#w-d1t1538-6</LM>
   </w.rf>
   <form>vysvětlit</form>
   <lemma>vysvětlit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-2198-2212">
   <w.rf>
    <LM>w#w-2198-2212</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1538-8">
   <w.rf>
    <LM>w#w-d1t1538-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1538-9">
   <w.rf>
    <LM>w#w-d1t1538-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1538-10">
   <w.rf>
    <LM>w#w-d1t1538-10</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t1538-11">
   <w.rf>
    <LM>w#w-d1t1538-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1538-12">
   <w.rf>
    <LM>w#w-d1t1538-12</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m784-2198-2214">
   <w.rf>
    <LM>w#w-2198-2214</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1540-1">
   <w.rf>
    <LM>w#w-d1t1540-1</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-2198-2221">
   <w.rf>
    <LM>w#w-2198-2221</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1542-7">
   <w.rf>
    <LM>w#w-d1t1542-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1542-8">
   <w.rf>
    <LM>w#w-d1t1542-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m784-d1t1542-4">
   <w.rf>
    <LM>w#w-d1t1542-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1542-1">
   <w.rf>
    <LM>w#w-d1t1542-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m784-d1t1542-2">
   <w.rf>
    <LM>w#w-d1t1542-2</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t1542-3">
   <w.rf>
    <LM>w#w-d1t1542-3</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t1542-5">
   <w.rf>
    <LM>w#w-d1t1542-5</LM>
   </w.rf>
   <form>zavřený</form>
   <lemma>zavřený_^(*3ít)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-2198-2222">
   <w.rf>
    <LM>w#w-2198-2222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-2223">
  <m id="m784-2223-2233">
   <w.rf>
    <LM>w#w-2223-2233</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1544-2">
   <w.rf>
    <LM>w#w-d1t1544-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1544-3">
   <w.rf>
    <LM>w#w-d1t1544-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1544-4">
   <w.rf>
    <LM>w#w-d1t1544-4</LM>
   </w.rf>
   <form>nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1544-5">
   <w.rf>
    <LM>w#w-d1t1544-5</LM>
   </w.rf>
   <form>podrobnosti</form>
   <lemma>podrobnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m784-2223-2236">
   <w.rf>
    <LM>w#w-2223-2236</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1549-1">
   <w.rf>
    <LM>w#w-d1t1549-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1549-3">
   <w.rf>
    <LM>w#w-d1t1549-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1549-2">
   <w.rf>
    <LM>w#w-d1t1549-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1549-5">
   <w.rf>
    <LM>w#w-d1t1549-5</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1549-4">
   <w.rf>
    <LM>w#w-d1t1549-4</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1551-1">
   <w.rf>
    <LM>w#w-d1t1551-1</LM>
   </w.rf>
   <form>nijak</form>
   <lemma>nijak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>dávat</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1551-3">
   <w.rf>
    <LM>w#w-d1t1551-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1551-4">
   <w.rf>
    <LM>w#w-d1t1551-4</LM>
   </w.rf>
   <form>souvislostí</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-2223-2239">
   <w.rf>
    <LM>w#w-2223-2239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-2240">
  <m id="m784-d1t1551-9">
   <w.rf>
    <LM>w#w-d1t1551-9</LM>
   </w.rf>
   <form>Vstoupil</form>
   <lemma>vstoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t1551-8">
   <w.rf>
    <LM>w#w-d1t1551-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-2240-2324">
   <w.rf>
    <LM>w#w-2240-2324</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1559-1">
   <w.rf>
    <LM>w#w-d1t1559-1</LM>
   </w.rf>
   <form>tudíž</form>
   <lemma>tudíž</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1559-2">
   <w.rf>
    <LM>w#w-d1t1559-2</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t1559-3">
   <w.rf>
    <LM>w#w-d1t1559-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1559-4">
   <w.rf>
    <LM>w#w-d1t1559-4</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWYP4----------</tag>
  </m>
  <m id="m784-d1t1559-5">
   <w.rf>
    <LM>w#w-d1t1559-5</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d-id106707">
   <w.rf>
    <LM>w#w-d-id106707</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1509-x5">
  <m id="m784-d1t1562-1">
   <w.rf>
    <LM>w#w-d1t1562-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1562-2">
   <w.rf>
    <LM>w#w-d1t1562-2</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m784-d1t1562-3">
   <w.rf>
    <LM>w#w-d1t1562-3</LM>
   </w.rf>
   <form>růstu</form>
   <lemma>růst-1</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t1562-4">
   <w.rf>
    <LM>w#w-d1t1562-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1562-5">
   <w.rf>
    <LM>w#w-d1t1562-5</LM>
   </w.rf>
   <form>politické</form>
   <lemma>politický</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m784-d1t1562-6">
   <w.rf>
    <LM>w#w-d1t1562-6</LM>
   </w.rf>
   <form>špičky</form>
   <lemma>špička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1t1562-7">
   <w.rf>
    <LM>w#w-d1t1562-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1562-8">
   <w.rf>
    <LM>w#w-d1t1562-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m784-d1t1562-9">
   <w.rf>
    <LM>w#w-d1t1562-9</LM>
   </w.rf>
   <form>nepřipadaly</form>
   <lemma>připadat</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m784-d1t1562-10">
   <w.rf>
    <LM>w#w-d1t1562-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1562-11">
   <w.rf>
    <LM>w#w-d1t1562-11</LM>
   </w.rf>
   <form>úvahu</form>
   <lemma>úvaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t1566-1">
   <w.rf>
    <LM>w#w-d1t1566-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1566-2">
   <w.rf>
    <LM>w#w-d1t1566-2</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m784-d1t1568-1">
   <w.rf>
    <LM>w#w-d1t1568-1</LM>
   </w.rf>
   <form>prostého</form>
   <lemma>prostý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m784-d1t1568-2">
   <w.rf>
    <LM>w#w-d1t1568-2</LM>
   </w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e1509-x5-2533">
   <w.rf>
    <LM>w#w-d1e1509-x5-2533</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1572-1">
   <w.rf>
    <LM>w#w-d1t1572-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1572-2">
   <w.rf>
    <LM>w#w-d1t1572-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1572-3">
   <w.rf>
    <LM>w#w-d1t1572-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1572-4">
   <w.rf>
    <LM>w#w-d1t1572-4</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1572-5">
   <w.rf>
    <LM>w#w-d1t1572-5</LM>
   </w.rf>
   <form>kariérista</form>
   <lemma>kariérista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e1509-x5-2536">
   <w.rf>
    <LM>w#w-d1e1509-x5-2536</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1572-6">
   <w.rf>
    <LM>w#w-d1t1572-6</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1572-7">
   <w.rf>
    <LM>w#w-d1t1572-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1572-8">
   <w.rf>
    <LM>w#w-d1t1572-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1572-9">
   <w.rf>
    <LM>w#w-d1t1572-9</LM>
   </w.rf>
   <form>snažil</form>
   <lemma>snažit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1572-15">
   <w.rf>
    <LM>w#w-d1t1572-15</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1572-12">
   <w.rf>
    <LM>w#w-d1t1572-12</LM>
   </w.rf>
   <form>plnit</form>
   <lemma>plnit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1572-13">
   <w.rf>
    <LM>w#w-d1t1572-13</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FP4---------1</tag>
  </m>
  <m id="m784-d1t1572-14">
   <w.rf>
    <LM>w#w-d1t1572-14</LM>
   </w.rf>
   <form>povinnosti</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m784-d1t1575-1">
   <w.rf>
    <LM>w#w-d1t1575-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1575-2">
   <w.rf>
    <LM>w#w-d1t1575-2</LM>
   </w.rf>
   <form>hledět</form>
   <lemma>hledět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t1575-3">
   <w.rf>
    <LM>w#w-d1t1575-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1575-4">
   <w.rf>
    <LM>w#w-d1t1575-4</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m784-d-id107338">
   <w.rf>
    <LM>w#w-d-id107338</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1509-x8">
  <m id="m784-d1t1579-1">
   <w.rf>
    <LM>w#w-d1t1579-1</LM>
   </w.rf>
   <form>Jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1579-2">
   <w.rf>
    <LM>w#w-d1t1579-2</LM>
   </w.rf>
   <form>coby</form>
   <lemma>coby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1579-4">
   <w.rf>
    <LM>w#w-d1t1579-4</LM>
   </w.rf>
   <form>amatér</form>
   <lemma>amatér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t1579-5">
   <w.rf>
    <LM>w#w-d1t1579-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1579-7">
   <w.rf>
    <LM>w#w-d1t1579-7</LM>
   </w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1e1509-x8-2598">
   <w.rf>
    <LM>w#w-d1e1509-x8-2598</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1579-9">
   <w.rf>
    <LM>w#w-d1t1579-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1579-10">
   <w.rf>
    <LM>w#w-d1t1579-10</LM>
   </w.rf>
   <form>řeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m784-d1t1579-11">
   <w.rf>
    <LM>w#w-d1t1579-11</LM>
   </w.rf>
   <form>otevřeně</form>
   <lemma>otevřeně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1e1509-x8-2600">
   <w.rf>
    <LM>w#w-d1e1509-x8-2600</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1581-1">
   <w.rf>
    <LM>w#w-d1t1581-1</LM>
   </w.rf>
   <form>skončit</form>
   <lemma>skončit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t1581-2">
   <w.rf>
    <LM>w#w-d1t1581-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1581-3">
   <w.rf>
    <LM>w#w-d1t1581-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m784-d-id107597">
   <w.rf>
    <LM>w#w-d-id107597</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1581-5">
   <w.rf>
    <LM>w#w-d1t1581-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1581-6">
   <w.rf>
    <LM>w#w-d1t1581-6</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m784-d1t1581-7">
   <w.rf>
    <LM>w#w-d1t1581-7</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1581-8">
   <w.rf>
    <LM>w#w-d1t1581-8</LM>
   </w.rf>
   <form>vysílat</form>
   <lemma>vysílat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1e1509-x8-1458">
   <w.rf>
    <LM>w#w-d1e1509-x8-1458</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1459">
  <m id="m784-d1t1583-2">
   <w.rf>
    <LM>w#w-d1t1583-2</LM>
   </w.rf>
   <form>Bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1583-3">
   <w.rf>
    <LM>w#w-d1t1583-3</LM>
   </w.rf>
   <form>komunistické</form>
   <lemma>komunistický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m784-d1t1583-4">
   <w.rf>
    <LM>w#w-d1t1583-4</LM>
   </w.rf>
   <form>příslušnosti</form>
   <lemma>příslušnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t1583-5">
   <w.rf>
    <LM>w#w-d1t1583-5</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m784-d1t1583-6">
   <w.rf>
    <LM>w#w-d1t1583-6</LM>
   </w.rf>
   <form>nevysílal</form>
   <lemma>vysílat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d-id107770">
   <w.rf>
    <LM>w#w-d-id107770</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1509-x9">
  <m id="m784-d1t1588-1">
   <w.rf>
    <LM>w#w-d1t1588-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1588-2">
   <w.rf>
    <LM>w#w-d1t1588-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1588-3">
   <w.rf>
    <LM>w#w-d1t1588-3</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1588-4">
   <w.rf>
    <LM>w#w-d1t1588-4</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m784-d1t1588-5">
   <w.rf>
    <LM>w#w-d1t1588-5</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1t1588-6">
   <w.rf>
    <LM>w#w-d1t1588-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m784-d1e1509-x9-2635">
   <w.rf>
    <LM>w#w-d1e1509-x9-2635</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1588-7">
   <w.rf>
    <LM>w#w-d1t1588-7</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1588-8">
   <w.rf>
    <LM>w#w-d1t1588-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1588-9">
   <w.rf>
    <LM>w#w-d1t1588-9</LM>
   </w.rf>
   <form>vstupoval</form>
   <lemma>vstupovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1e1509-x9-10334">
   <w.rf>
    <LM>w#w-d1e1509-x9-10334</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1592-1">
   <w.rf>
    <LM>w#w-d1t1592-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1592-2">
   <w.rf>
    <LM>w#w-d1t1592-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1592-3">
   <w.rf>
    <LM>w#w-d1t1592-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1592-4">
   <w.rf>
    <LM>w#w-d1t1592-4</LM>
   </w.rf>
   <form>prospěchu</form>
   <lemma>prospěch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d-id108038">
   <w.rf>
    <LM>w#w-d-id108038</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1593-x2">
  <m id="m784-d1t1596-3">
   <w.rf>
    <LM>w#w-d1t1596-3</LM>
   </w.rf>
   <form>Předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1596-2">
   <w.rf>
    <LM>w#w-d1t1596-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1596-4">
   <w.rf>
    <LM>w#w-d1t1596-4</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d-id108151">
   <w.rf>
    <LM>w#w-d-id108151</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1596-6">
   <w.rf>
    <LM>w#w-d1t1596-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1596-7">
   <w.rf>
    <LM>w#w-d1t1596-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1596-8">
   <w.rf>
    <LM>w#w-d1t1596-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1596-9">
   <w.rf>
    <LM>w#w-d1t1596-9</LM>
   </w.rf>
   <form>veden</form>
   <lemma>vést</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m784-d1t1596-10">
   <w.rf>
    <LM>w#w-d1t1596-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1596-11">
   <w.rf>
    <LM>w#w-d1t1596-11</LM>
   </w.rf>
   <form>kádrových</form>
   <lemma>kádrový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m784-d1t1596-12">
   <w.rf>
    <LM>w#w-d1t1596-12</LM>
   </w.rf>
   <form>materiálech</form>
   <lemma>materiál</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m784-d1t1596-13">
   <w.rf>
    <LM>w#w-d1t1596-13</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1596-14">
   <w.rf>
    <LM>w#w-d1t1596-14</LM>
   </w.rf>
   <form>politický</form>
   <lemma>politický</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t1596-15">
   <w.rf>
    <LM>w#w-d1t1596-15</LM>
   </w.rf>
   <form>vězeň</form>
   <lemma>vězeň</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id108268">
   <w.rf>
    <LM>w#w-d-id108268</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1593-x3">
  <m id="m784-d1t1598-1">
   <w.rf>
    <LM>w#w-d1t1598-1</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1598-3">
   <w.rf>
    <LM>w#w-d1t1598-3</LM>
   </w.rf>
   <form>kádrovák</form>
   <lemma>kádrovák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t1600-1">
   <w.rf>
    <LM>w#w-d1t1600-1</LM>
   </w.rf>
   <form>neuměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1600-2">
   <w.rf>
    <LM>w#w-d1t1600-2</LM>
   </w.rf>
   <form>počítat</form>
   <lemma>počítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1e1593-x3-2781">
   <w.rf>
    <LM>w#w-d1e1593-x3-2781</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1600-3">
   <w.rf>
    <LM>w#w-d1t1600-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1600-4">
   <w.rf>
    <LM>w#w-d1t1600-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1600-5">
   <w.rf>
    <LM>w#w-d1t1600-5</LM>
   </w.rf>
   <form>chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1e1593-x3-1469">
   <w.rf>
    <LM>w#w-d1e1593-x3-1469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1470">
  <m id="m784-d1t1600-7">
   <w.rf>
    <LM>w#w-d1t1600-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1600-9">
   <w.rf>
    <LM>w#w-d1t1600-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1600-10">
   <w.rf>
    <LM>w#w-d1t1600-10</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t1600-11">
   <w.rf>
    <LM>w#w-d1t1600-11</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d1t1600-12">
   <w.rf>
    <LM>w#w-d1t1600-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1600-13">
   <w.rf>
    <LM>w#w-d1t1600-13</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m784-d1t1600-14">
   <w.rf>
    <LM>w#w-d1t1600-14</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m784-d1t1600-15">
   <w.rf>
    <LM>w#w-d1t1600-15</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1600-16">
   <w.rf>
    <LM>w#w-d1t1600-16</LM>
   </w.rf>
   <form>politický</form>
   <lemma>politický</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t1602-1">
   <w.rf>
    <LM>w#w-d1t1602-1</LM>
   </w.rf>
   <form>vězeň</form>
   <lemma>vězeň</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e1593-x3-2782">
   <w.rf>
    <LM>w#w-d1e1593-x3-2782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1593-x3-2785">
   <w.rf>
    <LM>w#w-d1e1593-x3-2785</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1602-2">
   <w.rf>
    <LM>w#w-d1t1602-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t1602-3">
   <w.rf>
    <LM>w#w-d1t1602-3</LM>
   </w.rf>
   <form>připadá</form>
   <lemma>připadat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1602-5">
   <w.rf>
    <LM>w#w-d1t1602-5</LM>
   </w.rf>
   <form>absurdní</form>
   <lemma>absurdní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d-id108584">
   <w.rf>
    <LM>w#w-d-id108584</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1605-x2">
  <m id="m784-d1t1608-2">
   <w.rf>
    <LM>w#w-d1t1608-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1608-3">
   <w.rf>
    <LM>w#w-d1t1608-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1608-4">
   <w.rf>
    <LM>w#w-d1t1608-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1608-6">
   <w.rf>
    <LM>w#w-d1t1608-6</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1608-5">
   <w.rf>
    <LM>w#w-d1t1608-5</LM>
   </w.rf>
   <form>vedené</form>
   <lemma>vedený_^(*5ést)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1e1605-x2-2966">
   <w.rf>
    <LM>w#w-d1e1605-x2-2966</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1608-10">
   <w.rf>
    <LM>w#w-d1t1608-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1608-9">
   <w.rf>
    <LM>w#w-d1t1608-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1608-7">
   <w.rf>
    <LM>w#w-d1t1608-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1608-8">
   <w.rf>
    <LM>w#w-d1t1608-8</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d-id108634">
   <w.rf>
    <LM>w#w-d-id108634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1609-x2">
  <m id="m784-d1t1612-1">
   <w.rf>
    <LM>w#w-d1t1612-1</LM>
   </w.rf>
   <form>Zkrátka</form>
   <lemma>zkrátka-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1612-3">
   <w.rf>
    <LM>w#w-d1t1612-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1612-4">
   <w.rf>
    <LM>w#w-d1t1612-4</LM>
   </w.rf>
   <form>pitomci</form>
   <lemma>pitomec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d-id108955">
   <w.rf>
    <LM>w#w-d-id108955</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1613-x2">
  <m id="m784-d1t1616-1">
   <w.rf>
    <LM>w#w-d1t1616-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1616-2">
   <w.rf>
    <LM>w#w-d1t1616-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1616-3">
   <w.rf>
    <LM>w#w-d1t1616-3</LM>
   </w.rf>
   <form>pitomci</form>
   <lemma>pitomec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1e1613-x2-2969">
   <w.rf>
    <LM>w#w-d1e1613-x2-2969</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1616-5">
   <w.rf>
    <LM>w#w-d1t1616-5</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m784-d1t1616-4">
   <w.rf>
    <LM>w#w-d1t1616-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1616-6">
   <w.rf>
    <LM>w#w-d1t1616-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m784-d-id109005">
   <w.rf>
    <LM>w#w-d-id109005</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1617-x2">
  <m id="m784-d1e1617-x2-3194">
   <w.rf>
    <LM>w#w-d1e1617-x2-3194</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1e1617-x2-3195">
   <w.rf>
    <LM>w#w-d1e1617-x2-3195</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1622-1">
   <w.rf>
    <LM>w#w-d1t1622-1</LM>
   </w.rf>
   <form>jediné</form>
   <lemma>jediný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1t1622-2">
   <w.rf>
    <LM>w#w-d1t1622-2</LM>
   </w.rf>
   <form>vysvětlení</form>
   <lemma>vysvětlení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d-id109158">
   <w.rf>
    <LM>w#w-d-id109158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1625-x2">
  <m id="m784-d1t1624-1">
   <w.rf>
    <LM>w#w-d1t1624-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1628-1">
   <w.rf>
    <LM>w#w-d1t1628-1</LM>
   </w.rf>
   <form>tvrdím</form>
   <lemma>tvrdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1628-2">
   <w.rf>
    <LM>w#w-d1t1628-2</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m784-d1t1628-3">
   <w.rf>
    <LM>w#w-d1t1628-3</LM>
   </w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e1625-x2-1475">
   <w.rf>
    <LM>w#w-d1e1625-x2-1475</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1628-7">
   <w.rf>
    <LM>w#w-d1t1628-7</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1628-8">
   <w.rf>
    <LM>w#w-d1t1628-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1628-11">
   <w.rf>
    <LM>w#w-d1t1628-11</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1628-12">
   <w.rf>
    <LM>w#w-d1t1628-12</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t1628-13">
   <w.rf>
    <LM>w#w-d1t1628-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1628-14">
   <w.rf>
    <LM>w#w-d1t1628-14</LM>
   </w.rf>
   <form>vyzvednout</form>
   <lemma>vyzvednout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t1628-9">
   <w.rf>
    <LM>w#w-d1t1628-9</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m784-d1t1628-10">
   <w.rf>
    <LM>w#w-d1t1628-10</LM>
   </w.rf>
   <form>papíry</form>
   <lemma>papír</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1e1625-x2-3379">
   <w.rf>
    <LM>w#w-d1e1625-x2-3379</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1628-19">
   <w.rf>
    <LM>w#w-d1t1628-19</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1628-17">
   <w.rf>
    <LM>w#w-d1t1628-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1628-18">
   <w.rf>
    <LM>w#w-d1t1628-18</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1628-16">
   <w.rf>
    <LM>w#w-d1t1628-16</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1628-20">
   <w.rf>
    <LM>w#w-d1t1628-20</LM>
   </w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1e1625-x2-3322">
   <w.rf>
    <LM>w#w-d1e1625-x2-3322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-3323">
  <m id="m784-d1t1632-1">
   <w.rf>
    <LM>w#w-d1t1632-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1632-3">
   <w.rf>
    <LM>w#w-d1t1632-3</LM>
   </w.rf>
   <form>kádrových</form>
   <lemma>kádrův-2_^(*4-2)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m784-d1t1632-4">
   <w.rf>
    <LM>w#w-d1t1632-4</LM>
   </w.rf>
   <form>materiálech</form>
   <lemma>materiál</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m784-d1t1632-5">
   <w.rf>
    <LM>w#w-d1t1632-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t1632-8">
   <w.rf>
    <LM>w#w-d1t1632-8</LM>
   </w.rf>
   <form>založená</form>
   <lemma>založený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m784-d1t1632-6">
   <w.rf>
    <LM>w#w-d1t1632-6</LM>
   </w.rf>
   <form>kopie</form>
   <lemma>kopie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-3323-3626">
   <w.rf>
    <LM>w#w-3323-3626</LM>
   </w.rf>
   <form>osvědčení</form>
   <lemma>osvědčení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t1632-7">
   <w.rf>
    <LM>w#w-d1t1632-7</LM>
   </w.rf>
   <form>255</form>
   <lemma>255</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-3323-1478">
   <w.rf>
    <LM>w#w-3323-1478</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1479">
  <m id="m784-d1t1634-1">
   <w.rf>
    <LM>w#w-d1t1634-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1634-2">
   <w.rf>
    <LM>w#w-d1t1634-2</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d1t1634-3">
   <w.rf>
    <LM>w#w-d1t1634-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1634-4">
   <w.rf>
    <LM>w#w-d1t1634-4</LM>
   </w.rf>
   <form>trval</form>
   <lemma>trvat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-3323-3579">
   <w.rf>
    <LM>w#w-3323-3579</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1641-1">
   <w.rf>
    <LM>w#w-d1t1641-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1641-2">
   <w.rf>
    <LM>w#w-d1t1641-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1641-3">
   <w.rf>
    <LM>w#w-d1t1641-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1641-4">
   <w.rf>
    <LM>w#w-d1t1641-4</LM>
   </w.rf>
   <form>myslel</form>
   <lemma>myslit</lemma>
   <tag>VpYS----R-AAI-1</tag>
  </m>
  <m id="m784-d-id109939">
   <w.rf>
    <LM>w#w-d-id109939</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1641-6">
   <w.rf>
    <LM>w#w-d1t1641-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1641-7">
   <w.rf>
    <LM>w#w-d1t1641-7</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1645-1">
   <w.rf>
    <LM>w#w-d1t1645-1</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m784-d1t1645-2">
   <w.rf>
    <LM>w#w-d1t1645-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1645-3">
   <w.rf>
    <LM>w#w-d1t1645-3</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m784-d1t1645-4">
   <w.rf>
    <LM>w#w-d1t1645-4</LM>
   </w.rf>
   <form>slušně</form>
   <lemma>slušně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1645-5">
   <w.rf>
    <LM>w#w-d1t1645-5</LM>
   </w.rf>
   <form>jednat</form>
   <lemma>jednat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-3323-3582">
   <w.rf>
    <LM>w#w-3323-3582</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-3583">
  <m id="m784-d1t1645-7">
   <w.rf>
    <LM>w#w-d1t1645-7</LM>
   </w.rf>
   <form>Nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1645-8">
   <w.rf>
    <LM>w#w-d1t1645-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1645-9">
   <w.rf>
    <LM>w#w-d1t1645-9</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m784-d1t1645-10">
   <w.rf>
    <LM>w#w-d1t1645-10</LM>
   </w.rf>
   <form>výhody</form>
   <lemma>výhoda</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m784-3583-3646">
   <w.rf>
    <LM>w#w-3583-3646</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1647-1">
   <w.rf>
    <LM>w#w-d1t1647-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1647-2">
   <w.rf>
    <LM>w#w-d1t1647-2</LM>
   </w.rf>
   <form>slušné</form>
   <lemma>slušný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t1647-3">
   <w.rf>
    <LM>w#w-d1t1647-3</LM>
   </w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d-id110209">
   <w.rf>
    <LM>w#w-d-id110209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1655-x2">
  <m id="m784-d1t1658-2">
   <w.rf>
    <LM>w#w-d1t1658-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1658-3">
   <w.rf>
    <LM>w#w-d1t1658-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t1658-4">
   <w.rf>
    <LM>w#w-d1t1658-4</LM>
   </w.rf>
   <form>psán</form>
   <lemma>psát</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m784-d1t1658-5">
   <w.rf>
    <LM>w#w-d1t1658-5</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d-id110387">
   <w.rf>
    <LM>w#w-d-id110387</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1658-7">
   <w.rf>
    <LM>w#w-d1t1658-7</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1658-8">
   <w.rf>
    <LM>w#w-d1t1658-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1658-9">
   <w.rf>
    <LM>w#w-d1t1658-9</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1e1655-x2-3628">
   <w.rf>
    <LM>w#w-d1e1655-x2-3628</LM>
   </w.rf>
   <form>osvědčení</form>
   <lemma>osvědčení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t1664-1">
   <w.rf>
    <LM>w#w-d1t1664-1</LM>
   </w.rf>
   <form>255</form>
   <lemma>255</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e1655-x2-3897">
   <w.rf>
    <LM>w#w-d1e1655-x2-3897</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1659-x3">
  <m id="m784-d1t1666-1">
   <w.rf>
    <LM>w#w-d1t1666-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e1659-x3-3919">
   <w.rf>
    <LM>w#w-d1e1659-x3-3919</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1666-3">
   <w.rf>
    <LM>w#w-d1t1666-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1666-4">
   <w.rf>
    <LM>w#w-d1t1666-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d1e1659-x3-3630">
   <w.rf>
    <LM>w#w-d1e1659-x3-3630</LM>
   </w.rf>
   <form>osvědčení</form>
   <lemma>osvědčení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1t1666-5">
   <w.rf>
    <LM>w#w-d1t1666-5</LM>
   </w.rf>
   <form>255</form>
   <lemma>255</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e1659-x3-3952">
   <w.rf>
    <LM>w#w-d1e1659-x3-3952</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1e1659-x3-3953">
   <w.rf>
    <LM>w#w-d1e1659-x3-3953</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1666-6">
   <w.rf>
    <LM>w#w-d1t1666-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1666-7">
   <w.rf>
    <LM>w#w-d1t1666-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1666-8">
   <w.rf>
    <LM>w#w-d1t1666-8</LM>
   </w.rf>
   <form>zavřen</form>
   <lemma>zavřít</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m784-d1e1659-x3-3964">
   <w.rf>
    <LM>w#w-d1e1659-x3-3964</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1670-1">
   <w.rf>
    <LM>w#w-d1t1670-1</LM>
   </w.rf>
   <form>Koncentrační</form>
   <lemma>koncentrační</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m784-d1t1670-2">
   <w.rf>
    <LM>w#w-d1t1670-2</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1t1672-1">
   <w.rf>
    <LM>w#w-d1t1672-1</LM>
   </w.rf>
   <form>Terezín</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1e1659-x3-3967">
   <w.rf>
    <LM>w#w-d1e1659-x3-3967</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1672-3">
   <w.rf>
    <LM>w#w-d1t1672-3</LM>
   </w.rf>
   <form>ghetto</form>
   <lemma>ghetto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d-id110784">
   <w.rf>
    <LM>w#w-d-id110784</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1675-x2">
  <m id="m784-d1t1678-1">
   <w.rf>
    <LM>w#w-d1t1678-1</LM>
   </w.rf>
   <form>Udržujete</form>
   <lemma>udržovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1678-2">
   <w.rf>
    <LM>w#w-d1t1678-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1678-4">
   <w.rf>
    <LM>w#w-d1t1678-4</LM>
   </w.rf>
   <form>udržoval</form>
   <lemma>udržovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1678-3">
   <w.rf>
    <LM>w#w-d1t1678-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1678-5">
   <w.rf>
    <LM>w#w-d1t1678-5</LM>
   </w.rf>
   <form>kontakt</form>
   <lemma>kontakt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t1678-6">
   <w.rf>
    <LM>w#w-d1t1678-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1678-7">
   <w.rf>
    <LM>w#w-d1t1678-7</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m784-d-id110937">
   <w.rf>
    <LM>w#w-d-id110937</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1678-9">
   <w.rf>
    <LM>w#w-d1t1678-9</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m784-d1t1678-10">
   <w.rf>
    <LM>w#w-d1t1678-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1678-11">
   <w.rf>
    <LM>w#w-d1t1678-11</LM>
   </w.rf>
   <form>podobný</form>
   <lemma>podobný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m784-d1t1680-1">
   <w.rf>
    <LM>w#w-d1t1680-1</LM>
   </w.rf>
   <form>osud</form>
   <lemma>osud</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t1680-2">
   <w.rf>
    <LM>w#w-d1t1680-2</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1680-3">
   <w.rf>
    <LM>w#w-d1t1680-3</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m784-d-id111021">
   <w.rf>
    <LM>w#w-d-id111021</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1682-x2">
  <m id="m784-d1t1691-3">
   <w.rf>
    <LM>w#w-d1t1691-3</LM>
   </w.rf>
   <form>Udržoval</form>
   <lemma>udržovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1691-2">
   <w.rf>
    <LM>w#w-d1t1691-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1691-4">
   <w.rf>
    <LM>w#w-d1t1691-4</LM>
   </w.rf>
   <form>kontakt</form>
   <lemma>kontakt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t1691-5">
   <w.rf>
    <LM>w#w-d1t1691-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1691-6">
   <w.rf>
    <LM>w#w-d1t1691-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1691-7">
   <w.rf>
    <LM>w#w-d1t1691-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d1t1691-8">
   <w.rf>
    <LM>w#w-d1t1691-8</LM>
   </w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d-id111268">
   <w.rf>
    <LM>w#w-d-id111268</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1691-10">
   <w.rf>
    <LM>w#w-d1t1691-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1691-11">
   <w.rf>
    <LM>w#w-d1t1691-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1691-12">
   <w.rf>
    <LM>w#w-d1t1691-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1691-13">
   <w.rf>
    <LM>w#w-d1t1691-13</LM>
   </w.rf>
   <form>člen</form>
   <lemma>člen-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t1691-14">
   <w.rf>
    <LM>w#w-d1t1691-14</LM>
   </w.rf>
   <form>Svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t1691-15">
   <w.rf>
    <LM>w#w-d1t1691-15</LM>
   </w.rf>
   <form>bojovníků</form>
   <lemma>bojovník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m784-d1t1691-16">
   <w.rf>
    <LM>w#w-d1t1691-16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1691-17">
   <w.rf>
    <LM>w#w-d1t1691-17</LM>
   </w.rf>
   <form>svobodu</form>
   <lemma>svoboda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e1682-x2-4081">
   <w.rf>
    <LM>w#w-d1e1682-x2-4081</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1693-1">
   <w.rf>
    <LM>w#w-d1t1693-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1693-2">
   <w.rf>
    <LM>w#w-d1t1693-2</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m784-d1e1682-x2-4082">
   <w.rf>
    <LM>w#w-d1e1682-x2-4082</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1693-4">
   <w.rf>
    <LM>w#w-d1t1693-4</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m784-d1t1693-5">
   <w.rf>
    <LM>w#w-d1t1693-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1693-6">
   <w.rf>
    <LM>w#w-d1t1693-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1693-7">
   <w.rf>
    <LM>w#w-d1t1693-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1693-8">
   <w.rf>
    <LM>w#w-d1t1693-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1693-9">
   <w.rf>
    <LM>w#w-d1t1693-9</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m784-d1t1693-10">
   <w.rf>
    <LM>w#w-d1t1693-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1693-13">
   <w.rf>
    <LM>w#w-d1t1693-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1693-14">
   <w.rf>
    <LM>w#w-d1t1693-14</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m784-d1t1693-15">
   <w.rf>
    <LM>w#w-d1t1693-15</LM>
   </w.rf>
   <form>organizaci</form>
   <lemma>organizace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t1700-1">
   <w.rf>
    <LM>w#w-d1t1700-1</LM>
   </w.rf>
   <form>činnými</form>
   <lemma>činný</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m784-d-id111730">
   <w.rf>
    <LM>w#w-d-id111730</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1701-x2">
  <m id="m784-d1t1704-1">
   <w.rf>
    <LM>w#w-d1t1704-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1704-8">
   <w.rf>
    <LM>w#w-d1t1704-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m784-d1e1701-x2-4121">
   <w.rf>
    <LM>w#w-d1e1701-x2-4121</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1704-7">
   <w.rf>
    <LM>w#w-d1t1704-7</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1704-10">
   <w.rf>
    <LM>w#w-d1t1704-10</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1704-9">
   <w.rf>
    <LM>w#w-d1t1704-9</LM>
   </w.rf>
   <form>skuteční</form>
   <lemma>skutečný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m784-d1t1704-11">
   <w.rf>
    <LM>w#w-d1t1704-11</LM>
   </w.rf>
   <form>odbojáři</form>
   <lemma>odbojář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t1704-12">
   <w.rf>
    <LM>w#w-d1t1704-12</LM>
   </w.rf>
   <form>nežli</form>
   <lemma>nežli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1704-14">
   <w.rf>
    <LM>w#w-d1t1704-14</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t1704-15">
   <w.rf>
    <LM>w#w-d1t1704-15</LM>
   </w.rf>
   <form>pronásledovaní</form>
   <lemma>pronásledovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m784-d1t1706-1">
   <w.rf>
    <LM>w#w-d1t1706-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1706-2">
   <w.rf>
    <LM>w#w-d1t1706-2</LM>
   </w.rf>
   <form>rasových</form>
   <lemma>rasový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m784-d1t1706-3">
   <w.rf>
    <LM>w#w-d1t1706-3</LM>
   </w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d-id112010">
   <w.rf>
    <LM>w#w-d-id112010</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1707-x2">
  <m id="m784-d1t1712-1">
   <w.rf>
    <LM>w#w-d1t1712-1</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e1707-x2-4200">
   <w.rf>
    <LM>w#w-d1e1707-x2-4200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4201">
  <m id="m784-d1t1712-2">
   <w.rf>
    <LM>w#w-d1t1712-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1712-3">
   <w.rf>
    <LM>w#w-d1t1712-3</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1712-4">
   <w.rf>
    <LM>w#w-d1t1712-4</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d-id112161">
   <w.rf>
    <LM>w#w-d-id112161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1712-6">
   <w.rf>
    <LM>w#w-d1t1712-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1714-4">
   <w.rf>
    <LM>w#w-d1t1714-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1714-3">
   <w.rf>
    <LM>w#w-d1t1714-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1714-5">
   <w.rf>
    <LM>w#w-d1t1714-5</LM>
   </w.rf>
   <form>odbojáři</form>
   <lemma>odbojář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d-id112296">
   <w.rf>
    <LM>w#w-d-id112296</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1714-7">
   <w.rf>
    <LM>w#w-d1t1714-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1714-8">
   <w.rf>
    <LM>w#w-d1t1714-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1714-9">
   <w.rf>
    <LM>w#w-d1t1714-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1714-10">
   <w.rf>
    <LM>w#w-d1t1714-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1716-1">
   <w.rf>
    <LM>w#w-d1t1716-1</LM>
   </w.rf>
   <form>persekuovaní</form>
   <lemma>persekuovaný_^(^DD**perzekuovaný)_(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m784-d1t1716-2">
   <w.rf>
    <LM>w#w-d1t1716-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t1716-3">
   <w.rf>
    <LM>w#w-d1t1716-3</LM>
   </w.rf>
   <form>rasových</form>
   <lemma>rasový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m784-d1t1716-4">
   <w.rf>
    <LM>w#w-d1t1716-4</LM>
   </w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d-id112437">
   <w.rf>
    <LM>w#w-d-id112437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1717-x2">
  <m id="m784-d1t1722-2">
   <w.rf>
    <LM>w#w-d1t1722-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1722-3">
   <w.rf>
    <LM>w#w-d1t1722-3</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m784-d1t1722-8">
   <w.rf>
    <LM>w#w-d1t1722-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1722-9">
   <w.rf>
    <LM>w#w-d1t1722-9</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1722-10">
   <w.rf>
    <LM>w#w-d1t1722-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1722-7">
   <w.rf>
    <LM>w#w-d1t1722-7</LM>
   </w.rf>
   <form>nestydíte</form>
   <lemma>stydět</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m784-d1e1717-x2-4240">
   <w.rf>
    <LM>w#w-d1e1717-x2-4240</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1722-11">
   <w.rf>
    <LM>w#w-d1t1722-11</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d-id112653">
   <w.rf>
    <LM>w#w-d-id112653</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1723-x3">
  <m id="m784-d1t1732-1">
   <w.rf>
    <LM>w#w-d1t1732-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e1723-x3-4257">
   <w.rf>
    <LM>w#w-d1e1723-x3-4257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1732-2">
   <w.rf>
    <LM>w#w-d1t1732-2</LM>
   </w.rf>
   <form>nestydím</form>
   <lemma>stydět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m784-d1t1732-3">
   <w.rf>
    <LM>w#w-d1t1732-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1732-4">
   <w.rf>
    <LM>w#w-d1t1732-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t1732-5">
   <w.rf>
    <LM>w#w-d1t1732-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1e1723-x3-1502">
   <w.rf>
    <LM>w#w-d1e1723-x3-1502</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1503">
  <m id="m784-d1t1740-2">
   <w.rf>
    <LM>w#w-d1t1740-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1740-4">
   <w.rf>
    <LM>w#w-d1t1740-4</LM>
   </w.rf>
   <form>organizaci</form>
   <lemma>organizace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t1740-7">
   <w.rf>
    <LM>w#w-d1t1740-7</LM>
   </w.rf>
   <form>Svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t1740-8">
   <w.rf>
    <LM>w#w-d1t1740-8</LM>
   </w.rf>
   <form>bojovníků</form>
   <lemma>bojovník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m784-d1t1740-9">
   <w.rf>
    <LM>w#w-d1t1740-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1740-10">
   <w.rf>
    <LM>w#w-d1t1740-10</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m784-d1t1740-11">
   <w.rf>
    <LM>w#w-d1t1740-11</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m784-d-id113057">
   <w.rf>
    <LM>w#w-d-id113057</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1740-13">
   <w.rf>
    <LM>w#w-d1t1740-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1740-14">
   <w.rf>
    <LM>w#w-d1t1740-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1740-15">
   <w.rf>
    <LM>w#w-d1t1740-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t1744-3">
   <w.rf>
    <LM>w#w-d1t1744-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1744-4">
   <w.rf>
    <LM>w#w-d1t1744-4</LM>
   </w.rf>
   <form>tomhle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d1t1744-5">
   <w.rf>
    <LM>w#w-d1t1744-5</LM>
   </w.rf>
   <form>směru</form>
   <lemma>směr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t1744-2">
   <w.rf>
    <LM>w#w-d1t1744-2</LM>
   </w.rf>
   <form>rovni</form>
   <lemma>rovný_^(přímý,_stejný,_spravedlivý)</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m784-d1e1723-x3-4433">
   <w.rf>
    <LM>w#w-d1e1723-x3-4433</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1744-6">
   <w.rf>
    <LM>w#w-d1t1744-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1744-7">
   <w.rf>
    <LM>w#w-d1t1744-7</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m784-d1t1744-8">
   <w.rf>
    <LM>w#w-d1t1744-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1744-9">
   <w.rf>
    <LM>w#w-d1t1744-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t1744-10">
   <w.rf>
    <LM>w#w-d1t1744-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1744-11">
   <w.rf>
    <LM>w#w-d1t1744-11</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m784-d1t1744-12">
   <w.rf>
    <LM>w#w-d1t1744-12</LM>
   </w.rf>
   <form>lodi</form>
   <lemma>loď</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d-id113309">
   <w.rf>
    <LM>w#w-d-id113309</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1733-x3">
  <m id="m784-d1t1749-1">
   <w.rf>
    <LM>w#w-d1t1749-1</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m784-d1t1751-1">
   <w.rf>
    <LM>w#w-d1t1751-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e1733-x3-4528">
   <w.rf>
    <LM>w#w-d1e1733-x3-4528</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1751-2">
   <w.rf>
    <LM>w#w-d1t1751-2</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m784-d1t1751-3">
   <w.rf>
    <LM>w#w-d1t1751-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e1733-x3-4529">
   <w.rf>
    <LM>w#w-d1e1733-x3-4529</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1755-1">
   <w.rf>
    <LM>w#w-d1t1755-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1755-2">
   <w.rf>
    <LM>w#w-d1t1755-2</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m784-d1t1755-3">
   <w.rf>
    <LM>w#w-d1t1755-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t1767-1">
   <w.rf>
    <LM>w#w-d1t1767-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1767-2">
   <w.rf>
    <LM>w#w-d1t1767-2</LM>
   </w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1e1733-x3-4633">
   <w.rf>
    <LM>w#w-d1e1733-x3-4633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1733-x3-4634">
   <w.rf>
    <LM>w#w-d1e1733-x3-4634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1733-x3-4635">
   <w.rf>
    <LM>w#w-d1e1733-x3-4635</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1758-x2">
  <m id="m784-d1t1763-1">
   <w.rf>
    <LM>w#w-d1t1763-1</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1763-2">
   <w.rf>
    <LM>w#w-d1t1763-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1763-3">
   <w.rf>
    <LM>w#w-d1t1763-3</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1763-4">
   <w.rf>
    <LM>w#w-d1t1763-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1763-5">
   <w.rf>
    <LM>w#w-d1t1763-5</LM>
   </w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m784-d1t1763-6">
   <w.rf>
    <LM>w#w-d1t1763-6</LM>
   </w.rf>
   <form>organizacích</form>
   <lemma>organizace</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m784-d1t1763-7">
   <w.rf>
    <LM>w#w-d1t1763-7</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1e1758-x2-1513">
   <w.rf>
    <LM>w#w-d1e1758-x2-1513</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1758-x2-1514">
   <w.rf>
    <LM>w#w-d1e1758-x2-1514</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e1758-x2-1515">
   <w.rf>
    <LM>w#w-d1e1758-x2-1515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1520">
  <m id="m784-1520-1521">
   <w.rf>
    <LM>w#w-1520-1521</LM>
   </w.rf>
   <form>Sektářství</form>
   <lemma>sektářství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-1520-1522">
   <w.rf>
    <LM>w#w-1520-1522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1516">
  <m id="m784-1516-1517">
   <w.rf>
    <LM>w#w-1516-1517</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-1516-1518">
   <w.rf>
    <LM>w#w-1516-1518</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-1516-1519">
   <w.rf>
    <LM>w#w-1516-1519</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1765-1">
   <w.rf>
    <LM>w#w-d1t1765-1</LM>
   </w.rf>
   <form>značný</form>
   <lemma>značný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m784-d1t1765-2">
   <w.rf>
    <LM>w#w-d1t1765-2</LM>
   </w.rf>
   <form>rozdíl</form>
   <lemma>rozdíl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t1765-3">
   <w.rf>
    <LM>w#w-d1t1765-3</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1765-4">
   <w.rf>
    <LM>w#w-d1t1765-4</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m784-d1e1758-x2-4636">
   <w.rf>
    <LM>w#w-d1e1758-x2-4636</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1765-5">
   <w.rf>
    <LM>w#w-d1t1765-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m784-d1t1772-1">
   <w.rf>
    <LM>w#w-d1t1772-1</LM>
   </w.rf>
   <form>pasivně</form>
   <lemma>pasivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1772-3">
   <w.rf>
    <LM>w#w-d1t1772-3</LM>
   </w.rf>
   <form>trpěli</form>
   <lemma>trpět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1e1758-x2-4639">
   <w.rf>
    <LM>w#w-d1e1758-x2-4639</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1772-4">
   <w.rf>
    <LM>w#w-d1t1772-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1772-5">
   <w.rf>
    <LM>w#w-d1t1772-5</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t1772-6">
   <w.rf>
    <LM>w#w-d1t1772-6</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m784-d1e1758-x2-4640">
   <w.rf>
    <LM>w#w-d1e1758-x2-4640</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1772-7">
   <w.rf>
    <LM>w#w-d1t1772-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m784-d1t1772-8">
   <w.rf>
    <LM>w#w-d1t1772-8</LM>
   </w.rf>
   <form>aktivně</form>
   <lemma>aktivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t1772-9">
   <w.rf>
    <LM>w#w-d1t1772-9</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m784-d1t1772-10">
   <w.rf>
    <LM>w#w-d1t1772-10</LM>
   </w.rf>
   <form>podnikali</form>
   <lemma>podnikat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d-id113942">
   <w.rf>
    <LM>w#w-d-id113942</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1775-x2">
  <m id="m784-d1t1780-1">
   <w.rf>
    <LM>w#w-d1t1780-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e1775-x2-4724">
   <w.rf>
    <LM>w#w-d1e1775-x2-4724</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1780-2">
   <w.rf>
    <LM>w#w-d1t1780-2</LM>
   </w.rf>
   <form>stává</form>
   <lemma>stávat-2_^(*5t-2)_(*5t-3)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1780-3">
   <w.rf>
    <LM>w#w-d1t1780-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1780-4">
   <w.rf>
    <LM>w#w-d1t1780-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1e1775-x2-1532">
   <w.rf>
    <LM>w#w-d1e1775-x2-1532</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1533">
  <m id="m784-d1t1780-5">
   <w.rf>
    <LM>w#w-d1t1780-5</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1780-6">
   <w.rf>
    <LM>w#w-d1t1780-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1780-7">
   <w.rf>
    <LM>w#w-d1t1780-7</LM>
   </w.rf>
   <form>organizaci</form>
   <lemma>organizace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t1780-8">
   <w.rf>
    <LM>w#w-d1t1780-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1780-9">
   <w.rf>
    <LM>w#w-d1t1780-9</LM>
   </w.rf>
   <form>Chrudimi</form>
   <lemma>Chrudim_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d-id114173">
   <w.rf>
    <LM>w#w-d-id114173</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1780-11">
   <w.rf>
    <LM>w#w-d1t1780-11</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1782-2">
   <w.rf>
    <LM>w#w-d1t1782-2</LM>
   </w.rf>
   <form>působím</form>
   <lemma>působit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d-id114237">
   <w.rf>
    <LM>w#w-d-id114237</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1782-6">
   <w.rf>
    <LM>w#w-d1t1782-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t1782-7">
   <w.rf>
    <LM>w#w-d1t1782-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t1782-8">
   <w.rf>
    <LM>w#w-d1t1782-8</LM>
   </w.rf>
   <form>nevyskytuje</form>
   <lemma>vyskytovat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m784-d1e1775-x2-4728">
   <w.rf>
    <LM>w#w-d1e1775-x2-4728</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4729">
  <m id="m784-d1t1782-10">
   <w.rf>
    <LM>w#w-d1t1782-10</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1784-2">
   <w.rf>
    <LM>w#w-d1t1784-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1784-4">
   <w.rf>
    <LM>w#w-d1t1784-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t1784-5">
   <w.rf>
    <LM>w#w-d1t1784-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d1t1784-3">
   <w.rf>
    <LM>w#w-d1t1784-3</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m784-d1t1784-6">
   <w.rf>
    <LM>w#w-d1t1784-6</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1784-7">
   <w.rf>
    <LM>w#w-d1t1784-7</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d-id114495">
   <w.rf>
    <LM>w#w-d-id114495</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1785-x2">
  <m id="m784-d1t1788-1">
   <w.rf>
    <LM>w#w-d1t1788-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t1788-2">
   <w.rf>
    <LM>w#w-d1t1788-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t1788-3">
   <w.rf>
    <LM>w#w-d1t1788-3</LM>
   </w.rf>
   <form>poskytl</form>
   <lemma>poskytnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m784-d1t1788-4">
   <w.rf>
    <LM>w#w-d1t1788-4</LM>
   </w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m784-d1t1788-5">
   <w.rf>
    <LM>w#w-d1t1788-5</LM>
   </w.rf>
   <form>rozhovor</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id114624">
   <w.rf>
    <LM>w#w-d-id114624</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e1789-x2">
  <m id="m784-d1t1798-1">
   <w.rf>
    <LM>w#w-d1t1798-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t1798-3">
   <w.rf>
    <LM>w#w-d1t1798-3</LM>
   </w.rf>
   <form>dojem</form>
   <lemma>dojem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id114763">
   <w.rf>
    <LM>w#w-d-id114763</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1798-5">
   <w.rf>
    <LM>w#w-d1t1798-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t1800-2">
   <w.rf>
    <LM>w#w-d1t1800-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m784-d1t1800-1">
   <w.rf>
    <LM>w#w-d1t1800-1</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m784-d1t1800-3">
   <w.rf>
    <LM>w#w-d1t1800-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id114843">
   <w.rf>
    <LM>w#w-d-id114843</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t1803-1">
   <w.rf>
    <LM>w#w-d1t1803-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1803-2">
   <w.rf>
    <LM>w#w-d1t1803-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1803-3">
   <w.rf>
    <LM>w#w-d1t1803-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t1803-4">
   <w.rf>
    <LM>w#w-d1t1803-4</LM>
   </w.rf>
   <form>málo</form>
   <lemma>málo-2_^(to_málo_co_měl)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t1805-1">
   <w.rf>
    <LM>w#w-d1t1805-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t1805-2">
   <w.rf>
    <LM>w#w-d1t1805-2</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t1805-3">
   <w.rf>
    <LM>w#w-d1t1805-3</LM>
   </w.rf>
   <form>vhodné</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1t1807-1">
   <w.rf>
    <LM>w#w-d1t1807-1</LM>
   </w.rf>
   <form>některým</form>
   <lemma>některý</lemma>
   <tag>PZXP3----------</tag>
  </m>
  <m id="m784-d1t1807-2">
   <w.rf>
    <LM>w#w-d1t1807-2</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m784-d1t1807-5">
   <w.rf>
    <LM>w#w-d1t1807-5</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1809-3">
   <w.rf>
    <LM>w#w-d1t1809-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t1809-4">
   <w.rf>
    <LM>w#w-d1t1809-4</LM>
   </w.rf>
   <form>dospělým</form>
   <lemma>dospělý-2</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m784-d1t1807-4">
   <w.rf>
    <LM>w#w-d1t1807-4</LM>
   </w.rf>
   <form>přednést</form>
   <lemma>přednést</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d-id115168">
   <w.rf>
    <LM>w#w-d-id115168</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
