<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_051.03.w.gz" />
  </references>
 </head>
 <s id="m051-102">
  <m id="m051-d1t1156-1">
   <w.rf>
    <LM>w#w-d1t1156-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1156-2">
   <w.rf>
    <LM>w#w-d1t1156-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1156-3">
   <w.rf>
    <LM>w#w-d1t1156-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1158-1">
   <w.rf>
    <LM>w#w-d1t1158-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1156-4">
   <w.rf>
    <LM>w#w-d1t1156-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1156-5">
   <w.rf>
    <LM>w#w-d1t1156-5</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m051-d1t1156-6">
   <w.rf>
    <LM>w#w-d1t1156-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1147-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1147-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1162-x3">
  <m id="m051-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>Házená</form>
   <lemma>házená_^(sport)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m051-d1t1171-2">
   <w.rf>
    <LM>w#w-d1t1171-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1171-3">
   <w.rf>
    <LM>w#w-d1t1171-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1171-4">
   <w.rf>
    <LM>w#w-d1t1171-4</LM>
   </w.rf>
   <form>tvrdý</form>
   <lemma>tvrdý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m051-d1t1171-5">
   <w.rf>
    <LM>w#w-d1t1171-5</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m051-d-id82004-punct">
   <w.rf>
    <LM>w#w-d-id82004-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1171-7">
   <w.rf>
    <LM>w#w-d1t1171-7</LM>
   </w.rf>
   <form>viďte</form>
   <lemma>viďte</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1e1162-x3-105">
   <w.rf>
    <LM>w#w-d1e1162-x3-105</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1172-x2">
  <m id="m051-d1t1175-1">
   <w.rf>
    <LM>w#w-d1t1175-1</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1e1172-x2-108">
   <w.rf>
    <LM>w#w-d1e1172-x2-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-109">
  <m id="m051-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>Neřekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m051-d1t1175-5">
   <w.rf>
    <LM>w#w-d1t1175-5</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m051-d1t1175-3">
   <w.rf>
    <LM>w#w-d1t1175-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d-id82152-punct">
   <w.rf>
    <LM>w#w-d-id82152-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1175-7">
   <w.rf>
    <LM>w#w-d1t1175-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1177-1">
   <w.rf>
    <LM>w#w-d1t1177-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1177-2">
   <w.rf>
    <LM>w#w-d1t1177-2</LM>
   </w.rf>
   <form>tehdejší</form>
   <lemma>tehdejší</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m051-d1t1177-3">
   <w.rf>
    <LM>w#w-d1t1177-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d1t1177-5">
   <w.rf>
    <LM>w#w-d1t1177-5</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m051-d1t1177-4">
   <w.rf>
    <LM>w#w-d1t1177-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1177-6">
   <w.rf>
    <LM>w#w-d1t1177-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1177-7">
   <w.rf>
    <LM>w#w-d1t1177-7</LM>
   </w.rf>
   <form>tvrdý</form>
   <lemma>tvrdý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m051-d1t1177-8">
   <w.rf>
    <LM>w#w-d1t1177-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1177-9">
   <w.rf>
    <LM>w#w-d1t1177-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1177-10">
   <w.rf>
    <LM>w#w-d1t1177-10</LM>
   </w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m051-d1t1177-11">
   <w.rf>
    <LM>w#w-d1t1177-11</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-109-110">
   <w.rf>
    <LM>w#w-109-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-111">
  <m id="m051-111-278">
   <w.rf>
    <LM>w#w-111-278</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-111-279">
   <w.rf>
    <LM>w#w-111-279</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m051-111-280">
   <w.rf>
    <LM>w#w-111-280</LM>
   </w.rf>
   <form>straně</form>
   <lemma>strana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d1t1186-3">
   <w.rf>
    <LM>w#w-d1t1186-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1186-1">
   <w.rf>
    <LM>w#w-d1t1186-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1183-1">
   <w.rf>
    <LM>w#w-d1t1183-1</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1183-3">
   <w.rf>
    <LM>w#w-d1t1183-3</LM>
   </w.rf>
   <form>dívkami</form>
   <lemma>dívka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m051-d1t1186-2">
   <w.rf>
    <LM>w#w-d1t1186-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1186-4">
   <w.rf>
    <LM>w#w-d1t1186-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1186-5">
   <w.rf>
    <LM>w#w-d1t1186-5</LM>
   </w.rf>
   <form>tvrdé</form>
   <lemma>tvrdý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m051-d1t1186-7">
   <w.rf>
    <LM>w#w-d1t1186-7</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m051-111-116">
   <w.rf>
    <LM>w#w-111-116</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1195-1">
   <w.rf>
    <LM>w#w-d1t1195-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1197-1">
   <w.rf>
    <LM>w#w-d1t1197-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1197-2">
   <w.rf>
    <LM>w#w-d1t1197-2</LM>
   </w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d-m-d1e1190-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1190-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1190-x3">
  <m id="m051-d1t1199-1">
   <w.rf>
    <LM>w#w-d1t1199-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m051-d1t1199-2">
   <w.rf>
    <LM>w#w-d1t1199-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1199-3">
   <w.rf>
    <LM>w#w-d1t1199-3</LM>
   </w.rf>
   <form>změnilo</form>
   <lemma>změnit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m051-d-id82874-punct">
   <w.rf>
    <LM>w#w-d-id82874-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1190-x4">
  <m id="m051-d1t1208-1">
   <w.rf>
    <LM>w#w-d1t1208-1</LM>
   </w.rf>
   <form>Změnil</form>
   <lemma>změnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m051-d1t1208-2">
   <w.rf>
    <LM>w#w-d1t1208-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1e1190-x4-123">
   <w.rf>
    <LM>w#w-d1e1190-x4-123</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1208-3">
   <w.rf>
    <LM>w#w-d1t1208-3</LM>
   </w.rf>
   <form>tah</form>
   <lemma>tah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m051-d1e1190-x4-122">
   <w.rf>
    <LM>w#w-d1e1190-x4-122</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1210-1">
   <w.rf>
    <LM>w#w-d1t1210-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1210-2">
   <w.rf>
    <LM>w#w-d1t1210-2</LM>
   </w.rf>
   <form>úspěchu</form>
   <lemma>úspěch</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m051-d1e1190-x4-119">
   <w.rf>
    <LM>w#w-d1e1190-x4-119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-121">
  <m id="m051-d1t1212-3">
   <w.rf>
    <LM>w#w-d1t1212-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1212-2">
   <w.rf>
    <LM>w#w-d1t1212-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1212-1">
   <w.rf>
    <LM>w#w-d1t1212-1</LM>
   </w.rf>
   <form>mění</form>
   <lemma>měnit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1212-4">
   <w.rf>
    <LM>w#w-d1t1212-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m051-d1t1212-5">
   <w.rf>
    <LM>w#w-d1t1212-5</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m051-d1t1212-6">
   <w.rf>
    <LM>w#w-d1t1212-6</LM>
   </w.rf>
   <form>sportech</form>
   <lemma>sport</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1190-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1190-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1220-x2">
  <m id="m051-d1t1223-3">
   <w.rf>
    <LM>w#w-d1t1223-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1223-2">
   <w.rf>
    <LM>w#w-d1t1223-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1223-4">
   <w.rf>
    <LM>w#w-d1t1223-4</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1223-5">
   <w.rf>
    <LM>w#w-d1t1223-5</LM>
   </w.rf>
   <form>dáno</form>
   <lemma>dát-1</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m051-d1e1220-x2-128">
   <w.rf>
    <LM>w#w-d1e1220-x2-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-129">
  <m id="m051-d1t1225-2">
   <w.rf>
    <LM>w#w-d1t1225-2</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d-id83321-punct">
   <w.rf>
    <LM>w#w-d-id83321-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1225-4">
   <w.rf>
    <LM>w#w-d1t1225-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1225-5">
   <w.rf>
    <LM>w#w-d1t1225-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m051-d1t1225-6">
   <w.rf>
    <LM>w#w-d1t1225-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1227-1">
   <w.rf>
    <LM>w#w-d1t1227-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1227-3">
   <w.rf>
    <LM>w#w-d1t1227-3</LM>
   </w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m051-d1t1225-7">
   <w.rf>
    <LM>w#w-d1t1225-7</LM>
   </w.rf>
   <form>prožila</form>
   <lemma>prožít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m051-d1t1227-4">
   <w.rf>
    <LM>w#w-d1t1227-4</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1227-5">
   <w.rf>
    <LM>w#w-d1t1227-5</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m051-d1t1227-6">
   <w.rf>
    <LM>w#w-d1t1227-6</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m051-d1t1229-1">
   <w.rf>
    <LM>w#w-d1t1229-1</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1229-3">
   <w.rf>
    <LM>w#w-d1t1229-3</LM>
   </w.rf>
   <form>přílišné</form>
   <lemma>přílišný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m051-d1t1229-4">
   <w.rf>
    <LM>w#w-d1t1229-4</LM>
   </w.rf>
   <form>tvrdosti</form>
   <lemma>tvrdost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1220-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1220-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1230-x2">
  <m id="m051-d1t1233-1">
   <w.rf>
    <LM>w#w-d1t1233-1</LM>
   </w.rf>
   <form>Jakou</form>
   <lemma>jaký</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m051-d1t1233-2">
   <w.rf>
    <LM>w#w-d1t1233-2</LM>
   </w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-d1t1233-3">
   <w.rf>
    <LM>w#w-d1t1233-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m051-d1t1233-4">
   <w.rf>
    <LM>w#w-d1t1233-4</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d-id83669-punct">
   <w.rf>
    <LM>w#w-d-id83669-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1234-x2">
  <m id="m051-d1t1243-1">
   <w.rf>
    <LM>w#w-d1t1243-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1243-2">
   <w.rf>
    <LM>w#w-d1t1243-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1243-4">
   <w.rf>
    <LM>w#w-d1t1243-4</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d1t1248-1">
   <w.rf>
    <LM>w#w-d1t1248-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1248-2">
   <w.rf>
    <LM>w#w-d1t1248-2</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1256-2">
   <w.rf>
    <LM>w#w-d1t1256-2</LM>
   </w.rf>
   <form>napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1256-4">
   <w.rf>
    <LM>w#w-d1t1256-4</LM>
   </w.rf>
   <form>dorosteneckou</form>
   <lemma>dorostenecký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m051-d1e1251-x2-142">
   <w.rf>
    <LM>w#w-d1e1251-x2-142</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1256-7">
   <w.rf>
    <LM>w#w-d1t1256-7</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1256-8">
   <w.rf>
    <LM>w#w-d1t1256-8</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m051-d1t1256-9">
   <w.rf>
    <LM>w#w-d1t1256-9</LM>
   </w.rf>
   <form>ligu</form>
   <lemma>liga</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-d1e1251-x2-143">
   <w.rf>
    <LM>w#w-d1e1251-x2-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-144">
  <m id="m051-d1t1258-1">
   <w.rf>
    <LM>w#w-d1t1258-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1262-3">
   <w.rf>
    <LM>w#w-d1t1262-3</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1262-2">
   <w.rf>
    <LM>w#w-d1t1262-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1262-4">
   <w.rf>
    <LM>w#w-d1t1262-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1267-1">
   <w.rf>
    <LM>w#w-d1t1267-1</LM>
   </w.rf>
   <form>dorostenecké</form>
   <lemma>dorostenecký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m051-d1t1267-2">
   <w.rf>
    <LM>w#w-d1t1267-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1267-3">
   <w.rf>
    <LM>w#w-d1t1267-3</LM>
   </w.rf>
   <form>juniorské</form>
   <lemma>juniorský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m051-d1t1267-4">
   <w.rf>
    <LM>w#w-d1t1267-4</LM>
   </w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m051-d1t1267-5">
   <w.rf>
    <LM>w#w-d1t1267-5</LM>
   </w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1251-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1251-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1272-x2">
  <m id="m051-d1t1277-3">
   <w.rf>
    <LM>w#w-d1t1277-3</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1277-1">
   <w.rf>
    <LM>w#w-d1t1277-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1277-2">
   <w.rf>
    <LM>w#w-d1t1277-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m051-d1t1279-1">
   <w.rf>
    <LM>w#w-d1t1279-1</LM>
   </w.rf>
   <form>zahrála</form>
   <lemma>zahrát</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m051-d-m-d1e1272-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1272-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1287-x2">
  <m id="m051-d1t1290-1">
   <w.rf>
    <LM>w#w-d1t1290-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1290-2">
   <w.rf>
    <LM>w#w-d1t1290-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m051-d1t1290-3">
   <w.rf>
    <LM>w#w-d1t1290-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1290-5">
   <w.rf>
    <LM>w#w-d1t1290-5</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m051-d-m-d1e1287-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1287-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1291-x2">
  <m id="m051-d1t1298-1">
   <w.rf>
    <LM>w#w-d1t1298-1</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m051-d1t1298-2">
   <w.rf>
    <LM>w#w-d1t1298-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1298-3">
   <w.rf>
    <LM>w#w-d1t1298-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m051-d-id84715-punct">
   <w.rf>
    <LM>w#w-d-id84715-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1298-5">
   <w.rf>
    <LM>w#w-d1t1298-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1300-2">
   <w.rf>
    <LM>w#w-d1t1300-2</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m051-d-m-d1e1291-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1291-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1306-x2">
  <m id="m051-d1t1311-4">
   <w.rf>
    <LM>w#w-d1t1311-4</LM>
   </w.rf>
   <form>Neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m051-d1t1311-2">
   <w.rf>
    <LM>w#w-d1t1311-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1311-3">
   <w.rf>
    <LM>w#w-d1t1311-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m051-d1t1311-5">
   <w.rf>
    <LM>w#w-d1t1311-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1311-6">
   <w.rf>
    <LM>w#w-d1t1311-6</LM>
   </w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1306-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1306-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1306-x3">
  <m id="m051-d1t1313-1">
   <w.rf>
    <LM>w#w-d1t1313-1</LM>
   </w.rf>
   <form>Cestovali</form>
   <lemma>cestovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1313-2">
   <w.rf>
    <LM>w#w-d1t1313-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m051-d1t1313-3">
   <w.rf>
    <LM>w#w-d1t1313-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1313-4">
   <w.rf>
    <LM>w#w-d1t1313-4</LM>
   </w.rf>
   <form>zápasy</form>
   <lemma>zápas</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m051-d1t1313-5">
   <w.rf>
    <LM>w#w-d1t1313-5</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1313-6">
   <w.rf>
    <LM>w#w-d1t1313-6</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d-id85023-punct">
   <w.rf>
    <LM>w#w-d-id85023-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1314-x2">
  <m id="m051-d1t1328-1">
   <w.rf>
    <LM>w#w-d1t1328-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1328-3">
   <w.rf>
    <LM>w#w-d1t1328-3</LM>
   </w.rf>
   <form>národním</form>
   <lemma>národní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m051-d1t1328-4">
   <w.rf>
    <LM>w#w-d1t1328-4</LM>
   </w.rf>
   <form>družstvem</form>
   <lemma>družstvo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m051-d1t1321-2">
   <w.rf>
    <LM>w#w-d1t1321-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1321-1">
   <w.rf>
    <LM>w#w-d1t1321-1</LM>
   </w.rf>
   <form>cestovali</form>
   <lemma>cestovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1328-5">
   <w.rf>
    <LM>w#w-d1t1328-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1328-7">
   <w.rf>
    <LM>w#w-d1t1328-7</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d1e1314-x2-168">
   <w.rf>
    <LM>w#w-d1e1314-x2-168</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-169">
  <m id="m051-d1t1330-1">
   <w.rf>
    <LM>w#w-d1t1330-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1332-1">
   <w.rf>
    <LM>w#w-d1t1332-1</LM>
   </w.rf>
   <form>družstvem</form>
   <lemma>družstvo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m051-d1t1332-2">
   <w.rf>
    <LM>w#w-d1t1332-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1336-1">
   <w.rf>
    <LM>w#w-d1t1336-1</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-169-170">
   <w.rf>
    <LM>w#w-169-170</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-171">
  <m id="m051-d1t1341-2">
   <w.rf>
    <LM>w#w-d1t1341-2</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m051-d1t1341-1">
   <w.rf>
    <LM>w#w-d1t1341-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1341-3">
   <w.rf>
    <LM>w#w-d1t1341-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m051-d-id85594-punct">
   <w.rf>
    <LM>w#w-d-id85594-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1341-5">
   <w.rf>
    <LM>w#w-d1t1341-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1336-5">
   <w.rf>
    <LM>w#w-d1t1336-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1336-7">
   <w.rf>
    <LM>w#w-d1t1336-7</LM>
   </w.rf>
   <form>šedesátých</form>
   <lemma>šedesátý</lemma>
   <tag>CrNP6----------</tag>
  </m>
  <m id="m051-d1t1336-8">
   <w.rf>
    <LM>w#w-d1t1336-8</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m051-d1t1343-3">
   <w.rf>
    <LM>w#w-d1t1343-3</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m051-d1t1343-2">
   <w.rf>
    <LM>w#w-d1t1343-2</LM>
   </w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m051-d1t1343-4">
   <w.rf>
    <LM>w#w-d1t1343-4</LM>
   </w.rf>
   <form>uzavřené</form>
   <lemma>uzavřený_^(*3ít)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m051-171-172">
   <w.rf>
    <LM>w#w-171-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-173">
  <m id="m051-d1t1347-1">
   <w.rf>
    <LM>w#w-d1t1347-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1347-2">
   <w.rf>
    <LM>w#w-d1t1347-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1347-3">
   <w.rf>
    <LM>w#w-d1t1347-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1349-1">
   <w.rf>
    <LM>w#w-d1t1349-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1349-3">
   <w.rf>
    <LM>w#w-d1t1349-3</LM>
   </w.rf>
   <form>Západního</form>
   <lemma>západní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m051-d1t1349-4">
   <w.rf>
    <LM>w#w-d1t1349-4</LM>
   </w.rf>
   <form>Německa</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m051-d-id85832-punct">
   <w.rf>
    <LM>w#w-d-id85832-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1354-3">
   <w.rf>
    <LM>w#w-d1t1354-3</LM>
   </w.rf>
   <form>Belgie</form>
   <lemma>Belgie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m051-173-174">
   <w.rf>
    <LM>w#w-173-174</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1358-1">
   <w.rf>
    <LM>w#w-d1t1358-1</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1358-2">
   <w.rf>
    <LM>w#w-d1t1358-2</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1358-3">
   <w.rf>
    <LM>w#w-d1t1358-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1358-4">
   <w.rf>
    <LM>w#w-d1t1358-4</LM>
   </w.rf>
   <form>východ</form>
   <lemma>východ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d1t1358-5">
   <w.rf>
    <LM>w#w-d1t1358-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1358-7">
   <w.rf>
    <LM>w#w-d1t1358-7</LM>
   </w.rf>
   <form>Bulharska</form>
   <lemma>Bulharsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m051-173-192">
   <w.rf>
    <LM>w#w-173-192</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1360-5">
   <w.rf>
    <LM>w#w-d1t1360-5</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-173-195">
   <w.rf>
    <LM>w#w-173-195</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1360-3">
   <w.rf>
    <LM>w#w-d1t1360-3</LM>
   </w.rf>
   <form>Jugoslávie</form>
   <lemma>Jugoslávie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m051-d1e1314-x3-193">
   <w.rf>
    <LM>w#w-d1e1314-x3-193</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-194">
  <m id="m051-d1t1367-3">
   <w.rf>
    <LM>w#w-d1t1367-3</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1367-1">
   <w.rf>
    <LM>w#w-d1t1367-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1367-2">
   <w.rf>
    <LM>w#w-d1t1367-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m051-d1t1367-4">
   <w.rf>
    <LM>w#w-d1t1367-4</LM>
   </w.rf>
   <form>zpestřené</form>
   <lemma>zpestřený_^(*2t)_(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m051-d-m-d1e1314-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1314-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1368-x2">
  <m id="m051-d1t1373-1">
   <w.rf>
    <LM>w#w-d1t1373-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1373-2">
   <w.rf>
    <LM>w#w-d1t1373-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m051-d-m-d1e1368-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1368-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1375-x2">
  <m id="m051-d1t1378-1">
   <w.rf>
    <LM>w#w-d1t1378-1</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d-m-d1e1375-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1375-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1379-x2">
  <m id="m051-d1t1382-1">
   <w.rf>
    <LM>w#w-d1t1382-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m051-d1t1382-2">
   <w.rf>
    <LM>w#w-d1t1382-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m051-d1t1382-3">
   <w.rf>
    <LM>w#w-d1t1382-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1382-4">
   <w.rf>
    <LM>w#w-d1t1382-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m051-d1t1382-5">
   <w.rf>
    <LM>w#w-d1t1382-5</LM>
   </w.rf>
   <form>příhodu</form>
   <lemma>příhoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-d1t1382-6">
   <w.rf>
    <LM>w#w-d1t1382-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1382-7">
   <w.rf>
    <LM>w#w-d1t1382-7</LM>
   </w.rf>
   <form>cest</form>
   <lemma>cesta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m051-d1t1382-8">
   <w.rf>
    <LM>w#w-d1t1382-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1382-9">
   <w.rf>
    <LM>w#w-d1t1382-9</LM>
   </w.rf>
   <form>zápasy</form>
   <lemma>zápas</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m051-d-id86606-punct">
   <w.rf>
    <LM>w#w-d-id86606-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1383-x2">
  <m id="m051-d1t1388-1">
   <w.rf>
    <LM>w#w-d1t1388-1</LM>
   </w.rf>
   <form>Těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m051-d1t1388-2">
   <w.rf>
    <LM>w#w-d1t1388-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1388-3">
   <w.rf>
    <LM>w#w-d1t1388-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1e1383-x2-215">
   <w.rf>
    <LM>w#w-d1e1383-x2-215</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-216">
  <m id="m051-d1t1394-6">
   <w.rf>
    <LM>w#w-d1t1394-6</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m051-d1t1394-5">
   <w.rf>
    <LM>w#w-d1t1394-5</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m051-d1t1394-2">
   <w.rf>
    <LM>w#w-d1t1394-2</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1394-7">
   <w.rf>
    <LM>w#w-d1t1394-7</LM>
   </w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m051-d-id86875-punct">
   <w.rf>
    <LM>w#w-d-id86875-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1394-4">
   <w.rf>
    <LM>w#w-d1t1394-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1399-1">
   <w.rf>
    <LM>w#w-d1t1399-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1399-2">
   <w.rf>
    <LM>w#w-d1t1399-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1399-3">
   <w.rf>
    <LM>w#w-d1t1399-3</LM>
   </w.rf>
   <form>cestovali</form>
   <lemma>cestovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-216-217">
   <w.rf>
    <LM>w#w-216-217</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1399-4">
   <w.rf>
    <LM>w#w-d1t1399-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1405-2">
   <w.rf>
    <LM>w#w-d1t1405-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1405-1">
   <w.rf>
    <LM>w#w-d1t1405-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1405-4">
   <w.rf>
    <LM>w#w-d1t1405-4</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1405-3">
   <w.rf>
    <LM>w#w-d1t1405-3</LM>
   </w.rf>
   <form>spojeno</form>
   <lemma>spojit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m051-d1t1405-5">
   <w.rf>
    <LM>w#w-d1t1405-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1405-7">
   <w.rf>
    <LM>w#w-d1t1405-7</LM>
   </w.rf>
   <form>přijetím</form>
   <lemma>přijetí_^(*1)_(*3mout)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m051-d1t1405-9">
   <w.rf>
    <LM>w#w-d1t1405-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1405-10">
   <w.rf>
    <LM>w#w-d1t1405-10</LM>
   </w.rf>
   <form>radnici</form>
   <lemma>radnice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-216-218">
   <w.rf>
    <LM>w#w-216-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-219">
  <m id="m051-d1t1407-1">
   <w.rf>
    <LM>w#w-d1t1407-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1407-2">
   <w.rf>
    <LM>w#w-d1t1407-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m051-d1t1407-3">
   <w.rf>
    <LM>w#w-d1t1407-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m051-d1t1407-4">
   <w.rf>
    <LM>w#w-d1t1407-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1t1407-5">
   <w.rf>
    <LM>w#w-d1t1407-5</LM>
   </w.rf>
   <form>potrpěli</form>
   <lemma>potrpět</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m051-d1t1407-7">
   <w.rf>
    <LM>w#w-d1t1407-7</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m051-d1t1410-1">
   <w.rf>
    <LM>w#w-d1t1410-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1410-2">
   <w.rf>
    <LM>w#w-d1t1410-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1410-3">
   <w.rf>
    <LM>w#w-d1t1410-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1410-6">
   <w.rf>
    <LM>w#w-d1t1410-6</LM>
   </w.rf>
   <form>Belgii</form>
   <lemma>Belgie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-219-220">
   <w.rf>
    <LM>w#w-219-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-221">
  <m id="m051-d1t1414-3">
   <w.rf>
    <LM>w#w-d1t1414-3</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1414-2">
   <w.rf>
    <LM>w#w-d1t1414-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1414-4">
   <w.rf>
    <LM>w#w-d1t1414-4</LM>
   </w.rf>
   <form>prohlídky</form>
   <lemma>prohlídka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m051-d1t1414-5">
   <w.rf>
    <LM>w#w-d1t1414-5</LM>
   </w.rf>
   <form>měst</form>
   <lemma>město</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m051-221-222">
   <w.rf>
    <LM>w#w-221-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-223">
  <m id="m051-d1t1418-1">
   <w.rf>
    <LM>w#w-d1t1418-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1418-2">
   <w.rf>
    <LM>w#w-d1t1418-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1418-3">
   <w.rf>
    <LM>w#w-d1t1418-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m051-223-224">
   <w.rf>
    <LM>w#w-223-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-225">
  <m id="m051-d1t1423-1">
   <w.rf>
    <LM>w#w-d1t1423-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1423-2">
   <w.rf>
    <LM>w#w-d1t1423-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1423-3">
   <w.rf>
    <LM>w#w-d1t1423-3</LM>
   </w.rf>
   <form>poznávání</form>
   <lemma>poznávání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m051-225-226">
   <w.rf>
    <LM>w#w-225-226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-227">
  <m id="m051-d1t1425-1">
   <w.rf>
    <LM>w#w-d1t1425-1</LM>
   </w.rf>
   <form>Nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1425-2">
   <w.rf>
    <LM>w#w-d1t1425-2</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m051-d1t1425-3">
   <w.rf>
    <LM>w#w-d1t1425-3</LM>
   </w.rf>
   <form>příhoda</form>
   <lemma>příhoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m051-d1t1427-3">
   <w.rf>
    <LM>w#w-d1t1427-3</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1t1427-4">
   <w.rf>
    <LM>w#w-d1t1427-4</LM>
   </w.rf>
   <form>odjinud</form>
   <lemma>odjinud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-232-233">
   <w.rf>
    <LM>w#w-232-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-234">
  <m id="m051-d1t1431-1">
   <w.rf>
    <LM>w#w-d1t1431-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1431-2">
   <w.rf>
    <LM>w#w-d1t1431-2</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m051-d1t1431-3">
   <w.rf>
    <LM>w#w-d1t1431-3</LM>
   </w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m051-d1t1431-4">
   <w.rf>
    <LM>w#w-d1t1431-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1431-5">
   <w.rf>
    <LM>w#w-d1t1431-5</LM>
   </w.rf>
   <form>házenou</form>
   <lemma>házená_^(sport)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m051-234-235">
   <w.rf>
    <LM>w#w-234-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-236">
  <m id="m051-d1t1431-10">
   <w.rf>
    <LM>w#w-d1t1431-10</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1431-8">
   <w.rf>
    <LM>w#w-d1t1431-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1431-9">
   <w.rf>
    <LM>w#w-d1t1431-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1431-11">
   <w.rf>
    <LM>w#w-d1t1431-11</LM>
   </w.rf>
   <form>atletiku</form>
   <lemma>atletika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-236-238">
   <w.rf>
    <LM>w#w-236-238</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1436-5">
   <w.rf>
    <LM>w#w-d1t1436-5</LM>
   </w.rf>
   <form>házela</form>
   <lemma>házet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1436-6">
   <w.rf>
    <LM>w#w-d1t1436-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1436-7">
   <w.rf>
    <LM>w#w-d1t1436-7</LM>
   </w.rf>
   <form>oštěpem</form>
   <lemma>oštěp</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m051-236-239">
   <w.rf>
    <LM>w#w-236-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-240">
  <m id="m051-d1t1436-9">
   <w.rf>
    <LM>w#w-d1t1436-9</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1436-10">
   <w.rf>
    <LM>w#w-d1t1436-10</LM>
   </w.rf>
   <form>jedněch</form>
   <lemma>jedny`1</lemma>
   <tag>CdXP6----------</tag>
  </m>
  <m id="m051-d1t1436-11">
   <w.rf>
    <LM>w#w-d1t1436-11</LM>
   </w.rf>
   <form>závodech</form>
   <lemma>závod</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m051-d1t1438-1">
   <w.rf>
    <LM>w#w-d1t1438-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1438-3">
   <w.rf>
    <LM>w#w-d1t1438-3</LM>
   </w.rf>
   <form>Bulharsku</form>
   <lemma>Bulharsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m051-d1t1438-5">
   <w.rf>
    <LM>w#w-d1t1438-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1440-1">
   <w.rf>
    <LM>w#w-d1t1440-1</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m051-d1t1440-2">
   <w.rf>
    <LM>w#w-d1t1440-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>můj</lemma>
   <tag>PSFS1-S1------1</tag>
  </m>
  <m id="m051-d1t1440-3">
   <w.rf>
    <LM>w#w-d1t1440-3</LM>
   </w.rf>
   <form>kolegyně</form>
   <lemma>kolegyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m051-d1t1442-1">
   <w.rf>
    <LM>w#w-d1t1442-1</LM>
   </w.rf>
   <form>trefila</form>
   <lemma>trefit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1442-2">
   <w.rf>
    <LM>w#w-d1t1442-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1442-3">
   <w.rf>
    <LM>w#w-d1t1442-3</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m051-d1t1442-4">
   <w.rf>
    <LM>w#w-d1t1442-4</LM>
   </w.rf>
   <form>rozhodčího</form>
   <lemma>rozhodčí-1</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m051-240-241">
   <w.rf>
    <LM>w#w-240-241</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-242">
  <m id="m051-d1t1446-2">
   <w.rf>
    <LM>w#w-d1t1446-2</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m051-d1t1446-3">
   <w.rf>
    <LM>w#w-d1t1446-3</LM>
   </w.rf>
   <form>dneška</form>
   <lemma>dnešek</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m051-d1t1446-5">
   <w.rf>
    <LM>w#w-d1t1446-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1446-6">
   <w.rf>
    <LM>w#w-d1t1446-6</LM>
   </w.rf>
   <form>nikomu</form>
   <lemma>nikdo</lemma>
   <tag>PY--3----------</tag>
  </m>
  <m id="m051-242-243">
   <w.rf>
    <LM>w#w-242-243</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m051-d1t1446-7">
   <w.rf>
    <LM>w#w-d1t1446-7</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m051-242-247">
   <w.rf>
    <LM>w#w-242-247</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1455-1">
   <w.rf>
    <LM>w#w-d1t1455-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1455-2">
   <w.rf>
    <LM>w#w-d1t1455-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1455-4">
   <w.rf>
    <LM>w#w-d1t1455-4</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1455-3">
   <w.rf>
    <LM>w#w-d1t1455-3</LM>
   </w.rf>
   <form>úsměvné</form>
   <lemma>úsměvný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m051-d-m-d1e1450-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1450-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1462-x2">
  <m id="m051-d1t1465-2">
   <w.rf>
    <LM>w#w-d1t1465-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1465-3">
   <w.rf>
    <LM>w#w-d1t1465-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1465-4">
   <w.rf>
    <LM>w#w-d1t1465-4</LM>
   </w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m051-d1t1465-5">
   <w.rf>
    <LM>w#w-d1t1465-5</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m051-d-id88781-punct">
   <w.rf>
    <LM>w#w-d-id88781-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1465-7">
   <w.rf>
    <LM>w#w-d1t1465-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1465-8">
   <w.rf>
    <LM>w#w-d1t1465-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1465-10">
   <w.rf>
    <LM>w#w-d1t1465-10</LM>
   </w.rf>
   <form>celek</form>
   <lemma>celek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m051-d1t1465-9">
   <w.rf>
    <LM>w#w-d1t1465-9</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m051-d1e1462-x2-249">
   <w.rf>
    <LM>w#w-d1e1462-x2-249</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-250">
  <m id="m051-250-251">
   <w.rf>
    <LM>w#w-250-251</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1467-2">
   <w.rf>
    <LM>w#w-d1t1467-2</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m051-d1t1467-3">
   <w.rf>
    <LM>w#w-d1t1467-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m051-d1t1467-4">
   <w.rf>
    <LM>w#w-d1t1467-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m051-d1t1467-5">
   <w.rf>
    <LM>w#w-d1t1467-5</LM>
   </w.rf>
   <form>pamatuje</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m051-d1t1467-6">
   <w.rf>
    <LM>w#w-d1t1467-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1467-7">
   <w.rf>
    <LM>w#w-d1t1467-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1467-8">
   <w.rf>
    <LM>w#w-d1t1467-8</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m051-d1t1467-9">
   <w.rf>
    <LM>w#w-d1t1467-9</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1462-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1462-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1470-x2">
  <m id="m051-d1t1475-1">
   <w.rf>
    <LM>w#w-d1t1475-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1475-2">
   <w.rf>
    <LM>w#w-d1t1475-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1475-3">
   <w.rf>
    <LM>w#w-d1t1475-3</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m051-d1t1475-4">
   <w.rf>
    <LM>w#w-d1t1475-4</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léta</lemma>
   <tag>NNNP1-----A---2</tag>
  </m>
  <m id="m051-d-m-d1e1470-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1470-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1470-x3">
  <m id="m051-d1t1481-1">
   <w.rf>
    <LM>w#w-d1t1481-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1481-2">
   <w.rf>
    <LM>w#w-d1t1481-2</LM>
   </w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m051-d1t1481-3">
   <w.rf>
    <LM>w#w-d1t1481-3</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m051-d1t1481-4">
   <w.rf>
    <LM>w#w-d1t1481-4</LM>
   </w.rf>
   <form>zápas</form>
   <lemma>zápas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d1t1481-5">
   <w.rf>
    <LM>w#w-d1t1481-5</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m051-d1t1481-6">
   <w.rf>
    <LM>w#w-d1t1481-6</LM>
   </w.rf>
   <form>vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m051-d-id89207-punct">
   <w.rf>
    <LM>w#w-d-id89207-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1470-x4">
  <m id="m051-d1t1486-3">
   <w.rf>
    <LM>w#w-d1t1486-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1486-4">
   <w.rf>
    <LM>w#w-d1t1486-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m051-d1t1486-5">
   <w.rf>
    <LM>w#w-d1t1486-5</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m051-d1t1486-6">
   <w.rf>
    <LM>w#w-d1t1486-6</LM>
   </w.rf>
   <form>zaskočila</form>
   <lemma>zaskočit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m051-d1e1470-x4-256">
   <w.rf>
    <LM>w#w-d1e1470-x4-256</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-257">
  <m id="m051-d1t1488-4">
   <w.rf>
    <LM>w#w-d1t1488-4</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1488-5">
   <w.rf>
    <LM>w#w-d1t1488-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m051-d1t1488-6">
   <w.rf>
    <LM>w#w-d1t1488-6</LM>
   </w.rf>
   <form>řeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m051-d1t1488-7">
   <w.rf>
    <LM>w#w-d1t1488-7</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-257-343">
   <w.rf>
    <LM>w#w-257-343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-344">
  <m id="m051-d1t1498-3">
   <w.rf>
    <LM>w#w-d1t1498-3</LM>
   </w.rf>
   <form>Nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m051-d1t1498-2">
   <w.rf>
    <LM>w#w-d1t1498-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m051-d1t1498-1">
   <w.rf>
    <LM>w#w-d1t1498-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1498-4">
   <w.rf>
    <LM>w#w-d1t1498-4</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1e1495-x2-340">
   <w.rf>
    <LM>w#w-d1e1495-x2-340</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1498-5">
   <w.rf>
    <LM>w#w-d1t1498-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m051-d1t1498-6">
   <w.rf>
    <LM>w#w-d1t1498-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m051-d1t1498-7">
   <w.rf>
    <LM>w#w-d1t1498-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1498-8">
   <w.rf>
    <LM>w#w-d1t1498-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1498-9">
   <w.rf>
    <LM>w#w-d1t1498-9</LM>
   </w.rf>
   <form>soutěž</form>
   <lemma>soutěž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m051-d1e1495-x2-341">
   <w.rf>
    <LM>w#w-d1e1495-x2-341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-342">
  <m id="m051-d1t1500-2">
   <w.rf>
    <LM>w#w-d1t1500-2</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1500-3">
   <w.rf>
    <LM>w#w-d1t1500-3</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m051-d1t1500-4">
   <w.rf>
    <LM>w#w-d1t1500-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1500-5">
   <w.rf>
    <LM>w#w-d1t1500-5</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m051-342-345">
   <w.rf>
    <LM>w#w-342-345</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1500-8">
   <w.rf>
    <LM>w#w-d1t1500-8</LM>
   </w.rf>
   <form>šestnácti</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m051-d1t1500-9">
   <w.rf>
    <LM>w#w-d1t1500-9</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m051-d1t1500-10">
   <w.rf>
    <LM>w#w-d1t1500-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1500-11">
   <w.rf>
    <LM>w#w-d1t1500-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1500-12">
   <w.rf>
    <LM>w#w-d1t1500-12</LM>
   </w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m051-d1t1500-16">
   <w.rf>
    <LM>w#w-d1t1500-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1500-17">
   <w.rf>
    <LM>w#w-d1t1500-17</LM>
   </w.rf>
   <form>Mistrovství</form>
   <lemma>mistrovství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m051-d1t1500-18">
   <w.rf>
    <LM>w#w-d1t1500-18</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m051-342-346">
   <w.rf>
    <LM>w#w-342-346</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-347">
  <m id="m051-d1t1506-1">
   <w.rf>
    <LM>w#w-d1t1506-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1506-2">
   <w.rf>
    <LM>w#w-d1t1506-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m051-d1t1506-3">
   <w.rf>
    <LM>w#w-d1t1506-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1506-4">
   <w.rf>
    <LM>w#w-d1t1506-4</LM>
   </w.rf>
   <form>přijely</form>
   <lemma>přijet</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m051-d-id90016-punct">
   <w.rf>
    <LM>w#w-d-id90016-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1509-1">
   <w.rf>
    <LM>w#w-d1t1509-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1511-1">
   <w.rf>
    <LM>w#w-d1t1511-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m051-d1t1511-2">
   <w.rf>
    <LM>w#w-d1t1511-2</LM>
   </w.rf>
   <form>zjistilo</form>
   <lemma>zjistit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m051-d-id90089-punct">
   <w.rf>
    <LM>w#w-d-id90089-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1511-4">
   <w.rf>
    <LM>w#w-d1t1511-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1t1511-6">
   <w.rf>
    <LM>w#w-d1t1511-6</LM>
   </w.rf>
   <form>nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m051-d1t1511-7">
   <w.rf>
    <LM>w#w-d1t1511-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>moct</form>
   <lemma>moci</lemma>
   <tag>Vf--------A-I-1</tag>
  </m>
  <m id="m051-d1t1511-8">
   <w.rf>
    <LM>w#w-d1t1511-8</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m051-347-352">
   <w.rf>
    <LM>w#w-347-352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-353">
  <m id="m051-d1t1515-3">
   <w.rf>
    <LM>w#w-d1t1515-3</LM>
   </w.rf>
   <form>Hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1515-2">
   <w.rf>
    <LM>w#w-d1t1515-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m051-353-355">
   <w.rf>
    <LM>w#w-353-355</LM>
   </w.rf>
   <form>totiž</form>
   <lemma>totiž-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1515-4">
   <w.rf>
    <LM>w#w-d1t1515-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m051-d1t1515-6">
   <w.rf>
    <LM>w#w-d1t1515-6</LM>
   </w.rf>
   <form>děvčaty</form>
   <lemma>děvče</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m051-d-id90281-punct">
   <w.rf>
    <LM>w#w-d-id90281-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1515-9">
   <w.rf>
    <LM>w#w-d1t1515-9</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4NP1----------</tag>
  </m>
  <m id="m051-d1t1515-10">
   <w.rf>
    <LM>w#w-d1t1515-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1515-12">
   <w.rf>
    <LM>w#w-d1t1515-12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m051-d1t1515-13">
   <w.rf>
    <LM>w#w-d1t1515-13</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d1t1515-14">
   <w.rf>
    <LM>w#w-d1t1515-14</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1515-16">
   <w.rf>
    <LM>w#w-d1t1515-16</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m051-d1t1515-17">
   <w.rf>
    <LM>w#w-d1t1515-17</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANP1----2A----</tag>
  </m>
  <m id="m051-353-354">
   <w.rf>
    <LM>w#w-353-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-356">
  <m id="m051-d1t1515-19">
   <w.rf>
    <LM>w#w-d1t1515-19</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1515-20">
   <w.rf>
    <LM>w#w-d1t1515-20</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m051-d1t1515-21">
   <w.rf>
    <LM>w#w-d1t1515-21</LM>
   </w.rf>
   <form>kategorii</form>
   <lemma>kategorie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d1t1517-1">
   <w.rf>
    <LM>w#w-d1t1517-1</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m051-d1t1517-2">
   <w.rf>
    <LM>w#w-d1t1517-2</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1517-4">
   <w.rf>
    <LM>w#w-d1t1517-4</LM>
   </w.rf>
   <form>takzvaně</form>
   <lemma>takzvaně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-356-362">
   <w.rf>
    <LM>w#w-356-362</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1517-5">
   <w.rf>
    <LM>w#w-d1t1517-5</LM>
   </w.rf>
   <form>odstaršit</form>
   <lemma>odstaršit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m051-356-363">
   <w.rf>
    <LM>w#w-356-363</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d-m-d1e1495-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1495-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1518-x2">
  <m id="m051-d1t1523-2">
   <w.rf>
    <LM>w#w-d1t1523-2</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m051-d1t1523-3">
   <w.rf>
    <LM>w#w-d1t1523-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m051-d1e1518-x2-364">
   <w.rf>
    <LM>w#w-d1e1518-x2-364</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m051-d1t1529-1">
   <w.rf>
    <LM>w#w-d1t1529-1</LM>
   </w.rf>
   <form>legislativně</form>
   <lemma>legislativně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1e1518-x2-365">
   <w.rf>
    <LM>w#w-d1e1518-x2-365</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1532-1">
   <w.rf>
    <LM>w#w-d1t1532-1</LM>
   </w.rf>
   <form>papírově</form>
   <lemma>papírově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m051-d1e1518-x2-366">
   <w.rf>
    <LM>w#w-d1e1518-x2-366</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1534-1">
   <w.rf>
    <LM>w#w-d1t1534-1</LM>
   </w.rf>
   <form>povýšit</form>
   <lemma>povýšit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m051-d1e1518-x2-369">
   <w.rf>
    <LM>w#w-d1e1518-x2-369</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1e1518-x2-367">
   <w.rf>
    <LM>w#w-d1e1518-x2-367</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m051-d1e1518-x2-368">
   <w.rf>
    <LM>w#w-d1e1518-x2-368</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m051-d1t1534-4">
   <w.rf>
    <LM>w#w-d1t1534-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1534-5">
   <w.rf>
    <LM>w#w-d1t1534-5</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m051-d-id90823-punct">
   <w.rf>
    <LM>w#w-d-id90823-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m051-d1t1536-1">
   <w.rf>
    <LM>w#w-d1t1536-1</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m051-d1t1536-2">
   <w.rf>
    <LM>w#w-d1t1536-2</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m051-d1t1536-3">
   <w.rf>
    <LM>w#w-d1t1536-3</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m051-d1t1536-4">
   <w.rf>
    <LM>w#w-d1t1536-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m051-d1t1536-6">
   <w.rf>
    <LM>w#w-d1t1536-6</LM>
   </w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFS6----2A----</tag>
  </m>
  <m id="m051-d1t1538-2">
   <w.rf>
    <LM>w#w-d1t1538-2</LM>
   </w.rf>
   <form>věkové</form>
   <lemma>věkový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m051-d1t1536-7">
   <w.rf>
    <LM>w#w-d1t1536-7</LM>
   </w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m051-d-m-d1e1518-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1518-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m051-d1e1546-x2">
  <m id="m051-d1t1549-2">
   <w.rf>
    <LM>w#w-d1t1549-2</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1549-3">
   <w.rf>
    <LM>w#w-d1t1549-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m051-d1t1549-4">
   <w.rf>
    <LM>w#w-d1t1549-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m051-d1t1549-7">
   <w.rf>
    <LM>w#w-d1t1549-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m051-d1t1549-8">
   <w.rf>
    <LM>w#w-d1t1549-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m051-d1t1549-9">
   <w.rf>
    <LM>w#w-d1t1549-9</LM>
   </w.rf>
   <form>papírech</form>
   <lemma>papír</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m051-d1t1549-5">
   <w.rf>
    <LM>w#w-d1t1549-5</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m051-d1t1549-6">
   <w.rf>
    <LM>w#w-d1t1549-6</LM>
   </w.rf>
   <form>nedostatek</form>
   <lemma>nedostatek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m051-d1t1549-10">
   <w.rf>
    <LM>w#w-d1t1549-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m051-d1t1551-5">
   <w.rf>
    <LM>w#w-d1t1551-5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m051-d1t1551-7">
   <w.rf>
    <LM>w#w-d1t1551-7</LM>
   </w.rf>
   <form>hře</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m051-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m051-d1t1551-4">
   <w.rf>
    <LM>w#w-d1t1551-4</LM>
   </w.rf>
   <form>nepřipustili</form>
   <lemma>připustit</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m051-d1e1546-x2-376">
   <w.rf>
    <LM>w#w-d1e1546-x2-376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
