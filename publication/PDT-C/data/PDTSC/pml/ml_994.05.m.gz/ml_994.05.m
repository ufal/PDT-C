<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_994.05.w.gz" />
  </references>
 </head>
 <s id="m994-25819_04-1938">
  <m id="m994-d1t1646-1">
   <w.rf>
    <LM>w#w-d1t1646-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t1646-2">
   <w.rf>
    <LM>w#w-d1t1646-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t1646-3">
   <w.rf>
    <LM>w#w-d1t1646-3</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t1646-4">
   <w.rf>
    <LM>w#w-d1t1646-4</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t1646-5">
   <w.rf>
    <LM>w#w-d1t1646-5</LM>
   </w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m994-d-id105427">
   <w.rf>
    <LM>w#w-d-id105427</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1948">
  <m id="m994-1948-1951">
   <w.rf>
    <LM>w#w-1948-1951</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-1948-1952">
   <w.rf>
    <LM>w#w-1948-1952</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-1948-1953">
   <w.rf>
    <LM>w#w-1948-1953</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m994-1948-1954">
   <w.rf>
    <LM>w#w-1948-1954</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
