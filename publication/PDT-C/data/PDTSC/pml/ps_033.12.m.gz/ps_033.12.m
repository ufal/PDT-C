<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ps_033.12.w.gz" />
  </references>
 </head>
 <s id="m033-211">
  <m id="m033-d1t3863-1">
   <w.rf>
    <LM>w#w-d1t3863-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m033-d1t3863-2">
   <w.rf>
    <LM>w#w-d1t3863-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m033-d1t3863-3">
   <w.rf>
    <LM>w#w-d1t3863-3</LM>
   </w.rf>
   <form>neřeším</form>
   <lemma>řešit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-d-id193200-punct">
   <w.rf>
    <LM>w#w-d-id193200-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3863-6">
   <w.rf>
    <LM>w#w-d1t3863-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3863-7">
   <w.rf>
    <LM>w#w-d1t3863-7</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m033-d-id193255-punct">
   <w.rf>
    <LM>w#w-d-id193255-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3863-9">
   <w.rf>
    <LM>w#w-d1t3863-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3863-10">
   <w.rf>
    <LM>w#w-d1t3863-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3863-11">
   <w.rf>
    <LM>w#w-d1t3863-11</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-211-220">
   <w.rf>
    <LM>w#w-211-220</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3865-1">
   <w.rf>
    <LM>w#w-d1t3865-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3865-2">
   <w.rf>
    <LM>w#w-d1t3865-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3865-3">
   <w.rf>
    <LM>w#w-d1t3865-3</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m033-d1t3865-4">
   <w.rf>
    <LM>w#w-d1t3865-4</LM>
   </w.rf>
   <form>postaráno</form>
   <lemma>postarat</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m033-d-id193367-punct">
   <w.rf>
    <LM>w#w-d-id193367-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3865-6">
   <w.rf>
    <LM>w#w-d1t3865-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3865-7">
   <w.rf>
    <LM>w#w-d1t3865-7</LM>
   </w.rf>
   <form>uvařeno</form>
   <lemma>uvařit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m033-d-id193407-punct">
   <w.rf>
    <LM>w#w-d-id193407-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3865-9">
   <w.rf>
    <LM>w#w-d1t3865-9</LM>
   </w.rf>
   <form>uklizeno</form>
   <lemma>uklidit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m033-211-221">
   <w.rf>
    <LM>w#w-211-221</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-223">
  <m id="m033-d1t3872-5">
   <w.rf>
    <LM>w#w-d1t3872-5</LM>
   </w.rf>
   <form>Cestujeme</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m033-d-id193521-punct">
   <w.rf>
    <LM>w#w-d-id193521-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3872-7">
   <w.rf>
    <LM>w#w-d1t3872-7</LM>
   </w.rf>
   <form>užíváme</form>
   <lemma>užívat_^(*3t)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3872-8">
   <w.rf>
    <LM>w#w-d1t3872-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m033-d1t3872-10">
   <w.rf>
    <LM>w#w-d1t3872-10</LM>
   </w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d-id193585-punct">
   <w.rf>
    <LM>w#w-d-id193585-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3872-12">
   <w.rf>
    <LM>w#w-d1t3872-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3872-13">
   <w.rf>
    <LM>w#w-d1t3872-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t3872-14">
   <w.rf>
    <LM>w#w-d1t3872-14</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d-m-d1e3856-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3856-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3873-x2">
  <m id="m033-d1t3876-1">
   <w.rf>
    <LM>w#w-d1t3876-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m033-d1t3876-2">
   <w.rf>
    <LM>w#w-d1t3876-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3876-3">
   <w.rf>
    <LM>w#w-d1t3876-3</LM>
   </w.rf>
   <form>nepůjdete</form>
   <lemma>jít</lemma>
   <tag>VB-P---2F-NAI--</tag>
  </m>
  <m id="m033-d1t3876-4">
   <w.rf>
    <LM>w#w-d1t3876-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3876-5">
   <w.rf>
    <LM>w#w-d1t3876-5</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d-id193764-punct">
   <w.rf>
    <LM>w#w-d-id193764-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3877-x2">
  <m id="m033-d1t3880-5">
   <w.rf>
    <LM>w#w-d1t3880-5</LM>
   </w.rf>
   <form>Minimálně</form>
   <lemma>minimálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d1t3880-6">
   <w.rf>
    <LM>w#w-d1t3880-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3880-7">
   <w.rf>
    <LM>w#w-d1t3880-7</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d1t3880-8">
   <w.rf>
    <LM>w#w-d1t3880-8</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m033-d1t3880-9">
   <w.rf>
    <LM>w#w-d1t3880-9</LM>
   </w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m033-d1t3880-10">
   <w.rf>
    <LM>w#w-d1t3880-10</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d1t3880-11">
   <w.rf>
    <LM>w#w-d1t3880-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3880-12">
   <w.rf>
    <LM>w#w-d1t3880-12</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3880-13">
   <w.rf>
    <LM>w#w-d1t3880-13</LM>
   </w.rf>
   <form>uvidím</form>
   <lemma>uvidět</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m033-d-id194007-punct">
   <w.rf>
    <LM>w#w-d-id194007-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3880-15">
   <w.rf>
    <LM>w#w-d1t3880-15</LM>
   </w.rf>
   <form>jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m033-d1t3880-16">
   <w.rf>
    <LM>w#w-d1t3880-16</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m033-d1t3880-17">
   <w.rf>
    <LM>w#w-d1t3880-17</LM>
   </w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1e3877-x2-233">
   <w.rf>
    <LM>w#w-d1e3877-x2-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-234">
  <m id="m033-d1t3882-4">
   <w.rf>
    <LM>w#w-d1t3882-4</LM>
   </w.rf>
   <form>Nárok</form>
   <lemma>nárok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-d1t3882-5">
   <w.rf>
    <LM>w#w-d1t3882-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3882-6">
   <w.rf>
    <LM>w#w-d1t3882-6</LM>
   </w.rf>
   <form>důchod</form>
   <lemma>důchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-d1t3882-7">
   <w.rf>
    <LM>w#w-d1t3882-7</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-234-242">
   <w.rf>
    <LM>w#w-234-242</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3882-9">
   <w.rf>
    <LM>w#w-d1t3882-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3882-11">
   <w.rf>
    <LM>w#w-d1t3882-11</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m033-d1t3882-12">
   <w.rf>
    <LM>w#w-d1t3882-12</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m033-d1t3882-13">
   <w.rf>
    <LM>w#w-d1t3882-13</LM>
   </w.rf>
   <form>přesluhuju</form>
   <lemma>přesluhovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-234-243">
   <w.rf>
    <LM>w#w-234-243</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-244">
  <m id="m033-d1t3888-2">
   <w.rf>
    <LM>w#w-d1t3888-2</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3888-3">
   <w.rf>
    <LM>w#w-d1t3888-3</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d1t3888-4">
   <w.rf>
    <LM>w#w-d1t3888-4</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m033-d1t3888-5">
   <w.rf>
    <LM>w#w-d1t3888-5</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t3888-6">
   <w.rf>
    <LM>w#w-d1t3888-6</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d1t3888-7">
   <w.rf>
    <LM>w#w-d1t3888-7</LM>
   </w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m033-244-245">
   <w.rf>
    <LM>w#w-244-245</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3888-8">
   <w.rf>
    <LM>w#w-d1t3888-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t3888-9">
   <w.rf>
    <LM>w#w-d1t3888-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3888-10">
   <w.rf>
    <LM>w#w-d1t3888-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3888-11">
   <w.rf>
    <LM>w#w-d1t3888-11</LM>
   </w.rf>
   <form>domluvený</form>
   <lemma>domluvený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m033-d1t3888-12">
   <w.rf>
    <LM>w#w-d1t3888-12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t3888-13">
   <w.rf>
    <LM>w#w-d1t3888-13</LM>
   </w.rf>
   <form>naším</form>
   <lemma>náš</lemma>
   <tag>PSZS7-P1-------</tag>
  </m>
  <m id="m033-d1t3888-14">
   <w.rf>
    <LM>w#w-d1t3888-14</LM>
   </w.rf>
   <form>vedením</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m033-d-id194463-punct">
   <w.rf>
    <LM>w#w-d-id194463-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3891-2">
   <w.rf>
    <LM>w#w-d1t3891-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3891-5">
   <w.rf>
    <LM>w#w-d1t3891-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t3891-6">
   <w.rf>
    <LM>w#w-d1t3891-6</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3891-7">
   <w.rf>
    <LM>w#w-d1t3891-7</LM>
   </w.rf>
   <form>domluvíme</form>
   <lemma>domluvit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m033-244-246">
   <w.rf>
    <LM>w#w-244-246</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-248">
  <m id="m033-d1t3895-2">
   <w.rf>
    <LM>w#w-d1t3895-2</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m033-d1t3895-3">
   <w.rf>
    <LM>w#w-d1t3895-3</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m033-d1t3895-5">
   <w.rf>
    <LM>w#w-d1t3895-5</LM>
   </w.rf>
   <form>nepropouští</form>
   <lemma>propouštět</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m033-d-id194740-punct">
   <w.rf>
    <LM>w#w-d-id194740-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3895-7">
   <w.rf>
    <LM>w#w-d1t3895-7</LM>
   </w.rf>
   <form>nevyhazuje</form>
   <lemma>vyhazovat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m033-248-600">
   <w.rf>
    <LM>w#w-248-600</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-602">
  <m id="m033-d1t3895-11">
   <w.rf>
    <LM>w#w-d1t3895-11</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3895-12">
   <w.rf>
    <LM>w#w-d1t3895-12</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m033-d-id194828-punct">
   <w.rf>
    <LM>w#w-d-id194828-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3895-14">
   <w.rf>
    <LM>w#w-d1t3895-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3895-15">
   <w.rf>
    <LM>w#w-d1t3895-15</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m033-d1t3895-16">
   <w.rf>
    <LM>w#w-d1t3895-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3895-17">
   <w.rf>
    <LM>w#w-d1t3895-17</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m033-248-264">
   <w.rf>
    <LM>w#w-248-264</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3899-1">
   <w.rf>
    <LM>w#w-d1t3899-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3899-2">
   <w.rf>
    <LM>w#w-d1t3899-2</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t3899-3">
   <w.rf>
    <LM>w#w-d1t3899-3</LM>
   </w.rf>
   <form>znám</form>
   <lemma>znát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3899-4">
   <w.rf>
    <LM>w#w-d1t3899-4</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d-id194966-punct">
   <w.rf>
    <LM>w#w-d-id194966-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3899-6">
   <w.rf>
    <LM>w#w-d1t3899-6</LM>
   </w.rf>
   <form>zvládám</form>
   <lemma>zvládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3899-7">
   <w.rf>
    <LM>w#w-d1t3899-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m033-d1t3899-8">
   <w.rf>
    <LM>w#w-d1t3899-8</LM>
   </w.rf>
   <form>perfektně</form>
   <lemma>perfektně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-602-603">
   <w.rf>
    <LM>w#w-602-603</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-604">
  <m id="m033-d1t3901-2">
   <w.rf>
    <LM>w#w-d1t3901-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t3901-3">
   <w.rf>
    <LM>w#w-d1t3901-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m033-d1t3901-1">
   <w.rf>
    <LM>w#w-d1t3901-1</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-d1t3901-4">
   <w.rf>
    <LM>w#w-d1t3901-4</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWYP4----------</tag>
  </m>
  <m id="m033-d1t3901-5">
   <w.rf>
    <LM>w#w-d1t3901-5</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m033-248-265">
   <w.rf>
    <LM>w#w-248-265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-273">
  <m id="m033-d1t3904-3">
   <w.rf>
    <LM>w#w-d1t3904-3</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m033-d1t3904-2">
   <w.rf>
    <LM>w#w-d1t3904-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m033-d1t3904-4">
   <w.rf>
    <LM>w#w-d1t3904-4</LM>
   </w.rf>
   <form>nejradši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m033-d-id195222-punct">
   <w.rf>
    <LM>w#w-d-id195222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3904-6">
   <w.rf>
    <LM>w#w-d1t3904-6</LM>
   </w.rf>
   <form>kdybych</form>
   <lemma>kdyby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m033-d1t3904-7">
   <w.rf>
    <LM>w#w-d1t3904-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3904-8">
   <w.rf>
    <LM>w#w-d1t3904-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m033-d1t3904-9">
   <w.rf>
    <LM>w#w-d1t3904-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3904-10">
   <w.rf>
    <LM>w#w-d1t3904-10</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d1t3904-11">
   <w.rf>
    <LM>w#w-d1t3904-11</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d-id195310-punct">
   <w.rf>
    <LM>w#w-d-id195310-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3904-13">
   <w.rf>
    <LM>w#w-d1t3904-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3906-1">
   <w.rf>
    <LM>w#w-d1t3906-1</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-273-274">
   <w.rf>
    <LM>w#w-273-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-275">
  <m id="m033-d1t3908-1">
   <w.rf>
    <LM>w#w-d1t3908-1</LM>
   </w.rf>
   <form>Uvidím</form>
   <lemma>uvidět</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m033-d-id195405-punct">
   <w.rf>
    <LM>w#w-d-id195405-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3910-1">
   <w.rf>
    <LM>w#w-d1t3910-1</LM>
   </w.rf>
   <form>jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m033-d1t3910-2">
   <w.rf>
    <LM>w#w-d1t3910-2</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m033-d1t3910-3">
   <w.rf>
    <LM>w#w-d1t3910-3</LM>
   </w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t3910-5">
   <w.rf>
    <LM>w#w-d1t3910-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3910-6">
   <w.rf>
    <LM>w#w-d1t3910-6</LM>
   </w.rf>
   <form>finanční</form>
   <lemma>finanční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-275-282">
   <w.rf>
    <LM>w#w-275-282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3910-7">
   <w.rf>
    <LM>w#w-d1t3910-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3910-8">
   <w.rf>
    <LM>w#w-d1t3910-8</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-275-283">
   <w.rf>
    <LM>w#w-275-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-285">
  <m id="m033-d1t3914-4">
   <w.rf>
    <LM>w#w-d1t3914-4</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3914-5">
   <w.rf>
    <LM>w#w-d1t3914-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t3914-6">
   <w.rf>
    <LM>w#w-d1t3914-6</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m033-d1t3914-7">
   <w.rf>
    <LM>w#w-d1t3914-7</LM>
   </w.rf>
   <form>domlouvat</form>
   <lemma>domlouvat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d-id195701-punct">
   <w.rf>
    <LM>w#w-d-id195701-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3914-9">
   <w.rf>
    <LM>w#w-d1t3914-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3914-10">
   <w.rf>
    <LM>w#w-d1t3914-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3914-11">
   <w.rf>
    <LM>w#w-d1t3914-11</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d1t3914-12">
   <w.rf>
    <LM>w#w-d1t3914-12</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m033-d1t3914-13">
   <w.rf>
    <LM>w#w-d1t3914-13</LM>
   </w.rf>
   <form>stoprocentně</form>
   <lemma>stoprocentně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d1t3917-1">
   <w.rf>
    <LM>w#w-d1t3917-1</LM>
   </w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m033-d1t3917-2">
   <w.rf>
    <LM>w#w-d1t3917-2</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d-m-d1e3877-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3877-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3918-x2">
  <m id="m033-d1t3925-1">
   <w.rf>
    <LM>w#w-d1t3925-1</LM>
   </w.rf>
   <form>Práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t3925-2">
   <w.rf>
    <LM>w#w-d1t3925-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m033-d1t3925-3">
   <w.rf>
    <LM>w#w-d1t3925-3</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3925-4">
   <w.rf>
    <LM>w#w-d1t3925-4</LM>
   </w.rf>
   <form>baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d-id195947-punct">
   <w.rf>
    <LM>w#w-d-id195947-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3926-x2">
  <m id="m033-d1t3935-3">
   <w.rf>
    <LM>w#w-d1t3935-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3935-2">
   <w.rf>
    <LM>w#w-d1t3935-2</LM>
   </w.rf>
   <form>dělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3935-5">
   <w.rf>
    <LM>w#w-d1t3935-5</LM>
   </w.rf>
   <form>dozorčího</form>
   <lemma>dozorčí-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m033-d1t3935-6">
   <w.rf>
    <LM>w#w-d1t3935-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3935-8">
   <w.rf>
    <LM>w#w-d1t3935-8</LM>
   </w.rf>
   <form>ČD</form>
   <lemma>ČD-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m033-d1t3937-2">
   <w.rf>
    <LM>w#w-d1t3937-2</LM>
   </w.rf>
   <form>Cargo</form>
   <lemma>Cargo_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m033-d1e3926-x2-81">
   <w.rf>
    <LM>w#w-d1e3926-x2-81</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-84">
  <m id="m033-d1t3942-3">
   <w.rf>
    <LM>w#w-d1t3942-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3942-5">
   <w.rf>
    <LM>w#w-d1t3942-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3942-6">
   <w.rf>
    <LM>w#w-d1t3942-6</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m033-d1t3942-1">
   <w.rf>
    <LM>w#w-d1t3942-1</LM>
   </w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m033-d1t3942-2">
   <w.rf>
    <LM>w#w-d1t3942-2</LM>
   </w.rf>
   <form>dopravu</form>
   <lemma>doprava-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t3942-4">
   <w.rf>
    <LM>w#w-d1t3942-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3944-1">
   <w.rf>
    <LM>w#w-d1t3944-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t3944-2">
   <w.rf>
    <LM>w#w-d1t3944-2</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m033-d1t3944-3">
   <w.rf>
    <LM>w#w-d1t3944-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3946-2">
   <w.rf>
    <LM>w#w-d1t3946-2</LM>
   </w.rf>
   <form>Furth</form>
   <lemma>Furth-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m033-d1t3948-1">
   <w.rf>
    <LM>w#w-d1t3948-1</LM>
   </w.rf>
   <form>im</form>
   <lemma>im-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m033-d1t3950-1">
   <w.rf>
    <LM>w#w-d1t3950-1</LM>
   </w.rf>
   <form>Waldu</form>
   <lemma>Wald_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d1e3926-x2-27">
   <w.rf>
    <LM>w#w-d1e3926-x2-27</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3953-4">
   <w.rf>
    <LM>w#w-d1t3953-4</LM>
   </w.rf>
   <form>Domažlice</form>
   <lemma>Domažlice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m033-d-id196583-punct">
   <w.rf>
    <LM>w#w-d-id196583-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3953-8">
   <w.rf>
    <LM>w#w-d1t3953-8</LM>
   </w.rf>
   <form>Klatovy</form>
   <lemma>Klatovy_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m033-d-id196625-punct">
   <w.rf>
    <LM>w#w-d-id196625-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3955-2">
   <w.rf>
    <LM>w#w-d1t3955-2</LM>
   </w.rf>
   <form>Nepomuk</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-d-id196676-punct">
   <w.rf>
    <LM>w#w-d-id196676-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3955-6">
   <w.rf>
    <LM>w#w-d1t3955-6</LM>
   </w.rf>
   <form>Planou</form>
   <lemma>Planá_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t3955-7">
   <w.rf>
    <LM>w#w-d1t3955-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t3955-8">
   <w.rf>
    <LM>w#w-d1t3955-8</LM>
   </w.rf>
   <form>Mariánských</form>
   <lemma>mariánský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m033-d1t3957-1">
   <w.rf>
    <LM>w#w-d1t3957-1</LM>
   </w.rf>
   <form>Lázní</form>
   <lemma>lázně</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m033-d1t3957-3">
   <w.rf>
    <LM>w#w-d1t3957-3</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t3957-4">
   <w.rf>
    <LM>w#w-d1t3957-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3957-5">
   <w.rf>
    <LM>w#w-d1t3957-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3957-7">
   <w.rf>
    <LM>w#w-d1t3957-7</LM>
   </w.rf>
   <form>Zbiroh</form>
   <lemma>Zbiroh_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-d1t3959-1">
   <w.rf>
    <LM>w#w-d1t3959-1</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-2_^(mat._operace;_1_plus_1,_též_plus_dva_stupně)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m033-d1t3961-12">
   <w.rf>
    <LM>w#w-d1t3961-12</LM>
   </w.rf>
   <form>přepravu</form>
   <lemma>přeprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>uhlí</form>
   <lemma>uhlí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m033-d1t3961-14">
   <w.rf>
    <LM>w#w-d1t3961-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3961-15">
   <w.rf>
    <LM>w#w-d1t3961-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3961-16">
   <w.rf>
    <LM>w#w-d1t3961-16</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d-id196907-punct">
   <w.rf>
    <LM>w#w-d-id196907-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3961-9">
   <w.rf>
    <LM>w#w-d1t3961-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m033-d1t3963-4">
   <w.rf>
    <LM>w#w-d1t3963-4</LM>
   </w.rf>
   <form>přeletí</form>
   <lemma>přeletět</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m033-d1t3963-6">
   <w.rf>
    <LM>w#w-d1t3963-6</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3963-8">
   <w.rf>
    <LM>w#w-d1t3963-8</LM>
   </w.rf>
   <form>Plzeň</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t3963-10">
   <w.rf>
    <LM>w#w-d1t3963-10</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-2_^(mat._operace;_1_plus_1,_též_plus_dva_stupně)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m033-d1t3966-1">
   <w.rf>
    <LM>w#w-d1t3966-1</LM>
   </w.rf>
   <form>plzeňský</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m033-d1t3966-2">
   <w.rf>
    <LM>w#w-d1t3966-2</LM>
   </w.rf>
   <form>ranžír</form>
   <lemma>ranžír_,h</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-84-653">
   <w.rf>
    <LM>w#w-84-653</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-654">
  <m id="m033-d1t3970-3">
   <w.rf>
    <LM>w#w-d1t3970-3</LM>
   </w.rf>
   <form>Práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m033-d1t3970-4">
   <w.rf>
    <LM>w#w-d1t3970-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3970-5">
   <w.rf>
    <LM>w#w-d1t3970-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t3970-6">
   <w.rf>
    <LM>w#w-d1t3970-6</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3970-7">
   <w.rf>
    <LM>w#w-d1t3970-7</LM>
   </w.rf>
   <form>hlavu</form>
   <lemma>hlava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1e3926-x2-28">
   <w.rf>
    <LM>w#w-d1e3926-x2-28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3926-x3">
  <m id="m033-d1t3972-1">
   <w.rf>
    <LM>w#w-d1t3972-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t3972-2">
   <w.rf>
    <LM>w#w-d1t3972-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3972-3">
   <w.rf>
    <LM>w#w-d1t3972-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t3972-4">
   <w.rf>
    <LM>w#w-d1t3972-4</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m033-d1t3972-5">
   <w.rf>
    <LM>w#w-d1t3972-5</LM>
   </w.rf>
   <form>droga</form>
   <lemma>droga</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1e3926-x3-88">
   <w.rf>
    <LM>w#w-d1e3926-x3-88</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3974-3">
   <w.rf>
    <LM>w#w-d1t3974-3</LM>
   </w.rf>
   <form>děje</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3974-2">
   <w.rf>
    <LM>w#w-d1t3974-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t3974-1">
   <w.rf>
    <LM>w#w-d1t3974-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3974-4">
   <w.rf>
    <LM>w#w-d1t3974-4</LM>
   </w.rf>
   <form>každou</form>
   <lemma>každý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m033-d1t3974-8">
   <w.rf>
    <LM>w#w-d1t3974-8</LM>
   </w.rf>
   <form>minutu</form>
   <lemma>minuta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t3974-9">
   <w.rf>
    <LM>w#w-d1t3974-9</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m033-d1t3974-10">
   <w.rf>
    <LM>w#w-d1t3974-10</LM>
   </w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m033-d-id197568-punct">
   <w.rf>
    <LM>w#w-d-id197568-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3974-12">
   <w.rf>
    <LM>w#w-d1t3974-12</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3976-1">
   <w.rf>
    <LM>w#w-d1t3976-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t3976-2">
   <w.rf>
    <LM>w#w-d1t3976-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t3976-3">
   <w.rf>
    <LM>w#w-d1t3976-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m033-d1e3926-x3-89">
   <w.rf>
    <LM>w#w-d1e3926-x3-89</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-94">
  <m id="m033-d1t3983-8">
   <w.rf>
    <LM>w#w-d1t3983-8</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t3983-9">
   <w.rf>
    <LM>w#w-d1t3983-9</LM>
   </w.rf>
   <form>dělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t3983-4">
   <w.rf>
    <LM>w#w-d1t3983-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t3983-6">
   <w.rf>
    <LM>w#w-d1t3983-6</LM>
   </w.rf>
   <form>vedlejší</form>
   <lemma>vedlejší</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m033-94-2">
   <w.rf>
    <LM>w#w-94-2</LM>
   </w.rf>
   <form>úvazek</form>
   <lemma>úvazek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m033-d1t3983-10">
   <w.rf>
    <LM>w#w-d1t3983-10</LM>
   </w.rf>
   <form>výpravčího</form>
   <lemma>výpravčí-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m033-94-3">
   <w.rf>
    <LM>w#w-94-3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t3989-1">
   <w.rf>
    <LM>w#w-d1t3989-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t3989-5">
   <w.rf>
    <LM>w#w-d1t3989-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t3989-7">
   <w.rf>
    <LM>w#w-d1t3989-7</LM>
   </w.rf>
   <form>nenudím</form>
   <lemma>nudit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-94-4">
   <w.rf>
    <LM>w#w-94-4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3995-x2">
  <m id="m033-d1t4002-1">
   <w.rf>
    <LM>w#w-d1t4002-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4002-2">
   <w.rf>
    <LM>w#w-d1t4002-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4002-3">
   <w.rf>
    <LM>w#w-d1t4002-3</LM>
   </w.rf>
   <form>droga</form>
   <lemma>droga</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1e3995-x2-668">
   <w.rf>
    <LM>w#w-d1e3995-x2-668</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-669">
  <m id="m033-d1t4002-6">
   <w.rf>
    <LM>w#w-d1t4002-6</LM>
   </w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d1t4004-3">
   <w.rf>
    <LM>w#w-d1t4004-3</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4004-4">
   <w.rf>
    <LM>w#w-d1t4004-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4004-2">
   <w.rf>
    <LM>w#w-d1t4004-2</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d-id198253-punct">
   <w.rf>
    <LM>w#w-d-id198253-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4004-6">
   <w.rf>
    <LM>w#w-d1t4004-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4004-7">
   <w.rf>
    <LM>w#w-d1t4004-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4004-10">
   <w.rf>
    <LM>w#w-d1t4004-10</LM>
   </w.rf>
   <form>vysadí</form>
   <lemma>vysadit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m033-d1e3995-x2-11">
   <w.rf>
    <LM>w#w-d1e3995-x2-11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4004-12">
   <w.rf>
    <LM>w#w-d1t4004-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4004-13">
   <w.rf>
    <LM>w#w-d1t4004-13</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4006-2">
   <w.rf>
    <LM>w#w-d1t4006-2</LM>
   </w.rf>
   <form>začne</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m033-d1t4006-3">
   <w.rf>
    <LM>w#w-d1t4006-3</LM>
   </w.rf>
   <form>stárnout</form>
   <lemma>stárnout</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d1e3995-x2-15">
   <w.rf>
    <LM>w#w-d1e3995-x2-15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4019-5">
   <w.rf>
    <LM>w#w-d1t4019-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4019-1">
   <w.rf>
    <LM>w#w-d1t4019-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4019-2">
   <w.rf>
    <LM>w#w-d1t4019-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4019-3">
   <w.rf>
    <LM>w#w-d1t4019-3</LM>
   </w.rf>
   <form>stránce</form>
   <lemma>stránka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m033-d1t4019-4">
   <w.rf>
    <LM>w#w-d1t4019-4</LM>
   </w.rf>
   <form>mentální</form>
   <lemma>mentální</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m033-d-m-d1e3995-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3995-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e3995-x4">
  <m id="m033-d1t4022-1">
   <w.rf>
    <LM>w#w-d1t4022-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4022-2">
   <w.rf>
    <LM>w#w-d1t4022-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4022-3">
   <w.rf>
    <LM>w#w-d1t4022-3</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d-m-d1e3995-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3995-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4023-x2">
  <m id="m033-d1t4028-2">
   <w.rf>
    <LM>w#w-d1t4028-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4028-4">
   <w.rf>
    <LM>w#w-d1t4028-4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4028-3">
   <w.rf>
    <LM>w#w-d1t4028-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4028-5">
   <w.rf>
    <LM>w#w-d1t4028-5</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4028-6">
   <w.rf>
    <LM>w#w-d1t4028-6</LM>
   </w.rf>
   <form>udržovat</form>
   <lemma>udržovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m033-d1e4023-x2-20">
   <w.rf>
    <LM>w#w-d1e4023-x2-20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4028-8">
   <w.rf>
    <LM>w#w-d1t4028-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4030-2">
   <w.rf>
    <LM>w#w-d1t4030-2</LM>
   </w.rf>
   <form>nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4030-3">
   <w.rf>
    <LM>w#w-d1t4030-3</LM>
   </w.rf>
   <form>nespěchám</form>
   <lemma>spěchat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-d1e4023-x2-21">
   <w.rf>
    <LM>w#w-d1e4023-x2-21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-32">
  <m id="m033-d1t4037-11">
   <w.rf>
    <LM>w#w-d1t4037-11</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4037-9">
   <w.rf>
    <LM>w#w-d1t4037-9</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4037-10">
   <w.rf>
    <LM>w#w-d1t4037-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t4037-12">
   <w.rf>
    <LM>w#w-d1t4037-12</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4037-13">
   <w.rf>
    <LM>w#w-d1t4037-13</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m033-d-id199095-punct">
   <w.rf>
    <LM>w#w-d-id199095-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4037-15">
   <w.rf>
    <LM>w#w-d1t4037-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t4037-16">
   <w.rf>
    <LM>w#w-d1t4037-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4037-17">
   <w.rf>
    <LM>w#w-d1t4037-17</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m033-d1t4037-18">
   <w.rf>
    <LM>w#w-d1t4037-18</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4037-19">
   <w.rf>
    <LM>w#w-d1t4037-19</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4037-20">
   <w.rf>
    <LM>w#w-d1t4037-20</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-32-33">
   <w.rf>
    <LM>w#w-32-33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-35">
  <m id="m033-d1t4039-1">
   <w.rf>
    <LM>w#w-d1t4039-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m033-d1t4039-3">
   <w.rf>
    <LM>w#w-d1t4039-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4039-4">
   <w.rf>
    <LM>w#w-d1t4039-4</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d1t4039-5">
   <w.rf>
    <LM>w#w-d1t4039-5</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m033-d1t4039-6">
   <w.rf>
    <LM>w#w-d1t4039-6</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m033-d1t4039-2">
   <w.rf>
    <LM>w#w-d1t4039-2</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4039-7">
   <w.rf>
    <LM>w#w-d1t4039-7</LM>
   </w.rf>
   <form>nezastaví</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m033-35-36">
   <w.rf>
    <LM>w#w-35-36</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-37">
  <m id="m033-d1t4043-1">
   <w.rf>
    <LM>w#w-d1t4043-1</LM>
   </w.rf>
   <form>Přijdete</form>
   <lemma>přijít</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m033-d1t4043-2">
   <w.rf>
    <LM>w#w-d1t4043-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t4043-3">
   <w.rf>
    <LM>w#w-d1t4043-3</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m033-d1t4043-8">
   <w.rf>
    <LM>w#w-d1t4043-8</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4043-9">
   <w.rf>
    <LM>w#w-d1t4043-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4043-10">
   <w.rf>
    <LM>w#w-d1t4043-10</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m033-d1t4043-11">
   <w.rf>
    <LM>w#w-d1t4043-11</LM>
   </w.rf>
   <form>šesté</form>
   <lemma>šestý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m033-37-40">
   <w.rf>
    <LM>w#w-37-40</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4043-13">
   <w.rf>
    <LM>w#w-d1t4043-13</LM>
   </w.rf>
   <form>odcházíte</form>
   <lemma>odcházet</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m033-d1t4043-14">
   <w.rf>
    <LM>w#w-d1t4043-14</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4043-15">
   <w.rf>
    <LM>w#w-d1t4043-15</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t4043-18">
   <w.rf>
    <LM>w#w-d1t4043-18</LM>
   </w.rf>
   <form>šesté</form>
   <lemma>šestý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m033-37-41">
   <w.rf>
    <LM>w#w-37-41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4047-1">
   <w.rf>
    <LM>w#w-d1t4047-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4047-4">
   <w.rf>
    <LM>w#w-d1t4047-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m033-d1t4047-3">
   <w.rf>
    <LM>w#w-d1t4047-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4047-5">
   <w.rf>
    <LM>w#w-d1t4047-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-37-42">
   <w.rf>
    <LM>w#w-37-42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4023-x3">
  <m id="m033-d1t4052-1">
   <w.rf>
    <LM>w#w-d1t4052-1</LM>
   </w.rf>
   <form>Zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4052-2">
   <w.rf>
    <LM>w#w-d1t4052-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m033-d1t4052-3">
   <w.rf>
    <LM>w#w-d1t4052-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4052-4">
   <w.rf>
    <LM>w#w-d1t4052-4</LM>
   </w.rf>
   <form>baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d-id199755-punct">
   <w.rf>
    <LM>w#w-d-id199755-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4052-6">
   <w.rf>
    <LM>w#w-d1t4052-6</LM>
   </w.rf>
   <form>nestěžuju</form>
   <lemma>stěžovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-d1t4052-7">
   <w.rf>
    <LM>w#w-d1t4052-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m033-d-m-d1e4023-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4023-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4053-x2">
  <m id="m033-d1t4060-1">
   <w.rf>
    <LM>w#w-d1t4060-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m033-d1t4060-2">
   <w.rf>
    <LM>w#w-d1t4060-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m033-d1t4060-3">
   <w.rf>
    <LM>w#w-d1t4060-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m033-d1t4060-5">
   <w.rf>
    <LM>w#w-d1t4060-5</LM>
   </w.rf>
   <form>vaší</form>
   <lemma>váš</lemma>
   <tag>PSFS3-P2-------</tag>
  </m>
  <m id="m033-d1t4060-6">
   <w.rf>
    <LM>w#w-d1t4060-6</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m033-d1t4060-7">
   <w.rf>
    <LM>w#w-d1t4060-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4060-8">
   <w.rf>
    <LM>w#w-d1t4060-8</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m033-d-id199989-punct">
   <w.rf>
    <LM>w#w-d-id199989-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4062-x2">
  <m id="m033-d1t4065-1">
   <w.rf>
    <LM>w#w-d1t4065-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m033-d1t4065-2">
   <w.rf>
    <LM>w#w-d1t4065-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m033-d1t4065-3">
   <w.rf>
    <LM>w#w-d1t4065-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m033-d1t4065-4">
   <w.rf>
    <LM>w#w-d1t4065-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4065-5">
   <w.rf>
    <LM>w#w-d1t4065-5</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m033-d1t4065-6">
   <w.rf>
    <LM>w#w-d1t4065-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m033-d1e4062-x2-54">
   <w.rf>
    <LM>w#w-d1e4062-x2-54</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-85">
  <m id="m033-d1t4067-3">
   <w.rf>
    <LM>w#w-d1t4067-3</LM>
   </w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m033-d1t4067-5">
   <w.rf>
    <LM>w#w-d1t4067-5</LM>
   </w.rf>
   <form>ženou</form>
   <lemma>žena</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m033-d1t4067-7">
   <w.rf>
    <LM>w#w-d1t4067-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m033-d1t4067-8">
   <w.rf>
    <LM>w#w-d1t4067-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4067-9">
   <w.rf>
    <LM>w#w-d1t4067-9</LM>
   </w.rf>
   <form>znali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m033-d1t4067-14">
   <w.rf>
    <LM>w#w-d1t4067-14</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4067-15">
   <w.rf>
    <LM>w#w-d1t4067-15</LM>
   </w.rf>
   <form>mínus</form>
   <lemma>mínus-3_,h_^(^GC**minus-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4067-12">
   <w.rf>
    <LM>w#w-d1t4067-12</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m033-d1t4067-13">
   <w.rf>
    <LM>w#w-d1t4067-13</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m033-d-id200376-punct">
   <w.rf>
    <LM>w#w-d-id200376-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4073-4">
   <w.rf>
    <LM>w#w-d1t4073-4</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4073-5">
   <w.rf>
    <LM>w#w-d1t4073-5</LM>
   </w.rf>
   <form>hostina</form>
   <lemma>hostina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4073-6">
   <w.rf>
    <LM>w#w-d1t4073-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m033-d1t4073-7">
   <w.rf>
    <LM>w#w-d1t4073-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4073-10">
   <w.rf>
    <LM>w#w-d1t4073-10</LM>
   </w.rf>
   <form>Babyloně</form>
   <lemma>Babylon_;G_;m</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m033-85-93">
   <w.rf>
    <LM>w#w-85-93</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-98">
  <m id="m033-98-105">
   <w.rf>
    <LM>w#w-98-105</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m033-98-106">
   <w.rf>
    <LM>w#w-98-106</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4078-2">
   <w.rf>
    <LM>w#w-d1t4078-2</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4078-3">
   <w.rf>
    <LM>w#w-d1t4078-3</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m033-d1t4078-4">
   <w.rf>
    <LM>w#w-d1t4078-4</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m033-d-id200571-punct">
   <w.rf>
    <LM>w#w-d-id200571-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4078-7">
   <w.rf>
    <LM>w#w-d1t4078-7</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m033-d1t4078-6">
   <w.rf>
    <LM>w#w-d1t4078-6</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m033-d-id200611-punct">
   <w.rf>
    <LM>w#w-d-id200611-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4078-9">
   <w.rf>
    <LM>w#w-d1t4078-9</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m033-d1t4078-10">
   <w.rf>
    <LM>w#w-d1t4078-10</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4078-11">
   <w.rf>
    <LM>w#w-d1t4078-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4078-12">
   <w.rf>
    <LM>w#w-d1t4078-12</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m033-d1t4078-15">
   <w.rf>
    <LM>w#w-d1t4078-15</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t4078-16">
   <w.rf>
    <LM>w#w-d1t4078-16</LM>
   </w.rf>
   <form>svědky</form>
   <lemma>svědek</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m033-98-107">
   <w.rf>
    <LM>w#w-98-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-116">
  <m id="m033-d1t4084-1">
   <w.rf>
    <LM>w#w-d1t4084-1</LM>
   </w.rf>
   <form>Přijelo</form>
   <lemma>přijet</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m033-d1t4084-2">
   <w.rf>
    <LM>w#w-d1t4084-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4084-3">
   <w.rf>
    <LM>w#w-d1t4084-3</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m033-d1t4084-4">
   <w.rf>
    <LM>w#w-d1t4084-4</LM>
   </w.rf>
   <form>jejích</form>
   <lemma>jeho</lemma>
   <tag>P9XP2FS3-------</tag>
  </m>
  <m id="m033-d1t4084-8">
   <w.rf>
    <LM>w#w-d1t4084-8</LM>
   </w.rf>
   <form>spolupracovnic</form>
   <lemma>spolupracovnice_^(*3ík)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m033-d1t4084-10">
   <w.rf>
    <LM>w#w-d1t4084-10</LM>
   </w.rf>
   <form>popřát</form>
   <lemma>popřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m033-116-117">
   <w.rf>
    <LM>w#w-116-117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-157">
  <m id="m033-d1t4084-14">
   <w.rf>
    <LM>w#w-d1t4084-14</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4084-15">
   <w.rf>
    <LM>w#w-d1t4084-15</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m033-d1t4084-12">
   <w.rf>
    <LM>w#w-d1t4084-12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4084-13">
   <w.rf>
    <LM>w#w-d1t4084-13</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m033-d1t4084-11">
   <w.rf>
    <LM>w#w-d1t4084-11</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4084-16">
   <w.rf>
    <LM>w#w-d1t4084-16</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m033-d1t4084-18">
   <w.rf>
    <LM>w#w-d1t4084-18</LM>
   </w.rf>
   <form>nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m033-157-694">
   <w.rf>
    <LM>w#w-157-694</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-695">
  <m id="m033-d1t4084-23">
   <w.rf>
    <LM>w#w-d1t4084-23</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m033-d1t4084-21">
   <w.rf>
    <LM>w#w-d1t4084-21</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m033-d1t4084-22">
   <w.rf>
    <LM>w#w-d1t4084-22</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m033-d1t4084-27">
   <w.rf>
    <LM>w#w-d1t4084-27</LM>
   </w.rf>
   <form>napůl</form>
   <lemma>napůl</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4084-29">
   <w.rf>
    <LM>w#w-d1t4084-29</LM>
   </w.rf>
   <form>potajmu</form>
   <lemma>potajmu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d-id201111-punct">
   <w.rf>
    <LM>w#w-d-id201111-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4084-31">
   <w.rf>
    <LM>w#w-d1t4084-31</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4084-32">
   <w.rf>
    <LM>w#w-d1t4084-32</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m033-d1t4084-34">
   <w.rf>
    <LM>w#w-d1t4084-34</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m033-d1t4084-33">
   <w.rf>
    <LM>w#w-d1t4084-33</LM>
   </w.rf>
   <form>zbytečně</form>
   <lemma>zbytečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d1t4084-35">
   <w.rf>
    <LM>w#w-d1t4084-35</LM>
   </w.rf>
   <form>neobtěžovali</form>
   <lemma>obtěžovat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m033-157-164">
   <w.rf>
    <LM>w#w-157-164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4062-x3">
  <m id="m033-d1t4091-1">
   <w.rf>
    <LM>w#w-d1t4091-1</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m033-d1t4091-2">
   <w.rf>
    <LM>w#w-d1t4091-2</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4091-3">
   <w.rf>
    <LM>w#w-d1t4091-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m033-d1t4091-6">
   <w.rf>
    <LM>w#w-d1t4091-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4091-4">
   <w.rf>
    <LM>w#w-d1t4091-4</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4091-5">
   <w.rf>
    <LM>w#w-d1t4091-5</LM>
   </w.rf>
   <form>nevěsta</form>
   <lemma>nevěsta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d-m-d1e4062-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4062-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4092-x2">
  <m id="m033-d1t4097-3">
   <w.rf>
    <LM>w#w-d1t4097-3</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4097-4">
   <w.rf>
    <LM>w#w-d1t4097-4</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4097-2">
   <w.rf>
    <LM>w#w-d1t4097-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4097-5">
   <w.rf>
    <LM>w#w-d1t4097-5</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4099-1">
   <w.rf>
    <LM>w#w-d1t4099-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4097-6">
   <w.rf>
    <LM>w#w-d1t4097-6</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d-m-d1e4092-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4092-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4107-x2">
  <m id="m033-d1t4118-3">
   <w.rf>
    <LM>w#w-d1t4118-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4118-5">
   <w.rf>
    <LM>w#w-d1t4118-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4118-6">
   <w.rf>
    <LM>w#w-d1t4118-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t4118-7">
   <w.rf>
    <LM>w#w-d1t4118-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m033-d1t4118-8">
   <w.rf>
    <LM>w#w-d1t4118-8</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d1t4118-9">
   <w.rf>
    <LM>w#w-d1t4118-9</LM>
   </w.rf>
   <form>dívá</form>
   <lemma>dívat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4118-10">
   <w.rf>
    <LM>w#w-d1t4118-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4118-11">
   <w.rf>
    <LM>w#w-d1t4118-11</LM>
   </w.rf>
   <form>odstupem</form>
   <lemma>odstup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m033-d1e4107-x2-189">
   <w.rf>
    <LM>w#w-d1e4107-x2-189</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1e4107-x2-190">
   <w.rf>
    <LM>w#w-d1e4107-x2-190</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4114-6">
   <w.rf>
    <LM>w#w-d1t4114-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4114-7">
   <w.rf>
    <LM>w#w-d1t4114-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m033-d1t4114-11">
   <w.rf>
    <LM>w#w-d1t4114-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m033-d1t4114-12">
   <w.rf>
    <LM>w#w-d1t4114-12</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m033-d1t4114-13">
   <w.rf>
    <LM>w#w-d1t4114-13</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m033-d1t4114-1">
   <w.rf>
    <LM>w#w-d1t4114-1</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m033-d-id201644-punct">
   <w.rf>
    <LM>w#w-d-id201644-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4114-5">
   <w.rf>
    <LM>w#w-d1t4114-5</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m033-d1e4107-x2-167">
   <w.rf>
    <LM>w#w-d1e4107-x2-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4122-x2">
  <m id="m033-d1t4127-1">
   <w.rf>
    <LM>w#w-d1t4127-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m033-d1e4122-x2-191">
   <w.rf>
    <LM>w#w-d1e4122-x2-191</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4127-2">
   <w.rf>
    <LM>w#w-d1t4127-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m033-d1t4127-3">
   <w.rf>
    <LM>w#w-d1t4127-3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m033-d1t4127-4">
   <w.rf>
    <LM>w#w-d1t4127-4</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m033-d1t4127-5">
   <w.rf>
    <LM>w#w-d1t4127-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m033-d1t4127-6">
   <w.rf>
    <LM>w#w-d1t4127-6</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m033-d1t4127-10">
   <w.rf>
    <LM>w#w-d1t4127-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4127-11">
   <w.rf>
    <LM>w#w-d1t4127-11</LM>
   </w.rf>
   <form>pověděl</form>
   <lemma>povědět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m033-d-m-d1e4122-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4122-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4122-x3">
  <m id="m033-d1t4131-1">
   <w.rf>
    <LM>w#w-d1t4131-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m033-d-m-d1e4122-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4122-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4132-x2">
  <m id="m033-d1t4135-3">
   <w.rf>
    <LM>w#w-d1t4135-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m033-d1t4135-2">
   <w.rf>
    <LM>w#w-d1t4135-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4135-4">
   <w.rf>
    <LM>w#w-d1t4135-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d-m-d1e4132-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4132-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4136-x2">
  <m id="m033-d1t4139-1">
   <w.rf>
    <LM>w#w-d1t4139-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d-m-d1e4136-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4136-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4140-x2">
  <m id="m033-d1t4143-1">
   <w.rf>
    <LM>w#w-d1t4143-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m033-d1t4143-2">
   <w.rf>
    <LM>w#w-d1t4143-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4143-3">
   <w.rf>
    <LM>w#w-d1t4143-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4143-4">
   <w.rf>
    <LM>w#w-d1t4143-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m033-d1t4143-5">
   <w.rf>
    <LM>w#w-d1t4143-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m033-d-id202496-punct">
   <w.rf>
    <LM>w#w-d-id202496-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4144-x2">
  <m id="m033-d1t4147-2">
   <w.rf>
    <LM>w#w-d1t4147-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4147-3">
   <w.rf>
    <LM>w#w-d1t4147-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m033-d1t4147-4">
   <w.rf>
    <LM>w#w-d1t4147-4</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m033-d1t4147-5">
   <w.rf>
    <LM>w#w-d1t4147-5</LM>
   </w.rf>
   <form>báječný</form>
   <lemma>báječný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m033-d1t4147-6">
   <w.rf>
    <LM>w#w-d1t4147-6</LM>
   </w.rf>
   <form>dědeček</form>
   <lemma>dědeček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d1t4147-7">
   <w.rf>
    <LM>w#w-d1t4147-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t4147-8">
   <w.rf>
    <LM>w#w-d1t4147-8</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m033-d1t4147-9">
   <w.rf>
    <LM>w#w-d1t4147-9</LM>
   </w.rf>
   <form>báječná</form>
   <lemma>báječný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4147-10">
   <w.rf>
    <LM>w#w-d1t4147-10</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1e4144-x2-204">
   <w.rf>
    <LM>w#w-d1e4144-x2-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-213">
  <m id="m033-d1t4149-1">
   <w.rf>
    <LM>w#w-d1t4149-1</LM>
   </w.rf>
   <form>Jmenovali</form>
   <lemma>jmenovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m033-d1t4149-2">
   <w.rf>
    <LM>w#w-d1t4149-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m033-d1t4149-4">
   <w.rf>
    <LM>w#w-d1t4149-4</LM>
   </w.rf>
   <form>Slívovi</form>
   <lemma>Slívův_;Y_^(*2a)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m033-213-224">
   <w.rf>
    <LM>w#w-213-224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4151-1">
   <w.rf>
    <LM>w#w-d1t4151-1</LM>
   </w.rf>
   <form>dědeček</form>
   <lemma>dědeček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d1t4151-3">
   <w.rf>
    <LM>w#w-d1t4151-3</LM>
   </w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m033-d-id202836-punct">
   <w.rf>
    <LM>w#w-d-id202836-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4153-1">
   <w.rf>
    <LM>w#w-d1t4153-1</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4153-3">
   <w.rf>
    <LM>w#w-d1t4153-3</LM>
   </w.rf>
   <form>Barunka</form>
   <lemma>Barunka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-213-225">
   <w.rf>
    <LM>w#w-213-225</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-228">
  <m id="m033-d1t4158-3">
   <w.rf>
    <LM>w#w-d1t4158-3</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t4158-4">
   <w.rf>
    <LM>w#w-d1t4158-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-228-234">
   <w.rf>
    <LM>w#w-228-234</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m033-d1t4158-7">
   <w.rf>
    <LM>w#w-d1t4158-7</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS7---------1</tag>
  </m>
  <m id="m033-d1t4158-9">
   <w.rf>
    <LM>w#w-d1t4158-9</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m033-d1t4158-11">
   <w.rf>
    <LM>w#w-d1t4158-11</LM>
   </w.rf>
   <form>Hanou</form>
   <lemma>Hana_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m033-d-m-d1e4144-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4144-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4171-x2">
  <m id="m033-d1t4166-5">
   <w.rf>
    <LM>w#w-d1t4166-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4166-4">
   <w.rf>
    <LM>w#w-d1t4166-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4174-1">
   <w.rf>
    <LM>w#w-d1t4174-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m033-d1t4174-16">
   <w.rf>
    <LM>w#w-d1t4174-16</LM>
   </w.rf>
   <form>rodinného</form>
   <lemma>rodinný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m033-d1t4174-2">
   <w.rf>
    <LM>w#w-d1t4174-2</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m033-d1t4174-6">
   <w.rf>
    <LM>w#w-d1t4174-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4174-7">
   <w.rf>
    <LM>w#w-d1t4174-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4174-9">
   <w.rf>
    <LM>w#w-d1t4174-9</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m033-d1t4174-12">
   <w.rf>
    <LM>w#w-d1t4174-12</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4174-13">
   <w.rf>
    <LM>w#w-d1t4174-13</LM>
   </w.rf>
   <form>Záhorskem</form>
   <lemma>Záhorsko_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m033-d1e4171-x2-242">
   <w.rf>
    <LM>w#w-d1e4171-x2-242</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4174-3">
   <w.rf>
    <LM>w#w-d1t4174-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m033-d1t4174-4">
   <w.rf>
    <LM>w#w-d1t4174-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m033-d1t4174-5">
   <w.rf>
    <LM>w#w-d1t4174-5</LM>
   </w.rf>
   <form>bydlíval</form>
   <lemma>bydlívat_^(*4et)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m033-d-m-d1e4171-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4171-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4177-x2">
  <m id="m033-d1e4177-x2-262">
   <w.rf>
    <LM>w#w-d1e4177-x2-262</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1e4177-x2-263">
   <w.rf>
    <LM>w#w-d1e4177-x2-263</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4182-1">
   <w.rf>
    <LM>w#w-d1t4182-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4182-2">
   <w.rf>
    <LM>w#w-d1t4182-2</LM>
   </w.rf>
   <form>zahradě</form>
   <lemma>zahrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m033-d1t4182-3">
   <w.rf>
    <LM>w#w-d1t4182-3</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4182-4">
   <w.rf>
    <LM>w#w-d1t4182-4</LM>
   </w.rf>
   <form>domem</form>
   <lemma>dům</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m033-d-m-d1e4177-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4177-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4177-x3">
  <m id="m033-d1t4184-1">
   <w.rf>
    <LM>w#w-d1t4184-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4184-2">
   <w.rf>
    <LM>w#w-d1t4184-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4184-3">
   <w.rf>
    <LM>w#w-d1t4184-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d-id203677-punct">
   <w.rf>
    <LM>w#w-d-id203677-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4186-x2">
  <m id="m033-d1t4191-1">
   <w.rf>
    <LM>w#w-d1t4191-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4191-2">
   <w.rf>
    <LM>w#w-d1t4191-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4191-3">
   <w.rf>
    <LM>w#w-d1t4191-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4195-1">
   <w.rf>
    <LM>w#w-d1t4195-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4195-3">
   <w.rf>
    <LM>w#w-d1t4195-3</LM>
   </w.rf>
   <form>Karlovarské</form>
   <lemma>karlovarský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m033-d-id203787-punct">
   <w.rf>
    <LM>w#w-d-id203787-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4193-3">
   <w.rf>
    <LM>w#w-d1t4193-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m033-d1t4193-4">
   <w.rf>
    <LM>w#w-d1t4193-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4195-7">
   <w.rf>
    <LM>w#w-d1t4195-7</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4195-8">
   <w.rf>
    <LM>w#w-d1t4195-8</LM>
   </w.rf>
   <form>Záhorskem</form>
   <lemma>Záhorsko_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m033-d1e4186-x2-12">
   <w.rf>
    <LM>w#w-d1e4186-x2-12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1t4193-1">
   <w.rf>
    <LM>w#w-d1t4193-1</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m033-d1t4193-2">
   <w.rf>
    <LM>w#w-d1t4193-2</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m033-d1e4186-x2-41">
   <w.rf>
    <LM>w#w-d1e4186-x2-41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-43">
  <m id="m033-d1t4197-6">
   <w.rf>
    <LM>w#w-d1t4197-6</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4197-9">
   <w.rf>
    <LM>w#w-d1t4197-9</LM>
   </w.rf>
   <form>Bolevecké</form>
   <lemma>bolevecký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m033-d1t4197-2">
   <w.rf>
    <LM>w#w-d1t4197-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4197-4">
   <w.rf>
    <LM>w#w-d1t4197-4</LM>
   </w.rf>
   <form>vysokoškolské</form>
   <lemma>vysokoškolský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m033-d1t4197-5">
   <w.rf>
    <LM>w#w-d1t4197-5</LM>
   </w.rf>
   <form>koleje</form>
   <lemma>kolej</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m033-d1t4197-11">
   <w.rf>
    <LM>w#w-d1t4197-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m033-d1t4197-15">
   <w.rf>
    <LM>w#w-d1t4197-15</LM>
   </w.rf>
   <form>příčná</form>
   <lemma>příčný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4197-16">
   <w.rf>
    <LM>w#w-d1t4197-16</LM>
   </w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4197-13">
   <w.rf>
    <LM>w#w-d1t4197-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4197-18">
   <w.rf>
    <LM>w#w-d1t4197-18</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4197-19">
   <w.rf>
    <LM>w#w-d1t4197-19</LM>
   </w.rf>
   <form>Záhorskem</form>
   <lemma>Záhorsko_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m033-43-44">
   <w.rf>
    <LM>w#w-43-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m033-d1e4198-x2">
  <m id="m033-d1e4198-x2-46">
   <w.rf>
    <LM>w#w-d1e4198-x2-46</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m033-d1t4205-3">
   <w.rf>
    <LM>w#w-d1t4205-3</LM>
   </w.rf>
   <form>Karlovarské</form>
   <lemma>karlovarský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m033-d1t4207-2">
   <w.rf>
    <LM>w#w-d1t4207-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1t4207-3">
   <w.rf>
    <LM>w#w-d1t4207-3</LM>
   </w.rf>
   <form>benzinová</form>
   <lemma>benzinový_,s_^(^DD**benzínový)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m033-d1t4207-4">
   <w.rf>
    <LM>w#w-d1t4207-4</LM>
   </w.rf>
   <form>pumpa</form>
   <lemma>pumpa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m033-d1t4207-6">
   <w.rf>
    <LM>w#w-d1t4207-6</LM>
   </w.rf>
   <form>Shell</form>
   <lemma>Shell-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m033-d-id204527-punct">
   <w.rf>
    <LM>w#w-d-id204527-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m033-d1e4198-x2-47">
   <w.rf>
    <LM>w#w-d1e4198-x2-47</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m033-d1e4198-x2-48">
   <w.rf>
    <LM>w#w-d1e4198-x2-48</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m033-d1t4209-6">
   <w.rf>
    <LM>w#w-d1t4209-6</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m033-d1t4209-8">
   <w.rf>
    <LM>w#w-d1t4209-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m033-d1t4209-9">
   <w.rf>
    <LM>w#w-d1t4209-9</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m033-d-m-d1e4198-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4198-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
