<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pk_143.09.w.gz" />
  </references>
 </head>
 <s id="m143-288">
  <m id="m143-d1t2514-7">
   <w.rf>
    <LM>w#w-d1t2514-7</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m143-d-id162657-punct">
   <w.rf>
    <LM>w#w-d-id162657-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2514-9">
   <w.rf>
    <LM>w#w-d1t2514-9</LM>
   </w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2514-10">
   <w.rf>
    <LM>w#w-d1t2514-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2514-11">
   <w.rf>
    <LM>w#w-d1t2514-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2516-1">
   <w.rf>
    <LM>w#w-d1t2516-1</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m143-d1t2516-2">
   <w.rf>
    <LM>w#w-d1t2516-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2516-3">
   <w.rf>
    <LM>w#w-d1t2516-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2516-5">
   <w.rf>
    <LM>w#w-d1t2516-5</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2516-6">
   <w.rf>
    <LM>w#w-d1t2516-6</LM>
   </w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m143-d1t2516-7">
   <w.rf>
    <LM>w#w-d1t2516-7</LM>
   </w.rf>
   <form>odstupem</form>
   <lemma>odstup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m143-d1t2516-8">
   <w.rf>
    <LM>w#w-d1t2516-8</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2516-9">
   <w.rf>
    <LM>w#w-d1t2516-9</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m143-d1t2516-10">
   <w.rf>
    <LM>w#w-d1t2516-10</LM>
   </w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m143-d-id162876-punct">
   <w.rf>
    <LM>w#w-d-id162876-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2516-13">
   <w.rf>
    <LM>w#w-d1t2516-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2516-14">
   <w.rf>
    <LM>w#w-d1t2516-14</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2516-15">
   <w.rf>
    <LM>w#w-d1t2516-15</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m143-d1t2516-16">
   <w.rf>
    <LM>w#w-d1t2516-16</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP4----2A----</tag>
  </m>
  <m id="m143-d-id162971-punct">
   <w.rf>
    <LM>w#w-d-id162971-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2521-1">
   <w.rf>
    <LM>w#w-d1t2521-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2523-1">
   <w.rf>
    <LM>w#w-d1t2523-1</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m143-d1t2523-2">
   <w.rf>
    <LM>w#w-d1t2523-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2523-3">
   <w.rf>
    <LM>w#w-d1t2523-3</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m143-d1t2523-4">
   <w.rf>
    <LM>w#w-d1t2523-4</LM>
   </w.rf>
   <form>mladé</form>
   <lemma>mladý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m143-288-289">
   <w.rf>
    <LM>w#w-288-289</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-290">
  <m id="m143-d1t2523-8">
   <w.rf>
    <LM>w#w-d1t2523-8</LM>
   </w.rf>
   <form>Narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m143-d1t2523-7">
   <w.rf>
    <LM>w#w-d1t2523-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2523-9">
   <w.rf>
    <LM>w#w-d1t2523-9</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m143-d-id163152-punct">
   <w.rf>
    <LM>w#w-d-id163152-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2523-11">
   <w.rf>
    <LM>w#w-d1t2523-11</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS3----------</tag>
  </m>
  <m id="m143-d1t2523-12">
   <w.rf>
    <LM>w#w-d1t2523-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2523-13">
   <w.rf>
    <LM>w#w-d1t2523-13</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2523-15">
   <w.rf>
    <LM>w#w-d1t2523-15</LM>
   </w.rf>
   <form>necelých</form>
   <lemma>celý</lemma>
   <tag>AANP2----1N----</tag>
  </m>
  <m id="m143-d1t2523-16">
   <w.rf>
    <LM>w#w-d1t2523-16</LM>
   </w.rf>
   <form>osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m143-d1t2523-17">
   <w.rf>
    <LM>w#w-d1t2523-17</LM>
   </w.rf>
   <form>roků</form>
   <lemma>rok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m143-290-291">
   <w.rf>
    <LM>w#w-290-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-292">
  <m id="m143-d1t2523-19">
   <w.rf>
    <LM>w#w-d1t2523-19</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m143-d1t2523-20">
   <w.rf>
    <LM>w#w-d1t2523-20</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2523-21">
   <w.rf>
    <LM>w#w-d1t2523-21</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2523-22">
   <w.rf>
    <LM>w#w-d1t2523-22</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2523-23">
   <w.rf>
    <LM>w#w-d1t2523-23</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m143-d1t2523-24">
   <w.rf>
    <LM>w#w-d1t2523-24</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m143-d1t2523-27">
   <w.rf>
    <LM>w#w-d1t2523-27</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m143-d1t2523-25">
   <w.rf>
    <LM>w#w-d1t2523-25</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2523-26">
   <w.rf>
    <LM>w#w-d1t2523-26</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-292-688">
   <w.rf>
    <LM>w#w-292-688</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-689">
  <m id="m143-d1t2525-1">
   <w.rf>
    <LM>w#w-d1t2525-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2525-2">
   <w.rf>
    <LM>w#w-d1t2525-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2525-4">
   <w.rf>
    <LM>w#w-d1t2525-4</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m143-d-id163498-punct">
   <w.rf>
    <LM>w#w-d-id163498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2525-6">
   <w.rf>
    <LM>w#w-d1t2525-6</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2525-7">
   <w.rf>
    <LM>w#w-d1t2525-7</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m143-d1t2525-8">
   <w.rf>
    <LM>w#w-d1t2525-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2525-9">
   <w.rf>
    <LM>w#w-d1t2525-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2525-10">
   <w.rf>
    <LM>w#w-d1t2525-10</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2525-11">
   <w.rf>
    <LM>w#w-d1t2525-11</LM>
   </w.rf>
   <form>dvacítky</form>
   <lemma>dvacítka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m143-d-id163609-punct">
   <w.rf>
    <LM>w#w-d-id163609-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2529-2">
   <w.rf>
    <LM>w#w-d1t2529-2</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9XP1FS3-------</tag>
  </m>
  <m id="m143-d1t2529-3">
   <w.rf>
    <LM>w#w-d1t2529-3</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m143-d1t2529-4">
   <w.rf>
    <LM>w#w-d1t2529-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2529-5">
   <w.rf>
    <LM>w#w-d1t2529-5</LM>
   </w.rf>
   <form>těsně</form>
   <lemma>těsně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2529-6">
   <w.rf>
    <LM>w#w-d1t2529-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2529-7">
   <w.rf>
    <LM>w#w-d1t2529-7</LM>
   </w.rf>
   <form>čtyřiceti</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m143-d1t2529-8">
   <w.rf>
    <LM>w#w-d1t2529-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2529-9">
   <w.rf>
    <LM>w#w-d1t2529-9</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2529-10">
   <w.rf>
    <LM>w#w-d1t2529-10</LM>
   </w.rf>
   <form>čtyřiceti</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m143-d1t2529-11">
   <w.rf>
    <LM>w#w-d1t2529-11</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m143-292-314">
   <w.rf>
    <LM>w#w-292-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-313">
  <m id="m143-d1t2531-2">
   <w.rf>
    <LM>w#w-d1t2531-2</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2531-3">
   <w.rf>
    <LM>w#w-d1t2531-3</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2531-4">
   <w.rf>
    <LM>w#w-d1t2531-4</LM>
   </w.rf>
   <form>společenští</form>
   <lemma>společenský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m143-313-315">
   <w.rf>
    <LM>w#w-313-315</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-317">
  <m id="m143-d1t2534-1">
   <w.rf>
    <LM>w#w-d1t2534-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d-id163948-punct">
   <w.rf>
    <LM>w#w-d-id163948-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2534-3">
   <w.rf>
    <LM>w#w-d1t2534-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2534-4">
   <w.rf>
    <LM>w#w-d1t2534-4</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-317-318">
   <w.rf>
    <LM>w#w-317-318</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-317-319">
   <w.rf>
    <LM>w#w-317-319</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2534-5">
   <w.rf>
    <LM>w#w-d1t2534-5</LM>
   </w.rf>
   <form>Přijeďte</form>
   <lemma>přijet</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m143-d1t2534-6">
   <w.rf>
    <LM>w#w-d1t2534-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2534-7">
   <w.rf>
    <LM>w#w-d1t2534-7</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m143-317-320">
   <w.rf>
    <LM>w#w-317-320</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2534-11">
   <w.rf>
    <LM>w#w-d1t2534-11</LM>
   </w.rf>
   <form>provedeme</form>
   <lemma>provést</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m143-d1t2534-9">
   <w.rf>
    <LM>w#w-d1t2534-9</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m143-d1t2534-10">
   <w.rf>
    <LM>w#w-d1t2534-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-317-321">
   <w.rf>
    <LM>w#w-317-321</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-317-322">
   <w.rf>
    <LM>w#w-317-322</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-323">
  <m id="m143-d1t2538-5">
   <w.rf>
    <LM>w#w-d1t2538-5</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2538-2">
   <w.rf>
    <LM>w#w-d1t2538-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2542-2">
   <w.rf>
    <LM>w#w-d1t2542-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2538-3">
   <w.rf>
    <LM>w#w-d1t2538-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2538-4">
   <w.rf>
    <LM>w#w-d1t2538-4</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m143-d1t2542-1">
   <w.rf>
    <LM>w#w-d1t2542-1</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-d1t2542-4">
   <w.rf>
    <LM>w#w-d1t2542-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2542-6">
   <w.rf>
    <LM>w#w-d1t2542-6</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m143-d-id164326-punct">
   <w.rf>
    <LM>w#w-d-id164326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2542-8">
   <w.rf>
    <LM>w#w-d1t2542-8</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2542-9">
   <w.rf>
    <LM>w#w-d1t2542-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2542-10">
   <w.rf>
    <LM>w#w-d1t2542-10</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2542-11">
   <w.rf>
    <LM>w#w-d1t2542-11</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2544-1">
   <w.rf>
    <LM>w#w-d1t2544-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2544-2">
   <w.rf>
    <LM>w#w-d1t2544-2</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m143-d1t2544-3">
   <w.rf>
    <LM>w#w-d1t2544-3</LM>
   </w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m143-323-335">
   <w.rf>
    <LM>w#w-323-335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2545-x2">
  <m id="m143-d1t2550-1">
   <w.rf>
    <LM>w#w-d1t2550-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2550-2">
   <w.rf>
    <LM>w#w-d1t2550-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1e2545-x2-336">
   <w.rf>
    <LM>w#w-d1e2545-x2-336</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2550-3">
   <w.rf>
    <LM>w#w-d1t2550-3</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2552-1">
   <w.rf>
    <LM>w#w-d1t2552-1</LM>
   </w.rf>
   <form>pobavit</form>
   <lemma>pobavit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-d-m-d1e2545-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2545-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2545-x3">
  <m id="m143-d1t2554-1">
   <w.rf>
    <LM>w#w-d1t2554-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m143-d1t2554-2">
   <w.rf>
    <LM>w#w-d1t2554-2</LM>
   </w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m143-d1t2554-3">
   <w.rf>
    <LM>w#w-d1t2554-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m143-d1t2554-4">
   <w.rf>
    <LM>w#w-d1t2554-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2554-5">
   <w.rf>
    <LM>w#w-d1t2554-5</LM>
   </w.rf>
   <form>navštívili</form>
   <lemma>navštívit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d-id164714-punct">
   <w.rf>
    <LM>w#w-d-id164714-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2555-x2">
  <m id="m143-d1t2562-1">
   <w.rf>
    <LM>w#w-d1t2562-1</LM>
   </w.rf>
   <form>Přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2560-1">
   <w.rf>
    <LM>w#w-d1t2560-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2562-7">
   <w.rf>
    <LM>w#w-d1t2562-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2562-8">
   <w.rf>
    <LM>w#w-d1t2562-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2562-10">
   <w.rf>
    <LM>w#w-d1t2562-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2562-11">
   <w.rf>
    <LM>w#w-d1t2562-11</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-d1t2562-4">
   <w.rf>
    <LM>w#w-d1t2562-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1e2555-x2-1962">
   <w.rf>
    <LM>w#w-d1e2555-x2-1962</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2562-6">
   <w.rf>
    <LM>w#w-d1t2562-6</LM>
   </w.rf>
   <form>prameny</form>
   <lemma>pramen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m143-d-id164987-punct">
   <w.rf>
    <LM>w#w-d-id164987-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2564-1">
   <w.rf>
    <LM>w#w-d1t2564-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2564-2">
   <w.rf>
    <LM>w#w-d1t2564-2</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2564-3">
   <w.rf>
    <LM>w#w-d1t2564-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2564-4">
   <w.rf>
    <LM>w#w-d1t2564-4</LM>
   </w.rf>
   <form>nedalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m143-d1t2564-5">
   <w.rf>
    <LM>w#w-d1t2564-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m143-d1t2564-6">
   <w.rf>
    <LM>w#w-d1t2564-6</LM>
   </w.rf>
   <form>stihnout</form>
   <lemma>stihnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-d1e2555-x2-1963">
   <w.rf>
    <LM>w#w-d1e2555-x2-1963</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-1964">
  <m id="m143-d1t2566-2">
   <w.rf>
    <LM>w#w-d1t2566-2</LM>
   </w.rf>
   <form>Stavili</form>
   <lemma>stavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d1t2566-3">
   <w.rf>
    <LM>w#w-d1t2566-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2566-4">
   <w.rf>
    <LM>w#w-d1t2566-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2566-5">
   <w.rf>
    <LM>w#w-d1t2566-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2566-7">
   <w.rf>
    <LM>w#w-d1t2566-7</LM>
   </w.rf>
   <form>Karlových</form>
   <lemma>Karlův_;Y_^(*2)_(*3el)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m143-d1t2566-8">
   <w.rf>
    <LM>w#w-d1t2566-8</LM>
   </w.rf>
   <form>Varech</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m143-1964-1965">
   <w.rf>
    <LM>w#w-1964-1965</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-1966">
  <m id="m143-d1t2569-1">
   <w.rf>
    <LM>w#w-d1t2569-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2569-2">
   <w.rf>
    <LM>w#w-d1t2569-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2569-3">
   <w.rf>
    <LM>w#w-d1t2569-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2569-4">
   <w.rf>
    <LM>w#w-d1t2569-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2569-5">
   <w.rf>
    <LM>w#w-d1t2569-5</LM>
   </w.rf>
   <form>podívali</form>
   <lemma>podívat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d1t2569-6">
   <w.rf>
    <LM>w#w-d1t2569-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2569-7">
   <w.rf>
    <LM>w#w-d1t2569-7</LM>
   </w.rf>
   <form>kolonádu</form>
   <lemma>kolonáda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m143-1966-1967">
   <w.rf>
    <LM>w#w-1966-1967</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-1968">
  <m id="m143-d1t2571-3">
   <w.rf>
    <LM>w#w-d1t2571-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2571-4">
   <w.rf>
    <LM>w#w-d1t2571-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2571-2">
   <w.rf>
    <LM>w#w-d1t2571-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2571-7">
   <w.rf>
    <LM>w#w-d1t2571-7</LM>
   </w.rf>
   <form>nedalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m143-d1t2573-1">
   <w.rf>
    <LM>w#w-d1t2573-1</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m143-d1t2573-2">
   <w.rf>
    <LM>w#w-d1t2573-2</LM>
   </w.rf>
   <form>projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-1968-1969">
   <w.rf>
    <LM>w#w-1968-1969</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-1970">
  <m id="m143-d1t2573-5">
   <w.rf>
    <LM>w#w-d1t2573-5</LM>
   </w.rf>
   <form>Projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m143-d1t2573-6">
   <w.rf>
    <LM>w#w-d1t2573-6</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d-id165681-punct">
   <w.rf>
    <LM>w#w-d-id165681-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2573-10">
   <w.rf>
    <LM>w#w-d1t2573-10</LM>
   </w.rf>
   <form>lázně</form>
   <lemma>lázně</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m143-1970-1971">
   <w.rf>
    <LM>w#w-1970-1971</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2573-11">
   <w.rf>
    <LM>w#w-d1t2573-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2575-1">
   <w.rf>
    <LM>w#w-d1t2575-1</LM>
   </w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m143-d1t2575-3">
   <w.rf>
    <LM>w#w-d1t2575-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2575-4">
   <w.rf>
    <LM>w#w-d1t2575-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m143-d1t2575-5">
   <w.rf>
    <LM>w#w-d1t2575-5</LM>
   </w.rf>
   <form>nepamatuji</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI-1</tag>
  </m>
  <m id="m143-d-id165838-punct">
   <w.rf>
    <LM>w#w-d-id165838-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2575-7">
   <w.rf>
    <LM>w#w-d1t2575-7</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2575-9">
   <w.rf>
    <LM>w#w-d1t2575-9</LM>
   </w.rf>
   <form>prameny</form>
   <lemma>pramen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m143-1970-2002">
   <w.rf>
    <LM>w#w-1970-2002</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2003">
  <m id="m143-d1t2575-12">
   <w.rf>
    <LM>w#w-d1t2575-12</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2575-13">
   <w.rf>
    <LM>w#w-d1t2575-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2575-14">
   <w.rf>
    <LM>w#w-d1t2575-14</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2575-15">
   <w.rf>
    <LM>w#w-d1t2575-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2575-16">
   <w.rf>
    <LM>w#w-d1t2575-16</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2575-17">
   <w.rf>
    <LM>w#w-d1t2575-17</LM>
   </w.rf>
   <form>roků</form>
   <lemma>rok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m143-d-id166010-punct">
   <w.rf>
    <LM>w#w-d-id166010-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2579-2">
   <w.rf>
    <LM>w#w-d1t2579-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2584-1">
   <w.rf>
    <LM>w#w-d1t2584-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m143-d1t2584-5">
   <w.rf>
    <LM>w#w-d1t2584-5</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m143-2003-2004">
   <w.rf>
    <LM>w#w-2003-2004</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2005">
  <m id="m143-d1t2586-2">
   <w.rf>
    <LM>w#w-d1t2586-2</LM>
   </w.rf>
   <form>Památky</form>
   <lemma>památka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m143-d1t2584-7">
   <w.rf>
    <LM>w#w-d1t2584-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2586-3">
   <w.rf>
    <LM>w#w-d1t2586-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2586-5">
   <w.rf>
    <LM>w#w-d1t2586-5</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m143-2005-2006">
   <w.rf>
    <LM>w#w-2005-2006</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2007">
  <m id="m143-d1t2586-8">
   <w.rf>
    <LM>w#w-d1t2586-8</LM>
   </w.rf>
   <form>Šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2586-7">
   <w.rf>
    <LM>w#w-d1t2586-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2586-9">
   <w.rf>
    <LM>w#w-d1t2586-9</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2586-10">
   <w.rf>
    <LM>w#w-d1t2586-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m143-d-id166397-punct">
   <w.rf>
    <LM>w#w-d-id166397-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2586-12">
   <w.rf>
    <LM>w#w-d1t2586-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2586-13">
   <w.rf>
    <LM>w#w-d1t2586-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2586-14">
   <w.rf>
    <LM>w#w-d1t2586-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2586-15">
   <w.rf>
    <LM>w#w-d1t2586-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2586-16">
   <w.rf>
    <LM>w#w-d1t2586-16</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m143-d1t2586-18">
   <w.rf>
    <LM>w#w-d1t2586-18</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2586-19">
   <w.rf>
    <LM>w#w-d1t2586-19</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m143-d1t2586-20">
   <w.rf>
    <LM>w#w-d1t2586-20</LM>
   </w.rf>
   <form>letních</form>
   <lemma>letní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m143-d1t2586-21">
   <w.rf>
    <LM>w#w-d1t2586-21</LM>
   </w.rf>
   <form>šatů</form>
   <lemma>šaty</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m143-2007-2008">
   <w.rf>
    <LM>w#w-2007-2008</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2009">
  <m id="m143-d1t2590-1">
   <w.rf>
    <LM>w#w-d1t2590-1</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-d-id166705-punct">
   <w.rf>
    <LM>w#w-d-id166705-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2590-3">
   <w.rf>
    <LM>w#w-d1t2590-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2590-4">
   <w.rf>
    <LM>w#w-d1t2590-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2590-5">
   <w.rf>
    <LM>w#w-d1t2590-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2590-6">
   <w.rf>
    <LM>w#w-d1t2590-6</LM>
   </w.rf>
   <form>koupali</form>
   <lemma>koupat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2590-7">
   <w.rf>
    <LM>w#w-d1t2590-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2590-8">
   <w.rf>
    <LM>w#w-d1t2590-8</LM>
   </w.rf>
   <form>přehradě</form>
   <lemma>přehrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m143-d1t2592-1">
   <w.rf>
    <LM>w#w-d1t2592-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2592-3">
   <w.rf>
    <LM>w#w-d1t2592-3</LM>
   </w.rf>
   <form>Karlových</form>
   <lemma>Karlův_;Y_^(*2)_(*3el)</lemma>
   <tag>AUIP2M---------</tag>
  </m>
  <m id="m143-d1t2592-4">
   <w.rf>
    <LM>w#w-d1t2592-4</LM>
   </w.rf>
   <form>Varů</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m143-2009-2011">
   <w.rf>
    <LM>w#w-2009-2011</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2044">
  <m id="m143-d1t2595-1">
   <w.rf>
    <LM>w#w-d1t2595-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2595-2">
   <w.rf>
    <LM>w#w-d1t2595-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2595-6">
   <w.rf>
    <LM>w#w-d1t2595-6</LM>
   </w.rf>
   <form>přehrada</form>
   <lemma>přehrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2044-2045">
   <w.rf>
    <LM>w#w-2044-2045</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2046">
  <m id="m143-d1t2597-3">
   <w.rf>
    <LM>w#w-d1t2597-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2597-4">
   <w.rf>
    <LM>w#w-d1t2597-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2597-5">
   <w.rf>
    <LM>w#w-d1t2597-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2597-6">
   <w.rf>
    <LM>w#w-d1t2597-6</LM>
   </w.rf>
   <form>vykoupali</form>
   <lemma>vykoupat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-2046-2047">
   <w.rf>
    <LM>w#w-2046-2047</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2048">
  <m id="m143-d1t2597-7">
   <w.rf>
    <LM>w#w-d1t2597-7</LM>
   </w.rf>
   <form>Zastavili</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d1t2597-8">
   <w.rf>
    <LM>w#w-d1t2597-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2597-9">
   <w.rf>
    <LM>w#w-d1t2597-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2597-10">
   <w.rf>
    <LM>w#w-d1t2597-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d-id167161-punct">
   <w.rf>
    <LM>w#w-d-id167161-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2599-1">
   <w.rf>
    <LM>w#w-d1t2599-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2601-1">
   <w.rf>
    <LM>w#w-d1t2601-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2601-2">
   <w.rf>
    <LM>w#w-d1t2601-2</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2601-3">
   <w.rf>
    <LM>w#w-d1t2601-3</LM>
   </w.rf>
   <form>autem</form>
   <lemma>auto</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m143-2048-2049">
   <w.rf>
    <LM>w#w-2048-2049</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2050">
  <m id="m143-d1t2601-4">
   <w.rf>
    <LM>w#w-d1t2601-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2601-5">
   <w.rf>
    <LM>w#w-d1t2601-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2603-5">
   <w.rf>
    <LM>w#w-d1t2603-5</LM>
   </w.rf>
   <form>Spartak</form>
   <lemma>Spartak-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-d1t2605-1">
   <w.rf>
    <LM>w#w-d1t2605-1</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2605-2">
   <w.rf>
    <LM>w#w-d1t2605-2</LM>
   </w.rf>
   <form>jejích</form>
   <lemma>jeho</lemma>
   <tag>P9XP2FS3-------</tag>
  </m>
  <m id="m143-d1t2605-3">
   <w.rf>
    <LM>w#w-d1t2605-3</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m143-d-id167411-punct">
   <w.rf>
    <LM>w#w-d-id167411-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2605-5">
   <w.rf>
    <LM>w#w-d1t2605-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m143-d1t2605-6">
   <w.rf>
    <LM>w#w-d1t2605-6</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m143-d1t2605-7">
   <w.rf>
    <LM>w#w-d1t2605-7</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d1t2605-8">
   <w.rf>
    <LM>w#w-d1t2605-8</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2605-9">
   <w.rf>
    <LM>w#w-d1t2605-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2610-1">
   <w.rf>
    <LM>w#w-d1t2610-1</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m143-d1t2605-10">
   <w.rf>
    <LM>w#w-d1t2605-10</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2605-11">
   <w.rf>
    <LM>w#w-d1t2605-11</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m143-2050-2052">
   <w.rf>
    <LM>w#w-2050-2052</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2053">
  <m id="m143-d1t2612-2">
   <w.rf>
    <LM>w#w-d1t2612-2</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m143-d1t2612-3">
   <w.rf>
    <LM>w#w-d1t2612-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2612-4">
   <w.rf>
    <LM>w#w-d1t2612-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m143-d1t2612-5">
   <w.rf>
    <LM>w#w-d1t2612-5</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m143-d1t2612-6">
   <w.rf>
    <LM>w#w-d1t2612-6</LM>
   </w.rf>
   <form>teda</form>
   <lemma>teda-1_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2612-7">
   <w.rf>
    <LM>w#w-d1t2612-7</LM>
   </w.rf>
   <form>půjčili</form>
   <lemma>půjčit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d-id167694-punct">
   <w.rf>
    <LM>w#w-d-id167694-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2612-9">
   <w.rf>
    <LM>w#w-d1t2612-9</LM>
   </w.rf>
   <form>respektive</form>
   <lemma>respektive</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2614-1">
   <w.rf>
    <LM>w#w-d1t2614-1</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m143-d1t2614-2">
   <w.rf>
    <LM>w#w-d1t2614-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m143-d1t2614-3">
   <w.rf>
    <LM>w#w-d1t2614-3</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m143-d1t2614-4">
   <w.rf>
    <LM>w#w-d1t2614-4</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m143-d1t2614-5">
   <w.rf>
    <LM>w#w-d1t2614-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2614-6">
   <w.rf>
    <LM>w#w-d1t2614-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m143-d1t2614-7">
   <w.rf>
    <LM>w#w-d1t2614-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2614-8">
   <w.rf>
    <LM>w#w-d1t2614-8</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2614-9">
   <w.rf>
    <LM>w#w-d1t2614-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2616-1">
   <w.rf>
    <LM>w#w-d1t2616-1</LM>
   </w.rf>
   <form>pasažéři</form>
   <lemma>pasažér</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m143-d1t2616-2">
   <w.rf>
    <LM>w#w-d1t2616-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2616-3">
   <w.rf>
    <LM>w#w-d1t2616-3</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m143-2053-2054">
   <w.rf>
    <LM>w#w-2053-2054</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2055">
  <m id="m143-d1t2621-2">
   <w.rf>
    <LM>w#w-d1t2621-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2621-3">
   <w.rf>
    <LM>w#w-d1t2621-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2621-4">
   <w.rf>
    <LM>w#w-d1t2621-4</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m143-d1t2621-5">
   <w.rf>
    <LM>w#w-d1t2621-5</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-2055-2070">
   <w.rf>
    <LM>w#w-2055-2070</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2071">
  <m id="m143-d1t2621-7">
   <w.rf>
    <LM>w#w-d1t2621-7</LM>
   </w.rf>
   <form>Dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2621-8">
   <w.rf>
    <LM>w#w-d1t2621-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2621-9">
   <w.rf>
    <LM>w#w-d1t2621-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2621-10">
   <w.rf>
    <LM>w#w-d1t2621-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m143-d1t2621-11">
   <w.rf>
    <LM>w#w-d1t2621-11</LM>
   </w.rf>
   <form>vzpomínali</form>
   <lemma>vzpomínat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-2071-2072">
   <w.rf>
    <LM>w#w-2071-2072</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2073">
  <m id="m143-d1t2621-12">
   <w.rf>
    <LM>w#w-d1t2621-12</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2621-13">
   <w.rf>
    <LM>w#w-d1t2621-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2621-14">
   <w.rf>
    <LM>w#w-d1t2621-14</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m143-d1t2621-15">
   <w.rf>
    <LM>w#w-d1t2621-15</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m143-d1t2621-16">
   <w.rf>
    <LM>w#w-d1t2621-16</LM>
   </w.rf>
   <form>fotek</form>
   <lemma>fotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m143-2073-2074">
   <w.rf>
    <LM>w#w-2073-2074</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2075">
  <m id="m143-d1t2621-18">
   <w.rf>
    <LM>w#w-d1t2621-18</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2621-20">
   <w.rf>
    <LM>w#w-d1t2621-20</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2621-21">
   <w.rf>
    <LM>w#w-d1t2621-21</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m143-d1t2623-1">
   <w.rf>
    <LM>w#w-d1t2623-1</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2623-2">
   <w.rf>
    <LM>w#w-d1t2623-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2623-4">
   <w.rf>
    <LM>w#w-d1t2623-4</LM>
   </w.rf>
   <form>lázeňského</form>
   <lemma>lázeňský-2_^(např._dům,_péče,_oplatky)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m143-d1t2623-5">
   <w.rf>
    <LM>w#w-d1t2623-5</LM>
   </w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m143-d-m-d1e2555-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2555-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2624-x3">
  <m id="m143-d1t2633-1">
   <w.rf>
    <LM>w#w-d1t2633-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m143-d-m-d1e2624-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2624-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2634-x2">
  <m id="m143-d1t2637-3">
   <w.rf>
    <LM>w#w-d1t2637-3</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-d1t2637-5">
   <w.rf>
    <LM>w#w-d1t2637-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-d1e2634-x2-2084">
   <w.rf>
    <LM>w#w-d1e2634-x2-2084</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2085">
  <m id="m143-d1t2643-1">
   <w.rf>
    <LM>w#w-d1t2643-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m143-d1t2645-1">
   <w.rf>
    <LM>w#w-d1t2645-1</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2645-2">
   <w.rf>
    <LM>w#w-d1t2645-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d-id168731-punct">
   <w.rf>
    <LM>w#w-d-id168731-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e2646-x2">
  <m id="m143-d1t2649-2">
   <w.rf>
    <LM>w#w-d1t2649-2</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2649-3">
   <w.rf>
    <LM>w#w-d1t2649-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2649-4">
   <w.rf>
    <LM>w#w-d1t2649-4</LM>
   </w.rf>
   <form>dvůr</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-d1t2649-5">
   <w.rf>
    <LM>w#w-d1t2649-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2649-6">
   <w.rf>
    <LM>w#w-d1t2649-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m143-d1t2649-8">
   <w.rf>
    <LM>w#w-d1t2649-8</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1e2646-x2-2093">
   <w.rf>
    <LM>w#w-d1e2646-x2-2093</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2651-1">
   <w.rf>
    <LM>w#w-d1t2651-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2651-2">
   <w.rf>
    <LM>w#w-d1t2651-2</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m143-d1e2646-x2-784">
   <w.rf>
    <LM>w#w-d1e2646-x2-784</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-785">
  <m id="m143-d1t2655-1">
   <w.rf>
    <LM>w#w-d1t2655-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2655-2">
   <w.rf>
    <LM>w#w-d1t2655-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2655-4">
   <w.rf>
    <LM>w#w-d1t2655-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2655-5">
   <w.rf>
    <LM>w#w-d1t2655-5</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m143-d1t2655-6">
   <w.rf>
    <LM>w#w-d1t2655-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2655-7">
   <w.rf>
    <LM>w#w-d1t2655-7</LM>
   </w.rf>
   <form>žila</form>
   <lemma>žít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2655-8">
   <w.rf>
    <LM>w#w-d1t2655-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m143-d1t2655-9">
   <w.rf>
    <LM>w#w-d1t2655-9</LM>
   </w.rf>
   <form>svými</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP7----------</tag>
  </m>
  <m id="m143-d1t2655-10">
   <w.rf>
    <LM>w#w-d1t2655-10</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m143-d1t2655-11">
   <w.rf>
    <LM>w#w-d1t2655-11</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2655-12">
   <w.rf>
    <LM>w#w-d1t2655-12</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2657-1">
   <w.rf>
    <LM>w#w-d1t2657-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2657-2">
   <w.rf>
    <LM>w#w-d1t2657-2</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m143-d1e2646-x2-2094">
   <w.rf>
    <LM>w#w-d1e2646-x2-2094</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2657-3">
   <w.rf>
    <LM>w#w-d1t2657-3</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2657-4">
   <w.rf>
    <LM>w#w-d1t2657-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2657-5">
   <w.rf>
    <LM>w#w-d1t2657-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2657-6">
   <w.rf>
    <LM>w#w-d1t2657-6</LM>
   </w.rf>
   <form>odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m143-d1t2657-7">
   <w.rf>
    <LM>w#w-d1t2657-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2657-8">
   <w.rf>
    <LM>w#w-d1t2657-8</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m143-d1t2657-9">
   <w.rf>
    <LM>w#w-d1t2657-9</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2657-10">
   <w.rf>
    <LM>w#w-d1t2657-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2657-12">
   <w.rf>
    <LM>w#w-d1t2657-12</LM>
   </w.rf>
   <form>Mělníka</form>
   <lemma>Mělník_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m143-d1e2646-x2-2095">
   <w.rf>
    <LM>w#w-d1e2646-x2-2095</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2096">
  <m id="m143-d1t2664-1">
   <w.rf>
    <LM>w#w-d1t2664-1</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2664-3">
   <w.rf>
    <LM>w#w-d1t2664-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2664-4">
   <w.rf>
    <LM>w#w-d1t2664-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m143-d1t2664-5">
   <w.rf>
    <LM>w#w-d1t2664-5</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2096-2098">
   <w.rf>
    <LM>w#w-2096-2098</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2099">
  <m id="m143-d1t2664-7">
   <w.rf>
    <LM>w#w-d1t2664-7</LM>
   </w.rf>
   <form>Vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m143-d1t2664-8">
   <w.rf>
    <LM>w#w-d1t2664-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-2099-2100">
   <w.rf>
    <LM>w#w-2099-2100</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2664-9">
   <w.rf>
    <LM>w#w-d1t2664-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2664-10">
   <w.rf>
    <LM>w#w-d1t2664-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2668-1">
   <w.rf>
    <LM>w#w-d1t2668-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2664-11">
   <w.rf>
    <LM>w#w-d1t2664-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2664-12">
   <w.rf>
    <LM>w#w-d1t2664-12</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m143-d1t2664-13">
   <w.rf>
    <LM>w#w-d1t2664-13</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m143-d1t2668-2">
   <w.rf>
    <LM>w#w-d1t2668-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2668-3">
   <w.rf>
    <LM>w#w-d1t2668-3</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m143-d1t2668-4">
   <w.rf>
    <LM>w#w-d1t2668-4</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-d1t2670-1">
   <w.rf>
    <LM>w#w-d1t2670-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2670-2">
   <w.rf>
    <LM>w#w-d1t2670-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2670-3">
   <w.rf>
    <LM>w#w-d1t2670-3</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-2099-793">
   <w.rf>
    <LM>w#w-2099-793</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2670-5">
   <w.rf>
    <LM>w#w-d1t2670-5</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m143-d1t2670-4">
   <w.rf>
    <LM>w#w-d1t2670-4</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m143-2099-794">
   <w.rf>
    <LM>w#w-2099-794</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2670-7">
   <w.rf>
    <LM>w#w-d1t2670-7</LM>
   </w.rf>
   <form>udřená</form>
   <lemma>udřený_^(*3ít)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-2099-795">
   <w.rf>
    <LM>w#w-2099-795</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-796">
  <m id="m143-d1t2670-9">
   <w.rf>
    <LM>w#w-d1t2670-9</LM>
   </w.rf>
   <form>Pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2670-10">
   <w.rf>
    <LM>w#w-d1t2670-10</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m143-d1t2670-11">
   <w.rf>
    <LM>w#w-d1t2670-11</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m143-d1t2670-12">
   <w.rf>
    <LM>w#w-d1t2670-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2670-13">
   <w.rf>
    <LM>w#w-d1t2670-13</LM>
   </w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m143-d-id169932-punct">
   <w.rf>
    <LM>w#w-d-id169932-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2673-1">
   <w.rf>
    <LM>w#w-d1t2673-1</LM>
   </w.rf>
   <form>fyzicky</form>
   <lemma>fyzicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-2099-2122">
   <w.rf>
    <LM>w#w-2099-2122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2123">
  <m id="m143-d1t2677-2">
   <w.rf>
    <LM>w#w-d1t2677-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m143-d1t2677-1">
   <w.rf>
    <LM>w#w-d1t2677-1</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m143-d1t2679-3">
   <w.rf>
    <LM>w#w-d1t2679-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2679-2">
   <w.rf>
    <LM>w#w-d1t2679-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2679-1">
   <w.rf>
    <LM>w#w-d1t2679-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2679-4">
   <w.rf>
    <LM>w#w-d1t2679-4</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-2123-2151">
   <w.rf>
    <LM>w#w-2123-2151</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2152">
  <m id="m143-d1t2679-6">
   <w.rf>
    <LM>w#w-d1t2679-6</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2681-3">
   <w.rf>
    <LM>w#w-d1t2681-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2681-2">
   <w.rf>
    <LM>w#w-d1t2681-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2681-4">
   <w.rf>
    <LM>w#w-d1t2681-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2681-5">
   <w.rf>
    <LM>w#w-d1t2681-5</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m143-d-id170227-punct">
   <w.rf>
    <LM>w#w-d-id170227-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2681-7">
   <w.rf>
    <LM>w#w-d1t2681-7</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2683-1">
   <w.rf>
    <LM>w#w-d1t2683-1</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m143-d1t2683-2">
   <w.rf>
    <LM>w#w-d1t2683-2</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m143-2152-804">
   <w.rf>
    <LM>w#w-2152-804</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-2152-805">
   <w.rf>
    <LM>w#w-2152-805</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-2152-806">
   <w.rf>
    <LM>w#w-2152-806</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-807">
  <m id="m143-d1t2683-5">
   <w.rf>
    <LM>w#w-d1t2683-5</LM>
   </w.rf>
   <form>Tipla</form>
   <lemma>tipnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m143-d1t2683-3">
   <w.rf>
    <LM>w#w-d1t2683-3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m143-d-id170337-punct">
   <w.rf>
    <LM>w#w-d-id170337-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2686-1">
   <w.rf>
    <LM>w#w-d1t2686-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2686-2">
   <w.rf>
    <LM>w#w-d1t2686-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2686-3">
   <w.rf>
    <LM>w#w-d1t2686-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2686-4">
   <w.rf>
    <LM>w#w-d1t2686-4</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2686-5">
   <w.rf>
    <LM>w#w-d1t2686-5</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2686-7">
   <w.rf>
    <LM>w#w-d1t2686-7</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m143-d1t2686-6">
   <w.rf>
    <LM>w#w-d1t2686-6</LM>
   </w.rf>
   <form>1960</form>
   <lemma>1960</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m143-d1t2686-12">
   <w.rf>
    <LM>w#w-d1t2686-12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2686-14">
   <w.rf>
    <LM>w#w-d1t2686-14</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m143-d1t2686-13">
   <w.rf>
    <LM>w#w-d1t2686-13</LM>
   </w.rf>
   <form>1961</form>
   <lemma>1961</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m143-d-id170582-punct">
   <w.rf>
    <LM>w#w-d-id170582-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2690-1">
   <w.rf>
    <LM>w#w-d1t2690-1</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2690-3">
   <w.rf>
    <LM>w#w-d1t2690-3</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m143-d1t2690-4">
   <w.rf>
    <LM>w#w-d1t2690-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2690-5">
   <w.rf>
    <LM>w#w-d1t2690-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2690-6">
   <w.rf>
    <LM>w#w-d1t2690-6</LM>
   </w.rf>
   <form>dobrých</form>
   <lemma>dobrý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m143-d1t2690-7">
   <w.rf>
    <LM>w#w-d1t2690-7</LM>
   </w.rf>
   <form>šedesát</form>
   <lemma>šedesát`60</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m143-2152-2154">
   <w.rf>
    <LM>w#w-2152-2154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2155">
  <m id="m143-d1t2692-2">
   <w.rf>
    <LM>w#w-d1t2692-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2692-3">
   <w.rf>
    <LM>w#w-d1t2692-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2692-4">
   <w.rf>
    <LM>w#w-d1t2692-4</LM>
   </w.rf>
   <form>vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2692-5">
   <w.rf>
    <LM>w#w-d1t2692-5</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2692-6">
   <w.rf>
    <LM>w#w-d1t2692-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m143-d1t2692-7">
   <w.rf>
    <LM>w#w-d1t2692-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2692-8">
   <w.rf>
    <LM>w#w-d1t2692-8</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m143-2155-2156">
   <w.rf>
    <LM>w#w-2155-2156</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2157">
  <m id="m143-d1t2694-2">
   <w.rf>
    <LM>w#w-d1t2694-2</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2694-3">
   <w.rf>
    <LM>w#w-d1t2694-3</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-2157-2158">
   <w.rf>
    <LM>w#w-2157-2158</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2694-4">
   <w.rf>
    <LM>w#w-d1t2694-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2694-5">
   <w.rf>
    <LM>w#w-d1t2694-5</LM>
   </w.rf>
   <form>udření</form>
   <lemma>udřený_^(*3ít)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m143-2157-2159">
   <w.rf>
    <LM>w#w-2157-2159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2160">
  <m id="m143-d1t2696-1">
   <w.rf>
    <LM>w#w-d1t2696-1</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m143-d1t2696-2">
   <w.rf>
    <LM>w#w-d1t2696-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2699-1">
   <w.rf>
    <LM>w#w-d1t2699-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2699-2">
   <w.rf>
    <LM>w#w-d1t2699-2</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m143-d1t2699-3">
   <w.rf>
    <LM>w#w-d1t2699-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m143-d1t2696-3">
   <w.rf>
    <LM>w#w-d1t2696-3</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m143-d1t2696-4">
   <w.rf>
    <LM>w#w-d1t2696-4</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2696-5">
   <w.rf>
    <LM>w#w-d1t2696-5</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2160-2161">
   <w.rf>
    <LM>w#w-2160-2161</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2162">
  <m id="m143-d1t2703-3">
   <w.rf>
    <LM>w#w-d1t2703-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2703-7">
   <w.rf>
    <LM>w#w-d1t2703-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2703-8">
   <w.rf>
    <LM>w#w-d1t2703-8</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m143-d1t2703-9">
   <w.rf>
    <LM>w#w-d1t2703-9</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m143-d1t2703-10">
   <w.rf>
    <LM>w#w-d1t2703-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2703-12">
   <w.rf>
    <LM>w#w-d1t2703-12</LM>
   </w.rf>
   <form>pracovním</form>
   <lemma>pracovní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m143-d-id171355-punct">
   <w.rf>
    <LM>w#w-d-id171355-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2709-1">
   <w.rf>
    <LM>w#w-d1t2709-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2709-2">
   <w.rf>
    <LM>w#w-d1t2709-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2709-3">
   <w.rf>
    <LM>w#w-d1t2709-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2709-4">
   <w.rf>
    <LM>w#w-d1t2709-4</LM>
   </w.rf>
   <form>hospodářství</form>
   <lemma>hospodářství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m143-2162-2164">
   <w.rf>
    <LM>w#w-2162-2164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2165">
  <m id="m143-d1t2709-6">
   <w.rf>
    <LM>w#w-d1t2709-6</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2709-7">
   <w.rf>
    <LM>w#w-d1t2709-7</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m143-d1t2709-8">
   <w.rf>
    <LM>w#w-d1t2709-8</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-d-id171497-punct">
   <w.rf>
    <LM>w#w-d-id171497-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2709-10">
   <w.rf>
    <LM>w#w-d1t2709-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m143-d1t2709-11">
   <w.rf>
    <LM>w#w-d1t2709-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2709-12">
   <w.rf>
    <LM>w#w-d1t2709-12</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m143-d-id171552-punct">
   <w.rf>
    <LM>w#w-d-id171552-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2709-15">
   <w.rf>
    <LM>w#w-d1t2709-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2709-17">
   <w.rf>
    <LM>w#w-d1t2709-17</LM>
   </w.rf>
   <form>jakási</form>
   <lemma>jakýsi</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m143-d1t2709-19">
   <w.rf>
    <LM>w#w-d1t2709-19</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-d1t2709-16">
   <w.rf>
    <LM>w#w-d1t2709-16</LM>
   </w.rf>
   <form>hospodářská</form>
   <lemma>hospodářský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-d1t2709-18">
   <w.rf>
    <LM>w#w-d1t2709-18</LM>
   </w.rf>
   <form>budova</form>
   <lemma>budova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2165-2166">
   <w.rf>
    <LM>w#w-2165-2166</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2167">
  <m id="m143-d1t2709-21">
   <w.rf>
    <LM>w#w-d1t2709-21</LM>
   </w.rf>
   <form>Říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2709-22">
   <w.rf>
    <LM>w#w-d1t2709-22</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2709-23">
   <w.rf>
    <LM>w#w-d1t2709-23</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m143-2167-2169">
   <w.rf>
    <LM>w#w-2167-2169</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2709-24">
   <w.rf>
    <LM>w#w-d1t2709-24</LM>
   </w.rf>
   <form>vejminek</form>
   <lemma>vejminek_,h_^(^GC**výměnek)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-2167-2168">
   <w.rf>
    <LM>w#w-2167-2168</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d-id171724-punct">
   <w.rf>
    <LM>w#w-d-id171724-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2709-26">
   <w.rf>
    <LM>w#w-d1t2709-26</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2709-27">
   <w.rf>
    <LM>w#w-d1t2709-27</LM>
   </w.rf>
   <form>původně</form>
   <lemma>původně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2712-1">
   <w.rf>
    <LM>w#w-d1t2712-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2712-2">
   <w.rf>
    <LM>w#w-d1t2712-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2712-3">
   <w.rf>
    <LM>w#w-d1t2712-3</LM>
   </w.rf>
   <form>pokoj</form>
   <lemma>pokoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-d1t2712-4">
   <w.rf>
    <LM>w#w-d1t2712-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2712-5">
   <w.rf>
    <LM>w#w-d1t2712-5</LM>
   </w.rf>
   <form>kuchyň</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-d-id171850-punct">
   <w.rf>
    <LM>w#w-d-id171850-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2712-9">
   <w.rf>
    <LM>w#w-d1t2712-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2712-7">
   <w.rf>
    <LM>w#w-d1t2712-7</LM>
   </w.rf>
   <form>černá</form>
   <lemma>černý_;o</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-d1t2712-8">
   <w.rf>
    <LM>w#w-d1t2712-8</LM>
   </w.rf>
   <form>kuchyň</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2167-826">
   <w.rf>
    <LM>w#w-2167-826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-827">
  <m id="m143-d1t2716-1">
   <w.rf>
    <LM>w#w-d1t2716-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2716-2">
   <w.rf>
    <LM>w#w-d1t2716-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m143-d1t2716-4">
   <w.rf>
    <LM>w#w-d1t2716-4</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-827-831">
   <w.rf>
    <LM>w#w-827-831</LM>
   </w.rf>
   <form>původní</form>
   <lemma>původní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m143-827-832">
   <w.rf>
    <LM>w#w-827-832</LM>
   </w.rf>
   <form>vlastník</form>
   <lemma>vlastník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m143-d1t2716-3">
   <w.rf>
    <LM>w#w-d1t2716-3</LM>
   </w.rf>
   <form>odstěhoval</form>
   <lemma>odstěhovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m143-d1t2716-5">
   <w.rf>
    <LM>w#w-d1t2716-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2716-7">
   <w.rf>
    <LM>w#w-d1t2716-7</LM>
   </w.rf>
   <form>hlavního</form>
   <lemma>hlavní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m143-d1t2716-8">
   <w.rf>
    <LM>w#w-d1t2716-8</LM>
   </w.rf>
   <form>baráku</form>
   <lemma>barák</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m143-d-id172062-punct">
   <w.rf>
    <LM>w#w-d-id172062-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2718-1">
   <w.rf>
    <LM>w#w-d1t2718-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m143-d1t2718-2">
   <w.rf>
    <LM>w#w-d1t2718-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2718-3">
   <w.rf>
    <LM>w#w-d1t2718-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2720-1">
   <w.rf>
    <LM>w#w-d1t2720-1</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2720-3">
   <w.rf>
    <LM>w#w-d1t2720-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2722-1">
   <w.rf>
    <LM>w#w-d1t2722-1</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1-------</tag>
  </m>
  <m id="m143-d1t2722-2">
   <w.rf>
    <LM>w#w-d1t2722-2</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m143-2167-2188">
   <w.rf>
    <LM>w#w-2167-2188</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2189">
  <m id="m143-d1t2722-4">
   <w.rf>
    <LM>w#w-d1t2722-4</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2722-6">
   <w.rf>
    <LM>w#w-d1t2722-6</LM>
   </w.rf>
   <form>stál</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2722-12">
   <w.rf>
    <LM>w#w-d1t2722-12</LM>
   </w.rf>
   <form>kolmo</form>
   <lemma>kolmo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2722-9">
   <w.rf>
    <LM>w#w-d1t2722-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2722-10">
   <w.rf>
    <LM>w#w-d1t2722-10</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m143-d1t2722-11">
   <w.rf>
    <LM>w#w-d1t2722-11</LM>
   </w.rf>
   <form>budovu</form>
   <lemma>budova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m143-d1t2725-1">
   <w.rf>
    <LM>w#w-d1t2725-1</LM>
   </w.rf>
   <form>obytný</form>
   <lemma>obytný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m143-d1t2725-2">
   <w.rf>
    <LM>w#w-d1t2725-2</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-2189-2190">
   <w.rf>
    <LM>w#w-2189-2190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2191">
  <m id="m143-d1t2729-1">
   <w.rf>
    <LM>w#w-d1t2729-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2729-2">
   <w.rf>
    <LM>w#w-d1t2729-2</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m143-d1t2729-3">
   <w.rf>
    <LM>w#w-d1t2729-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2729-4">
   <w.rf>
    <LM>w#w-d1t2729-4</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-2191-2192">
   <w.rf>
    <LM>w#w-2191-2192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2193">
  <m id="m143-d1t2731-2">
   <w.rf>
    <LM>w#w-d1t2731-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2731-3">
   <w.rf>
    <LM>w#w-d1t2731-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t2731-4">
   <w.rf>
    <LM>w#w-d1t2731-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m143-d1t2731-5">
   <w.rf>
    <LM>w#w-d1t2731-5</LM>
   </w.rf>
   <form>hospodářská</form>
   <lemma>hospodářský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m143-d1t2731-6">
   <w.rf>
    <LM>w#w-d1t2731-6</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-2193-2194">
   <w.rf>
    <LM>w#w-2193-2194</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2195">
  <m id="m143-d1t2731-8">
   <w.rf>
    <LM>w#w-d1t2731-8</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2731-9">
   <w.rf>
    <LM>w#w-d1t2731-9</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m143-d1t2731-12">
   <w.rf>
    <LM>w#w-d1t2731-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2731-10">
   <w.rf>
    <LM>w#w-d1t2731-10</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m143-d1t2731-11">
   <w.rf>
    <LM>w#w-d1t2731-11</LM>
   </w.rf>
   <form>dvůr</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m143-d1t2731-13">
   <w.rf>
    <LM>w#w-d1t2731-13</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m143-d1t2731-14">
   <w.rf>
    <LM>w#w-d1t2731-14</LM>
   </w.rf>
   <form>uzavřený</form>
   <lemma>uzavřený_^(*3ít)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m143-d1t2733-1">
   <w.rf>
    <LM>w#w-d1t2733-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m143-d1t2733-2">
   <w.rf>
    <LM>w#w-d1t2733-2</LM>
   </w.rf>
   <form>čtverce</form>
   <lemma>čtverec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m143-2195-838">
   <w.rf>
    <LM>w#w-2195-838</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2733-6">
   <w.rf>
    <LM>w#w-d1t2733-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m143-d1t2733-7">
   <w.rf>
    <LM>w#w-d1t2733-7</LM>
   </w.rf>
   <form>přerušen</form>
   <lemma>přerušit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m143-d1t2733-5">
   <w.rf>
    <LM>w#w-d1t2733-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2733-10">
   <w.rf>
    <LM>w#w-d1t2733-10</LM>
   </w.rf>
   <form>vstupem</form>
   <lemma>vstup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m143-d1t2733-8">
   <w.rf>
    <LM>w#w-d1t2733-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m143-d1t2733-9">
   <w.rf>
    <LM>w#w-d1t2733-9</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m143-d1t2735-1">
   <w.rf>
    <LM>w#w-d1t2735-1</LM>
   </w.rf>
   <form>vraty</form>
   <lemma>vrata</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m143-d1t2735-2">
   <w.rf>
    <LM>w#w-d1t2735-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2735-3">
   <w.rf>
    <LM>w#w-d1t2735-3</LM>
   </w.rf>
   <form>dvířkami</form>
   <lemma>dvířka</lemma>
   <tag>NNNP7-----A---7</tag>
  </m>
  <m id="m143-2195-2196">
   <w.rf>
    <LM>w#w-2195-2196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-2197">
  <m id="m143-d1t2744-2">
   <w.rf>
    <LM>w#w-d1t2744-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2744-3">
   <w.rf>
    <LM>w#w-d1t2744-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m143-d1t2744-5">
   <w.rf>
    <LM>w#w-d1t2744-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m143-d1t2744-4">
   <w.rf>
    <LM>w#w-d1t2744-4</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m143-d1t2744-6">
   <w.rf>
    <LM>w#w-d1t2744-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m143-d1t2744-7">
   <w.rf>
    <LM>w#w-d1t2744-7</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m143-d1t2744-8">
   <w.rf>
    <LM>w#w-d1t2744-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m143-d1t2744-9">
   <w.rf>
    <LM>w#w-d1t2744-9</LM>
   </w.rf>
   <form>párem</form>
   <lemma>pár-2</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m143-d1t2744-10">
   <w.rf>
    <LM>w#w-d1t2744-10</LM>
   </w.rf>
   <form>koní</form>
   <lemma>kůň</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m143-d-id173157-punct">
   <w.rf>
    <LM>w#w-d-id173157-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2744-12">
   <w.rf>
    <LM>w#w-d1t2744-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t2744-13">
   <w.rf>
    <LM>w#w-d1t2744-13</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m143-d1t2744-14">
   <w.rf>
    <LM>w#w-d1t2744-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m143-d1t2744-15">
   <w.rf>
    <LM>w#w-d1t2744-15</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m143-d1t2746-2">
   <w.rf>
    <LM>w#w-d1t2746-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m143-d1t2746-3">
   <w.rf>
    <LM>w#w-d1t2746-3</LM>
   </w.rf>
   <form>zemědělství</form>
   <lemma>zemědělství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m143-2197-2235">
   <w.rf>
    <LM>w#w-2197-2235</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t2746-5">
   <w.rf>
    <LM>w#w-d1t2746-5</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m143-d1t2748-2">
   <w.rf>
    <LM>w#w-d1t2748-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2748-3">
   <w.rf>
    <LM>w#w-d1t2748-3</LM>
   </w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m143-d1t2751-3">
   <w.rf>
    <LM>w#w-d1t2751-3</LM>
   </w.rf>
   <form>krmiva</form>
   <lemma>krmivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m143-d1t2751-4">
   <w.rf>
    <LM>w#w-d1t2751-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t2751-5">
   <w.rf>
    <LM>w#w-d1t2751-5</LM>
   </w.rf>
   <form>koně</form>
   <lemma>kůň</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m143-2197-850">
   <w.rf>
    <LM>w#w-2197-850</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
