<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_037.12.w.gz" />
  </references>
 </head>
 <s id="m037-d1e3762-x2">
  <m id="m037-d1t3765-1">
   <w.rf>
    <LM>w#w-d1t3765-1</LM>
   </w.rf>
   <form>Počkejte</form>
   <lemma>počkat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m037-d1t3765-2">
   <w.rf>
    <LM>w#w-d1t3765-2</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d-id178816-punct">
   <w.rf>
    <LM>w#w-d-id178816-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t3771-1">
   <w.rf>
    <LM>w#w-d1t3771-1</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m037-d1t3771-2">
   <w.rf>
    <LM>w#w-d1t3771-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m037-d1t3771-3">
   <w.rf>
    <LM>w#w-d1t3771-3</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m037-d1t3771-4">
   <w.rf>
    <LM>w#w-d1t3771-4</LM>
   </w.rf>
   <form>vysvobodit</form>
   <lemma>vysvobodit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m037-d-m-d1e3766-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3766-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e3766-x3">
  <m id="m037-d1t3773-1">
   <w.rf>
    <LM>w#w-d1t3773-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m037-d1e3766-x3-1748">
   <w.rf>
    <LM>w#w-d1e3766-x3-1748</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-1749">
  <m id="m037-1749-1751">
   <w.rf>
    <LM>w#w-1749-1751</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-1749-1752">
   <w.rf>
    <LM>w#w-1749-1752</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-1749-1753">
   <w.rf>
    <LM>w#w-1749-1753</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-1754">
  <m id="m037-1749-1750">
   <w.rf>
    <LM>w#w-1749-1750</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t3775-1">
   <w.rf>
    <LM>w#w-d1t3775-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d-m-d1e3766-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3766-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
