<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_031.03.w.gz" />
  </references>
 </head>
 <s id="m031-d1e984-x2">
  <m id="m031-d1t987-1">
   <w.rf>
    <LM>w#w-d1t987-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m031-d1t987-2">
   <w.rf>
    <LM>w#w-d1t987-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m031-d1t987-4">
   <w.rf>
    <LM>w#w-d1t987-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m031-d1t987-5">
   <w.rf>
    <LM>w#w-d1t987-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t987-6">
   <w.rf>
    <LM>w#w-d1t987-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m031-d-id92050-punct">
   <w.rf>
    <LM>w#w-d-id92050-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e988-x2">
  <m id="m031-d1t991-2">
   <w.rf>
    <LM>w#w-d1t991-2</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d-id92143-punct">
   <w.rf>
    <LM>w#w-d-id92143-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t991-4">
   <w.rf>
    <LM>w#w-d1t991-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t991-8">
   <w.rf>
    <LM>w#w-d1t991-8</LM>
   </w.rf>
   <form>mému</form>
   <lemma>můj</lemma>
   <tag>PSZS3-S1-------</tag>
  </m>
  <m id="m031-d1t991-9">
   <w.rf>
    <LM>w#w-d1t991-9</LM>
   </w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m031-d-id92245-punct">
   <w.rf>
    <LM>w#w-d-id92245-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t991-11">
   <w.rf>
    <LM>w#w-d1t991-11</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m031-d1t991-12">
   <w.rf>
    <LM>w#w-d1t991-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t991-13">
   <w.rf>
    <LM>w#w-d1t991-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t991-15">
   <w.rf>
    <LM>w#w-d1t991-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-d1t991-16">
   <w.rf>
    <LM>w#w-d1t991-16</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m031-d1t991-17">
   <w.rf>
    <LM>w#w-d1t991-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t991-18">
   <w.rf>
    <LM>w#w-d1t991-18</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t991-19">
   <w.rf>
    <LM>w#w-d1t991-19</LM>
   </w.rf>
   <form>zakoukali</form>
   <lemma>zakoukat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t991-20">
   <w.rf>
    <LM>w#w-d1t991-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t991-21">
   <w.rf>
    <LM>w#w-d1t991-21</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m031-d1t991-22">
   <w.rf>
    <LM>w#w-d1t991-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t991-23">
   <w.rf>
    <LM>w#w-d1t991-23</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m031-d1t991-24">
   <w.rf>
    <LM>w#w-d1t991-24</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t991-25">
   <w.rf>
    <LM>w#w-d1t991-25</LM>
   </w.rf>
   <form>zamilovali</form>
   <lemma>zamilovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d-id92452-punct">
   <w.rf>
    <LM>w#w-d-id92452-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1e988-x2-134">
   <w.rf>
    <LM>w#w-d1e988-x2-134</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t993-3">
   <w.rf>
    <LM>w#w-d1t993-3</LM>
   </w.rf>
   <form>líbily</form>
   <lemma>líbit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m031-d1t993-5">
   <w.rf>
    <LM>w#w-d1t993-5</LM>
   </w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m031-d1t993-6">
   <w.rf>
    <LM>w#w-d1t993-6</LM>
   </w.rf>
   <form>šaty</form>
   <lemma>šaty</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m031-d1t993-7">
   <w.rf>
    <LM>w#w-d1t993-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t993-8">
   <w.rf>
    <LM>w#w-d1t993-8</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m031-d1t993-9">
   <w.rf>
    <LM>w#w-d1t993-9</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1e988-x2-118">
   <w.rf>
    <LM>w#w-d1e988-x2-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-120">
  <m id="m031-d1t997-6">
   <w.rf>
    <LM>w#w-d1t997-6</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-120-154">
   <w.rf>
    <LM>w#w-120-154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-120-156">
   <w.rf>
    <LM>w#w-120-156</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t997-12">
   <w.rf>
    <LM>w#w-d1t997-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t997-13">
   <w.rf>
    <LM>w#w-d1t997-13</LM>
   </w.rf>
   <form>unešený</form>
   <lemma>unešený</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m031-d-m-d1e988-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e988-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e998-x2">
  <m id="m031-d1t1001-1">
   <w.rf>
    <LM>w#w-d1t1001-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1001-2">
   <w.rf>
    <LM>w#w-d1t1001-2</LM>
   </w.rf>
   <form>věřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1e998-x2-158">
   <w.rf>
    <LM>w#w-d1e998-x2-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-160_1">
  <m id="m031-d1t1003-6">
   <w.rf>
    <LM>w#w-d1t1003-6</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m031-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-160_1-164">
   <w.rf>
    <LM>w#w-160_1-164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-162">
  <m id="m031-d1t1007-26">
   <w.rf>
    <LM>w#w-d1t1007-26</LM>
   </w.rf>
   <form>Dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t1007-25">
   <w.rf>
    <LM>w#w-d1t1007-25</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d1t1007-3">
   <w.rf>
    <LM>w#w-d1t1007-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m031-162-938">
   <w.rf>
    <LM>w#w-162-938</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1007-4">
   <w.rf>
    <LM>w#w-d1t1007-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-162-940">
   <w.rf>
    <LM>w#w-162-940</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m031-d1t1009-4">
   <w.rf>
    <LM>w#w-d1t1009-4</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1007-5">
   <w.rf>
    <LM>w#w-d1t1007-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1007-6">
   <w.rf>
    <LM>w#w-d1t1007-6</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m031-d1t1007-7">
   <w.rf>
    <LM>w#w-d1t1007-7</LM>
   </w.rf>
   <form>rámečku</form>
   <lemma>rámeček</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m031-d-id93147-punct">
   <w.rf>
    <LM>w#w-d-id93147-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1007-9">
   <w.rf>
    <LM>w#w-d1t1007-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1007-10">
   <w.rf>
    <LM>w#w-d1t1007-10</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m031-d1t1007-12">
   <w.rf>
    <LM>w#w-d1t1007-12</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1007-13">
   <w.rf>
    <LM>w#w-d1t1007-13</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m031-d1t1007-15">
   <w.rf>
    <LM>w#w-d1t1007-15</LM>
   </w.rf>
   <form>výlohou</form>
   <lemma>výloha_^(v_obchodě,_reklamní,...)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m031-162-172">
   <w.rf>
    <LM>w#w-162-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1013-x2">
  <m id="m031-d1t1016-1">
   <w.rf>
    <LM>w#w-d1t1016-1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m031-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m031-d-m-d1e1013-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1013-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1017-x2">
  <m id="m031-d1t1020-1">
   <w.rf>
    <LM>w#w-d1t1020-1</LM>
   </w.rf>
   <form>Děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d-m-d1e1017-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1017-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1022-x2">
  <m id="m031-d1t1025-3">
   <w.rf>
    <LM>w#w-d1t1025-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m031-d1t1025-2">
   <w.rf>
    <LM>w#w-d1t1025-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1031-1">
   <w.rf>
    <LM>w#w-d1t1031-1</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d-m-d1e1022-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1022-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1026-x3">
  <m id="m031-d1t1033-1">
   <w.rf>
    <LM>w#w-d1t1033-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1e1026-x3-180">
   <w.rf>
    <LM>w#w-d1e1026-x3-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-178">
  <m id="m031-d1t1037-1">
   <w.rf>
    <LM>w#w-d1t1037-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m031-d1t1037-2">
   <w.rf>
    <LM>w#w-d1t1037-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1037-3">
   <w.rf>
    <LM>w#w-d1t1037-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1037-4">
   <w.rf>
    <LM>w#w-d1t1037-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m031-d1t1037-5">
   <w.rf>
    <LM>w#w-d1t1037-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m031-d-id94022-punct">
   <w.rf>
    <LM>w#w-d-id94022-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1043-x2">
  <m id="m031-d1t1046-4">
   <w.rf>
    <LM>w#w-d1t1046-4</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1046-5">
   <w.rf>
    <LM>w#w-d1t1046-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1046-6">
   <w.rf>
    <LM>w#w-d1t1046-6</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1e1043-x2-188">
   <w.rf>
    <LM>w#w-d1e1043-x2-188</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1050-1">
   <w.rf>
    <LM>w#w-d1t1050-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1050-2">
   <w.rf>
    <LM>w#w-d1t1050-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1050-3">
   <w.rf>
    <LM>w#w-d1t1050-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1050-4">
   <w.rf>
    <LM>w#w-d1t1050-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHP1-S1-------</tag>
  </m>
  <m id="m031-d1t1050-5">
   <w.rf>
    <LM>w#w-d1t1050-5</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m031-d1t1050-6">
   <w.rf>
    <LM>w#w-d1t1050-6</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m031-d-m-d1e1043-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1043-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1051-x3">
  <m id="m031-d1t1060-8">
   <w.rf>
    <LM>w#w-d1t1060-8</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-d1t1060-9">
   <w.rf>
    <LM>w#w-d1t1060-9</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m031-d1t1064-1">
   <w.rf>
    <LM>w#w-d1t1064-1</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m031-d1t1060-2">
   <w.rf>
    <LM>w#w-d1t1060-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1060-4">
   <w.rf>
    <LM>w#w-d1t1060-4</LM>
   </w.rf>
   <form>Růženka</form>
   <lemma>Růženka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1t1066-1">
   <w.rf>
    <LM>w#w-d1t1066-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m031-d1t1068-1">
   <w.rf>
    <LM>w#w-d1t1068-1</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m031-d1t1068-2">
   <w.rf>
    <LM>w#w-d1t1068-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1068-4">
   <w.rf>
    <LM>w#w-d1t1068-4</LM>
   </w.rf>
   <form>Boženka</form>
   <lemma>Boženka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1e1061-x2-220">
   <w.rf>
    <LM>w#w-d1e1061-x2-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-252_1">
  <m id="m031-d1t1077-1">
   <w.rf>
    <LM>w#w-d1t1077-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1077-3">
   <w.rf>
    <LM>w#w-d1t1077-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1077-4">
   <w.rf>
    <LM>w#w-d1t1077-4</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m031-d1t1077-5">
   <w.rf>
    <LM>w#w-d1t1077-5</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d-id94990-punct">
   <w.rf>
    <LM>w#w-d-id94990-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-252_1-254">
   <w.rf>
    <LM>w#w-252_1-254</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1075-2">
   <w.rf>
    <LM>w#w-d1t1075-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-d1t1075-3">
   <w.rf>
    <LM>w#w-d1t1075-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m031-d1t1077-7">
   <w.rf>
    <LM>w#w-d1t1077-7</LM>
   </w.rf>
   <form>ubytováni</form>
   <lemma>ubytovat</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m031-d1t1077-10">
   <w.rf>
    <LM>w#w-d1t1077-10</LM>
   </w.rf>
   <form>tadyhleti</form>
   <lemma>tadyhleten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m031-d1t1077-12">
   <w.rf>
    <LM>w#w-d1t1077-12</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m031-252_1-398">
   <w.rf>
    <LM>w#w-252_1-398</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-399">
  <m id="m031-d1t1079-4">
   <w.rf>
    <LM>w#w-d1t1079-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1079-5">
   <w.rf>
    <LM>w#w-d1t1079-5</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1089-1">
   <w.rf>
    <LM>w#w-d1t1089-1</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1089-2">
   <w.rf>
    <LM>w#w-d1t1089-2</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m031-d-m-d1e1061-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1061-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1080-x3">
  <m id="m031-d1t1089-4">
   <w.rf>
    <LM>w#w-d1t1089-4</LM>
   </w.rf>
   <form>Strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1089-5">
   <w.rf>
    <LM>w#w-d1t1089-5</LM>
   </w.rf>
   <form>milé</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m031-d1t1093-4">
   <w.rf>
    <LM>w#w-d1t1093-4</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m031-d1t1093-1">
   <w.rf>
    <LM>w#w-d1t1093-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1093-2">
   <w.rf>
    <LM>w#w-d1t1093-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1093-3">
   <w.rf>
    <LM>w#w-d1t1093-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d-m-d1e1080-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1080-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-286">
  <m id="m031-d1t1093-8">
   <w.rf>
    <LM>w#w-d1t1093-8</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m031-d1t1093-9">
   <w.rf>
    <LM>w#w-d1t1093-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1093-10">
   <w.rf>
    <LM>w#w-d1t1093-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1093-11">
   <w.rf>
    <LM>w#w-d1t1093-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m031-d1t1093-12">
   <w.rf>
    <LM>w#w-d1t1093-12</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m031-286-986">
   <w.rf>
    <LM>w#w-286-986</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1093-13">
   <w.rf>
    <LM>w#w-d1t1093-13</LM>
   </w.rf>
   <form>chovali</form>
   <lemma>chovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1095-3">
   <w.rf>
    <LM>w#w-d1t1095-3</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1095-4">
   <w.rf>
    <LM>w#w-d1t1095-4</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-286-988">
   <w.rf>
    <LM>w#w-286-988</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-990">
  <m id="m031-286-288">
   <w.rf>
    <LM>w#w-286-288</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1t1095-10">
   <w.rf>
    <LM>w#w-d1t1095-10</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m031-d1t1095-9">
   <w.rf>
    <LM>w#w-d1t1095-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1095-12">
   <w.rf>
    <LM>w#w-d1t1095-12</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m031-d1t1095-13">
   <w.rf>
    <LM>w#w-d1t1095-13</LM>
   </w.rf>
   <form>dobrého</form>
   <lemma>dobrý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m031-d1t1095-11">
   <w.rf>
    <LM>w#w-d1t1095-11</LM>
   </w.rf>
   <form>uvařila</form>
   <lemma>uvařit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1097-1">
   <w.rf>
    <LM>w#w-d1t1097-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1097-5">
   <w.rf>
    <LM>w#w-d1t1097-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1097-6">
   <w.rf>
    <LM>w#w-d1t1097-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1097-7">
   <w.rf>
    <LM>w#w-d1t1097-7</LM>
   </w.rf>
   <form>potřebovali</form>
   <lemma>potřebovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1097-8">
   <w.rf>
    <LM>w#w-d1t1097-8</LM>
   </w.rf>
   <form>cokoliv</form>
   <lemma>cokoliv</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m031-d1t1097-9">
   <w.rf>
    <LM>w#w-d1t1097-9</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-d-id95856-punct">
   <w.rf>
    <LM>w#w-d-id95856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1097-11">
   <w.rf>
    <LM>w#w-d1t1097-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1097-14">
   <w.rf>
    <LM>w#w-d1t1097-14</LM>
   </w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t1097-13">
   <w.rf>
    <LM>w#w-d1t1097-13</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m031-286-292">
   <w.rf>
    <LM>w#w-286-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-294_1">
  <m id="m031-d1t1101-3">
   <w.rf>
    <LM>w#w-d1t1101-3</LM>
   </w.rf>
   <form>Neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m031-d1t1101-2">
   <w.rf>
    <LM>w#w-d1t1101-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1101-4">
   <w.rf>
    <LM>w#w-d1t1101-4</LM>
   </w.rf>
   <form>tatínka</form>
   <lemma>tatínek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m031-d-id96029-punct">
   <w.rf>
    <LM>w#w-d-id96029-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1101-5">
   <w.rf>
    <LM>w#w-d1t1101-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1101-7">
   <w.rf>
    <LM>w#w-d1t1101-7</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m031-d1t1101-8">
   <w.rf>
    <LM>w#w-d1t1101-8</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m031-d-id96069-punct">
   <w.rf>
    <LM>w#w-d-id96069-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1101-10">
   <w.rf>
    <LM>w#w-d1t1101-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1101-11">
   <w.rf>
    <LM>w#w-d1t1101-11</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1t1101-12">
   <w.rf>
    <LM>w#w-d1t1101-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d1t1101-13">
   <w.rf>
    <LM>w#w-d1t1101-13</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m031-294_1-428">
   <w.rf>
    <LM>w#w-294_1-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-429">
  <m id="m031-d1t1104-2">
   <w.rf>
    <LM>w#w-d1t1104-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1106-1">
   <w.rf>
    <LM>w#w-d1t1106-1</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m031-d1t1106-2">
   <w.rf>
    <LM>w#w-d1t1106-2</LM>
   </w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d-id96259-punct">
   <w.rf>
    <LM>w#w-d-id96259-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1106-6">
   <w.rf>
    <LM>w#w-d1t1106-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1106-7">
   <w.rf>
    <LM>w#w-d1t1106-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1106-8">
   <w.rf>
    <LM>w#w-d1t1106-8</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-294_1-340">
   <w.rf>
    <LM>w#w-294_1-340</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-342">
  <m id="m031-d1t1112-1">
   <w.rf>
    <LM>w#w-d1t1112-1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1112-2">
   <w.rf>
    <LM>w#w-d1t1112-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1112-3">
   <w.rf>
    <LM>w#w-d1t1112-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-d1t1112-4">
   <w.rf>
    <LM>w#w-d1t1112-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m031-d1t1112-5">
   <w.rf>
    <LM>w#w-d1t1112-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1112-6">
   <w.rf>
    <LM>w#w-d1t1112-6</LM>
   </w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m031-d1t1112-7">
   <w.rf>
    <LM>w#w-d1t1112-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1112-9">
   <w.rf>
    <LM>w#w-d1t1112-9</LM>
   </w.rf>
   <form>Rábí</form>
   <lemma>Rábí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m031-342-442">
   <w.rf>
    <LM>w#w-342-442</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-443">
  <m id="m031-d1t1124-2">
   <w.rf>
    <LM>w#w-d1t1124-2</LM>
   </w.rf>
   <form>Tamtu</form>
   <lemma>tamten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m031-d1t1124-3">
   <w.rf>
    <LM>w#w-d1t1124-3</LM>
   </w.rf>
   <form>kůlničku</form>
   <lemma>kůlnička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d1t1128-1">
   <w.rf>
    <LM>w#w-d1t1128-1</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1128-6">
   <w.rf>
    <LM>w#w-d1t1128-6</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m031-d1t1132-1">
   <w.rf>
    <LM>w#w-d1t1132-1</LM>
   </w.rf>
   <form>zbourali</form>
   <lemma>zbourat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d-id96860-punct">
   <w.rf>
    <LM>w#w-d-id96860-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1132-3">
   <w.rf>
    <LM>w#w-d1t1132-3</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t1132-4">
   <w.rf>
    <LM>w#w-d1t1132-4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m031-d1t1132-5">
   <w.rf>
    <LM>w#w-d1t1132-5</LM>
   </w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m031-d1t1134-1">
   <w.rf>
    <LM>w#w-d1t1134-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1134-2">
   <w.rf>
    <LM>w#w-d1t1134-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m031-d1t1134-3">
   <w.rf>
    <LM>w#w-d1t1134-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m031-d1t1134-4">
   <w.rf>
    <LM>w#w-d1t1134-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m031-d1t1134-6">
   <w.rf>
    <LM>w#w-d1t1134-6</LM>
   </w.rf>
   <form>uklidili</form>
   <lemma>uklidit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1e1125-x2-390">
   <w.rf>
    <LM>w#w-d1e1125-x2-390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-392">
  <m id="m031-d1t1139-1">
   <w.rf>
    <LM>w#w-d1t1139-1</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m031-d1t1139-2">
   <w.rf>
    <LM>w#w-d1t1139-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1139-3">
   <w.rf>
    <LM>w#w-d1t1139-3</LM>
   </w.rf>
   <form>jmenoval</form>
   <lemma>jmenovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m031-d1t1139-5">
   <w.rf>
    <LM>w#w-d1t1139-5</LM>
   </w.rf>
   <form>Milan</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m031-d1t1139-6">
   <w.rf>
    <LM>w#w-d1t1139-6</LM>
   </w.rf>
   <form>Horký</form>
   <lemma>Horký_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m031-d1t1139-8">
   <w.rf>
    <LM>w#w-d1t1139-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1143-3">
   <w.rf>
    <LM>w#w-d1t1143-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1143-6">
   <w.rf>
    <LM>w#w-d1t1143-6</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d1t1143-10">
   <w.rf>
    <LM>w#w-d1t1143-10</LM>
   </w.rf>
   <form>Jitku</form>
   <lemma>Jitka-1_;Y_;m</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d1t1139-9">
   <w.rf>
    <LM>w#w-d1t1139-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1139-11">
   <w.rf>
    <LM>w#w-d1t1139-11</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP6-S1-------</tag>
  </m>
  <m id="m031-d1t1139-12">
   <w.rf>
    <LM>w#w-d1t1139-12</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m031-392-224">
   <w.rf>
    <LM>w#w-392-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-222_3">
  <m id="m031-d1t1139-15">
   <w.rf>
    <LM>w#w-d1t1139-15</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m031-d1t1139-16">
   <w.rf>
    <LM>w#w-d1t1139-16</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1139-17">
   <w.rf>
    <LM>w#w-d1t1139-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1139-18">
   <w.rf>
    <LM>w#w-d1t1139-18</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1141-5">
   <w.rf>
    <LM>w#w-d1t1141-5</LM>
   </w.rf>
   <form>třináct</form>
   <lemma>třináct`13</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m031-d1t1141-6">
   <w.rf>
    <LM>w#w-d1t1141-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m031-392-418">
   <w.rf>
    <LM>w#w-392-418</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1125-x3">
  <m id="m031-d1t1149-8">
   <w.rf>
    <LM>w#w-d1t1149-8</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1149-7">
   <w.rf>
    <LM>w#w-d1t1149-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1149-11">
   <w.rf>
    <LM>w#w-d1t1149-11</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m031-d1t1149-12">
   <w.rf>
    <LM>w#w-d1t1149-12</LM>
   </w.rf>
   <form>vzor</form>
   <lemma>vzor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m031-d1e1125-x3-1038">
   <w.rf>
    <LM>w#w-d1e1125-x3-1038</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-1040">
  <m id="m031-d1t1152-3">
   <w.rf>
    <LM>w#w-d1t1152-3</LM>
   </w.rf>
   <form>Strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1152-2">
   <w.rf>
    <LM>w#w-d1t1152-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1152-1">
   <w.rf>
    <LM>w#w-d1t1152-1</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d1t1152-4">
   <w.rf>
    <LM>w#w-d1t1152-4</LM>
   </w.rf>
   <form>líbil</form>
   <lemma>líbit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1e1125-x3-446">
   <w.rf>
    <LM>w#w-d1e1125-x3-446</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1162-2">
   <w.rf>
    <LM>w#w-d1t1162-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1162-3">
   <w.rf>
    <LM>w#w-d1t1162-3</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1162-4">
   <w.rf>
    <LM>w#w-d1t1162-4</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m031-d-m-d1e1125-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1125-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1153-x3">
  <m id="m031-d1e1153-x3-482">
   <w.rf>
    <LM>w#w-d1e1153-x3-482</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1e1153-x3-491">
   <w.rf>
    <LM>w#w-d1e1153-x3-491</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1e1153-x3-492">
   <w.rf>
    <LM>w#w-d1e1153-x3-492</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1168-5">
   <w.rf>
    <LM>w#w-d1t1168-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1168-6">
   <w.rf>
    <LM>w#w-d1t1168-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1168-7">
   <w.rf>
    <LM>w#w-d1t1168-7</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m031-d1t1168-9">
   <w.rf>
    <LM>w#w-d1t1168-9</LM>
   </w.rf>
   <form>tatínka</form>
   <lemma>tatínek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m031-d1e1153-x3-484">
   <w.rf>
    <LM>w#w-d1e1153-x3-484</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-486">
  <m id="m031-d1t1172-3">
   <w.rf>
    <LM>w#w-d1t1172-3</LM>
   </w.rf>
   <form>Býval</form>
   <lemma>bývat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1172-1">
   <w.rf>
    <LM>w#w-d1t1172-1</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m031-d1t1172-2">
   <w.rf>
    <LM>w#w-d1t1172-2</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m031-d1t1172-4">
   <w.rf>
    <LM>w#w-d1t1172-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m031-d1e1165-x2-474">
   <w.rf>
    <LM>w#w-d1e1165-x2-474</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-472">
  <m id="m031-d1t1179-6">
   <w.rf>
    <LM>w#w-d1t1179-6</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m031-d1t1179-7">
   <w.rf>
    <LM>w#w-d1t1179-7</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m031-d1t1179-8">
   <w.rf>
    <LM>w#w-d1t1179-8</LM>
   </w.rf>
   <form>vojskem</form>
   <lemma>vojsko</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m031-d-id98578-punct">
   <w.rf>
    <LM>w#w-d-id98578-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1179-10">
   <w.rf>
    <LM>w#w-d1t1179-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m031-d1t1179-11">
   <w.rf>
    <LM>w#w-d1t1179-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1179-12">
   <w.rf>
    <LM>w#w-d1t1179-12</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m031-d1t1179-13">
   <w.rf>
    <LM>w#w-d1t1179-13</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m031-472-493">
   <w.rf>
    <LM>w#w-472-493</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1179-14">
   <w.rf>
    <LM>w#w-d1t1179-14</LM>
   </w.rf>
   <form>gazík</form>
   <lemma>gazík_,h_^(automobil_značky_GAZ)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m031-472-494">
   <w.rf>
    <LM>w#w-472-494</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1183-2">
   <w.rf>
    <LM>w#w-d1t1183-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1183-5">
   <w.rf>
    <LM>w#w-d1t1183-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1183-6">
   <w.rf>
    <LM>w#w-d1t1183-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1183-7">
   <w.rf>
    <LM>w#w-d1t1183-7</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m031-d1t1183-8">
   <w.rf>
    <LM>w#w-d1t1183-8</LM>
   </w.rf>
   <form>strávili</form>
   <lemma>strávit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t1183-10">
   <w.rf>
    <LM>w#w-d1t1183-10</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m031-472-495">
   <w.rf>
    <LM>w#w-472-495</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-496">
  <m id="m031-d1t1181-14">
   <w.rf>
    <LM>w#w-d1t1181-14</LM>
   </w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m031-d1t1181-15">
   <w.rf>
    <LM>w#w-d1t1181-15</LM>
   </w.rf>
   <form>všemi</form>
   <lemma>všechen</lemma>
   <tag>PLXP7----------</tag>
  </m>
  <m id="m031-496-517">
   <w.rf>
    <LM>w#w-496-517</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-496-512">
   <w.rf>
    <LM>w#w-496-512</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m031-496-513">
   <w.rf>
    <LM>w#w-496-513</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-496-514">
   <w.rf>
    <LM>w#w-496-514</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-496-515">
   <w.rf>
    <LM>w#w-496-515</LM>
   </w.rf>
   <form>pronajaté</form>
   <lemma>pronajatý_^(*3mout)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m031-496-516">
   <w.rf>
    <LM>w#w-496-516</LM>
   </w.rf>
   <form>pokoje</form>
   <lemma>pokoj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m031-496-497">
   <w.rf>
    <LM>w#w-496-497</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1181-17">
   <w.rf>
    <LM>w#w-d1t1181-17</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1181-19">
   <w.rf>
    <LM>w#w-d1t1181-19</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1181-27">
   <w.rf>
    <LM>w#w-d1t1181-27</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-472-526">
   <w.rf>
    <LM>w#w-472-526</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m031-d1t1181-30">
   <w.rf>
    <LM>w#w-d1t1181-30</LM>
   </w.rf>
   <form>ubytovaný</form>
   <lemma>ubytovaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m031-d1t1181-20">
   <w.rf>
    <LM>w#w-d1t1181-20</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m031-d1t1181-21">
   <w.rf>
    <LM>w#w-d1t1181-21</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m031-d-id99003-punct">
   <w.rf>
    <LM>w#w-d-id99003-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1181-23">
   <w.rf>
    <LM>w#w-d1t1181-23</LM>
   </w.rf>
   <form>učitelé</form>
   <lemma>učitel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m031-d-id99028-punct">
   <w.rf>
    <LM>w#w-d-id99028-punct</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1181-26">
   <w.rf>
    <LM>w#w-d1t1181-26</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m031-d-m-d1e1165-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1165-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1185-x3">
  <m id="m031-d1t1196-2">
   <w.rf>
    <LM>w#w-d1t1196-2</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m031-d1t1196-3">
   <w.rf>
    <LM>w#w-d1t1196-3</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m031-d1t1196-4">
   <w.rf>
    <LM>w#w-d1t1196-4</LM>
   </w.rf>
   <form>sestřička</form>
   <lemma>sestřička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1e1185-x3-550">
   <w.rf>
    <LM>w#w-d1e1185-x3-550</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1200-1">
   <w.rf>
    <LM>w#w-d1t1200-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1200-3">
   <w.rf>
    <LM>w#w-d1t1200-3</LM>
   </w.rf>
   <form>bílé</form>
   <lemma>bílý_;o</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m031-d1t1200-4">
   <w.rf>
    <LM>w#w-d1t1200-4</LM>
   </w.rf>
   <form>blůzičce</form>
   <lemma>blůzička</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m031-d-id99670-punct">
   <w.rf>
    <LM>w#w-d-id99670-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1200-8">
   <w.rf>
    <LM>w#w-d1t1200-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d1t1200-6">
   <w.rf>
    <LM>w#w-d1t1200-6</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1200-9">
   <w.rf>
    <LM>w#w-d1t1200-9</LM>
   </w.rf>
   <form>umřela</form>
   <lemma>umřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1200-17">
   <w.rf>
    <LM>w#w-d1t1200-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m031-d1t1200-18">
   <w.rf>
    <LM>w#w-d1t1200-18</LM>
   </w.rf>
   <form>rakovinu</form>
   <lemma>rakovina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d1t1200-19">
   <w.rf>
    <LM>w#w-d1t1200-19</LM>
   </w.rf>
   <form>prsu</form>
   <lemma>prs</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m031-d1e1197-x2-546">
   <w.rf>
    <LM>w#w-d1e1197-x2-546</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-548">
  <m id="m031-d1t1200-11">
   <w.rf>
    <LM>w#w-d1t1200-11</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1200-12">
   <w.rf>
    <LM>w#w-d1t1200-12</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m031-d1t1200-13">
   <w.rf>
    <LM>w#w-d1t1200-13</LM>
   </w.rf>
   <form>42</form>
   <lemma>42</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m031-d1t1200-15">
   <w.rf>
    <LM>w#w-d1t1200-15</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m031-d1t1202-1">
   <w.rf>
    <LM>w#w-d1t1202-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1204-2">
   <w.rf>
    <LM>w#w-d1t1204-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d1t1206-1">
   <w.rf>
    <LM>w#w-d1t1206-1</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m031-d1t1206-2">
   <w.rf>
    <LM>w#w-d1t1206-2</LM>
   </w.rf>
   <form>dcerky</form>
   <lemma>dcerka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m031-548-552">
   <w.rf>
    <LM>w#w-548-552</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-554">
  <m id="m031-d1t1206-12">
   <w.rf>
    <LM>w#w-d1t1206-12</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1206-16">
   <w.rf>
    <LM>w#w-d1t1206-16</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m031-d1t1206-14">
   <w.rf>
    <LM>w#w-d1t1206-14</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1206-15">
   <w.rf>
    <LM>w#w-d1t1206-15</LM>
   </w.rf>
   <form>hodného</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m031-d1t1206-13">
   <w.rf>
    <LM>w#w-d1t1206-13</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m031-554-556">
   <w.rf>
    <LM>w#w-554-556</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-554-558">
   <w.rf>
    <LM>w#w-554-558</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1206-18">
   <w.rf>
    <LM>w#w-d1t1206-18</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1t1208-4">
   <w.rf>
    <LM>w#w-d1t1208-4</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m031-d1t1208-5">
   <w.rf>
    <LM>w#w-d1t1208-5</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m031-d1t1208-6">
   <w.rf>
    <LM>w#w-d1t1208-6</LM>
   </w.rf>
   <form>vychovávala</form>
   <lemma>vychovávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-554-560">
   <w.rf>
    <LM>w#w-554-560</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-7">
   <w.rf>
    <LM>w#w-d1t1208-7</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m031-d1t1208-8">
   <w.rf>
    <LM>w#w-d1t1208-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1208-9">
   <w.rf>
    <LM>w#w-d1t1208-9</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m031-554-290">
   <w.rf>
    <LM>w#w-554-290</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-10">
   <w.rf>
    <LM>w#w-d1t1208-10</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m031-554-292">
   <w.rf>
    <LM>w#w-554-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-294_2">
  <m id="m031-d1t1208-12">
   <w.rf>
    <LM>w#w-d1t1208-12</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1t1208-13">
   <w.rf>
    <LM>w#w-d1t1208-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1208-14">
   <w.rf>
    <LM>w#w-d1t1208-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1208-15">
   <w.rf>
    <LM>w#w-d1t1208-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m031-d1t1208-16">
   <w.rf>
    <LM>w#w-d1t1208-16</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m031-d1t1208-17">
   <w.rf>
    <LM>w#w-d1t1208-17</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d1t1208-19">
   <w.rf>
    <LM>w#w-d1t1208-19</LM>
   </w.rf>
   <form>každou</form>
   <lemma>každý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m031-d1t1208-20">
   <w.rf>
    <LM>w#w-d1t1208-20</LM>
   </w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d-id100533-punct">
   <w.rf>
    <LM>w#w-d-id100533-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-22">
   <w.rf>
    <LM>w#w-d1t1208-22</LM>
   </w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d-id100557-punct">
   <w.rf>
    <LM>w#w-d-id100557-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-24">
   <w.rf>
    <LM>w#w-d1t1208-24</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m031-d1t1208-25">
   <w.rf>
    <LM>w#w-d1t1208-25</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m031-d1t1208-26">
   <w.rf>
    <LM>w#w-d1t1208-26</LM>
   </w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1208-27">
   <w.rf>
    <LM>w#w-d1t1208-27</LM>
   </w.rf>
   <form>vyprat</form>
   <lemma>vyprat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-d-id100628-punct">
   <w.rf>
    <LM>w#w-d-id100628-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-29">
   <w.rf>
    <LM>w#w-d1t1208-29</LM>
   </w.rf>
   <form>vyžehlit</form>
   <lemma>vyžehlit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-d-id100652-punct">
   <w.rf>
    <LM>w#w-d-id100652-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1208-31">
   <w.rf>
    <LM>w#w-d1t1208-31</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m031-d1t1211-5">
   <w.rf>
    <LM>w#w-d1t1211-5</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m031-d1t1211-12">
   <w.rf>
    <LM>w#w-d1t1211-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m031-d1t1211-13">
   <w.rf>
    <LM>w#w-d1t1211-13</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m031-d1t1211-14">
   <w.rf>
    <LM>w#w-d1t1211-14</LM>
   </w.rf>
   <form>ulehčila</form>
   <lemma>ulehčit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1e1197-x3-590">
   <w.rf>
    <LM>w#w-d1e1197-x3-590</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-686">
  <m id="m031-d1t1217-3">
   <w.rf>
    <LM>w#w-d1t1217-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1217-4">
   <w.rf>
    <LM>w#w-d1t1217-4</LM>
   </w.rf>
   <form>neměly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m031-d1t1217-5">
   <w.rf>
    <LM>w#w-d1t1217-5</LM>
   </w.rf>
   <form>mámu</form>
   <lemma>máma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m031-d-id101023-punct">
   <w.rf>
    <LM>w#w-d-id101023-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1217-7">
   <w.rf>
    <LM>w#w-d1t1217-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1217-8">
   <w.rf>
    <LM>w#w-d1t1217-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1217-10">
   <w.rf>
    <LM>w#w-d1t1217-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1217-11">
   <w.rf>
    <LM>w#w-d1t1217-11</LM>
   </w.rf>
   <form>zastávala</form>
   <lemma>zastávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d1t1217-13">
   <w.rf>
    <LM>w#w-d1t1217-13</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m031-686-688">
   <w.rf>
    <LM>w#w-686-688</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-642_1">
  <m id="m031-d1t1217-15">
   <w.rf>
    <LM>w#w-d1t1217-15</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-d1t1217-16">
   <w.rf>
    <LM>w#w-d1t1217-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1217-17">
   <w.rf>
    <LM>w#w-d1t1217-17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m031-d1t1217-18">
   <w.rf>
    <LM>w#w-d1t1217-18</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m031-d1t1217-20">
   <w.rf>
    <LM>w#w-d1t1217-20</LM>
   </w.rf>
   <form>postarala</form>
   <lemma>postarat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d-id101258-punct">
   <w.rf>
    <LM>w#w-d-id101258-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1217-23">
   <w.rf>
    <LM>w#w-d1t1217-23</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1231-1">
   <w.rf>
    <LM>w#w-d1t1231-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1231-2">
   <w.rf>
    <LM>w#w-d1t1231-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1231-3">
   <w.rf>
    <LM>w#w-d1t1231-3</LM>
   </w.rf>
   <form>potřeba</form>
   <lemma>potřeba-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1231-4">
   <w.rf>
    <LM>w#w-d1t1231-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m031-d1t1231-5">
   <w.rf>
    <LM>w#w-d1t1231-5</LM>
   </w.rf>
   <form>módního</form>
   <lemma>módní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m031-d1e1228-x2-692">
   <w.rf>
    <LM>w#w-d1e1228-x2-692</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1231-6">
   <w.rf>
    <LM>w#w-d1t1231-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1231-7">
   <w.rf>
    <LM>w#w-d1t1231-7</LM>
   </w.rf>
   <form>ušít</form>
   <lemma>ušít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-d1e1228-x2-694">
   <w.rf>
    <LM>w#w-d1e1228-x2-694</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1231-8">
   <w.rf>
    <LM>w#w-d1t1231-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1231-9">
   <w.rf>
    <LM>w#w-d1t1231-9</LM>
   </w.rf>
   <form>nakoupit</form>
   <lemma>nakoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-d-id101581-punct">
   <w.rf>
    <LM>w#w-d-id101581-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1233-1">
   <w.rf>
    <LM>w#w-d1t1233-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1233-3">
   <w.rf>
    <LM>w#w-d1t1233-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1233-5">
   <w.rf>
    <LM>w#w-d1t1233-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m031-d1t1233-6">
   <w.rf>
    <LM>w#w-d1t1233-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m031-d1t1233-7">
   <w.rf>
    <LM>w#w-d1t1233-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m031-d1t1233-8">
   <w.rf>
    <LM>w#w-d1t1233-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d1t1233-4">
   <w.rf>
    <LM>w#w-d1t1233-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1233-9">
   <w.rf>
    <LM>w#w-d1t1233-9</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1e1228-x2-698">
   <w.rf>
    <LM>w#w-d1e1228-x2-698</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-696">
  <m id="m031-d1t1237-2">
   <w.rf>
    <LM>w#w-d1t1237-2</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m031-d1t1237-3">
   <w.rf>
    <LM>w#w-d1t1237-3</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m031-d1t1237-4">
   <w.rf>
    <LM>w#w-d1t1237-4</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-696-722">
   <w.rf>
    <LM>w#w-696-722</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1237-5">
   <w.rf>
    <LM>w#w-d1t1237-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d1t1237-6">
   <w.rf>
    <LM>w#w-d1t1237-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1237-8">
   <w.rf>
    <LM>w#w-d1t1237-8</LM>
   </w.rf>
   <form>Růženka</form>
   <lemma>Růženka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m031-696-1110">
   <w.rf>
    <LM>w#w-696-1110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-1112">
  <m id="m031-d1t1237-12">
   <w.rf>
    <LM>w#w-d1t1237-12</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d1t1237-13">
   <w.rf>
    <LM>w#w-d1t1237-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1237-15">
   <w.rf>
    <LM>w#w-d1t1237-15</LM>
   </w.rf>
   <form>Bratislavě</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m031-696-724">
   <w.rf>
    <LM>w#w-696-724</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-726_1">
  <m id="m031-d1t1242-7">
   <w.rf>
    <LM>w#w-d1t1242-7</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1242-6">
   <w.rf>
    <LM>w#w-d1t1242-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1242-8">
   <w.rf>
    <LM>w#w-d1t1242-8</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1242-9">
   <w.rf>
    <LM>w#w-d1t1242-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1242-10">
   <w.rf>
    <LM>w#w-d1t1242-10</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m031-d-id102108-punct">
   <w.rf>
    <LM>w#w-d-id102108-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-726_1-1120">
   <w.rf>
    <LM>w#w-726_1-1120</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1248-4">
   <w.rf>
    <LM>w#w-d1t1248-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1248-2">
   <w.rf>
    <LM>w#w-d1t1248-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m031-d1t1248-3">
   <w.rf>
    <LM>w#w-d1t1248-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1246-1">
   <w.rf>
    <LM>w#w-d1t1246-1</LM>
   </w.rf>
   <form>64</form>
   <lemma>64</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m031-726_1-728">
   <w.rf>
    <LM>w#w-726_1-728</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-730_2">
  <m id="m031-d1t1255-1">
   <w.rf>
    <LM>w#w-d1t1255-1</LM>
   </w.rf>
   <form>Provdala</form>
   <lemma>provdat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1255-2">
   <w.rf>
    <LM>w#w-d1t1255-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1255-3">
   <w.rf>
    <LM>w#w-d1t1255-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m031-d1t1255-5">
   <w.rf>
    <LM>w#w-d1t1255-5</LM>
   </w.rf>
   <form>Bratislavy</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m031-730_2-16">
   <w.rf>
    <LM>w#w-730_2-16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-18_1">
  <m id="m031-d1t1261-2">
   <w.rf>
    <LM>w#w-d1t1261-2</LM>
   </w.rf>
   <form>Vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1261-1">
   <w.rf>
    <LM>w#w-d1t1261-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m031-d1t1259-5">
   <w.rf>
    <LM>w#w-d1t1259-5</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1259-6">
   <w.rf>
    <LM>w#w-d1t1259-6</LM>
   </w.rf>
   <form>hodného</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m031-730-766">
   <w.rf>
    <LM>w#w-730-766</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1259-1">
   <w.rf>
    <LM>w#w-d1t1259-1</LM>
   </w.rf>
   <form>hezkého</form>
   <lemma>hezký</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m031-d1t1259-2">
   <w.rf>
    <LM>w#w-d1t1259-2</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m031-730-770">
   <w.rf>
    <LM>w#w-730-770</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1228-x3">
  <m id="m031-d1t1263-3">
   <w.rf>
    <LM>w#w-d1t1263-3</LM>
   </w.rf>
   <form>Zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m031-d1e1228-x3-816">
   <w.rf>
    <LM>w#w-d1e1228-x3-816</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d-id102602-punct">
   <w.rf>
    <LM>w#w-d-id102602-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1263-5">
   <w.rf>
    <LM>w#w-d1t1263-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1265-2">
   <w.rf>
    <LM>w#w-d1t1265-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m031-d1t1268-3">
   <w.rf>
    <LM>w#w-d1t1268-3</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m031-d1t1268-1">
   <w.rf>
    <LM>w#w-d1t1268-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m031-d1t1268-2">
   <w.rf>
    <LM>w#w-d1t1268-2</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m031-d1t1268-16">
   <w.rf>
    <LM>w#w-d1t1268-16</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1268-17">
   <w.rf>
    <LM>w#w-d1t1268-17</LM>
   </w.rf>
   <form>vykládal</form>
   <lemma>vykládat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1268-18">
   <w.rf>
    <LM>w#w-d1t1268-18</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m031-d1e1228-x3-856">
   <w.rf>
    <LM>w#w-d1e1228-x3-856</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-858">
  <m id="m031-d1t1268-21">
   <w.rf>
    <LM>w#w-d1t1268-21</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m031-d-id102984-punct">
   <w.rf>
    <LM>w#w-d-id102984-punct</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1e1228-x3-820">
   <w.rf>
    <LM>w#w-d1e1228-x3-820</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1268-23">
   <w.rf>
    <LM>w#w-d1t1268-23</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1t1268-24">
   <w.rf>
    <LM>w#w-d1t1268-24</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m031-d1t1268-25">
   <w.rf>
    <LM>w#w-d1t1268-25</LM>
   </w.rf>
   <form>nevěřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m031-858-860">
   <w.rf>
    <LM>w#w-858-860</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1e1228-x3-822">
   <w.rf>
    <LM>w#w-d1e1228-x3-822</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1269-x3">
  <m id="m031-d1t1280-4">
   <w.rf>
    <LM>w#w-d1t1280-4</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1280-3">
   <w.rf>
    <LM>w#w-d1t1280-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m031-d1t1280-5">
   <w.rf>
    <LM>w#w-d1t1280-5</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m031-d1t1280-6">
   <w.rf>
    <LM>w#w-d1t1280-6</LM>
   </w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m031-d1t1280-7">
   <w.rf>
    <LM>w#w-d1t1280-7</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m031-d-m-d1e1269-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1269-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-d1e1281-x2">
  <m id="m031-d1t1284-3">
   <w.rf>
    <LM>w#w-d1t1284-3</LM>
   </w.rf>
   <form>Přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m031-d1t1284-4">
   <w.rf>
    <LM>w#w-d1t1284-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1284-5">
   <w.rf>
    <LM>w#w-d1t1284-5</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m031-d-id103362-punct">
   <w.rf>
    <LM>w#w-d-id103362-punct</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1e1281-x2-884">
   <w.rf>
    <LM>w#w-d1e1281-x2-884</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1284-7">
   <w.rf>
    <LM>w#w-d1t1284-7</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1284-8">
   <w.rf>
    <LM>w#w-d1t1284-8</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m031-d-id103395-punct">
   <w.rf>
    <LM>w#w-d-id103395-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1284-14">
   <w.rf>
    <LM>w#w-d1t1284-14</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m031-d1t1284-15">
   <w.rf>
    <LM>w#w-d1t1284-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1284-16">
   <w.rf>
    <LM>w#w-d1t1284-16</LM>
   </w.rf>
   <form>vykládali</form>
   <lemma>vykládat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m031-d1t1284-17">
   <w.rf>
    <LM>w#w-d1t1284-17</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m031-d1t1284-18">
   <w.rf>
    <LM>w#w-d1t1284-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1284-21">
   <w.rf>
    <LM>w#w-d1t1284-21</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m031-d1t1284-19">
   <w.rf>
    <LM>w#w-d1t1284-19</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d-id103556-punct">
   <w.rf>
    <LM>w#w-d-id103556-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1284-23">
   <w.rf>
    <LM>w#w-d1t1284-23</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1284-24">
   <w.rf>
    <LM>w#w-d1t1284-24</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1286-1">
   <w.rf>
    <LM>w#w-d1t1286-1</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m031-d1t1286-2">
   <w.rf>
    <LM>w#w-d1t1286-2</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m031-d1t1286-3">
   <w.rf>
    <LM>w#w-d1t1286-3</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m031-d-id103651-punct">
   <w.rf>
    <LM>w#w-d-id103651-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1286-5">
   <w.rf>
    <LM>w#w-d1t1286-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1292-1">
   <w.rf>
    <LM>w#w-d1t1292-1</LM>
   </w.rf>
   <form>zůstanu</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m031-d1t1292-2">
   <w.rf>
    <LM>w#w-d1t1292-2</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m031-d1e1281-x2-46">
   <w.rf>
    <LM>w#w-d1e1281-x2-46</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-48_3">
  <m id="m031-d1t1292-7">
   <w.rf>
    <LM>w#w-d1t1292-7</LM>
   </w.rf>
   <form>Že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m031-d1t1295-3">
   <w.rf>
    <LM>w#w-d1t1295-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1295-2">
   <w.rf>
    <LM>w#w-d1t1295-2</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1295-1">
   <w.rf>
    <LM>w#w-d1t1295-1</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m031-d1t1295-4">
   <w.rf>
    <LM>w#w-d1t1295-4</LM>
   </w.rf>
   <form>stane</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m031-d1e1281-x2-886">
   <w.rf>
    <LM>w#w-d1e1281-x2-886</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1e1281-x2-888">
   <w.rf>
    <LM>w#w-d1e1281-x2-888</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-890">
  <m id="m031-d1t1299-2">
   <w.rf>
    <LM>w#w-d1t1299-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1t1299-3">
   <w.rf>
    <LM>w#w-d1t1299-3</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d-id103979-punct">
   <w.rf>
    <LM>w#w-d-id103979-punct</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-890-902">
   <w.rf>
    <LM>w#w-890-902</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1299-5">
   <w.rf>
    <LM>w#w-d1t1299-5</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m031-d1t1299-6">
   <w.rf>
    <LM>w#w-d1t1299-6</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m031-d-id104012-punct">
   <w.rf>
    <LM>w#w-d-id104012-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1299-8">
   <w.rf>
    <LM>w#w-d1t1299-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m031-d1t1299-9">
   <w.rf>
    <LM>w#w-d1t1299-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m031-d1t1299-11">
   <w.rf>
    <LM>w#w-d1t1299-11</LM>
   </w.rf>
   <form>nemůžeš</form>
   <lemma>moci</lemma>
   <tag>VB-S---2P-NAI--</tag>
  </m>
  <m id="m031-d1t1299-12">
   <w.rf>
    <LM>w#w-d1t1299-12</LM>
   </w.rf>
   <form>myslet</form>
   <lemma>myslit</lemma>
   <tag>Vf--------A-I-1</tag>
  </m>
  <m id="m031-890-904">
   <w.rf>
    <LM>w#w-890-904</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-906">
  <m id="m031-d1t1301-4">
   <w.rf>
    <LM>w#w-d1t1301-4</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m031-d1t1301-5">
   <w.rf>
    <LM>w#w-d1t1301-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m031-d1t1301-6">
   <w.rf>
    <LM>w#w-d1t1301-6</LM>
   </w.rf>
   <form>nevěřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m031-906-908">
   <w.rf>
    <LM>w#w-906-908</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-906-910">
   <w.rf>
    <LM>w#w-906-910</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-912">
  <m id="m031-d1t1301-7">
   <w.rf>
    <LM>w#w-d1t1301-7</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1303-4">
   <w.rf>
    <LM>w#w-d1t1303-4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1303-2">
   <w.rf>
    <LM>w#w-d1t1303-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1303-3">
   <w.rf>
    <LM>w#w-d1t1303-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m031-d-id104299-punct">
   <w.rf>
    <LM>w#w-d-id104299-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1303-7">
   <w.rf>
    <LM>w#w-d1t1303-7</LM>
   </w.rf>
   <form>nedej</form>
   <lemma>dát-1</lemma>
   <tag>Vi-S---2--N-P--</tag>
  </m>
  <m id="m031-d1t1303-8">
   <w.rf>
    <LM>w#w-d1t1303-8</LM>
   </w.rf>
   <form>bože</form>
   <lemma>bůh</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m031-d-id104434-punct">
   <w.rf>
    <LM>w#w-d-id104434-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1303-18">
   <w.rf>
    <LM>w#w-d1t1303-18</LM>
   </w.rf>
   <form>vyplnilo</form>
   <lemma>vyplnit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m031-d1e1281-x3-936">
   <w.rf>
    <LM>w#w-d1e1281-x3-936</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m031-940">
  <m id="m031-d1t1305-3">
   <w.rf>
    <LM>w#w-d1t1305-3</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m031-d1t1305-4">
   <w.rf>
    <LM>w#w-d1t1305-4</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m031-d-id104559-punct">
   <w.rf>
    <LM>w#w-d-id104559-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1305-6">
   <w.rf>
    <LM>w#w-d1t1305-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m031-d1t1305-7">
   <w.rf>
    <LM>w#w-d1t1305-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1305-8">
   <w.rf>
    <LM>w#w-d1t1305-8</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m031-d1t1305-9">
   <w.rf>
    <LM>w#w-d1t1305-9</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m031-d-id104630-punct">
   <w.rf>
    <LM>w#w-d-id104630-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m031-d1t1305-11">
   <w.rf>
    <LM>w#w-d1t1305-11</LM>
   </w.rf>
   <form>jel</form>
   <lemma>jet-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m031-d1t1308-2">
   <w.rf>
    <LM>w#w-d1t1308-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m031-d1t1308-3">
   <w.rf>
    <LM>w#w-d1t1308-3</LM>
   </w.rf>
   <form>synem</form>
   <lemma>syn</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m031-940-592">
   <w.rf>
    <LM>w#w-940-592</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m031-940-593">
   <w.rf>
    <LM>w#w-940-593</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m031-d1t1308-6">
   <w.rf>
    <LM>w#w-d1t1308-6</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m031-d1t1310-1">
   <w.rf>
    <LM>w#w-d1t1310-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1310-2">
   <w.rf>
    <LM>w#w-d1t1310-2</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m031-d1t1310-3">
   <w.rf>
    <LM>w#w-d1t1310-3</LM>
   </w.rf>
   <form>opilý</form>
   <lemma>opilý_^(*3ít)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m031-d1t1310-5">
   <w.rf>
    <LM>w#w-d1t1310-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m031-d1t1310-6">
   <w.rf>
    <LM>w#w-d1t1310-6</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m031-d1t1310-8">
   <w.rf>
    <LM>w#w-d1t1310-8</LM>
   </w.rf>
   <form>najel</form>
   <lemma>najet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m031-d1t1310-9">
   <w.rf>
    <LM>w#w-d1t1310-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m031-d1t1310-10">
   <w.rf>
    <LM>w#w-d1t1310-10</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m031-d1t1310-11">
   <w.rf>
    <LM>w#w-d1t1310-11</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m031-d1t1310-15">
   <w.rf>
    <LM>w#w-d1t1310-15</LM>
   </w.rf>
   <form>zabil</form>
   <lemma>zabít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m031-940-956">
   <w.rf>
    <LM>w#w-940-956</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
