<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_994.01.w.gz" />
  </references>
 </head>
 <s id="m994-25819_04-97">
  <m id="m994-d1t321-8">
   <w.rf>
    <LM>w#w-d1t321-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m994-d1t321-9">
   <w.rf>
    <LM>w#w-d1t321-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t321-10">
   <w.rf>
    <LM>w#w-d1t321-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t321-11">
   <w.rf>
    <LM>w#w-d1t321-11</LM>
   </w.rf>
   <form>věděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d-id65609">
   <w.rf>
    <LM>w#w-d-id65609</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t321-13">
   <w.rf>
    <LM>w#w-d1t321-13</LM>
   </w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m994-d1t321-14">
   <w.rf>
    <LM>w#w-d1t321-14</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-97-107">
   <w.rf>
    <LM>w#w-97-107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t321-15">
   <w.rf>
    <LM>w#w-d1t321-15</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m994-d1t321-16">
   <w.rf>
    <LM>w#w-d1t321-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t321-17">
   <w.rf>
    <LM>w#w-d1t321-17</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d-id65688">
   <w.rf>
    <LM>w#w-d-id65688</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e37-x25">
  <m id="m994-d1t326-1">
   <w.rf>
    <LM>w#w-d1t326-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t328-5">
   <w.rf>
    <LM>w#w-d1t328-5</LM>
   </w.rf>
   <form>nelituju</form>
   <lemma>litovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-d1t328-4">
   <w.rf>
    <LM>w#w-d1t328-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m994-d-id65816">
   <w.rf>
    <LM>w#w-d-id65816</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t332-3">
   <w.rf>
    <LM>w#w-d1t332-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t328-8">
   <w.rf>
    <LM>w#w-d1t328-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t328-9">
   <w.rf>
    <LM>w#w-d1t328-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m994-d1t328-10">
   <w.rf>
    <LM>w#w-d1t328-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t332-1">
   <w.rf>
    <LM>w#w-d1t332-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t332-2">
   <w.rf>
    <LM>w#w-d1t332-2</LM>
   </w.rf>
   <form>dobrém</form>
   <lemma>dobrý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m994-d1t328-11">
   <w.rf>
    <LM>w#w-d1t328-11</LM>
   </w.rf>
   <form>vrátilo</form>
   <lemma>vrátit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m994-d-id65975">
   <w.rf>
    <LM>w#w-d-id65975</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e37-x27">
  <m id="m994-d1t339-2">
   <w.rf>
    <LM>w#w-d1t339-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t339-3">
   <w.rf>
    <LM>w#w-d1t339-3</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t339-7">
   <w.rf>
    <LM>w#w-d1t339-7</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m994-d1t339-8">
   <w.rf>
    <LM>w#w-d1t339-8</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1e37-x27-313">
   <w.rf>
    <LM>w#w-d1e37-x27-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-333">
  <m id="m994-d1t343-3">
   <w.rf>
    <LM>w#w-d1t343-3</LM>
   </w.rf>
   <form>Neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m994-d1t343-2">
   <w.rf>
    <LM>w#w-d1t343-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t343-4">
   <w.rf>
    <LM>w#w-d1t343-4</LM>
   </w.rf>
   <form>potravinové</form>
   <lemma>potravinový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m994-d1t343-5">
   <w.rf>
    <LM>w#w-d1t343-5</LM>
   </w.rf>
   <form>lístky</form>
   <lemma>lístek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m994-333-1243">
   <w.rf>
    <LM>w#w-333-1243</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1244">
  <m id="m994-d1t345-4">
   <w.rf>
    <LM>w#w-d1t345-4</LM>
   </w.rf>
   <form>Dobývali</form>
   <lemma>dobývat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t345-3">
   <w.rf>
    <LM>w#w-d1t345-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t345-1">
   <w.rf>
    <LM>w#w-d1t345-1</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m994-d1t345-2">
   <w.rf>
    <LM>w#w-d1t345-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t345-5">
   <w.rf>
    <LM>w#w-d1t345-5</LM>
   </w.rf>
   <form>Rusáci</form>
   <lemma>Rusák_;E_,h</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m994-d-id66332">
   <w.rf>
    <LM>w#w-d-id66332</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t352-1">
   <w.rf>
    <LM>w#w-d1t352-1</LM>
   </w.rf>
   <form>domovník</form>
   <lemma>domovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t352-2">
   <w.rf>
    <LM>w#w-d1t352-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m994-d1t352-3">
   <w.rf>
    <LM>w#w-d1t352-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t352-4">
   <w.rf>
    <LM>w#w-d1t352-4</LM>
   </w.rf>
   <form>posílal</form>
   <lemma>posílat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1e37-x27-317">
   <w.rf>
    <LM>w#w-d1e37-x27-317</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t352-5">
   <w.rf>
    <LM>w#w-d1t352-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t352-6">
   <w.rf>
    <LM>w#w-d1t352-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t352-7">
   <w.rf>
    <LM>w#w-d1t352-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t352-8">
   <w.rf>
    <LM>w#w-d1t352-8</LM>
   </w.rf>
   <form>Němec</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-1244-1245">
   <w.rf>
    <LM>w#w-1244-1245</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1246">
  <m id="m994-d1t352-10">
   <w.rf>
    <LM>w#w-d1t352-10</LM>
   </w.rf>
   <form>Hledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t352-11">
   <w.rf>
    <LM>w#w-d1t352-11</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSMS4-S1-------</tag>
  </m>
  <m id="m994-d1t352-12">
   <w.rf>
    <LM>w#w-d1t352-12</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-333-343">
   <w.rf>
    <LM>w#w-333-343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-344">
  <m id="m994-d1t360-1">
   <w.rf>
    <LM>w#w-d1t360-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t360-2">
   <w.rf>
    <LM>w#w-d1t360-2</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d1t360-3">
   <w.rf>
    <LM>w#w-d1t360-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t360-4">
   <w.rf>
    <LM>w#w-d1t360-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m994-d1t360-5">
   <w.rf>
    <LM>w#w-d1t360-5</LM>
   </w.rf>
   <form>hajzl</form>
   <lemma>hajzl-2_,v</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d-id66683">
   <w.rf>
    <LM>w#w-d-id66683</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t363-1">
   <w.rf>
    <LM>w#w-d1t363-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t360-7">
   <w.rf>
    <LM>w#w-d1t360-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t371-1">
   <w.rf>
    <LM>w#w-d1t371-1</LM>
   </w.rf>
   <form>vlajkař</form>
   <lemma>vlajkař_,h</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-344-1256">
   <w.rf>
    <LM>w#w-344-1256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t371-3">
   <w.rf>
    <LM>w#w-d1t371-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t371-4">
   <w.rf>
    <LM>w#w-d1t371-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-344-394">
   <w.rf>
    <LM>w#w-344-394</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t371-6">
   <w.rf>
    <LM>w#w-d1t371-6</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-344-397">
   <w.rf>
    <LM>w#w-344-397</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-320">
  <m id="m994-d1t373-4">
   <w.rf>
    <LM>w#w-d1t373-4</LM>
   </w.rf>
   <form>Dám</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m994-d1t373-3">
   <w.rf>
    <LM>w#w-d1t373-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m994-d1t376-4">
   <w.rf>
    <LM>w#w-d1t376-4</LM>
   </w.rf>
   <form>jinou</form>
   <lemma>jiný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m994-d1t376-5">
   <w.rf>
    <LM>w#w-d1t376-5</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-d-id67048">
   <w.rf>
    <LM>w#w-d-id67048</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e377-x2">
  <m id="m994-d1t380-2">
   <w.rf>
    <LM>w#w-d1t380-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1e377-x2-370">
   <w.rf>
    <LM>w#w-d1e377-x2-370</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t380-1">
   <w.rf>
    <LM>w#w-d1t380-1</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m994-d1e377-x2-373">
   <w.rf>
    <LM>w#w-d1e377-x2-373</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x2">
  <m id="m994-d1t390-3">
   <w.rf>
    <LM>w#w-d1t390-3</LM>
   </w.rf>
   <form>Sebrali</form>
   <lemma>sebrat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t390-4">
   <w.rf>
    <LM>w#w-d1t390-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t390-5">
   <w.rf>
    <LM>w#w-d1t390-5</LM>
   </w.rf>
   <form>telefon</form>
   <lemma>telefon</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-d1e385-x2-1257">
   <w.rf>
    <LM>w#w-d1e385-x2-1257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1258">
  <m id="m994-d1t394-5">
   <w.rf>
    <LM>w#w-d1t394-5</LM>
   </w.rf>
   <form>Zabarikádovala</form>
   <lemma>zabarikádovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t394-3">
   <w.rf>
    <LM>w#w-d1t394-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t394-4">
   <w.rf>
    <LM>w#w-d1t394-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t394-6">
   <w.rf>
    <LM>w#w-d1t394-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t394-8">
   <w.rf>
    <LM>w#w-d1t394-8</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d-id67503">
   <w.rf>
    <LM>w#w-d-id67503</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t394-11">
   <w.rf>
    <LM>w#w-d1t394-11</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m994-d1t394-10">
   <w.rf>
    <LM>w#w-d1t394-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t394-12">
   <w.rf>
    <LM>w#w-d1t394-12</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t394-13">
   <w.rf>
    <LM>w#w-d1t394-13</LM>
   </w.rf>
   <form>bytelné</form>
   <lemma>bytelný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m994-d1t394-14">
   <w.rf>
    <LM>w#w-d1t394-14</LM>
   </w.rf>
   <form>dveře</form>
   <lemma>dveře</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m994-d1e385-x2-496">
   <w.rf>
    <LM>w#w-d1e385-x2-496</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e385-x2-480">
   <w.rf>
    <LM>w#w-d1e385-x2-480</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t401-1">
   <w.rf>
    <LM>w#w-d1t401-1</LM>
   </w.rf>
   <form>dobýval</form>
   <lemma>dobývat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t399-2">
   <w.rf>
    <LM>w#w-d1t399-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t399-3">
   <w.rf>
    <LM>w#w-d1t399-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t399-4">
   <w.rf>
    <LM>w#w-d1t399-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t401-3">
   <w.rf>
    <LM>w#w-d1t401-3</LM>
   </w.rf>
   <form>domovník</form>
   <lemma>domovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t401-4">
   <w.rf>
    <LM>w#w-d1t401-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t401-5">
   <w.rf>
    <LM>w#w-d1t401-5</LM>
   </w.rf>
   <form>Rusy</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m994-d1e385-x2-498">
   <w.rf>
    <LM>w#w-d1e385-x2-498</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-481">
  <m id="m994-d1t405-4">
   <w.rf>
    <LM>w#w-d1t405-4</LM>
   </w.rf>
   <form>Neotevřela</form>
   <lemma>otevřít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m994-d1t405-2">
   <w.rf>
    <LM>w#w-d1t405-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t405-3">
   <w.rf>
    <LM>w#w-d1t405-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m994-d1e385-x2-501">
   <w.rf>
    <LM>w#w-d1e385-x2-501</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t405-5">
   <w.rf>
    <LM>w#w-d1t405-5</LM>
   </w.rf>
   <form>volala</form>
   <lemma>volat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t405-6">
   <w.rf>
    <LM>w#w-d1t405-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t405-7">
   <w.rf>
    <LM>w#w-d1t405-7</LM>
   </w.rf>
   <form>policii</form>
   <lemma>policie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-d1e385-x2-503">
   <w.rf>
    <LM>w#w-d1e385-x2-503</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t405-8">
   <w.rf>
    <LM>w#w-d1t405-8</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t405-9">
   <w.rf>
    <LM>w#w-d1t405-9</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t405-10">
   <w.rf>
    <LM>w#w-d1t405-10</LM>
   </w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1e385-x2-506">
   <w.rf>
    <LM>w#w-d1e385-x2-506</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-507">
  <m id="m994-507-553">
   <w.rf>
    <LM>w#w-507-553</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t407-3">
   <w.rf>
    <LM>w#w-d1t407-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t407-7">
   <w.rf>
    <LM>w#w-d1t407-7</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t407-5">
   <w.rf>
    <LM>w#w-d1t407-5</LM>
   </w.rf>
   <form>nemůžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m994-507-545">
   <w.rf>
    <LM>w#w-507-545</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-507-554">
   <w.rf>
    <LM>w#w-507-554</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-546">
  <m id="m994-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t412-1">
   <w.rf>
    <LM>w#w-d1t412-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t412-2">
   <w.rf>
    <LM>w#w-d1t412-2</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m994-d1t412-3">
   <w.rf>
    <LM>w#w-d1t412-3</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m994-d-id68212">
   <w.rf>
    <LM>w#w-d-id68212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x3">
  <m id="m994-d1t420-5">
   <w.rf>
    <LM>w#w-d1t420-5</LM>
   </w.rf>
   <form>Chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t420-3">
   <w.rf>
    <LM>w#w-d1t420-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m994-d1t420-4">
   <w.rf>
    <LM>w#w-d1t420-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t420-6">
   <w.rf>
    <LM>w#w-d1t420-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m994-d-id68378">
   <w.rf>
    <LM>w#w-d-id68378</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t420-8">
   <w.rf>
    <LM>w#w-d1t420-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m994-d1t420-9">
   <w.rf>
    <LM>w#w-d1t420-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t420-10">
   <w.rf>
    <LM>w#w-d1t420-10</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t420-11">
   <w.rf>
    <LM>w#w-d1t420-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t420-12">
   <w.rf>
    <LM>w#w-d1t420-12</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m994-d1t422-1">
   <w.rf>
    <LM>w#w-d1t422-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t422-3">
   <w.rf>
    <LM>w#w-d1t422-3</LM>
   </w.rf>
   <form>Heydricha</form>
   <lemma>Heydrich_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m994-d1e385-x3-670">
   <w.rf>
    <LM>w#w-d1e385-x3-670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-671">
  <m id="m994-d1t427-2">
   <w.rf>
    <LM>w#w-d1t427-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-671-1268">
   <w.rf>
    <LM>w#w-671-1268</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t427-3">
   <w.rf>
    <LM>w#w-d1t427-3</LM>
   </w.rf>
   <form>hlášená</form>
   <lemma>hlášený_^(*4sit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m994-d1t425-1">
   <w.rf>
    <LM>w#w-d1t425-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t425-2">
   <w.rf>
    <LM>w#w-d1t425-2</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d1t427-4">
   <w.rf>
    <LM>w#w-d1t427-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t427-5">
   <w.rf>
    <LM>w#w-d1t427-5</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m994-d1e385-x3-668">
   <w.rf>
    <LM>w#w-d1e385-x3-668</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-671-688">
   <w.rf>
    <LM>w#w-671-688</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t427-6">
   <w.rf>
    <LM>w#w-d1t427-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m994-d1t427-7">
   <w.rf>
    <LM>w#w-d1t427-7</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t427-9">
   <w.rf>
    <LM>w#w-d1t427-9</LM>
   </w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m994-d-id68690">
   <w.rf>
    <LM>w#w-d-id68690</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t427-11">
   <w.rf>
    <LM>w#w-d1t427-11</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m994-671-689">
   <w.rf>
    <LM>w#w-671-689</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t427-12">
   <w.rf>
    <LM>w#w-d1t427-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t427-13">
   <w.rf>
    <LM>w#w-d1t427-13</LM>
   </w.rf>
   <form>hlášená</form>
   <lemma>hlášený_^(*4sit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m994-671-690">
   <w.rf>
    <LM>w#w-671-690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-681">
  <m id="m994-d1t435-1">
   <w.rf>
    <LM>w#w-d1t435-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t435-2">
   <w.rf>
    <LM>w#w-d1t435-2</LM>
   </w.rf>
   <form>hledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t438-2">
   <w.rf>
    <LM>w#w-d1t438-2</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-d1t438-3">
   <w.rf>
    <LM>w#w-d1t438-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t440-2">
   <w.rf>
    <LM>w#w-d1t440-2</LM>
   </w.rf>
   <form>kabát</form>
   <lemma>kabát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-681-735">
   <w.rf>
    <LM>w#w-681-735</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t442-1">
   <w.rf>
    <LM>w#w-d1t442-1</LM>
   </w.rf>
   <form>baloňák</form>
   <lemma>baloňák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-d-id69002">
   <w.rf>
    <LM>w#w-d-id69002</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t442-4">
   <w.rf>
    <LM>w#w-d1t442-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m994-d1t442-7">
   <w.rf>
    <LM>w#w-d1t442-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t442-8">
   <w.rf>
    <LM>w#w-d1t442-8</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t442-6">
   <w.rf>
    <LM>w#w-d1t442-6</LM>
   </w.rf>
   <form>parašutisti</form>
   <lemma>parašutista</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m994-d-id69104">
   <w.rf>
    <LM>w#w-d-id69104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x4">
  <m id="m994-d1t451-2">
   <w.rf>
    <LM>w#w-d1t451-2</LM>
   </w.rf>
   <form>Nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m994-d1t451-3">
   <w.rf>
    <LM>w#w-d1t451-3</LM>
   </w.rf>
   <form>nesměl</form>
   <lemma>smět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m994-d1t451-4">
   <w.rf>
    <LM>w#w-d1t451-4</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d1t451-5">
   <w.rf>
    <LM>w#w-d1t451-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t451-6">
   <w.rf>
    <LM>w#w-d1t451-6</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d-id69256">
   <w.rf>
    <LM>w#w-d-id69256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e385-x4-659">
   <w.rf>
    <LM>w#w-d1e385-x4-659</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m994-d1t451-8">
   <w.rf>
    <LM>w#w-d1t451-8</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m994-d1t451-9">
   <w.rf>
    <LM>w#w-d1t451-9</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m994-d1t451-10">
   <w.rf>
    <LM>w#w-d1t451-10</LM>
   </w.rf>
   <form>hlášený</form>
   <lemma>hlášený_^(*4sit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m994-d1e385-x4-810">
   <w.rf>
    <LM>w#w-d1e385-x4-810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-816">
  <m id="m994-d1t453-1">
   <w.rf>
    <LM>w#w-d1t453-1</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t453-2">
   <w.rf>
    <LM>w#w-d1t453-2</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m994-d1t453-3">
   <w.rf>
    <LM>w#w-d1t453-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t457-3">
   <w.rf>
    <LM>w#w-d1t457-3</LM>
   </w.rf>
   <form>četník</form>
   <lemma>četník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t459-1">
   <w.rf>
    <LM>w#w-d1t459-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t459-2">
   <w.rf>
    <LM>w#w-d1t459-2</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t459-3">
   <w.rf>
    <LM>w#w-d1t459-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d1t459-4">
   <w.rf>
    <LM>w#w-d1t459-4</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1-------</tag>
  </m>
  <m id="m994-d1t459-5">
   <w.rf>
    <LM>w#w-d1t459-5</LM>
   </w.rf>
   <form>občanku</form>
   <lemma>občanka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m994-816-1275">
   <w.rf>
    <LM>w#w-816-1275</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1276">
  <m id="m994-d1t459-7">
   <w.rf>
    <LM>w#w-d1t459-7</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t459-8">
   <w.rf>
    <LM>w#w-d1t459-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t459-9">
   <w.rf>
    <LM>w#w-d1t459-9</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m994-d1t459-10">
   <w.rf>
    <LM>w#w-d1t459-10</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m994-d1t459-11">
   <w.rf>
    <LM>w#w-d1t459-11</LM>
   </w.rf>
   <form>dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t459-12">
   <w.rf>
    <LM>w#w-d1t459-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t459-13">
   <w.rf>
    <LM>w#w-d1t459-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t459-15">
   <w.rf>
    <LM>w#w-d1t459-15</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-816-826">
   <w.rf>
    <LM>w#w-816-826</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t459-16">
   <w.rf>
    <LM>w#w-d1t459-16</LM>
   </w.rf>
   <form>Kostečná</form>
   <lemma>kostečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m994-d1t459-17">
   <w.rf>
    <LM>w#w-d1t459-17</LM>
   </w.rf>
   <form>ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-816-827">
   <w.rf>
    <LM>w#w-816-827</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d-id69670">
   <w.rf>
    <LM>w#w-d-id69670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x5">
  <m id="m994-d1e385-x5-914">
   <w.rf>
    <LM>w#w-d1e385-x5-914</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t464-1">
   <w.rf>
    <LM>w#w-d1t464-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t464-2">
   <w.rf>
    <LM>w#w-d1t464-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d-id69733">
   <w.rf>
    <LM>w#w-d-id69733</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t464-4">
   <w.rf>
    <LM>w#w-d1t464-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t464-6">
   <w.rf>
    <LM>w#w-d1t464-6</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m994-d1t464-5">
   <w.rf>
    <LM>w#w-d1t464-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t464-7">
   <w.rf>
    <LM>w#w-d1t464-7</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-899">
  <m id="m994-d1t464-8">
   <w.rf>
    <LM>w#w-d1t464-8</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m994-d1t464-9">
   <w.rf>
    <LM>w#w-d1t464-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t464-10">
   <w.rf>
    <LM>w#w-d1t464-10</LM>
   </w.rf>
   <form>nebydlíte</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m994-899-906">
   <w.rf>
    <LM>w#w-899-906</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-899-918">
   <w.rf>
    <LM>w#w-899-918</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-907">
  <m id="m994-d1t464-19">
   <w.rf>
    <LM>w#w-d1t464-19</LM>
   </w.rf>
   <form>Vysvětlovala</form>
   <lemma>vysvětlovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t464-13">
   <w.rf>
    <LM>w#w-d1t464-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t464-17">
   <w.rf>
    <LM>w#w-d1t464-17</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m994-907-986">
   <w.rf>
    <LM>w#w-907-986</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t464-20">
   <w.rf>
    <LM>w#w-d1t464-20</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t464-22">
   <w.rf>
    <LM>w#w-d1t464-22</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t464-21">
   <w.rf>
    <LM>w#w-d1t464-21</LM>
   </w.rf>
   <form>myslela</form>
   <lemma>myslit</lemma>
   <tag>VpQW----R-AAI-1</tag>
  </m>
  <m id="m994-d-id70009">
   <w.rf>
    <LM>w#w-d-id70009</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t464-24">
   <w.rf>
    <LM>w#w-d1t464-24</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t466-2">
   <w.rf>
    <LM>w#w-d1t466-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-907-989">
   <w.rf>
    <LM>w#w-907-989</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m994-d1t466-5">
   <w.rf>
    <LM>w#w-d1t466-5</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m994-d1t466-6">
   <w.rf>
    <LM>w#w-d1t466-6</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1t466-7">
   <w.rf>
    <LM>w#w-d1t466-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t466-8">
   <w.rf>
    <LM>w#w-d1t466-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t466-9">
   <w.rf>
    <LM>w#w-d1t466-9</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d-id70162">
   <w.rf>
    <LM>w#w-d-id70162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x6">
  <m id="m994-d1t472-3">
   <w.rf>
    <LM>w#w-d1t472-3</LM>
   </w.rf>
   <form>Odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t472-4">
   <w.rf>
    <LM>w#w-d1t472-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t472-5">
   <w.rf>
    <LM>w#w-d1t472-5</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t472-6">
   <w.rf>
    <LM>w#w-d1t472-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t474-1">
   <w.rf>
    <LM>w#w-d1t474-1</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m994-d1t474-2">
   <w.rf>
    <LM>w#w-d1t474-2</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m994-d1t479-1">
   <w.rf>
    <LM>w#w-d1t479-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t479-2">
   <w.rf>
    <LM>w#w-d1t479-2</LM>
   </w.rf>
   <form>odvedl</form>
   <lemma>odvést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t479-3">
   <w.rf>
    <LM>w#w-d1t479-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1e385-x6-1028">
   <w.rf>
    <LM>w#w-d1e385-x6-1028</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t479-4">
   <w.rf>
    <LM>w#w-d1t479-4</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m994-d-id70416">
   <w.rf>
    <LM>w#w-d-id70416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x7">
  <m id="m994-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m994-d1t481-5">
   <w.rf>
    <LM>w#w-d1t481-5</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d-id70518">
   <w.rf>
    <LM>w#w-d-id70518</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e385-x8">
  <m id="m994-d1t487-1">
   <w.rf>
    <LM>w#w-d1t487-1</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m994-d1t487-3">
   <w.rf>
    <LM>w#w-d1t487-3</LM>
   </w.rf>
   <form>elektrikou</form>
   <lemma>elektrika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m994-d1t494-1">
   <w.rf>
    <LM>w#w-d1t494-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m994-d1t494-2">
   <w.rf>
    <LM>w#w-d1t494-2</LM>
   </w.rf>
   <form>Pivovarnické</form>
   <lemma>pivovarnický</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m994-d1t494-3">
   <w.rf>
    <LM>w#w-d1t494-3</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m994-d1e385-x8-1196">
   <w.rf>
    <LM>w#w-d1e385-x8-1196</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t500-1">
   <w.rf>
    <LM>w#w-d1t500-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t500-2">
   <w.rf>
    <LM>w#w-d1t500-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t500-3">
   <w.rf>
    <LM>w#w-d1t500-3</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t500-4">
   <w.rf>
    <LM>w#w-d1t500-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m994-d1t500-5">
   <w.rf>
    <LM>w#w-d1t500-5</LM>
   </w.rf>
   <form>nějakému</form>
   <lemma>nějaký</lemma>
   <tag>PZZS3----------</tag>
  </m>
  <m id="m994-d1e385-x8-1201">
   <w.rf>
    <LM>w#w-d1e385-x8-1201</LM>
   </w.rf>
   <form>pánovi</form>
   <lemma>pán</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m994-d1e385-x8-1294">
   <w.rf>
    <LM>w#w-d1e385-x8-1294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1295">
  <m id="m994-d1t505-1">
   <w.rf>
    <LM>w#w-d1t505-1</LM>
   </w.rf>
   <form>Kdybych</form>
   <lemma>kdyby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m994-d1t505-2">
   <w.rf>
    <LM>w#w-d1t505-2</LM>
   </w.rf>
   <form>věděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t505-3">
   <w.rf>
    <LM>w#w-d1t505-3</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m994-d1t505-4">
   <w.rf>
    <LM>w#w-d1t505-4</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-d-id70905">
   <w.rf>
    <LM>w#w-d-id70905</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t505-6">
   <w.rf>
    <LM>w#w-d1t505-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t505-7">
   <w.rf>
    <LM>w#w-d1t505-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t505-9">
   <w.rf>
    <LM>w#w-d1t505-9</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t505-8">
   <w.rf>
    <LM>w#w-d1t505-8</LM>
   </w.rf>
   <form>odnese</form>
   <lemma>odnést</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m994-1295-1296">
   <w.rf>
    <LM>w#w-1295-1296</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1297">
  <m id="m994-d1t505-13">
   <w.rf>
    <LM>w#w-d1t505-13</LM>
   </w.rf>
   <form>Začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t505-12">
   <w.rf>
    <LM>w#w-d1t505-12</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m994-d1t507-1">
   <w.rf>
    <LM>w#w-d1t507-1</LM>
   </w.rf>
   <form>šíleně</form>
   <lemma>šíleně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m994-d1t505-14">
   <w.rf>
    <LM>w#w-d1t505-14</LM>
   </w.rf>
   <form>nadávat</form>
   <lemma>nadávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d1e385-x8-1202">
   <w.rf>
    <LM>w#w-d1e385-x8-1202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1203">
  <m id="m994-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>Nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m994-d1t509-4">
   <w.rf>
    <LM>w#w-d1t509-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-d1t509-5">
   <w.rf>
    <LM>w#w-d1t509-5</LM>
   </w.rf>
   <form>opakovat</form>
   <lemma>opakovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m994-d1t509-6">
   <w.rf>
    <LM>w#w-d1t509-6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-1203-1308">
   <w.rf>
    <LM>w#w-1203-1308</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t509-7">
   <w.rf>
    <LM>w#w-d1t509-7</LM>
   </w.rf>
   <form>svině</form>
   <lemma>svině</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m994-1203-1309">
   <w.rf>
    <LM>w#w-1203-1309</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t509-8">
   <w.rf>
    <LM>w#w-d1t509-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t509-10">
   <w.rf>
    <LM>w#w-d1t509-10</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-1203-1298">
   <w.rf>
    <LM>w#w-1203-1298</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t509-11">
   <w.rf>
    <LM>w#w-d1t509-11</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m994-d1t509-12">
   <w.rf>
    <LM>w#w-d1t509-12</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m994-1203-1312">
   <w.rf>
    <LM>w#w-1203-1312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1313">
  <m id="m994-d1t513-4">
   <w.rf>
    <LM>w#w-d1t513-4</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t513-3">
   <w.rf>
    <LM>w#w-d1t513-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t513-2">
   <w.rf>
    <LM>w#w-d1t513-2</LM>
   </w.rf>
   <form>odvedli</form>
   <lemma>odvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t520-4">
   <w.rf>
    <LM>w#w-d1t520-4</LM>
   </w.rf>
   <form>četníky</form>
   <lemma>četník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m994-d1t522-1">
   <w.rf>
    <LM>w#w-d1t522-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t522-2">
   <w.rf>
    <LM>w#w-d1t522-2</LM>
   </w.rf>
   <form>odvoz</form>
   <lemma>odvoz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-d1t522-3">
   <w.rf>
    <LM>w#w-d1t522-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-1203-1293">
   <w.rf>
    <LM>w#w-1203-1293</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-1203-1294">
   <w.rf>
    <LM>w#w-1203-1294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-1203-1295">
   <w.rf>
    <LM>w#w-1203-1295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1296">
  <m id="m994-d1t531-1">
   <w.rf>
    <LM>w#w-d1t531-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t531-2">
   <w.rf>
    <LM>w#w-d1t531-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t531-3">
   <w.rf>
    <LM>w#w-d1t531-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m994-d1t531-4">
   <w.rf>
    <LM>w#w-d1t531-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t531-5">
   <w.rf>
    <LM>w#w-d1t531-5</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m994-d-id71735">
   <w.rf>
    <LM>w#w-d-id71735</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t531-7">
   <w.rf>
    <LM>w#w-d1t531-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t531-8">
   <w.rf>
    <LM>w#w-d1t531-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t531-9">
   <w.rf>
    <LM>w#w-d1t531-9</LM>
   </w.rf>
   <form>stříleli</form>
   <lemma>střílet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d-id71783">
   <w.rf>
    <LM>w#w-d-id71783</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e538-x2">
  <m id="m994-d1t543-2">
   <w.rf>
    <LM>w#w-d1t543-2</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-d1e538-x2-1405">
   <w.rf>
    <LM>w#w-d1e538-x2-1405</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1452">
  <m id="m994-d1t545-1">
   <w.rf>
    <LM>w#w-d1t545-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m994-d1t545-2">
   <w.rf>
    <LM>w#w-d1t545-2</LM>
   </w.rf>
   <form>čtvrť</form>
   <lemma>čtvrť_^(města)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t545-3">
   <w.rf>
    <LM>w#w-d1t545-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-1452-1471">
   <w.rf>
    <LM>w#w-1452-1471</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1406">
  <m id="m994-d1t543-4">
   <w.rf>
    <LM>w#w-d1t543-4</LM>
   </w.rf>
   <form>Ruzyně</form>
   <lemma>Ruzyně_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d-id71982">
   <w.rf>
    <LM>w#w-d-id71982</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1553">
  <m id="m994-d1t554-2">
   <w.rf>
    <LM>w#w-d1t554-2</LM>
   </w.rf>
   <form>Ruzyně</form>
   <lemma>Ruzyně_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m994-d1t554-1">
   <w.rf>
    <LM>w#w-d1t554-1</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m994-1553-1564">
   <w.rf>
    <LM>w#w-1553-1564</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e538-x4">
  <m id="m994-d1t552-1">
   <w.rf>
    <LM>w#w-d1t552-1</LM>
   </w.rf>
   <form>Kobylisy</form>
   <lemma>Kobylisy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m994-d-id72086">
   <w.rf>
    <LM>w#w-d-id72086</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e538-x6">
  <m id="m994-d1t554-4">
   <w.rf>
    <LM>w#w-d1t554-4</LM>
   </w.rf>
   <form>Kobylisy</form>
   <lemma>Kobylisy_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m994-d-id72159">
   <w.rf>
    <LM>w#w-d-id72159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x2">
  <m id="m994-d1t560-5">
   <w.rf>
    <LM>w#w-d1t560-5</LM>
   </w.rf>
   <form>Rozbrečela</form>
   <lemma>rozbrečet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-d1t560-2">
   <w.rf>
    <LM>w#w-d1t560-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t560-3">
   <w.rf>
    <LM>w#w-d1t560-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t560-4">
   <w.rf>
    <LM>w#w-d1t560-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1e555-x2-1632">
   <w.rf>
    <LM>w#w-d1e555-x2-1632</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t564-3">
   <w.rf>
    <LM>w#w-d1t564-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t564-2">
   <w.rf>
    <LM>w#w-d1t564-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t564-4">
   <w.rf>
    <LM>w#w-d1t564-4</LM>
   </w.rf>
   <form>utěšovali</form>
   <lemma>utěšovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m994-d1e555-x2-1357">
   <w.rf>
    <LM>w#w-d1e555-x2-1357</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1358">
  <m id="m994-d1t564-10">
   <w.rf>
    <LM>w#w-d1t564-10</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m994-1358-1359">
   <w.rf>
    <LM>w#w-1358-1359</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d-id72476">
   <w.rf>
    <LM>w#w-d-id72476</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x2-1627">
   <w.rf>
    <LM>w#w-d1e555-x2-1627</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t564-12">
   <w.rf>
    <LM>w#w-d1t564-12</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t564-13">
   <w.rf>
    <LM>w#w-d1t564-13</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m994-d-id72516">
   <w.rf>
    <LM>w#w-d-id72516</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t564-15">
   <w.rf>
    <LM>w#w-d1t564-15</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t564-16">
   <w.rf>
    <LM>w#w-d1t564-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t564-17">
   <w.rf>
    <LM>w#w-d1t564-17</LM>
   </w.rf>
   <form>zavolat</form>
   <lemma>zavolat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m994-d-id72571">
   <w.rf>
    <LM>w#w-d-id72571</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x2-1630">
   <w.rf>
    <LM>w#w-d1e555-x2-1630</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x3">
  <m id="m994-d1t571-1">
   <w.rf>
    <LM>w#w-d1t571-1</LM>
   </w.rf>
   <form>Řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m994-d1e555-x3-1712">
   <w.rf>
    <LM>w#w-d1e555-x3-1712</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x3-1713">
   <w.rf>
    <LM>w#w-d1e555-x3-1713</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t571-2">
   <w.rf>
    <LM>w#w-d1t571-2</LM>
   </w.rf>
   <form>Zavolejte</form>
   <lemma>zavolat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m994-d1t571-3">
   <w.rf>
    <LM>w#w-d1t571-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1e555-x3-1715">
   <w.rf>
    <LM>w#w-d1e555-x3-1715</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x3-1716">
   <w.rf>
    <LM>w#w-d1e555-x3-1716</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1705">
  <m id="m994-d1t571-5">
   <w.rf>
    <LM>w#w-d1t571-5</LM>
   </w.rf>
   <form>Volala</form>
   <lemma>volat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-1705-1363">
   <w.rf>
    <LM>w#w-1705-1363</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t573-1">
   <w.rf>
    <LM>w#w-d1t573-1</LM>
   </w.rf>
   <form>Fídlera</form>
   <lemma>Fídler_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d-id72709">
   <w.rf>
    <LM>w#w-d-id72709</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t573-3">
   <w.rf>
    <LM>w#w-d1t573-3</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m994-d1t573-4">
   <w.rf>
    <LM>w#w-d1t573-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t573-15">
   <w.rf>
    <LM>w#w-d1t573-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m994-d1t573-13">
   <w.rf>
    <LM>w#w-d1t573-13</LM>
   </w.rf>
   <form>nemohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m994-d1t573-17">
   <w.rf>
    <LM>w#w-d1t573-17</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t573-18">
   <w.rf>
    <LM>w#w-d1t573-18</LM>
   </w.rf>
   <form>dovolat</form>
   <lemma>dovolat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m994-1705-1724">
   <w.rf>
    <LM>w#w-1705-1724</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t573-9">
   <w.rf>
    <LM>w#w-d1t573-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t573-10">
   <w.rf>
    <LM>w#w-d1t573-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t573-12">
   <w.rf>
    <LM>w#w-d1t573-12</LM>
   </w.rf>
   <form>Devisen</form>
   <lemma>Devisen-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m994-1705-1364">
   <w.rf>
    <LM>w#w-1705-1364</LM>
   </w.rf>
   <form>Schutzu</form>
   <lemma>schutz</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-1705-1365">
   <w.rf>
    <LM>w#w-1705-1365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1366">
  <m id="m994-d1t575-2">
   <w.rf>
    <LM>w#w-d1t575-2</LM>
   </w.rf>
   <form>Buďto</form>
   <lemma>buďto</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-1366-1367">
   <w.rf>
    <LM>w#w-1366-1367</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m994-d1t575-3">
   <w.rf>
    <LM>w#w-d1t575-3</LM>
   </w.rf>
   <form>obsazeno</form>
   <lemma>obsadit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m994-1705-1727">
   <w.rf>
    <LM>w#w-1705-1727</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t575-4">
   <w.rf>
    <LM>w#w-d1t575-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t575-5">
   <w.rf>
    <LM>w#w-d1t575-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t575-6">
   <w.rf>
    <LM>w#w-d1t575-6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m994-1705-1728">
   <w.rf>
    <LM>w#w-1705-1728</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1729">
  <m id="m994-d1t577-3">
   <w.rf>
    <LM>w#w-d1t577-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t577-4">
   <w.rf>
    <LM>w#w-d1t577-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t577-5">
   <w.rf>
    <LM>w#w-d1t577-5</LM>
   </w.rf>
   <form>aparátu</form>
   <lemma>aparát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m994-d-id73132">
   <w.rf>
    <LM>w#w-d-id73132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x4">
  <m id="m994-d1t588-1">
   <w.rf>
    <LM>w#w-d1t588-1</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t584-2">
   <w.rf>
    <LM>w#w-d1t584-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t584-3">
   <w.rf>
    <LM>w#w-d1t584-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m994-d-id73269">
   <w.rf>
    <LM>w#w-d-id73269</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t588-3">
   <w.rf>
    <LM>w#w-d1t588-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m994-d1t588-4">
   <w.rf>
    <LM>w#w-d1t588-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t588-5">
   <w.rf>
    <LM>w#w-d1t588-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1e555-x4-1882">
   <w.rf>
    <LM>w#w-d1e555-x4-1882</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t588-9">
   <w.rf>
    <LM>w#w-d1t588-9</LM>
   </w.rf>
   <form>čekám</form>
   <lemma>čekat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t588-6">
   <w.rf>
    <LM>w#w-d1t588-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t588-7">
   <w.rf>
    <LM>w#w-d1t588-7</LM>
   </w.rf>
   <form>odvoz</form>
   <lemma>odvoz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m994-d1e555-x4-1372">
   <w.rf>
    <LM>w#w-d1e555-x4-1372</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1373">
  <m id="m994-d1t595-1">
   <w.rf>
    <LM>w#w-d1t595-1</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m994-d1e555-x4-1872">
   <w.rf>
    <LM>w#w-d1e555-x4-1872</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x4-1873">
   <w.rf>
    <LM>w#w-d1e555-x4-1873</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t595-2">
   <w.rf>
    <LM>w#w-d1t595-2</LM>
   </w.rf>
   <form>Počkej</form>
   <lemma>počkat</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m994-d-id73459">
   <w.rf>
    <LM>w#w-d-id73459</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t595-5">
   <w.rf>
    <LM>w#w-d1t595-5</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t595-6">
   <w.rf>
    <LM>w#w-d1t595-6</LM>
   </w.rf>
   <form>přijdu</form>
   <lemma>přijít</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m994-d1e555-x4-1877">
   <w.rf>
    <LM>w#w-d1e555-x4-1877</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1e555-x4-1876">
   <w.rf>
    <LM>w#w-d1e555-x4-1876</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-933">
  <m id="m994-d1t597-4">
   <w.rf>
    <LM>w#w-d1t597-4</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t595-11">
   <w.rf>
    <LM>w#w-d1t595-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m994-933-1377">
   <w.rf>
    <LM>w#w-933-1377</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t595-9">
   <w.rf>
    <LM>w#w-d1t595-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t595-10">
   <w.rf>
    <LM>w#w-d1t595-10</LM>
   </w.rf>
   <form>kým</form>
   <lemma>kdo</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m994-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t595-12">
   <w.rf>
    <LM>w#w-d1t595-12</LM>
   </w.rf>
   <form>mluvila</form>
   <lemma>mluvit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1e555-x4-1890">
   <w.rf>
    <LM>w#w-d1e555-x4-1890</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-1883">
  <m id="m994-d1t599-4">
   <w.rf>
    <LM>w#w-d1t599-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t599-5">
   <w.rf>
    <LM>w#w-d1t599-5</LM>
   </w.rf>
   <form>soudce</form>
   <lemma>soudce_^(člověk,_který_soudí)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-1883-1381">
   <w.rf>
    <LM>w#w-1883-1381</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t601-3">
   <w.rf>
    <LM>w#w-d1t601-3</LM>
   </w.rf>
   <form>školil</form>
   <lemma>školit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t601-4">
   <w.rf>
    <LM>w#w-d1t601-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m994-d1t601-7">
   <w.rf>
    <LM>w#w-d1t601-7</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m994-d1t601-9">
   <w.rf>
    <LM>w#w-d1t601-9</LM>
   </w.rf>
   <form>úředníky</form>
   <lemma>úředník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m994-1883-1944">
   <w.rf>
    <LM>w#w-1883-1944</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t601-11">
   <w.rf>
    <LM>w#w-d1t601-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t601-12">
   <w.rf>
    <LM>w#w-d1t601-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m994-d1t603-1">
   <w.rf>
    <LM>w#w-d1t603-1</LM>
   </w.rf>
   <form>Devisen</form>
   <lemma>Devisen-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m994-1883-1382">
   <w.rf>
    <LM>w#w-1883-1382</LM>
   </w.rf>
   <form>Schutzu</form>
   <lemma>schutz</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m994-d-id74039">
   <w.rf>
    <LM>w#w-d-id74039</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x5">
  <m id="m994-d1t610-2">
   <w.rf>
    <LM>w#w-d1t610-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t610-3">
   <w.rf>
    <LM>w#w-d1t610-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Poloněmec</form>
   <lemma>Poloněmec_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m994-d1e555-x5-1975">
   <w.rf>
    <LM>w#w-d1e555-x5-1975</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m994-d1t612-2">
   <w.rf>
    <LM>w#w-d1t612-2</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m994-d1t612-1">
   <w.rf>
    <LM>w#w-d1t612-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m994-d1t610-5">
   <w.rf>
    <LM>w#w-d1t610-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t610-6">
   <w.rf>
    <LM>w#w-d1t610-6</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m994-d1t612-3">
   <w.rf>
    <LM>w#w-d1t612-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m994-d1t612-4">
   <w.rf>
    <LM>w#w-d1t612-4</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m994-d-id74229">
   <w.rf>
    <LM>w#w-d-id74229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x6">
  <m id="m994-d1t616-6">
   <w.rf>
    <LM>w#w-d1t616-6</LM>
   </w.rf>
   <form>Došel</form>
   <lemma>dojít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m994-d1t616-10">
   <w.rf>
    <LM>w#w-d1t616-10</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m994-d1t616-11">
   <w.rf>
    <LM>w#w-d1t616-11</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m994-d1e555-x6-2022">
   <w.rf>
    <LM>w#w-d1e555-x6-2022</LM>
   </w.rf>
   <form>chlápkem</form>
   <lemma>chlápek</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m994-d1t618-1">
   <w.rf>
    <LM>w#w-d1t618-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t618-4">
   <w.rf>
    <LM>w#w-d1t618-4</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m994-d1t618-3">
   <w.rf>
    <LM>w#w-d1t618-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m994-d1t618-5">
   <w.rf>
    <LM>w#w-d1t618-5</LM>
   </w.rf>
   <form>propustit</form>
   <lemma>propustit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m994-d-id74506">
   <w.rf>
    <LM>w#w-d-id74506</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m994-25819_04-d1e555-x7">
  <m id="m994-d1t623-1">
   <w.rf>
    <LM>w#w-d1t623-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m994-d1t623-4">
   <w.rf>
    <LM>w#w-d1t623-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t623-6">
   <w.rf>
    <LM>w#w-d1t623-6</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m994-d1t623-7">
   <w.rf>
    <LM>w#w-d1t623-7</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m994-d1t623-3">
   <w.rf>
    <LM>w#w-d1t623-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m994-d1t623-8">
   <w.rf>
    <LM>w#w-d1t623-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m994-d1t623-10">
   <w.rf>
    <LM>w#w-d1t623-10</LM>
   </w.rf>
   <form>boha</form>
   <lemma>bůh</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m994-d1t623-9">
   <w.rf>
    <LM>w#w-d1t623-9</LM>
   </w.rf>
   <form>živého</form>
   <lemma>živý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m994-d1t623-11">
   <w.rf>
    <LM>w#w-d1t623-11</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m994-d1t623-12">
   <w.rf>
    <LM>w#w-d1t623-12</LM>
   </w.rf>
   <form>vzpomenout</form>
   <lemma>vzpomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m994-d-id74725">
   <w.rf>
    <LM>w#w-d-id74725</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
