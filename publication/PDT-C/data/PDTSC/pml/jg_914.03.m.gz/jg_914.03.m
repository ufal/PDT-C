<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_914.03.w.gz" />
  </references>
 </head>
 <s id="m914-12941_04-d1e1227-x3">
  <m id="m914-d1t1247-1">
   <w.rf>
    <LM>w#w-d1t1247-1</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m914-d1e1227-x3-1870">
   <w.rf>
    <LM>w#w-d1e1227-x3-1870</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1247-2">
   <w.rf>
    <LM>w#w-d1t1247-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1247-3">
   <w.rf>
    <LM>w#w-d1t1247-3</LM>
   </w.rf>
   <form>navazuji</form>
   <lemma>navazovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m914-d1t1247-4">
   <w.rf>
    <LM>w#w-d1t1247-4</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d1t1247-5">
   <w.rf>
    <LM>w#w-d1t1247-5</LM>
   </w.rf>
   <form>lehce</form>
   <lemma>lehce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d1t1247-6">
   <w.rf>
    <LM>w#w-d1t1247-6</LM>
   </w.rf>
   <form>kontakty</form>
   <lemma>kontakt</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m914-d1e1227-x3-1872">
   <w.rf>
    <LM>w#w-d1e1227-x3-1872</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1245-2">
   <w.rf>
    <LM>w#w-d1t1245-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1247-7">
   <w.rf>
    <LM>w#w-d1t1247-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1247-8">
   <w.rf>
    <LM>w#w-d1t1247-8</LM>
   </w.rf>
   <form>dostával</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1247-9">
   <w.rf>
    <LM>w#w-d1t1247-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1247-10">
   <w.rf>
    <LM>w#w-d1t1247-10</LM>
   </w.rf>
   <form>rodin</form>
   <lemma>rodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m914-d-id98939">
   <w.rf>
    <LM>w#w-d-id98939</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1249-1">
   <w.rf>
    <LM>w#w-d1t1249-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1249-2">
   <w.rf>
    <LM>w#w-d1t1249-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1249-3">
   <w.rf>
    <LM>w#w-d1t1249-3</LM>
   </w.rf>
   <form>Anglii</form>
   <lemma>Anglie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d-id99003">
   <w.rf>
    <LM>w#w-d-id99003</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1249-5">
   <w.rf>
    <LM>w#w-d1t1249-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1249-6">
   <w.rf>
    <LM>w#w-d1t1249-6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m914-d1t1249-7">
   <w.rf>
    <LM>w#w-d1t1249-7</LM>
   </w.rf>
   <form>Skotsku</form>
   <lemma>Skotsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m914-d1e1227-x3-2055">
   <w.rf>
    <LM>w#w-d1e1227-x3-2055</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1254-1">
   <w.rf>
    <LM>w#w-d1t1254-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1254-2">
   <w.rf>
    <LM>w#w-d1t1254-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d1t1254-3">
   <w.rf>
    <LM>w#w-d1t1254-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1254-4">
   <w.rf>
    <LM>w#w-d1t1254-4</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1254-5">
   <w.rf>
    <LM>w#w-d1t1254-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1254-6">
   <w.rf>
    <LM>w#w-d1t1254-6</LM>
   </w.rf>
   <form>kontinentě</form>
   <lemma>kontinent</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-d-id99058">
   <w.rf>
    <LM>w#w-d-id99058</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1227-x4">
  <m id="m914-d1t1256-3">
   <w.rf>
    <LM>w#w-d1t1256-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1256-4">
   <w.rf>
    <LM>w#w-d1t1256-4</LM>
   </w.rf>
   <form>Anglii</form>
   <lemma>Anglie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1256-5">
   <w.rf>
    <LM>w#w-d1t1256-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1256-6">
   <w.rf>
    <LM>w#w-d1t1256-6</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m914-d1t1256-7">
   <w.rf>
    <LM>w#w-d1t1256-7</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m914-d1t1256-8">
   <w.rf>
    <LM>w#w-d1t1256-8</LM>
   </w.rf>
   <form>špatné</form>
   <lemma>špatný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m914-d1t1256-9">
   <w.rf>
    <LM>w#w-d1t1256-9</LM>
   </w.rf>
   <form>zkušenosti</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m914-d1t1258-1">
   <w.rf>
    <LM>w#w-d1t1258-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m914-d1t1258-2">
   <w.rf>
    <LM>w#w-d1t1258-2</LM>
   </w.rf>
   <form>vztahu</form>
   <lemma>vztah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-d1t1258-3">
   <w.rf>
    <LM>w#w-d1t1258-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m914-d1t1258-4">
   <w.rf>
    <LM>w#w-d1t1258-4</LM>
   </w.rf>
   <form>obyvatelstvu</form>
   <lemma>obyvatelstvo</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m914-d1e1227-x4-2059">
   <w.rf>
    <LM>w#w-d1e1227-x4-2059</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1260-1">
   <w.rf>
    <LM>w#w-d1t1260-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1260-2">
   <w.rf>
    <LM>w#w-d1t1260-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1260-4">
   <w.rf>
    <LM>w#w-d1t1260-4</LM>
   </w.rf>
   <form>armádě</form>
   <lemma>armáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1260-5">
   <w.rf>
    <LM>w#w-d1t1260-5</LM>
   </w.rf>
   <form>nemohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI-1</tag>
  </m>
  <m id="m914-d1t1260-6">
   <w.rf>
    <LM>w#w-d1t1260-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m914-d-id99498">
   <w.rf>
    <LM>w#w-d-id99498</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1260-8">
   <w.rf>
    <LM>w#w-d1t1260-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1260-9">
   <w.rf>
    <LM>w#w-d1t1260-9</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m914-d1t1260-10">
   <w.rf>
    <LM>w#w-d1t1260-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1260-11">
   <w.rf>
    <LM>w#w-d1t1260-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1260-12">
   <w.rf>
    <LM>w#w-d1t1260-12</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1260-13">
   <w.rf>
    <LM>w#w-d1t1260-13</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d-id99600">
   <w.rf>
    <LM>w#w-d-id99600</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1261-x2">
  <m id="m914-d1t1266-1">
   <w.rf>
    <LM>w#w-d1t1266-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1266-2">
   <w.rf>
    <LM>w#w-d1t1266-2</LM>
   </w.rf>
   <form>jednotce</form>
   <lemma>jednotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d-id99698">
   <w.rf>
    <LM>w#w-d-id99698</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1266-4">
   <w.rf>
    <LM>w#w-d1t1266-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1266-5">
   <w.rf>
    <LM>w#w-d1t1266-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1266-6">
   <w.rf>
    <LM>w#w-d1t1266-6</LM>
   </w.rf>
   <form>sloužil</form>
   <lemma>sloužit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1e1261-x2-2084">
   <w.rf>
    <LM>w#w-d1e1261-x2-2084</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1266-7">
   <w.rf>
    <LM>w#w-d1t1266-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d1t1268-1">
   <w.rf>
    <LM>w#w-d1t1268-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1268-2">
   <w.rf>
    <LM>w#w-d1t1268-2</LM>
   </w.rf>
   <form>Židé</form>
   <lemma>žid</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m914-d-id99819">
   <w.rf>
    <LM>w#w-d-id99819</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1269-x2">
  <m id="m914-d1t1272-1">
   <w.rf>
    <LM>w#w-d1t1272-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d-id99900">
   <w.rf>
    <LM>w#w-d-id99900</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1272-7">
   <w.rf>
    <LM>w#w-d1t1272-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1272-8">
   <w.rf>
    <LM>w#w-d1t1272-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m914-d1t1272-9">
   <w.rf>
    <LM>w#w-d1t1272-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1272-10">
   <w.rf>
    <LM>w#w-d1t1272-10</LM>
   </w.rf>
   <form>normální</form>
   <lemma>normální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m914-d1t1272-11">
   <w.rf>
    <LM>w#w-d1t1272-11</LM>
   </w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m914-d1e1269-x2-2153">
   <w.rf>
    <LM>w#w-d1e1269-x2-2153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-2154">
  <m id="m914-d1t1274-1">
   <w.rf>
    <LM>w#w-d1t1274-1</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1274-2">
   <w.rf>
    <LM>w#w-d1t1274-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m914-d1t1274-3">
   <w.rf>
    <LM>w#w-d1t1274-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1274-4">
   <w.rf>
    <LM>w#w-d1t1274-4</LM>
   </w.rf>
   <form>nedalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m914-d1t1274-5">
   <w.rf>
    <LM>w#w-d1t1274-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m914-d-id100127">
   <w.rf>
    <LM>w#w-d-id100127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1274-7">
   <w.rf>
    <LM>w#w-d1t1274-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1276-1">
   <w.rf>
    <LM>w#w-d1t1276-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1276-2">
   <w.rf>
    <LM>w#w-d1t1276-2</LM>
   </w.rf>
   <form>Středním</form>
   <lemma>střední</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m914-d1t1276-3">
   <w.rf>
    <LM>w#w-d1t1276-3</LM>
   </w.rf>
   <form>východě</form>
   <lemma>východ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-d1t1276-4">
   <w.rf>
    <LM>w#w-d1t1276-4</LM>
   </w.rf>
   <form>neboli</form>
   <lemma>neboli</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1276-5">
   <w.rf>
    <LM>w#w-d1t1276-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1276-6">
   <w.rf>
    <LM>w#w-d1t1276-6</LM>
   </w.rf>
   <form>Palestině</form>
   <lemma>Palestina_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1278-1">
   <w.rf>
    <LM>w#w-d1t1278-1</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m914-d1t1278-2">
   <w.rf>
    <LM>w#w-d1t1278-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1278-3">
   <w.rf>
    <LM>w#w-d1t1278-3</LM>
   </w.rf>
   <form>česká</form>
   <lemma>český</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m914-d1t1278-4">
   <w.rf>
    <LM>w#w-d1t1278-4</LM>
   </w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m914-d1t1278-5">
   <w.rf>
    <LM>w#w-d1t1278-5</LM>
   </w.rf>
   <form>skládala</form>
   <lemma>skládat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m914-d1t1278-6">
   <w.rf>
    <LM>w#w-d1t1278-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1278-7">
   <w.rf>
    <LM>w#w-d1t1278-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1278-8">
   <w.rf>
    <LM>w#w-d1t1278-8</LM>
   </w.rf>
   <form>Židů</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m914-d-id100380">
   <w.rf>
    <LM>w#w-d-id100380</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1269-x3">
  <m id="m914-d1t1280-1">
   <w.rf>
    <LM>w#w-d1t1280-1</LM>
   </w.rf>
   <form>Zdaleka</form>
   <lemma>zdaleka</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1280-2">
   <w.rf>
    <LM>w#w-d1t1280-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d1e1269-x3-2317">
   <w.rf>
    <LM>w#w-d1e1269-x3-2317</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1287-1">
   <w.rf>
    <LM>w#w-d1t1287-1</LM>
   </w.rf>
   <form>jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1287-6">
   <w.rf>
    <LM>w#w-d1t1287-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m914-d1t1287-7">
   <w.rf>
    <LM>w#w-d1t1287-7</LM>
   </w.rf>
   <form>složena</form>
   <lemma>složit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m914-d1t1289-1">
   <w.rf>
    <LM>w#w-d1t1289-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1289-2">
   <w.rf>
    <LM>w#w-d1t1289-2</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m914-d-id100618">
   <w.rf>
    <LM>w#w-d-id100618</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1289-4">
   <w.rf>
    <LM>w#w-d1t1289-4</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m914-d1t1289-5">
   <w.rf>
    <LM>w#w-d1t1289-5</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m914-d1t1291-1">
   <w.rf>
    <LM>w#w-d1t1291-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1291-2">
   <w.rf>
    <LM>w#w-d1t1291-2</LM>
   </w.rf>
   <form>Polska</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m914-d-id100697">
   <w.rf>
    <LM>w#w-d-id100697</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1296-3">
   <w.rf>
    <LM>w#w-d1t1296-3</LM>
   </w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d1t1296-1">
   <w.rf>
    <LM>w#w-d1t1296-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1296-2">
   <w.rf>
    <LM>w#w-d1t1296-2</LM>
   </w.rf>
   <form>Ruska</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m914-d-id100770">
   <w.rf>
    <LM>w#w-d-id100770</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1300-1">
   <w.rf>
    <LM>w#w-d1t1300-1</LM>
   </w.rf>
   <form>částečně</form>
   <lemma>částečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d1t1300-2">
   <w.rf>
    <LM>w#w-d1t1300-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1300-3">
   <w.rf>
    <LM>w#w-d1t1300-3</LM>
   </w.rf>
   <form>cizinecké</form>
   <lemma>cizinecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m914-d1t1300-4">
   <w.rf>
    <LM>w#w-d1t1300-4</LM>
   </w.rf>
   <form>legie</form>
   <lemma>legie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m914-d-id100859">
   <w.rf>
    <LM>w#w-d-id100859</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1302-1">
   <w.rf>
    <LM>w#w-d1t1302-1</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m914-d1t1302-2">
   <w.rf>
    <LM>w#w-d1t1302-2</LM>
   </w.rf>
   <form>Španělska</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m914-d1e1269-x3-1821">
   <w.rf>
    <LM>w#w-d1e1269-x3-1821</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-2264">
  <m id="m914-d1t1302-4">
   <w.rf>
    <LM>w#w-d1t1302-4</LM>
   </w.rf>
   <form>Španělé</form>
   <lemma>Španěl_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m914-d1t1302-5">
   <w.rf>
    <LM>w#w-d1t1302-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1302-6">
   <w.rf>
    <LM>w#w-d1t1302-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d-id100963">
   <w.rf>
    <LM>w#w-d-id100963</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1302-8">
   <w.rf>
    <LM>w#w-d1t1302-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1302-10">
   <w.rf>
    <LM>w#w-d1t1302-10</LM>
   </w.rf>
   <form>sestava</form>
   <lemma>sestava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m914-d1t1302-11">
   <w.rf>
    <LM>w#w-d1t1302-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m914-d1t1302-12">
   <w.rf>
    <LM>w#w-d1t1302-12</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1302-13">
   <w.rf>
    <LM>w#w-d1t1302-13</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1302-14">
   <w.rf>
    <LM>w#w-d1t1302-14</LM>
   </w.rf>
   <form>pestrá</form>
   <lemma>pestrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m914-d-id101080">
   <w.rf>
    <LM>w#w-d-id101080</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1304-x2">
  <m id="m914-d1t1307-1">
   <w.rf>
    <LM>w#w-d1t1307-1</LM>
   </w.rf>
   <form>Setkal</form>
   <lemma>setkat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1307-2">
   <w.rf>
    <LM>w#w-d1t1307-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1307-3">
   <w.rf>
    <LM>w#w-d1t1307-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1309-1">
   <w.rf>
    <LM>w#w-d1t1309-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1309-2">
   <w.rf>
    <LM>w#w-d1t1309-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1309-3">
   <w.rf>
    <LM>w#w-d1t1309-3</LM>
   </w.rf>
   <form>antisemitismem</form>
   <lemma>antisemitismus_,s_^(^DD**antisemitizmus)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m914-d-id101227">
   <w.rf>
    <LM>w#w-d-id101227</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1310-x2">
  <m id="m914-d1t1315-1">
   <w.rf>
    <LM>w#w-d1t1315-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d-id101316">
   <w.rf>
    <LM>w#w-d-id101316</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1315-3">
   <w.rf>
    <LM>w#w-d1t1315-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1315-4">
   <w.rf>
    <LM>w#w-d1t1315-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d-id101356">
   <w.rf>
    <LM>w#w-d-id101356</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1318-x2">
  <m id="m914-d1t1321-1">
   <w.rf>
    <LM>w#w-d1t1321-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1321-2">
   <w.rf>
    <LM>w#w-d1t1321-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1321-3">
   <w.rf>
    <LM>w#w-d1t1321-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1321-4">
   <w.rf>
    <LM>w#w-d1t1321-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1321-5">
   <w.rf>
    <LM>w#w-d1t1321-5</LM>
   </w.rf>
   <form>Británii</form>
   <lemma>Británie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d-id101557">
   <w.rf>
    <LM>w#w-d-id101557</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1321-7">
   <w.rf>
    <LM>w#w-d1t1321-7</LM>
   </w.rf>
   <form>dozvěděl</form>
   <lemma>dozvědět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1321-8">
   <w.rf>
    <LM>w#w-d1t1321-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1321-9">
   <w.rf>
    <LM>w#w-d1t1321-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1321-10">
   <w.rf>
    <LM>w#w-d1t1321-10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1321-11">
   <w.rf>
    <LM>w#w-d1t1321-11</LM>
   </w.rf>
   <form>existenci</form>
   <lemma>existence</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1323-1">
   <w.rf>
    <LM>w#w-d1t1323-1</LM>
   </w.rf>
   <form>koncentračních</form>
   <lemma>koncentrační</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m914-d1t1323-2">
   <w.rf>
    <LM>w#w-d1t1323-2</LM>
   </w.rf>
   <form>táborů</form>
   <lemma>tábor-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m914-d1e1318-x2-1661">
   <w.rf>
    <LM>w#w-d1e1318-x2-1661</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-1662">
  <m id="m914-d1t1325-2">
   <w.rf>
    <LM>w#w-d1t1325-2</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1325-3">
   <w.rf>
    <LM>w#w-d1t1325-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1325-4">
   <w.rf>
    <LM>w#w-d1t1325-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1325-5">
   <w.rf>
    <LM>w#w-d1t1325-5</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1325-6">
   <w.rf>
    <LM>w#w-d1t1325-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1325-7">
   <w.rf>
    <LM>w#w-d1t1325-7</LM>
   </w.rf>
   <form>konečným</form>
   <lemma>konečný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m914-d1t1325-8">
   <w.rf>
    <LM>w#w-d1t1325-8</LM>
   </w.rf>
   <form>vyřešením</form>
   <lemma>vyřešení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m914-d1e1318-x2-2426">
   <w.rf>
    <LM>w#w-d1e1318-x2-2426</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-2427">
  <m id="m914-d1t1325-10">
   <w.rf>
    <LM>w#w-d1t1325-10</LM>
   </w.rf>
   <form>Přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m914-d1t1325-11">
   <w.rf>
    <LM>w#w-d1t1325-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1325-12">
   <w.rf>
    <LM>w#w-d1t1325-12</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m914-d1t1331-1">
   <w.rf>
    <LM>w#w-d1t1331-1</LM>
   </w.rf>
   <form>informace</form>
   <lemma>informace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m914-d-id101900">
   <w.rf>
    <LM>w#w-d-id101900</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x2">
  <m id="m914-d1t1339-5">
   <w.rf>
    <LM>w#w-d1t1339-5</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1339-6">
   <w.rf>
    <LM>w#w-d1t1339-6</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m914-d1t1339-7">
   <w.rf>
    <LM>w#w-d1t1339-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1339-8">
   <w.rf>
    <LM>w#w-d1t1339-8</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d1t1339-9">
   <w.rf>
    <LM>w#w-d1t1339-9</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1339-10">
   <w.rf>
    <LM>w#w-d1t1339-10</LM>
   </w.rf>
   <form>dávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m914-d-id102130">
   <w.rf>
    <LM>w#w-d-id102130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x3">
  <m id="m914-d1t1345-1">
   <w.rf>
    <LM>w#w-d1t1345-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m914-d1t1345-2">
   <w.rf>
    <LM>w#w-d1t1345-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1345-3">
   <w.rf>
    <LM>w#w-d1t1345-3</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d1t1345-4">
   <w.rf>
    <LM>w#w-d1t1345-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1345-5">
   <w.rf>
    <LM>w#w-d1t1345-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1345-6">
   <w.rf>
    <LM>w#w-d1t1345-6</LM>
   </w.rf>
   <form>Atlitu</form>
   <lemma>Atlit_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-d1e1336-x3-2671">
   <w.rf>
    <LM>w#w-d1e1336-x3-2671</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1350-1">
   <w.rf>
    <LM>w#w-d1t1350-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1350-2">
   <w.rf>
    <LM>w#w-d1t1350-2</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m914-d-id102322">
   <w.rf>
    <LM>w#w-d-id102322</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1350-4">
   <w.rf>
    <LM>w#w-d1t1350-4</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m914-d1t1350-5">
   <w.rf>
    <LM>w#w-d1t1350-5</LM>
   </w.rf>
   <form>opouštějí</form>
   <lemma>opouštět</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1350-6">
   <w.rf>
    <LM>w#w-d1t1350-6</LM>
   </w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m914-d1t1350-7">
   <w.rf>
    <LM>w#w-d1t1350-7</LM>
   </w.rf>
   <form>Čech</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m914-d1t1350-8">
   <w.rf>
    <LM>w#w-d1t1350-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1350-9">
   <w.rf>
    <LM>w#w-d1t1350-9</LM>
   </w.rf>
   <form>Moravy</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m914-d1t1350-10">
   <w.rf>
    <LM>w#w-d1t1350-10</LM>
   </w.rf>
   <form>nejdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m914-d1t1350-11">
   <w.rf>
    <LM>w#w-d1t1350-11</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1350-12">
   <w.rf>
    <LM>w#w-d1t1350-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1350-13">
   <w.rf>
    <LM>w#w-d1t1350-13</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d-id102487">
   <w.rf>
    <LM>w#w-d-id102487</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1350-15">
   <w.rf>
    <LM>w#w-d1t1350-15</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1350-16">
   <w.rf>
    <LM>w#w-d1t1350-16</LM>
   </w.rf>
   <form>jedou</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m914-d1e1336-x3-2674">
   <w.rf>
    <LM>w#w-d1e1336-x3-2674</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1350-17">
   <w.rf>
    <LM>w#w-d1t1350-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1350-18">
   <w.rf>
    <LM>w#w-d1t1350-18</LM>
   </w.rf>
   <form>Polska</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m914-d-id102557">
   <w.rf>
    <LM>w#w-d-id102557</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x5">
  <m id="m914-d1t1352-2">
   <w.rf>
    <LM>w#w-d1t1352-2</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1352-3">
   <w.rf>
    <LM>w#w-d1t1352-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m914-d-id102627">
   <w.rf>
    <LM>w#w-d-id102627</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1352-5">
   <w.rf>
    <LM>w#w-d1t1352-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1352-6">
   <w.rf>
    <LM>w#w-d1t1352-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1352-7">
   <w.rf>
    <LM>w#w-d1t1352-7</LM>
   </w.rf>
   <form>Polsku</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m914-d1t1352-8">
   <w.rf>
    <LM>w#w-d1t1352-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1352-9">
   <w.rf>
    <LM>w#w-d1t1352-9</LM>
   </w.rf>
   <form>tábory</form>
   <lemma>tábor-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m914-d1t1352-10">
   <w.rf>
    <LM>w#w-d1t1352-10</LM>
   </w.rf>
   <form>likvidační</form>
   <lemma>likvidační</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m914-d-id102729">
   <w.rf>
    <LM>w#w-d-id102729</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1352-13">
   <w.rf>
    <LM>w#w-d1t1352-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1352-14">
   <w.rf>
    <LM>w#w-d1t1352-14</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d1t1352-15">
   <w.rf>
    <LM>w#w-d1t1352-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1352-16">
   <w.rf>
    <LM>w#w-d1t1352-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d-id102815">
   <w.rf>
    <LM>w#w-d-id102815</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x6">
  <m id="m914-d1t1358-1">
   <w.rf>
    <LM>w#w-d1t1358-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1358-2">
   <w.rf>
    <LM>w#w-d1t1358-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1360-1">
   <w.rf>
    <LM>w#w-d1t1360-1</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m914-d1t1360-2">
   <w.rf>
    <LM>w#w-d1t1360-2</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d1t1360-5">
   <w.rf>
    <LM>w#w-d1t1360-5</LM>
   </w.rf>
   <form>vyrovnáte</form>
   <lemma>vyrovnat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m914-d1t1360-6">
   <w.rf>
    <LM>w#w-d1t1360-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1360-8">
   <w.rf>
    <LM>w#w-d1t1360-8</LM>
   </w.rf>
   <form>myšlenkou</form>
   <lemma>myšlenka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m914-d-id103028">
   <w.rf>
    <LM>w#w-d-id103028</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1365-1">
   <w.rf>
    <LM>w#w-d1t1365-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1365-2">
   <w.rf>
    <LM>w#w-d1t1365-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1365-3">
   <w.rf>
    <LM>w#w-d1t1365-3</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1365-4">
   <w.rf>
    <LM>w#w-d1t1365-4</LM>
   </w.rf>
   <form>nesejdete</form>
   <lemma>sejít</lemma>
   <tag>VB-P---2P-NAP--</tag>
  </m>
  <m id="m914-d1t1365-5">
   <w.rf>
    <LM>w#w-d1t1365-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1365-6">
   <w.rf>
    <LM>w#w-d1t1365-6</LM>
   </w.rf>
   <form>lidmi</form>
   <lemma>lidé</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m914-d-id103137">
   <w.rf>
    <LM>w#w-d-id103137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1365-8">
   <w.rf>
    <LM>w#w-d1t1365-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m914-d1t1365-9">
   <w.rf>
    <LM>w#w-d1t1365-9</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m914-d1t1367-1">
   <w.rf>
    <LM>w#w-d1t1367-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1367-2">
   <w.rf>
    <LM>w#w-d1t1367-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1367-3">
   <w.rf>
    <LM>w#w-d1t1367-3</LM>
   </w.rf>
   <form>rozloučil</form>
   <lemma>rozloučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1367-4">
   <w.rf>
    <LM>w#w-d1t1367-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1367-5">
   <w.rf>
    <LM>w#w-d1t1367-5</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1367-6">
   <w.rf>
    <LM>w#w-d1t1367-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1367-7">
   <w.rf>
    <LM>w#w-d1t1367-7</LM>
   </w.rf>
   <form>kdekoliv</form>
   <lemma>kdekoliv_,s_^(^DD**kdekoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1367-8">
   <w.rf>
    <LM>w#w-d1t1367-8</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1369-1">
   <w.rf>
    <LM>w#w-d1t1369-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1369-2">
   <w.rf>
    <LM>w#w-d1t1369-2</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d-id103343">
   <w.rf>
    <LM>w#w-d-id103343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x7">
  <m id="m914-d1t1373-1">
   <w.rf>
    <LM>w#w-d1t1373-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1373-2">
   <w.rf>
    <LM>w#w-d1t1373-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1373-4">
   <w.rf>
    <LM>w#w-d1t1373-4</LM>
   </w.rf>
   <form>obtížné</form>
   <lemma>obtížný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m914-d-id103437">
   <w.rf>
    <LM>w#w-d-id103437</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1373-6">
   <w.rf>
    <LM>w#w-d1t1373-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1376-1">
   <w.rf>
    <LM>w#w-d1t1376-1</LM>
   </w.rf>
   <form>dospějete</form>
   <lemma>dospět</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m914-d1t1376-2">
   <w.rf>
    <LM>w#w-d1t1376-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m914-d1t1376-3">
   <w.rf>
    <LM>w#w-d1t1376-3</LM>
   </w.rf>
   <form>názoru</form>
   <lemma>názor</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m914-d-id103517">
   <w.rf>
    <LM>w#w-d-id103517</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1376-5">
   <w.rf>
    <LM>w#w-d1t1376-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1376-6">
   <w.rf>
    <LM>w#w-d1t1376-6</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m914-d1t1376-7">
   <w.rf>
    <LM>w#w-d1t1376-7</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1376-8">
   <w.rf>
    <LM>w#w-d1t1376-8</LM>
   </w.rf>
   <form>beztak</form>
   <lemma>beztak</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d1t1376-9">
   <w.rf>
    <LM>w#w-d1t1376-9</LM>
   </w.rf>
   <form>nemůžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m914-d1t1376-10">
   <w.rf>
    <LM>w#w-d1t1376-10</LM>
   </w.rf>
   <form>pomoct</form>
   <lemma>pomoci</lemma>
   <tag>Vf--------A-P-6</tag>
  </m>
  <m id="m914-d1e1336-x7-1689">
   <w.rf>
    <LM>w#w-d1e1336-x7-1689</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-1690">
  <m id="m914-d1t1376-12">
   <w.rf>
    <LM>w#w-d1t1376-12</LM>
   </w.rf>
   <form>Překonáte</form>
   <lemma>překonat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m914-d1t1376-13">
   <w.rf>
    <LM>w#w-d1t1376-13</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m914-d1t1376-14">
   <w.rf>
    <LM>w#w-d1t1376-14</LM>
   </w.rf>
   <form>bezmoc</form>
   <lemma>bezmoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m914-d1t1376-15">
   <w.rf>
    <LM>w#w-d1t1376-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1376-16">
   <w.rf>
    <LM>w#w-d1t1376-16</LM>
   </w.rf>
   <form>vyrovnáte</form>
   <lemma>vyrovnat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m914-d1t1376-17">
   <w.rf>
    <LM>w#w-d1t1376-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1376-18">
   <w.rf>
    <LM>w#w-d1t1376-18</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1376-19">
   <w.rf>
    <LM>w#w-d1t1376-19</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m914-d-id103751">
   <w.rf>
    <LM>w#w-d-id103751</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x8">
  <m id="m914-d1t1378-2">
   <w.rf>
    <LM>w#w-d1t1378-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1378-1">
   <w.rf>
    <LM>w#w-d1t1378-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1378-3">
   <w.rf>
    <LM>w#w-d1t1378-3</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m914-d1t1378-4">
   <w.rf>
    <LM>w#w-d1t1378-4</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d1t1378-7">
   <w.rf>
    <LM>w#w-d1t1378-7</LM>
   </w.rf>
   <form>stojíte</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1378-8">
   <w.rf>
    <LM>w#w-d1t1378-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1378-9">
   <w.rf>
    <LM>w#w-d1t1378-9</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1378-10">
   <w.rf>
    <LM>w#w-d1t1378-10</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m914-d1t1378-11">
   <w.rf>
    <LM>w#w-d1t1378-11</LM>
   </w.rf>
   <form>bytem</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m914-d-id103939">
   <w.rf>
    <LM>w#w-d-id103939</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1378-13">
   <w.rf>
    <LM>w#w-d1t1378-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1378-14">
   <w.rf>
    <LM>w#w-d1t1378-14</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m914-d1t1378-15">
   <w.rf>
    <LM>w#w-d1t1378-15</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1378-16">
   <w.rf>
    <LM>w#w-d1t1378-16</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1e1336-x8-2988">
   <w.rf>
    <LM>w#w-d1e1336-x8-2988</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1378-17">
   <w.rf>
    <LM>w#w-d1t1378-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1378-18">
   <w.rf>
    <LM>w#w-d1t1378-18</LM>
   </w.rf>
   <form>Kaprově</form>
   <lemma>kaprův_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m914-d1t1378-19">
   <w.rf>
    <LM>w#w-d1t1378-19</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1378-20">
   <w.rf>
    <LM>w#w-d1t1378-20</LM>
   </w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m914-d1e1336-x8-1695">
   <w.rf>
    <LM>w#w-d1e1336-x8-1695</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1378-21">
   <w.rf>
    <LM>w#w-d1t1378-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1380-1">
   <w.rf>
    <LM>w#w-d1t1380-1</LM>
   </w.rf>
   <form>otevře</form>
   <lemma>otevřít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m914-d1t1380-2">
   <w.rf>
    <LM>w#w-d1t1380-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m914-d1t1380-3">
   <w.rf>
    <LM>w#w-d1t1380-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m914-d1t1380-4">
   <w.rf>
    <LM>w#w-d1t1380-4</LM>
   </w.rf>
   <form>kolaborant</form>
   <lemma>kolaborant</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m914-d1e1336-x8-1701">
   <w.rf>
    <LM>w#w-d1e1336-x8-1701</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-1702">
  <m id="m914-d1t1380-8">
   <w.rf>
    <LM>w#w-d1t1380-8</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1380-7">
   <w.rf>
    <LM>w#w-d1t1380-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1380-9">
   <w.rf>
    <LM>w#w-d1t1380-9</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m914-d1t1380-10">
   <w.rf>
    <LM>w#w-d1t1380-10</LM>
   </w.rf>
   <form>myšlenka</form>
   <lemma>myšlenka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m914-d1t1380-11">
   <w.rf>
    <LM>w#w-d1t1380-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1380-12">
   <w.rf>
    <LM>w#w-d1t1380-12</LM>
   </w.rf>
   <form>hrozný</form>
   <lemma>hrozný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m914-d1t1380-13">
   <w.rf>
    <LM>w#w-d1t1380-13</LM>
   </w.rf>
   <form>okamžik</form>
   <lemma>okamžik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m914-d1e1336-x8-2994">
   <w.rf>
    <LM>w#w-d1e1336-x8-2994</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-2995">
  <m id="m914-d1t1380-15">
   <w.rf>
    <LM>w#w-d1t1380-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1380-16">
   <w.rf>
    <LM>w#w-d1t1380-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1380-17">
   <w.rf>
    <LM>w#w-d1t1380-17</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m914-d1t1380-18">
   <w.rf>
    <LM>w#w-d1t1380-18</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1380-19">
   <w.rf>
    <LM>w#w-d1t1380-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1380-20">
   <w.rf>
    <LM>w#w-d1t1380-20</LM>
   </w.rf>
   <form>mém</form>
   <lemma>můj</lemma>
   <tag>PSZS6-S1-------</tag>
  </m>
  <m id="m914-d1t1380-21">
   <w.rf>
    <LM>w#w-d1t1380-21</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-2995-3005">
   <w.rf>
    <LM>w#w-2995-3005</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3006">
  <m id="m914-d1t1384-2">
   <w.rf>
    <LM>w#w-d1t1384-2</LM>
   </w.rf>
   <form>Správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m914-d1t1384-3">
   <w.rf>
    <LM>w#w-d1t1384-3</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d1t1384-4">
   <w.rf>
    <LM>w#w-d1t1384-4</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m914-d1t1384-5">
   <w.rf>
    <LM>w#w-d1t1384-5</LM>
   </w.rf>
   <form>zavede</form>
   <lemma>zavést</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m914-d1t1384-6">
   <w.rf>
    <LM>w#w-d1t1384-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1384-7">
   <w.rf>
    <LM>w#w-d1t1384-7</LM>
   </w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d-id104536">
   <w.rf>
    <LM>w#w-d-id104536</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1384-9">
   <w.rf>
    <LM>w#w-d1t1384-9</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1384-10">
   <w.rf>
    <LM>w#w-d1t1384-10</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1384-11">
   <w.rf>
    <LM>w#w-d1t1384-11</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1384-12">
   <w.rf>
    <LM>w#w-d1t1384-12</LM>
   </w.rf>
   <form>nábytek</form>
   <lemma>nábytek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m914-d-id104607">
   <w.rf>
    <LM>w#w-d-id104607</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1384-14">
   <w.rf>
    <LM>w#w-d1t1384-14</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m914-d1t1384-15">
   <w.rf>
    <LM>w#w-d1t1384-15</LM>
   </w.rf>
   <form>patřil</form>
   <lemma>patřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1384-16">
   <w.rf>
    <LM>w#w-d1t1384-16</LM>
   </w.rf>
   <form>vašim</form>
   <lemma>váš</lemma>
   <tag>PSXP3-P2-------</tag>
  </m>
  <m id="m914-d1t1384-17">
   <w.rf>
    <LM>w#w-d1t1384-17</LM>
   </w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m914-3006-1712">
   <w.rf>
    <LM>w#w-3006-1712</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-1713">
  <m id="m914-d1t1386-3">
   <w.rf>
    <LM>w#w-d1t1386-3</LM>
   </w.rf>
   <form>Prohlásí</form>
   <lemma>prohlásit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m914-3006-3018">
   <w.rf>
    <LM>w#w-3006-3018</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d-id104735">
   <w.rf>
    <LM>w#w-d-id104735</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1386-5">
   <w.rf>
    <LM>w#w-d1t1386-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m914-d1t1386-6">
   <w.rf>
    <LM>w#w-d1t1386-6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m914-d1t1386-7">
   <w.rf>
    <LM>w#w-d1t1386-7</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m914-d1t1386-8">
   <w.rf>
    <LM>w#w-d1t1386-8</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m914-d1t1386-9">
   <w.rf>
    <LM>w#w-d1t1386-9</LM>
   </w.rf>
   <form>dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m914-3006-2081">
   <w.rf>
    <LM>w#w-3006-2081</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-3006-3020">
   <w.rf>
    <LM>w#w-3006-3020</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-2082">
  <m id="m914-d1t1391-2">
   <w.rf>
    <LM>w#w-d1t1391-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m914-d1t1391-3">
   <w.rf>
    <LM>w#w-d1t1391-3</LM>
   </w.rf>
   <form>byste</form>
   <lemma>být</lemma>
   <tag>Vc----------Ie-</tag>
  </m>
  <m id="m914-d1t1391-4">
   <w.rf>
    <LM>w#w-d1t1391-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m914-d1t1391-5">
   <w.rf>
    <LM>w#w-d1t1391-5</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d-id104936">
   <w.rf>
    <LM>w#w-d-id104936</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x10">
  <m id="m914-d1t1393-2">
   <w.rf>
    <LM>w#w-d1t1393-2</LM>
   </w.rf>
   <form>Jdete</form>
   <lemma>jít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1393-3">
   <w.rf>
    <LM>w#w-d1t1393-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1393-4">
   <w.rf>
    <LM>w#w-d1t1393-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m914-d1t1393-5">
   <w.rf>
    <LM>w#w-d1t1393-5</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-d1e1336-x10-3240">
   <w.rf>
    <LM>w#w-d1e1336-x10-3240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3241">
  <m id="m914-d1t1395-1">
   <w.rf>
    <LM>w#w-d1t1395-1</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m914-d1t1395-2">
   <w.rf>
    <LM>w#w-d1t1395-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1395-3">
   <w.rf>
    <LM>w#w-d1t1395-3</LM>
   </w.rf>
   <form>divili</form>
   <lemma>divit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m914-d-id105101">
   <w.rf>
    <LM>w#w-d-id105101</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1397-1">
   <w.rf>
    <LM>w#w-d1t1397-1</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1397-2">
   <w.rf>
    <LM>w#w-d1t1397-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1397-3">
   <w.rf>
    <LM>w#w-d1t1397-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1397-4">
   <w.rf>
    <LM>w#w-d1t1397-4</LM>
   </w.rf>
   <form>nesnažil</form>
   <lemma>snažit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m914-d1t1397-5">
   <w.rf>
    <LM>w#w-d1t1397-5</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m914-d1t1397-7">
   <w.rf>
    <LM>w#w-d1t1397-7</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1397-6">
   <w.rf>
    <LM>w#w-d1t1397-6</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m914-d1t1397-8">
   <w.rf>
    <LM>w#w-d1t1397-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1397-9">
   <w.rf>
    <LM>w#w-d1t1397-9</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m914-d1t1397-10">
   <w.rf>
    <LM>w#w-d1t1397-10</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-3241-3251">
   <w.rf>
    <LM>w#w-3241-3251</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3252">
  <m id="m914-d1t1399-1">
   <w.rf>
    <LM>w#w-d1t1399-1</LM>
   </w.rf>
   <form>Nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m914-d1t1399-2">
   <w.rf>
    <LM>w#w-d1t1399-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m914-3252-3262">
   <w.rf>
    <LM>w#w-3252-3262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1336-x11">
  <m id="m914-d1t1402-1">
   <w.rf>
    <LM>w#w-d1t1402-1</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m914-d1t1402-2">
   <w.rf>
    <LM>w#w-d1t1402-2</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m914-d1e1336-x11-3378">
   <w.rf>
    <LM>w#w-d1e1336-x11-3378</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1404-1">
   <w.rf>
    <LM>w#w-d1t1404-1</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m914-d1e1336-x11-3379">
   <w.rf>
    <LM>w#w-d1e1336-x11-3379</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1404-2">
   <w.rf>
    <LM>w#w-d1t1404-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1406-1">
   <w.rf>
    <LM>w#w-d1t1406-1</LM>
   </w.rf>
   <form>nežijou</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m914-d1e1336-x11-3395">
   <w.rf>
    <LM>w#w-d1e1336-x11-3395</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1408-2">
   <w.rf>
    <LM>w#w-d1t1408-2</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1408-3">
   <w.rf>
    <LM>w#w-d1t1408-3</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m914-d1t1408-4">
   <w.rf>
    <LM>w#w-d1t1408-4</LM>
   </w.rf>
   <form>domovník</form>
   <lemma>domovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m914-d1t1408-5">
   <w.rf>
    <LM>w#w-d1t1408-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1408-6">
   <w.rf>
    <LM>w#w-d1t1408-6</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m914-d-id105572">
   <w.rf>
    <LM>w#w-d-id105572</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1408-8">
   <w.rf>
    <LM>w#w-d1t1408-8</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1408-9">
   <w.rf>
    <LM>w#w-d1t1408-9</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m914-d1e1336-x11-3381">
   <w.rf>
    <LM>w#w-d1e1336-x11-3381</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1408-10">
   <w.rf>
    <LM>w#w-d1t1408-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m914-d1t1408-11">
   <w.rf>
    <LM>w#w-d1t1408-11</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m914-d1t1408-12">
   <w.rf>
    <LM>w#w-d1t1408-12</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m914-d1t1408-15">
   <w.rf>
    <LM>w#w-d1t1408-15</LM>
   </w.rf>
   <form>obsadili</form>
   <lemma>obsadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m914-d1e1336-x11-3382">
   <w.rf>
    <LM>w#w-d1e1336-x11-3382</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3383">
  <m id="m914-d1t1408-18">
   <w.rf>
    <LM>w#w-d1t1408-18</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1408-19">
   <w.rf>
    <LM>w#w-d1t1408-19</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m914-d1t1408-20">
   <w.rf>
    <LM>w#w-d1t1408-20</LM>
   </w.rf>
   <form>představím</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m914-d-id105767">
   <w.rf>
    <LM>w#w-d-id105767</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1408-22">
   <w.rf>
    <LM>w#w-d1t1408-22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1408-24">
   <w.rf>
    <LM>w#w-d1t1408-24</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1408-25">
   <w.rf>
    <LM>w#w-d1t1408-25</LM>
   </w.rf>
   <form>vstoupil</form>
   <lemma>vstoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1408-26">
   <w.rf>
    <LM>w#w-d1t1408-26</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1408-27">
   <w.rf>
    <LM>w#w-d1t1408-27</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m914-d1t1408-28">
   <w.rf>
    <LM>w#w-d1t1408-28</LM>
   </w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m914-3383-1745">
   <w.rf>
    <LM>w#w-3383-1745</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-3383-1746">
   <w.rf>
    <LM>w#w-3383-1746</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-3383-1747">
   <w.rf>
    <LM>w#w-3383-1747</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-1748">
  <m id="m914-d1t1408-30">
   <w.rf>
    <LM>w#w-d1t1408-30</LM>
   </w.rf>
   <form>Sáhnul</form>
   <lemma>sáhnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1408-31">
   <w.rf>
    <LM>w#w-d1t1408-31</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1408-32">
   <w.rf>
    <LM>w#w-d1t1408-32</LM>
   </w.rf>
   <form>doprava</form>
   <lemma>doprava-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-3383-3403">
   <w.rf>
    <LM>w#w-3383-3403</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1410-2">
   <w.rf>
    <LM>w#w-d1t1410-2</LM>
   </w.rf>
   <form>rozsvítil</form>
   <lemma>rozsvítit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1410-3">
   <w.rf>
    <LM>w#w-d1t1410-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d1t1410-4">
   <w.rf>
    <LM>w#w-d1t1410-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1410-5">
   <w.rf>
    <LM>w#w-d1t1410-5</LM>
   </w.rf>
   <form>předsíni</form>
   <lemma>předsíň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m914-d1t1410-6">
   <w.rf>
    <LM>w#w-d1t1410-6</LM>
   </w.rf>
   <form>světlo</form>
   <lemma>světlo-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m914-d1t1415-1">
   <w.rf>
    <LM>w#w-d1t1415-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1415-2">
   <w.rf>
    <LM>w#w-d1t1415-2</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m914-d1t1415-3">
   <w.rf>
    <LM>w#w-d1t1415-3</LM>
   </w.rf>
   <form>vypínač</form>
   <lemma>vypínač</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m914-d1t1415-4">
   <w.rf>
    <LM>w#w-d1t1415-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1415-5">
   <w.rf>
    <LM>w#w-d1t1415-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-3383-3640">
   <w.rf>
    <LM>w#w-3383-3640</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3641">
  <m id="m914-d1t1421-2">
   <w.rf>
    <LM>w#w-d1t1421-2</LM>
   </w.rf>
   <form>Věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1421-3">
   <w.rf>
    <LM>w#w-d1t1421-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-3383-3634">
   <w.rf>
    <LM>w#w-3383-3634</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1421-4">
   <w.rf>
    <LM>w#w-d1t1421-4</LM>
   </w.rf>
   <form>kudy</form>
   <lemma>kudy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1421-5">
   <w.rf>
    <LM>w#w-d1t1421-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1421-6">
   <w.rf>
    <LM>w#w-d1t1421-6</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1421-7">
   <w.rf>
    <LM>w#w-d1t1421-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m914-d1t1421-8">
   <w.rf>
    <LM>w#w-d1t1421-8</LM>
   </w.rf>
   <form>koupelny</form>
   <lemma>koupelna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m914-3383-3636">
   <w.rf>
    <LM>w#w-3383-3636</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1423-1">
   <w.rf>
    <LM>w#w-d1t1423-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1423-2">
   <w.rf>
    <LM>w#w-d1t1423-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m914-d1t1423-3">
   <w.rf>
    <LM>w#w-d1t1423-3</LM>
   </w.rf>
   <form>vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m914-d1t1423-4">
   <w.rf>
    <LM>w#w-d1t1423-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1423-6">
   <w.rf>
    <LM>w#w-d1t1423-6</LM>
   </w.rf>
   <form>pokojích</form>
   <lemma>pokoj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m914-3641-3649">
   <w.rf>
    <LM>w#w-3641-3649</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3650">
  <m id="m914-d1t1423-8">
   <w.rf>
    <LM>w#w-d1t1423-8</LM>
   </w.rf>
   <form>Stál</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1423-9">
   <w.rf>
    <LM>w#w-d1t1423-9</LM>
   </w.rf>
   <form>přede</form>
   <lemma>před-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m914-d1t1423-10">
   <w.rf>
    <LM>w#w-d1t1423-10</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m914-d1t1428-1">
   <w.rf>
    <LM>w#w-d1t1428-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1428-2">
   <w.rf>
    <LM>w#w-d1t1428-2</LM>
   </w.rf>
   <form>zeleném</form>
   <lemma>zelený_;o</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m914-d1t1428-3">
   <w.rf>
    <LM>w#w-d1t1428-3</LM>
   </w.rf>
   <form>županu</form>
   <lemma>župan-2</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m914-d1t1428-4">
   <w.rf>
    <LM>w#w-d1t1428-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m914-d1t1430-1">
   <w.rf>
    <LM>w#w-d1t1430-1</LM>
   </w.rf>
   <form>blekotal</form>
   <lemma>blekotat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d1t1430-2">
   <w.rf>
    <LM>w#w-d1t1430-2</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m914-d1t1430-3">
   <w.rf>
    <LM>w#w-d1t1430-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m914-d1t1430-4">
   <w.rf>
    <LM>w#w-d1t1430-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m914-d-id106595">
   <w.rf>
    <LM>w#w-d-id106595</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1430-6">
   <w.rf>
    <LM>w#w-d1t1430-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m914-d1t1430-8">
   <w.rf>
    <LM>w#w-d1t1430-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m914-d1t1430-9">
   <w.rf>
    <LM>w#w-d1t1430-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m914-d1t1430-10">
   <w.rf>
    <LM>w#w-d1t1430-10</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m914-3650-3658">
   <w.rf>
    <LM>w#w-3650-3658</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-3659">
  <m id="m914-d1t1432-1">
   <w.rf>
    <LM>w#w-d1t1432-1</LM>
   </w.rf>
   <form>Hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m914-d-id106694">
   <w.rf>
    <LM>w#w-d-id106694</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1433-x2">
  <m id="m914-d1t1436-1">
   <w.rf>
    <LM>w#w-d1t1436-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m914-d1t1436-2">
   <w.rf>
    <LM>w#w-d1t1436-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m914-d1t1436-3">
   <w.rf>
    <LM>w#w-d1t1436-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m914-d1t1436-4">
   <w.rf>
    <LM>w#w-d1t1436-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m914-d1t1436-5">
   <w.rf>
    <LM>w#w-d1t1436-5</LM>
   </w.rf>
   <form>reagoval</form>
   <lemma>reagovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m914-d-id106823">
   <w.rf>
    <LM>w#w-d-id106823</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m914-12941_04-d1e1437-x2">
  <m id="m914-d1t1442-1">
   <w.rf>
    <LM>w#w-d1t1442-1</LM>
   </w.rf>
   <form>Odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m914-d1t1442-2">
   <w.rf>
    <LM>w#w-d1t1442-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m914-d-id106928">
   <w.rf>
    <LM>w#w-d-id106928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m914-d1t1444-5">
   <w.rf>
    <LM>w#w-d1t1444-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m914-d1t1444-6">
   <w.rf>
    <LM>w#w-d1t1444-6</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m914-d1t1444-2">
   <w.rf>
    <LM>w#w-d1t1444-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m914-d1t1444-3">
   <w.rf>
    <LM>w#w-d1t1444-3</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m914-d1t1444-4">
   <w.rf>
    <LM>w#w-d1t1444-4</LM>
   </w.rf>
   <form>reagovat</form>
   <lemma>reagovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m914-d-id107018">
   <w.rf>
    <LM>w#w-d-id107018</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
