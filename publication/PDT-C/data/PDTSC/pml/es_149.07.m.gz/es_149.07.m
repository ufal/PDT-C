<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_149.07.w.gz" />
  </references>
 </head>
 <s id="m149-d1e1453-x2">
  <m id="m149-d1t1456-1">
   <w.rf>
    <LM>w#w-d1t1456-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1456-2">
   <w.rf>
    <LM>w#w-d1t1456-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1456-3">
   <w.rf>
    <LM>w#w-d1t1456-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1456-4">
   <w.rf>
    <LM>w#w-d1t1456-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m149-d1t1456-5">
   <w.rf>
    <LM>w#w-d1t1456-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1456-6">
   <w.rf>
    <LM>w#w-d1t1456-6</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m149-d1t1456-7">
   <w.rf>
    <LM>w#w-d1t1456-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m149-d1t1456-8">
   <w.rf>
    <LM>w#w-d1t1456-8</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-m-d1e1453-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1453-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1457-x2">
  <m id="m149-d1t1460-1">
   <w.rf>
    <LM>w#w-d1t1460-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1460-2">
   <w.rf>
    <LM>w#w-d1t1460-2</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1460-3">
   <w.rf>
    <LM>w#w-d1t1460-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1460-4">
   <w.rf>
    <LM>w#w-d1t1460-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1460-5">
   <w.rf>
    <LM>w#w-d1t1460-5</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-id123754-punct">
   <w.rf>
    <LM>w#w-d-id123754-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1461-x2">
  <m id="m149-d1t1464-1">
   <w.rf>
    <LM>w#w-d1t1464-1</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1464-2">
   <w.rf>
    <LM>w#w-d1t1464-2</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1e1461-x2-171">
   <w.rf>
    <LM>w#w-d1e1461-x2-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-170">
  <m id="m149-d1t1466-1">
   <w.rf>
    <LM>w#w-d1t1466-1</LM>
   </w.rf>
   <form>Například</form>
   <lemma>například</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1466-2">
   <w.rf>
    <LM>w#w-d1t1466-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1466-4">
   <w.rf>
    <LM>w#w-d1t1466-4</LM>
   </w.rf>
   <form>Údolí</form>
   <lemma>údolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m149-d1t1466-5">
   <w.rf>
    <LM>w#w-d1t1466-5</LM>
   </w.rf>
   <form>králů</form>
   <lemma>král</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m149-d1t1466-7">
   <w.rf>
    <LM>w#w-d1t1466-7</LM>
   </w.rf>
   <form>neklesá</form>
   <lemma>klesat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m149-d1t1466-8">
   <w.rf>
    <LM>w#w-d1t1466-8</LM>
   </w.rf>
   <form>teplota</form>
   <lemma>teplota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m149-d1t1466-9">
   <w.rf>
    <LM>w#w-d1t1466-9</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1466-10">
   <w.rf>
    <LM>w#w-d1t1466-10</LM>
   </w.rf>
   <form>čtyřicet</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m149-d1t1466-11">
   <w.rf>
    <LM>w#w-d1t1466-11</LM>
   </w.rf>
   <form>stupňů</form>
   <lemma>stupeň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m149-d1t1466-12">
   <w.rf>
    <LM>w#w-d1t1466-12</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m149-d1t1466-13">
   <w.rf>
    <LM>w#w-d1t1466-13</LM>
   </w.rf>
   <form>stínu</form>
   <lemma>stín</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1461-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1461-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1467-x2">
  <m id="m149-d1t1470-1">
   <w.rf>
    <LM>w#w-d1t1470-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1470-2">
   <w.rf>
    <LM>w#w-d1t1470-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1470-3">
   <w.rf>
    <LM>w#w-d1t1470-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m149-d1t1470-4">
   <w.rf>
    <LM>w#w-d1t1470-4</LM>
   </w.rf>
   <form>pyramidy</form>
   <lemma>pyramida</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d1t1470-5">
   <w.rf>
    <LM>w#w-d1t1470-5</LM>
   </w.rf>
   <form>zapůsobily</form>
   <lemma>zapůsobit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m149-d-id124181-punct">
   <w.rf>
    <LM>w#w-d-id124181-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1472-x2">
  <m id="m149-d1t1475-2">
   <w.rf>
    <LM>w#w-d1t1475-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1475-3">
   <w.rf>
    <LM>w#w-d1t1475-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1475-4">
   <w.rf>
    <LM>w#w-d1t1475-4</LM>
   </w.rf>
   <form>monumentální</form>
   <lemma>monumentální</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m149-d1t1475-5">
   <w.rf>
    <LM>w#w-d1t1475-5</LM>
   </w.rf>
   <form>stavby</form>
   <lemma>stavba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d-id124320-punct">
   <w.rf>
    <LM>w#w-d-id124320-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1475-7">
   <w.rf>
    <LM>w#w-d1t1475-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1475-8">
   <w.rf>
    <LM>w#w-d1t1475-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1475-9">
   <w.rf>
    <LM>w#w-d1t1475-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1475-10">
   <w.rf>
    <LM>w#w-d1t1475-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1475-11">
   <w.rf>
    <LM>w#w-d1t1475-11</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1475-12">
   <w.rf>
    <LM>w#w-d1t1475-12</LM>
   </w.rf>
   <form>žalostném</form>
   <lemma>žalostný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m149-d1t1475-13">
   <w.rf>
    <LM>w#w-d1t1475-13</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m149-d1e1472-x2-181">
   <w.rf>
    <LM>w#w-d1e1472-x2-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-180">
  <m id="m149-d1t1477-2">
   <w.rf>
    <LM>w#w-d1t1477-2</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1477-3">
   <w.rf>
    <LM>w#w-d1t1477-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m149-d-id124499-punct">
   <w.rf>
    <LM>w#w-d-id124499-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1477-5">
   <w.rf>
    <LM>w#w-d1t1477-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1477-6">
   <w.rf>
    <LM>w#w-d1t1477-6</LM>
   </w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m149-d1t1477-7">
   <w.rf>
    <LM>w#w-d1t1477-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1477-8">
   <w.rf>
    <LM>w#w-d1t1477-8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1477-10">
   <w.rf>
    <LM>w#w-d1t1477-10</LM>
   </w.rf>
   <form>údržbu</form>
   <lemma>údržba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-d1t1477-11">
   <w.rf>
    <LM>w#w-d1t1477-11</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1477-12">
   <w.rf>
    <LM>w#w-d1t1477-12</LM>
   </w.rf>
   <form>nestarají</form>
   <lemma>starat_^(se)</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m149-d-id124632-punct">
   <w.rf>
    <LM>w#w-d-id124632-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1477-14">
   <w.rf>
    <LM>w#w-d1t1477-14</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1477-15">
   <w.rf>
    <LM>w#w-d1t1477-15</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m149-d1t1477-16">
   <w.rf>
    <LM>w#w-d1t1477-16</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m149-d1t1477-17">
   <w.rf>
    <LM>w#w-d1t1477-17</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m149-d1t1477-24">
   <w.rf>
    <LM>w#w-d1t1477-24</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1477-25">
   <w.rf>
    <LM>w#w-d1t1477-25</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1477-26">
   <w.rf>
    <LM>w#w-d1t1477-26</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1477-27">
   <w.rf>
    <LM>w#w-d1t1477-27</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1477-28">
   <w.rf>
    <LM>w#w-d1t1477-28</LM>
   </w.rf>
   <form>rozpadají</form>
   <lemma>rozpadat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-180-778">
   <w.rf>
    <LM>w#w-180-778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-779">
  <m id="m149-d1t1477-19">
   <w.rf>
    <LM>w#w-d1t1477-19</LM>
   </w.rf>
   <form>Naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1477-20">
   <w.rf>
    <LM>w#w-d1t1477-20</LM>
   </w.rf>
   <form>jich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3------1</tag>
  </m>
  <m id="m149-d1t1477-21">
   <w.rf>
    <LM>w#w-d1t1477-21</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1477-22">
   <w.rf>
    <LM>w#w-d1t1477-22</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d-m-d1e1472-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1472-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1478-x2">
  <m id="m149-d1t1481-1">
   <w.rf>
    <LM>w#w-d1t1481-1</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d1t1481-2">
   <w.rf>
    <LM>w#w-d1t1481-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m149-d-id124944-punct">
   <w.rf>
    <LM>w#w-d-id124944-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1481-4">
   <w.rf>
    <LM>w#w-d1t1481-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1481-5">
   <w.rf>
    <LM>w#w-d1t1481-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1481-6">
   <w.rf>
    <LM>w#w-d1t1481-6</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1481-7">
   <w.rf>
    <LM>w#w-d1t1481-7</LM>
   </w.rf>
   <form>opraví</form>
   <lemma>opravit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m149-d-id125014-punct">
   <w.rf>
    <LM>w#w-d-id125014-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1482-x2">
  <m id="m149-d1t1485-1">
   <w.rf>
    <LM>w#w-d1t1485-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1485-2">
   <w.rf>
    <LM>w#w-d1t1485-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m149-d-id125107-punct">
   <w.rf>
    <LM>w#w-d-id125107-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1485-4">
   <w.rf>
    <LM>w#w-d1t1485-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1485-5">
   <w.rf>
    <LM>w#w-d1t1485-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1e1482-x2-191">
   <w.rf>
    <LM>w#w-d1e1482-x2-191</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1487-1">
   <w.rf>
    <LM>w#w-d1t1487-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1487-2">
   <w.rf>
    <LM>w#w-d1t1487-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1487-3">
   <w.rf>
    <LM>w#w-d1t1487-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m149-d1t1487-4">
   <w.rf>
    <LM>w#w-d1t1487-4</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m149-d1t1487-5">
   <w.rf>
    <LM>w#w-d1t1487-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1487-6">
   <w.rf>
    <LM>w#w-d1t1487-6</LM>
   </w.rf>
   <form>prostředky</form>
   <lemma>prostředek_^(střed,způsob,_nástroj)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m149-d1e1482-x2-192">
   <w.rf>
    <LM>w#w-d1e1482-x2-192</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1487-7">
   <w.rf>
    <LM>w#w-d1t1487-7</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1487-8">
   <w.rf>
    <LM>w#w-d1t1487-8</LM>
   </w.rf>
   <form>síly</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m149-d1e1482-x2-788">
   <w.rf>
    <LM>w#w-d1e1482-x2-788</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-789">
  <m id="m149-d1t1489-3">
   <w.rf>
    <LM>w#w-d1t1489-3</LM>
   </w.rf>
   <form>Patrně</form>
   <lemma>patrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1e1482-x2-194">
   <w.rf>
    <LM>w#w-d1e1482-x2-194</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m149-d1t1489-1">
   <w.rf>
    <LM>w#w-d1t1489-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1489-2">
   <w.rf>
    <LM>w#w-d1t1489-2</LM>
   </w.rf>
   <form>zájem</form>
   <lemma>zájem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1482-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1482-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1490-x2">
  <m id="m149-d1t1493-1">
   <w.rf>
    <LM>w#w-d1t1493-1</LM>
   </w.rf>
   <form>Ochutnal</form>
   <lemma>ochutnat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m149-d1t1493-2">
   <w.rf>
    <LM>w#w-d1t1493-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d1t1493-3">
   <w.rf>
    <LM>w#w-d1t1493-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m149-d1t1493-4">
   <w.rf>
    <LM>w#w-d1t1493-4</LM>
   </w.rf>
   <form>egyptské</form>
   <lemma>egyptský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m149-d1t1493-5">
   <w.rf>
    <LM>w#w-d1t1493-5</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m149-d-id125478-punct">
   <w.rf>
    <LM>w#w-d-id125478-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1494-x2">
  <m id="m149-d1t1497-3">
   <w.rf>
    <LM>w#w-d1t1497-3</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m149-d1t1497-4">
   <w.rf>
    <LM>w#w-d1t1497-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m149-d1e1494-x2-795">
   <w.rf>
    <LM>w#w-d1e1494-x2-795</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-796">
  <m id="m149-d1t1497-7">
   <w.rf>
    <LM>w#w-d1t1497-7</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1497-8">
   <w.rf>
    <LM>w#w-d1t1497-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1497-9">
   <w.rf>
    <LM>w#w-d1t1497-9</LM>
   </w.rf>
   <form>strava</form>
   <lemma>strava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m149-d1t1497-10">
   <w.rf>
    <LM>w#w-d1t1497-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m149-d1e1494-x2-203">
   <w.rf>
    <LM>w#w-d1e1494-x2-203</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1497-17">
   <w.rf>
    <LM>w#w-d1t1497-17</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m149-d1t1497-16">
   <w.rf>
    <LM>w#w-d1t1497-16</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m149-796-797">
   <w.rf>
    <LM>w#w-796-797</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1497-12">
   <w.rf>
    <LM>w#w-d1t1497-12</LM>
   </w.rf>
   <form>kombinovaná</form>
   <lemma>kombinovaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m149-d1t1497-13">
   <w.rf>
    <LM>w#w-d1t1497-13</LM>
   </w.rf>
   <form>evropsko</form>
   <lemma>evropsko-1</lemma>
   <tag>S2--------A----</tag>
  </m>
  <m id="m149-d1t1497-14">
   <w.rf>
    <LM>w#w-d1t1497-14</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1497-15">
   <w.rf>
    <LM>w#w-d1t1497-15</LM>
   </w.rf>
   <form>arabská</form>
   <lemma>arabský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m149-d-id125784-punct">
   <w.rf>
    <LM>w#w-d-id125784-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1497-19">
   <w.rf>
    <LM>w#w-d1t1497-19</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1497-20">
   <w.rf>
    <LM>w#w-d1t1497-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1497-21">
   <w.rf>
    <LM>w#w-d1t1497-21</LM>
   </w.rf>
   <form>ochutnali</form>
   <lemma>ochutnat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m149-796-798">
   <w.rf>
    <LM>w#w-796-798</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-799">
  <m id="m149-d1t1499-1">
   <w.rf>
    <LM>w#w-d1t1499-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1499-2">
   <w.rf>
    <LM>w#w-d1t1499-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m149-d-id125916-punct">
   <w.rf>
    <LM>w#w-d-id125916-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1499-7">
   <w.rf>
    <LM>w#w-d1t1499-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m149-d1t1499-8">
   <w.rf>
    <LM>w#w-d1t1499-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m149-d1t1499-9">
   <w.rf>
    <LM>w#w-d1t1499-9</LM>
   </w.rf>
   <form>dávali</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m149-d-id125987-punct">
   <w.rf>
    <LM>w#w-d-id125987-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1499-3">
   <w.rf>
    <LM>w#w-d1t1499-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m149-d1t1499-4">
   <w.rf>
    <LM>w#w-d1t1499-4</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1499-13">
   <w.rf>
    <LM>w#w-d1t1499-13</LM>
   </w.rf>
   <form>jedlé</form>
   <lemma>jedlý_^(*4íst)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m149-d1e1494-x2-205">
   <w.rf>
    <LM>w#w-d1e1494-x2-205</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-202">
  <m id="m149-d1t1501-1">
   <w.rf>
    <LM>w#w-d1t1501-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1501-2">
   <w.rf>
    <LM>w#w-d1t1501-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1501-3">
   <w.rf>
    <LM>w#w-d1t1501-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1501-4">
   <w.rf>
    <LM>w#w-d1t1501-4</LM>
   </w.rf>
   <form>žádnou</form>
   <lemma>žádný</lemma>
   <tag>PWFS4----------</tag>
  </m>
  <m id="m149-d1t1501-5">
   <w.rf>
    <LM>w#w-d1t1501-5</LM>
   </w.rf>
   <form>specialitu</form>
   <lemma>specialita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-d1t1501-7">
   <w.rf>
    <LM>w#w-d1t1501-7</LM>
   </w.rf>
   <form>nejedl</form>
   <lemma>jíst</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m149-202-207">
   <w.rf>
    <LM>w#w-202-207</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-201">
  <m id="m149-d1t1503-1">
   <w.rf>
    <LM>w#w-d1t1503-1</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1503-2">
   <w.rf>
    <LM>w#w-d1t1503-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m149-d1t1503-3">
   <w.rf>
    <LM>w#w-d1t1503-3</LM>
   </w.rf>
   <form>ostřejší</form>
   <lemma>ostrý</lemma>
   <tag>AANS4----2A----</tag>
  </m>
  <m id="m149-d1t1503-4">
   <w.rf>
    <LM>w#w-d1t1503-4</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1503-5">
   <w.rf>
    <LM>w#w-d1t1503-5</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m149-d-id126274-punct">
   <w.rf>
    <LM>w#w-d-id126274-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1503-7">
   <w.rf>
    <LM>w#w-d1t1503-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1503-9">
   <w.rf>
    <LM>w#w-d1t1503-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1503-10">
   <w.rf>
    <LM>w#w-d1t1503-10</LM>
   </w.rf>
   <form>mezích</form>
   <lemma>mez</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m149-d1t1503-11">
   <w.rf>
    <LM>w#w-d1t1503-11</LM>
   </w.rf>
   <form>normy</form>
   <lemma>norma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1494-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1494-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1504-x2">
  <m id="m149-d1t1507-1">
   <w.rf>
    <LM>w#w-d1t1507-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1507-2">
   <w.rf>
    <LM>w#w-d1t1507-2</LM>
   </w.rf>
   <form>byste</form>
   <lemma>být</lemma>
   <tag>Vc----------Ie-</tag>
  </m>
  <m id="m149-d1t1507-3">
   <w.rf>
    <LM>w#w-d1t1507-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1507-4">
   <w.rf>
    <LM>w#w-d1t1507-4</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m149-d1t1507-5">
   <w.rf>
    <LM>w#w-d1t1507-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1507-6">
   <w.rf>
    <LM>w#w-d1t1507-6</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m149-d-id126506-punct">
   <w.rf>
    <LM>w#w-d-id126506-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1508-x2">
  <m id="m149-d1t1511-2">
   <w.rf>
    <LM>w#w-d1t1511-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1511-3">
   <w.rf>
    <LM>w#w-d1t1511-3</LM>
   </w.rf>
   <form>především</form>
   <lemma>především-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1511-4">
   <w.rf>
    <LM>w#w-d1t1511-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1511-6">
   <w.rf>
    <LM>w#w-d1t1511-6</LM>
   </w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m149-d1t1511-7">
   <w.rf>
    <LM>w#w-d1t1511-7</LM>
   </w.rf>
   <form>Zéland</form>
   <lemma>Zéland_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m149-d-id126679-punct">
   <w.rf>
    <LM>w#w-d-id126679-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1511-10">
   <w.rf>
    <LM>w#w-d1t1511-10</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m149-d1t1511-11">
   <w.rf>
    <LM>w#w-d1t1511-11</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1511-12">
   <w.rf>
    <LM>w#w-d1t1511-12</LM>
   </w.rf>
   <form>stihnul</form>
   <lemma>stihnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m149-d1t1511-13">
   <w.rf>
    <LM>w#w-d1t1511-13</LM>
   </w.rf>
   <form>Severní</form>
   <lemma>severní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m149-d1t1511-14">
   <w.rf>
    <LM>w#w-d1t1511-14</LM>
   </w.rf>
   <form>ostrov</form>
   <lemma>ostrov</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m149-d1t1513-1">
   <w.rf>
    <LM>w#w-d1t1513-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1513-2">
   <w.rf>
    <LM>w#w-d1t1513-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m149-d-id126811-punct">
   <w.rf>
    <LM>w#w-d-id126811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1513-4">
   <w.rf>
    <LM>w#w-d1t1513-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m149-d1t1513-5">
   <w.rf>
    <LM>w#w-d1t1513-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1513-6">
   <w.rf>
    <LM>w#w-d1t1513-6</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1513-7">
   <w.rf>
    <LM>w#w-d1t1513-7</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m149-d1t1513-8">
   <w.rf>
    <LM>w#w-d1t1513-8</LM>
   </w.rf>
   <form>návštěvě</form>
   <lemma>návštěva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m149-d1t1513-9">
   <w.rf>
    <LM>w#w-d1t1513-9</LM>
   </w.rf>
   <form>nestihnul</form>
   <lemma>stihnout</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m149-d-m-d1e1508-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1508-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1514-x2">
  <m id="m149-d1t1517-1">
   <w.rf>
    <LM>w#w-d1t1517-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1517-2">
   <w.rf>
    <LM>w#w-d1t1517-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1517-3">
   <w.rf>
    <LM>w#w-d1t1517-3</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1517-4">
   <w.rf>
    <LM>w#w-d1t1517-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1517-5">
   <w.rf>
    <LM>w#w-d1t1517-5</LM>
   </w.rf>
   <form>jedete</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d-id127044-punct">
   <w.rf>
    <LM>w#w-d-id127044-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1518-x2">
  <m id="m149-d1t1521-1">
   <w.rf>
    <LM>w#w-d1t1521-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1521-2">
   <w.rf>
    <LM>w#w-d1t1521-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1521-3">
   <w.rf>
    <LM>w#w-d1t1521-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1521-4">
   <w.rf>
    <LM>w#w-d1t1521-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m149-d1t1521-5">
   <w.rf>
    <LM>w#w-d1t1521-5</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1518-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1518-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1522-x2">
  <m id="m149-d1t1525-1">
   <w.rf>
    <LM>w#w-d1t1525-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1525-2">
   <w.rf>
    <LM>w#w-d1t1525-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1525-3">
   <w.rf>
    <LM>w#w-d1t1525-3</LM>
   </w.rf>
   <form>draho</form>
   <lemma>draho</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-id127281-punct">
   <w.rf>
    <LM>w#w-d-id127281-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1526-x2">
  <m id="m149-d1t1529-1">
   <w.rf>
    <LM>w#w-d1t1529-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1e1526-x2-815">
   <w.rf>
    <LM>w#w-d1e1526-x2-815</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-816">
  <m id="m149-d1t1529-3">
   <w.rf>
    <LM>w#w-d1t1529-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1529-4">
   <w.rf>
    <LM>w#w-d1t1529-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1529-5">
   <w.rf>
    <LM>w#w-d1t1529-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1529-6">
   <w.rf>
    <LM>w#w-d1t1529-6</LM>
   </w.rf>
   <form>srovnatelné</form>
   <lemma>srovnatelný_^(*4)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m149-d1t1529-7">
   <w.rf>
    <LM>w#w-d1t1529-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m149-d1t1529-8">
   <w.rf>
    <LM>w#w-d1t1529-8</LM>
   </w.rf>
   <form>evropskými</form>
   <lemma>evropský</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m149-d1t1529-9">
   <w.rf>
    <LM>w#w-d1t1529-9</LM>
   </w.rf>
   <form>cenami</form>
   <lemma>cena</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m149-d1e1526-x2-225">
   <w.rf>
    <LM>w#w-d1e1526-x2-225</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1531-1">
   <w.rf>
    <LM>w#w-d1t1531-1</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1531-2">
   <w.rf>
    <LM>w#w-d1t1531-2</LM>
   </w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m149-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1531-4">
   <w.rf>
    <LM>w#w-d1t1531-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m149-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m149-d-id127569-punct">
   <w.rf>
    <LM>w#w-d-id127569-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1531-7">
   <w.rf>
    <LM>w#w-d1t1531-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1531-8">
   <w.rf>
    <LM>w#w-d1t1531-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1e1526-x2-226">
   <w.rf>
    <LM>w#w-d1e1526-x2-226</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1531-9">
   <w.rf>
    <LM>w#w-d1t1531-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1531-10">
   <w.rf>
    <LM>w#w-d1t1531-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1531-11">
   <w.rf>
    <LM>w#w-d1t1531-11</LM>
   </w.rf>
   <form>běžně</form>
   <lemma>běžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1531-12">
   <w.rf>
    <LM>w#w-d1t1531-12</LM>
   </w.rf>
   <form>ceny</form>
   <lemma>cena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d1t1531-13">
   <w.rf>
    <LM>w#w-d1t1531-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1531-15">
   <w.rf>
    <LM>w#w-d1t1531-15</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m149-d1e1526-x2-227">
   <w.rf>
    <LM>w#w-d1e1526-x2-227</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-224">
  <m id="m149-d1t1533-1">
   <w.rf>
    <LM>w#w-d1t1533-1</LM>
   </w.rf>
   <form>Záleží</form>
   <lemma>záležet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-224-232">
   <w.rf>
    <LM>w#w-224-232</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1533-2">
   <w.rf>
    <LM>w#w-d1t1533-2</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m149-224-233">
   <w.rf>
    <LM>w#w-224-233</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1533-3">
   <w.rf>
    <LM>w#w-d1t1533-3</LM>
   </w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m149-d1t1533-4">
   <w.rf>
    <LM>w#w-d1t1533-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1533-5">
   <w.rf>
    <LM>w#w-d1t1533-5</LM>
   </w.rf>
   <form>kurs</form>
   <lemma>kurs_,s_^(^DD**kurz)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m149-d1t1533-7">
   <w.rf>
    <LM>w#w-d1t1533-7</LM>
   </w.rf>
   <form>zélandského</form>
   <lemma>zélandský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m149-d1t1533-8">
   <w.rf>
    <LM>w#w-d1t1533-8</LM>
   </w.rf>
   <form>dolaru</form>
   <lemma>dolar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m149-224-821">
   <w.rf>
    <LM>w#w-224-821</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-822">
  <m id="m149-d1t1533-11">
   <w.rf>
    <LM>w#w-d1t1533-11</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1533-12">
   <w.rf>
    <LM>w#w-d1t1533-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1533-10">
   <w.rf>
    <LM>w#w-d1t1533-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1533-13">
   <w.rf>
    <LM>w#w-d1t1533-13</LM>
   </w.rf>
   <form>momentálně</form>
   <lemma>momentálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1533-14">
   <w.rf>
    <LM>w#w-d1t1533-14</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1533-15">
   <w.rf>
    <LM>w#w-d1t1533-15</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m149-d-id127960-punct">
   <w.rf>
    <LM>w#w-d-id127960-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1533-17">
   <w.rf>
    <LM>w#w-d1t1533-17</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1533-20">
   <w.rf>
    <LM>w#w-d1t1533-20</LM>
   </w.rf>
   <form>ceny</form>
   <lemma>cena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d1t1533-21">
   <w.rf>
    <LM>w#w-d1t1533-21</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-224-234">
   <w.rf>
    <LM>w#w-224-234</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-223">
  <m id="m149-d1t1535-2">
   <w.rf>
    <LM>w#w-d1t1535-2</LM>
   </w.rf>
   <form>Navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1535-3">
   <w.rf>
    <LM>w#w-d1t1535-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1535-4">
   <w.rf>
    <LM>w#w-d1t1535-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1535-5">
   <w.rf>
    <LM>w#w-d1t1535-5</LM>
   </w.rf>
   <form>sponzora</form>
   <lemma>sponzor</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m149-d1t1535-6">
   <w.rf>
    <LM>w#w-d1t1535-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1535-7">
   <w.rf>
    <LM>w#w-d1t1535-7</LM>
   </w.rf>
   <form>podobě</form>
   <lemma>podoba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m149-d1t1535-8">
   <w.rf>
    <LM>w#w-d1t1535-8</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m149-d1t1535-9">
   <w.rf>
    <LM>w#w-d1t1535-9</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m149-d-id128201-punct">
   <w.rf>
    <LM>w#w-d-id128201-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1535-11">
   <w.rf>
    <LM>w#w-d1t1535-11</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1535-12">
   <w.rf>
    <LM>w#w-d1t1535-12</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m149-d1t1535-13">
   <w.rf>
    <LM>w#w-d1t1535-13</LM>
   </w.rf>
   <form>nemusím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m149-d1t1546-1">
   <w.rf>
    <LM>w#w-d1t1546-1</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m149-d1t1546-2">
   <w.rf>
    <LM>w#w-d1t1546-2</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1546-3">
   <w.rf>
    <LM>w#w-d1t1546-3</LM>
   </w.rf>
   <form>starostí</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1537-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1537-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-241">
  <m id="m149-d1t1550-1">
   <w.rf>
    <LM>w#w-d1t1550-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m149-d1t1550-2">
   <w.rf>
    <LM>w#w-d1t1550-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1550-3">
   <w.rf>
    <LM>w#w-d1t1550-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-id128492-punct">
   <w.rf>
    <LM>w#w-d-id128492-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1551-x2">
  <m id="m149-d1t1554-2">
   <w.rf>
    <LM>w#w-d1t1554-2</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1554-4">
   <w.rf>
    <LM>w#w-d1t1554-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1554-5">
   <w.rf>
    <LM>w#w-d1t1554-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1554-7">
   <w.rf>
    <LM>w#w-d1t1554-7</LM>
   </w.rf>
   <form>Krkonoších</form>
   <lemma>Krkonoše_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m149-d1t1554-9">
   <w.rf>
    <LM>w#w-d1t1554-9</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m149-d1t1554-10">
   <w.rf>
    <LM>w#w-d1t1554-10</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS7-P1-------</tag>
  </m>
  <m id="m149-d1t1554-11">
   <w.rf>
    <LM>w#w-d1t1554-11</LM>
   </w.rf>
   <form>chalupou</form>
   <lemma>chalupa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m149-d1e1551-x2-262">
   <w.rf>
    <LM>w#w-d1e1551-x2-262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-261">
  <m id="m149-d1t1556-3">
   <w.rf>
    <LM>w#w-d1t1556-3</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m149-d-id128772-punct">
   <w.rf>
    <LM>w#w-d-id128772-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1556-5">
   <w.rf>
    <LM>w#w-d1t1556-5</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m149-d1t1556-6">
   <w.rf>
    <LM>w#w-d1t1556-6</LM>
   </w.rf>
   <form>sedí</form>
   <lemma>sedět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1556-7">
   <w.rf>
    <LM>w#w-d1t1556-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m149-d1t1556-8">
   <w.rf>
    <LM>w#w-d1t1556-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m149-d1t1556-9">
   <w.rf>
    <LM>w#w-d1t1556-9</LM>
   </w.rf>
   <form>nohou</form>
   <lemma>noha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m149-d-id128858-punct">
   <w.rf>
    <LM>w#w-d-id128858-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1556-13">
   <w.rf>
    <LM>w#w-d1t1556-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1556-14">
   <w.rf>
    <LM>w#w-d1t1556-14</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m149-d1t1556-15">
   <w.rf>
    <LM>w#w-d1t1556-15</LM>
   </w.rf>
   <form>pejsánek</form>
   <lemma>pejsánek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d-id128944-punct">
   <w.rf>
    <LM>w#w-d-id128944-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1556-17">
   <w.rf>
    <LM>w#w-d1t1556-17</LM>
   </w.rf>
   <form>šestiletý</form>
   <lemma>šestiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m149-d1t1556-19">
   <w.rf>
    <LM>w#w-d1t1556-19</LM>
   </w.rf>
   <form>Merlin</form>
   <lemma>Merlin_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-261-263">
   <w.rf>
    <LM>w#w-261-263</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1558-1">
   <w.rf>
    <LM>w#w-d1t1558-1</LM>
   </w.rf>
   <form>rasy</form>
   <lemma>rasa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m149-d1t1558-4">
   <w.rf>
    <LM>w#w-d1t1558-4</LM>
   </w.rf>
   <form>Jack</form>
   <lemma>Jack_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d1t1560-2">
   <w.rf>
    <LM>w#w-d1t1560-2</LM>
   </w.rf>
   <form>Russel</form>
   <lemma>Russel-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d1t1562-1">
   <w.rf>
    <LM>w#w-d1t1562-1</LM>
   </w.rf>
   <form>teriér</form>
   <lemma>teriér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d-id129139-punct">
   <w.rf>
    <LM>w#w-d-id129139-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1562-4">
   <w.rf>
    <LM>w#w-d1t1562-4</LM>
   </w.rf>
   <form>obrovský</form>
   <lemma>obrovský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m149-d1t1562-5">
   <w.rf>
    <LM>w#w-d1t1562-5</LM>
   </w.rf>
   <form>norník</form>
   <lemma>norník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-261-841">
   <w.rf>
    <LM>w#w-261-841</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-842">
  <m id="m149-d1t1565-1">
   <w.rf>
    <LM>w#w-d1t1565-1</LM>
   </w.rf>
   <form>Myši</form>
   <lemma>myš</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d1t1565-2">
   <w.rf>
    <LM>w#w-d1t1565-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1565-3">
   <w.rf>
    <LM>w#w-d1t1565-3</LM>
   </w.rf>
   <form>krtkové</form>
   <lemma>krtek</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m149-d1t1565-6">
   <w.rf>
    <LM>w#w-d1t1565-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1565-7">
   <w.rf>
    <LM>w#w-d1t1565-7</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m149-d1t1565-8">
   <w.rf>
    <LM>w#w-d1t1565-8</LM>
   </w.rf>
   <form>parketa</form>
   <lemma>parketa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1551-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1551-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1566-x2">
  <m id="m149-d1t1569-1">
   <w.rf>
    <LM>w#w-d1t1569-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m149-d1t1569-2">
   <w.rf>
    <LM>w#w-d1t1569-2</LM>
   </w.rf>
   <form>rasy</form>
   <lemma>rasa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m149-d1t1569-3">
   <w.rf>
    <LM>w#w-d1t1569-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1569-4">
   <w.rf>
    <LM>w#w-d1t1569-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m149-d1t1569-5">
   <w.rf>
    <LM>w#w-d1t1569-5</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d-id129442-punct">
   <w.rf>
    <LM>w#w-d-id129442-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1570-x2">
  <m id="m149-d1t1573-3">
   <w.rf>
    <LM>w#w-d1t1573-3</LM>
   </w.rf>
   <form>Jack</form>
   <lemma>Jack_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d1t1575-2">
   <w.rf>
    <LM>w#w-d1t1575-2</LM>
   </w.rf>
   <form>Russel</form>
   <lemma>Russel-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d1t1577-1">
   <w.rf>
    <LM>w#w-d1t1577-1</LM>
   </w.rf>
   <form>teriér</form>
   <lemma>teriér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d-m-d1e1570-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1570-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1578-x2">
  <m id="m149-d1t1581-1">
   <w.rf>
    <LM>w#w-d1t1581-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1581-2">
   <w.rf>
    <LM>w#w-d1t1581-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1581-3">
   <w.rf>
    <LM>w#w-d1t1581-3</LM>
   </w.rf>
   <form>rasa</form>
   <lemma>rasa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m149-d-id129710-punct">
   <w.rf>
    <LM>w#w-d-id129710-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1578-x3">
  <m id="m149-d1t1581-5">
   <w.rf>
    <LM>w#w-d1t1581-5</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m149-d-id129734-punct">
   <w.rf>
    <LM>w#w-d-id129734-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1581-7">
   <w.rf>
    <LM>w#w-d1t1581-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m149-d1t1581-8">
   <w.rf>
    <LM>w#w-d1t1581-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1581-9">
   <w.rf>
    <LM>w#w-d1t1581-9</LM>
   </w.rf>
   <form>nevěděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m149-d1e1578-x3-278">
   <w.rf>
    <LM>w#w-d1e1578-x3-278</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-277">
  <m id="m149-d1t1583-1">
   <w.rf>
    <LM>w#w-d1t1583-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m149-d1t1583-2">
   <w.rf>
    <LM>w#w-d1t1583-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m149-d1t1583-3">
   <w.rf>
    <LM>w#w-d1t1583-3</LM>
   </w.rf>
   <form>dáváte</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d1t1583-4">
   <w.rf>
    <LM>w#w-d1t1583-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m149-d1t1583-5">
   <w.rf>
    <LM>w#w-d1t1583-5</LM>
   </w.rf>
   <form>jídlu</form>
   <lemma>jídlo</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m149-d-id129881-punct">
   <w.rf>
    <LM>w#w-d-id129881-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1584-x2">
  <m id="m149-d1t1587-2">
   <w.rf>
    <LM>w#w-d1t1587-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1587-3">
   <w.rf>
    <LM>w#w-d1t1587-3</LM>
   </w.rf>
   <form>naučený</form>
   <lemma>naučený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m149-d1t1587-4">
   <w.rf>
    <LM>w#w-d1t1587-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1587-5">
   <w.rf>
    <LM>w#w-d1t1587-5</LM>
   </w.rf>
   <form>granule</form>
   <lemma>granule</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m149-d1e1584-x2-290">
   <w.rf>
    <LM>w#w-d1e1584-x2-290</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-287">
  <m id="m149-d1t1589-1">
   <w.rf>
    <LM>w#w-d1t1589-1</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1589-2">
   <w.rf>
    <LM>w#w-d1t1589-2</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m149-d1t1589-3">
   <w.rf>
    <LM>w#w-d1t1589-3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1589-4">
   <w.rf>
    <LM>w#w-d1t1589-4</LM>
   </w.rf>
   <form>syrovou</form>
   <lemma>syrový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m149-d1t1589-5">
   <w.rf>
    <LM>w#w-d1t1589-5</LM>
   </w.rf>
   <form>mrkev</form>
   <lemma>mrkev</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-287-291">
   <w.rf>
    <LM>w#w-287-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-288">
  <m id="m149-d1t1591-3">
   <w.rf>
    <LM>w#w-d1t1591-3</LM>
   </w.rf>
   <form>Občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1591-4">
   <w.rf>
    <LM>w#w-d1t1591-4</LM>
   </w.rf>
   <form>dostane</form>
   <lemma>dostat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m149-d1t1591-5">
   <w.rf>
    <LM>w#w-d1t1591-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m149-d1t1591-6">
   <w.rf>
    <LM>w#w-d1t1591-6</LM>
   </w.rf>
   <form>odměnu</form>
   <lemma>odměna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-d1t1591-8">
   <w.rf>
    <LM>w#w-d1t1591-8</LM>
   </w.rf>
   <form>psí</form>
   <lemma>psí-1</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m149-d1t1591-9">
   <w.rf>
    <LM>w#w-d1t1591-9</LM>
   </w.rf>
   <form>paštičku</form>
   <lemma>paštička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-288-292">
   <w.rf>
    <LM>w#w-288-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-289">
  <m id="m149-d1t1593-1">
   <w.rf>
    <LM>w#w-d1t1593-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1593-2">
   <w.rf>
    <LM>w#w-d1t1593-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1593-3">
   <w.rf>
    <LM>w#w-d1t1593-3</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m149-d1t1593-4">
   <w.rf>
    <LM>w#w-d1t1593-4</LM>
   </w.rf>
   <form>chuti</form>
   <lemma>chuť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m149-d-id130346-punct">
   <w.rf>
    <LM>w#w-d-id130346-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1593-6">
   <w.rf>
    <LM>w#w-d1t1593-6</LM>
   </w.rf>
   <form>sežral</form>
   <lemma>sežrat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m149-d1t1593-7">
   <w.rf>
    <LM>w#w-d1t1593-7</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m149-d1t1593-8">
   <w.rf>
    <LM>w#w-d1t1593-8</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m149-289-295">
   <w.rf>
    <LM>w#w-289-295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1595-1">
   <w.rf>
    <LM>w#w-d1t1595-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1595-2">
   <w.rf>
    <LM>w#w-d1t1595-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m149-d1t1595-3">
   <w.rf>
    <LM>w#w-d1t1595-3</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m149-d1t1595-4">
   <w.rf>
    <LM>w#w-d1t1595-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m149-d1t1595-5">
   <w.rf>
    <LM>w#w-d1t1595-5</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m149-d1t1595-6">
   <w.rf>
    <LM>w#w-d1t1595-6</LM>
   </w.rf>
   <form>stolu</form>
   <lemma>stůl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m149-289-873">
   <w.rf>
    <LM>w#w-289-873</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-874">
  <m id="m149-d1t1595-9">
   <w.rf>
    <LM>w#w-d1t1595-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m149-d1t1595-10">
   <w.rf>
    <LM>w#w-d1t1595-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1595-11">
   <w.rf>
    <LM>w#w-d1t1595-11</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m149-d1t1595-8">
   <w.rf>
    <LM>w#w-d1t1595-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1595-12">
   <w.rf>
    <LM>w#w-d1t1595-12</LM>
   </w.rf>
   <form>nedává</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m149-289-296">
   <w.rf>
    <LM>w#w-289-296</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1598-1">
   <w.rf>
    <LM>w#w-d1t1598-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1598-2">
   <w.rf>
    <LM>w#w-d1t1598-2</LM>
   </w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1598-3">
   <w.rf>
    <LM>w#w-d1t1598-3</LM>
   </w.rf>
   <form>výjimečně</form>
   <lemma>výjimečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d-m-d1e1584-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1584-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1599-x2">
  <m id="m149-d1t1602-1">
   <w.rf>
    <LM>w#w-d1t1602-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1602-2">
   <w.rf>
    <LM>w#w-d1t1602-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1602-3">
   <w.rf>
    <LM>w#w-d1t1602-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m149-d1t1602-4">
   <w.rf>
    <LM>w#w-d1t1602-4</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1602-5">
   <w.rf>
    <LM>w#w-d1t1602-5</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m149-d1t1602-6">
   <w.rf>
    <LM>w#w-d1t1602-6</LM>
   </w.rf>
   <form>venčit</form>
   <lemma>venčit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m149-d-id130802-punct">
   <w.rf>
    <LM>w#w-d-id130802-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1603-x2">
  <m id="m149-d1t1606-3">
   <w.rf>
    <LM>w#w-d1t1606-3</LM>
   </w.rf>
   <form>Třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m149-d1t1606-4">
   <w.rf>
    <LM>w#w-d1t1606-4</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1606-5">
   <w.rf>
    <LM>w#w-d1t1606-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d1t1606-6">
   <w.rf>
    <LM>w#w-d1t1606-6</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m149-d1e1603-x2-302">
   <w.rf>
    <LM>w#w-d1e1603-x2-302</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-301">
  <m id="m149-d1t1608-1">
   <w.rf>
    <LM>w#w-d1t1608-1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1608-2">
   <w.rf>
    <LM>w#w-d1t1608-2</LM>
   </w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m149-d1t1608-3">
   <w.rf>
    <LM>w#w-d1t1608-3</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m149-d1t1608-4">
   <w.rf>
    <LM>w#w-d1t1608-4</LM>
   </w.rf>
   <form>stačí</form>
   <lemma>stačit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m149-d-id131034-punct">
   <w.rf>
    <LM>w#w-d-id131034-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1608-6">
   <w.rf>
    <LM>w#w-d1t1608-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1608-7">
   <w.rf>
    <LM>w#w-d1t1608-7</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m149-d1t1608-8">
   <w.rf>
    <LM>w#w-d1t1608-8</LM>
   </w.rf>
   <form>chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1608-9">
   <w.rf>
    <LM>w#w-d1t1608-9</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-id131105-punct">
   <w.rf>
    <LM>w#w-d-id131105-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1608-16">
   <w.rf>
    <LM>w#w-d1t1608-16</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d1t1608-17">
   <w.rf>
    <LM>w#w-d1t1608-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m149-d1t1608-18">
   <w.rf>
    <LM>w#w-d1t1608-18</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m149-d-m-d1e1603-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1603-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1609-x2">
  <m id="m149-d1t1612-1">
   <w.rf>
    <LM>w#w-d1t1612-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m149-d1t1612-3">
   <w.rf>
    <LM>w#w-d1t1612-3</LM>
   </w.rf>
   <form>zvířata</form>
   <lemma>zvíře</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m149-d1e1609-x2-306">
   <w.rf>
    <LM>w#w-d1e1609-x2-306</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1613-x2">
  <m id="m149-d1t1616-2">
   <w.rf>
    <LM>w#w-d1t1616-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d-m-d1e1613-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1613-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1623-x2">
  <m id="m149-d1t1626-1">
   <w.rf>
    <LM>w#w-d1t1626-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m149-d1t1626-2">
   <w.rf>
    <LM>w#w-d1t1626-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m149-d1t1626-3">
   <w.rf>
    <LM>w#w-d1t1626-3</LM>
   </w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m149-d1t1626-4">
   <w.rf>
    <LM>w#w-d1t1626-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1t1626-5">
   <w.rf>
    <LM>w#w-d1t1626-5</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m149-d-id131545-punct">
   <w.rf>
    <LM>w#w-d-id131545-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1627-x2">
  <m id="m149-d1t1630-1">
   <w.rf>
    <LM>w#w-d1t1630-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m149-d1e1627-x2-884">
   <w.rf>
    <LM>w#w-d1e1627-x2-884</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-885">
  <m id="m149-d1t1630-3">
   <w.rf>
    <LM>w#w-d1t1630-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1630-4">
   <w.rf>
    <LM>w#w-d1t1630-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m149-d1t1630-5">
   <w.rf>
    <LM>w#w-d1t1630-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m149-d1t1630-6">
   <w.rf>
    <LM>w#w-d1t1630-6</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m149-d-id131693-punct">
   <w.rf>
    <LM>w#w-d-id131693-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1630-10">
   <w.rf>
    <LM>w#w-d1t1630-10</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m149-d1t1630-9">
   <w.rf>
    <LM>w#w-d1t1630-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m149-d1t1630-11">
   <w.rf>
    <LM>w#w-d1t1630-11</LM>
   </w.rf>
   <form>trpasličí</form>
   <lemma>trpasličí</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m149-d1t1630-12">
   <w.rf>
    <LM>w#w-d1t1630-12</LM>
   </w.rf>
   <form>dlouhosrstou</form>
   <lemma>dlouhosrstý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m149-d1t1630-13">
   <w.rf>
    <LM>w#w-d1t1630-13</LM>
   </w.rf>
   <form>jezevčici</form>
   <lemma>jezevčice_^(*3ík)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-d1t1630-15">
   <w.rf>
    <LM>w#w-d1t1630-15</LM>
   </w.rf>
   <form>Nelinku</form>
   <lemma>Nelinka_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m149-d1e1627-x2-312">
   <w.rf>
    <LM>w#w-d1e1627-x2-312</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m149-d1t1632-1">
   <w.rf>
    <LM>w#w-d1t1632-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m149-d1t1632-2">
   <w.rf>
    <LM>w#w-d1t1632-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m149-d-m-d1e1627-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1627-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m149-d1e1633-x2">
  <m id="m149-d1t1636-1">
   <w.rf>
    <LM>w#w-d1t1636-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m149-d1e1633-x2-314">
   <w.rf>
    <LM>w#w-d1e1633-x2-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
