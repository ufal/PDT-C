<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_022.06.w.gz" />
  </references>
 </head>
 <s id="m022-336_1">
  <m id="m022-d1t1833-1">
   <w.rf>
    <LM>w#w-d1t1833-1</LM>
   </w.rf>
   <form>Lecos</form>
   <lemma>leccos</lemma>
   <tag>PK--4---------6</tag>
  </m>
  <m id="m022-d1t1833-5">
   <w.rf>
    <LM>w#w-d1t1833-5</LM>
   </w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m022-d1t1833-2">
   <w.rf>
    <LM>w#w-d1t1833-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1833-3">
   <w.rf>
    <LM>w#w-d1t1833-3</LM>
   </w.rf>
   <form>viděly</form>
   <lemma>vidět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d-m-d1e1826-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1826-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1834-x2">
  <m id="m022-d1t1839-1">
   <w.rf>
    <LM>w#w-d1t1839-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m022-d1t1839-2">
   <w.rf>
    <LM>w#w-d1t1839-2</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m022-d-id110753-punct">
   <w.rf>
    <LM>w#w-d-id110753-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1840-x3">
  <m id="m022-d1t1849-1">
   <w.rf>
    <LM>w#w-d1t1849-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1849-2">
   <w.rf>
    <LM>w#w-d1t1849-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m022-d1t1849-3">
   <w.rf>
    <LM>w#w-d1t1849-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1849-4">
   <w.rf>
    <LM>w#w-d1t1849-4</LM>
   </w.rf>
   <form>svítilo</form>
   <lemma>svítit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1849-5">
   <w.rf>
    <LM>w#w-d1t1849-5</LM>
   </w.rf>
   <form>sluníčko</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m022-d-id110947-punct">
   <w.rf>
    <LM>w#w-d-id110947-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1849-7">
   <w.rf>
    <LM>w#w-d1t1849-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d-id110971-punct">
   <w.rf>
    <LM>w#w-d-id110971-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1850-x2">
  <m id="m022-d1t1853-1">
   <w.rf>
    <LM>w#w-d1t1853-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1e1850-x2-362">
   <w.rf>
    <LM>w#w-d1e1850-x2-362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1853-3">
   <w.rf>
    <LM>w#w-d1t1853-3</LM>
   </w.rf>
   <form>svítilo</form>
   <lemma>svítit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1853-2">
   <w.rf>
    <LM>w#w-d1t1853-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1853-4">
   <w.rf>
    <LM>w#w-d1t1853-4</LM>
   </w.rf>
   <form>sluníčko</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m022-d1e1850-x2-658">
   <w.rf>
    <LM>w#w-d1e1850-x2-658</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-659">
  <m id="m022-d1t1853-5">
   <w.rf>
    <LM>w#w-d1t1853-5</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1e1850-x2-394">
   <w.rf>
    <LM>w#w-d1e1850-x2-394</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1853-12">
   <w.rf>
    <LM>w#w-d1t1853-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1855-1">
   <w.rf>
    <LM>w#w-d1t1855-1</LM>
   </w.rf>
   <form>bouřka</form>
   <lemma>bouřka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m022-d-id111237-punct">
   <w.rf>
    <LM>w#w-d-id111237-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1855-3">
   <w.rf>
    <LM>w#w-d1t1855-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1855-5">
   <w.rf>
    <LM>w#w-d1t1855-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1855-6">
   <w.rf>
    <LM>w#w-d1t1855-6</LM>
   </w.rf>
   <form>udělaly</form>
   <lemma>udělat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-d1t1855-7">
   <w.rf>
    <LM>w#w-d1t1855-7</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m022-d1t1855-8">
   <w.rf>
    <LM>w#w-d1t1855-8</LM>
   </w.rf>
   <form>vlny</form>
   <lemma>vlna</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m022-d-id111325-punct">
   <w.rf>
    <LM>w#w-d-id111325-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1857-1">
   <w.rf>
    <LM>w#w-d1t1857-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1857-3">
   <w.rf>
    <LM>w#w-d1t1857-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1857-4">
   <w.rf>
    <LM>w#w-d1t1857-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1857-2">
   <w.rf>
    <LM>w#w-d1t1857-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1857-5">
   <w.rf>
    <LM>w#w-d1t1857-5</LM>
   </w.rf>
   <form>nemohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m022-d1t1857-6">
   <w.rf>
    <LM>w#w-d1t1857-6</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m022-d1e1850-x2-386">
   <w.rf>
    <LM>w#w-d1e1850-x2-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-388">
  <m id="m022-d1t1857-7">
   <w.rf>
    <LM>w#w-d1t1857-7</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1857-8">
   <w.rf>
    <LM>w#w-d1t1857-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1857-9">
   <w.rf>
    <LM>w#w-d1t1857-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1857-10">
   <w.rf>
    <LM>w#w-d1t1857-10</LM>
   </w.rf>
   <form>procházely</form>
   <lemma>procházet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d-id111498-punct">
   <w.rf>
    <LM>w#w-d-id111498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1857-12">
   <w.rf>
    <LM>w#w-d1t1857-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1857-14">
   <w.rf>
    <LM>w#w-d1t1857-14</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1857-13">
   <w.rf>
    <LM>w#w-d1t1857-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1857-15">
   <w.rf>
    <LM>w#w-d1t1857-15</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1857-16">
   <w.rf>
    <LM>w#w-d1t1857-16</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1857-17">
   <w.rf>
    <LM>w#w-d1t1857-17</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m022-d1t1857-18">
   <w.rf>
    <LM>w#w-d1t1857-18</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1857-19">
   <w.rf>
    <LM>w#w-d1t1857-19</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m022-d1t1857-20">
   <w.rf>
    <LM>w#w-d1t1857-20</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m022-388-390">
   <w.rf>
    <LM>w#w-388-390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-392">
  <m id="m022-d1t1861-2">
   <w.rf>
    <LM>w#w-d1t1861-2</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1861-4">
   <w.rf>
    <LM>w#w-d1t1861-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1861-5">
   <w.rf>
    <LM>w#w-d1t1861-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1861-6">
   <w.rf>
    <LM>w#w-d1t1861-6</LM>
   </w.rf>
   <form>bezvadné</form>
   <lemma>bezvadný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-392-396">
   <w.rf>
    <LM>w#w-392-396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-398">
  <m id="m022-d1t1861-8">
   <w.rf>
    <LM>w#w-d1t1861-8</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1861-9">
   <w.rf>
    <LM>w#w-d1t1861-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m022-d1t1864-1">
   <w.rf>
    <LM>w#w-d1t1864-1</LM>
   </w.rf>
   <form>vyfotily</form>
   <lemma>vyfotit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-398-400">
   <w.rf>
    <LM>w#w-398-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-402">
  <m id="m022-d1t1864-3">
   <w.rf>
    <LM>w#w-d1t1864-3</LM>
   </w.rf>
   <form>Požádaly</form>
   <lemma>požádat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-d1t1864-4">
   <w.rf>
    <LM>w#w-d1t1864-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1864-5">
   <w.rf>
    <LM>w#w-d1t1864-5</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m022-d1t1866-1">
   <w.rf>
    <LM>w#w-d1t1866-1</LM>
   </w.rf>
   <form>cizinky</form>
   <lemma>cizinka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m022-d1t1866-2">
   <w.rf>
    <LM>w#w-d1t1866-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1866-3">
   <w.rf>
    <LM>w#w-d1t1866-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m022-d1t1866-4">
   <w.rf>
    <LM>w#w-d1t1866-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m022-d1t1866-6">
   <w.rf>
    <LM>w#w-d1t1866-6</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1866-5">
   <w.rf>
    <LM>w#w-d1t1866-5</LM>
   </w.rf>
   <form>vyfotily</form>
   <lemma>vyfotit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-402-404">
   <w.rf>
    <LM>w#w-402-404</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-406">
  <m id="m022-d1t1866-10">
   <w.rf>
    <LM>w#w-d1t1866-10</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1866-13">
   <w.rf>
    <LM>w#w-d1t1866-13</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1866-11">
   <w.rf>
    <LM>w#w-d1t1866-11</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m022-d1t1866-12">
   <w.rf>
    <LM>w#w-d1t1866-12</LM>
   </w.rf>
   <form>fotek</form>
   <lemma>fotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m022-406-408">
   <w.rf>
    <LM>w#w-406-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1850-x3">
  <m id="m022-d1t1868-3">
   <w.rf>
    <LM>w#w-d1t1868-3</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m022-d1t1868-4">
   <w.rf>
    <LM>w#w-d1t1868-4</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m022-d1t1868-6">
   <w.rf>
    <LM>w#w-d1t1868-6</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1868-7">
   <w.rf>
    <LM>w#w-d1t1868-7</LM>
   </w.rf>
   <form>padesátiny</form>
   <lemma>padesátiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m022-d-id112200-punct">
   <w.rf>
    <LM>w#w-d-id112200-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1870-1">
   <w.rf>
    <LM>w#w-d1t1870-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1870-2">
   <w.rf>
    <LM>w#w-d1t1870-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m022-d1t1870-3">
   <w.rf>
    <LM>w#w-d1t1870-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1870-4">
   <w.rf>
    <LM>w#w-d1t1870-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1870-6">
   <w.rf>
    <LM>w#w-d1t1870-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m022-d1t1870-7">
   <w.rf>
    <LM>w#w-d1t1870-7</LM>
   </w.rf>
   <form>odměnu</form>
   <lemma>odměna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m022-d1e1850-x3-410">
   <w.rf>
    <LM>w#w-d1e1850-x3-410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-412">
  <m id="m022-d1t1870-9">
   <w.rf>
    <LM>w#w-d1t1870-9</LM>
   </w.rf>
   <form>Dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m022-d1t1870-10">
   <w.rf>
    <LM>w#w-d1t1870-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m022-d1t1870-11">
   <w.rf>
    <LM>w#w-d1t1870-11</LM>
   </w.rf>
   <form>manžela</form>
   <lemma>manžel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m022-d1t1870-13">
   <w.rf>
    <LM>w#w-d1t1870-13</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m022-d1t1870-14">
   <w.rf>
    <LM>w#w-d1t1870-14</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m022-d1t1870-15">
   <w.rf>
    <LM>w#w-d1t1870-15</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m022-d-id112444-punct">
   <w.rf>
    <LM>w#w-d-id112444-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1872-1">
   <w.rf>
    <LM>w#w-d1t1872-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1872-2">
   <w.rf>
    <LM>w#w-d1t1872-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1872-3">
   <w.rf>
    <LM>w#w-d1t1872-3</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1872-4">
   <w.rf>
    <LM>w#w-d1t1872-4</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d-m-d1e1850-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1850-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-420">
  <m id="m022-d1t1887-1">
   <w.rf>
    <LM>w#w-d1t1887-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1887-2">
   <w.rf>
    <LM>w#w-d1t1887-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m022-d1t1887-3">
   <w.rf>
    <LM>w#w-d1t1887-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1887-4">
   <w.rf>
    <LM>w#w-d1t1887-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1887-5">
   <w.rf>
    <LM>w#w-d1t1887-5</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1887-6">
   <w.rf>
    <LM>w#w-d1t1887-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m022-d1t1887-7">
   <w.rf>
    <LM>w#w-d1t1887-7</LM>
   </w.rf>
   <form>dcerou</form>
   <lemma>dcera</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m022-d-id112750-punct">
   <w.rf>
    <LM>w#w-d-id112750-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1873-x5">
  <m id="m022-d1t1889-3">
   <w.rf>
    <LM>w#w-d1t1889-3</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d-m-d1e1873-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1873-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1890-x2">
  <m id="m022-d1t1893-1">
   <w.rf>
    <LM>w#w-d1t1893-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1893-2">
   <w.rf>
    <LM>w#w-d1t1893-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1893-3">
   <w.rf>
    <LM>w#w-d1t1893-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m022-d1t1893-5">
   <w.rf>
    <LM>w#w-d1t1893-5</LM>
   </w.rf>
   <form>Kréta</form>
   <lemma>Kréta_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m022-d1t1893-7">
   <w.rf>
    <LM>w#w-d1t1893-7</LM>
   </w.rf>
   <form>líbila</form>
   <lemma>líbit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d-id112954-punct">
   <w.rf>
    <LM>w#w-d-id112954-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1895-x2">
  <m id="m022-d1t1902-1">
   <w.rf>
    <LM>w#w-d1t1902-1</LM>
   </w.rf>
   <form>Líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1902-2">
   <w.rf>
    <LM>w#w-d1t1902-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1902-3">
   <w.rf>
    <LM>w#w-d1t1902-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m022-d1t1902-4">
   <w.rf>
    <LM>w#w-d1t1902-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d-id113096-punct">
   <w.rf>
    <LM>w#w-d-id113096-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1902-6">
   <w.rf>
    <LM>w#w-d1t1902-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1902-7">
   <w.rf>
    <LM>w#w-d1t1902-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1902-8">
   <w.rf>
    <LM>w#w-d1t1902-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1902-9">
   <w.rf>
    <LM>w#w-d1t1902-9</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-d1e1895-x2-38">
   <w.rf>
    <LM>w#w-d1e1895-x2-38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-40_2">
  <m id="m022-d1t1902-13">
   <w.rf>
    <LM>w#w-d1t1902-13</LM>
   </w.rf>
   <form>Všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1902-15">
   <w.rf>
    <LM>w#w-d1t1902-15</LM>
   </w.rf>
   <form>turisté</form>
   <lemma>turista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m022-40_2-42">
   <w.rf>
    <LM>w#w-40_2-42</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1902-17">
   <w.rf>
    <LM>w#w-d1t1902-17</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1902-18">
   <w.rf>
    <LM>w#w-d1t1902-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1902-19">
   <w.rf>
    <LM>w#w-d1t1902-19</LM>
   </w.rf>
   <form>plno</form>
   <lemma>plno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1902-20">
   <w.rf>
    <LM>w#w-d1t1902-20</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m022-40_2-682">
   <w.rf>
    <LM>w#w-40_2-682</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-683">
  <m id="m022-d1t1906-4">
   <w.rf>
    <LM>w#w-d1t1906-4</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m022-d1t1906-5">
   <w.rf>
    <LM>w#w-d1t1906-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1906-6">
   <w.rf>
    <LM>w#w-d1t1906-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1906-8">
   <w.rf>
    <LM>w#w-d1t1906-8</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1906-7">
   <w.rf>
    <LM>w#w-d1t1906-7</LM>
   </w.rf>
   <form>dívaly</form>
   <lemma>dívat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d-id113495-punct">
   <w.rf>
    <LM>w#w-d-id113495-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1906-12">
   <w.rf>
    <LM>w#w-d1t1906-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1906-13">
   <w.rf>
    <LM>w#w-d1t1906-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1906-14">
   <w.rf>
    <LM>w#w-d1t1906-14</LM>
   </w.rf>
   <form>rostou</form>
   <lemma>růst-2</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1906-15">
   <w.rf>
    <LM>w#w-d1t1906-15</LM>
   </w.rf>
   <form>kytičky</form>
   <lemma>kytička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m022-40_2-46">
   <w.rf>
    <LM>w#w-40_2-46</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1906-17">
   <w.rf>
    <LM>w#w-d1t1906-17</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1906-18">
   <w.rf>
    <LM>w#w-d1t1906-18</LM>
   </w.rf>
   <form>kvetou</form>
   <lemma>kvést</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-40_2-72">
   <w.rf>
    <LM>w#w-40_2-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-48">
  <m id="m022-d1t1909-7">
   <w.rf>
    <LM>w#w-d1t1909-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1909-6">
   <w.rf>
    <LM>w#w-d1t1909-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1909-8">
   <w.rf>
    <LM>w#w-d1t1909-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1909-9">
   <w.rf>
    <LM>w#w-d1t1909-9</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-48-50">
   <w.rf>
    <LM>w#w-48-50</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1909-13">
   <w.rf>
    <LM>w#w-d1t1909-13</LM>
   </w.rf>
   <form>kytičky</form>
   <lemma>kytička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m022-48-688">
   <w.rf>
    <LM>w#w-48-688</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1909-12">
   <w.rf>
    <LM>w#w-d1t1909-12</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d-m-d1e1895-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1895-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1912-x2">
  <m id="m022-d1t1917-1">
   <w.rf>
    <LM>w#w-d1t1917-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m022-d1t1917-2">
   <w.rf>
    <LM>w#w-d1t1917-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1917-3">
   <w.rf>
    <LM>w#w-d1t1917-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m022-d1t1917-4">
   <w.rf>
    <LM>w#w-d1t1917-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1917-5">
   <w.rf>
    <LM>w#w-d1t1917-5</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1917-6">
   <w.rf>
    <LM>w#w-d1t1917-6</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m022-d-id113939-punct">
   <w.rf>
    <LM>w#w-d-id113939-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1918-x2">
  <m id="m022-d1t1923-1">
   <w.rf>
    <LM>w#w-d1t1923-1</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m022-d1t1923-2">
   <w.rf>
    <LM>w#w-d1t1923-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1923-3">
   <w.rf>
    <LM>w#w-d1t1923-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m022-d1t1923-4">
   <w.rf>
    <LM>w#w-d1t1923-4</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d-id114071-punct">
   <w.rf>
    <LM>w#w-d-id114071-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1923-6">
   <w.rf>
    <LM>w#w-d1t1923-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1923-7">
   <w.rf>
    <LM>w#w-d1t1923-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1923-8">
   <w.rf>
    <LM>w#w-d1t1923-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t1923-9">
   <w.rf>
    <LM>w#w-d1t1923-9</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1923-10">
   <w.rf>
    <LM>w#w-d1t1923-10</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m022-d1t1923-13">
   <w.rf>
    <LM>w#w-d1t1923-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t1923-15">
   <w.rf>
    <LM>w#w-d1t1923-15</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-d-id114243-punct">
   <w.rf>
    <LM>w#w-d-id114243-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1923-18">
   <w.rf>
    <LM>w#w-d1t1923-18</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1923-19">
   <w.rf>
    <LM>w#w-d1t1923-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1923-20">
   <w.rf>
    <LM>w#w-d1t1923-20</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1925-1">
   <w.rf>
    <LM>w#w-d1t1925-1</LM>
   </w.rf>
   <form>píseček</form>
   <lemma>píseček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m022-d1e1918-x2-60">
   <w.rf>
    <LM>w#w-d1e1918-x2-60</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1927-1">
   <w.rf>
    <LM>w#w-d1t1927-1</LM>
   </w.rf>
   <form>teplá</form>
   <lemma>teplý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m022-d1t1927-2">
   <w.rf>
    <LM>w#w-d1t1927-2</LM>
   </w.rf>
   <form>vodička</form>
   <lemma>vodička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m022-d1e1918-x2-64">
   <w.rf>
    <LM>w#w-d1e1918-x2-64</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-62">
  <m id="m022-d1t1927-5">
   <w.rf>
    <LM>w#w-d1t1927-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1927-6">
   <w.rf>
    <LM>w#w-d1t1927-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t1927-7">
   <w.rf>
    <LM>w#w-d1t1927-7</LM>
   </w.rf>
   <form>bezvadné</form>
   <lemma>bezvadný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-d1t1927-8">
   <w.rf>
    <LM>w#w-d1t1927-8</LM>
   </w.rf>
   <form>relaxování</form>
   <lemma>relaxování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m022-d-m-d1e1918-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1918-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1934-x2">
  <m id="m022-d1t1939-1">
   <w.rf>
    <LM>w#w-d1t1939-1</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1939-2">
   <w.rf>
    <LM>w#w-d1t1939-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1939-3">
   <w.rf>
    <LM>w#w-d1t1939-3</LM>
   </w.rf>
   <form>šly</form>
   <lemma>jít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1939-4">
   <w.rf>
    <LM>w#w-d1t1939-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m022-d1t1939-5">
   <w.rf>
    <LM>w#w-d1t1939-5</LM>
   </w.rf>
   <form>pizzu</form>
   <lemma>pizza</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m022-d-m-d1e1934-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1934-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1934-x3">
  <m id="m022-d1t1943-1">
   <w.rf>
    <LM>w#w-d1t1943-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t1943-2">
   <w.rf>
    <LM>w#w-d1t1943-2</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t1943-3">
   <w.rf>
    <LM>w#w-d1t1943-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m022-d1t1943-4">
   <w.rf>
    <LM>w#w-d1t1943-4</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d-m-d1e1934-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1934-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1950-x2">
  <m id="m022-d1t1953-1">
   <w.rf>
    <LM>w#w-d1t1953-1</LM>
   </w.rf>
   <form>Cestujete</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m022-d1t1953-2">
   <w.rf>
    <LM>w#w-d1t1953-2</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m022-d-id114795-punct">
   <w.rf>
    <LM>w#w-d-id114795-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1954-x2">
  <m id="m022-d1t1959-1">
   <w.rf>
    <LM>w#w-d1t1959-1</LM>
   </w.rf>
   <form>Cestujeme</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1e1954-x2-96">
   <w.rf>
    <LM>w#w-d1e1954-x2-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-100">
  <m id="m022-d1t1959-2">
   <w.rf>
    <LM>w#w-d1t1959-2</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m022-d1t1959-3">
   <w.rf>
    <LM>w#w-d1t1959-3</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m022-d1t1959-4">
   <w.rf>
    <LM>w#w-d1t1959-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1959-5">
   <w.rf>
    <LM>w#w-d1t1959-5</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1959-6">
   <w.rf>
    <LM>w#w-d1t1959-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m022-100-102">
   <w.rf>
    <LM>w#w-100-102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-104_1">
  <m id="m022-d1t1959-7">
   <w.rf>
    <LM>w#w-d1t1959-7</LM>
   </w.rf>
   <form>Napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1959-8">
   <w.rf>
    <LM>w#w-d1t1959-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1959-9">
   <w.rf>
    <LM>w#w-d1t1959-9</LM>
   </w.rf>
   <form>jezdívala</form>
   <lemma>jezdívat_^(*4it)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1959-10">
   <w.rf>
    <LM>w#w-d1t1959-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m022-d1t1959-11">
   <w.rf>
    <LM>w#w-d1t1959-11</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m022-d-id115023-punct">
   <w.rf>
    <LM>w#w-d-id115023-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1959-13">
   <w.rf>
    <LM>w#w-d1t1959-13</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m022-d1t1959-14">
   <w.rf>
    <LM>w#w-d1t1959-14</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1959-15">
   <w.rf>
    <LM>w#w-d1t1959-15</LM>
   </w.rf>
   <form>ovdověla</form>
   <lemma>ovdovět</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m022-104_1-707">
   <w.rf>
    <LM>w#w-104_1-707</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-708">
  <m id="m022-d1t1959-19">
   <w.rf>
    <LM>w#w-d1t1959-19</LM>
   </w.rf>
   <form>Jezdily</form>
   <lemma>jezdit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1959-18">
   <w.rf>
    <LM>w#w-d1t1959-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1959-20">
   <w.rf>
    <LM>w#w-d1t1959-20</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-104_1-106">
   <w.rf>
    <LM>w#w-104_1-106</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-108_1">
  <m id="m022-d1t1961-2">
   <w.rf>
    <LM>w#w-d1t1961-2</LM>
   </w.rf>
   <form>Několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m022-d1t1961-3">
   <w.rf>
    <LM>w#w-d1t1961-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1961-4">
   <w.rf>
    <LM>w#w-d1t1961-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1961-5">
   <w.rf>
    <LM>w#w-d1t1961-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m022-d1t1961-6">
   <w.rf>
    <LM>w#w-d1t1961-6</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m022-108_1-110">
   <w.rf>
    <LM>w#w-108_1-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-112">
  <m id="m022-d1t1961-8">
   <w.rf>
    <LM>w#w-d1t1961-8</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1961-9">
   <w.rf>
    <LM>w#w-d1t1961-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1961-10">
   <w.rf>
    <LM>w#w-d1t1961-10</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1961-11">
   <w.rf>
    <LM>w#w-d1t1961-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t1961-13">
   <w.rf>
    <LM>w#w-d1t1961-13</LM>
   </w.rf>
   <form>Holandsku</form>
   <lemma>Holandsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-112-114">
   <w.rf>
    <LM>w#w-112-114</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1961-18">
   <w.rf>
    <LM>w#w-d1t1961-18</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m022-d1t1961-20">
   <w.rf>
    <LM>w#w-d1t1961-20</LM>
   </w.rf>
   <form>Španělsku</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-d1t1961-15">
   <w.rf>
    <LM>w#w-d1t1961-15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1963-1">
   <w.rf>
    <LM>w#w-d1t1963-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t1963-3">
   <w.rf>
    <LM>w#w-d1t1963-3</LM>
   </w.rf>
   <form>Itálii</form>
   <lemma>Itálie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m022-112-116">
   <w.rf>
    <LM>w#w-112-116</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1965-2">
   <w.rf>
    <LM>w#w-d1t1965-2</LM>
   </w.rf>
   <form>různě</form>
   <lemma>různě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m022-112-118">
   <w.rf>
    <LM>w#w-112-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-120">
  <m id="m022-d1t1965-4">
   <w.rf>
    <LM>w#w-d1t1965-4</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m022-d1t1965-5">
   <w.rf>
    <LM>w#w-d1t1965-5</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m022-d1t1965-6">
   <w.rf>
    <LM>w#w-d1t1965-6</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-120-122">
   <w.rf>
    <LM>w#w-120-122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-124">
  <m id="m022-d1t1965-8">
   <w.rf>
    <LM>w#w-d1t1965-8</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1965-9">
   <w.rf>
    <LM>w#w-d1t1965-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1965-10">
   <w.rf>
    <LM>w#w-d1t1965-10</LM>
   </w.rf>
   <form>naspořily</form>
   <lemma>naspořit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-d1t1965-11">
   <w.rf>
    <LM>w#w-d1t1965-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1965-12">
   <w.rf>
    <LM>w#w-d1t1965-12</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t1965-13">
   <w.rf>
    <LM>w#w-d1t1965-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d-m-d1e1954-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1954-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1969-x2">
  <m id="m022-d1t1974-3">
   <w.rf>
    <LM>w#w-d1t1974-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1982-1">
   <w.rf>
    <LM>w#w-d1t1982-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m022-d1t1982-2">
   <w.rf>
    <LM>w#w-d1t1982-2</LM>
   </w.rf>
   <form>našla</form>
   <lemma>najít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m022-d1t1982-6">
   <w.rf>
    <LM>w#w-d1t1982-6</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnMS4----------</tag>
  </m>
  <m id="m022-d1t1982-5">
   <w.rf>
    <LM>w#w-d1t1982-5</LM>
   </w.rf>
   <form>pána</form>
   <lemma>pán</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m022-d-id115993-punct">
   <w.rf>
    <LM>w#w-d-id115993-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t1982-9">
   <w.rf>
    <LM>w#w-d1t1982-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t1982-10">
   <w.rf>
    <LM>w#w-d1t1982-10</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1982-11">
   <w.rf>
    <LM>w#w-d1t1982-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1982-12">
   <w.rf>
    <LM>w#w-d1t1982-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1982-13">
   <w.rf>
    <LM>w#w-d1t1982-13</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t1982-14">
   <w.rf>
    <LM>w#w-d1t1982-14</LM>
   </w.rf>
   <form>nejezdily</form>
   <lemma>jezdit</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m022-d1e1969-x2-128">
   <w.rf>
    <LM>w#w-d1e1969-x2-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-130">
  <m id="m022-d1t1984-1">
   <w.rf>
    <LM>w#w-d1t1984-1</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t1984-2">
   <w.rf>
    <LM>w#w-d1t1984-2</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m022-d1t1984-3">
   <w.rf>
    <LM>w#w-d1t1984-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m022-d1t1984-4">
   <w.rf>
    <LM>w#w-d1t1984-4</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t1984-5">
   <w.rf>
    <LM>w#w-d1t1984-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m022-d1t1984-6">
   <w.rf>
    <LM>w#w-d1t1984-6</LM>
   </w.rf>
   <form>dcerou</form>
   <lemma>dcera</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m022-d-m-d1e1979-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1979-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e1999-x2">
  <m id="m022-d1t2002-1">
   <w.rf>
    <LM>w#w-d1t2002-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t2002-2">
   <w.rf>
    <LM>w#w-d1t2002-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t2002-3">
   <w.rf>
    <LM>w#w-d1t2002-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m022-d1t2002-4">
   <w.rf>
    <LM>w#w-d1t2002-4</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t2002-5">
   <w.rf>
    <LM>w#w-d1t2002-5</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m022-d-id116499-punct">
   <w.rf>
    <LM>w#w-d-id116499-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2003-x2">
  <m id="m022-d1t2008-1">
   <w.rf>
    <LM>w#w-d1t2008-1</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m022-d1t2008-2">
   <w.rf>
    <LM>w#w-d1t2008-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t2008-3">
   <w.rf>
    <LM>w#w-d1t2008-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m022-d1t2008-5">
   <w.rf>
    <LM>w#w-d1t2008-5</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t2008-6">
   <w.rf>
    <LM>w#w-d1t2008-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2008-8">
   <w.rf>
    <LM>w#w-d1t2008-8</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-d-m-d1e2003-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2003-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2013-x2">
  <m id="m022-d1t2016-1">
   <w.rf>
    <LM>w#w-d1t2016-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d-id116841-punct">
   <w.rf>
    <LM>w#w-d-id116841-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2017-x2">
  <m id="m022-d1t2024-3">
   <w.rf>
    <LM>w#w-d1t2024-3</LM>
   </w.rf>
   <form>Domorodci</form>
   <lemma>domorodec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m022-d1t2022-1">
   <w.rf>
    <LM>w#w-d1t2022-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2022-3">
   <w.rf>
    <LM>w#w-d1t2022-3</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-d1t2022-5">
   <w.rf>
    <LM>w#w-d1t2022-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-d1t2032-5">
   <w.rf>
    <LM>w#w-d1t2032-5</LM>
   </w.rf>
   <form>pohodoví</form>
   <lemma>pohodový</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m022-d1t2022-7">
   <w.rf>
    <LM>w#w-d1t2022-7</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m022-d-m-d1e2027-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2027-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2038-x2">
  <m id="m022-d1t2041-3">
   <w.rf>
    <LM>w#w-d1t2041-3</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-d1t2041-4">
   <w.rf>
    <LM>w#w-d1t2041-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m022-d1t2041-7">
   <w.rf>
    <LM>w#w-d1t2041-7</LM>
   </w.rf>
   <form>Čechy</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m022-d1t2041-9">
   <w.rf>
    <LM>w#w-d1t2041-9</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m022-d-m-d1e2038-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2038-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2042-x2">
  <m id="m022-d1t2045-1">
   <w.rf>
    <LM>w#w-d1t2045-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t2045-2">
   <w.rf>
    <LM>w#w-d1t2045-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m022-d1t2045-3">
   <w.rf>
    <LM>w#w-d1t2045-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-d-m-d1e2042-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2042-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2052-x2">
  <m id="m022-d1t2055-1">
   <w.rf>
    <LM>w#w-d1t2055-1</LM>
   </w.rf>
   <form>Kolikrát</form>
   <lemma>kolikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m022-d1t2055-2">
   <w.rf>
    <LM>w#w-d1t2055-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m022-d1t2055-3">
   <w.rf>
    <LM>w#w-d1t2055-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t2055-4">
   <w.rf>
    <LM>w#w-d1t2055-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2055-6">
   <w.rf>
    <LM>w#w-d1t2055-6</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m022-d-id117873-punct">
   <w.rf>
    <LM>w#w-d-id117873-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2056-x2">
  <m id="m022-d1t2063-2">
   <w.rf>
    <LM>w#w-d1t2063-2</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t2063-3">
   <w.rf>
    <LM>w#w-d1t2063-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t2063-4">
   <w.rf>
    <LM>w#w-d1t2063-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2063-5">
   <w.rf>
    <LM>w#w-d1t2063-5</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m022-d1e2056-x2-40">
   <w.rf>
    <LM>w#w-d1e2056-x2-40</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2064-x2">
  <m id="m022-d1t2067-1">
   <w.rf>
    <LM>w#w-d1t2067-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m022-d1t2067-2">
   <w.rf>
    <LM>w#w-d1t2067-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m022-d1t2067-3">
   <w.rf>
    <LM>w#w-d1t2067-3</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m022-d1t2067-4">
   <w.rf>
    <LM>w#w-d1t2067-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m022-d1t2067-5">
   <w.rf>
    <LM>w#w-d1t2067-5</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m022-d1t2067-6">
   <w.rf>
    <LM>w#w-d1t2067-6</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m022-d1t2067-7">
   <w.rf>
    <LM>w#w-d1t2067-7</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m022-d-id118274-punct">
   <w.rf>
    <LM>w#w-d-id118274-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2068-x2">
  <m id="m022-d1t2075-2">
   <w.rf>
    <LM>w#w-d1t2075-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t2075-3">
   <w.rf>
    <LM>w#w-d1t2075-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1e2068-x2-68">
   <w.rf>
    <LM>w#w-d1e2068-x2-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-70">
  <m id="m022-d1t2075-4">
   <w.rf>
    <LM>w#w-d1t2075-4</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m022-d1t2075-5">
   <w.rf>
    <LM>w#w-d1t2075-5</LM>
   </w.rf>
   <form>proběhlo</form>
   <lemma>proběhnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m022-d1t2075-6">
   <w.rf>
    <LM>w#w-d1t2075-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2075-7">
   <w.rf>
    <LM>w#w-d1t2075-7</LM>
   </w.rf>
   <form>pořádku</form>
   <lemma>pořádek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m022-70-72">
   <w.rf>
    <LM>w#w-70-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-74">
  <m id="m022-d1t2077-1">
   <w.rf>
    <LM>w#w-d1t2077-1</LM>
   </w.rf>
   <form>Chutnala</form>
   <lemma>chutnat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m022-d1t2077-2">
   <w.rf>
    <LM>w#w-d1t2077-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m022-d1t2077-3">
   <w.rf>
    <LM>w#w-d1t2077-3</LM>
   </w.rf>
   <form>pizza</form>
   <lemma>pizza</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m022-d-id118535-punct">
   <w.rf>
    <LM>w#w-d-id118535-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t2079-2">
   <w.rf>
    <LM>w#w-d1t2079-2</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m022-d1t2079-3">
   <w.rf>
    <LM>w#w-d1t2079-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t2079-4">
   <w.rf>
    <LM>w#w-d1t2079-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m022-d1t2079-5">
   <w.rf>
    <LM>w#w-d1t2079-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t2079-6">
   <w.rf>
    <LM>w#w-d1t2079-6</LM>
   </w.rf>
   <form>koupily</form>
   <lemma>koupit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-74-76">
   <w.rf>
    <LM>w#w-74-76</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-78">
  <m id="m022-d1t2079-7">
   <w.rf>
    <LM>w#w-d1t2079-7</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d-id118637-punct">
   <w.rf>
    <LM>w#w-d-id118637-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-78-80">
   <w.rf>
    <LM>w#w-78-80</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t2082-21">
   <w.rf>
    <LM>w#w-d1t2082-21</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m022-d1t2082-22">
   <w.rf>
    <LM>w#w-d1t2082-22</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m022-d1t2082-23">
   <w.rf>
    <LM>w#w-d1t2082-23</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m022-78-82">
   <w.rf>
    <LM>w#w-78-82</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t2082-2">
   <w.rf>
    <LM>w#w-d1t2082-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m022-d1t2082-3">
   <w.rf>
    <LM>w#w-d1t2082-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m022-d1t2082-4">
   <w.rf>
    <LM>w#w-d1t2082-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m022-d1t2082-5">
   <w.rf>
    <LM>w#w-d1t2082-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m022-d1t2082-7">
   <w.rf>
    <LM>w#w-d1t2082-7</LM>
   </w.rf>
   <form>upekli</form>
   <lemma>upéci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m022-d1t2082-8">
   <w.rf>
    <LM>w#w-d1t2082-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m022-d1t2082-9">
   <w.rf>
    <LM>w#w-d1t2082-9</LM>
   </w.rf>
   <form>peci</form>
   <lemma>pec</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m022-d-id118851-punct">
   <w.rf>
    <LM>w#w-d-id118851-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t2082-16">
   <w.rf>
    <LM>w#w-d1t2082-16</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m022-d1t2082-17">
   <w.rf>
    <LM>w#w-d1t2082-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t2082-18">
   <w.rf>
    <LM>w#w-d1t2082-18</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-78-84">
   <w.rf>
    <LM>w#w-78-84</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-86">
  <m id="m022-d1t2082-25">
   <w.rf>
    <LM>w#w-d1t2082-25</LM>
   </w.rf>
   <form>Ochutnaly</form>
   <lemma>ochutnat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m022-d1t2082-26">
   <w.rf>
    <LM>w#w-d1t2082-26</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m022-d1t2082-27">
   <w.rf>
    <LM>w#w-d1t2082-27</LM>
   </w.rf>
   <form>všechna</form>
   <lemma>všechen</lemma>
   <tag>PLNP4----------</tag>
  </m>
  <m id="m022-d1t2084-2">
   <w.rf>
    <LM>w#w-d1t2084-2</LM>
   </w.rf>
   <form>řecká</form>
   <lemma>řecký</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m022-d1t2082-30">
   <w.rf>
    <LM>w#w-d1t2082-30</LM>
   </w.rf>
   <form>jídla</form>
   <lemma>jídlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m022-d-id119058-punct">
   <w.rf>
    <LM>w#w-d-id119058-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m022-d1t2082-32">
   <w.rf>
    <LM>w#w-d1t2082-32</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m022-d1t2082-33">
   <w.rf>
    <LM>w#w-d1t2082-33</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t2084-1">
   <w.rf>
    <LM>w#w-d1t2084-1</LM>
   </w.rf>
   <form>vaří</form>
   <lemma>vařit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m022-d-m-d1e2068-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2068-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m022-d1e2097-x2">
  <m id="m022-d1t2100-1">
   <w.rf>
    <LM>w#w-d1t2100-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m022-d1t2100-2">
   <w.rf>
    <LM>w#w-d1t2100-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m022-d1t2100-3">
   <w.rf>
    <LM>w#w-d1t2100-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m022-d1t2100-4">
   <w.rf>
    <LM>w#w-d1t2100-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m022-d1t2100-5">
   <w.rf>
    <LM>w#w-d1t2100-5</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m022-d1t2100-6">
   <w.rf>
    <LM>w#w-d1t2100-6</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m022-d-id119416-punct">
   <w.rf>
    <LM>w#w-d-id119416-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
