<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pk_015.01.w.gz" />
  </references>
 </head>
 <s id="m015-183">
  <m id="m015-d1t240-6">
   <w.rf>
    <LM>w#w-d1t240-6</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t240-7">
   <w.rf>
    <LM>w#w-d1t240-7</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m015-d-id66410-punct">
   <w.rf>
    <LM>w#w-d-id66410-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t240-9">
   <w.rf>
    <LM>w#w-d1t240-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t240-10">
   <w.rf>
    <LM>w#w-d1t240-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t240-12">
   <w.rf>
    <LM>w#w-d1t240-12</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m015-d1t240-11">
   <w.rf>
    <LM>w#w-d1t240-11</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m015-d-id66481-punct">
   <w.rf>
    <LM>w#w-d-id66481-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t242-2">
   <w.rf>
    <LM>w#w-d1t242-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t242-3">
   <w.rf>
    <LM>w#w-d1t242-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t242-4">
   <w.rf>
    <LM>w#w-d1t242-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t242-5">
   <w.rf>
    <LM>w#w-d1t242-5</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t242-6">
   <w.rf>
    <LM>w#w-d1t242-6</LM>
   </w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d1t242-9">
   <w.rf>
    <LM>w#w-d1t242-9</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t242-7">
   <w.rf>
    <LM>w#w-d1t242-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m015-d1t242-8">
   <w.rf>
    <LM>w#w-d1t242-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m015-d-m-d1e237-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e237-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e243-x2">
  <m id="m015-d1t246-1">
   <w.rf>
    <LM>w#w-d1t246-1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m015-d1t246-2">
   <w.rf>
    <LM>w#w-d1t246-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t246-3">
   <w.rf>
    <LM>w#w-d1t246-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m015-d1t246-4">
   <w.rf>
    <LM>w#w-d1t246-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m015-d-id66733-punct">
   <w.rf>
    <LM>w#w-d-id66733-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e247-x2">
  <m id="m015-d1t250-1">
   <w.rf>
    <LM>w#w-d1t250-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t250-2">
   <w.rf>
    <LM>w#w-d1t250-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m015-d1t250-3">
   <w.rf>
    <LM>w#w-d1t250-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m015-d1t250-4">
   <w.rf>
    <LM>w#w-d1t250-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t250-5">
   <w.rf>
    <LM>w#w-d1t250-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t250-6">
   <w.rf>
    <LM>w#w-d1t250-6</LM>
   </w.rf>
   <form>vepředu</form>
   <lemma>vepředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d-id66904-punct">
   <w.rf>
    <LM>w#w-d-id66904-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t250-9">
   <w.rf>
    <LM>w#w-d1t250-9</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m015-d1t250-10">
   <w.rf>
    <LM>w#w-d1t250-10</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d-m-d1e247-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e247-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e252-x2">
  <m id="m015-d1t259-3">
   <w.rf>
    <LM>w#w-d1t259-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t259-2">
   <w.rf>
    <LM>w#w-d1t259-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m015-d1t259-1">
   <w.rf>
    <LM>w#w-d1t259-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t259-4">
   <w.rf>
    <LM>w#w-d1t259-4</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m015-d-id67079-punct">
   <w.rf>
    <LM>w#w-d-id67079-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t259-6">
   <w.rf>
    <LM>w#w-d1t259-6</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m015-d1t259-7">
   <w.rf>
    <LM>w#w-d1t259-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t259-8">
   <w.rf>
    <LM>w#w-d1t259-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t259-9">
   <w.rf>
    <LM>w#w-d1t259-9</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t259-10">
   <w.rf>
    <LM>w#w-d1t259-10</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m015-d-m-d1e252-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e252-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e264-x2">
  <m id="m015-d1t267-1">
   <w.rf>
    <LM>w#w-d1t267-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m015-d1t267-2">
   <w.rf>
    <LM>w#w-d1t267-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m015-d1t267-3">
   <w.rf>
    <LM>w#w-d1t267-3</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m015-d-id67275-punct">
   <w.rf>
    <LM>w#w-d-id67275-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t269-1">
   <w.rf>
    <LM>w#w-d1t269-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t269-5">
   <w.rf>
    <LM>w#w-d1t269-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t269-6">
   <w.rf>
    <LM>w#w-d1t269-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t269-7">
   <w.rf>
    <LM>w#w-d1t269-7</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t269-8">
   <w.rf>
    <LM>w#w-d1t269-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t269-10">
   <w.rf>
    <LM>w#w-d1t269-10</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m015-d1t269-11">
   <w.rf>
    <LM>w#w-d1t269-11</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1e264-x2-224">
   <w.rf>
    <LM>w#w-d1e264-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-225">
  <m id="m015-d1t269-13">
   <w.rf>
    <LM>w#w-d1t269-13</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m015-d1t269-14">
   <w.rf>
    <LM>w#w-d1t269-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t269-15">
   <w.rf>
    <LM>w#w-d1t269-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t269-16">
   <w.rf>
    <LM>w#w-d1t269-16</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m015-d1t269-17">
   <w.rf>
    <LM>w#w-d1t269-17</LM>
   </w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m015-d1t269-20">
   <w.rf>
    <LM>w#w-d1t269-20</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m015-d1t269-21">
   <w.rf>
    <LM>w#w-d1t269-21</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m015-225-214">
   <w.rf>
    <LM>w#w-225-214</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-216">
  <m id="m015-d1t271-5">
   <w.rf>
    <LM>w#w-d1t271-5</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t271-6">
   <w.rf>
    <LM>w#w-d1t271-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t271-7">
   <w.rf>
    <LM>w#w-d1t271-7</LM>
   </w.rf>
   <form>jednotřídka</form>
   <lemma>jednotřídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d-id67703-punct">
   <w.rf>
    <LM>w#w-d-id67703-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t271-9">
   <w.rf>
    <LM>w#w-d1t271-9</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t271-10">
   <w.rf>
    <LM>w#w-d1t271-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t271-11">
   <w.rf>
    <LM>w#w-d1t271-11</LM>
   </w.rf>
   <form>páté</form>
   <lemma>pátý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m015-d1t271-12">
   <w.rf>
    <LM>w#w-d1t271-12</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-225-226">
   <w.rf>
    <LM>w#w-225-226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-208">
  <m id="m015-d1t278-2">
   <w.rf>
    <LM>w#w-d1t278-2</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t278-3">
   <w.rf>
    <LM>w#w-d1t278-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t278-4">
   <w.rf>
    <LM>w#w-d1t278-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t278-5">
   <w.rf>
    <LM>w#w-d1t278-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t278-1">
   <w.rf>
    <LM>w#w-d1t278-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t278-6">
   <w.rf>
    <LM>w#w-d1t278-6</LM>
   </w.rf>
   <form>naučili</form>
   <lemma>naučit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d-id68043-punct">
   <w.rf>
    <LM>w#w-d-id68043-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t278-8">
   <w.rf>
    <LM>w#w-d1t278-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t278-9">
   <w.rf>
    <LM>w#w-d1t278-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t278-10">
   <w.rf>
    <LM>w#w-d1t278-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t278-11">
   <w.rf>
    <LM>w#w-d1t278-11</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t278-12">
   <w.rf>
    <LM>w#w-d1t278-12</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m015-d1t278-13">
   <w.rf>
    <LM>w#w-d1t278-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t278-15">
   <w.rf>
    <LM>w#w-d1t278-15</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m015-d1t278-17">
   <w.rf>
    <LM>w#w-d1t278-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t278-18">
   <w.rf>
    <LM>w#w-d1t278-18</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d-id68203-punct">
   <w.rf>
    <LM>w#w-d-id68203-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t280-3">
   <w.rf>
    <LM>w#w-d1t280-3</LM>
   </w.rf>
   <form>znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t280-1">
   <w.rf>
    <LM>w#w-d1t280-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t280-2">
   <w.rf>
    <LM>w#w-d1t280-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m015-d1t280-4">
   <w.rf>
    <LM>w#w-d1t280-4</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m015-d1t280-6">
   <w.rf>
    <LM>w#w-d1t280-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t280-8">
   <w.rf>
    <LM>w#w-d1t280-8</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m015-d1t280-10">
   <w.rf>
    <LM>w#w-d1t280-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t280-11">
   <w.rf>
    <LM>w#w-d1t280-11</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m015-d1t280-12">
   <w.rf>
    <LM>w#w-d1t280-12</LM>
   </w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m015-d-id68440-punct">
   <w.rf>
    <LM>w#w-d-id68440-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t280-14">
   <w.rf>
    <LM>w#w-d1t280-14</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t280-15">
   <w.rf>
    <LM>w#w-d1t280-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t280-16">
   <w.rf>
    <LM>w#w-d1t280-16</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m015-208-223">
   <w.rf>
    <LM>w#w-208-223</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e281-x2">
  <m id="m015-d1t286-1">
   <w.rf>
    <LM>w#w-d1t286-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t286-2">
   <w.rf>
    <LM>w#w-d1t286-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t286-4">
   <w.rf>
    <LM>w#w-d1t286-4</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m015-d1t286-5">
   <w.rf>
    <LM>w#w-d1t286-5</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1e281-x2-284">
   <w.rf>
    <LM>w#w-d1e281-x2-284</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-285">
  <m id="m015-d1t286-7">
   <w.rf>
    <LM>w#w-d1t286-7</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m015-d-id68665-punct">
   <w.rf>
    <LM>w#w-d-id68665-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t286-9">
   <w.rf>
    <LM>w#w-d1t286-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t286-11">
   <w.rf>
    <LM>w#w-d1t286-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t286-10">
   <w.rf>
    <LM>w#w-d1t286-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t286-12">
   <w.rf>
    <LM>w#w-d1t286-12</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m015-d-m-d1e281-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e281-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e281-x3">
  <m id="m015-d1t288-1">
   <w.rf>
    <LM>w#w-d1t288-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t288-2">
   <w.rf>
    <LM>w#w-d1t288-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t288-3">
   <w.rf>
    <LM>w#w-d1t288-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m015-d-m-d1e281-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e281-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e289-x2">
  <m id="m015-d1t292-1">
   <w.rf>
    <LM>w#w-d1t292-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t292-2">
   <w.rf>
    <LM>w#w-d1t292-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1e289-x2-246">
   <w.rf>
    <LM>w#w-d1e289-x2-246</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t292-3">
   <w.rf>
    <LM>w#w-d1t292-3</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1e289-x2-244">
   <w.rf>
    <LM>w#w-d1e289-x2-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-245">
  <m id="m015-d1t294-1">
   <w.rf>
    <LM>w#w-d1t294-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t294-2">
   <w.rf>
    <LM>w#w-d1t294-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t294-3">
   <w.rf>
    <LM>w#w-d1t294-3</LM>
   </w.rf>
   <form>přinesla</form>
   <lemma>přinést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m015-d1t294-5">
   <w.rf>
    <LM>w#w-d1t294-5</LM>
   </w.rf>
   <form>sešity</form>
   <lemma>sešit</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m015-d1t294-8">
   <w.rf>
    <LM>w#w-d1t294-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t294-12">
   <w.rf>
    <LM>w#w-d1t294-12</LM>
   </w.rf>
   <form>čtení</form>
   <lemma>čtení_^(*4íst)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m015-245-22">
   <w.rf>
    <LM>w#w-245-22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-245-23">
   <w.rf>
    <LM>w#w-245-23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-245-24">
   <w.rf>
    <LM>w#w-245-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-250">
  <m id="m015-d1t294-14">
   <w.rf>
    <LM>w#w-d1t294-14</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t294-15">
   <w.rf>
    <LM>w#w-d1t294-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t294-17">
   <w.rf>
    <LM>w#w-d1t294-17</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m015-d1t294-18">
   <w.rf>
    <LM>w#w-d1t294-18</LM>
   </w.rf>
   <form>četlo</form>
   <lemma>číst</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t294-19">
   <w.rf>
    <LM>w#w-d1t294-19</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t296-1">
   <w.rf>
    <LM>w#w-d1t296-1</LM>
   </w.rf>
   <form>lístečků</form>
   <lemma>lísteček</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m015-d-id69198-punct">
   <w.rf>
    <LM>w#w-d-id69198-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t298-1">
   <w.rf>
    <LM>w#w-d1t298-1</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t298-2">
   <w.rf>
    <LM>w#w-d1t298-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t298-3">
   <w.rf>
    <LM>w#w-d1t298-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t298-4">
   <w.rf>
    <LM>w#w-d1t298-4</LM>
   </w.rf>
   <form>učí</form>
   <lemma>učit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t298-5">
   <w.rf>
    <LM>w#w-d1t298-5</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d-id69280-punct">
   <w.rf>
    <LM>w#w-d-id69280-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t298-7">
   <w.rf>
    <LM>w#w-d1t298-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t298-8">
   <w.rf>
    <LM>w#w-d1t298-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t298-10">
   <w.rf>
    <LM>w#w-d1t298-10</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t298-9">
   <w.rf>
    <LM>w#w-d1t298-9</LM>
   </w.rf>
   <form>učí</form>
   <lemma>učit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t298-11">
   <w.rf>
    <LM>w#w-d1t298-11</LM>
   </w.rf>
   <form>abeceda</form>
   <lemma>abeceda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-250-251">
   <w.rf>
    <LM>w#w-250-251</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-252">
  <m id="m015-d1t298-14">
   <w.rf>
    <LM>w#w-d1t298-14</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m015-d1t298-15">
   <w.rf>
    <LM>w#w-d1t298-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t298-16">
   <w.rf>
    <LM>w#w-d1t298-16</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t298-18">
   <w.rf>
    <LM>w#w-d1t298-18</LM>
   </w.rf>
   <form>slovíčka</form>
   <lemma>slovíčko</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m015-d1t298-17">
   <w.rf>
    <LM>w#w-d1t298-17</LM>
   </w.rf>
   <form>napsaná</form>
   <lemma>napsaný_^(*2t)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m015-d1t300-1">
   <w.rf>
    <LM>w#w-d1t300-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t300-2">
   <w.rf>
    <LM>w#w-d1t300-2</LM>
   </w.rf>
   <form>lístečcích</form>
   <lemma>lísteček</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m015-d1t300-3">
   <w.rf>
    <LM>w#w-d1t300-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t300-4">
   <w.rf>
    <LM>w#w-d1t300-4</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t300-5">
   <w.rf>
    <LM>w#w-d1t300-5</LM>
   </w.rf>
   <form>učitelka</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t300-6">
   <w.rf>
    <LM>w#w-d1t300-6</LM>
   </w.rf>
   <form>zvedla</form>
   <lemma>zvednout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m015-d1t300-7">
   <w.rf>
    <LM>w#w-d1t300-7</LM>
   </w.rf>
   <form>slovíčko</form>
   <lemma>slovíčko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m015-d1t300-8">
   <w.rf>
    <LM>w#w-d1t300-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t300-9">
   <w.rf>
    <LM>w#w-d1t300-9</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m015-d1t300-10">
   <w.rf>
    <LM>w#w-d1t300-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t300-11">
   <w.rf>
    <LM>w#w-d1t300-11</LM>
   </w.rf>
   <form>rovnou</form>
   <lemma>rovnou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t300-12">
   <w.rf>
    <LM>w#w-d1t300-12</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t300-13">
   <w.rf>
    <LM>w#w-d1t300-13</LM>
   </w.rf>
   <form>kohout</form>
   <lemma>kohout-1_^(pták)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m015-d1t300-15">
   <w.rf>
    <LM>w#w-d1t300-15</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t306-1">
   <w.rf>
    <LM>w#w-d1t306-1</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d-m-d1e289-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e289-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e311-x2">
  <m id="m015-d1t316-9">
   <w.rf>
    <LM>w#w-d1t316-9</LM>
   </w.rf>
   <form>Zapadla</form>
   <lemma>zapadnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m015-d1t316-8">
   <w.rf>
    <LM>w#w-d1t316-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t316-7">
   <w.rf>
    <LM>w#w-d1t316-7</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t316-10">
   <w.rf>
    <LM>w#w-d1t316-10</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d-id70050-punct">
   <w.rf>
    <LM>w#w-d-id70050-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t316-13">
   <w.rf>
    <LM>w#w-d1t316-13</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t316-14">
   <w.rf>
    <LM>w#w-d1t316-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t316-15">
   <w.rf>
    <LM>w#w-d1t316-15</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t316-16">
   <w.rf>
    <LM>w#w-d1t316-16</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t316-17">
   <w.rf>
    <LM>w#w-d1t316-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t316-19">
   <w.rf>
    <LM>w#w-d1t316-19</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m015-d-m-d1e311-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e311-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e317-x2">
  <m id="m015-d1t322-1">
   <w.rf>
    <LM>w#w-d1t322-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t322-2">
   <w.rf>
    <LM>w#w-d1t322-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m015-d1t322-3">
   <w.rf>
    <LM>w#w-d1t322-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t322-4">
   <w.rf>
    <LM>w#w-d1t322-4</LM>
   </w.rf>
   <form>přestěhovala</form>
   <lemma>přestěhovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m015-d-id70283-punct">
   <w.rf>
    <LM>w#w-d-id70283-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e317-x4">
  <m id="m015-d1t328-1">
   <w.rf>
    <LM>w#w-d1t328-1</LM>
   </w.rf>
   <form>Přistěhovali</form>
   <lemma>přistěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t324-4">
   <w.rf>
    <LM>w#w-d1t324-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t324-5">
   <w.rf>
    <LM>w#w-d1t324-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t328-2">
   <w.rf>
    <LM>w#w-d1t328-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t330-2">
   <w.rf>
    <LM>w#w-d1t330-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m015-d1t330-4">
   <w.rf>
    <LM>w#w-d1t330-4</LM>
   </w.rf>
   <form>1937</form>
   <lemma>1937</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m015-d-m-d1e317-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e317-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e331-x2">
  <m id="m015-d1t336-1">
   <w.rf>
    <LM>w#w-d1t336-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t344-2">
   <w.rf>
    <LM>w#w-d1t344-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m015-d1t344-3">
   <w.rf>
    <LM>w#w-d1t344-3</LM>
   </w.rf>
   <form>zabrali</form>
   <lemma>zabrat_^([zabavit]_něco_někomu)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t344-5">
   <w.rf>
    <LM>w#w-d1t344-5</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d-m-d1e331-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e331-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e341-x2">
  <m id="m015-d1t344-9">
   <w.rf>
    <LM>w#w-d1t344-9</LM>
   </w.rf>
   <form>Než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t344-10">
   <w.rf>
    <LM>w#w-d1t344-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m015-d1t344-13">
   <w.rf>
    <LM>w#w-d1t344-13</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d1t344-15">
   <w.rf>
    <LM>w#w-d1t344-15</LM>
   </w.rf>
   <form>zabrali</form>
   <lemma>zabrat_^([zabavit]_něco_někomu)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d-id70853-punct">
   <w.rf>
    <LM>w#w-d-id70853-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t344-20">
   <w.rf>
    <LM>w#w-d1t344-20</LM>
   </w.rf>
   <form>odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1e341-x2-76">
   <w.rf>
    <LM>w#w-d1e341-x2-76</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t344-19">
   <w.rf>
    <LM>w#w-d1t344-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1e341-x2-55">
   <w.rf>
    <LM>w#w-d1e341-x2-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-56">
  <m id="m015-d1t344-23">
   <w.rf>
    <LM>w#w-d1t344-23</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m015-d1t344-24">
   <w.rf>
    <LM>w#w-d1t344-24</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m015-d1t344-25">
   <w.rf>
    <LM>w#w-d1t344-25</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t344-27">
   <w.rf>
    <LM>w#w-d1t344-27</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m015-d1t344-31">
   <w.rf>
    <LM>w#w-d1t344-31</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t344-32">
   <w.rf>
    <LM>w#w-d1t344-32</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t344-33">
   <w.rf>
    <LM>w#w-d1t344-33</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t344-34">
   <w.rf>
    <LM>w#w-d1t344-34</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m015-d1t344-36">
   <w.rf>
    <LM>w#w-d1t344-36</LM>
   </w.rf>
   <form>příbuzné</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m015-d1t344-37">
   <w.rf>
    <LM>w#w-d1t344-37</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t344-38">
   <w.rf>
    <LM>w#w-d1t344-38</LM>
   </w.rf>
   <form>tatínkovy</form>
   <lemma>tatínkův_^(*3ek)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m015-d1t344-39">
   <w.rf>
    <LM>w#w-d1t344-39</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t344-40">
   <w.rf>
    <LM>w#w-d1t344-40</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t344-42">
   <w.rf>
    <LM>w#w-d1t344-42</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m015-d1e341-x2-274">
   <w.rf>
    <LM>w#w-d1e341-x2-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-275">
  <m id="m015-d1t344-49">
   <w.rf>
    <LM>w#w-d1t344-49</LM>
   </w.rf>
   <form>Našli</form>
   <lemma>najít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t344-47">
   <w.rf>
    <LM>w#w-d1t344-47</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m015-d1t344-48">
   <w.rf>
    <LM>w#w-d1t344-48</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t344-50">
   <w.rf>
    <LM>w#w-d1t344-50</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m015-d1t344-51">
   <w.rf>
    <LM>w#w-d1t344-51</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t344-52">
   <w.rf>
    <LM>w#w-d1t344-52</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t344-53">
   <w.rf>
    <LM>w#w-d1t344-53</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t344-54">
   <w.rf>
    <LM>w#w-d1t344-54</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t344-55">
   <w.rf>
    <LM>w#w-d1t344-55</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t344-57">
   <w.rf>
    <LM>w#w-d1t344-57</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m015-275-276">
   <w.rf>
    <LM>w#w-275-276</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-277">
  <m id="m015-d1t344-64">
   <w.rf>
    <LM>w#w-d1t344-64</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t344-66">
   <w.rf>
    <LM>w#w-d1t344-66</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m015-d1t344-61">
   <w.rf>
    <LM>w#w-d1t344-61</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t344-62">
   <w.rf>
    <LM>w#w-d1t344-62</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t344-63">
   <w.rf>
    <LM>w#w-d1t344-63</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d-id71510-punct">
   <w.rf>
    <LM>w#w-d-id71510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t344-69">
   <w.rf>
    <LM>w#w-d1t344-69</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t344-70">
   <w.rf>
    <LM>w#w-d1t344-70</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m015-d1t344-71">
   <w.rf>
    <LM>w#w-d1t344-71</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t354-2">
   <w.rf>
    <LM>w#w-d1t354-2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t354-4">
   <w.rf>
    <LM>w#w-d1t354-4</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d-m-d1e341-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e341-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e345-x3">
  <m id="m015-d1t359-7">
   <w.rf>
    <LM>w#w-d1t359-7</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t359-5">
   <w.rf>
    <LM>w#w-d1t359-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m015-d1t359-6">
   <w.rf>
    <LM>w#w-d1t359-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t359-8">
   <w.rf>
    <LM>w#w-d1t359-8</LM>
   </w.rf>
   <form>přestěhovat</form>
   <lemma>přestěhovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m015-d1t359-1">
   <w.rf>
    <LM>w#w-d1t359-1</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m015-d1t359-3">
   <w.rf>
    <LM>w#w-d1t359-3</LM>
   </w.rf>
   <form>Němcům</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m015-d-id71823-punct">
   <w.rf>
    <LM>w#w-d-id71823-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e345-x5">
  <m id="m015-d1t366-3">
   <w.rf>
    <LM>w#w-d1t366-3</LM>
   </w.rf>
   <form>Zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t366-2">
   <w.rf>
    <LM>w#w-d1t366-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t366-4">
   <w.rf>
    <LM>w#w-d1t366-4</LM>
   </w.rf>
   <form>nemuseli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m015-d-id72072-punct">
   <w.rf>
    <LM>w#w-d-id72072-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t366-6">
   <w.rf>
    <LM>w#w-d1t366-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t370-11">
   <w.rf>
    <LM>w#w-d1t370-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m015-d1t370-15">
   <w.rf>
    <LM>w#w-d1t370-15</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d1t370-12">
   <w.rf>
    <LM>w#w-d1t370-12</LM>
   </w.rf>
   <form>zabrali</form>
   <lemma>zabrat_^([zabavit]_něco_někomu)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t370-5">
   <w.rf>
    <LM>w#w-d1t370-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1e363-x2-80">
   <w.rf>
    <LM>w#w-d1e363-x2-80</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m015-d1t370-7">
   <w.rf>
    <LM>w#w-d1t370-7</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m015-d-id72358-punct">
   <w.rf>
    <LM>w#w-d-id72358-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t372-1">
   <w.rf>
    <LM>w#w-d1t372-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t372-5">
   <w.rf>
    <LM>w#w-d1t372-5</LM>
   </w.rf>
   <form>poměry</form>
   <lemma>poměry_^(stav,_uspořádání_věcí)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m015-d1t372-6">
   <w.rf>
    <LM>w#w-d1t372-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t372-7">
   <w.rf>
    <LM>w#w-d1t372-7</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m015-d1t372-8">
   <w.rf>
    <LM>w#w-d1t372-8</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m015-d1e363-x2-81">
   <w.rf>
    <LM>w#w-d1e363-x2-81</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-82">
  <m id="m015-d1t372-10">
   <w.rf>
    <LM>w#w-d1t372-10</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t372-11">
   <w.rf>
    <LM>w#w-d1t372-11</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t372-12">
   <w.rf>
    <LM>w#w-d1t372-12</LM>
   </w.rf>
   <form>souseda</form>
   <lemma>soused</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m015-82-68">
   <w.rf>
    <LM>w#w-82-68</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t372-13">
   <w.rf>
    <LM>w#w-d1t372-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d-id72556-punct">
   <w.rf>
    <LM>w#w-d-id72556-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t372-15">
   <w.rf>
    <LM>w#w-d1t372-15</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m015-d1t372-16">
   <w.rf>
    <LM>w#w-d1t372-16</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t372-19">
   <w.rf>
    <LM>w#w-d1t372-19</LM>
   </w.rf>
   <form>Češi</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d-id72644-punct">
   <w.rf>
    <LM>w#w-d-id72644-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t372-26">
   <w.rf>
    <LM>w#w-d1t372-26</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t372-24">
   <w.rf>
    <LM>w#w-d1t372-24</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t372-25">
   <w.rf>
    <LM>w#w-d1t372-25</LM>
   </w.rf>
   <form>rána</form>
   <lemma>ráno-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m015-d1t372-27">
   <w.rf>
    <LM>w#w-d1t372-27</LM>
   </w.rf>
   <form>vytlučená</form>
   <lemma>vytlučený_^(*5ouci)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m015-d1t372-28">
   <w.rf>
    <LM>w#w-d1t372-28</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m015-82-132">
   <w.rf>
    <LM>w#w-82-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-133">
  <m id="m015-d1t372-31">
   <w.rf>
    <LM>w#w-d1t372-31</LM>
   </w.rf>
   <form>Házeli</form>
   <lemma>házet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t372-32">
   <w.rf>
    <LM>w#w-d1t372-32</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t372-33">
   <w.rf>
    <LM>w#w-d1t372-33</LM>
   </w.rf>
   <form>kamení</form>
   <lemma>kamení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m015-82-69">
   <w.rf>
    <LM>w#w-82-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-70">
  <m id="m015-d1t372-40">
   <w.rf>
    <LM>w#w-d1t372-40</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t377-3">
   <w.rf>
    <LM>w#w-d1t377-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t377-2">
   <w.rf>
    <LM>w#w-d1t377-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t377-4">
   <w.rf>
    <LM>w#w-d1t377-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t377-5">
   <w.rf>
    <LM>w#w-d1t377-5</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m015-d-id73009-punct">
   <w.rf>
    <LM>w#w-d-id73009-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t377-8">
   <w.rf>
    <LM>w#w-d1t377-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t377-9">
   <w.rf>
    <LM>w#w-d1t377-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t377-10">
   <w.rf>
    <LM>w#w-d1t377-10</LM>
   </w.rf>
   <form>nečekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m015-70-90">
   <w.rf>
    <LM>w#w-70-90</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t377-11">
   <w.rf>
    <LM>w#w-d1t377-11</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t377-12">
   <w.rf>
    <LM>w#w-d1t377-12</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m015-d1t377-13">
   <w.rf>
    <LM>w#w-d1t377-13</LM>
   </w.rf>
   <form>nejhůř</form>
   <lemma>hůře</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m015-70-91">
   <w.rf>
    <LM>w#w-70-91</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-70-92">
   <w.rf>
    <LM>w#w-70-92</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t383-1">
   <w.rf>
    <LM>w#w-d1t383-1</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t383-2">
   <w.rf>
    <LM>w#w-d1t383-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t383-3">
   <w.rf>
    <LM>w#w-d1t383-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t383-4">
   <w.rf>
    <LM>w#w-d1t383-4</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m015-d-m-d1e378-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e378-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e388-x2">
  <m id="m015-d1t391-6">
   <w.rf>
    <LM>w#w-d1t391-6</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t391-8">
   <w.rf>
    <LM>w#w-d1t391-8</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m015-d-id73454-punct">
   <w.rf>
    <LM>w#w-d-id73454-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t391-16">
   <w.rf>
    <LM>w#w-d1t391-16</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m015-d1t391-17">
   <w.rf>
    <LM>w#w-d1t391-17</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t391-18">
   <w.rf>
    <LM>w#w-d1t391-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t391-19">
   <w.rf>
    <LM>w#w-d1t391-19</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t391-20">
   <w.rf>
    <LM>w#w-d1t391-20</LM>
   </w.rf>
   <form>nechodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m015-d1e388-x2-99">
   <w.rf>
    <LM>w#w-d1e388-x2-99</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t391-10">
   <w.rf>
    <LM>w#w-d1t391-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t391-11">
   <w.rf>
    <LM>w#w-d1t391-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t391-12">
   <w.rf>
    <LM>w#w-d1t391-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t391-13">
   <w.rf>
    <LM>w#w-d1t391-13</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m015-d1t391-14">
   <w.rf>
    <LM>w#w-d1t391-14</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m015-d-id73521-punct">
   <w.rf>
    <LM>w#w-d-id73521-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t391-22">
   <w.rf>
    <LM>w#w-d1t391-22</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t391-23">
   <w.rf>
    <LM>w#w-d1t391-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t391-24">
   <w.rf>
    <LM>w#w-d1t391-24</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t391-25">
   <w.rf>
    <LM>w#w-d1t391-25</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1e388-x2-100">
   <w.rf>
    <LM>w#w-d1e388-x2-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-101">
  <m id="m015-d1t393-2">
   <w.rf>
    <LM>w#w-d1t393-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m015-d1t393-1">
   <w.rf>
    <LM>w#w-d1t393-1</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m015-d1t393-3">
   <w.rf>
    <LM>w#w-d1t393-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m015-d1t393-4">
   <w.rf>
    <LM>w#w-d1t393-4</LM>
   </w.rf>
   <form>strojvůdce</form>
   <lemma>strojvůdce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m015-d-id73759-punct">
   <w.rf>
    <LM>w#w-d-id73759-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t393-6">
   <w.rf>
    <LM>w#w-d1t393-6</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t399-7">
   <w.rf>
    <LM>w#w-d1t399-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t399-9">
   <w.rf>
    <LM>w#w-d1t399-9</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m015-d1t399-1">
   <w.rf>
    <LM>w#w-d1t399-1</LM>
   </w.rf>
   <form>snadno</form>
   <lemma>snadno</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t399-2">
   <w.rf>
    <LM>w#w-d1t399-2</LM>
   </w.rf>
   <form>našel</form>
   <lemma>najít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m015-d1t399-3">
   <w.rf>
    <LM>w#w-d1t399-3</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m015-d-m-d1e388-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e388-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e404-x2">
  <m id="m015-d1t407-3">
   <w.rf>
    <LM>w#w-d1t407-3</LM>
   </w.rf>
   <form>Přeložili</form>
   <lemma>přeložit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t407-1">
   <w.rf>
    <LM>w#w-d1t407-1</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m015-d1t407-4">
   <w.rf>
    <LM>w#w-d1t407-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t407-6">
   <w.rf>
    <LM>w#w-d1t407-6</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t407-9">
   <w.rf>
    <LM>w#w-d1t407-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t407-10">
   <w.rf>
    <LM>w#w-d1t407-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t407-11">
   <w.rf>
    <LM>w#w-d1t407-11</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m015-d1t407-12">
   <w.rf>
    <LM>w#w-d1t407-12</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t407-13">
   <w.rf>
    <LM>w#w-d1t407-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t407-14">
   <w.rf>
    <LM>w#w-d1t407-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t407-16">
   <w.rf>
    <LM>w#w-d1t407-16</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m015-d-id74271-punct">
   <w.rf>
    <LM>w#w-d-id74271-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t407-19">
   <w.rf>
    <LM>w#w-d1t407-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t407-20">
   <w.rf>
    <LM>w#w-d1t407-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t407-21">
   <w.rf>
    <LM>w#w-d1t407-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m015-d1t407-22">
   <w.rf>
    <LM>w#w-d1t407-22</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m015-d-m-d1e404-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e404-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e408-x2">
  <m id="m015-d1t411-1">
   <w.rf>
    <LM>w#w-d1t411-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d-m-d1e408-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e408-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e412-x2">
  <m id="m015-d1t417-1">
   <w.rf>
    <LM>w#w-d1t417-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t417-2">
   <w.rf>
    <LM>w#w-d1t417-2</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t417-3">
   <w.rf>
    <LM>w#w-d1t417-3</LM>
   </w.rf>
   <form>probíhalo</form>
   <lemma>probíhat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t417-4">
   <w.rf>
    <LM>w#w-d1t417-4</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t417-5">
   <w.rf>
    <LM>w#w-d1t417-5</LM>
   </w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d-id74537-punct">
   <w.rf>
    <LM>w#w-d-id74537-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e420-x2">
  <m id="m015-d1t425-2">
   <w.rf>
    <LM>w#w-d1t425-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t425-1">
   <w.rf>
    <LM>w#w-d1t425-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t425-3">
   <w.rf>
    <LM>w#w-d1t425-3</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t427-1">
   <w.rf>
    <LM>w#w-d1t427-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t427-2">
   <w.rf>
    <LM>w#w-d1t427-2</LM>
   </w.rf>
   <form>sokolovna</form>
   <lemma>sokolovna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t427-3">
   <w.rf>
    <LM>w#w-d1t427-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t427-4">
   <w.rf>
    <LM>w#w-d1t427-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t427-5">
   <w.rf>
    <LM>w#w-d1t427-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m015-d1t427-6">
   <w.rf>
    <LM>w#w-d1t427-6</LM>
   </w.rf>
   <form>sokolovny</form>
   <lemma>sokolovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t427-7">
   <w.rf>
    <LM>w#w-d1t427-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t427-9">
   <w.rf>
    <LM>w#w-d1t427-9</LM>
   </w.rf>
   <form>hřiště</form>
   <lemma>hřiště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-103-378">
   <w.rf>
    <LM>w#w-103-378</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-379">
  <m id="m015-d1t429-6">
   <w.rf>
    <LM>w#w-d1t429-6</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t429-7">
   <w.rf>
    <LM>w#w-d1t429-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m015-d1t429-8">
   <w.rf>
    <LM>w#w-d1t429-8</LM>
   </w.rf>
   <form>sokolovny</form>
   <lemma>sokolovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t429-9">
   <w.rf>
    <LM>w#w-d1t429-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t429-10">
   <w.rf>
    <LM>w#w-d1t429-10</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t429-11">
   <w.rf>
    <LM>w#w-d1t429-11</LM>
   </w.rf>
   <form>cvičit</form>
   <lemma>cvičit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m015-103-104">
   <w.rf>
    <LM>w#w-103-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-105">
  <m id="m015-d1t429-14">
   <w.rf>
    <LM>w#w-d1t429-14</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t429-13">
   <w.rf>
    <LM>w#w-d1t429-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t429-17">
   <w.rf>
    <LM>w#w-d1t429-17</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t429-15">
   <w.rf>
    <LM>w#w-d1t429-15</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t429-16">
   <w.rf>
    <LM>w#w-d1t429-16</LM>
   </w.rf>
   <form>jeviště</form>
   <lemma>jeviště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d-id75213-punct">
   <w.rf>
    <LM>w#w-d-id75213-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t429-19">
   <w.rf>
    <LM>w#w-d1t429-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t429-20">
   <w.rf>
    <LM>w#w-d1t429-20</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m015-d1t429-21">
   <w.rf>
    <LM>w#w-d1t429-21</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t429-22">
   <w.rf>
    <LM>w#w-d1t429-22</LM>
   </w.rf>
   <form>různá</form>
   <lemma>různý</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m015-d1t429-24">
   <w.rf>
    <LM>w#w-d1t429-24</LM>
   </w.rf>
   <form>vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m015-d1t429-25">
   <w.rf>
    <LM>w#w-d1t429-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t429-30">
   <w.rf>
    <LM>w#w-d1t429-30</LM>
   </w.rf>
   <form>hrálo</form>
   <lemma>hrát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t429-28">
   <w.rf>
    <LM>w#w-d1t429-28</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t429-29">
   <w.rf>
    <LM>w#w-d1t429-29</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t429-27">
   <w.rf>
    <LM>w#w-d1t429-27</LM>
   </w.rf>
   <form>divadlo</form>
   <lemma>divadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-105-370">
   <w.rf>
    <LM>w#w-105-370</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-106">
  <m id="m015-d1t434-2">
   <w.rf>
    <LM>w#w-d1t434-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t434-3">
   <w.rf>
    <LM>w#w-d1t434-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m015-d1t434-4">
   <w.rf>
    <LM>w#w-d1t434-4</LM>
   </w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m015-d1t434-5">
   <w.rf>
    <LM>w#w-d1t434-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t434-6">
   <w.rf>
    <LM>w#w-d1t434-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t434-7">
   <w.rf>
    <LM>w#w-d1t434-7</LM>
   </w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d-id75535-punct">
   <w.rf>
    <LM>w#w-d-id75535-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t434-9">
   <w.rf>
    <LM>w#w-d1t434-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t434-10">
   <w.rf>
    <LM>w#w-d1t434-10</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m015-d1t434-11">
   <w.rf>
    <LM>w#w-d1t434-11</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m015-d1t434-12">
   <w.rf>
    <LM>w#w-d1t434-12</LM>
   </w.rf>
   <form>cvičením</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m015-d1t434-14">
   <w.rf>
    <LM>w#w-d1t434-14</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m015-d1t434-17">
   <w.rf>
    <LM>w#w-d1t434-17</LM>
   </w.rf>
   <form>průvod</form>
   <lemma>průvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m015-106-109">
   <w.rf>
    <LM>w#w-106-109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-107">
  <m id="m015-d1t434-18">
   <w.rf>
    <LM>w#w-d1t434-18</LM>
   </w.rf>
   <form>Přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m015-d1t434-19">
   <w.rf>
    <LM>w#w-d1t434-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t434-20">
   <w.rf>
    <LM>w#w-d1t434-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m015-d1t434-22">
   <w.rf>
    <LM>w#w-d1t434-22</LM>
   </w.rf>
   <form>hřiště</form>
   <lemma>hřiště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m015-107-387">
   <w.rf>
    <LM>w#w-107-387</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t442-2">
   <w.rf>
    <LM>w#w-d1t442-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t442-1">
   <w.rf>
    <LM>w#w-d1t442-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t442-3">
   <w.rf>
    <LM>w#w-d1t442-3</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m015-d1t442-6">
   <w.rf>
    <LM>w#w-d1t442-6</LM>
   </w.rf>
   <form>Čechů</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m015-d-id75932-punct">
   <w.rf>
    <LM>w#w-d-id75932-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t450-7">
   <w.rf>
    <LM>w#w-d1t450-7</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m015-d1t450-6">
   <w.rf>
    <LM>w#w-d1t450-6</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d1t450-9">
   <w.rf>
    <LM>w#w-d1t450-9</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m015-d-id76058-punct">
   <w.rf>
    <LM>w#w-d-id76058-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t450-1">
   <w.rf>
    <LM>w#w-d1t450-1</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m015-d1t450-2">
   <w.rf>
    <LM>w#w-d1t450-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t450-3">
   <w.rf>
    <LM>w#w-d1t450-3</LM>
   </w.rf>
   <form>dívali</form>
   <lemma>dívat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d-m-d1e435-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e435-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e447-x2">
  <m id="m015-d1t452-6">
   <w.rf>
    <LM>w#w-d1t452-6</LM>
   </w.rf>
   <form>Odcvičili</form>
   <lemma>odcvičit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m015-d1t452-4">
   <w.rf>
    <LM>w#w-d1t452-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t452-5">
   <w.rf>
    <LM>w#w-d1t452-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m015-d1t452-7">
   <w.rf>
    <LM>w#w-d1t452-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t452-8">
   <w.rf>
    <LM>w#w-d1t452-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t452-9">
   <w.rf>
    <LM>w#w-d1t452-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t452-11">
   <w.rf>
    <LM>w#w-d1t452-11</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m015-d1t452-12">
   <w.rf>
    <LM>w#w-d1t452-12</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-2</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m015-d1e447-x2-118">
   <w.rf>
    <LM>w#w-d1e447-x2-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-120">
  <m id="m015-d1t452-19">
   <w.rf>
    <LM>w#w-d1t452-19</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m015-d1t452-17">
   <w.rf>
    <LM>w#w-d1t452-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t452-18">
   <w.rf>
    <LM>w#w-d1t452-18</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t452-20">
   <w.rf>
    <LM>w#w-d1t452-20</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m015-d-id76438-punct">
   <w.rf>
    <LM>w#w-d-id76438-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t452-22">
   <w.rf>
    <LM>w#w-d1t452-22</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t452-23">
   <w.rf>
    <LM>w#w-d1t452-23</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t452-24">
   <w.rf>
    <LM>w#w-d1t452-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t452-25">
   <w.rf>
    <LM>w#w-d1t452-25</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t452-27">
   <w.rf>
    <LM>w#w-d1t452-27</LM>
   </w.rf>
   <form>dechovka</form>
   <lemma>dechovka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d-id76539-punct">
   <w.rf>
    <LM>w#w-d-id76539-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t452-29">
   <w.rf>
    <LM>w#w-d1t452-29</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m015-d1t452-30">
   <w.rf>
    <LM>w#w-d1t452-30</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m015-d1t452-31">
   <w.rf>
    <LM>w#w-d1t452-31</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m015-d1t452-32">
   <w.rf>
    <LM>w#w-d1t452-32</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-120-186">
   <w.rf>
    <LM>w#w-120-186</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-189">
  <m id="m015-d1t452-34">
   <w.rf>
    <LM>w#w-d1t452-34</LM>
   </w.rf>
   <form>Hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t452-35">
   <w.rf>
    <LM>w#w-d1t452-35</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m015-d1t452-36">
   <w.rf>
    <LM>w#w-d1t452-36</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t452-37">
   <w.rf>
    <LM>w#w-d1t452-37</LM>
   </w.rf>
   <form>pochodu</form>
   <lemma>pochod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m015-122-125">
   <w.rf>
    <LM>w#w-122-125</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-122">
  <m id="m015-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>Zpívali</form>
   <lemma>zpívat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t454-4">
   <w.rf>
    <LM>w#w-d1t454-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m015-d1t454-7">
   <w.rf>
    <LM>w#w-d1t454-7</LM>
   </w.rf>
   <form>sokolské</form>
   <lemma>sokolský</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m015-d1t454-8">
   <w.rf>
    <LM>w#w-d1t454-8</LM>
   </w.rf>
   <form>písně</form>
   <lemma>píseň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m015-d-id76780-punct">
   <w.rf>
    <LM>w#w-d-id76780-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t454-10">
   <w.rf>
    <LM>w#w-d1t454-10</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m015-d1t454-11">
   <w.rf>
    <LM>w#w-d1t454-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t454-14">
   <w.rf>
    <LM>w#w-d1t454-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m015-d1t454-12">
   <w.rf>
    <LM>w#w-d1t454-12</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t454-13">
   <w.rf>
    <LM>w#w-d1t454-13</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1t454-15">
   <w.rf>
    <LM>w#w-d1t454-15</LM>
   </w.rf>
   <form>nezpívají</form>
   <lemma>zpívat</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m015-122-126">
   <w.rf>
    <LM>w#w-122-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-124">
  <m id="m015-d1t454-17">
   <w.rf>
    <LM>w#w-d1t454-17</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t454-18">
   <w.rf>
    <LM>w#w-d1t454-18</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m015-d1t454-19">
   <w.rf>
    <LM>w#w-d1t454-19</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m015-d1t454-20">
   <w.rf>
    <LM>w#w-d1t454-20</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t454-21">
   <w.rf>
    <LM>w#w-d1t454-21</LM>
   </w.rf>
   <form>nevzpomněla</form>
   <lemma>vzpomenout</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m015-d1t454-22">
   <w.rf>
    <LM>w#w-d1t454-22</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m015-d1t454-23">
   <w.rf>
    <LM>w#w-d1t454-23</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m015-d-m-d1e447-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e447-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e457-x3">
  <m id="m015-d1t466-1">
   <w.rf>
    <LM>w#w-d1t466-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m015-d1t466-2">
   <w.rf>
    <LM>w#w-d1t466-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t466-3">
   <w.rf>
    <LM>w#w-d1t466-3</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A---6</tag>
  </m>
  <m id="m015-d1e457-x3-127">
   <w.rf>
    <LM>w#w-d1e457-x3-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-31">
  <m id="m015-d1t471-1">
   <w.rf>
    <LM>w#w-d1t471-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t471-2">
   <w.rf>
    <LM>w#w-d1t471-2</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t471-3">
   <w.rf>
    <LM>w#w-d1t471-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m015-d1t471-4">
   <w.rf>
    <LM>w#w-d1t471-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m015-d1t471-5">
   <w.rf>
    <LM>w#w-d1t471-5</LM>
   </w.rf>
   <form>sokolské</form>
   <lemma>sokolský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m015-d1t471-6">
   <w.rf>
    <LM>w#w-d1t471-6</LM>
   </w.rf>
   <form>slety</form>
   <lemma>slet</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m015-d-id77215-punct">
   <w.rf>
    <LM>w#w-d-id77215-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e475-x2">
  <m id="m015-d1t473-1">
   <w.rf>
    <LM>w#w-d1t473-1</LM>
   </w.rf>
   <form>Kdepak</form>
   <lemma>kdepak-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m015-d1e475-x2-27">
   <w.rf>
    <LM>w#w-d1e475-x2-27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t480-1">
   <w.rf>
    <LM>w#w-d1t480-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t480-2">
   <w.rf>
    <LM>w#w-d1t480-2</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m015-d1t480-3">
   <w.rf>
    <LM>w#w-d1t480-3</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m015-d1t480-4">
   <w.rf>
    <LM>w#w-d1t480-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m015-d1e475-x2-28">
   <w.rf>
    <LM>w#w-d1e475-x2-28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-29">
  <m id="m015-d1t480-7">
   <w.rf>
    <LM>w#w-d1t480-7</LM>
   </w.rf>
   <form>Skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m015-d1t480-6">
   <w.rf>
    <LM>w#w-d1t480-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t480-9">
   <w.rf>
    <LM>w#w-d1t480-9</LM>
   </w.rf>
   <form>sletem</form>
   <lemma>slet</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m015-d1t482-1">
   <w.rf>
    <LM>w#w-d1t482-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t482-2">
   <w.rf>
    <LM>w#w-d1t482-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m015-d1t482-4">
   <w.rf>
    <LM>w#w-d1t482-4</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m015-29-203">
   <w.rf>
    <LM>w#w-29-203</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-204">
  <m id="m015-d1t482-5">
   <w.rf>
    <LM>w#w-d1t482-5</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1e475-x2-20">
   <w.rf>
    <LM>w#w-d1e475-x2-20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1e475-x2-21">
   <w.rf>
    <LM>w#w-d1e475-x2-21</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-29-202">
   <w.rf>
    <LM>w#w-29-202</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m015-d1t482-6">
   <w.rf>
    <LM>w#w-d1t482-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m015-d1t482-7">
   <w.rf>
    <LM>w#w-d1t482-7</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m015-d1t482-8">
   <w.rf>
    <LM>w#w-d1t482-8</LM>
   </w.rf>
   <form>slet</form>
   <lemma>slet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m015-d-id77655-punct">
   <w.rf>
    <LM>w#w-d-id77655-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t482-10">
   <w.rf>
    <LM>w#w-d1t482-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t482-13">
   <w.rf>
    <LM>w#w-d1t482-13</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m015-d1t482-17">
   <w.rf>
    <LM>w#w-d1t482-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m015-d1t482-12">
   <w.rf>
    <LM>w#w-d1t482-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t482-15">
   <w.rf>
    <LM>w#w-d1t482-15</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m015-d1t482-16">
   <w.rf>
    <LM>w#w-d1t482-16</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t482-18">
   <w.rf>
    <LM>w#w-d1t482-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m015-d1t482-19">
   <w.rf>
    <LM>w#w-d1t482-19</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m015-d1t482-20">
   <w.rf>
    <LM>w#w-d1t482-20</LM>
   </w.rf>
   <form>sletě</form>
   <lemma>slet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m015-d1t482-21">
   <w.rf>
    <LM>w#w-d1t482-21</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m015-d-m-d1e475-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e475-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-d1e495-x2">
  <m id="m015-d1t498-1">
   <w.rf>
    <LM>w#w-d1t498-1</LM>
   </w.rf>
   <form>Hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>sokolů</form>
   <lemma>sokol-1</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m015-d1t498-4">
   <w.rf>
    <LM>w#w-d1t498-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t498-5">
   <w.rf>
    <LM>w#w-d1t498-5</LM>
   </w.rf>
   <form>zavřená</form>
   <lemma>zavřený_^(*3ít)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m015-d-id78121-punct">
   <w.rf>
    <LM>w#w-d-id78121-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m015-d1t498-7">
   <w.rf>
    <LM>w#w-d1t498-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m015-d1t498-11">
   <w.rf>
    <LM>w#w-d1t498-11</LM>
   </w.rf>
   <form>sokolové</form>
   <lemma>sokol-1</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m015-d1t498-16">
   <w.rf>
    <LM>w#w-d1t498-16</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m015-d1t498-19">
   <w.rf>
    <LM>w#w-d1t498-19</LM>
   </w.rf>
   <form>Němcům</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m015-d1t498-22">
   <w.rf>
    <LM>w#w-d1t498-22</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t498-24">
   <w.rf>
    <LM>w#w-d1t498-24</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m015-d1t498-26">
   <w.rf>
    <LM>w#w-d1t498-26</LM>
   </w.rf>
   <form>buňky</form>
   <lemma>buňka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m015-d1t498-27">
   <w.rf>
    <LM>w#w-d1t498-27</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m015-d1t498-28">
   <w.rf>
    <LM>w#w-d1t498-28</LM>
   </w.rf>
   <form>dávali</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m015-d1t498-30">
   <w.rf>
    <LM>w#w-d1t498-30</LM>
   </w.rf>
   <form>letáky</form>
   <lemma>leták</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m015-d1e495-x2-222">
   <w.rf>
    <LM>w#w-d1e495-x2-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m015-223">
  <m id="m015-d1t500-4">
   <w.rf>
    <LM>w#w-d1t500-4</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m015-d1t500-5">
   <w.rf>
    <LM>w#w-d1t500-5</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m015-d1t500-7">
   <w.rf>
    <LM>w#w-d1t500-7</LM>
   </w.rf>
   <form>okresu</form>
   <lemma>okres</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m015-d1t498-36">
   <w.rf>
    <LM>w#w-d1t498-36</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m015-d1t498-37">
   <w.rf>
    <LM>w#w-d1t498-37</LM>
   </w.rf>
   <form>zavřená</form>
   <lemma>zavřený_^(*3ít)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m015-d1t498-33">
   <w.rf>
    <LM>w#w-d1t498-33</LM>
   </w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m015-d1t498-35">
   <w.rf>
    <LM>w#w-d1t498-35</LM>
   </w.rf>
   <form>sokolů</form>
   <lemma>sokol-1</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m015-d1e495-x2-14">
   <w.rf>
    <LM>w#w-d1e495-x2-14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
