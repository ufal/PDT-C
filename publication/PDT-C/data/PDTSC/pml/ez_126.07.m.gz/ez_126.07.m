<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_126.07.w.gz" />
  </references>
 </head>
 <s id="m126-d1e1281-x2">
  <m id="m126-d1t1284-4">
   <w.rf>
    <LM>w#w-d1t1284-4</LM>
   </w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m126-d1t1284-5">
   <w.rf>
    <LM>w#w-d1t1284-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1284-3">
   <w.rf>
    <LM>w#w-d1t1284-3</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1284-6">
   <w.rf>
    <LM>w#w-d1t1284-6</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m126-d1t1284-7">
   <w.rf>
    <LM>w#w-d1t1284-7</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m126-d1e1281-x2-69">
   <w.rf>
    <LM>w#w-d1e1281-x2-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-70">
  <m id="m126-d1t1284-9">
   <w.rf>
    <LM>w#w-d1t1284-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1284-11">
   <w.rf>
    <LM>w#w-d1t1284-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1284-12">
   <w.rf>
    <LM>w#w-d1t1284-12</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1284-13">
   <w.rf>
    <LM>w#w-d1t1284-13</LM>
   </w.rf>
   <form>samozřejmé</form>
   <lemma>samozřejmý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m126-70-1345">
   <w.rf>
    <LM>w#w-70-1345</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1346">
  <m id="m126-d1t1286-3">
   <w.rf>
    <LM>w#w-d1t1286-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1286-4">
   <w.rf>
    <LM>w#w-d1t1286-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1286-5">
   <w.rf>
    <LM>w#w-d1t1286-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1286-6">
   <w.rf>
    <LM>w#w-d1t1286-6</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d1t1286-7">
   <w.rf>
    <LM>w#w-d1t1286-7</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m126-d1t1286-8">
   <w.rf>
    <LM>w#w-d1t1286-8</LM>
   </w.rf>
   <form>parádu</form>
   <lemma>paráda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d1t1286-9">
   <w.rf>
    <LM>w#w-d1t1286-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1286-10">
   <w.rf>
    <LM>w#w-d1t1286-10</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m126-d-id121903-punct">
   <w.rf>
    <LM>w#w-d-id121903-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1286-12">
   <w.rf>
    <LM>w#w-d1t1286-12</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1288-1">
   <w.rf>
    <LM>w#w-d1t1288-1</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m126-d1t1288-2">
   <w.rf>
    <LM>w#w-d1t1288-2</LM>
   </w.rf>
   <form>bony</form>
   <lemma>bon</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m126-d-id121982-punct">
   <w.rf>
    <LM>w#w-d-id121982-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1288-6">
   <w.rf>
    <LM>w#w-d1t1288-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1288-7">
   <w.rf>
    <LM>w#w-d1t1288-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1288-8">
   <w.rf>
    <LM>w#w-d1t1288-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1288-9">
   <w.rf>
    <LM>w#w-d1t1288-9</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1288-10">
   <w.rf>
    <LM>w#w-d1t1288-10</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m126-d1t1288-11">
   <w.rf>
    <LM>w#w-d1t1288-11</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m126-d1t1288-12">
   <w.rf>
    <LM>w#w-d1t1288-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1288-13">
   <w.rf>
    <LM>w#w-d1t1288-13</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m126-70-96">
   <w.rf>
    <LM>w#w-70-96</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1288-14">
   <w.rf>
    <LM>w#w-d1t1288-14</LM>
   </w.rf>
   <form>Túzu</form>
   <lemma>Túzo_;m_,h_^(Tuzex)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m126-70-97">
   <w.rf>
    <LM>w#w-70-97</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d-m-d1e1281-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1281-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1295-x2">
  <m id="m126-d1t1298-1">
   <w.rf>
    <LM>w#w-d1t1298-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1298-2">
   <w.rf>
    <LM>w#w-d1t1298-2</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m126-d1t1298-3">
   <w.rf>
    <LM>w#w-d1t1298-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m126-d1t1298-4">
   <w.rf>
    <LM>w#w-d1t1298-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m126-d1t1298-5">
   <w.rf>
    <LM>w#w-d1t1298-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m126-d1t1298-6">
   <w.rf>
    <LM>w#w-d1t1298-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m126-d-m-d1e1295-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1295-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1299-x2">
  <m id="m126-d1t1302-1">
   <w.rf>
    <LM>w#w-d1t1302-1</LM>
   </w.rf>
   <form>Koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d1t1302-2">
   <w.rf>
    <LM>w#w-d1t1302-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1302-3">
   <w.rf>
    <LM>w#w-d1t1302-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1302-4">
   <w.rf>
    <LM>w#w-d1t1302-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1302-5">
   <w.rf>
    <LM>w#w-d1t1302-5</LM>
   </w.rf>
   <form>džíny</form>
   <lemma>džíny-2</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m126-d-id122431-punct">
   <w.rf>
    <LM>w#w-d-id122431-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1303-x2">
  <m id="m126-d1t1306-1">
   <w.rf>
    <LM>w#w-d1t1306-1</LM>
   </w.rf>
   <form>Koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d-id122508-punct">
   <w.rf>
    <LM>w#w-d-id122508-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1306-3">
   <w.rf>
    <LM>w#w-d1t1306-3</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1e1303-x2-86">
   <w.rf>
    <LM>w#w-d1e1303-x2-86</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-88">
  <m id="m126-d1t1306-8">
   <w.rf>
    <LM>w#w-d1t1306-8</LM>
   </w.rf>
   <form>Dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m126-d1t1306-9">
   <w.rf>
    <LM>w#w-d1t1306-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1306-10">
   <w.rf>
    <LM>w#w-d1t1306-10</LM>
   </w.rf>
   <form>neříkalo</form>
   <lemma>říkat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m126-d1t1306-11">
   <w.rf>
    <LM>w#w-d1t1306-11</LM>
   </w.rf>
   <form>džíny</form>
   <lemma>džíny-1</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d-id122642-punct">
   <w.rf>
    <LM>w#w-d-id122642-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1308-1">
   <w.rf>
    <LM>w#w-d1t1308-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1308-2">
   <w.rf>
    <LM>w#w-d1t1308-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1308-3">
   <w.rf>
    <LM>w#w-d1t1308-3</LM>
   </w.rf>
   <form>rifle</form>
   <lemma>rifle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-88-89">
   <w.rf>
    <LM>w#w-88-89</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-90">
  <m id="m126-d1t1308-6">
   <w.rf>
    <LM>w#w-d1t1308-6</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1308-5">
   <w.rf>
    <LM>w#w-d1t1308-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1310-1">
   <w.rf>
    <LM>w#w-d1t1310-1</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1310-2">
   <w.rf>
    <LM>w#w-d1t1310-2</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m126-d1t1310-3">
   <w.rf>
    <LM>w#w-d1t1310-3</LM>
   </w.rf>
   <form>džíny</form>
   <lemma>džíny-2</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m126-d-id122802-punct">
   <w.rf>
    <LM>w#w-d-id122802-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1310-5">
   <w.rf>
    <LM>w#w-d1t1310-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1310-6">
   <w.rf>
    <LM>w#w-d1t1310-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1310-7">
   <w.rf>
    <LM>w#w-d1t1310-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1310-8">
   <w.rf>
    <LM>w#w-d1t1310-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1310-9">
   <w.rf>
    <LM>w#w-d1t1310-9</LM>
   </w.rf>
   <form>sedla</form>
   <lemma>sednout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m126-d-id122888-punct">
   <w.rf>
    <LM>w#w-d-id122888-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1310-11">
   <w.rf>
    <LM>w#w-d1t1310-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1310-12">
   <w.rf>
    <LM>w#w-d1t1310-12</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1312-1">
   <w.rf>
    <LM>w#w-d1t1312-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1312-2">
   <w.rf>
    <LM>w#w-d1t1312-2</LM>
   </w.rf>
   <form>zadkem</form>
   <lemma>zadek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m126-d1t1312-3">
   <w.rf>
    <LM>w#w-d1t1312-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1312-4">
   <w.rf>
    <LM>w#w-d1t1312-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1312-6">
   <w.rf>
    <LM>w#w-d1t1312-6</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m126-d1t1312-7">
   <w.rf>
    <LM>w#w-d1t1312-7</LM>
   </w.rf>
   <form>tvrdou</form>
   <lemma>tvrdý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m126-d1t1312-8">
   <w.rf>
    <LM>w#w-d1t1312-8</LM>
   </w.rf>
   <form>díru</form>
   <lemma>díra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-90-1363">
   <w.rf>
    <LM>w#w-90-1363</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1364">
  <m id="m126-d1t1314-1">
   <w.rf>
    <LM>w#w-d1t1314-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1314-3">
   <w.rf>
    <LM>w#w-d1t1314-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1314-4">
   <w.rf>
    <LM>w#w-d1t1314-4</LM>
   </w.rf>
   <form>díru</form>
   <lemma>díra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d1t1314-6">
   <w.rf>
    <LM>w#w-d1t1314-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1314-7">
   <w.rf>
    <LM>w#w-d1t1314-7</LM>
   </w.rf>
   <form>otvor</form>
   <lemma>otvor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d-id123180-punct">
   <w.rf>
    <LM>w#w-d-id123180-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1314-12">
   <w.rf>
    <LM>w#w-d1t1314-12</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1314-10">
   <w.rf>
    <LM>w#w-d1t1314-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1314-11">
   <w.rf>
    <LM>w#w-d1t1314-11</LM>
   </w.rf>
   <form>nepřiléhalo</form>
   <lemma>přiléhat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m126-d1t1314-13">
   <w.rf>
    <LM>w#w-d1t1314-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m126-d1t1314-14">
   <w.rf>
    <LM>w#w-d1t1314-14</LM>
   </w.rf>
   <form>zadku</form>
   <lemma>zadek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m126-d-id123282-punct">
   <w.rf>
    <LM>w#w-d-id123282-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1314-16">
   <w.rf>
    <LM>w#w-d1t1314-16</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1314-17">
   <w.rf>
    <LM>w#w-d1t1314-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1314-18">
   <w.rf>
    <LM>w#w-d1t1314-18</LM>
   </w.rf>
   <form>sedlo</form>
   <lemma>sednout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m126-1364-1365">
   <w.rf>
    <LM>w#w-1364-1365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1366">
  <m id="m126-d1t1314-21">
   <w.rf>
    <LM>w#w-d1t1314-21</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1314-22">
   <w.rf>
    <LM>w#w-d1t1314-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1314-20">
   <w.rf>
    <LM>w#w-d1t1314-20</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1314-23">
   <w.rf>
    <LM>w#w-d1t1314-23</LM>
   </w.rf>
   <form>onosily</form>
   <lemma>onosit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1314-24">
   <w.rf>
    <LM>w#w-d1t1314-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1314-25">
   <w.rf>
    <LM>w#w-d1t1314-25</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1314-26">
   <w.rf>
    <LM>w#w-d1t1314-26</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-90-93">
   <w.rf>
    <LM>w#w-90-93</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1303-x3">
  <m id="m126-d1t1317-7">
   <w.rf>
    <LM>w#w-d1t1317-7</LM>
   </w.rf>
   <form>Trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1317-1">
   <w.rf>
    <LM>w#w-d1t1317-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1317-2">
   <w.rf>
    <LM>w#w-d1t1317-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1317-3">
   <w.rf>
    <LM>w#w-d1t1317-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m126-d1t1317-4">
   <w.rf>
    <LM>w#w-d1t1317-4</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1317-5">
   <w.rf>
    <LM>w#w-d1t1317-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1321-2">
   <w.rf>
    <LM>w#w-d1t1321-2</LM>
   </w.rf>
   <form>scvakali</form>
   <lemma>scvakat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1317-6">
   <w.rf>
    <LM>w#w-d1t1317-6</LM>
   </w.rf>
   <form>kamenem</form>
   <lemma>kámen</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m126-d1t1321-3">
   <w.rf>
    <LM>w#w-d1t1321-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1321-4">
   <w.rf>
    <LM>w#w-d1t1321-4</LM>
   </w.rf>
   <form>stehnech</form>
   <lemma>stehno</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m126-d-id123658-punct">
   <w.rf>
    <LM>w#w-d-id123658-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1321-6">
   <w.rf>
    <LM>w#w-d1t1321-6</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1321-7">
   <w.rf>
    <LM>w#w-d1t1321-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1321-8">
   <w.rf>
    <LM>w#w-d1t1321-8</LM>
   </w.rf>
   <form>vypadalo</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d-id123712-punct">
   <w.rf>
    <LM>w#w-d-id123712-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1321-10">
   <w.rf>
    <LM>w#w-d1t1321-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1321-11">
   <w.rf>
    <LM>w#w-d1t1321-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1321-12">
   <w.rf>
    <LM>w#w-d1t1321-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m126-d1t1321-13">
   <w.rf>
    <LM>w#w-d1t1321-13</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1321-14">
   <w.rf>
    <LM>w#w-d1t1321-14</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1321-15">
   <w.rf>
    <LM>w#w-d1t1321-15</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1e1303-x3-101">
   <w.rf>
    <LM>w#w-d1e1303-x3-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-102">
  <m id="m126-d1t1323-2">
   <w.rf>
    <LM>w#w-d1t1323-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1323-1">
   <w.rf>
    <LM>w#w-d1t1323-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1325-1">
   <w.rf>
    <LM>w#w-d1t1325-1</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1325-2">
   <w.rf>
    <LM>w#w-d1t1325-2</LM>
   </w.rf>
   <form>móda</form>
   <lemma>móda_^(co_je_módní)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-102-103">
   <w.rf>
    <LM>w#w-102-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-104">
  <m id="m126-d1t1325-9">
   <w.rf>
    <LM>w#w-d1t1325-9</LM>
   </w.rf>
   <form>Furt</form>
   <lemma>furt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1325-7">
   <w.rf>
    <LM>w#w-d1t1325-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1325-8">
   <w.rf>
    <LM>w#w-d1t1325-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1325-10">
   <w.rf>
    <LM>w#w-d1t1325-10</LM>
   </w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m126-104-105">
   <w.rf>
    <LM>w#w-104-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-107">
  <m id="m126-d1t1327-3">
   <w.rf>
    <LM>w#w-d1t1327-3</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1327-4">
   <w.rf>
    <LM>w#w-d1t1327-4</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m126-d1t1327-2">
   <w.rf>
    <LM>w#w-d1t1327-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m126-d1t1327-5">
   <w.rf>
    <LM>w#w-d1t1327-5</LM>
   </w.rf>
   <form>nosím</form>
   <lemma>nosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1327-6">
   <w.rf>
    <LM>w#w-d1t1327-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1327-7">
   <w.rf>
    <LM>w#w-d1t1327-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1330-1">
   <w.rf>
    <LM>w#w-d1t1330-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1330-2">
   <w.rf>
    <LM>w#w-d1t1330-2</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1330-3">
   <w.rf>
    <LM>w#w-d1t1330-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1330-4">
   <w.rf>
    <LM>w#w-d1t1330-4</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-d1t1330-5">
   <w.rf>
    <LM>w#w-d1t1330-5</LM>
   </w.rf>
   <form>džíny</form>
   <lemma>džíny-1</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1303-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1303-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1331-x2">
  <m id="m126-d1t1334-1">
   <w.rf>
    <LM>w#w-d1t1334-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1334-2">
   <w.rf>
    <LM>w#w-d1t1334-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1334-3">
   <w.rf>
    <LM>w#w-d1t1334-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m126-d1t1334-4">
   <w.rf>
    <LM>w#w-d1t1334-4</LM>
   </w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m126-d1t1334-5">
   <w.rf>
    <LM>w#w-d1t1334-5</LM>
   </w.rf>
   <form>rifle</form>
   <lemma>rifle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d1t1334-6">
   <w.rf>
    <LM>w#w-d1t1334-6</LM>
   </w.rf>
   <form>sloužily</form>
   <lemma>sloužit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d-id124364-punct">
   <w.rf>
    <LM>w#w-d-id124364-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1335-x2">
  <m id="m126-d1t1340-1">
   <w.rf>
    <LM>w#w-d1t1340-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m126-d1t1340-3">
   <w.rf>
    <LM>w#w-d1t1340-3</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m126-d1e1335-x2-114">
   <w.rf>
    <LM>w#w-d1e1335-x2-114</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-115">
  <m id="m126-d1t1342-3">
   <w.rf>
    <LM>w#w-d1t1342-3</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1342-4">
   <w.rf>
    <LM>w#w-d1t1342-4</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-d1t1342-5">
   <w.rf>
    <LM>w#w-d1t1342-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1342-6">
   <w.rf>
    <LM>w#w-d1t1342-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m126-d1t1342-7">
   <w.rf>
    <LM>w#w-d1t1342-7</LM>
   </w.rf>
   <form>nenosili</form>
   <lemma>nosit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m126-d-id124598-punct">
   <w.rf>
    <LM>w#w-d-id124598-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1342-9">
   <w.rf>
    <LM>w#w-d1t1342-9</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1342-10">
   <w.rf>
    <LM>w#w-d1t1342-10</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1342-11">
   <w.rf>
    <LM>w#w-d1t1342-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1342-12">
   <w.rf>
    <LM>w#w-d1t1342-12</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m126-d1t1342-13">
   <w.rf>
    <LM>w#w-d1t1342-13</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m126-d1t1342-14">
   <w.rf>
    <LM>w#w-d1t1342-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m126-d1t1342-15">
   <w.rf>
    <LM>w#w-d1t1342-15</LM>
   </w.rf>
   <form>zakazovali</form>
   <lemma>zakazovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d-id124715-punct">
   <w.rf>
    <LM>w#w-d-id124715-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1342-17">
   <w.rf>
    <LM>w#w-d1t1342-17</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1342-19">
   <w.rf>
    <LM>w#w-d1t1342-19</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1342-20">
   <w.rf>
    <LM>w#w-d1t1342-20</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m126-d1t1342-21">
   <w.rf>
    <LM>w#w-d1t1342-21</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m126-d1t1342-22">
   <w.rf>
    <LM>w#w-d1t1342-22</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m126-d1t1342-18">
   <w.rf>
    <LM>w#w-d1t1342-18</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1342-23">
   <w.rf>
    <LM>w#w-d1t1342-23</LM>
   </w.rf>
   <form>nedovolila</form>
   <lemma>dovolit</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m126-115-116">
   <w.rf>
    <LM>w#w-115-116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-117">
  <m id="m126-d1t1344-2">
   <w.rf>
    <LM>w#w-d1t1344-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1344-3">
   <w.rf>
    <LM>w#w-d1t1344-3</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d-id124893-punct">
   <w.rf>
    <LM>w#w-d-id124893-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1344-6">
   <w.rf>
    <LM>w#w-d1t1344-6</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m126-d1t1344-7">
   <w.rf>
    <LM>w#w-d1t1344-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m126-d1t1344-8">
   <w.rf>
    <LM>w#w-d1t1344-8</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m126-d1t1344-5">
   <w.rf>
    <LM>w#w-d1t1344-5</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d-m-d1e1335-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1335-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1345-x2">
  <m id="m126-d1t1348-1">
   <w.rf>
    <LM>w#w-d1t1348-1</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m126-d1t1348-2">
   <w.rf>
    <LM>w#w-d1t1348-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m126-d1t1348-3">
   <w.rf>
    <LM>w#w-d1t1348-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m126-d1t1348-4">
   <w.rf>
    <LM>w#w-d1t1348-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1345-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1345-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1349-x2">
  <m id="m126-d1t1354-1">
   <w.rf>
    <LM>w#w-d1t1354-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d-id125220-punct">
   <w.rf>
    <LM>w#w-d-id125220-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1354-6">
   <w.rf>
    <LM>w#w-d1t1354-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m126-d1t1354-7">
   <w.rf>
    <LM>w#w-d1t1354-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1354-8">
   <w.rf>
    <LM>w#w-d1t1354-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1354-9">
   <w.rf>
    <LM>w#w-d1t1354-9</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-d1t1354-12">
   <w.rf>
    <LM>w#w-d1t1354-12</LM>
   </w.rf>
   <form>Zdeničkou</form>
   <lemma>Zdenička_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-d1e1349-x2-131">
   <w.rf>
    <LM>w#w-d1e1349-x2-131</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-132">
  <m id="m126-d1t1354-15">
   <w.rf>
    <LM>w#w-d1t1354-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1354-16">
   <w.rf>
    <LM>w#w-d1t1354-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1354-17">
   <w.rf>
    <LM>w#w-d1t1354-17</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m126-d1t1354-18">
   <w.rf>
    <LM>w#w-d1t1354-18</LM>
   </w.rf>
   <form>kamarádka</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id125409-punct">
   <w.rf>
    <LM>w#w-d-id125409-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1354-20">
   <w.rf>
    <LM>w#w-d1t1354-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m126-d1t1354-21">
   <w.rf>
    <LM>w#w-d1t1354-21</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS7----------</tag>
  </m>
  <m id="m126-d1t1354-22">
   <w.rf>
    <LM>w#w-d1t1354-22</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1354-23">
   <w.rf>
    <LM>w#w-d1t1354-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1354-24">
   <w.rf>
    <LM>w#w-d1t1354-24</LM>
   </w.rf>
   <form>posestřily</form>
   <lemma>posestřit_,h</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1354-26">
   <w.rf>
    <LM>w#w-d1t1354-26</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1354-27">
   <w.rf>
    <LM>w#w-d1t1354-27</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1354-28">
   <w.rf>
    <LM>w#w-d1t1354-28</LM>
   </w.rf>
   <form>krví</form>
   <lemma>krev</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-132-133">
   <w.rf>
    <LM>w#w-132-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-135">
  <m id="m126-d1t1356-2">
   <w.rf>
    <LM>w#w-d1t1356-2</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1356-3">
   <w.rf>
    <LM>w#w-d1t1356-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1356-4">
   <w.rf>
    <LM>w#w-d1t1356-4</LM>
   </w.rf>
   <form>zájezdě</form>
   <lemma>zájezd</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-d1t1358-1">
   <w.rf>
    <LM>w#w-d1t1358-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1358-2">
   <w.rf>
    <LM>w#w-d1t1358-2</LM>
   </w.rf>
   <form>Krkonoších</form>
   <lemma>Krkonoše_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-135-136">
   <w.rf>
    <LM>w#w-135-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-137">
  <m id="m126-d1t1356-8">
   <w.rf>
    <LM>w#w-d1t1356-8</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1356-7">
   <w.rf>
    <LM>w#w-d1t1356-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1356-9">
   <w.rf>
    <LM>w#w-d1t1356-9</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1356-11">
   <w.rf>
    <LM>w#w-d1t1356-11</LM>
   </w.rf>
   <form>Rekrey</form>
   <lemma>Rekrea_;m</lemma>
   <tag>NNFS2-----A---1</tag>
  </m>
  <m id="m126-137-138">
   <w.rf>
    <LM>w#w-137-138</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-139">
  <m id="m126-d1t1360-7">
   <w.rf>
    <LM>w#w-d1t1360-7</LM>
   </w.rf>
   <form>Šly</form>
   <lemma>jít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1360-5">
   <w.rf>
    <LM>w#w-d1t1360-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1360-6">
   <w.rf>
    <LM>w#w-d1t1360-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1360-8">
   <w.rf>
    <LM>w#w-d1t1360-8</LM>
   </w.rf>
   <form>lovit</form>
   <lemma>lovit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d1t1360-9">
   <w.rf>
    <LM>w#w-d1t1360-9</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m126-d-id125943-punct">
   <w.rf>
    <LM>w#w-d-id125943-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1360-11">
   <w.rf>
    <LM>w#w-d1t1360-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m126-d1t1360-12">
   <w.rf>
    <LM>w#w-d1t1360-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1360-13">
   <w.rf>
    <LM>w#w-d1t1360-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1360-14">
   <w.rf>
    <LM>w#w-d1t1360-14</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1360-15">
   <w.rf>
    <LM>w#w-d1t1360-15</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m126-d1t1360-16">
   <w.rf>
    <LM>w#w-d1t1360-16</LM>
   </w.rf>
   <form>svobodné</form>
   <lemma>svobodný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-139-140">
   <w.rf>
    <LM>w#w-139-140</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-141">
  <m id="m126-d1t1363-1">
   <w.rf>
    <LM>w#w-d1t1363-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1363-2">
   <w.rf>
    <LM>w#w-d1t1363-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1363-3">
   <w.rf>
    <LM>w#w-d1t1363-3</LM>
   </w.rf>
   <form>sranda</form>
   <lemma>sranda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1363-4">
   <w.rf>
    <LM>w#w-d1t1363-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1363-5">
   <w.rf>
    <LM>w#w-d1t1363-5</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m126-d1t1363-6">
   <w.rf>
    <LM>w#w-d1t1363-6</LM>
   </w.rf>
   <form>kufry</form>
   <lemma>kufr</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m126-141-146">
   <w.rf>
    <LM>w#w-141-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1349-x3">
  <m id="m126-d1t1369-4">
   <w.rf>
    <LM>w#w-d1t1369-4</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1369-3">
   <w.rf>
    <LM>w#w-d1t1369-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1369-2">
   <w.rf>
    <LM>w#w-d1t1369-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1369-5">
   <w.rf>
    <LM>w#w-d1t1369-5</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1369-6">
   <w.rf>
    <LM>w#w-d1t1369-6</LM>
   </w.rf>
   <form>boty</form>
   <lemma>bota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m126-d-id126387-punct">
   <w.rf>
    <LM>w#w-d-id126387-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1373-1">
   <w.rf>
    <LM>w#w-d1t1373-1</LM>
   </w.rf>
   <form>pionýrky</form>
   <lemma>pionýrka_^(*2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m126-d-id126491-punct">
   <w.rf>
    <LM>w#w-d-id126491-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m126-d1t1373-4">
   <w.rf>
    <LM>w#w-d1t1373-4</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d1t1373-6">
   <w.rf>
    <LM>w#w-d1t1373-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1373-7">
   <w.rf>
    <LM>w#w-d1t1373-7</LM>
   </w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1349-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1349-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1374-x2">
  <m id="m126-d1t1377-1">
   <w.rf>
    <LM>w#w-d1t1377-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1377-2">
   <w.rf>
    <LM>w#w-d1t1377-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1377-3">
   <w.rf>
    <LM>w#w-d1t1377-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1377-4">
   <w.rf>
    <LM>w#w-d1t1377-4</LM>
   </w.rf>
   <form>poznaly</form>
   <lemma>poznat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-d-id126692-punct">
   <w.rf>
    <LM>w#w-d-id126692-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1378-x2">
  <m id="m126-d1t1381-1">
   <w.rf>
    <LM>w#w-d1t1381-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1381-2">
   <w.rf>
    <LM>w#w-d1t1381-2</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m126-d1t1381-3">
   <w.rf>
    <LM>w#w-d1t1381-3</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-d1t1381-4">
   <w.rf>
    <LM>w#w-d1t1381-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1381-5">
   <w.rf>
    <LM>w#w-d1t1381-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1381-6">
   <w.rf>
    <LM>w#w-d1t1381-6</LM>
   </w.rf>
   <form>poznaly</form>
   <lemma>poznat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1381-7">
   <w.rf>
    <LM>w#w-d1t1381-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1387-1">
   <w.rf>
    <LM>w#w-d1t1387-1</LM>
   </w.rf>
   <form>klubu</form>
   <lemma>klub</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-d1t1385-1">
   <w.rf>
    <LM>w#w-d1t1385-1</LM>
   </w.rf>
   <form>ČSM</form>
   <lemma>ČSM_^(Československý_svaz_mládeže)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m126-d-id126966-punct">
   <w.rf>
    <LM>w#w-d-id126966-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1387-4">
   <w.rf>
    <LM>w#w-d1t1387-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1387-3">
   <w.rf>
    <LM>w#w-d1t1387-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1387-5">
   <w.rf>
    <LM>w#w-d1t1387-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1387-7">
   <w.rf>
    <LM>w#w-d1t1387-7</LM>
   </w.rf>
   <form>Dejvicích</form>
   <lemma>Dejvice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-d-id127054-punct">
   <w.rf>
    <LM>w#w-d-id127054-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1387-10">
   <w.rf>
    <LM>w#w-d1t1387-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1387-12">
   <w.rf>
    <LM>w#w-d1t1387-12</LM>
   </w.rf>
   <form>Kulaťáku</form>
   <lemma>Kulaťák_;G_,l</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-d1e1378-x2-169">
   <w.rf>
    <LM>w#w-d1e1378-x2-169</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-170">
  <m id="m126-d1t1387-15">
   <w.rf>
    <LM>w#w-d1t1387-15</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1387-16">
   <w.rf>
    <LM>w#w-d1t1387-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1387-17">
   <w.rf>
    <LM>w#w-d1t1387-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1387-18">
   <w.rf>
    <LM>w#w-d1t1387-18</LM>
   </w.rf>
   <form>scházeli</form>
   <lemma>scházet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d-id127182-punct">
   <w.rf>
    <LM>w#w-d-id127182-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1387-21">
   <w.rf>
    <LM>w#w-d1t1387-21</LM>
   </w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1387-22">
   <w.rf>
    <LM>w#w-d1t1387-22</LM>
   </w.rf>
   <form>mládežníků</form>
   <lemma>mládežník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m126-170-172">
   <w.rf>
    <LM>w#w-170-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-173">
  <m id="m126-d1t1387-27">
   <w.rf>
    <LM>w#w-d1t1387-27</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1387-28">
   <w.rf>
    <LM>w#w-d1t1387-28</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1387-29">
   <w.rf>
    <LM>w#w-d1t1387-29</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1387-30">
   <w.rf>
    <LM>w#w-d1t1387-30</LM>
   </w.rf>
   <form>hospůdek</form>
   <lemma>hospůdka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m126-d1t1387-31">
   <w.rf>
    <LM>w#w-d1t1387-31</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1387-32">
   <w.rf>
    <LM>w#w-d1t1387-32</LM>
   </w.rf>
   <form>vymýšleli</form>
   <lemma>vymýšlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1387-33">
   <w.rf>
    <LM>w#w-d1t1387-33</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1387-34">
   <w.rf>
    <LM>w#w-d1t1387-34</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m126-173-1429">
   <w.rf>
    <LM>w#w-173-1429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-173-1430">
   <w.rf>
    <LM>w#w-173-1430</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-173-1431">
   <w.rf>
    <LM>w#w-173-1431</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-175">
  <m id="m126-d1t1387-37">
   <w.rf>
    <LM>w#w-d1t1387-37</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1387-38">
   <w.rf>
    <LM>w#w-d1t1387-38</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1387-39">
   <w.rf>
    <LM>w#w-d1t1387-39</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1387-41">
   <w.rf>
    <LM>w#w-d1t1387-41</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1387-40">
   <w.rf>
    <LM>w#w-d1t1387-40</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1387-42">
   <w.rf>
    <LM>w#w-d1t1387-42</LM>
   </w.rf>
   <form>sešly</form>
   <lemma>sejít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-175-1433">
   <w.rf>
    <LM>w#w-175-1433</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1434">
  <m id="m126-d1t1387-44">
   <w.rf>
    <LM>w#w-d1t1387-44</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1387-46">
   <w.rf>
    <LM>w#w-d1t1387-46</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m126-d1t1387-47">
   <w.rf>
    <LM>w#w-d1t1387-47</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d-id127619-punct">
   <w.rf>
    <LM>w#w-d-id127619-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1392-1">
   <w.rf>
    <LM>w#w-d1t1392-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1392-2">
   <w.rf>
    <LM>w#w-d1t1392-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m126-d1t1392-3">
   <w.rf>
    <LM>w#w-d1t1392-3</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1392-4">
   <w.rf>
    <LM>w#w-d1t1392-4</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-175-1432">
   <w.rf>
    <LM>w#w-175-1432</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1392-5">
   <w.rf>
    <LM>w#w-d1t1392-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1392-6">
   <w.rf>
    <LM>w#w-d1t1392-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1392-7">
   <w.rf>
    <LM>w#w-d1t1392-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1392-9">
   <w.rf>
    <LM>w#w-d1t1392-9</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m126-d1t1392-10">
   <w.rf>
    <LM>w#w-d1t1392-10</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id127807-punct">
   <w.rf>
    <LM>w#w-d-id127807-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1392-12">
   <w.rf>
    <LM>w#w-d1t1392-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1392-13">
   <w.rf>
    <LM>w#w-d1t1392-13</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1392-17">
   <w.rf>
    <LM>w#w-d1t1392-17</LM>
   </w.rf>
   <form>maminko</form>
   <lemma>maminka</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m126-d1t1392-14">
   <w.rf>
    <LM>w#w-d1t1392-14</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m126-d1t1392-15">
   <w.rf>
    <LM>w#w-d1t1392-15</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1392-18">
   <w.rf>
    <LM>w#w-d1t1392-18</LM>
   </w.rf>
   <form>neříkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m126-175-192">
   <w.rf>
    <LM>w#w-175-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1378-x3">
  <m id="m126-d1t1392-23">
   <w.rf>
    <LM>w#w-d1t1392-23</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1392-24">
   <w.rf>
    <LM>w#w-d1t1392-24</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-d1t1392-20">
   <w.rf>
    <LM>w#w-d1t1392-20</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1392-22">
   <w.rf>
    <LM>w#w-d1t1392-22</LM>
   </w.rf>
   <form>patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1392-25">
   <w.rf>
    <LM>w#w-d1t1392-25</LM>
   </w.rf>
   <form>dodneška</form>
   <lemma>dodneška</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d-m-d1e1378-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1378-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1393-x2">
  <m id="m126-d1t1398-1">
   <w.rf>
    <LM>w#w-d1t1398-1</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1398-2">
   <w.rf>
    <LM>w#w-d1t1398-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m126-d1t1400-1">
   <w.rf>
    <LM>w#w-d1t1400-1</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1400-2">
   <w.rf>
    <LM>w#w-d1t1400-2</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m126-d1t1400-3">
   <w.rf>
    <LM>w#w-d1t1400-3</LM>
   </w.rf>
   <form>sestro</form>
   <lemma>sestra</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m126-d-id128170-punct">
   <w.rf>
    <LM>w#w-d-id128170-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1401-x2">
  <m id="m126-d1t1404-4">
   <w.rf>
    <LM>w#w-d1t1404-4</LM>
   </w.rf>
   <form>Spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1404-2">
   <w.rf>
    <LM>w#w-d1t1404-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1404-3">
   <w.rf>
    <LM>w#w-d1t1404-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1404-5">
   <w.rf>
    <LM>w#w-d1t1404-5</LM>
   </w.rf>
   <form>říkaly</form>
   <lemma>říkat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1404-6">
   <w.rf>
    <LM>w#w-d1t1404-6</LM>
   </w.rf>
   <form>ségra</form>
   <lemma>ségra_,h</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1401-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1401-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1411-x2">
  <m id="m126-d1t1416-1">
   <w.rf>
    <LM>w#w-d1t1416-1</LM>
   </w.rf>
   <form>Vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1416-2">
   <w.rf>
    <LM>w#w-d1t1416-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1416-3">
   <w.rf>
    <LM>w#w-d1t1416-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1416-4">
   <w.rf>
    <LM>w#w-d1t1416-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m126-d1t1416-5">
   <w.rf>
    <LM>w#w-d1t1416-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1416-6">
   <w.rf>
    <LM>w#w-d1t1416-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d-id128474-punct">
   <w.rf>
    <LM>w#w-d-id128474-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1411-x4">
  <m id="m126-d1t1418-1">
   <w.rf>
    <LM>w#w-d1t1418-1</LM>
   </w.rf>
   <form>Vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d-id128576-punct">
   <w.rf>
    <LM>w#w-d-id128576-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1422-3">
   <w.rf>
    <LM>w#w-d1t1422-3</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d-m-d1e1411-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1411-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1419-x2">
  <m id="m126-d1t1422-7">
   <w.rf>
    <LM>w#w-d1t1422-7</LM>
   </w.rf>
   <form>Navštěvujeme</form>
   <lemma>navštěvovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1422-8">
   <w.rf>
    <LM>w#w-d1t1422-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1e1419-x2-232">
   <w.rf>
    <LM>w#w-d1e1419-x2-232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1424-1">
   <w.rf>
    <LM>w#w-d1t1424-1</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1424-2">
   <w.rf>
    <LM>w#w-d1t1424-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1424-3">
   <w.rf>
    <LM>w#w-d1t1424-3</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3-------</tag>
  </m>
  <m id="m126-d1e1419-x2-1463">
   <w.rf>
    <LM>w#w-d1e1419-x2-1463</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-234">
  <m id="m126-d1t1424-5">
   <w.rf>
    <LM>w#w-d1t1424-5</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m126-d1t1424-6">
   <w.rf>
    <LM>w#w-d1t1424-6</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1424-7">
   <w.rf>
    <LM>w#w-d1t1424-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1424-9">
   <w.rf>
    <LM>w#w-d1t1424-9</LM>
   </w.rf>
   <form>Lužinách</form>
   <lemma>Lužiny_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-d-id128808-punct">
   <w.rf>
    <LM>w#w-d-id128808-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1424-12">
   <w.rf>
    <LM>w#w-d1t1424-12</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m126-d1t1424-13">
   <w.rf>
    <LM>w#w-d1t1424-13</LM>
   </w.rf>
   <form>bydlím</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1424-14">
   <w.rf>
    <LM>w#w-d1t1424-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-234-107">
   <w.rf>
    <LM>w#w-234-107</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1424-16">
   <w.rf>
    <LM>w#w-d1t1424-16</LM>
   </w.rf>
   <form>Strossmayeráku</form>
   <lemma>Strossmayerák_;G_,h_^(Strossmayerovo_náměstí)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-234-108">
   <w.rf>
    <LM>w#w-234-108</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-234-235">
   <w.rf>
    <LM>w#w-234-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-236">
  <m id="m126-d1t1426-3">
   <w.rf>
    <LM>w#w-d1t1426-3</LM>
   </w.rf>
   <form>Vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1426-4">
   <w.rf>
    <LM>w#w-d1t1426-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-236-237">
   <w.rf>
    <LM>w#w-236-237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-239">
  <m id="m126-d1t1428-2">
   <w.rf>
    <LM>w#w-d1t1428-2</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1428-1">
   <w.rf>
    <LM>w#w-d1t1428-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1428-3">
   <w.rf>
    <LM>w#w-d1t1428-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1428-4">
   <w.rf>
    <LM>w#w-d1t1428-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1428-5">
   <w.rf>
    <LM>w#w-d1t1428-5</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d-id129038-punct">
   <w.rf>
    <LM>w#w-d-id129038-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1428-9">
   <w.rf>
    <LM>w#w-d1t1428-9</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m126-d1t1428-7">
   <w.rf>
    <LM>w#w-d1t1428-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1428-10">
   <w.rf>
    <LM>w#w-d1t1428-10</LM>
   </w.rf>
   <form>vdané</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-239-153">
   <w.rf>
    <LM>w#w-239-153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-155">
  <m id="m126-d1t1428-14">
   <w.rf>
    <LM>w#w-d1t1428-14</LM>
   </w.rf>
   <form>Nechaly</form>
   <lemma>nechat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1428-13">
   <w.rf>
    <LM>w#w-d1t1428-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1428-15">
   <w.rf>
    <LM>w#w-d1t1428-15</LM>
   </w.rf>
   <form>mužské</form>
   <lemma>mužský-2_^(osoba)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m126-d1t1428-16">
   <w.rf>
    <LM>w#w-d1t1428-16</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1428-17">
   <w.rf>
    <LM>w#w-d1t1428-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1428-18">
   <w.rf>
    <LM>w#w-d1t1428-18</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1428-19">
   <w.rf>
    <LM>w#w-d1t1428-19</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1428-20">
   <w.rf>
    <LM>w#w-d1t1428-20</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-239-240">
   <w.rf>
    <LM>w#w-239-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-241">
  <m id="m126-d1t1428-22">
   <w.rf>
    <LM>w#w-d1t1428-22</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1428-23">
   <w.rf>
    <LM>w#w-d1t1428-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1428-24">
   <w.rf>
    <LM>w#w-d1t1428-24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1428-26">
   <w.rf>
    <LM>w#w-d1t1428-26</LM>
   </w.rf>
   <form>Telči</form>
   <lemma>Telč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-241-242">
   <w.rf>
    <LM>w#w-241-242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-243">
  <m id="m126-d1t1433-5">
   <w.rf>
    <LM>w#w-d1t1433-5</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1433-4">
   <w.rf>
    <LM>w#w-d1t1433-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m126-d1t1433-6">
   <w.rf>
    <LM>w#w-d1t1433-6</LM>
   </w.rf>
   <form>furt</form>
   <lemma>furt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1433-7">
   <w.rf>
    <LM>w#w-d1t1433-7</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m126-243-244">
   <w.rf>
    <LM>w#w-243-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-245">
  <m id="m126-d1t1433-10">
   <w.rf>
    <LM>w#w-d1t1433-10</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1433-11">
   <w.rf>
    <LM>w#w-d1t1433-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1433-12">
   <w.rf>
    <LM>w#w-d1t1433-12</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m126-d1t1433-13">
   <w.rf>
    <LM>w#w-d1t1433-13</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d1t1433-14">
   <w.rf>
    <LM>w#w-d1t1433-14</LM>
   </w.rf>
   <form>rády</form>
   <lemma>rád-1</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m126-d1t1433-15">
   <w.rf>
    <LM>w#w-d1t1433-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1433-16">
   <w.rf>
    <LM>w#w-d1t1433-16</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1419-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1419-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1434-x2">
  <m id="m126-d1t1437-1">
   <w.rf>
    <LM>w#w-d1t1437-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m126-d1e1434-x2-247">
   <w.rf>
    <LM>w#w-d1e1434-x2-247</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-248">
  <m id="m126-d1t1439-1">
   <w.rf>
    <LM>w#w-d1t1439-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1439-2">
   <w.rf>
    <LM>w#w-d1t1439-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1439-3">
   <w.rf>
    <LM>w#w-d1t1439-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1439-4">
   <w.rf>
    <LM>w#w-d1t1439-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id129758-punct">
   <w.rf>
    <LM>w#w-d-id129758-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1440-x2">
  <m id="m126-d1t1443-3">
   <w.rf>
    <LM>w#w-d1t1443-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1443-4">
   <w.rf>
    <LM>w#w-d1t1443-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1443-5">
   <w.rf>
    <LM>w#w-d1t1443-5</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m126-d1t1443-6">
   <w.rf>
    <LM>w#w-d1t1443-6</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1e1440-x2-259">
   <w.rf>
    <LM>w#w-d1e1440-x2-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-260">
  <m id="m126-d1t1443-10">
   <w.rf>
    <LM>w#w-d1t1443-10</LM>
   </w.rf>
   <form>Vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1443-9">
   <w.rf>
    <LM>w#w-d1t1443-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1443-11">
   <w.rf>
    <LM>w#w-d1t1443-11</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m126-d1t1443-12">
   <w.rf>
    <LM>w#w-d1t1443-12</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1443-13">
   <w.rf>
    <LM>w#w-d1t1443-13</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m126-260-261">
   <w.rf>
    <LM>w#w-260-261</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-262">
  <m id="m126-d1t1445-1">
   <w.rf>
    <LM>w#w-d1t1445-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m126-d1t1445-2">
   <w.rf>
    <LM>w#w-d1t1445-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1445-3">
   <w.rf>
    <LM>w#w-d1t1445-3</LM>
   </w.rf>
   <form>támhle</form>
   <lemma>támhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1445-4">
   <w.rf>
    <LM>w#w-d1t1445-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1445-5">
   <w.rf>
    <LM>w#w-d1t1445-5</LM>
   </w.rf>
   <form>boku</form>
   <lemma>bok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m126-d-id130100-punct">
   <w.rf>
    <LM>w#w-d-id130100-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1445-7">
   <w.rf>
    <LM>w#w-d1t1445-7</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1445-8">
   <w.rf>
    <LM>w#w-d1t1445-8</LM>
   </w.rf>
   <form>vykulená</form>
   <lemma>vykulený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-d-id130140-punct">
   <w.rf>
    <LM>w#w-d-id130140-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1445-10">
   <w.rf>
    <LM>w#w-d1t1445-10</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1445-11">
   <w.rf>
    <LM>w#w-d1t1445-11</LM>
   </w.rf>
   <form>dlouhá</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-262-263">
   <w.rf>
    <LM>w#w-262-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
