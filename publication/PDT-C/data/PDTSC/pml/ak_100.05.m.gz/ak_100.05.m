<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_100.05.w.gz" />
  </references>
 </head>
 <s id="m100-447">
  <m id="m100-d1t1159-1">
   <w.rf>
    <LM>w#w-d1t1159-1</LM>
   </w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1159-2">
   <w.rf>
    <LM>w#w-d1t1159-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m100-d1t1159-3">
   <w.rf>
    <LM>w#w-d1t1159-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1159-4">
   <w.rf>
    <LM>w#w-d1t1159-4</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m100-d1t1159-5">
   <w.rf>
    <LM>w#w-d1t1159-5</LM>
   </w.rf>
   <form>slavný</form>
   <lemma>slavný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m100-d1t1159-6">
   <w.rf>
    <LM>w#w-d1t1159-6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m100-d-m-d1e1154-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1154-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-463">
  <m id="m100-d1t1175-3">
   <w.rf>
    <LM>w#w-d1t1175-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1175-6">
   <w.rf>
    <LM>w#w-d1t1175-6</LM>
   </w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m100-d1t1175-7">
   <w.rf>
    <LM>w#w-d1t1175-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m100-d1t1175-8">
   <w.rf>
    <LM>w#w-d1t1175-8</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1175-9">
   <w.rf>
    <LM>w#w-d1t1175-9</LM>
   </w.rf>
   <form>hyenismus</form>
   <lemma>hyenismus_,s_^(^DD**hyenizmus)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-463-464">
   <w.rf>
    <LM>w#w-463-464</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-465">
  <m id="m100-d1t1180-5">
   <w.rf>
    <LM>w#w-d1t1180-5</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1180-2">
   <w.rf>
    <LM>w#w-d1t1180-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m100-d1t1180-3">
   <w.rf>
    <LM>w#w-d1t1180-3</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m100-d1t1180-4">
   <w.rf>
    <LM>w#w-d1t1180-4</LM>
   </w.rf>
   <form>koukám</form>
   <lemma>koukat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-465-466">
   <w.rf>
    <LM>w#w-465-466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-467">
  <m id="m100-d1t1180-6">
   <w.rf>
    <LM>w#w-d1t1180-6</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1180-7">
   <w.rf>
    <LM>w#w-d1t1180-7</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m100-d1t1180-8">
   <w.rf>
    <LM>w#w-d1t1180-8</LM>
   </w.rf>
   <form>hoch</form>
   <lemma>hoch</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m100-d-id100813-punct">
   <w.rf>
    <LM>w#w-d-id100813-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1180-10">
   <w.rf>
    <LM>w#w-d1t1180-10</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m100-d1t1180-11">
   <w.rf>
    <LM>w#w-d1t1180-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1180-12">
   <w.rf>
    <LM>w#w-d1t1180-12</LM>
   </w.rf>
   <form>stal</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1180-13">
   <w.rf>
    <LM>w#w-d1t1180-13</LM>
   </w.rf>
   <form>slavným</form>
   <lemma>slavný</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m100-d1t1180-14">
   <w.rf>
    <LM>w#w-d1t1180-14</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m100-d-id100900-punct">
   <w.rf>
    <LM>w#w-d-id100900-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1180-16">
   <w.rf>
    <LM>w#w-d1t1180-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1180-17">
   <w.rf>
    <LM>w#w-d1t1180-17</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m100-d1t1180-19">
   <w.rf>
    <LM>w#w-d1t1180-19</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m100-d1t1180-21">
   <w.rf>
    <LM>w#w-d1t1180-21</LM>
   </w.rf>
   <form>popravili</form>
   <lemma>popravit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m100-d1t1180-22">
   <w.rf>
    <LM>w#w-d1t1180-22</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m100-d1t1180-23">
   <w.rf>
    <LM>w#w-d1t1180-23</LM>
   </w.rf>
   <form>loupežnou</form>
   <lemma>loupežný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m100-d1t1180-24">
   <w.rf>
    <LM>w#w-d1t1180-24</LM>
   </w.rf>
   <form>vraždu</form>
   <lemma>vražda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m100-467-468">
   <w.rf>
    <LM>w#w-467-468</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-469">
  <m id="m100-d1t1180-26">
   <w.rf>
    <LM>w#w-d1t1180-26</LM>
   </w.rf>
   <form>Kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1180-28">
   <w.rf>
    <LM>w#w-d1t1180-28</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m100-d1t1180-29">
   <w.rf>
    <LM>w#w-d1t1180-29</LM>
   </w.rf>
   <form>politická</form>
   <lemma>politický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m100-d-id101106-punct">
   <w.rf>
    <LM>w#w-d-id101106-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1180-31">
   <w.rf>
    <LM>w#w-d1t1180-31</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1180-34">
   <w.rf>
    <LM>w#w-d1t1180-34</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m100-d1t1180-33">
   <w.rf>
    <LM>w#w-d1t1180-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1180-35">
   <w.rf>
    <LM>w#w-d1t1180-35</LM>
   </w.rf>
   <form>loupežná</form>
   <lemma>loupežný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m100-d1t1180-36">
   <w.rf>
    <LM>w#w-d1t1180-36</LM>
   </w.rf>
   <form>vražda</form>
   <lemma>vražda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d1t1182-1">
   <w.rf>
    <LM>w#w-d1t1182-1</LM>
   </w.rf>
   <form>prostitutky</form>
   <lemma>prostitutka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m100-469-474">
   <w.rf>
    <LM>w#w-469-474</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-475">
  <m id="m100-d1t1186-3">
   <w.rf>
    <LM>w#w-d1t1186-3</LM>
   </w.rf>
   <form>Popravili</form>
   <lemma>popravit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m100-d1t1186-4">
   <w.rf>
    <LM>w#w-d1t1186-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m100-d-id101333-punct">
   <w.rf>
    <LM>w#w-d-id101333-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1186-6">
   <w.rf>
    <LM>w#w-d1t1186-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1186-7">
   <w.rf>
    <LM>w#w-d1t1186-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1186-8">
   <w.rf>
    <LM>w#w-d1t1186-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1186-9">
   <w.rf>
    <LM>w#w-d1t1186-9</LM>
   </w.rf>
   <form>kvartě</form>
   <lemma>kvarta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-475-478">
   <w.rf>
    <LM>w#w-475-478</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1166-x3">
  <m id="m100-d1t1188-2">
   <w.rf>
    <LM>w#w-d1t1188-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1188-3">
   <w.rf>
    <LM>w#w-d1t1188-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1188-5">
   <w.rf>
    <LM>w#w-d1t1188-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m100-d1t1188-6">
   <w.rf>
    <LM>w#w-d1t1188-6</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m100-d1t1188-7">
   <w.rf>
    <LM>w#w-d1t1188-7</LM>
   </w.rf>
   <form>sláva</form>
   <lemma>sláva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d-id101530-punct">
   <w.rf>
    <LM>w#w-d-id101530-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1188-9">
   <w.rf>
    <LM>w#w-d1t1188-9</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d-id101554-punct">
   <w.rf>
    <LM>w#w-d-id101554-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1166-x4">
  <m id="m100-d1t1193-4">
   <w.rf>
    <LM>w#w-d1t1193-4</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m100-d1t1193-5">
   <w.rf>
    <LM>w#w-d1t1193-5</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d-id101657-punct">
   <w.rf>
    <LM>w#w-d-id101657-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1193-8">
   <w.rf>
    <LM>w#w-d1t1193-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1193-7">
   <w.rf>
    <LM>w#w-d1t1193-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1193-10">
   <w.rf>
    <LM>w#w-d1t1193-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1193-11">
   <w.rf>
    <LM>w#w-d1t1193-11</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m100-d1t1193-12">
   <w.rf>
    <LM>w#w-d1t1193-12</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m100-d1t1193-9">
   <w.rf>
    <LM>w#w-d1t1193-9</LM>
   </w.rf>
   <form>hyenismus</form>
   <lemma>hyenismus_,s_^(^DD**hyenizmus)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1e1166-x4-492">
   <w.rf>
    <LM>w#w-d1e1166-x4-492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-493">
  <m id="m100-d1t1193-16">
   <w.rf>
    <LM>w#w-d1t1193-16</LM>
   </w.rf>
   <form>Omlouvám</form>
   <lemma>omlouvat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1193-15">
   <w.rf>
    <LM>w#w-d1t1193-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-493-494">
   <w.rf>
    <LM>w#w-493-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-495">
  <m id="m100-d1t1197-4">
   <w.rf>
    <LM>w#w-d1t1197-4</LM>
   </w.rf>
   <form>Nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m100-d1t1197-5">
   <w.rf>
    <LM>w#w-d1t1197-5</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m100-d1t1197-6">
   <w.rf>
    <LM>w#w-d1t1197-6</LM>
   </w.rf>
   <form>slavného</form>
   <lemma>slavný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m100-d1t1197-9">
   <w.rf>
    <LM>w#w-d1t1197-9</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1197-10">
   <w.rf>
    <LM>w#w-d1t1197-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m100-d1t1197-8">
   <w.rf>
    <LM>w#w-d1t1197-8</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m100-d-m-d1e1166-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1166-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1198-x2">
  <m id="m100-d1t1201-2">
   <w.rf>
    <LM>w#w-d1t1201-2</LM>
   </w.rf>
   <form>Můžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1201-3">
   <w.rf>
    <LM>w#w-d1t1201-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m100-d1t1201-4">
   <w.rf>
    <LM>w#w-d1t1201-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m100-d1t1201-5">
   <w.rf>
    <LM>w#w-d1t1201-5</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m100-d-m-d1e1198-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1198-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1202-x2">
  <m id="m100-d1t1205-1">
   <w.rf>
    <LM>w#w-d1t1205-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d-m-d1e1202-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1202-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1207-x2">
  <m id="m100-d1t1210-1">
   <w.rf>
    <LM>w#w-d1t1210-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m100-d1t1210-2">
   <w.rf>
    <LM>w#w-d1t1210-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1210-3">
   <w.rf>
    <LM>w#w-d1t1210-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1210-4">
   <w.rf>
    <LM>w#w-d1t1210-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m100-d1t1210-5">
   <w.rf>
    <LM>w#w-d1t1210-5</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m100-d-id102323-punct">
   <w.rf>
    <LM>w#w-d-id102323-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1213-x2">
  <m id="m100-d1t1218-1">
   <w.rf>
    <LM>w#w-d1t1218-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m100-d1t1218-2">
   <w.rf>
    <LM>w#w-d1t1218-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m100-d1t1218-3">
   <w.rf>
    <LM>w#w-d1t1218-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1218-4">
   <w.rf>
    <LM>w#w-d1t1218-4</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m100-d1t1218-5">
   <w.rf>
    <LM>w#w-d1t1218-5</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1e1213-x2-509">
   <w.rf>
    <LM>w#w-d1e1213-x2-509</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-510">
  <m id="m100-d1t1222-3">
   <w.rf>
    <LM>w#w-d1t1222-3</LM>
   </w.rf>
   <form>Jednoznačně</form>
   <lemma>jednoznačně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m100-d1t1222-2">
   <w.rf>
    <LM>w#w-d1t1222-2</LM>
   </w.rf>
   <form>skautský</form>
   <lemma>skautský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-510-511">
   <w.rf>
    <LM>w#w-510-511</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-512">
  <m id="m100-d1t1222-6">
   <w.rf>
    <LM>w#w-d1t1222-6</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1222-6-sw1">
   <w.rf>
    <LM>w#w-d1t1222-6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1222-6-sw2">
   <w.rf>
    <LM>w#w-d1t1222-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>li</form>
   <lemma>li-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1222-7">
   <w.rf>
    <LM>w#w-d1t1222-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1222-8">
   <w.rf>
    <LM>w#w-d1t1222-8</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m100-d1t1222-9">
   <w.rf>
    <LM>w#w-d1t1222-9</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d-id102670-punct">
   <w.rf>
    <LM>w#w-d-id102670-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1222-16">
   <w.rf>
    <LM>w#w-d1t1222-16</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m100-d1t1222-17">
   <w.rf>
    <LM>w#w-d1t1222-17</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m100-24-25">
   <w.rf>
    <LM>w#w-24-25</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1222-18">
   <w.rf>
    <LM>w#w-d1t1222-18</LM>
   </w.rf>
   <form>nepoznávám</form>
   <lemma>poznávat_^(*4at)</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-27-28">
   <w.rf>
    <LM>w#w-27-28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1224-2">
   <w.rf>
    <LM>w#w-d1t1224-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1224-3">
   <w.rf>
    <LM>w#w-d1t1224-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1224-4">
   <w.rf>
    <LM>w#w-d1t1224-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1224-5">
   <w.rf>
    <LM>w#w-d1t1224-5</LM>
   </w.rf>
   <form>jednoznačně</form>
   <lemma>jednoznačně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m100-d1t1224-6">
   <w.rf>
    <LM>w#w-d1t1224-6</LM>
   </w.rf>
   <form>skautský</form>
   <lemma>skautský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-d1t1224-7">
   <w.rf>
    <LM>w#w-d1t1224-7</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-27-29">
   <w.rf>
    <LM>w#w-27-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-30">
  <m id="m100-d1t1231-6">
   <w.rf>
    <LM>w#w-d1t1231-6</LM>
   </w.rf>
   <form>Jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1231-7">
   <w.rf>
    <LM>w#w-d1t1231-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1231-8">
   <w.rf>
    <LM>w#w-d1t1231-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1231-9">
   <w.rf>
    <LM>w#w-d1t1231-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1231-11">
   <w.rf>
    <LM>w#w-d1t1231-11</LM>
   </w.rf>
   <form>Blanici</form>
   <lemma>Blanice_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-d-id103111-punct">
   <w.rf>
    <LM>w#w-d-id103111-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1231-14">
   <w.rf>
    <LM>w#w-d1t1231-14</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1231-15">
   <w.rf>
    <LM>w#w-d1t1231-15</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1231-16">
   <w.rf>
    <LM>w#w-d1t1231-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1231-17">
   <w.rf>
    <LM>w#w-d1t1231-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1231-18">
   <w.rf>
    <LM>w#w-d1t1231-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1231-20">
   <w.rf>
    <LM>w#w-d1t1231-20</LM>
   </w.rf>
   <form>Lužnici</form>
   <lemma>Lužnice_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-d-id103230-punct">
   <w.rf>
    <LM>w#w-d-id103230-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1231-23">
   <w.rf>
    <LM>w#w-d1t1231-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m100-d1t1231-24">
   <w.rf>
    <LM>w#w-d1t1231-24</LM>
   </w.rf>
   <form>nepoznám</form>
   <lemma>poznat</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m100-51-52">
   <w.rf>
    <LM>w#w-51-52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-54">
  <m id="m100-d1t1237-1">
   <w.rf>
    <LM>w#w-d1t1237-1</LM>
   </w.rf>
   <form>Nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1237-5">
   <w.rf>
    <LM>w#w-d1t1237-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1237-6">
   <w.rf>
    <LM>w#w-d1t1237-6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m100-d1t1237-4">
   <w.rf>
    <LM>w#w-d1t1237-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1237-8">
   <w.rf>
    <LM>w#w-d1t1237-8</LM>
   </w.rf>
   <form>nezdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m100-d-id103457-punct">
   <w.rf>
    <LM>w#w-d-id103457-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1237-11">
   <w.rf>
    <LM>w#w-d1t1237-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1e1213-x3-86">
   <w.rf>
    <LM>w#w-d1e1213-x3-86</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m100-d1t1237-12">
   <w.rf>
    <LM>w#w-d1t1237-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1237-13">
   <w.rf>
    <LM>w#w-d1t1237-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1237-14">
   <w.rf>
    <LM>w#w-d1t1237-14</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m100-d1t1237-15">
   <w.rf>
    <LM>w#w-d1t1237-15</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1e1213-x3-87">
   <w.rf>
    <LM>w#w-d1e1213-x3-87</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-89">
  <m id="m100-d1t1237-25">
   <w.rf>
    <LM>w#w-d1t1237-25</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-89-111">
   <w.rf>
    <LM>w#w-89-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-112">
  <m id="m100-d1t1237-33">
   <w.rf>
    <LM>w#w-d1t1237-33</LM>
   </w.rf>
   <form>Nezdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m100-d1t1237-29">
   <w.rf>
    <LM>w#w-d1t1237-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1237-30">
   <w.rf>
    <LM>w#w-d1t1237-30</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m100-d1t1237-34">
   <w.rf>
    <LM>w#w-d1t1237-34</LM>
   </w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1t1237-35">
   <w.rf>
    <LM>w#w-d1t1237-35</LM>
   </w.rf>
   <form>stanů</form>
   <lemma>stan</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m100-d-id103848-punct">
   <w.rf>
    <LM>w#w-d-id103848-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1237-37">
   <w.rf>
    <LM>w#w-d1t1237-37</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m100-d1t1237-38">
   <w.rf>
    <LM>w#w-d1t1237-38</LM>
   </w.rf>
   <form>uspořádání</form>
   <lemma>uspořádání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m100-d-id103897-punct">
   <w.rf>
    <LM>w#w-d-id103897-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-112-115">
   <w.rf>
    <LM>w#w-112-115</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m100-d1t1240-3">
   <w.rf>
    <LM>w#w-d1t1240-3</LM>
   </w.rf>
   <form>stožár</form>
   <lemma>stožár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1t1240-4">
   <w.rf>
    <LM>w#w-d1t1240-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1240-5">
   <w.rf>
    <LM>w#w-d1t1240-5</LM>
   </w.rf>
   <form>prostředku</form>
   <lemma>prostředek_^(střed,způsob,_nástroj)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m100-109-113">
   <w.rf>
    <LM>w#w-109-113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-114">
  <m id="m100-d1t1242-1">
   <w.rf>
    <LM>w#w-d1t1242-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1242-2">
   <w.rf>
    <LM>w#w-d1t1242-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1242-3">
   <w.rf>
    <LM>w#w-d1t1242-3</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m100-d1t1242-4">
   <w.rf>
    <LM>w#w-d1t1242-4</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m100-d-id104038-punct">
   <w.rf>
    <LM>w#w-d-id104038-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-114-117">
   <w.rf>
    <LM>w#w-114-117</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m100-d1t1242-6">
   <w.rf>
    <LM>w#w-d1t1242-6</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m100-d1t1242-7">
   <w.rf>
    <LM>w#w-d1t1242-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1242-8">
   <w.rf>
    <LM>w#w-d1t1242-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m100-d1t1244-1">
   <w.rf>
    <LM>w#w-d1t1244-1</LM>
   </w.rf>
   <form>nezdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m100-114-118">
   <w.rf>
    <LM>w#w-114-118</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-114-119">
   <w.rf>
    <LM>w#w-114-119</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1244-2">
   <w.rf>
    <LM>w#w-d1t1244-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-114-120">
   <w.rf>
    <LM>w#w-114-120</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1246-1">
   <w.rf>
    <LM>w#w-d1t1246-1</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d1t1246-2">
   <w.rf>
    <LM>w#w-d1t1246-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1246-3">
   <w.rf>
    <LM>w#w-d1t1246-3</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d-id104189-punct">
   <w.rf>
    <LM>w#w-d-id104189-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1246-5">
   <w.rf>
    <LM>w#w-d1t1246-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1246-6">
   <w.rf>
    <LM>w#w-d1t1246-6</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m100-d1t1246-7">
   <w.rf>
    <LM>w#w-d1t1246-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1246-8">
   <w.rf>
    <LM>w#w-d1t1246-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-114-121">
   <w.rf>
    <LM>w#w-114-121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-114-124">
   <w.rf>
    <LM>w#w-114-124</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-114-122">
   <w.rf>
    <LM>w#w-114-122</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-114-123">
   <w.rf>
    <LM>w#w-114-123</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d1t1246-12">
   <w.rf>
    <LM>w#w-d1t1246-12</LM>
   </w.rf>
   <form>skautského</form>
   <lemma>skautský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m100-d1t1246-11">
   <w.rf>
    <LM>w#w-d1t1246-11</LM>
   </w.rf>
   <form>oddílu</form>
   <lemma>oddíl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m100-d-id104322-punct">
   <w.rf>
    <LM>w#w-d-id104322-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1246-14">
   <w.rf>
    <LM>w#w-d1t1246-14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m100-d1t1246-15">
   <w.rf>
    <LM>w#w-d1t1246-15</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m100-d1t1246-16">
   <w.rf>
    <LM>w#w-d1t1246-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1246-18">
   <w.rf>
    <LM>w#w-d1t1246-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1246-19">
   <w.rf>
    <LM>w#w-d1t1246-19</LM>
   </w.rf>
   <form>táboře</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m100-d1t1246-17">
   <w.rf>
    <LM>w#w-d1t1246-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d-m-d1e1213-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1213-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1247-x2">
  <m id="m100-d1t1252-1">
   <w.rf>
    <LM>w#w-d1t1252-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1e1247-x2-126">
   <w.rf>
    <LM>w#w-d1e1247-x2-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-127">
  <m id="m100-d1t1252-3">
   <w.rf>
    <LM>w#w-d1t1252-3</LM>
   </w.rf>
   <form>Nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1t1252-4">
   <w.rf>
    <LM>w#w-d1t1252-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1252-5">
   <w.rf>
    <LM>w#w-d1t1252-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m100-d1t1252-6">
   <w.rf>
    <LM>w#w-d1t1252-6</LM>
   </w.rf>
   <form>mluvit</form>
   <lemma>mluvit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m100-d-m-d1e1247-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1247-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1247-x3">
  <m id="m100-d1t1254-1">
   <w.rf>
    <LM>w#w-d1t1254-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1254-2">
   <w.rf>
    <LM>w#w-d1t1254-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m100-d1t1254-3">
   <w.rf>
    <LM>w#w-d1t1254-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1254-4">
   <w.rf>
    <LM>w#w-d1t1254-4</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1254-5">
   <w.rf>
    <LM>w#w-d1t1254-5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m100-d1t1254-6">
   <w.rf>
    <LM>w#w-d1t1254-6</LM>
   </w.rf>
   <form>skautům</form>
   <lemma>skaut</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m100-d-id104667-punct">
   <w.rf>
    <LM>w#w-d-id104667-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1255-x2">
  <m id="m100-d1t1260-1">
   <w.rf>
    <LM>w#w-d1t1260-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1260-2">
   <w.rf>
    <LM>w#w-d1t1260-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1262-5">
   <w.rf>
    <LM>w#w-d1t1262-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1262-6">
   <w.rf>
    <LM>w#w-d1t1262-6</LM>
   </w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m100-d1t1262-7">
   <w.rf>
    <LM>w#w-d1t1262-7</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-d1t1260-3">
   <w.rf>
    <LM>w#w-d1t1260-3</LM>
   </w.rf>
   <form>spolužáka</form>
   <lemma>spolužák</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m100-d1t1262-8">
   <w.rf>
    <LM>w#w-d1t1262-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1266-1">
   <w.rf>
    <LM>w#w-d1t1266-1</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m100-d1t1266-2">
   <w.rf>
    <LM>w#w-d1t1266-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1266-3">
   <w.rf>
    <LM>w#w-d1t1266-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m100-d1t1266-4">
   <w.rf>
    <LM>w#w-d1t1266-4</LM>
   </w.rf>
   <form>skautingu</form>
   <lemma>skauting</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m100-d1t1266-5">
   <w.rf>
    <LM>w#w-d1t1266-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1266-6">
   <w.rf>
    <LM>w#w-d1t1266-6</LM>
   </w.rf>
   <form>oddílu</form>
   <lemma>oddíl</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m100-d1t1266-11">
   <w.rf>
    <LM>w#w-d1t1266-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1266-12">
   <w.rf>
    <LM>w#w-d1t1266-12</LM>
   </w.rf>
   <form>dejvické</form>
   <lemma>dejvický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m100-d1t1266-14">
   <w.rf>
    <LM>w#w-d1t1266-14</LM>
   </w.rf>
   <form>jedenáctce</form>
   <lemma>jedenáctka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-d1e1255-x2-140">
   <w.rf>
    <LM>w#w-d1e1255-x2-140</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-146">
  <m id="m100-d1t1266-20">
   <w.rf>
    <LM>w#w-d1t1266-20</LM>
   </w.rf>
   <form>Přivedl</form>
   <lemma>přivést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1266-18">
   <w.rf>
    <LM>w#w-d1t1266-18</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m100-d1t1266-19">
   <w.rf>
    <LM>w#w-d1t1266-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-146-147">
   <w.rf>
    <LM>w#w-146-147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-148">
  <m id="m100-d1t1269-1">
   <w.rf>
    <LM>w#w-d1t1269-1</LM>
   </w.rf>
   <form>Přivedl</form>
   <lemma>přivést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m100-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1269-4">
   <w.rf>
    <LM>w#w-d1t1269-4</LM>
   </w.rf>
   <form>těsně</form>
   <lemma>těsně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m100-d1t1273-3">
   <w.rf>
    <LM>w#w-d1t1273-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1273-4">
   <w.rf>
    <LM>w#w-d1t1273-4</LM>
   </w.rf>
   <form>návratu</form>
   <lemma>návrat</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m100-d1t1273-5">
   <w.rf>
    <LM>w#w-d1t1273-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1273-6">
   <w.rf>
    <LM>w#w-d1t1273-6</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d1t1277-8">
   <w.rf>
    <LM>w#w-d1t1277-8</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-148-150">
   <w.rf>
    <LM>w#w-148-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1277-9">
   <w.rf>
    <LM>w#w-d1t1277-9</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m100-d1t1277-10">
   <w.rf>
    <LM>w#w-d1t1277-10</LM>
   </w.rf>
   <form>1937</form>
   <lemma>1937</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-d-m-d1e1255-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1255-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1278-x2">
  <m id="m100-d1t1281-1">
   <w.rf>
    <LM>w#w-d1t1281-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m100-d1t1281-2">
   <w.rf>
    <LM>w#w-d1t1281-2</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m100-d1t1281-3">
   <w.rf>
    <LM>w#w-d1t1281-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m100-d1t1281-4">
   <w.rf>
    <LM>w#w-d1t1281-4</LM>
   </w.rf>
   <form>strávil</form>
   <lemma>strávit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1281-5">
   <w.rf>
    <LM>w#w-d1t1281-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m100-d1t1281-6">
   <w.rf>
    <LM>w#w-d1t1281-6</LM>
   </w.rf>
   <form>skautu</form>
   <lemma>skaut</lemma>
   <tag>NNMS6-----A---1</tag>
  </m>
  <m id="m100-d-id105864-punct">
   <w.rf>
    <LM>w#w-d-id105864-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1282-x2">
  <m id="m100-d1t1285-11">
   <w.rf>
    <LM>w#w-d1t1285-11</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1285-8">
   <w.rf>
    <LM>w#w-d1t1285-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1285-10">
   <w.rf>
    <LM>w#w-d1t1285-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1285-9">
   <w.rf>
    <LM>w#w-d1t1285-9</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1285-13">
   <w.rf>
    <LM>w#w-d1t1285-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1e1282-x2-159">
   <w.rf>
    <LM>w#w-d1e1282-x2-159</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d1t1285-14">
   <w.rf>
    <LM>w#w-d1t1285-14</LM>
   </w.rf>
   <form>1946</form>
   <lemma>1946</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-d1t1285-16">
   <w.rf>
    <LM>w#w-d1t1285-16</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1e1282-x2-160">
   <w.rf>
    <LM>w#w-d1e1282-x2-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-161">
  <m id="m100-d1t1291-6">
   <w.rf>
    <LM>w#w-d1t1291-6</LM>
   </w.rf>
   <form>Devět</form>
   <lemma>devět`9</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m100-161-945">
   <w.rf>
    <LM>w#w-161-945</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m100-d1e1282-x4-168">
   <w.rf>
    <LM>w#w-d1e1282-x4-168</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1e1282-x4-169">
   <w.rf>
    <LM>w#w-d1e1282-x4-169</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-161-177">
   <w.rf>
    <LM>w#w-161-177</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-161-178">
   <w.rf>
    <LM>w#w-161-178</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-161-179">
   <w.rf>
    <LM>w#w-161-179</LM>
   </w.rf>
   <form>jo</form>
   <lemma>jo_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-161-180">
   <w.rf>
    <LM>w#w-161-180</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-173">
  <m id="m100-d1t1300-3">
   <w.rf>
    <LM>w#w-d1t1300-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1300-4">
   <w.rf>
    <LM>w#w-d1t1300-4</LM>
   </w.rf>
   <form>neumím</form>
   <lemma>umět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1t1300-5">
   <w.rf>
    <LM>w#w-d1t1300-5</LM>
   </w.rf>
   <form>počítat</form>
   <lemma>počítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m100-d-m-d1e1282-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1282-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1303-x2">
  <m id="m100-d1t1306-1">
   <w.rf>
    <LM>w#w-d1t1306-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1306-2">
   <w.rf>
    <LM>w#w-d1t1306-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m100-d1t1306-3">
   <w.rf>
    <LM>w#w-d1t1306-3</LM>
   </w.rf>
   <form>skauting</form>
   <lemma>skauting</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1t1306-4">
   <w.rf>
    <LM>w#w-d1t1306-4</LM>
   </w.rf>
   <form>ovlivnil</form>
   <lemma>ovlivnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d-id106752-punct">
   <w.rf>
    <LM>w#w-d-id106752-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1309-x2">
  <m id="m100-d1t1314-1">
   <w.rf>
    <LM>w#w-d1t1314-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1314-2">
   <w.rf>
    <LM>w#w-d1t1314-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1314-3">
   <w.rf>
    <LM>w#w-d1t1314-3</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m100-d1t1314-4">
   <w.rf>
    <LM>w#w-d1t1314-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m100-d-id106908-punct">
   <w.rf>
    <LM>w#w-d-id106908-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1316-1">
   <w.rf>
    <LM>w#w-d1t1316-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1316-2">
   <w.rf>
    <LM>w#w-d1t1316-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m100-d1t1316-3">
   <w.rf>
    <LM>w#w-d1t1316-3</LM>
   </w.rf>
   <form>skauting</form>
   <lemma>skauting</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1t1316-4">
   <w.rf>
    <LM>w#w-d1t1316-4</LM>
   </w.rf>
   <form>ovlivnil</form>
   <lemma>ovlivnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1e1309-x2-200">
   <w.rf>
    <LM>w#w-d1e1309-x2-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-201">
  <m id="m100-d1t1320-5">
   <w.rf>
    <LM>w#w-d1t1320-5</LM>
   </w.rf>
   <form>Představuju</form>
   <lemma>představovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1320-4">
   <w.rf>
    <LM>w#w-d1t1320-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m100-d-id107108-punct">
   <w.rf>
    <LM>w#w-d-id107108-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1320-7">
   <w.rf>
    <LM>w#w-d1t1320-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1320-8">
   <w.rf>
    <LM>w#w-d1t1320-8</LM>
   </w.rf>
   <form>skauting</form>
   <lemma>skauting</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d1t1323-1">
   <w.rf>
    <LM>w#w-d1t1323-1</LM>
   </w.rf>
   <form>ovlivní</form>
   <lemma>ovlivnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m100-d1t1323-2">
   <w.rf>
    <LM>w#w-d1t1323-2</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m100-d1t1323-3">
   <w.rf>
    <LM>w#w-d1t1323-3</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m100-d-id107203-punct">
   <w.rf>
    <LM>w#w-d-id107203-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1323-5">
   <w.rf>
    <LM>w#w-d1t1323-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m100-d1t1323-6">
   <w.rf>
    <LM>w#w-d1t1323-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1323-7">
   <w.rf>
    <LM>w#w-d1t1323-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1323-8">
   <w.rf>
    <LM>w#w-d1t1323-8</LM>
   </w.rf>
   <form>dostane</form>
   <lemma>dostat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m100-201-204">
   <w.rf>
    <LM>w#w-201-204</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1323-9">
   <w.rf>
    <LM>w#w-d1t1323-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1323-10">
   <w.rf>
    <LM>w#w-d1t1323-10</LM>
   </w.rf>
   <form>každou</form>
   <lemma>každý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m100-d1t1323-11">
   <w.rf>
    <LM>w#w-d1t1323-11</LM>
   </w.rf>
   <form>osobu</form>
   <lemma>osoba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m100-d-id107320-punct">
   <w.rf>
    <LM>w#w-d-id107320-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1323-13">
   <w.rf>
    <LM>w#w-d1t1323-13</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m100-d1t1323-14">
   <w.rf>
    <LM>w#w-d1t1323-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1323-15">
   <w.rf>
    <LM>w#w-d1t1323-15</LM>
   </w.rf>
   <form>přijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m100-201-202">
   <w.rf>
    <LM>w#w-201-202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-203">
  <m id="m100-d1t1329-1">
   <w.rf>
    <LM>w#w-d1t1329-1</LM>
   </w.rf>
   <form>Skautská</form>
   <lemma>skautský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m100-d1t1329-2">
   <w.rf>
    <LM>w#w-d1t1329-2</LM>
   </w.rf>
   <form>morálka</form>
   <lemma>morálka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d-id107440-punct">
   <w.rf>
    <LM>w#w-d-id107440-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1329-4">
   <w.rf>
    <LM>w#w-d1t1329-4</LM>
   </w.rf>
   <form>skautský</form>
   <lemma>skautský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-d1t1329-5">
   <w.rf>
    <LM>w#w-d1t1329-5</LM>
   </w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d-id107480-punct">
   <w.rf>
    <LM>w#w-d-id107480-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1329-8">
   <w.rf>
    <LM>w#w-d1t1329-8</LM>
   </w.rf>
   <form>myšlenka</form>
   <lemma>myšlenka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d1t1329-9">
   <w.rf>
    <LM>w#w-d1t1329-9</LM>
   </w.rf>
   <form>skautingu</form>
   <lemma>skauting</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m100-d-id107535-punct">
   <w.rf>
    <LM>w#w-d-id107535-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1329-12">
   <w.rf>
    <LM>w#w-d1t1329-12</LM>
   </w.rf>
   <form>skautská</form>
   <lemma>skautský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m100-d1t1329-11">
   <w.rf>
    <LM>w#w-d1t1329-11</LM>
   </w.rf>
   <form>přísaha</form>
   <lemma>přísaha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m100-d1t1329-13">
   <w.rf>
    <LM>w#w-d1t1329-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1329-14">
   <w.rf>
    <LM>w#w-d1t1329-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1329-15">
   <w.rf>
    <LM>w#w-d1t1329-15</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-203-205">
   <w.rf>
    <LM>w#w-203-205</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-207">
  <m id="m100-d1t1329-17">
   <w.rf>
    <LM>w#w-d1t1329-17</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1329-18">
   <w.rf>
    <LM>w#w-d1t1329-18</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m100-d-id107661-punct">
   <w.rf>
    <LM>w#w-d-id107661-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1329-20">
   <w.rf>
    <LM>w#w-d1t1329-20</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m100-d1t1331-1">
   <w.rf>
    <LM>w#w-d1t1331-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1331-2">
   <w.rf>
    <LM>w#w-d1t1331-2</LM>
   </w.rf>
   <form>děje</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1331-3">
   <w.rf>
    <LM>w#w-d1t1331-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1331-4">
   <w.rf>
    <LM>w#w-d1t1331-4</LM>
   </w.rf>
   <form>dobrých</form>
   <lemma>dobrý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m100-d1t1331-5">
   <w.rf>
    <LM>w#w-d1t1331-5</LM>
   </w.rf>
   <form>skautských</form>
   <lemma>skautský</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m100-d1t1331-6">
   <w.rf>
    <LM>w#w-d1t1331-6</LM>
   </w.rf>
   <form>oddílech</form>
   <lemma>oddíl</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m100-d-id107787-punct">
   <w.rf>
    <LM>w#w-d-id107787-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1331-10">
   <w.rf>
    <LM>w#w-d1t1331-10</LM>
   </w.rf>
   <form>všecky</form>
   <lemma>všecek</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m100-d1t1331-9">
   <w.rf>
    <LM>w#w-d1t1331-9</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m100-d1t1331-11">
   <w.rf>
    <LM>w#w-d1t1331-11</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m100-d1e1309-x3-223">
   <w.rf>
    <LM>w#w-d1e1309-x3-223</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1338-3">
   <w.rf>
    <LM>w#w-d1t1338-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m100-d1t1338-5">
   <w.rf>
    <LM>w#w-d1t1338-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1338-4">
   <w.rf>
    <LM>w#w-d1t1338-4</LM>
   </w.rf>
   <form>ovlivní</form>
   <lemma>ovlivnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m100-d1e1309-x3-224">
   <w.rf>
    <LM>w#w-d1e1309-x3-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-226">
  <m id="m100-d1t1338-11">
   <w.rf>
    <LM>w#w-d1t1338-11</LM>
   </w.rf>
   <form>Nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1t1338-12">
   <w.rf>
    <LM>w#w-d1t1338-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1338-13">
   <w.rf>
    <LM>w#w-d1t1338-13</LM>
   </w.rf>
   <form>nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m100-d1t1338-9">
   <w.rf>
    <LM>w#w-d1t1338-9</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m100-d1t1338-10">
   <w.rf>
    <LM>w#w-d1t1338-10</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1338-7">
   <w.rf>
    <LM>w#w-d1t1338-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1340-1">
   <w.rf>
    <LM>w#w-d1t1340-1</LM>
   </w.rf>
   <form>vyprávět</form>
   <lemma>vyprávět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m100-d-id108110-punct">
   <w.rf>
    <LM>w#w-d-id108110-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1340-3">
   <w.rf>
    <LM>w#w-d1t1340-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1340-4">
   <w.rf>
    <LM>w#w-d1t1340-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1340-5">
   <w.rf>
    <LM>w#w-d1t1340-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1340-6">
   <w.rf>
    <LM>w#w-d1t1340-6</LM>
   </w.rf>
   <form>stal</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1340-7">
   <w.rf>
    <LM>w#w-d1t1340-7</LM>
   </w.rf>
   <form>čestnějším</form>
   <lemma>čestný</lemma>
   <tag>AAMS7----2A----</tag>
  </m>
  <m id="m100-226-232">
   <w.rf>
    <LM>w#w-226-232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1340-13">
   <w.rf>
    <LM>w#w-d1t1340-13</LM>
   </w.rf>
   <form>pravdomluvnějším</form>
   <lemma>pravdomluvný</lemma>
   <tag>AAMS7----2A----</tag>
  </m>
  <m id="m100-226-233">
   <w.rf>
    <LM>w#w-226-233</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1340-15">
   <w.rf>
    <LM>w#w-d1t1340-15</LM>
   </w.rf>
   <form>rovnějším</form>
   <lemma>rovný_^(přímý,_stejný,_spravedlivý)</lemma>
   <tag>AAMS7----2A----</tag>
  </m>
  <m id="m100-d1t1340-16">
   <w.rf>
    <LM>w#w-d1t1340-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1340-18">
   <w.rf>
    <LM>w#w-d1t1340-18</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1t1340-20">
   <w.rf>
    <LM>w#w-d1t1340-20</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m100-226-234">
   <w.rf>
    <LM>w#w-226-234</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-235">
  <m id="m100-d1t1342-5">
   <w.rf>
    <LM>w#w-d1t1342-5</LM>
   </w.rf>
   <form>Nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m100-d1t1342-3">
   <w.rf>
    <LM>w#w-d1t1342-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1342-4">
   <w.rf>
    <LM>w#w-d1t1342-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1342-6">
   <w.rf>
    <LM>w#w-d1t1342-6</LM>
   </w.rf>
   <form>vychloubat</form>
   <lemma>vychloubat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m100-d-m-d1e1309-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1309-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1343-x2">
  <m id="m100-d1t1348-1">
   <w.rf>
    <LM>w#w-d1t1348-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m100-d1t1348-2">
   <w.rf>
    <LM>w#w-d1t1348-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m100-d1t1348-3">
   <w.rf>
    <LM>w#w-d1t1348-3</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m100-d1t1348-4">
   <w.rf>
    <LM>w#w-d1t1348-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1348-5">
   <w.rf>
    <LM>w#w-d1t1348-5</LM>
   </w.rf>
   <form>schůzkách</form>
   <lemma>schůzka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m100-d1t1348-6">
   <w.rf>
    <LM>w#w-d1t1348-6</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1348-7">
   <w.rf>
    <LM>w#w-d1t1348-7</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d-id108658-punct">
   <w.rf>
    <LM>w#w-d-id108658-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-d1e1349-x2">
  <m id="m100-d1t1352-3">
   <w.rf>
    <LM>w#w-d1t1352-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m100-d1t1352-4">
   <w.rf>
    <LM>w#w-d1t1352-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m100-d1t1352-5">
   <w.rf>
    <LM>w#w-d1t1352-5</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1352-6">
   <w.rf>
    <LM>w#w-d1t1352-6</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m100-d1e1349-x2-246">
   <w.rf>
    <LM>w#w-d1e1349-x2-246</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-247">
  <m id="m100-d1t1352-11">
   <w.rf>
    <LM>w#w-d1t1352-11</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m100-d1t1352-12">
   <w.rf>
    <LM>w#w-d1t1352-12</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m100-d1t1352-15">
   <w.rf>
    <LM>w#w-d1t1352-15</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m100-d1t1352-16">
   <w.rf>
    <LM>w#w-d1t1352-16</LM>
   </w.rf>
   <form>hry</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m100-247-248">
   <w.rf>
    <LM>w#w-247-248</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-249">
  <m id="m100-d1t1354-2">
   <w.rf>
    <LM>w#w-d1t1354-2</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1354-3">
   <w.rf>
    <LM>w#w-d1t1354-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m100-d-id109008-punct">
   <w.rf>
    <LM>w#w-d-id109008-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1354-5">
   <w.rf>
    <LM>w#w-d1t1354-5</LM>
   </w.rf>
   <form>uvědomte</form>
   <lemma>uvědomit</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m100-d1t1354-6">
   <w.rf>
    <LM>w#w-d1t1354-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m100-d-id109048-punct">
   <w.rf>
    <LM>w#w-d-id109048-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1354-8">
   <w.rf>
    <LM>w#w-d1t1354-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1354-9">
   <w.rf>
    <LM>w#w-d1t1354-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1354-10">
   <w.rf>
    <LM>w#w-d1t1354-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m100-d1t1354-11">
   <w.rf>
    <LM>w#w-d1t1354-11</LM>
   </w.rf>
   <form>82</form>
   <lemma>82</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-249-1009">
   <w.rf>
    <LM>w#w-249-1009</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-1010">
  <m id="m100-d1t1356-2">
   <w.rf>
    <LM>w#w-d1t1356-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1356-3">
   <w.rf>
    <LM>w#w-d1t1356-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1356-7">
   <w.rf>
    <LM>w#w-d1t1356-7</LM>
   </w.rf>
   <form>přestal</form>
   <lemma>přestat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1356-8">
   <w.rf>
    <LM>w#w-d1t1356-8</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m100-d1t1356-9">
   <w.rf>
    <LM>w#w-d1t1356-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1356-10">
   <w.rf>
    <LM>w#w-d1t1356-10</LM>
   </w.rf>
   <form>skautingu</form>
   <lemma>skauting</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m100-d-id109307-punct">
   <w.rf>
    <LM>w#w-d-id109307-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1358-2">
   <w.rf>
    <LM>w#w-d1t1358-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1360-13">
   <w.rf>
    <LM>w#w-d1t1360-13</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m100-d1t1360-14">
   <w.rf>
    <LM>w#w-d1t1360-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1365-1">
   <w.rf>
    <LM>w#w-d1t1365-1</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m100-249-287">
   <w.rf>
    <LM>w#w-249-287</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1365-2">
   <w.rf>
    <LM>w#w-d1t1365-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1365-3">
   <w.rf>
    <LM>w#w-d1t1365-3</LM>
   </w.rf>
   <form>kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m100-249-251">
   <w.rf>
    <LM>w#w-249-251</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-252">
  <m id="m100-d1t1365-6">
   <w.rf>
    <LM>w#w-d1t1365-6</LM>
   </w.rf>
   <form>Narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m100-d1t1365-7">
   <w.rf>
    <LM>w#w-d1t1365-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1365-8">
   <w.rf>
    <LM>w#w-d1t1365-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-252-253">
   <w.rf>
    <LM>w#w-252-253</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-252-254">
   <w.rf>
    <LM>w#w-252-254</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m100-d1t1365-9">
   <w.rf>
    <LM>w#w-d1t1365-9</LM>
   </w.rf>
   <form>1927</form>
   <lemma>1927</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-252-255">
   <w.rf>
    <LM>w#w-252-255</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-257">
  <m id="m100-257-258">
   <w.rf>
    <LM>w#w-257-258</LM>
   </w.rf>
   <form>27</form>
   <lemma>27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-d1t1365-11">
   <w.rf>
    <LM>w#w-d1t1365-11</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1365-12">
   <w.rf>
    <LM>w#w-d1t1365-12</LM>
   </w.rf>
   <form>46</form>
   <lemma>46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m100-d1t1365-14">
   <w.rf>
    <LM>w#w-d1t1365-14</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m100-d1t1365-15">
   <w.rf>
    <LM>w#w-d1t1365-15</LM>
   </w.rf>
   <form>devatenáct</form>
   <lemma>devatenáct`19</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m100-d1e1349-x4-286">
   <w.rf>
    <LM>w#w-d1e1349-x4-286</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-1022">
  <m id="m100-d1t1369-2">
   <w.rf>
    <LM>w#w-d1t1369-2</LM>
   </w.rf>
   <form>Oddíl</form>
   <lemma>oddíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d-id109943-punct">
   <w.rf>
    <LM>w#w-d-id109943-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1369-4">
   <w.rf>
    <LM>w#w-d1t1369-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1369-5">
   <w.rf>
    <LM>w#w-d1t1369-5</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m100-d1t1369-6">
   <w.rf>
    <LM>w#w-d1t1369-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1369-7">
   <w.rf>
    <LM>w#w-d1t1369-7</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d1t1369-8">
   <w.rf>
    <LM>w#w-d1t1369-8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1369-9">
   <w.rf>
    <LM>w#w-d1t1369-9</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m100-d1e1349-x4-298">
   <w.rf>
    <LM>w#w-d1e1349-x4-298</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1371-3">
   <w.rf>
    <LM>w#w-d1t1371-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m100-d1t1371-4">
   <w.rf>
    <LM>w#w-d1t1371-4</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-d1e1349-x4-299">
   <w.rf>
    <LM>w#w-d1e1349-x4-299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-300">
  <m id="m100-d1t1371-7">
   <w.rf>
    <LM>w#w-d1t1371-7</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-d1t1371-8">
   <w.rf>
    <LM>w#w-d1t1371-8</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-d-id110171-punct">
   <w.rf>
    <LM>w#w-d-id110171-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1371-10">
   <w.rf>
    <LM>w#w-d1t1371-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m100-d1t1371-11">
   <w.rf>
    <LM>w#w-d1t1371-11</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m100-d1t1371-12">
   <w.rf>
    <LM>w#w-d1t1371-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1371-13">
   <w.rf>
    <LM>w#w-d1t1371-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m100-d-id110241-punct">
   <w.rf>
    <LM>w#w-d-id110241-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m100-d1t1373-4">
   <w.rf>
    <LM>w#w-d1t1373-4</LM>
   </w.rf>
   <form>skautský</form>
   <lemma>skautský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m100-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m100-300-301">
   <w.rf>
    <LM>w#w-300-301</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-302">
  <m id="m100-d1t1380-1">
   <w.rf>
    <LM>w#w-d1t1380-1</LM>
   </w.rf>
   <form>Vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m100-d1t1380-3">
   <w.rf>
    <LM>w#w-d1t1380-3</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m100-d1t1380-4">
   <w.rf>
    <LM>w#w-d1t1380-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m100-d1t1380-5">
   <w.rf>
    <LM>w#w-d1t1380-5</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1380-6">
   <w.rf>
    <LM>w#w-d1t1380-6</LM>
   </w.rf>
   <form>nezvládl</form>
   <lemma>zvládnout</lemma>
   <tag>VpYS----R-NAP-1</tag>
  </m>
  <m id="m100-302-307">
   <w.rf>
    <LM>w#w-302-307</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-308">
  <m id="m100-d1t1382-4">
   <w.rf>
    <LM>w#w-d1t1382-4</LM>
   </w.rf>
   <form>Děly</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m100-d1t1382-3">
   <w.rf>
    <LM>w#w-d1t1382-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m100-d1t1382-2">
   <w.rf>
    <LM>w#w-d1t1382-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1382-5">
   <w.rf>
    <LM>w#w-d1t1382-5</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m100-d1t1384-1">
   <w.rf>
    <LM>w#w-d1t1384-1</LM>
   </w.rf>
   <form>nedobré</form>
   <lemma>dobrý</lemma>
   <tag>AAFP1----1N----</tag>
  </m>
  <m id="m100-d1t1384-2">
   <w.rf>
    <LM>w#w-d1t1384-2</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m100-308-309">
   <w.rf>
    <LM>w#w-308-309</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m100-310">
  <m id="m100-d1t1395-2">
   <w.rf>
    <LM>w#w-d1t1395-2</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1395-3">
   <w.rf>
    <LM>w#w-d1t1395-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m100-d-id110867-punct">
   <w.rf>
    <LM>w#w-d-id110867-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1395-5">
   <w.rf>
    <LM>w#w-d1t1395-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1395-6">
   <w.rf>
    <LM>w#w-d1t1395-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m100-d1t1395-7">
   <w.rf>
    <LM>w#w-d1t1395-7</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m100-d1t1395-8">
   <w.rf>
    <LM>w#w-d1t1395-8</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m100-d-id110938-punct">
   <w.rf>
    <LM>w#w-d-id110938-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1397-1">
   <w.rf>
    <LM>w#w-d1t1397-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1397-2">
   <w.rf>
    <LM>w#w-d1t1397-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1397-3">
   <w.rf>
    <LM>w#w-d1t1397-3</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d-id111002-punct">
   <w.rf>
    <LM>w#w-d-id111002-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-d1t1397-5">
   <w.rf>
    <LM>w#w-d1t1397-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m100-d1t1397-6">
   <w.rf>
    <LM>w#w-d1t1397-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m100-d1t1397-7">
   <w.rf>
    <LM>w#w-d1t1397-7</LM>
   </w.rf>
   <form>tohohle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m100-d1t1397-8">
   <w.rf>
    <LM>w#w-d1t1397-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1397-9">
   <w.rf>
    <LM>w#w-d1t1397-9</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m100-d1t1397-10">
   <w.rf>
    <LM>w#w-d1t1397-10</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m100-d-id111104-punct">
   <w.rf>
    <LM>w#w-d-id111104-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m100-310-321">
   <w.rf>
    <LM>w#w-310-321</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m100-d1t1402-1">
   <w.rf>
    <LM>w#w-d1t1402-1</LM>
   </w.rf>
   <form>povalili</form>
   <lemma>povalit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m100-d1t1402-2">
   <w.rf>
    <LM>w#w-d1t1402-2</LM>
   </w.rf>
   <form>stožár</form>
   <lemma>stožár</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m100-d1t1402-3">
   <w.rf>
    <LM>w#w-d1t1402-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m100-d1t1402-4">
   <w.rf>
    <LM>w#w-d1t1402-4</LM>
   </w.rf>
   <form>rozřezali</form>
   <lemma>rozřezat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m100-d1t1402-5">
   <w.rf>
    <LM>w#w-d1t1402-5</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m100-d1t1402-6">
   <w.rf>
    <LM>w#w-d1t1402-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m100-d1t1402-7">
   <w.rf>
    <LM>w#w-d1t1402-7</LM>
   </w.rf>
   <form>kusy</form>
   <lemma>kus</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m100-d1e1349-x5-322">
   <w.rf>
    <LM>w#w-d1e1349-x5-322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
