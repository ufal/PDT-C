<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_784.00.w.gz" />
  </references>
 </head>
 <s id="m784-27638_04-d1e8-x2">
  <m id="m784-d1t15-1">
   <w.rf>
    <LM>w#w-d1t15-1</LM>
   </w.rf>
   <form>Skončili</form>
   <lemma>skončit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t15-2">
   <w.rf>
    <LM>w#w-d1t15-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t15-3">
   <w.rf>
    <LM>w#w-d1t15-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m784-d-id54970">
   <w.rf>
    <LM>w#w-d-id54970</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t15-5">
   <w.rf>
    <LM>w#w-d1t15-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t15-6">
   <w.rf>
    <LM>w#w-d1t15-6</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m784-d1t17-1">
   <w.rf>
    <LM>w#w-d1t17-1</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m784-d1t17-2">
   <w.rf>
    <LM>w#w-d1t17-2</LM>
   </w.rf>
   <form>zdravotních</form>
   <lemma>zdravotní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m784-d1t17-3">
   <w.rf>
    <LM>w#w-d1t17-3</LM>
   </w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1t19-9">
   <w.rf>
    <LM>w#w-d1t19-9</LM>
   </w.rf>
   <form>doporučili</form>
   <lemma>doporučit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1e8-x2-44">
   <w.rf>
    <LM>w#w-d1e8-x2-44</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t17-6">
   <w.rf>
    <LM>w#w-d1t17-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t17-7">
   <w.rf>
    <LM>w#w-d1t17-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t17-8">
   <w.rf>
    <LM>w#w-d1t17-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t19-2">
   <w.rf>
    <LM>w#w-d1t19-2</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t19-3">
   <w.rf>
    <LM>w#w-d1t19-3</LM>
   </w.rf>
   <form>formuloval</form>
   <lemma>formulovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m784-d-id55172">
   <w.rf>
    <LM>w#w-d-id55172</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t19-7">
   <w.rf>
    <LM>w#w-d1t19-7</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t19-6">
   <w.rf>
    <LM>w#w-d1t19-6</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1e8-x2-950">
   <w.rf>
    <LM>w#w-d1e8-x2-950</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t19-10">
   <w.rf>
    <LM>w#w-d1t19-10</LM>
   </w.rf>
   <form>zemědělce</form>
   <lemma>zemědělec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m784-d1e8-x2-46">
   <w.rf>
    <LM>w#w-d1e8-x2-46</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t22-1">
   <w.rf>
    <LM>w#w-d1t22-1</LM>
   </w.rf>
   <form>havíře</form>
   <lemma>havíř</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m784-d1t22-2">
   <w.rf>
    <LM>w#w-d1t22-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t24-1">
   <w.rf>
    <LM>w#w-d1t24-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t26-1">
   <w.rf>
    <LM>w#w-d1t26-1</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m784-d1e8-x2-48">
   <w.rf>
    <LM>w#w-d1e8-x2-48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-49">
  <m id="m784-d1t26-2">
   <w.rf>
    <LM>w#w-d1t26-2</LM>
   </w.rf>
   <form>Doporučili</form>
   <lemma>doporučit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t26-3">
   <w.rf>
    <LM>w#w-d1t26-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t32-1">
   <w.rf>
    <LM>w#w-d1t32-1</LM>
   </w.rf>
   <form>nedoporučili</form>
   <lemma>doporučit</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m784-49-124">
   <w.rf>
    <LM>w#w-49-124</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e27-x3">
  <m id="m784-d1t34-1">
   <w.rf>
    <LM>w#w-d1t34-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e27-x3-302">
   <w.rf>
    <LM>w#w-d1e27-x3-302</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t34-8">
   <w.rf>
    <LM>w#w-d1t34-8</LM>
   </w.rf>
   <form>mylně</form>
   <lemma>mylně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t34-6">
   <w.rf>
    <LM>w#w-d1t34-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t34-9">
   <w.rf>
    <LM>w#w-d1t34-9</LM>
   </w.rf>
   <form>informoval</form>
   <lemma>informovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m784-d-id55434">
   <w.rf>
    <LM>w#w-d-id55434</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e35-x2">
  <m id="m784-d1t40-3">
   <w.rf>
    <LM>w#w-d1t40-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m784-d1t40-4">
   <w.rf>
    <LM>w#w-d1t40-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m784-d1t40-5">
   <w.rf>
    <LM>w#w-d1t40-5</LM>
   </w.rf>
   <form>možnosti</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1t40-6">
   <w.rf>
    <LM>w#w-d1t40-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t40-7">
   <w.rf>
    <LM>w#w-d1t40-7</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSNS4-S1------1</tag>
  </m>
  <m id="m784-d1t40-8">
   <w.rf>
    <LM>w#w-d1t40-8</LM>
   </w.rf>
   <form>učení</form>
   <lemma>učení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e35-x2-956">
   <w.rf>
    <LM>w#w-d1e35-x2-956</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-957">
  <m id="m784-d1t44-2">
   <w.rf>
    <LM>w#w-d1t44-2</LM>
   </w.rf>
   <form>Sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t44-3">
   <w.rf>
    <LM>w#w-d1t44-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t44-4">
   <w.rf>
    <LM>w#w-d1t44-4</LM>
   </w.rf>
   <form>odjakživa</form>
   <lemma>odjakživa</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t44-5">
   <w.rf>
    <LM>w#w-d1t44-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t44-6">
   <w.rf>
    <LM>w#w-d1t44-6</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m784-d1t46-1">
   <w.rf>
    <LM>w#w-d1t46-1</LM>
   </w.rf>
   <form>elektrotechniku</form>
   <lemma>elektrotechnika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e35-x2-472">
   <w.rf>
    <LM>w#w-d1e35-x2-472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t51-1">
   <w.rf>
    <LM>w#w-d1t51-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t51-2">
   <w.rf>
    <LM>w#w-d1t51-2</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t51-3">
   <w.rf>
    <LM>w#w-d1t51-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t51-4">
   <w.rf>
    <LM>w#w-d1t51-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t51-6">
   <w.rf>
    <LM>w#w-d1t51-6</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t51-7">
   <w.rf>
    <LM>w#w-d1t51-7</LM>
   </w.rf>
   <form>učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t51-10">
   <w.rf>
    <LM>w#w-d1t51-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t51-11">
   <w.rf>
    <LM>w#w-d1t51-11</LM>
   </w.rf>
   <form>Přerovských</form>
   <lemma>přerovský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m784-d1t51-12">
   <w.rf>
    <LM>w#w-d1t51-12</LM>
   </w.rf>
   <form>strojíren</form>
   <lemma>strojírna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-d1t51-13">
   <w.rf>
    <LM>w#w-d1t51-13</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t51-16">
   <w.rf>
    <LM>w#w-d1t51-16</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t51-14">
   <w.rf>
    <LM>w#w-d1t51-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t51-15">
   <w.rf>
    <LM>w#w-d1t51-15</LM>
   </w.rf>
   <form>Přerova</form>
   <lemma>Přerov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e35-x2-475">
   <w.rf>
    <LM>w#w-d1e35-x2-475</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t55-1">
   <w.rf>
    <LM>w#w-d1t55-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t55-2">
   <w.rf>
    <LM>w#w-d1t55-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t55-3">
   <w.rf>
    <LM>w#w-d1t55-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m784-d1t55-4">
   <w.rf>
    <LM>w#w-d1t55-4</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t55-5">
   <w.rf>
    <LM>w#w-d1t55-5</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t55-7">
   <w.rf>
    <LM>w#w-d1t55-7</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t55-6">
   <w.rf>
    <LM>w#w-d1t55-6</LM>
   </w.rf>
   <form>podnájem</form>
   <lemma>podnájem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id56277">
   <w.rf>
    <LM>w#w-d-id56277</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e35-x4">
  <m id="m784-d1t62-8">
   <w.rf>
    <LM>w#w-d1t62-8</LM>
   </w.rf>
   <form>Prostředků</form>
   <lemma>prostředek_^(střed,způsob,_nástroj)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1t62-9">
   <w.rf>
    <LM>w#w-d1t62-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t62-10">
   <w.rf>
    <LM>w#w-d1t62-10</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m784-d1t62-11">
   <w.rf>
    <LM>w#w-d1t62-11</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m784-d1t62-14">
   <w.rf>
    <LM>w#w-d1t62-14</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t62-15">
   <w.rf>
    <LM>w#w-d1t62-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t62-16">
   <w.rf>
    <LM>w#w-d1t62-16</LM>
   </w.rf>
   <form>mysleli</form>
   <lemma>myslit</lemma>
   <tag>VpMP----R-AAI-1</tag>
  </m>
  <m id="m784-d-id56547">
   <w.rf>
    <LM>w#w-d-id56547</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t62-18">
   <w.rf>
    <LM>w#w-d1t62-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t62-19">
   <w.rf>
    <LM>w#w-d1t62-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t62-20">
   <w.rf>
    <LM>w#w-d1t62-20</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t62-21">
   <w.rf>
    <LM>w#w-d1t62-21</LM>
   </w.rf>
   <form>zbytečné</form>
   <lemma>zbytečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1e35-x4-606">
   <w.rf>
    <LM>w#w-d1e35-x4-606</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t64-1">
   <w.rf>
    <LM>w#w-d1t64-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t64-2">
   <w.rf>
    <LM>w#w-d1t64-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t64-3">
   <w.rf>
    <LM>w#w-d1t64-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t64-4">
   <w.rf>
    <LM>w#w-d1t64-4</LM>
   </w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d1t64-5">
   <w.rf>
    <LM>w#w-d1t64-5</LM>
   </w.rf>
   <form>zadarmo</form>
   <lemma>zadarmo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id56704">
   <w.rf>
    <LM>w#w-d-id56704</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e35-x5">
  <m id="m784-d1t70-1">
   <w.rf>
    <LM>w#w-d1t70-1</LM>
   </w.rf>
   <form>Horníka</form>
   <lemma>horník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1t70-3">
   <w.rf>
    <LM>w#w-d1t70-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t70-4">
   <w.rf>
    <LM>w#w-d1t70-4</LM>
   </w.rf>
   <form>nedoporučil</form>
   <lemma>doporučit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1t70-5">
   <w.rf>
    <LM>w#w-d1t70-5</LM>
   </w.rf>
   <form>pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t70-6">
   <w.rf>
    <LM>w#w-d1t70-6</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id56833">
   <w.rf>
    <LM>w#w-d-id56833</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t70-8">
   <w.rf>
    <LM>w#w-d1t70-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t70-9">
   <w.rf>
    <LM>w#w-d1t70-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t70-10">
   <w.rf>
    <LM>w#w-d1t70-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t70-11">
   <w.rf>
    <LM>w#w-d1t70-11</LM>
   </w.rf>
   <form>nedomykavost</form>
   <lemma>nedomykavost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t70-12">
   <w.rf>
    <LM>w#w-d1t70-12</LM>
   </w.rf>
   <form>chlopní</form>
   <lemma>chlopeň</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-d-id56919">
   <w.rf>
    <LM>w#w-d-id56919</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t70-14">
   <w.rf>
    <LM>w#w-d1t70-14</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t70-15">
   <w.rf>
    <LM>w#w-d1t70-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t75-1">
   <w.rf>
    <LM>w#w-d1t75-1</LM>
   </w.rf>
   <form>naznačil</form>
   <lemma>naznačit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d-id57036">
   <w.rf>
    <LM>w#w-d-id57036</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e35-x6">
  <m id="m784-d1t83-1">
   <w.rf>
    <LM>w#w-d1t83-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t83-2">
   <w.rf>
    <LM>w#w-d1t83-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t83-3">
   <w.rf>
    <LM>w#w-d1t83-3</LM>
   </w.rf>
   <form>nedoporučil</form>
   <lemma>doporučit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1e35-x6-742">
   <w.rf>
    <LM>w#w-d1e35-x6-742</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t88-1">
   <w.rf>
    <LM>w#w-d1t88-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t88-2">
   <w.rf>
    <LM>w#w-d1t88-2</LM>
   </w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t88-3">
   <w.rf>
    <LM>w#w-d1t88-3</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t88-4">
   <w.rf>
    <LM>w#w-d1t88-4</LM>
   </w.rf>
   <form>oboustrannému</form>
   <lemma>oboustranný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m784-d1t88-5">
   <w.rf>
    <LM>w#w-d1t88-5</LM>
   </w.rf>
   <form>zánětu</form>
   <lemma>zánět</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m784-d1t88-6">
   <w.rf>
    <LM>w#w-d1t88-6</LM>
   </w.rf>
   <form>středního</form>
   <lemma>střední</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m784-d1t88-7">
   <w.rf>
    <LM>w#w-d1t88-7</LM>
   </w.rf>
   <form>ucha</form>
   <lemma>ucho-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t88-9">
   <w.rf>
    <LM>w#w-d1t88-9</LM>
   </w.rf>
   <form>nechtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m784-d-id57282">
   <w.rf>
    <LM>w#w-d-id57282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t88-11">
   <w.rf>
    <LM>w#w-d1t88-11</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m784-d1t88-13">
   <w.rf>
    <LM>w#w-d1t88-13</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1e35-x6-743">
   <w.rf>
    <LM>w#w-d1e35-x6-743</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m784-d1t88-14">
   <w.rf>
    <LM>w#w-d1t88-14</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t88-15">
   <w.rf>
    <LM>w#w-d1t88-15</LM>
   </w.rf>
   <form>prašném</form>
   <lemma>prašný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m784-d1t88-16">
   <w.rf>
    <LM>w#w-d1t88-16</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1e35-x6-745">
   <w.rf>
    <LM>w#w-d1e35-x6-745</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-746">
  <m id="m784-d1t90-1">
   <w.rf>
    <LM>w#w-d1t90-1</LM>
   </w.rf>
   <form>Zemědělství</form>
   <lemma>zemědělství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t90-7">
   <w.rf>
    <LM>w#w-d1t90-7</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t90-8">
   <w.rf>
    <LM>w#w-d1t90-8</LM>
   </w.rf>
   <form>nechtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m784-d1t90-4">
   <w.rf>
    <LM>w#w-d1t90-4</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t90-6">
   <w.rf>
    <LM>w#w-d1t90-6</LM>
   </w.rf>
   <form>sluníčku</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m784-d-id57527">
   <w.rf>
    <LM>w#w-d-id57527</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t90-10">
   <w.rf>
    <LM>w#w-d1t90-10</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m784-d1t90-11">
   <w.rf>
    <LM>w#w-d1t90-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t90-13">
   <w.rf>
    <LM>w#w-d1t90-13</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t90-12">
   <w.rf>
    <LM>w#w-d1t90-12</LM>
   </w.rf>
   <form>nevystavoval</form>
   <lemma>vystavovat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-746-756">
   <w.rf>
    <LM>w#w-746-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-757">
  <m id="m784-d1t92-4">
   <w.rf>
    <LM>w#w-d1t92-4</LM>
   </w.rf>
   <form>Zbylo</form>
   <lemma>zbýt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m784-d1t92-3">
   <w.rf>
    <LM>w#w-d1t92-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t94-1">
   <w.rf>
    <LM>w#w-d1t94-1</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t94-2">
   <w.rf>
    <LM>w#w-d1t94-2</LM>
   </w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1t94-3">
   <w.rf>
    <LM>w#w-d1t94-3</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-757-769">
   <w.rf>
    <LM>w#w-757-769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t94-4">
   <w.rf>
    <LM>w#w-d1t94-4</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t94-5">
   <w.rf>
    <LM>w#w-d1t94-5</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id57742">
   <w.rf>
    <LM>w#w-d-id57742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e95-x2">
  <m id="m784-d1t98-2">
   <w.rf>
    <LM>w#w-d1t98-2</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t98-3">
   <w.rf>
    <LM>w#w-d1t98-3</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t98-4">
   <w.rf>
    <LM>w#w-d1t98-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t98-5">
   <w.rf>
    <LM>w#w-d1t98-5</LM>
   </w.rf>
   <form>Uničově</form>
   <lemma>Uničov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1e95-x2-873">
   <w.rf>
    <LM>w#w-d1e95-x2-873</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t98-6">
   <w.rf>
    <LM>w#w-d1t98-6</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m784-d1t98-7">
   <w.rf>
    <LM>w#w-d1t98-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1e95-x2-875">
   <w.rf>
    <LM>w#w-d1e95-x2-875</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t98-8">
   <w.rf>
    <LM>w#w-d1t98-8</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t98-9">
   <w.rf>
    <LM>w#w-d1t98-9</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d-id57920">
   <w.rf>
    <LM>w#w-d-id57920</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e99-x2">
  <m id="m784-d1t102-3">
   <w.rf>
    <LM>w#w-d1t102-3</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t102-2">
   <w.rf>
    <LM>w#w-d1t102-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t106-3">
   <w.rf>
    <LM>w#w-d1t106-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t102-4">
   <w.rf>
    <LM>w#w-d1t102-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t106-1">
   <w.rf>
    <LM>w#w-d1t106-1</LM>
   </w.rf>
   <form>Bruntále</form>
   <lemma>Bruntál_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t110-1">
   <w.rf>
    <LM>w#w-d1t110-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t110-2">
   <w.rf>
    <LM>w#w-d1t110-2</LM>
   </w.rf>
   <form>nejbližší</form>
   <lemma>blízký</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m784-d1t110-3">
   <w.rf>
    <LM>w#w-d1t110-3</LM>
   </w.rf>
   <form>učební</form>
   <lemma>učební</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m784-d1t110-4">
   <w.rf>
    <LM>w#w-d1t110-4</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1t110-5">
   <w.rf>
    <LM>w#w-d1t110-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m784-d1t110-6">
   <w.rf>
    <LM>w#w-d1t110-6</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t110-7">
   <w.rf>
    <LM>w#w-d1t110-7</LM>
   </w.rf>
   <form>Uničovské</form>
   <lemma>uničovský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m784-d1t110-8">
   <w.rf>
    <LM>w#w-d1t110-8</LM>
   </w.rf>
   <form>strojírny</form>
   <lemma>strojírna</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1e99-x2-990">
   <w.rf>
    <LM>w#w-d1e99-x2-990</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-991">
  <m id="m784-d1t110-10">
   <w.rf>
    <LM>w#w-d1t110-10</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m784-d1t110-9">
   <w.rf>
    <LM>w#w-d1t110-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t110-11">
   <w.rf>
    <LM>w#w-d1t110-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t110-12">
   <w.rf>
    <LM>w#w-d1t110-12</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1e99-x2-1076">
   <w.rf>
    <LM>w#w-d1e99-x2-1076</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t113-1">
   <w.rf>
    <LM>w#w-d1t113-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t113-2">
   <w.rf>
    <LM>w#w-d1t113-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t113-3">
   <w.rf>
    <LM>w#w-d1t113-3</LM>
   </w.rf>
   <form>internát</form>
   <lemma>internát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1e99-x2-1077">
   <w.rf>
    <LM>w#w-d1e99-x2-1077</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1033">
  <m id="m784-d1t115-1">
   <w.rf>
    <LM>w#w-d1t115-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t115-2">
   <w.rf>
    <LM>w#w-d1t115-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t115-4">
   <w.rf>
    <LM>w#w-d1t115-4</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m784-d1t115-5">
   <w.rf>
    <LM>w#w-d1t115-5</LM>
   </w.rf>
   <form>pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-1033-1081">
   <w.rf>
    <LM>w#w-1033-1081</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t115-6">
   <w.rf>
    <LM>w#w-d1t115-6</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m784-1033-1082">
   <w.rf>
    <LM>w#w-1033-1082</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t117-1">
   <w.rf>
    <LM>w#w-d1t117-1</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1t117-2">
   <w.rf>
    <LM>w#w-d1t117-2</LM>
   </w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-1033-1083">
   <w.rf>
    <LM>w#w-1033-1083</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t117-3">
   <w.rf>
    <LM>w#w-d1t117-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t117-4">
   <w.rf>
    <LM>w#w-d1t117-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m784-d1t117-5">
   <w.rf>
    <LM>w#w-d1t117-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t117-6">
   <w.rf>
    <LM>w#w-d1t117-6</LM>
   </w.rf>
   <form>naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m784-d1t121-1">
   <w.rf>
    <LM>w#w-d1t121-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t121-2">
   <w.rf>
    <LM>w#w-d1t121-2</LM>
   </w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t117-7">
   <w.rf>
    <LM>w#w-d1t117-7</LM>
   </w.rf>
   <form>odvezli</form>
   <lemma>odvézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d-id58662">
   <w.rf>
    <LM>w#w-d-id58662</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e99-x5">
  <m id="m784-d1t128-3">
   <w.rf>
    <LM>w#w-d1t128-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t128-4">
   <w.rf>
    <LM>w#w-d1t128-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t128-5">
   <w.rf>
    <LM>w#w-d1t128-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t128-6">
   <w.rf>
    <LM>w#w-d1t128-6</LM>
   </w.rf>
   <form>učil</form>
   <lemma>učit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t128-7">
   <w.rf>
    <LM>w#w-d1t128-7</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t128-8">
   <w.rf>
    <LM>w#w-d1t128-8</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d-id58892">
   <w.rf>
    <LM>w#w-d-id58892</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t130-1">
   <w.rf>
    <LM>w#w-d1t130-1</LM>
   </w.rf>
   <form>učební</form>
   <lemma>učební</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m784-d1t130-2">
   <w.rf>
    <LM>w#w-d1t130-2</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t130-3">
   <w.rf>
    <LM>w#w-d1t130-3</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t130-4">
   <w.rf>
    <LM>w#w-d1t130-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t130-5">
   <w.rf>
    <LM>w#w-d1t130-5</LM>
   </w.rf>
   <form>absolvoval</form>
   <lemma>absolvovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m784-d1t130-6">
   <w.rf>
    <LM>w#w-d1t130-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t130-7">
   <w.rf>
    <LM>w#w-d1t130-7</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP6----------</tag>
  </m>
  <m id="m784-d1t130-8">
   <w.rf>
    <LM>w#w-d1t130-8</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m784-d-id59034">
   <w.rf>
    <LM>w#w-d-id59034</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e131-x2">
  <m id="m784-d1t134-1">
   <w.rf>
    <LM>w#w-d1t134-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t134-2">
   <w.rf>
    <LM>w#w-d1t134-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id59123">
   <w.rf>
    <LM>w#w-d-id59123</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e135-x2">
  <m id="m784-d1t140-5">
   <w.rf>
    <LM>w#w-d1t140-5</LM>
   </w.rf>
   <form>Učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t140-6">
   <w.rf>
    <LM>w#w-d1t140-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t140-7">
   <w.rf>
    <LM>w#w-d1t140-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t140-8">
   <w.rf>
    <LM>w#w-d1t140-8</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t140-9">
   <w.rf>
    <LM>w#w-d1t140-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t140-10">
   <w.rf>
    <LM>w#w-d1t140-10</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t140-11">
   <w.rf>
    <LM>w#w-d1t140-11</LM>
   </w.rf>
   <form>1954</form>
   <lemma>1954</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e135-x2-1317">
   <w.rf>
    <LM>w#w-d1e135-x2-1317</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t144-1">
   <w.rf>
    <LM>w#w-d1t144-1</LM>
   </w.rf>
   <form>vyučil</form>
   <lemma>vyučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t144-2">
   <w.rf>
    <LM>w#w-d1t144-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t144-3">
   <w.rf>
    <LM>w#w-d1t144-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t144-4">
   <w.rf>
    <LM>w#w-d1t144-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1e135-x2-1319">
   <w.rf>
    <LM>w#w-d1e135-x2-1319</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t144-5">
   <w.rf>
    <LM>w#w-d1t144-5</LM>
   </w.rf>
   <form>1956</form>
   <lemma>1956</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e135-x2-1569">
   <w.rf>
    <LM>w#w-d1e135-x2-1569</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t155-1">
   <w.rf>
    <LM>w#w-d1t155-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t157-1">
   <w.rf>
    <LM>w#w-d1t157-1</LM>
   </w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t157-2">
   <w.rf>
    <LM>w#w-d1t157-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t157-3">
   <w.rf>
    <LM>w#w-d1t157-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t157-4">
   <w.rf>
    <LM>w#w-d1t157-4</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t157-5">
   <w.rf>
    <LM>w#w-d1t157-5</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t157-6">
   <w.rf>
    <LM>w#w-d1t157-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t157-7">
   <w.rf>
    <LM>w#w-d1t157-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t157-8">
   <w.rf>
    <LM>w#w-d1t157-8</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t157-9">
   <w.rf>
    <LM>w#w-d1t157-9</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d-id59763">
   <w.rf>
    <LM>w#w-d-id59763</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t159-1">
   <w.rf>
    <LM>w#w-d1t159-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1e135-x2-1572">
   <w.rf>
    <LM>w#w-d1e135-x2-1572</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t159-2">
   <w.rf>
    <LM>w#w-d1t159-2</LM>
   </w.rf>
   <form>1958</form>
   <lemma>1958</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e135-x2-1578">
   <w.rf>
    <LM>w#w-d1e135-x2-1578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e135-x2-1579">
   <w.rf>
    <LM>w#w-d1e135-x2-1579</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e135-x2-1580">
   <w.rf>
    <LM>w#w-d1e135-x2-1580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1581">
  <m id="m784-d1t164-5">
   <w.rf>
    <LM>w#w-d1t164-5</LM>
   </w.rf>
   <form>Promiňte</form>
   <lemma>prominout</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m784-1581-1593">
   <w.rf>
    <LM>w#w-1581-1593</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-1581-1664">
   <w.rf>
    <LM>w#w-1581-1664</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t166-8">
   <w.rf>
    <LM>w#w-d1t166-8</LM>
   </w.rf>
   <form>1952</form>
   <lemma>1952</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t166-9">
   <w.rf>
    <LM>w#w-d1t166-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t166-10">
   <w.rf>
    <LM>w#w-d1t166-10</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t166-11">
   <w.rf>
    <LM>w#w-d1t166-11</LM>
   </w.rf>
   <form>učební</form>
   <lemma>učební</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m784-d1t166-12">
   <w.rf>
    <LM>w#w-d1t166-12</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-1581-1666">
   <w.rf>
    <LM>w#w-1581-1666</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t168-1">
   <w.rf>
    <LM>w#w-d1t168-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-1581-1660">
   <w.rf>
    <LM>w#w-1581-1660</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t166-7">
   <w.rf>
    <LM>w#w-d1t166-7</LM>
   </w.rf>
   <form>1954</form>
   <lemma>1954</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t168-3">
   <w.rf>
    <LM>w#w-d1t168-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t168-4">
   <w.rf>
    <LM>w#w-d1t168-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t168-5">
   <w.rf>
    <LM>w#w-d1t168-5</LM>
   </w.rf>
   <form>vyučil</form>
   <lemma>vyučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-1581-1012">
   <w.rf>
    <LM>w#w-1581-1012</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1013">
  <m id="m784-d1t170-1">
   <w.rf>
    <LM>w#w-d1t170-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-1581-1671">
   <w.rf>
    <LM>w#w-1581-1671</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t170-2">
   <w.rf>
    <LM>w#w-d1t170-2</LM>
   </w.rf>
   <form>1956</form>
   <lemma>1956</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t170-4">
   <w.rf>
    <LM>w#w-d1t170-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t170-5">
   <w.rf>
    <LM>w#w-d1t170-5</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t170-6">
   <w.rf>
    <LM>w#w-d1t170-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t170-7">
   <w.rf>
    <LM>w#w-d1t170-7</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t172-1">
   <w.rf>
    <LM>w#w-d1t172-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t172-2">
   <w.rf>
    <LM>w#w-d1t172-2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t172-3">
   <w.rf>
    <LM>w#w-d1t172-3</LM>
   </w.rf>
   <form>1958</form>
   <lemma>1958</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d-id60420">
   <w.rf>
    <LM>w#w-d-id60420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e173-x2">
  <m id="m784-d1t176-4">
   <w.rf>
    <LM>w#w-d1t176-4</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t176-5">
   <w.rf>
    <LM>w#w-d1t176-5</LM>
   </w.rf>
   <form>vyučení</form>
   <lemma>vyučení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1t176-3">
   <w.rf>
    <LM>w#w-d1t176-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t176-6">
   <w.rf>
    <LM>w#w-d1t176-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t176-7">
   <w.rf>
    <LM>w#w-d1t176-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t176-8">
   <w.rf>
    <LM>w#w-d1t176-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t176-9">
   <w.rf>
    <LM>w#w-d1t176-9</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1e173-x2-1851">
   <w.rf>
    <LM>w#w-d1e173-x2-1851</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t186-1">
   <w.rf>
    <LM>w#w-d1t186-1</LM>
   </w.rf>
   <form>řemeslník</form>
   <lemma>řemeslník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e173-x2-1695">
   <w.rf>
    <LM>w#w-d1e173-x2-1695</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e177-x2">
  <m id="m784-d1t180-1">
   <w.rf>
    <LM>w#w-d1t180-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e177-x2-1713">
   <w.rf>
    <LM>w#w-d1e177-x2-1713</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t180-4">
   <w.rf>
    <LM>w#w-d1t180-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t180-5">
   <w.rf>
    <LM>w#w-d1t180-5</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t180-3">
   <w.rf>
    <LM>w#w-d1t180-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t180-6">
   <w.rf>
    <LM>w#w-d1t180-6</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t188-4">
   <w.rf>
    <LM>w#w-d1t188-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t188-5">
   <w.rf>
    <LM>w#w-d1t188-5</LM>
   </w.rf>
   <form>řemeslník</form>
   <lemma>řemeslník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id60641">
   <w.rf>
    <LM>w#w-d-id60641</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1853">
  <m id="m784-d1t190-2">
   <w.rf>
    <LM>w#w-d1t190-2</LM>
   </w.rf>
   <form>Šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t190-3">
   <w.rf>
    <LM>w#w-d1t190-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t190-4">
   <w.rf>
    <LM>w#w-d1t190-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t190-5">
   <w.rf>
    <LM>w#w-d1t190-5</LM>
   </w.rf>
   <form>devatenácti</form>
   <lemma>devatenáct`19</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m784-d1t190-6">
   <w.rf>
    <LM>w#w-d1t190-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t190-7">
   <w.rf>
    <LM>w#w-d1t190-7</LM>
   </w.rf>
   <form>vojnu</form>
   <lemma>vojna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-1853-1993">
   <w.rf>
    <LM>w#w-1853-1993</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1994">
  <m id="m784-d1t190-8">
   <w.rf>
    <LM>w#w-d1t190-8</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t190-9">
   <w.rf>
    <LM>w#w-d1t190-9</LM>
   </w.rf>
   <form>sedmnácti</form>
   <lemma>sedmnáct`17</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m784-d1t190-10">
   <w.rf>
    <LM>w#w-d1t190-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t190-11">
   <w.rf>
    <LM>w#w-d1t190-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t190-12">
   <w.rf>
    <LM>w#w-d1t190-12</LM>
   </w.rf>
   <form>vyučený</form>
   <lemma>vyučený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t196-1">
   <w.rf>
    <LM>w#w-d1t196-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t196-2">
   <w.rf>
    <LM>w#w-d1t196-2</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t196-3">
   <w.rf>
    <LM>w#w-d1t196-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t196-4">
   <w.rf>
    <LM>w#w-d1t196-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t196-5">
   <w.rf>
    <LM>w#w-d1t196-5</LM>
   </w.rf>
   <form>třísměnném</form>
   <lemma>třísměnný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m784-d1t196-6">
   <w.rf>
    <LM>w#w-d1t196-6</LM>
   </w.rf>
   <form>provozu</form>
   <lemma>provoz</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-1994-1021">
   <w.rf>
    <LM>w#w-1994-1021</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1022">
  <m id="m784-d1t198-1">
   <w.rf>
    <LM>w#w-d1t198-1</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m784-d1t198-2">
   <w.rf>
    <LM>w#w-d1t198-2</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t198-3">
   <w.rf>
    <LM>w#w-d1t198-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t198-4">
   <w.rf>
    <LM>w#w-d1t198-4</LM>
   </w.rf>
   <form>soustruhu</form>
   <lemma>soustruh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-1022-1023">
   <w.rf>
    <LM>w#w-1022-1023</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-1022-1024">
   <w.rf>
    <LM>w#w-1022-1024</LM>
   </w.rf>
   <form>střídali</form>
   <lemma>střídat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-1022-1025">
   <w.rf>
    <LM>w#w-1022-1025</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m784-1022-1026">
   <w.rf>
    <LM>w#w-1022-1026</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-1022-1027">
   <w.rf>
    <LM>w#w-1022-1027</LM>
   </w.rf>
   <form>ranní</form>
   <lemma>ranní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m784-d1t198-5">
   <w.rf>
    <LM>w#w-d1t198-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t198-6">
   <w.rf>
    <LM>w#w-d1t198-6</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m784-d1t198-7">
   <w.rf>
    <LM>w#w-d1t198-7</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-1022-1030">
   <w.rf>
    <LM>w#w-1022-1030</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-1022-1028">
   <w.rf>
    <LM>w#w-1022-1028</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-1022-1029">
   <w.rf>
    <LM>w#w-1022-1029</LM>
   </w.rf>
   <form>odpolední</form>
   <lemma>odpolední</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m784-d-id61496">
   <w.rf>
    <LM>w#w-d-id61496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e191-x3">
  <m id="m784-d1t202-1">
   <w.rf>
    <LM>w#w-d1t202-1</LM>
   </w.rf>
   <form>Plnili</form>
   <lemma>plnit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t202-2">
   <w.rf>
    <LM>w#w-d1t202-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t202-3">
   <w.rf>
    <LM>w#w-d1t202-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t202-5">
   <w.rf>
    <LM>w#w-d1t202-5</LM>
   </w.rf>
   <form>dvouletku</form>
   <lemma>dvouletka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d-id61606">
   <w.rf>
    <LM>w#w-d-id61606</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e191-x4">
  <m id="m784-d1t207-3">
   <w.rf>
    <LM>w#w-d1t207-3</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m784-d1t207-4">
   <w.rf>
    <LM>w#w-d1t207-4</LM>
   </w.rf>
   <form>sedmnáctiletí</form>
   <lemma>sedmnáctiletý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m784-d1t207-5">
   <w.rf>
    <LM>w#w-d1t207-5</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m784-d1t207-2">
   <w.rf>
    <LM>w#w-d1t207-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t209-1">
   <w.rf>
    <LM>w#w-d1t209-1</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t209-2">
   <w.rf>
    <LM>w#w-d1t209-2</LM>
   </w.rf>
   <form>střídavě</form>
   <lemma>střídavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t209-3">
   <w.rf>
    <LM>w#w-d1t209-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t209-4">
   <w.rf>
    <LM>w#w-d1t209-4</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e191-x4-2255">
   <w.rf>
    <LM>w#w-d1e191-x4-2255</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t209-5">
   <w.rf>
    <LM>w#w-d1t209-5</LM>
   </w.rf>
   <form>střídavě</form>
   <lemma>střídavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t209-6">
   <w.rf>
    <LM>w#w-d1t209-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t209-7">
   <w.rf>
    <LM>w#w-d1t209-7</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t209-8">
   <w.rf>
    <LM>w#w-d1t209-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t211-1">
   <w.rf>
    <LM>w#w-d1t211-1</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1e191-x4-2256">
   <w.rf>
    <LM>w#w-d1e191-x4-2256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t211-2">
   <w.rf>
    <LM>w#w-d1t211-2</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m784-d1t211-3">
   <w.rf>
    <LM>w#w-d1t211-3</LM>
   </w.rf>
   <form>soustružnice</form>
   <lemma>soustružnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1e191-x4-2257">
   <w.rf>
    <LM>w#w-d1e191-x4-2257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t211-4">
   <w.rf>
    <LM>w#w-d1t211-4</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t211-5">
   <w.rf>
    <LM>w#w-d1t211-5</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m784-d1t211-6">
   <w.rf>
    <LM>w#w-d1t211-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t211-7">
   <w.rf>
    <LM>w#w-d1t211-7</LM>
   </w.rf>
   <form>odpolední</form>
   <lemma>odpolední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d-id61961">
   <w.rf>
    <LM>w#w-d-id61961</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e213-x2">
  <m id="m784-d1e213-x2-2318">
   <w.rf>
    <LM>w#w-d1e213-x2-2318</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1e213-x2-2272">
   <w.rf>
    <LM>w#w-d1e213-x2-2272</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t216-1">
   <w.rf>
    <LM>w#w-d1t216-1</LM>
   </w.rf>
   <form>1956</form>
   <lemma>1956</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e213-x2-1037">
   <w.rf>
    <LM>w#w-d1e213-x2-1037</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t216-3">
   <w.rf>
    <LM>w#w-d1t216-3</LM>
   </w.rf>
   <form>vojna</form>
   <lemma>vojna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1e213-x2-2273">
   <w.rf>
    <LM>w#w-d1e213-x2-2273</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e217-x2">
  <m id="m784-d1e217-x2-2320">
   <w.rf>
    <LM>w#w-d1e217-x2-2320</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1e217-x2-2321">
   <w.rf>
    <LM>w#w-d1e217-x2-2321</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t220-1">
   <w.rf>
    <LM>w#w-d1t220-1</LM>
   </w.rf>
   <form>1956</form>
   <lemma>1956</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e217-x2-1040">
   <w.rf>
    <LM>w#w-d1e217-x2-1040</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t220-3">
   <w.rf>
    <LM>w#w-d1t220-3</LM>
   </w.rf>
   <form>vojna</form>
   <lemma>vojna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d-id62178">
   <w.rf>
    <LM>w#w-d-id62178</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t222-1">
   <w.rf>
    <LM>w#w-d1t222-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t222-2">
   <w.rf>
    <LM>w#w-d1t222-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t222-3">
   <w.rf>
    <LM>w#w-d1t222-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t222-4">
   <w.rf>
    <LM>w#w-d1t222-4</LM>
   </w.rf>
   <form>26</form>
   <lemma>26</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t222-6">
   <w.rf>
    <LM>w#w-d1t222-6</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1t224-3">
   <w.rf>
    <LM>w#w-d1t224-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t226-2">
   <w.rf>
    <LM>w#w-d1t226-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t226-3">
   <w.rf>
    <LM>w#w-d1t226-3</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t236-1">
   <w.rf>
    <LM>w#w-d1t236-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t236-2">
   <w.rf>
    <LM>w#w-d1t236-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t236-3">
   <w.rf>
    <LM>w#w-d1t236-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1e217-x2-2375">
   <w.rf>
    <LM>w#w-d1e217-x2-2375</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e217-x2-2376">
   <w.rf>
    <LM>w#w-d1e217-x2-2376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d-id62116">
   <w.rf>
    <LM>w#w-d-id62116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e227-x2">
  <m id="m784-d1e227-x2-1042">
   <w.rf>
    <LM>w#w-d1e227-x2-1042</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1e227-x2-1043">
   <w.rf>
    <LM>w#w-d1e227-x2-1043</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t234-3">
   <w.rf>
    <LM>w#w-d1t234-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1e227-x2-1044">
   <w.rf>
    <LM>w#w-d1e227-x2-1044</LM>
   </w.rf>
   <form>dýl</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------2A---6</tag>
  </m>
  <m id="m784-d1e227-x2-1045">
   <w.rf>
    <LM>w#w-d1e227-x2-1045</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t234-1">
   <w.rf>
    <LM>w#w-d1t234-1</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m784-d1t234-2">
   <w.rf>
    <LM>w#w-d1t234-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m784-d1e227-x2-2383">
   <w.rf>
    <LM>w#w-d1e227-x2-2383</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t234-4">
   <w.rf>
    <LM>w#w-d1t234-4</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d-id62503">
   <w.rf>
    <LM>w#w-d-id62503</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e237-x2">
  <m id="m784-d1t240-2">
   <w.rf>
    <LM>w#w-d1t240-2</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t240-3">
   <w.rf>
    <LM>w#w-d1t240-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t240-4">
   <w.rf>
    <LM>w#w-d1t240-4</LM>
   </w.rf>
   <form>vojna</form>
   <lemma>vojna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1e237-x2-2503">
   <w.rf>
    <LM>w#w-d1e237-x2-2503</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t240-5">
   <w.rf>
    <LM>w#w-d1t240-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t242-4">
   <w.rf>
    <LM>w#w-d1t242-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t242-2">
   <w.rf>
    <LM>w#w-d1t242-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t242-3">
   <w.rf>
    <LM>w#w-d1t242-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t242-5">
   <w.rf>
    <LM>w#w-d1t242-5</LM>
   </w.rf>
   <form>prodloužené</form>
   <lemma>prodloužený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t242-6">
   <w.rf>
    <LM>w#w-d1t242-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t242-8">
   <w.rf>
    <LM>w#w-d1t242-8</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t242-9">
   <w.rf>
    <LM>w#w-d1t242-9</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1e237-x2-2549">
   <w.rf>
    <LM>w#w-d1e237-x2-2549</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e245-x2">
  <m id="m784-d1t248-1">
   <w.rf>
    <LM>w#w-d1t248-1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t248-2">
   <w.rf>
    <LM>w#w-d1t248-2</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m784-d1t248-3">
   <w.rf>
    <LM>w#w-d1t248-3</LM>
   </w.rf>
   <form>cvičení</form>
   <lemma>cvičení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e245-x2-2550">
   <w.rf>
    <LM>w#w-d1e245-x2-2550</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e249-x2">
  <m id="m784-d1t256-5">
   <w.rf>
    <LM>w#w-d1t256-5</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t256-3">
   <w.rf>
    <LM>w#w-d1t256-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m784-d1t256-4">
   <w.rf>
    <LM>w#w-d1t256-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t256-6">
   <w.rf>
    <LM>w#w-d1t256-6</LM>
   </w.rf>
   <form>zapsali</form>
   <lemma>zapsat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1e249-x2-2623">
   <w.rf>
    <LM>w#w-d1e249-x2-2623</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t256-7">
   <w.rf>
    <LM>w#w-d1t256-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t256-8">
   <w.rf>
    <LM>w#w-d1t256-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t256-9">
   <w.rf>
    <LM>w#w-d1t256-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t258-1">
   <w.rf>
    <LM>w#w-d1t258-1</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t258-2">
   <w.rf>
    <LM>w#w-d1t258-2</LM>
   </w.rf>
   <form>něčemu</form>
   <lemma>něco</lemma>
   <tag>PK--3----------</tag>
  </m>
  <m id="m784-d1t258-3">
   <w.rf>
    <LM>w#w-d1t258-3</LM>
   </w.rf>
   <form>jinému</form>
   <lemma>jiný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m784-d-id63407">
   <w.rf>
    <LM>w#w-d-id63407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e249-x3">
  <m id="m784-d1t265-2">
   <w.rf>
    <LM>w#w-d1t265-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1e249-x3-2741">
   <w.rf>
    <LM>w#w-d1e249-x3-2741</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t265-3">
   <w.rf>
    <LM>w#w-d1t265-3</LM>
   </w.rf>
   <form>1956</form>
   <lemma>1956</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t265-5">
   <w.rf>
    <LM>w#w-d1t265-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m784-d1t265-6">
   <w.rf>
    <LM>w#w-d1t265-6</LM>
   </w.rf>
   <form>maďarské</form>
   <lemma>maďarský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m784-d1t273-1">
   <w.rf>
    <LM>w#w-d1t273-1</LM>
   </w.rf>
   <form>události</form>
   <lemma>událost</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1e249-x3-2748">
   <w.rf>
    <LM>w#w-d1e249-x3-2748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t279-1">
   <w.rf>
    <LM>w#w-d1t279-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t279-2">
   <w.rf>
    <LM>w#w-d1t279-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t279-3">
   <w.rf>
    <LM>w#w-d1t279-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t279-4">
   <w.rf>
    <LM>w#w-d1t279-4</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t279-5">
   <w.rf>
    <LM>w#w-d1t279-5</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t279-6">
   <w.rf>
    <LM>w#w-d1t279-6</LM>
   </w.rf>
   <form>déle</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m784-d-id63794">
   <w.rf>
    <LM>w#w-d-id63794</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e266-x2">
  <m id="m784-d1t271-1">
   <w.rf>
    <LM>w#w-d1t271-1</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m784-d-id63587">
   <w.rf>
    <LM>w#w-d-id63587</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e274-x3">
  <m id="m784-d1t285-3">
   <w.rf>
    <LM>w#w-d1t285-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t285-4">
   <w.rf>
    <LM>w#w-d1t285-4</LM>
   </w.rf>
   <form>návratu</form>
   <lemma>návrat</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t285-5">
   <w.rf>
    <LM>w#w-d1t285-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t285-6">
   <w.rf>
    <LM>w#w-d1t285-6</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t290-1">
   <w.rf>
    <LM>w#w-d1t290-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t290-3">
   <w.rf>
    <LM>w#w-d1t290-3</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t290-4">
   <w.rf>
    <LM>w#w-d1t290-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t290-5">
   <w.rf>
    <LM>w#w-d1t290-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t290-7">
   <w.rf>
    <LM>w#w-d1t290-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m784-d1t290-8">
   <w.rf>
    <LM>w#w-d1t290-8</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1e274-x3-2860">
   <w.rf>
    <LM>w#w-d1e274-x3-2860</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t294-10">
   <w.rf>
    <LM>w#w-d1t294-10</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t294-11">
   <w.rf>
    <LM>w#w-d1t294-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t294-12">
   <w.rf>
    <LM>w#w-d1t294-12</LM>
   </w.rf>
   <form>vyřídil</form>
   <lemma>vyřídit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t294-13">
   <w.rf>
    <LM>w#w-d1t294-13</LM>
   </w.rf>
   <form>rozvázání</form>
   <lemma>rozvázání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t294-14">
   <w.rf>
    <LM>w#w-d1t294-14</LM>
   </w.rf>
   <form>pracovního</form>
   <lemma>pracovní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m784-d1t294-15">
   <w.rf>
    <LM>w#w-d1t294-15</LM>
   </w.rf>
   <form>poměru</form>
   <lemma>poměr_^(vztah_mezi_2_věcmi/lidmi)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e274-x3-2861">
   <w.rf>
    <LM>w#w-d1e274-x3-2861</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t294-1">
   <w.rf>
    <LM>w#w-d1t294-1</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t292-1">
   <w.rf>
    <LM>w#w-d1t292-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t292-2">
   <w.rf>
    <LM>w#w-d1t292-2</LM>
   </w.rf>
   <form>Uničova</form>
   <lemma>Uničov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t294-2">
   <w.rf>
    <LM>w#w-d1t294-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t294-3">
   <w.rf>
    <LM>w#w-d1t294-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t294-4">
   <w.rf>
    <LM>w#w-d1t294-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m784-d1t294-5">
   <w.rf>
    <LM>w#w-d1t294-5</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t294-6">
   <w.rf>
    <LM>w#w-d1t294-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t294-8">
   <w.rf>
    <LM>w#w-d1t294-8</LM>
   </w.rf>
   <form>odcházel</form>
   <lemma>odcházet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t294-16">
   <w.rf>
    <LM>w#w-d1t294-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t294-17">
   <w.rf>
    <LM>w#w-d1t294-17</LM>
   </w.rf>
   <form>Tesly</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t294-18">
   <w.rf>
    <LM>w#w-d1t294-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t294-19">
   <w.rf>
    <LM>w#w-d1t294-19</LM>
   </w.rf>
   <form>Přelouče</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d-id64533">
   <w.rf>
    <LM>w#w-d-id64533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e295-x2">
  <m id="m784-d1t300-1">
   <w.rf>
    <LM>w#w-d1t300-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t300-2">
   <w.rf>
    <LM>w#w-d1t300-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id64631">
   <w.rf>
    <LM>w#w-d-id64631</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e301-x2">
  <m id="m784-d1t306-1">
   <w.rf>
    <LM>w#w-d1t306-1</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t306-2">
   <w.rf>
    <LM>w#w-d1t306-2</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t306-3">
   <w.rf>
    <LM>w#w-d1t306-3</LM>
   </w.rf>
   <form>kovů</form>
   <lemma>kov</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1t306-4">
   <w.rf>
    <LM>w#w-d1t306-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t306-5">
   <w.rf>
    <LM>w#w-d1t306-5</LM>
   </w.rf>
   <form>vzorkovny</form>
   <lemma>vzorkovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1e301-x2-2887">
   <w.rf>
    <LM>w#w-d1e301-x2-2887</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t308-1">
   <w.rf>
    <LM>w#w-d1t308-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t308-2">
   <w.rf>
    <LM>w#w-d1t308-2</LM>
   </w.rf>
   <form>vývoje</form>
   <lemma>vývoj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d-id64829">
   <w.rf>
    <LM>w#w-d-id64829</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e309-x2">
  <m id="m784-d1t312-1">
   <w.rf>
    <LM>w#w-d1t312-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m784-d1t312-2">
   <w.rf>
    <LM>w#w-d1t312-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t312-3">
   <w.rf>
    <LM>w#w-d1t312-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t312-4">
   <w.rf>
    <LM>w#w-d1t312-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t312-5">
   <w.rf>
    <LM>w#w-d1t312-5</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t312-6">
   <w.rf>
    <LM>w#w-d1t312-6</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d-id64960">
   <w.rf>
    <LM>w#w-d-id64960</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e314-x2">
  <m id="m784-d1t319-1">
   <w.rf>
    <LM>w#w-d1t319-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t321-1">
   <w.rf>
    <LM>w#w-d1t321-1</LM>
   </w.rf>
   <form>Tesle</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1e314-x2-1063">
   <w.rf>
    <LM>w#w-d1e314-x2-1063</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t321-2">
   <w.rf>
    <LM>w#w-d1t321-2</LM>
   </w.rf>
   <form>Přelouči</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t321-3">
   <w.rf>
    <LM>w#w-d1t321-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t323-1">
   <w.rf>
    <LM>w#w-d1t323-1</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t323-2">
   <w.rf>
    <LM>w#w-d1t323-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t323-5">
   <w.rf>
    <LM>w#w-d1t323-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t323-6">
   <w.rf>
    <LM>w#w-d1t323-6</LM>
   </w.rf>
   <form>průmyslové</form>
   <lemma>průmyslový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m784-d1t323-7">
   <w.rf>
    <LM>w#w-d1t323-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t325-2">
   <w.rf>
    <LM>w#w-d1t325-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t325-3">
   <w.rf>
    <LM>w#w-d1t325-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t325-4">
   <w.rf>
    <LM>w#w-d1t325-4</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m784-d1t325-5">
   <w.rf>
    <LM>w#w-d1t325-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t325-6">
   <w.rf>
    <LM>w#w-d1t325-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t325-7">
   <w.rf>
    <LM>w#w-d1t325-7</LM>
   </w.rf>
   <form>přešel</form>
   <lemma>přejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t325-8">
   <w.rf>
    <LM>w#w-d1t325-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t325-9">
   <w.rf>
    <LM>w#w-d1t325-9</LM>
   </w.rf>
   <form>montáž</form>
   <lemma>montáž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t325-10">
   <w.rf>
    <LM>w#w-d1t325-10</LM>
   </w.rf>
   <form>rozhlasových</form>
   <lemma>rozhlasový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m784-d1t325-11">
   <w.rf>
    <LM>w#w-d1t325-11</LM>
   </w.rf>
   <form>přijímačů</form>
   <lemma>přijímač</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d-id65401">
   <w.rf>
    <LM>w#w-d-id65401</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e326-x2">
  <m id="m784-d1t329-5">
   <w.rf>
    <LM>w#w-d1t329-5</LM>
   </w.rf>
   <form>Nedoplňoval</form>
   <lemma>doplňovat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t329-3">
   <w.rf>
    <LM>w#w-d1t329-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t329-4">
   <w.rf>
    <LM>w#w-d1t329-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t335-1">
   <w.rf>
    <LM>w#w-d1t335-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t329-2">
   <w.rf>
    <LM>w#w-d1t329-2</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t329-6">
   <w.rf>
    <LM>w#w-d1t329-6</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e326-x2-2971">
   <w.rf>
    <LM>w#w-d1e326-x2-2971</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e330-x3">
  <m id="m784-d1t337-3">
   <w.rf>
    <LM>w#w-d1t337-3</LM>
   </w.rf>
   <form>Dálkovým</form>
   <lemma>dálkový</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m784-d1t337-4">
   <w.rf>
    <LM>w#w-d1t337-4</LM>
   </w.rf>
   <form>studiem</form>
   <lemma>studium</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m784-d1t337-5">
   <w.rf>
    <LM>w#w-d1t337-5</LM>
   </w.rf>
   <form>průmyslové</form>
   <lemma>průmyslový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m784-d1t337-6">
   <w.rf>
    <LM>w#w-d1t337-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d-id65711">
   <w.rf>
    <LM>w#w-d-id65711</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e338-x2">
  <m id="m784-d1t341-2">
   <w.rf>
    <LM>w#w-d1t341-2</LM>
   </w.rf>
   <form>Obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d-id65807">
   <w.rf>
    <LM>w#w-d-id65807</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e342-x2">
  <m id="m784-d1t347-4">
   <w.rf>
    <LM>w#w-d1t347-4</LM>
   </w.rf>
   <form>Obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1t347-5">
   <w.rf>
    <LM>w#w-d1t347-5</LM>
   </w.rf>
   <form>strojař</form>
   <lemma>strojař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id65951">
   <w.rf>
    <LM>w#w-d-id65951</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e348-x2">
  <m id="m784-d1t351-3">
   <w.rf>
    <LM>w#w-d1t351-3</LM>
   </w.rf>
   <form>Zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t357-1">
   <w.rf>
    <LM>w#w-d1t357-1</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id66001">
   <w.rf>
    <LM>w#w-d-id66001</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e352-x2">
  <m id="m784-d1t363-1">
   <w.rf>
    <LM>w#w-d1t363-1</LM>
   </w.rf>
   <form>Zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t363-2">
   <w.rf>
    <LM>w#w-d1t363-2</LM>
   </w.rf>
   <form>strojař</form>
   <lemma>strojař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e352-x3-3132">
   <w.rf>
    <LM>w#w-d1e352-x3-3132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t366-1">
   <w.rf>
    <LM>w#w-d1t366-1</LM>
   </w.rf>
   <form>černé</form>
   <lemma>černý_;o</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1t366-2">
   <w.rf>
    <LM>w#w-d1t366-2</LM>
   </w.rf>
   <form>řemeslo</form>
   <lemma>řemeslo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d1e352-x2-3178">
   <w.rf>
    <LM>w#w-d1e352-x2-3178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e352-x3">
  <m id="m784-d1t359-1">
   <w.rf>
    <LM>w#w-d1t359-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1e352-x3-3238">
   <w.rf>
    <LM>w#w-d1e352-x3-3238</LM>
   </w.rf>
   <form>elektrice</form>
   <lemma>elektrika</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m784-d1e352-x3-3234">
   <w.rf>
    <LM>w#w-d1e352-x3-3234</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1e352-x3-3235">
   <w.rf>
    <LM>w#w-d1e352-x3-3235</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1e352-x3-3239">
   <w.rf>
    <LM>w#w-d1e352-x3-3239</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e352-x3-3237">
   <w.rf>
    <LM>w#w-d1e352-x3-3237</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e352-x3-3236">
   <w.rf>
    <LM>w#w-d1e352-x3-3236</LM>
   </w.rf>
   <form>nedostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1e352-x3-3240">
   <w.rf>
    <LM>w#w-d1e352-x3-3240</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-3135">
  <m id="m784-d1t366-5">
   <w.rf>
    <LM>w#w-d1t366-5</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-3135-3143">
   <w.rf>
    <LM>w#w-3135-3143</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-3135-3144">
   <w.rf>
    <LM>w#w-3135-3144</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t366-6">
   <w.rf>
    <LM>w#w-d1t366-6</LM>
   </w.rf>
   <form>elektřině</form>
   <lemma>elektřina</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m784-d1t366-7">
   <w.rf>
    <LM>w#w-d1t366-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t366-8">
   <w.rf>
    <LM>w#w-d1t366-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t366-9">
   <w.rf>
    <LM>w#w-d1t366-9</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t366-10">
   <w.rf>
    <LM>w#w-d1t366-10</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d-id66382">
   <w.rf>
    <LM>w#w-d-id66382</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e367-x2">
  <m id="m784-d1t370-1">
   <w.rf>
    <LM>w#w-d1t370-1</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t370-2">
   <w.rf>
    <LM>w#w-d1t370-2</LM>
   </w.rf>
   <form>ačkoliv</form>
   <lemma>ačkoliv_,s_^(^DD**ačkoli)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t370-3">
   <w.rf>
    <LM>w#w-d1t370-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1e367-x2-3447">
   <w.rf>
    <LM>w#w-d1e367-x2-3447</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e367-x2-3448">
   <w.rf>
    <LM>w#w-d1e367-x2-3448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e367-x2-3449">
   <w.rf>
    <LM>w#w-d1e367-x2-3449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e371-x2">
  <m id="m784-d1e371-x2-1069">
   <w.rf>
    <LM>w#w-d1e371-x2-1069</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e371-x2-1070">
   <w.rf>
    <LM>w#w-d1e371-x2-1070</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e371-x2-1071">
   <w.rf>
    <LM>w#w-d1e371-x2-1071</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t374-1">
   <w.rf>
    <LM>w#w-d1t374-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m784-d1t374-2">
   <w.rf>
    <LM>w#w-d1t374-2</LM>
   </w.rf>
   <form>koníček</form>
   <lemma>koníček-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id66565">
   <w.rf>
    <LM>w#w-d-id66565</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e375-x2">
  <m id="m784-d1e375-x2-1072">
   <w.rf>
    <LM>w#w-d1e375-x2-1072</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t378-3">
   <w.rf>
    <LM>w#w-d1t378-3</LM>
   </w.rf>
   <form>ačkoliv</form>
   <lemma>ačkoliv_,s_^(^DD**ačkoli)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t378-4">
   <w.rf>
    <LM>w#w-d1t378-4</LM>
   </w.rf>
   <form>Tesla</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t378-5">
   <w.rf>
    <LM>w#w-d1t378-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t380-1">
   <w.rf>
    <LM>w#w-d1t380-1</LM>
   </w.rf>
   <form>elektrotechnický</form>
   <lemma>elektrotechnický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m784-d1t380-2">
   <w.rf>
    <LM>w#w-d1t380-2</LM>
   </w.rf>
   <form>podnik</form>
   <lemma>podnik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1e375-x2-3558">
   <w.rf>
    <LM>w#w-d1e375-x2-3558</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>vyráběla</form>
   <lemma>vyrábět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t391-4">
   <w.rf>
    <LM>w#w-d1t391-4</LM>
   </w.rf>
   <form>rádia</form>
   <lemma>rádio</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m784-d1t391-5">
   <w.rf>
    <LM>w#w-d1t391-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t391-6">
   <w.rf>
    <LM>w#w-d1t391-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m784-d1t391-7">
   <w.rf>
    <LM>w#w-d1t391-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e375-x2-3561">
   <w.rf>
    <LM>w#w-d1e375-x2-3561</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1e375-x2-3461">
   <w.rf>
    <LM>w#w-d1e375-x2-3461</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
