<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_783.06.w.gz" />
  </references>
 </head>
 <s id="m783-27638_03-d1e2297-x4">
  <m id="m783-d1t2315-1">
   <w.rf>
    <LM>w#w-d1t2315-1</LM>
   </w.rf>
   <form>Horník</form>
   <lemma>horník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m783-d1e2297-x4-2223">
   <w.rf>
    <LM>w#w-d1e2297-x4-2223</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m783-d1t2317-1">
   <w.rf>
    <LM>w#w-d1t2317-1</LM>
   </w.rf>
   <form>zemědělec</form>
   <lemma>zemědělec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m783-d1t2317-2">
   <w.rf>
    <LM>w#w-d1t2317-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m783-d1t2317-3">
   <w.rf>
    <LM>w#w-d1t2317-3</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m783-d-id131335">
   <w.rf>
    <LM>w#w-d-id131335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m783-27638_03-d1e2318-x2">
  <m id="m783-d1t2323-1">
   <w.rf>
    <LM>w#w-d1t2323-1</LM>
   </w.rf>
   <form>Konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m783-d1t2323-2">
   <w.rf>
    <LM>w#w-d1t2323-2</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m783-d1t2323-3">
   <w.rf>
    <LM>w#w-d1t2323-3</LM>
   </w.rf>
   <form>kazety</form>
   <lemma>kazeta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m783-d-id131453">
   <w.rf>
    <LM>w#w-d-id131453</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
