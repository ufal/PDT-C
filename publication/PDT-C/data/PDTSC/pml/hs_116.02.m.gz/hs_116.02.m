<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_116.02.w.gz" />
  </references>
 </head>
 <s id="m116-305">
  <m id="m116-d1t421-1">
   <w.rf>
    <LM>w#w-d1t421-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t421-3">
   <w.rf>
    <LM>w#w-d1t421-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t421-2">
   <w.rf>
    <LM>w#w-d1t421-2</LM>
   </w.rf>
   <form>zkrátka</form>
   <lemma>zkrátka-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t421-4">
   <w.rf>
    <LM>w#w-d1t421-4</LM>
   </w.rf>
   <form>silný</form>
   <lemma>silný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m116-d1t421-5">
   <w.rf>
    <LM>w#w-d1t421-5</LM>
   </w.rf>
   <form>soupeř</form>
   <lemma>soupeř</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m116-d1t421-7">
   <w.rf>
    <LM>w#w-d1t421-7</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t421-8">
   <w.rf>
    <LM>w#w-d1t421-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t421-9">
   <w.rf>
    <LM>w#w-d1t421-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t421-10">
   <w.rf>
    <LM>w#w-d1t421-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t421-11">
   <w.rf>
    <LM>w#w-d1t421-11</LM>
   </w.rf>
   <form>silní</form>
   <lemma>silný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m116-d1t421-12">
   <w.rf>
    <LM>w#w-d1t421-12</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m116-305-306">
   <w.rf>
    <LM>w#w-305-306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t424-1">
   <w.rf>
    <LM>w#w-d1t424-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t424-2">
   <w.rf>
    <LM>w#w-d1t424-2</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t424-3">
   <w.rf>
    <LM>w#w-d1t424-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m116-d1t424-4">
   <w.rf>
    <LM>w#w-d1t424-4</LM>
   </w.rf>
   <form>vypadaly</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m116-d1t424-5">
   <w.rf>
    <LM>w#w-d1t424-5</LM>
   </w.rf>
   <form>výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m116-d-m-d1e410-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e410-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e426-x2">
  <m id="m116-d1e430">
   <w.rf>
    <LM>w#w-d1e430</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m116-d-m-d1e426-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e426-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e436-x2">
  <m id="m116-d1t439-1">
   <w.rf>
    <LM>w#w-d1t439-1</LM>
   </w.rf>
   <form>Jakého</form>
   <lemma>jaký</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m116-d1t439-2">
   <w.rf>
    <LM>w#w-d1t439-2</LM>
   </w.rf>
   <form>úspěchu</form>
   <lemma>úspěch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m116-d1t439-3">
   <w.rf>
    <LM>w#w-d1t439-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t439-4">
   <w.rf>
    <LM>w#w-d1t439-4</LM>
   </w.rf>
   <form>ceníte</form>
   <lemma>cenit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t439-5">
   <w.rf>
    <LM>w#w-d1t439-5</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m116-d-id73953-punct">
   <w.rf>
    <LM>w#w-d-id73953-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e440-x2">
  <m id="m116-d1t445-1">
   <w.rf>
    <LM>w#w-d1t445-1</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t445-2">
   <w.rf>
    <LM>w#w-d1t445-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m116-d1t445-3">
   <w.rf>
    <LM>w#w-d1t445-3</LM>
   </w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m116-d-id74070-punct">
   <w.rf>
    <LM>w#w-d-id74070-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e452-x2">
  <m id="m116-d1t455-1">
   <w.rf>
    <LM>w#w-d1t455-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d-m-d1e452-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e452-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e456-x2">
  <m id="m116-d1t461-5">
   <w.rf>
    <LM>w#w-d1t461-5</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t461-6">
   <w.rf>
    <LM>w#w-d1t461-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t461-7">
   <w.rf>
    <LM>w#w-d1t461-7</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d1t461-8">
   <w.rf>
    <LM>w#w-d1t461-8</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m116-d1t461-9">
   <w.rf>
    <LM>w#w-d1t461-9</LM>
   </w.rf>
   <form>liga</form>
   <lemma>liga</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1e456-x2-311">
   <w.rf>
    <LM>w#w-d1e456-x2-311</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-312">
  <m id="m116-d1t461-16">
   <w.rf>
    <LM>w#w-d1t461-16</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t461-15">
   <w.rf>
    <LM>w#w-d1t461-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t461-17">
   <w.rf>
    <LM>w#w-d1t461-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t461-18">
   <w.rf>
    <LM>w#w-d1t461-18</LM>
   </w.rf>
   <form>pátí</form>
   <lemma>pátý</lemma>
   <tag>CrMP1----------</tag>
  </m>
  <m id="m116-312-313">
   <w.rf>
    <LM>w#w-312-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-314">
  <m id="m116-d1t463-1">
   <w.rf>
    <LM>w#w-d1t463-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t463-2">
   <w.rf>
    <LM>w#w-d1t463-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t463-3">
   <w.rf>
    <LM>w#w-d1t463-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t463-4">
   <w.rf>
    <LM>w#w-d1t463-4</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m116-d1t463-5">
   <w.rf>
    <LM>w#w-d1t463-5</LM>
   </w.rf>
   <form>úspěch</form>
   <lemma>úspěch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-d-m-d1e456-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e456-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e470-x2">
  <m id="m116-d1t473-1">
   <w.rf>
    <LM>w#w-d1t473-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t473-2">
   <w.rf>
    <LM>w#w-d1t473-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t473-3">
   <w.rf>
    <LM>w#w-d1t473-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m116-d1e470-x2-316">
   <w.rf>
    <LM>w#w-d1e470-x2-316</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e474-x2">
  <m id="m116-d1t477-6">
   <w.rf>
    <LM>w#w-d1t477-6</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1e474-x2-318">
   <w.rf>
    <LM>w#w-d1e474-x2-318</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t477-7">
   <w.rf>
    <LM>w#w-d1t477-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t477-2">
   <w.rf>
    <LM>w#w-d1t477-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t477-3">
   <w.rf>
    <LM>w#w-d1t477-3</LM>
   </w.rf>
   <form>tehdejší</form>
   <lemma>tehdejší</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m116-d1t477-4">
   <w.rf>
    <LM>w#w-d1t477-4</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d1t477-8">
   <w.rf>
    <LM>w#w-d1t477-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t477-9">
   <w.rf>
    <LM>w#w-d1t477-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t477-10">
   <w.rf>
    <LM>w#w-d1t477-10</LM>
   </w.rf>
   <form>rozumné</form>
   <lemma>rozumný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m116-d-m-d1e474-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e474-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e478-x2">
  <m id="m116-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d1t481-5">
   <w.rf>
    <LM>w#w-d1t481-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1e478-x2-320">
   <w.rf>
    <LM>w#w-d1e478-x2-320</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-321">
  <m id="m116-d1t483-1">
   <w.rf>
    <LM>w#w-d1t483-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t483-2">
   <w.rf>
    <LM>w#w-d1t483-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t483-3">
   <w.rf>
    <LM>w#w-d1t483-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t483-4">
   <w.rf>
    <LM>w#w-d1t483-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t483-5">
   <w.rf>
    <LM>w#w-d1t483-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id75099-punct">
   <w.rf>
    <LM>w#w-d-id75099-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e484-x2">
  <m id="m116-d1t487-1">
   <w.rf>
    <LM>w#w-d1t487-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t487-3">
   <w.rf>
    <LM>w#w-d1t487-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t487-4">
   <w.rf>
    <LM>w#w-d1t487-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t487-5">
   <w.rf>
    <LM>w#w-d1t487-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m116-d1t487-7">
   <w.rf>
    <LM>w#w-d1t487-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m116-d1t487-8">
   <w.rf>
    <LM>w#w-d1t487-8</LM>
   </w.rf>
   <form>svojí</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS7----------</tag>
  </m>
  <m id="m116-d1t487-9">
   <w.rf>
    <LM>w#w-d1t487-9</LM>
   </w.rf>
   <form>vnučkou</form>
   <lemma>vnučka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m116-d1e484-x2-323">
   <w.rf>
    <LM>w#w-d1e484-x2-323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-324">
  <m id="m116-d1t489-1">
   <w.rf>
    <LM>w#w-d1t489-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t489-2">
   <w.rf>
    <LM>w#w-d1t489-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t489-3">
   <w.rf>
    <LM>w#w-d1t489-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t489-4">
   <w.rf>
    <LM>w#w-d1t489-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-324-325">
   <w.rf>
    <LM>w#w-324-325</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t489-5">
   <w.rf>
    <LM>w#w-d1t489-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t489-6">
   <w.rf>
    <LM>w#w-d1t489-6</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m116-d-id75408-punct">
   <w.rf>
    <LM>w#w-d-id75408-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t489-8">
   <w.rf>
    <LM>w#w-d1t489-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t489-9">
   <w.rf>
    <LM>w#w-d1t489-9</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m116-d1t489-10">
   <w.rf>
    <LM>w#w-d1t489-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t489-11">
   <w.rf>
    <LM>w#w-d1t489-11</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m116-d1t489-12">
   <w.rf>
    <LM>w#w-d1t489-12</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m116-d1t489-13">
   <w.rf>
    <LM>w#w-d1t489-13</LM>
   </w.rf>
   <form>bazének</form>
   <lemma>bazének</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-324-326">
   <w.rf>
    <LM>w#w-324-326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-327">
  <m id="m116-d1t491-8">
   <w.rf>
    <LM>w#w-d1t491-8</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t491-6">
   <w.rf>
    <LM>w#w-d1t491-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t491-7">
   <w.rf>
    <LM>w#w-d1t491-7</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m116-d1t491-5">
   <w.rf>
    <LM>w#w-d1t491-5</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t491-9">
   <w.rf>
    <LM>w#w-d1t491-9</LM>
   </w.rf>
   <form>učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t491-10">
   <w.rf>
    <LM>w#w-d1t491-10</LM>
   </w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d-m-d1e484-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e484-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e492-x2">
  <m id="m116-d1t495-1">
   <w.rf>
    <LM>w#w-d1t495-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t495-2">
   <w.rf>
    <LM>w#w-d1t495-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t495-3">
   <w.rf>
    <LM>w#w-d1t495-3</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m116-d1t495-4">
   <w.rf>
    <LM>w#w-d1t495-4</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t495-5">
   <w.rf>
    <LM>w#w-d1t495-5</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m116-d-id75811-punct">
   <w.rf>
    <LM>w#w-d-id75811-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e496-x2">
  <m id="m116-d1t501-1">
   <w.rf>
    <LM>w#w-d1t501-1</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m116-d1t501-2">
   <w.rf>
    <LM>w#w-d1t501-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t501-4">
   <w.rf>
    <LM>w#w-d1t501-4</LM>
   </w.rf>
   <form>Terezka</form>
   <lemma>Terezka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t501-5">
   <w.rf>
    <LM>w#w-d1t501-5</LM>
   </w.rf>
   <form>Jonáková</form>
   <lemma>Jonáková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-m-d1e496-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e496-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e502-x2">
  <m id="m116-d1t505-1">
   <w.rf>
    <LM>w#w-d1t505-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m116-d1t505-2">
   <w.rf>
    <LM>w#w-d1t505-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t505-3">
   <w.rf>
    <LM>w#w-d1t505-3</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t505-4">
   <w.rf>
    <LM>w#w-d1t505-4</LM>
   </w.rf>
   <form>vnoučat</form>
   <lemma>vnouče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m116-d-id76076-punct">
   <w.rf>
    <LM>w#w-d-id76076-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e506-x2">
  <m id="m116-d1t509-1">
   <w.rf>
    <LM>w#w-d1t509-1</LM>
   </w.rf>
   <form>Vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m116-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t509-4">
   <w.rf>
    <LM>w#w-d1t509-4</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m116-d-m-d1e506-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e506-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e510-x2">
  <m id="m116-d1t513-1">
   <w.rf>
    <LM>w#w-d1t513-1</LM>
   </w.rf>
   <form>Naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d1t513-2">
   <w.rf>
    <LM>w#w-d1t513-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t513-3">
   <w.rf>
    <LM>w#w-d1t513-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m116-d1t513-4">
   <w.rf>
    <LM>w#w-d1t513-4</LM>
   </w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d-id76315-punct">
   <w.rf>
    <LM>w#w-d-id76315-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e514-x2">
  <m id="m116-d1t519-2">
   <w.rf>
    <LM>w#w-d1t519-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t519-4">
   <w.rf>
    <LM>w#w-d1t519-4</LM>
   </w.rf>
   <form>napůl</form>
   <lemma>napůl</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1e514-x2-7">
   <w.rf>
    <LM>w#w-d1e514-x2-7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-8">
  <m id="m116-d1t523-3">
   <w.rf>
    <LM>w#w-d1t523-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t523-2">
   <w.rf>
    <LM>w#w-d1t523-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t523-4">
   <w.rf>
    <LM>w#w-d1t523-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t523-5">
   <w.rf>
    <LM>w#w-d1t523-5</LM>
   </w.rf>
   <form>počátku</form>
   <lemma>počátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m116-8-9">
   <w.rf>
    <LM>w#w-8-9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t523-6">
   <w.rf>
    <LM>w#w-d1t523-6</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t523-8">
   <w.rf>
    <LM>w#w-d1t523-8</LM>
   </w.rf>
   <form>začínala</form>
   <lemma>začínat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-8-10">
   <w.rf>
    <LM>w#w-8-10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-11">
  <m id="m116-d1t523-17">
   <w.rf>
    <LM>w#w-d1t523-17</LM>
   </w.rf>
   <form>Naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d1t523-14">
   <w.rf>
    <LM>w#w-d1t523-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t523-15">
   <w.rf>
    <LM>w#w-d1t523-15</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m116-d1t525-2">
   <w.rf>
    <LM>w#w-d1t525-2</LM>
   </w.rf>
   <form>základy</form>
   <lemma>základ</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m116-d-id76821-punct">
   <w.rf>
    <LM>w#w-d-id76821-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t525-4">
   <w.rf>
    <LM>w#w-d1t525-4</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t525-5">
   <w.rf>
    <LM>w#w-d1t525-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t525-7">
   <w.rf>
    <LM>w#w-d1t525-7</LM>
   </w.rf>
   <form>neutopila</form>
   <lemma>utopit</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m116-d1t525-8">
   <w.rf>
    <LM>w#w-d1t525-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t525-9">
   <w.rf>
    <LM>w#w-d1t525-9</LM>
   </w.rf>
   <form>vydržela</form>
   <lemma>vydržet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m116-d1t525-10">
   <w.rf>
    <LM>w#w-d1t525-10</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t525-11">
   <w.rf>
    <LM>w#w-d1t525-11</LM>
   </w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m116-d-m-d1e514-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e514-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e526-x2">
  <m id="m116-d1t533-2">
   <w.rf>
    <LM>w#w-d1t533-2</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m116-d1t533-3">
   <w.rf>
    <LM>w#w-d1t533-3</LM>
   </w.rf>
   <form>umíte</form>
   <lemma>umět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t533-4">
   <w.rf>
    <LM>w#w-d1t533-4</LM>
   </w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d-id77093-punct">
   <w.rf>
    <LM>w#w-d-id77093-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e535-x2">
  <m id="m116-d1t538-1">
   <w.rf>
    <LM>w#w-d1t538-1</LM>
   </w.rf>
   <form>Umím</form>
   <lemma>umět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t538-2">
   <w.rf>
    <LM>w#w-d1t538-2</LM>
   </w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t538-3">
   <w.rf>
    <LM>w#w-d1t538-3</LM>
   </w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--7----------</tag>
  </m>
  <m id="m116-d1t538-4">
   <w.rf>
    <LM>w#w-d1t538-4</LM>
   </w.rf>
   <form>styly</form>
   <lemma>styl</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m116-d-id77210-punct">
   <w.rf>
    <LM>w#w-d-id77210-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t538-7">
   <w.rf>
    <LM>w#w-d1t538-7</LM>
   </w.rf>
   <form>nechalo</form>
   <lemma>nechat</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m116-d1t538-9">
   <w.rf>
    <LM>w#w-d1t538-9</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m116-d1t538-10">
   <w.rf>
    <LM>w#w-d1t538-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t538-12">
   <w.rf>
    <LM>w#w-d1t538-12</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m116-d-m-d1e535-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e535-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e539-x2">
  <m id="m116-d1t542-1">
   <w.rf>
    <LM>w#w-d1t542-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t542-2">
   <w.rf>
    <LM>w#w-d1t542-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t542-3">
   <w.rf>
    <LM>w#w-d1t542-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t542-4">
   <w.rf>
    <LM>w#w-d1t542-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m116-d1t542-5">
   <w.rf>
    <LM>w#w-d1t542-5</LM>
   </w.rf>
   <form>naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d-id77430-punct">
   <w.rf>
    <LM>w#w-d-id77430-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e543-x2">
  <m id="m116-d1t548-9">
   <w.rf>
    <LM>w#w-d1t548-9</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t548-8">
   <w.rf>
    <LM>w#w-d1t548-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t548-10">
   <w.rf>
    <LM>w#w-d1t548-10</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1e543-x2-25">
   <w.rf>
    <LM>w#w-d1e543-x2-25</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1e543-x2-26">
   <w.rf>
    <LM>w#w-d1e543-x2-26</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t548-12">
   <w.rf>
    <LM>w#w-d1t548-12</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t548-13">
   <w.rf>
    <LM>w#w-d1t548-13</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m116-d1t548-14">
   <w.rf>
    <LM>w#w-d1t548-14</LM>
   </w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m116-d1t548-15">
   <w.rf>
    <LM>w#w-d1t548-15</LM>
   </w.rf>
   <form>hodí</form>
   <lemma>hodit-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m116-d1t548-16">
   <w.rf>
    <LM>w#w-d1t548-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t548-17">
   <w.rf>
    <LM>w#w-d1t548-17</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d-id77750-punct">
   <w.rf>
    <LM>w#w-d-id77750-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t548-22">
   <w.rf>
    <LM>w#w-d1t548-22</LM>
   </w.rf>
   <form>naučí</form>
   <lemma>naučit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m116-d1t548-21">
   <w.rf>
    <LM>w#w-d1t548-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t548-23">
   <w.rf>
    <LM>w#w-d1t548-23</LM>
   </w.rf>
   <form>plavat</form>
   <lemma>plavat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1e543-x2-24">
   <w.rf>
    <LM>w#w-d1e543-x2-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1e543-x2-27">
   <w.rf>
    <LM>w#w-d1e543-x2-27</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-28">
  <m id="m116-d1t548-25">
   <w.rf>
    <LM>w#w-d1t548-25</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t548-29">
   <w.rf>
    <LM>w#w-d1t548-29</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t548-27">
   <w.rf>
    <LM>w#w-d1t548-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t548-28">
   <w.rf>
    <LM>w#w-d1t548-28</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t548-30">
   <w.rf>
    <LM>w#w-d1t548-30</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m116-28-29">
   <w.rf>
    <LM>w#w-28-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-30">
  <m id="m116-d1t550-6">
   <w.rf>
    <LM>w#w-d1t550-6</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t550-3">
   <w.rf>
    <LM>w#w-d1t550-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m116-d1t550-2">
   <w.rf>
    <LM>w#w-d1t550-2</LM>
   </w.rf>
   <form>pomohli</form>
   <lemma>pomoci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m116-d1t550-4">
   <w.rf>
    <LM>w#w-d1t550-4</LM>
   </w.rf>
   <form>kamarádi</form>
   <lemma>kamarád</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m116-30-31">
   <w.rf>
    <LM>w#w-30-31</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-32">
  <m id="m116-32-46">
   <w.rf>
    <LM>w#w-32-46</LM>
   </w.rf>
   <form>Naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-32-45">
   <w.rf>
    <LM>w#w-32-45</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-32-44">
   <w.rf>
    <LM>w#w-32-44</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-32-43">
   <w.rf>
    <LM>w#w-32-43</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m116-32-42">
   <w.rf>
    <LM>w#w-32-42</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-32-41">
   <w.rf>
    <LM>w#w-32-41</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m116-32-40">
   <w.rf>
    <LM>w#w-32-40</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-32-39">
   <w.rf>
    <LM>w#w-32-39</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-32-38">
   <w.rf>
    <LM>w#w-32-38</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-32-37">
   <w.rf>
    <LM>w#w-32-37</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m116-32-36">
   <w.rf>
    <LM>w#w-32-36</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m116-32-35">
   <w.rf>
    <LM>w#w-32-35</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m116-32-34">
   <w.rf>
    <LM>w#w-32-34</LM>
   </w.rf>
   <form>učil</form>
   <lemma>učit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-32-33">
   <w.rf>
    <LM>w#w-32-33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e562-x2">
  <m id="m116-d1t565-1">
   <w.rf>
    <LM>w#w-d1t565-1</LM>
   </w.rf>
   <form>Jakým</form>
   <lemma>jaký</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m116-d1t565-2">
   <w.rf>
    <LM>w#w-d1t565-2</LM>
   </w.rf>
   <form>stylem</form>
   <lemma>styl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m116-d1t565-3">
   <w.rf>
    <LM>w#w-d1t565-3</LM>
   </w.rf>
   <form>plavete</form>
   <lemma>plavat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t565-4">
   <w.rf>
    <LM>w#w-d1t565-4</LM>
   </w.rf>
   <form>nejraději</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m116-d-id78367-punct">
   <w.rf>
    <LM>w#w-d-id78367-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e566-x2">
  <m id="m116-d1t571-1">
   <w.rf>
    <LM>w#w-d1t571-1</LM>
   </w.rf>
   <form>Nejraději</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m116-d1t571-2">
   <w.rf>
    <LM>w#w-d1t571-2</LM>
   </w.rf>
   <form>plavu</form>
   <lemma>plavat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t571-3">
   <w.rf>
    <LM>w#w-d1t571-3</LM>
   </w.rf>
   <form>prsa</form>
   <lemma>prsa</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m116-d1t571-4">
   <w.rf>
    <LM>w#w-d1t571-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t571-5">
   <w.rf>
    <LM>w#w-d1t571-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t571-6">
   <w.rf>
    <LM>w#w-d1t571-6</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t571-7">
   <w.rf>
    <LM>w#w-d1t571-7</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m116-d1t571-8">
   <w.rf>
    <LM>w#w-d1t571-8</LM>
   </w.rf>
   <form>znak</form>
   <lemma>znak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d-m-d1e566-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e566-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e578-x2">
  <m id="m116-d1t581-1">
   <w.rf>
    <LM>w#w-d1t581-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m116-d1e578-x2-56">
   <w.rf>
    <LM>w#w-d1e578-x2-56</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-57">
  <m id="m116-d1t583-1">
   <w.rf>
    <LM>w#w-d1t583-1</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m116-d1t583-2">
   <w.rf>
    <LM>w#w-d1t583-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t583-3">
   <w.rf>
    <LM>w#w-d1t583-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m116-d1t583-4">
   <w.rf>
    <LM>w#w-d1t583-4</LM>
   </w.rf>
   <form>otázce</form>
   <lemma>otázka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m116-57-58">
   <w.rf>
    <LM>w#w-57-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-59">
  <m id="m116-d1t585-1">
   <w.rf>
    <LM>w#w-d1t585-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m116-d1t585-2">
   <w.rf>
    <LM>w#w-d1t585-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t585-3">
   <w.rf>
    <LM>w#w-d1t585-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t585-4">
   <w.rf>
    <LM>w#w-d1t585-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t585-5">
   <w.rf>
    <LM>w#w-d1t585-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id78800-punct">
   <w.rf>
    <LM>w#w-d-id78800-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e586-x2">
  <m id="m116-d1t589-1">
   <w.rf>
    <LM>w#w-d1t589-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t589-2">
   <w.rf>
    <LM>w#w-d1t589-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t589-3">
   <w.rf>
    <LM>w#w-d1t589-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d-id78908-punct">
   <w.rf>
    <LM>w#w-d-id78908-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t589-5">
   <w.rf>
    <LM>w#w-d1t589-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t589-6">
   <w.rf>
    <LM>w#w-d1t589-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t589-7">
   <w.rf>
    <LM>w#w-d1t589-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t589-8">
   <w.rf>
    <LM>w#w-d1t589-8</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m116-d1t589-9">
   <w.rf>
    <LM>w#w-d1t589-9</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1e586-x2-175">
   <w.rf>
    <LM>w#w-d1e586-x2-175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1e586-x2-176">
   <w.rf>
    <LM>w#w-d1e586-x2-176</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t589-12">
   <w.rf>
    <LM>w#w-d1t589-12</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t589-13">
   <w.rf>
    <LM>w#w-d1t589-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t589-14">
   <w.rf>
    <LM>w#w-d1t589-14</LM>
   </w.rf>
   <form>současnosti</form>
   <lemma>současnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t589-15">
   <w.rf>
    <LM>w#w-d1t589-15</LM>
   </w.rf>
   <form>chodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t589-16">
   <w.rf>
    <LM>w#w-d1t589-16</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t589-17">
   <w.rf>
    <LM>w#w-d1t589-17</LM>
   </w.rf>
   <form>bowling</form>
   <lemma>bowling</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-68-69">
   <w.rf>
    <LM>w#w-68-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-70">
  <m id="m116-d1t591-4">
   <w.rf>
    <LM>w#w-d1t591-4</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t591-3">
   <w.rf>
    <LM>w#w-d1t591-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t593-1">
   <w.rf>
    <LM>w#w-d1t593-1</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m116-d1t593-2">
   <w.rf>
    <LM>w#w-d1t593-2</LM>
   </w.rf>
   <form>střediska</form>
   <lemma>středisko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m116-d-id79244-punct">
   <w.rf>
    <LM>w#w-d-id79244-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t593-4">
   <w.rf>
    <LM>w#w-d1t593-4</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m116-d1t593-5">
   <w.rf>
    <LM>w#w-d1t593-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t593-6">
   <w.rf>
    <LM>w#w-d1t593-6</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m116-d1t593-8">
   <w.rf>
    <LM>w#w-d1t593-8</LM>
   </w.rf>
   <form>Radava</form>
   <lemma>Radava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-70-71">
   <w.rf>
    <LM>w#w-70-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-72">
  <m id="m116-d1t593-11">
   <w.rf>
    <LM>w#w-d1t593-11</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t593-12">
   <w.rf>
    <LM>w#w-d1t593-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t593-13">
   <w.rf>
    <LM>w#w-d1t593-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t593-15">
   <w.rf>
    <LM>w#w-d1t593-15</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t593-16">
   <w.rf>
    <LM>w#w-d1t593-16</LM>
   </w.rf>
   <form>Milady</form>
   <lemma>Milada_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d1t593-17">
   <w.rf>
    <LM>w#w-d1t593-17</LM>
   </w.rf>
   <form>Horákové</form>
   <lemma>Horáková_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d-m-d1e586-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e586-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e594-x2">
  <m id="m116-d1t597-1">
   <w.rf>
    <LM>w#w-d1t597-1</LM>
   </w.rf>
   <form>Chodíte</form>
   <lemma>chodit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>bowling</form>
   <lemma>bowling</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d1t597-4">
   <w.rf>
    <LM>w#w-d1t597-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d-id79573-punct">
   <w.rf>
    <LM>w#w-d-id79573-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e598-x2">
  <m id="m116-d1t603-1">
   <w.rf>
    <LM>w#w-d1t603-1</LM>
   </w.rf>
   <form>Chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t603-2">
   <w.rf>
    <LM>w#w-d1t603-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m116-d1t603-3">
   <w.rf>
    <LM>w#w-d1t603-3</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t603-4">
   <w.rf>
    <LM>w#w-d1t603-4</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m116-d1t603-5">
   <w.rf>
    <LM>w#w-d1t603-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t603-6">
   <w.rf>
    <LM>w#w-d1t603-6</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m116-d1t603-7">
   <w.rf>
    <LM>w#w-d1t603-7</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m116-d-id79752-punct">
   <w.rf>
    <LM>w#w-d-id79752-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t603-9">
   <w.rf>
    <LM>w#w-d1t603-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t603-10">
   <w.rf>
    <LM>w#w-d1t603-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t603-11">
   <w.rf>
    <LM>w#w-d1t603-11</LM>
   </w.rf>
   <form>hodinu</form>
   <lemma>hodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d1e598-x2-79">
   <w.rf>
    <LM>w#w-d1e598-x2-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-80">
  <m id="m116-d1t605-6">
   <w.rf>
    <LM>w#w-d1t605-6</LM>
   </w.rf>
   <form>Nezdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m116-d1t605-4">
   <w.rf>
    <LM>w#w-d1t605-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t605-5">
   <w.rf>
    <LM>w#w-d1t605-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d-id79916-punct">
   <w.rf>
    <LM>w#w-d-id79916-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t605-8">
   <w.rf>
    <LM>w#w-d1t605-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t605-11">
   <w.rf>
    <LM>w#w-d1t605-11</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m116-d1t605-12">
   <w.rf>
    <LM>w#w-d1t605-12</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m116-80-81">
   <w.rf>
    <LM>w#w-80-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t605-13">
   <w.rf>
    <LM>w#w-d1t605-13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m116-80-84">
   <w.rf>
    <LM>w#w-80-84</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m116-d1t605-14">
   <w.rf>
    <LM>w#w-d1t605-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t605-15">
   <w.rf>
    <LM>w#w-d1t605-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d-id80063-punct">
   <w.rf>
    <LM>w#w-d-id80063-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t605-18">
   <w.rf>
    <LM>w#w-d1t605-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t605-19">
   <w.rf>
    <LM>w#w-d1t605-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t605-20">
   <w.rf>
    <LM>w#w-d1t605-20</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t605-21">
   <w.rf>
    <LM>w#w-d1t605-21</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t605-22">
   <w.rf>
    <LM>w#w-d1t605-22</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t605-24">
   <w.rf>
    <LM>w#w-d1t605-24</LM>
   </w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m116-80-82">
   <w.rf>
    <LM>w#w-80-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-83">
  <m id="m116-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t607-7">
   <w.rf>
    <LM>w#w-d1t607-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t607-8">
   <w.rf>
    <LM>w#w-d1t607-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t607-9">
   <w.rf>
    <LM>w#w-d1t607-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t607-10">
   <w.rf>
    <LM>w#w-d1t607-10</LM>
   </w.rf>
   <form>vyřádíme</form>
   <lemma>vyřádit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m116-83-85">
   <w.rf>
    <LM>w#w-83-85</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t607-14">
   <w.rf>
    <LM>w#w-d1t607-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t607-13">
   <w.rf>
    <LM>w#w-d1t607-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t607-5">
   <w.rf>
    <LM>w#w-d1t607-5</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>chutí</form>
   <lemma>chuť</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m116-d1t607-16">
   <w.rf>
    <LM>w#w-d1t607-16</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t607-15">
   <w.rf>
    <LM>w#w-d1t607-15</LM>
   </w.rf>
   <form>posedíme</form>
   <lemma>posedět</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m116-d1t607-18">
   <w.rf>
    <LM>w#w-d1t607-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t607-19">
   <w.rf>
    <LM>w#w-d1t607-19</LM>
   </w.rf>
   <form>popovídáme</form>
   <lemma>popovídat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m116-d-m-d1e598-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e598-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e608-x2">
  <m id="m116-d1t611-1">
   <w.rf>
    <LM>w#w-d1t611-1</LM>
   </w.rf>
   <form>Jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t611-2">
   <w.rf>
    <LM>w#w-d1t611-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m116-d1t611-3">
   <w.rf>
    <LM>w#w-d1t611-3</LM>
   </w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m116-d1t611-4">
   <w.rf>
    <LM>w#w-d1t611-4</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-d-id80591-punct">
   <w.rf>
    <LM>w#w-d-id80591-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e612-x2">
  <m id="m116-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t617-5">
   <w.rf>
    <LM>w#w-d1t617-5</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS6-P1-------</tag>
  </m>
  <m id="m116-d1t617-6">
   <w.rf>
    <LM>w#w-d1t617-6</LM>
   </w.rf>
   <form>skupině</form>
   <lemma>skupina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t617-7">
   <w.rf>
    <LM>w#w-d1t617-7</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t617-9">
   <w.rf>
    <LM>w#w-d1t617-9</LM>
   </w.rf>
   <form>partě</form>
   <lemma>parta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id80801-punct">
   <w.rf>
    <LM>w#w-d-id80801-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t617-11">
   <w.rf>
    <LM>w#w-d1t617-11</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t617-12">
   <w.rf>
    <LM>w#w-d1t617-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t617-13">
   <w.rf>
    <LM>w#w-d1t617-13</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d-id80856-punct">
   <w.rf>
    <LM>w#w-d-id80856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t617-21">
   <w.rf>
    <LM>w#w-d1t617-21</LM>
   </w.rf>
   <form>průměrný</form>
   <lemma>průměrný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m116-d1t617-22">
   <w.rf>
    <LM>w#w-d1t617-22</LM>
   </w.rf>
   <form>hráč</form>
   <lemma>hráč</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m116-d1e612-x2-92">
   <w.rf>
    <LM>w#w-d1e612-x2-92</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-93">
  <m id="m116-d1t619-9">
   <w.rf>
    <LM>w#w-d1t619-9</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m116-d1t619-10">
   <w.rf>
    <LM>w#w-d1t619-10</LM>
   </w.rf>
   <form>dobří</form>
   <lemma>dobrý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m116-d1t619-3">
   <w.rf>
    <LM>w#w-d1t619-3</LM>
   </w.rf>
   <form>hází</form>
   <lemma>házet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m116-d1t619-5">
   <w.rf>
    <LM>w#w-d1t619-5</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t619-7">
   <w.rf>
    <LM>w#w-d1t619-7</LM>
   </w.rf>
   <form>200</form>
   <lemma>200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m116-d1t619-11">
   <w.rf>
    <LM>w#w-d1t619-11</LM>
   </w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m116-93-94">
   <w.rf>
    <LM>w#w-93-94</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-95">
  <m id="m116-d1t619-15">
   <w.rf>
    <LM>w#w-d1t619-15</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m116-d1t619-16">
   <w.rf>
    <LM>w#w-d1t619-16</LM>
   </w.rf>
   <form>házím</form>
   <lemma>házet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t619-18">
   <w.rf>
    <LM>w#w-d1t619-18</LM>
   </w.rf>
   <form>150</form>
   <lemma>150</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m116-95-96">
   <w.rf>
    <LM>w#w-95-96</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t621-3">
   <w.rf>
    <LM>w#w-d1t621-3</LM>
   </w.rf>
   <form>průměr</form>
   <lemma>průměr</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d-m-d1e612-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e612-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e622-x2">
  <m id="m116-d1t625-1">
   <w.rf>
    <LM>w#w-d1t625-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m116-d1t625-2">
   <w.rf>
    <LM>w#w-d1t625-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t625-3">
   <w.rf>
    <LM>w#w-d1t625-3</LM>
   </w.rf>
   <form>uhrál</form>
   <lemma>uhrát</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d1t625-5">
   <w.rf>
    <LM>w#w-d1t625-5</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m116-d1t625-6">
   <w.rf>
    <LM>w#w-d1t625-6</LM>
   </w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m116-d-id81486-punct">
   <w.rf>
    <LM>w#w-d-id81486-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e626-x2">
  <m id="m116-d1t629-2">
   <w.rf>
    <LM>w#w-d1t629-2</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m116-d1t629-4">
   <w.rf>
    <LM>w#w-d1t629-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t629-5">
   <w.rf>
    <LM>w#w-d1t629-5</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d1t629-6">
   <w.rf>
    <LM>w#w-d1t629-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t629-7">
   <w.rf>
    <LM>w#w-d1t629-7</LM>
   </w.rf>
   <form>183</form>
   <lemma>183</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m116-d1t629-3">
   <w.rf>
    <LM>w#w-d1t629-3</LM>
   </w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m116-d-m-d1e626-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e626-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e630-x2">
  <m id="m116-d1t633-1">
   <w.rf>
    <LM>w#w-d1t633-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m116-d1t633-2">
   <w.rf>
    <LM>w#w-d1t633-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t633-3">
   <w.rf>
    <LM>w#w-d1t633-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m116-d1t633-4">
   <w.rf>
    <LM>w#w-d1t633-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t633-5">
   <w.rf>
    <LM>w#w-d1t633-5</LM>
   </w.rf>
   <form>bowlingu</form>
   <lemma>bowling</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m116-d1t633-6">
   <w.rf>
    <LM>w#w-d1t633-6</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d-id81833-punct">
   <w.rf>
    <LM>w#w-d-id81833-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e634-x2">
  <m id="m116-d1t639-1">
   <w.rf>
    <LM>w#w-d1t639-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t639-2">
   <w.rf>
    <LM>w#w-d1t639-2</LM>
   </w.rf>
   <form>bowlingu</form>
   <lemma>bowling</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m116-d1t639-3">
   <w.rf>
    <LM>w#w-d1t639-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t639-4">
   <w.rf>
    <LM>w#w-d1t639-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m116-d1t639-5">
   <w.rf>
    <LM>w#w-d1t639-5</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d-id81981-punct">
   <w.rf>
    <LM>w#w-d-id81981-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t639-7">
   <w.rf>
    <LM>w#w-d1t639-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t639-9">
   <w.rf>
    <LM>w#w-d1t639-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t639-8">
   <w.rf>
    <LM>w#w-d1t639-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t639-11">
   <w.rf>
    <LM>w#w-d1t639-11</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m116-d1e634-x2-107">
   <w.rf>
    <LM>w#w-d1e634-x2-107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t639-12">
   <w.rf>
    <LM>w#w-d1t639-12</LM>
   </w.rf>
   <form>řek</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP-7</tag>
  </m>
  <m id="m116-d1t639-13">
   <w.rf>
    <LM>w#w-d1t639-13</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m116-d1e634-x2-108">
   <w.rf>
    <LM>w#w-d1e634-x2-108</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t639-14">
   <w.rf>
    <LM>w#w-d1t639-14</LM>
   </w.rf>
   <form>příjemná</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d1t639-15">
   <w.rf>
    <LM>w#w-d1t639-15</LM>
   </w.rf>
   <form>relaxace</form>
   <lemma>relaxace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t639-16">
   <w.rf>
    <LM>w#w-d1t639-16</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t639-17">
   <w.rf>
    <LM>w#w-d1t639-17</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1e634-x2-109">
   <w.rf>
    <LM>w#w-d1e634-x2-109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
