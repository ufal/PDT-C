<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_035.01.w.gz" />
  </references>
 </head>
 <s id="m035-648">
  <m id="m035-d1t388-5">
   <w.rf>
    <LM>w#w-d1t388-5</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t388-6">
   <w.rf>
    <LM>w#w-d1t388-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t388-7">
   <w.rf>
    <LM>w#w-d1t388-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t388-9">
   <w.rf>
    <LM>w#w-d1t388-9</LM>
   </w.rf>
   <form>čtyřmi</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m035-d1t388-10">
   <w.rf>
    <LM>w#w-d1t388-10</LM>
   </w.rf>
   <form>auty</form>
   <lemma>auto</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m035-d-m-d1e383-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e383-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e389-x2">
  <m id="m035-d1t392-1">
   <w.rf>
    <LM>w#w-d1t392-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e389-x2-650">
   <w.rf>
    <LM>w#w-d1e389-x2-650</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-651">
  <m id="m035-d1t394-1">
   <w.rf>
    <LM>w#w-d1t394-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t394-2">
   <w.rf>
    <LM>w#w-d1t394-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t394-3">
   <w.rf>
    <LM>w#w-d1t394-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t394-4">
   <w.rf>
    <LM>w#w-d1t394-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t394-5">
   <w.rf>
    <LM>w#w-d1t394-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d-id65755-punct">
   <w.rf>
    <LM>w#w-d-id65755-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e395-x2">
  <m id="m035-d1t398-1">
   <w.rf>
    <LM>w#w-d1t398-1</LM>
   </w.rf>
   <form>Tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m035-d1t398-2">
   <w.rf>
    <LM>w#w-d1t398-2</LM>
   </w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d1t398-5">
   <w.rf>
    <LM>w#w-d1t398-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t398-6">
   <w.rf>
    <LM>w#w-d1t398-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t398-7">
   <w.rf>
    <LM>w#w-d1t398-7</LM>
   </w.rf>
   <form>cestou</form>
   <lemma>cesta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m035-d-m-d1e395-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e395-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e399-x3">
  <m id="m035-d1t408-1">
   <w.rf>
    <LM>w#w-d1t408-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t408-2">
   <w.rf>
    <LM>w#w-d1t408-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t408-3">
   <w.rf>
    <LM>w#w-d1t408-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d-m-d1e399-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e399-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e409-x2">
  <m id="m035-d1t412-1">
   <w.rf>
    <LM>w#w-d1t412-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e409-x2-654">
   <w.rf>
    <LM>w#w-d1e409-x2-654</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e413-x2">
  <m id="m035-d1t416-1">
   <w.rf>
    <LM>w#w-d1t416-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t416-2">
   <w.rf>
    <LM>w#w-d1t416-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t416-3">
   <w.rf>
    <LM>w#w-d1t416-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d-m-d1e413-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e413-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e417-x2">
  <m id="m035-d1t422-2">
   <w.rf>
    <LM>w#w-d1t422-2</LM>
   </w.rf>
   <form>Cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1t422-3">
   <w.rf>
    <LM>w#w-d1t422-3</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m035-d1t422-4">
   <w.rf>
    <LM>w#w-d1t422-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t422-5">
   <w.rf>
    <LM>w#w-d1t422-5</LM>
   </w.rf>
   <form>pěkná</form>
   <lemma>pěkný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m035-d1e417-x2-657">
   <w.rf>
    <LM>w#w-d1e417-x2-657</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-658">
  <m id="m035-d1t422-8">
   <w.rf>
    <LM>w#w-d1t422-8</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t424-1">
   <w.rf>
    <LM>w#w-d1t424-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t422-7">
   <w.rf>
    <LM>w#w-d1t422-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t422-9">
   <w.rf>
    <LM>w#w-d1t422-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t424-2">
   <w.rf>
    <LM>w#w-d1t424-2</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d-id66408-punct">
   <w.rf>
    <LM>w#w-d-id66408-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t424-4">
   <w.rf>
    <LM>w#w-d1t424-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t424-5">
   <w.rf>
    <LM>w#w-d1t424-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t424-6">
   <w.rf>
    <LM>w#w-d1t424-6</LM>
   </w.rf>
   <form>říkalo</form>
   <lemma>říkat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-658-659">
   <w.rf>
    <LM>w#w-658-659</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t424-7">
   <w.rf>
    <LM>w#w-d1t424-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t424-8">
   <w.rf>
    <LM>w#w-d1t424-8</LM>
   </w.rf>
   <form>vitacitem</form>
   <lemma>vitacit</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m035-d1t424-9">
   <w.rf>
    <LM>w#w-d1t424-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-658-660">
   <w.rf>
    <LM>w#w-658-660</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-658-661">
   <w.rf>
    <LM>w#w-658-661</LM>
   </w.rf>
   <form>krevní</form>
   <lemma>krevní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m035-658-662">
   <w.rf>
    <LM>w#w-658-662</LM>
   </w.rf>
   <form>tučnicí</form>
   <lemma>tučnice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m035-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>celého</form>
   <lemma>celý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m035-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d-m-d1e417-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e417-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e428-x2">
  <m id="m035-d1t439-1">
   <w.rf>
    <LM>w#w-d1t439-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t439-2">
   <w.rf>
    <LM>w#w-d1t439-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t439-3">
   <w.rf>
    <LM>w#w-d1t439-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m035-d1t439-4">
   <w.rf>
    <LM>w#w-d1t439-4</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m035-d1t439-6">
   <w.rf>
    <LM>w#w-d1t439-6</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d-id66746-punct">
   <w.rf>
    <LM>w#w-d-id66746-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e440-x2">
  <m id="m035-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m035-d1t447-4">
   <w.rf>
    <LM>w#w-d1t447-4</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t447-7">
   <w.rf>
    <LM>w#w-d1t447-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t447-8">
   <w.rf>
    <LM>w#w-d1t447-8</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t447-9">
   <w.rf>
    <LM>w#w-d1t447-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t449-2">
   <w.rf>
    <LM>w#w-d1t449-2</LM>
   </w.rf>
   <form>Maďarsku</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-d1t449-5">
   <w.rf>
    <LM>w#w-d1t449-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t449-7">
   <w.rf>
    <LM>w#w-d1t449-7</LM>
   </w.rf>
   <form>Letenye</form>
   <lemma>Letenye_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m035-d1e440-x2-61">
   <w.rf>
    <LM>w#w-d1e440-x2-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-67">
  <m id="m035-d1t449-11">
   <w.rf>
    <LM>w#w-d1t449-11</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t449-12">
   <w.rf>
    <LM>w#w-d1t449-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t449-13">
   <w.rf>
    <LM>w#w-d1t449-13</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t454-7">
   <w.rf>
    <LM>w#w-d1t454-7</LM>
   </w.rf>
   <form>Rumunsku</form>
   <lemma>Rumunsko-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-d1t449-14">
   <w.rf>
    <LM>w#w-d1t449-14</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t449-16">
   <w.rf>
    <LM>w#w-d1t449-16</LM>
   </w.rf>
   <form>Aradem</form>
   <lemma>Arad_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m035-d1t456-5">
   <w.rf>
    <LM>w#w-d1t456-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t456-6">
   <w.rf>
    <LM>w#w-d1t456-6</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t456-7">
   <w.rf>
    <LM>w#w-d1t456-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t456-8">
   <w.rf>
    <LM>w#w-d1t456-8</LM>
   </w.rf>
   <form>přejížděli</form>
   <lemma>přejíždět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1e440-x2-712">
   <w.rf>
    <LM>w#w-d1e440-x2-712</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-713">
  <m id="m035-d1t456-14">
   <w.rf>
    <LM>w#w-d1t456-14</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m035-d1t456-15">
   <w.rf>
    <LM>w#w-d1t456-15</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t456-16">
   <w.rf>
    <LM>w#w-d1t456-16</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t456-17">
   <w.rf>
    <LM>w#w-d1t456-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t456-12">
   <w.rf>
    <LM>w#w-d1t456-12</LM>
   </w.rf>
   <form>vyjížděli</form>
   <lemma>vyjíždět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t456-20">
   <w.rf>
    <LM>w#w-d1t456-20</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t456-22">
   <w.rf>
    <LM>w#w-d1t456-22</LM>
   </w.rf>
   <form>Tlučné</form>
   <lemma>Tlučná_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m035-d-id67676-punct">
   <w.rf>
    <LM>w#w-d-id67676-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t458-1">
   <w.rf>
    <LM>w#w-d1t458-1</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m035-d1t458-2">
   <w.rf>
    <LM>w#w-d1t458-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t458-3">
   <w.rf>
    <LM>w#w-d1t458-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t458-5">
   <w.rf>
    <LM>w#w-d1t458-5</LM>
   </w.rf>
   <form>Maďarska</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m035-d1t458-8">
   <w.rf>
    <LM>w#w-d1t458-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t460-3">
   <w.rf>
    <LM>w#w-d1t460-3</LM>
   </w.rf>
   <form>Letenye</form>
   <lemma>Letenye_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m035-d-id67849-punct">
   <w.rf>
    <LM>w#w-d-id67849-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-713-740">
   <w.rf>
    <LM>w#w-713-740</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t460-7">
   <w.rf>
    <LM>w#w-d1t460-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t460-8">
   <w.rf>
    <LM>w#w-d1t460-8</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d-m-d1e440-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e440-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e461-x2">
  <m id="m035-d1t470-2">
   <w.rf>
    <LM>w#w-d1t470-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t470-3">
   <w.rf>
    <LM>w#w-d1t470-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t470-4">
   <w.rf>
    <LM>w#w-d1t470-4</LM>
   </w.rf>
   <form>přejížděli</form>
   <lemma>přejíždět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>Rumunsko</form>
   <lemma>Rumunsko-2_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d1t481-6">
   <w.rf>
    <LM>w#w-d1t481-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1e461-x2-39">
   <w.rf>
    <LM>w#w-d1e461-x2-39</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t481-8">
   <w.rf>
    <LM>w#w-d1t481-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t481-9">
   <w.rf>
    <LM>w#w-d1t481-9</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t483-1">
   <w.rf>
    <LM>w#w-d1t483-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t483-3">
   <w.rf>
    <LM>w#w-d1t483-3</LM>
   </w.rf>
   <form>Aradu</form>
   <lemma>Arad_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d1e461-x2-800">
   <w.rf>
    <LM>w#w-d1e461-x2-800</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-801">
  <m id="m035-d1t483-19">
   <w.rf>
    <LM>w#w-d1t483-19</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t483-17">
   <w.rf>
    <LM>w#w-d1t483-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t483-16">
   <w.rf>
    <LM>w#w-d1t483-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t483-18">
   <w.rf>
    <LM>w#w-d1t483-18</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t483-21">
   <w.rf>
    <LM>w#w-d1t483-21</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t483-22">
   <w.rf>
    <LM>w#w-d1t483-22</LM>
   </w.rf>
   <form>kempu</form>
   <lemma>kemp</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d-m-d1e478-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e478-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e484-x2">
  <m id="m035-d1t487-1">
   <w.rf>
    <LM>w#w-d1t487-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m035-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d-id68580-punct">
   <w.rf>
    <LM>w#w-d-id68580-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e488-x2">
  <m id="m035-d1t493-3">
   <w.rf>
    <LM>w#w-d1t493-3</LM>
   </w.rf>
   <form>Počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d1t493-4">
   <w.rf>
    <LM>w#w-d1t493-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t493-5">
   <w.rf>
    <LM>w#w-d1t493-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t493-6">
   <w.rf>
    <LM>w#w-d1t493-6</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t493-7">
   <w.rf>
    <LM>w#w-d1t493-7</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d-m-d1e488-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e488-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e494-x2">
  <m id="m035-d1t501-14">
   <w.rf>
    <LM>w#w-d1t501-14</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m035-d1t501-15">
   <w.rf>
    <LM>w#w-d1t501-15</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t501-12">
   <w.rf>
    <LM>w#w-d1t501-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t501-16">
   <w.rf>
    <LM>w#w-d1t501-16</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t501-13">
   <w.rf>
    <LM>w#w-d1t501-13</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1e494-x2-889">
   <w.rf>
    <LM>w#w-d1e494-x2-889</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t512-2">
   <w.rf>
    <LM>w#w-d1t512-2</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t501-3">
   <w.rf>
    <LM>w#w-d1t501-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t501-5">
   <w.rf>
    <LM>w#w-d1t501-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t501-6">
   <w.rf>
    <LM>w#w-d1t501-6</LM>
   </w.rf>
   <form>dovolených</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m035-d1e494-x2-890">
   <w.rf>
    <LM>w#w-d1e494-x2-890</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t501-7">
   <w.rf>
    <LM>w#w-d1t501-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m035-d1t501-8">
   <w.rf>
    <LM>w#w-d1t501-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t501-9">
   <w.rf>
    <LM>w#w-d1t501-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1e494-x2-891">
   <w.rf>
    <LM>w#w-d1e494-x2-891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t512-6">
   <w.rf>
    <LM>w#w-d1t512-6</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t512-7">
   <w.rf>
    <LM>w#w-d1t512-7</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d1e494-x2-892">
   <w.rf>
    <LM>w#w-d1e494-x2-892</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t514-2">
   <w.rf>
    <LM>w#w-d1t514-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t514-4">
   <w.rf>
    <LM>w#w-d1t514-4</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m035-d1t514-5">
   <w.rf>
    <LM>w#w-d1t514-5</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d1e494-x2-893">
   <w.rf>
    <LM>w#w-d1e494-x2-893</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-894">
  <m id="m035-d1t514-8">
   <w.rf>
    <LM>w#w-d1t514-8</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t514-9">
   <w.rf>
    <LM>w#w-d1t514-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-id69327-punct">
   <w.rf>
    <LM>w#w-d-id69327-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t514-11">
   <w.rf>
    <LM>w#w-d1t514-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t514-12">
   <w.rf>
    <LM>w#w-d1t514-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t514-13">
   <w.rf>
    <LM>w#w-d1t514-13</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t516-1">
   <w.rf>
    <LM>w#w-d1t516-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t518-3">
   <w.rf>
    <LM>w#w-d1t518-3</LM>
   </w.rf>
   <form>Benecko</form>
   <lemma>Benecko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d-id69457-punct">
   <w.rf>
    <LM>w#w-d-id69457-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t520-1">
   <w.rf>
    <LM>w#w-d1t520-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t520-3">
   <w.rf>
    <LM>w#w-d1t520-3</LM>
   </w.rf>
   <form>Vrchlabí</form>
   <lemma>Vrchlabí_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m035-d-id69532-punct">
   <w.rf>
    <LM>w#w-d-id69532-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t520-7">
   <w.rf>
    <LM>w#w-d1t520-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t520-9">
   <w.rf>
    <LM>w#w-d1t520-9</LM>
   </w.rf>
   <form>Harachova</form>
   <lemma>Harachov_;G_,i_^(^DS**Harrachov)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d1t523-1">
   <w.rf>
    <LM>w#w-d1t523-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t523-2">
   <w.rf>
    <LM>w#w-d1t523-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t523-4">
   <w.rf>
    <LM>w#w-d1t523-4</LM>
   </w.rf>
   <form>Máchovo</form>
   <lemma>Máchův_;Y_^(*2a)</lemma>
   <tag>AUNS4M---------</tag>
  </m>
  <m id="m035-d1t523-5">
   <w.rf>
    <LM>w#w-d1t523-5</LM>
   </w.rf>
   <form>jezero</form>
   <lemma>jezero</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d-id69689-punct">
   <w.rf>
    <LM>w#w-d-id69689-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t523-10">
   <w.rf>
    <LM>w#w-d1t523-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t523-9">
   <w.rf>
    <LM>w#w-d1t523-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t523-11">
   <w.rf>
    <LM>w#w-d1t523-11</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-894-895">
   <w.rf>
    <LM>w#w-894-895</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-896">
  <m id="m035-d1t529-4">
   <w.rf>
    <LM>w#w-d1t529-4</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t539-2">
   <w.rf>
    <LM>w#w-d1t539-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m035-d1t539-5">
   <w.rf>
    <LM>w#w-d1t539-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t539-6">
   <w.rf>
    <LM>w#w-d1t539-6</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t539-7">
   <w.rf>
    <LM>w#w-d1t539-7</LM>
   </w.rf>
   <form>nepršelo</form>
   <lemma>pršet</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-d-id70128-punct">
   <w.rf>
    <LM>w#w-d-id70128-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t539-10">
   <w.rf>
    <LM>w#w-d1t539-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-896-903">
   <w.rf>
    <LM>w#w-896-903</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t539-11">
   <w.rf>
    <LM>w#w-d1t539-11</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e536-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e536-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e542-x2">
  <m id="m035-d1t545-1">
   <w.rf>
    <LM>w#w-d1t545-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t545-2">
   <w.rf>
    <LM>w#w-d1t545-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t545-3">
   <w.rf>
    <LM>w#w-d1t545-3</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m035-d1t545-4">
   <w.rf>
    <LM>w#w-d1t545-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m035-d1t545-5">
   <w.rf>
    <LM>w#w-d1t545-5</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m035-d1t545-6">
   <w.rf>
    <LM>w#w-d1t545-6</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m035-d1t545-7">
   <w.rf>
    <LM>w#w-d1t545-7</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d-id70381-punct">
   <w.rf>
    <LM>w#w-d-id70381-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e547-x2">
  <m id="m035-d1t552-3">
   <w.rf>
    <LM>w#w-d1t552-3</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d-id70491-punct">
   <w.rf>
    <LM>w#w-d-id70491-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t554-1">
   <w.rf>
    <LM>w#w-d1t554-1</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e547-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e547-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-934">
  <m id="m035-d1t579-2">
   <w.rf>
    <LM>w#w-d1t579-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t579-3">
   <w.rf>
    <LM>w#w-d1t579-3</LM>
   </w.rf>
   <form>úterý</form>
   <lemma>úterý</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d1t579-4">
   <w.rf>
    <LM>w#w-d1t579-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-d1t579-5">
   <w.rf>
    <LM>w#w-d1t579-5</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m035-934-935">
   <w.rf>
    <LM>w#w-934-935</LM>
   </w.rf>
   <form>39</form>
   <lemma>39</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t579-1">
   <w.rf>
    <LM>w#w-d1t579-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t577-16">
   <w.rf>
    <LM>w#w-d1t577-16</LM>
   </w.rf>
   <form>včera</form>
   <lemma>včera</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t577-17">
   <w.rf>
    <LM>w#w-d1t577-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t577-18">
   <w.rf>
    <LM>w#w-d1t577-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t577-19">
   <w.rf>
    <LM>w#w-d1t577-19</LM>
   </w.rf>
   <form>slavili</form>
   <lemma>slavit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-934-936">
   <w.rf>
    <LM>w#w-934-936</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-937">
  <m id="m035-d1t581-2">
   <w.rf>
    <LM>w#w-d1t581-2</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m035-d1t581-3">
   <w.rf>
    <LM>w#w-d1t581-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t581-4">
   <w.rf>
    <LM>w#w-d1t581-4</LM>
   </w.rf>
   <form>tamodtud</form>
   <lemma>tamodtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-937-938">
   <w.rf>
    <LM>w#w-937-938</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t589-3">
   <w.rf>
    <LM>w#w-d1t589-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t589-4">
   <w.rf>
    <LM>w#w-d1t589-4</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m035-937-939">
   <w.rf>
    <LM>w#w-937-939</LM>
   </w.rf>
   <form>1968</form>
   <lemma>1968</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d-m-d1e584-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e584-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e584-x3">
  <m id="m035-d1t591-1">
   <w.rf>
    <LM>w#w-d1t591-1</LM>
   </w.rf>
   <form>Zajímavý</form>
   <lemma>zajímavý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1t591-2">
   <w.rf>
    <LM>w#w-d1t591-2</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e584-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e584-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e592-x2">
  <m id="m035-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t597-1">
   <w.rf>
    <LM>w#w-d1t597-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>perfektní</form>
   <lemma>perfektní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1t597-4">
   <w.rf>
    <LM>w#w-d1t597-4</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e592-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e592-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e600-x2">
  <m id="m035-d1t603-1">
   <w.rf>
    <LM>w#w-d1t603-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t603-2">
   <w.rf>
    <LM>w#w-d1t603-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t603-3">
   <w.rf>
    <LM>w#w-d1t603-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d-id71658-punct">
   <w.rf>
    <LM>w#w-d-id71658-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e604-x2">
  <m id="m035-d1t609-1">
   <w.rf>
    <LM>w#w-d1t609-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e604-x2-941">
   <w.rf>
    <LM>w#w-d1e604-x2-941</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e610-x2">
  <m id="m035-d1t613-1">
   <w.rf>
    <LM>w#w-d1t613-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t613-2">
   <w.rf>
    <LM>w#w-d1t613-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t613-3">
   <w.rf>
    <LM>w#w-d1t613-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d-id71843-punct">
   <w.rf>
    <LM>w#w-d-id71843-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e614-x2">
  <m id="m035-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>Nerozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-d1e614-x2-946">
   <w.rf>
    <LM>w#w-d1e614-x2-946</LM>
   </w.rf>
   <form>otázce</form>
   <lemma>otázka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m035-d1e618-x2-948">
   <w.rf>
    <LM>w#w-d1e618-x2-948</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e618-x2">
  <m id="m035-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t621-2">
   <w.rf>
    <LM>w#w-d1t621-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t621-3">
   <w.rf>
    <LM>w#w-d1t621-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t621-4">
   <w.rf>
    <LM>w#w-d1t621-4</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m035-d-id72099-punct">
   <w.rf>
    <LM>w#w-d-id72099-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e622-x2">
  <m id="m035-d1t627-2">
   <w.rf>
    <LM>w#w-d1t627-2</LM>
   </w.rf>
   <form>Jakpak</form>
   <lemma>jakpak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t627-3">
   <w.rf>
    <LM>w#w-d1t627-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t627-4">
   <w.rf>
    <LM>w#w-d1t627-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1e622-x2-956">
   <w.rf>
    <LM>w#w-d1e622-x2-956</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t627-5">
   <w.rf>
    <LM>w#w-d1t627-5</LM>
   </w.rf>
   <form>stane</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m035-d-id72289-punct">
   <w.rf>
    <LM>w#w-d-id72289-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t627-11">
   <w.rf>
    <LM>w#w-d1t627-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t627-12">
   <w.rf>
    <LM>w#w-d1t627-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t629-3">
   <w.rf>
    <LM>w#w-d1t629-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t629-4">
   <w.rf>
    <LM>w#w-d1t629-4</LM>
   </w.rf>
   <form>devíti</form>
   <lemma>devět`9</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m035-d1t629-5">
   <w.rf>
    <LM>w#w-d1t629-5</LM>
   </w.rf>
   <form>měsících</form>
   <lemma>měsíc</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m035-d1t627-13">
   <w.rf>
    <LM>w#w-d1t627-13</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d1e622-x2-50">
   <w.rf>
    <LM>w#w-d1e622-x2-50</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e646-x2">
  <m id="m035-d1t649-5">
   <w.rf>
    <LM>w#w-d1t649-5</LM>
   </w.rf>
   <form>Chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t649-2">
   <w.rf>
    <LM>w#w-d1t649-2</LM>
   </w.rf>
   <form>byste</form>
   <lemma>být</lemma>
   <tag>Vc----------Ie-</tag>
  </m>
  <m id="m035-d1t649-3">
   <w.rf>
    <LM>w#w-d1t649-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t649-4">
   <w.rf>
    <LM>w#w-d1t649-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t649-1">
   <w.rf>
    <LM>w#w-d1t649-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t649-6">
   <w.rf>
    <LM>w#w-d1t649-6</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m035-d-id72673-punct">
   <w.rf>
    <LM>w#w-d-id72673-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e650-x2">
  <m id="m035-d1t655-3">
   <w.rf>
    <LM>w#w-d1t655-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t655-5">
   <w.rf>
    <LM>w#w-d1t655-5</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t655-6">
   <w.rf>
    <LM>w#w-d1t655-6</LM>
   </w.rf>
   <form>heslo</form>
   <lemma>heslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d-id72836-punct">
   <w.rf>
    <LM>w#w-d-id72836-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t655-8">
   <w.rf>
    <LM>w#w-d1t655-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t655-10">
   <w.rf>
    <LM>w#w-d1t655-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t655-11">
   <w.rf>
    <LM>w#w-d1t655-11</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1t655-12">
   <w.rf>
    <LM>w#w-d1t655-12</LM>
   </w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m035-d1t655-9">
   <w.rf>
    <LM>w#w-d1t655-9</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t655-13">
   <w.rf>
    <LM>w#w-d1t655-13</LM>
   </w.rf>
   <form>vracet</form>
   <lemma>vracet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1t655-14">
   <w.rf>
    <LM>w#w-d1t655-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-id72947-punct">
   <w.rf>
    <LM>w#w-d-id72947-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t655-16">
   <w.rf>
    <LM>w#w-d1t655-16</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t655-17">
   <w.rf>
    <LM>w#w-d1t655-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t655-18">
   <w.rf>
    <LM>w#w-d1t655-18</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-d1t655-19">
   <w.rf>
    <LM>w#w-d1t655-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t655-20">
   <w.rf>
    <LM>w#w-d1t655-20</LM>
   </w.rf>
   <form>zdálo</form>
   <lemma>zdát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t655-21">
   <w.rf>
    <LM>w#w-d1t655-21</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1e650-x2-374">
   <w.rf>
    <LM>w#w-d1e650-x2-374</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-377">
  <m id="m035-d1t657-6">
   <w.rf>
    <LM>w#w-d1t657-6</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t657-2">
   <w.rf>
    <LM>w#w-d1t657-2</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m035-d1t657-3">
   <w.rf>
    <LM>w#w-d1t657-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t657-4">
   <w.rf>
    <LM>w#w-d1t657-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t657-5">
   <w.rf>
    <LM>w#w-d1t657-5</LM>
   </w.rf>
   <form>vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1t659-1">
   <w.rf>
    <LM>w#w-d1t659-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1e650-x2-970">
   <w.rf>
    <LM>w#w-d1e650-x2-970</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t659-4">
   <w.rf>
    <LM>w#w-d1t659-4</LM>
   </w.rf>
   <form>samé</form>
   <lemma>samý</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m035-d1t659-3">
   <w.rf>
    <LM>w#w-d1t659-3</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-d-id73197-punct">
   <w.rf>
    <LM>w#w-d-id73197-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t659-6">
   <w.rf>
    <LM>w#w-d1t659-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t659-7">
   <w.rf>
    <LM>w#w-d1t659-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t659-8">
   <w.rf>
    <LM>w#w-d1t659-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m035-d1t659-9">
   <w.rf>
    <LM>w#w-d1t659-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t659-10">
   <w.rf>
    <LM>w#w-d1t659-10</LM>
   </w.rf>
   <form>zdálo</form>
   <lemma>zdát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t659-11">
   <w.rf>
    <LM>w#w-d1t659-11</LM>
   </w.rf>
   <form>nádherné</form>
   <lemma>nádherný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1e650-x2-64">
   <w.rf>
    <LM>w#w-d1e650-x2-64</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e650-x2-59">
   <w.rf>
    <LM>w#w-d1e650-x2-59</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1e650-x2-60">
   <w.rf>
    <LM>w#w-d1e650-x2-60</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1e650-x2-61">
   <w.rf>
    <LM>w#w-d1e650-x2-61</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e650-x2-62">
   <w.rf>
    <LM>w#w-d1e650-x2-62</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1e650-x2-63">
   <w.rf>
    <LM>w#w-d1e650-x2-63</LM>
   </w.rf>
   <form>zklamaný</form>
   <lemma>zklamaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1e650-x2-65">
   <w.rf>
    <LM>w#w-d1e650-x2-65</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-74">
  <m id="m035-74-75">
   <w.rf>
    <LM>w#w-74-75</LM>
   </w.rf>
   <form>Vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-74-76">
   <w.rf>
    <LM>w#w-74-76</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-74-77">
   <w.rf>
    <LM>w#w-74-77</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-74-78">
   <w.rf>
    <LM>w#w-74-78</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t661-1">
   <w.rf>
    <LM>w#w-d1t661-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t661-2">
   <w.rf>
    <LM>w#w-d1t661-2</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m035-d1t661-3">
   <w.rf>
    <LM>w#w-d1t661-3</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m035-d1t659-13">
   <w.rf>
    <LM>w#w-d1t659-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t659-14">
   <w.rf>
    <LM>w#w-d1t659-14</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t659-15">
   <w.rf>
    <LM>w#w-d1t659-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t659-18">
   <w.rf>
    <LM>w#w-d1t659-18</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t659-17">
   <w.rf>
    <LM>w#w-d1t659-17</LM>
   </w.rf>
   <form>zklamaný</form>
   <lemma>zklamaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1e650-x2-971">
   <w.rf>
    <LM>w#w-d1e650-x2-971</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-972">
  <m id="m035-d1t664-2">
   <w.rf>
    <LM>w#w-d1t664-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t664-3">
   <w.rf>
    <LM>w#w-d1t664-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t666-1">
   <w.rf>
    <LM>w#w-d1t666-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t666-3">
   <w.rf>
    <LM>w#w-d1t666-3</LM>
   </w.rf>
   <form>Slovensku</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-972-996">
   <w.rf>
    <LM>w#w-972-996</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-972-407">
   <w.rf>
    <LM>w#w-972-407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-972-408">
   <w.rf>
    <LM>w#w-972-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-972-409">
   <w.rf>
    <LM>w#w-972-409</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-411">
  <m id="m035-411-412">
   <w.rf>
    <LM>w#w-411-412</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-411-413">
   <w.rf>
    <LM>w#w-411-413</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t670-11">
   <w.rf>
    <LM>w#w-d1t670-11</LM>
   </w.rf>
   <form>Chopok</form>
   <lemma>Chopok_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-411-415">
   <w.rf>
    <LM>w#w-411-415</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-411-416">
   <w.rf>
    <LM>w#w-411-416</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-411-414">
   <w.rf>
    <LM>w#w-411-414</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m035-411-417">
   <w.rf>
    <LM>w#w-411-417</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m035-d1t670-15">
   <w.rf>
    <LM>w#w-d1t670-15</LM>
   </w.rf>
   <form>hora</form>
   <lemma>hora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-411-418">
   <w.rf>
    <LM>w#w-411-418</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-411-419">
   <w.rf>
    <LM>w#w-411-419</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-411-420">
   <w.rf>
    <LM>w#w-411-420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-411-421">
   <w.rf>
    <LM>w#w-411-421</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-426">
  <m id="m035-411-422">
   <w.rf>
    <LM>w#w-411-422</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-411-423">
   <w.rf>
    <LM>w#w-411-423</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-411-424">
   <w.rf>
    <LM>w#w-411-424</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jedno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-426-427">
   <w.rf>
    <LM>w#w-426-427</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-433">
  <m id="m035-426-428">
   <w.rf>
    <LM>w#w-426-428</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-426-429">
   <w.rf>
    <LM>w#w-426-429</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-426-430">
   <w.rf>
    <LM>w#w-426-430</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-972-95">
   <w.rf>
    <LM>w#w-972-95</LM>
   </w.rf>
   <form>Chopku</form>
   <lemma>Chopok_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-433-434">
   <w.rf>
    <LM>w#w-433-434</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-96">
  <m id="m035-d1t674-9">
   <w.rf>
    <LM>w#w-d1t674-9</LM>
   </w.rf>
   <form>Vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1t674-5">
   <w.rf>
    <LM>w#w-d1t674-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t674-7">
   <w.rf>
    <LM>w#w-d1t674-7</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m035-d1t674-2">
   <w.rf>
    <LM>w#w-d1t674-2</LM>
   </w.rf>
   <form>Liptovský</form>
   <lemma>liptovský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1t674-3">
   <w.rf>
    <LM>w#w-d1t674-3</LM>
   </w.rf>
   <form>Ján</form>
   <lemma>Ján_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e650-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e650-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e678-x2">
  <m id="m035-d1t693-4">
   <w.rf>
    <LM>w#w-d1t693-4</LM>
   </w.rf>
   <form>Rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t693-5">
   <w.rf>
    <LM>w#w-d1t693-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t693-6">
   <w.rf>
    <LM>w#w-d1t693-6</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t693-2">
   <w.rf>
    <LM>w#w-d1t693-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t683-2">
   <w.rf>
    <LM>w#w-d1t683-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t693-3">
   <w.rf>
    <LM>w#w-d1t693-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t683-5">
   <w.rf>
    <LM>w#w-d1t683-5</LM>
   </w.rf>
   <form>prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t693-8">
   <w.rf>
    <LM>w#w-d1t693-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t693-12">
   <w.rf>
    <LM>w#w-d1t693-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t693-10">
   <w.rf>
    <LM>w#w-d1t693-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t693-11">
   <w.rf>
    <LM>w#w-d1t693-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t693-15">
   <w.rf>
    <LM>w#w-d1t693-15</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t693-16">
   <w.rf>
    <LM>w#w-d1t693-16</LM>
   </w.rf>
   <form>nádherné</form>
   <lemma>nádherný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d-id74654-punct">
   <w.rf>
    <LM>w#w-d-id74654-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t693-18">
   <w.rf>
    <LM>w#w-d1t693-18</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m035-d1t693-20">
   <w.rf>
    <LM>w#w-d1t693-20</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m035-d1t695-1">
   <w.rf>
    <LM>w#w-d1t695-1</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m035-d1t693-19">
   <w.rf>
    <LM>w#w-d1t693-19</LM>
   </w.rf>
   <form>vesnička</form>
   <lemma>vesnička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1e678-x2-1056">
   <w.rf>
    <LM>w#w-d1e678-x2-1056</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1055">
  <m id="m035-d1t697-4">
   <w.rf>
    <LM>w#w-d1t697-4</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t697-6">
   <w.rf>
    <LM>w#w-d1t697-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t697-14">
   <w.rf>
    <LM>w#w-d1t697-14</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t697-15">
   <w.rf>
    <LM>w#w-d1t697-15</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t697-16">
   <w.rf>
    <LM>w#w-d1t697-16</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m035-d1t697-17">
   <w.rf>
    <LM>w#w-d1t697-17</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m035-d1t697-7">
   <w.rf>
    <LM>w#w-d1t697-7</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-1055-1057">
   <w.rf>
    <LM>w#w-1055-1057</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-1055-1058">
   <w.rf>
    <LM>w#w-1055-1058</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t697-12">
   <w.rf>
    <LM>w#w-d1t697-12</LM>
   </w.rf>
   <form>Půjdem</form>
   <lemma>jít</lemma>
   <tag>VB-P---1F-AAI-6</tag>
  </m>
  <m id="m035-d1t697-10">
   <w.rf>
    <LM>w#w-d1t697-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t697-11">
   <w.rf>
    <LM>w#w-d1t697-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t697-13">
   <w.rf>
    <LM>w#w-d1t697-13</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m035-1055-1059">
   <w.rf>
    <LM>w#w-1055-1059</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-1055-1061">
   <w.rf>
    <LM>w#w-1055-1061</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1062">
  <m id="m035-d1t697-22">
   <w.rf>
    <LM>w#w-d1t697-22</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t697-21">
   <w.rf>
    <LM>w#w-d1t697-21</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t697-20">
   <w.rf>
    <LM>w#w-d1t697-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t697-23">
   <w.rf>
    <LM>w#w-d1t697-23</LM>
   </w.rf>
   <form>zmodernizované</form>
   <lemma>zmodernizovaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d-id75052-punct">
   <w.rf>
    <LM>w#w-d-id75052-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t701-8">
   <w.rf>
    <LM>w#w-d1t701-8</LM>
   </w.rf>
   <form>termální</form>
   <lemma>termální</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1t701-7">
   <w.rf>
    <LM>w#w-d1t701-7</LM>
   </w.rf>
   <form>koupaliště</form>
   <lemma>koupaliště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d1t701-4">
   <w.rf>
    <LM>w#w-d1t701-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t701-1">
   <w.rf>
    <LM>w#w-d1t701-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t701-2">
   <w.rf>
    <LM>w#w-d1t701-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m035-d1t701-3">
   <w.rf>
    <LM>w#w-d1t701-3</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t701-5">
   <w.rf>
    <LM>w#w-d1t701-5</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-1062-1063">
   <w.rf>
    <LM>w#w-1062-1063</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1064">
  <m id="m035-d1t704-8">
   <w.rf>
    <LM>w#w-d1t704-8</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m035-d1t704-10">
   <w.rf>
    <LM>w#w-d1t704-10</LM>
   </w.rf>
   <form>stráni</form>
   <lemma>stráň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t704-6">
   <w.rf>
    <LM>w#w-d1t704-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t704-7">
   <w.rf>
    <LM>w#w-d1t704-7</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m035-d1t704-4">
   <w.rf>
    <LM>w#w-d1t704-4</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m035-d1t704-11">
   <w.rf>
    <LM>w#w-d1t704-11</LM>
   </w.rf>
   <form>obrovský</form>
   <lemma>obrovský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m035-d1t704-5">
   <w.rf>
    <LM>w#w-d1t704-5</LM>
   </w.rf>
   <form>hotel</form>
   <lemma>hotel</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-1064-1105">
   <w.rf>
    <LM>w#w-1064-1105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1106">
  <m id="m035-d1t708-9">
   <w.rf>
    <LM>w#w-d1t708-9</LM>
   </w.rf>
   <form>Zklamalo</form>
   <lemma>zklamat</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m035-d1t708-7">
   <w.rf>
    <LM>w#w-d1t708-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m035-d1t708-8">
   <w.rf>
    <LM>w#w-d1t708-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-1106-1114">
   <w.rf>
    <LM>w#w-1106-1114</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1115">
  <m id="m035-1115-459">
   <w.rf>
    <LM>w#w-1115-459</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t710-3">
   <w.rf>
    <LM>w#w-d1t710-3</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSNS1-S1------1</tag>
  </m>
  <m id="m035-d1t710-4">
   <w.rf>
    <LM>w#w-d1t710-4</LM>
   </w.rf>
   <form>heslo</form>
   <lemma>heslo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-1115-1117">
   <w.rf>
    <LM>w#w-1115-1117</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-1115-6">
   <w.rf>
    <LM>w#w-1115-6</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t710-6">
   <w.rf>
    <LM>w#w-d1t710-6</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t710-7">
   <w.rf>
    <LM>w#w-d1t710-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t710-8">
   <w.rf>
    <LM>w#w-d1t710-8</LM>
   </w.rf>
   <form>nevracet</form>
   <lemma>vracet</lemma>
   <tag>Vf--------N-I--</tag>
  </m>
  <m id="m035-d1t710-9">
   <w.rf>
    <LM>w#w-d1t710-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-id75620-punct">
   <w.rf>
    <LM>w#w-d-id75620-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t712-4">
   <w.rf>
    <LM>w#w-d1t712-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t712-5">
   <w.rf>
    <LM>w#w-d1t712-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t712-6">
   <w.rf>
    <LM>w#w-d1t712-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t712-7">
   <w.rf>
    <LM>w#w-d1t712-7</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1t712-9">
   <w.rf>
    <LM>w#w-d1t712-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t712-10">
   <w.rf>
    <LM>w#w-d1t712-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m035-d1t712-11">
   <w.rf>
    <LM>w#w-d1t712-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t712-12">
   <w.rf>
    <LM>w#w-d1t712-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t712-13">
   <w.rf>
    <LM>w#w-d1t712-13</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m035-d1t712-14">
   <w.rf>
    <LM>w#w-d1t712-14</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m035-1115-7">
   <w.rf>
    <LM>w#w-1115-7</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-1115-1118">
   <w.rf>
    <LM>w#w-1115-1118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-1119">
  <m id="m035-d1t714-1">
   <w.rf>
    <LM>w#w-d1t714-1</LM>
   </w.rf>
   <form>Zachovat</form>
   <lemma>zachovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1t714-2">
   <w.rf>
    <LM>w#w-d1t714-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t714-3">
   <w.rf>
    <LM>w#w-d1t714-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m035-d1t714-4">
   <w.rf>
    <LM>w#w-d1t714-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t714-5">
   <w.rf>
    <LM>w#w-d1t714-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t714-6">
   <w.rf>
    <LM>w#w-d1t714-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t714-7">
   <w.rf>
    <LM>w#w-d1t714-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t714-8">
   <w.rf>
    <LM>w#w-d1t714-8</LM>
   </w.rf>
   <form>nevracet</form>
   <lemma>vracet</lemma>
   <tag>Vf--------N-I--</tag>
  </m>
  <m id="m035-d-m-d1e690-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e690-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e718-x2">
  <m id="m035-d1t721-1">
   <w.rf>
    <LM>w#w-d1t721-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t721-2">
   <w.rf>
    <LM>w#w-d1t721-2</LM>
   </w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m035-d1e718-x2-1127">
   <w.rf>
    <LM>w#w-d1e718-x2-1127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t721-3">
   <w.rf>
    <LM>w#w-d1t721-3</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t721-4">
   <w.rf>
    <LM>w#w-d1t721-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t721-5">
   <w.rf>
    <LM>w#w-d1t721-5</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m035-d1t721-6">
   <w.rf>
    <LM>w#w-d1t721-6</LM>
   </w.rf>
   <form>nelíbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-d1e718-x2-1128">
   <w.rf>
    <LM>w#w-d1e718-x2-1128</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t721-7">
   <w.rf>
    <LM>w#w-d1t721-7</LM>
   </w.rf>
   <form>byste</form>
   <lemma>být</lemma>
   <tag>Vc----------Ie-</tag>
  </m>
  <m id="m035-d1t721-8">
   <w.rf>
    <LM>w#w-d1t721-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t721-9">
   <w.rf>
    <LM>w#w-d1t721-9</LM>
   </w.rf>
   <form>vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d-id76116-punct">
   <w.rf>
    <LM>w#w-d-id76116-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e724-x2">
  <m id="m035-d1t729-2">
   <w.rf>
    <LM>w#w-d1t729-2</LM>
   </w.rf>
   <form>Nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-d1t729-3">
   <w.rf>
    <LM>w#w-d1t729-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m035-d-id76236-punct">
   <w.rf>
    <LM>w#w-d-id76236-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t729-5">
   <w.rf>
    <LM>w#w-d1t729-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t729-6">
   <w.rf>
    <LM>w#w-d1t729-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t729-7">
   <w.rf>
    <LM>w#w-d1t729-7</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m035-d1t729-8">
   <w.rf>
    <LM>w#w-d1t729-8</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t729-11">
   <w.rf>
    <LM>w#w-d1t729-11</LM>
   </w.rf>
   <form>vyloženě</form>
   <lemma>vyloženě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t729-9">
   <w.rf>
    <LM>w#w-d1t729-9</LM>
   </w.rf>
   <form>nelíbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-d1e724-x2-1153">
   <w.rf>
    <LM>w#w-d1e724-x2-1153</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
