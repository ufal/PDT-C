<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_144.03.w.gz" />
  </references>
 </head>
 <s id="m144-d1e667-x2">
  <m id="m144-d1t670-1">
   <w.rf>
    <LM>w#w-d1t670-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t670-2">
   <w.rf>
    <LM>w#w-d1t670-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m144-d1t670-3">
   <w.rf>
    <LM>w#w-d1t670-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t670-4">
   <w.rf>
    <LM>w#w-d1t670-4</LM>
   </w.rf>
   <form>přestal</form>
   <lemma>přestat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t670-5">
   <w.rf>
    <LM>w#w-d1t670-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t670-6">
   <w.rf>
    <LM>w#w-d1t670-6</LM>
   </w.rf>
   <form>skauta</form>
   <lemma>skaut</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m144-d1t670-7">
   <w.rf>
    <LM>w#w-d1t670-7</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m144-d-id87299-punct">
   <w.rf>
    <LM>w#w-d-id87299-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e671-x2">
  <m id="m144-d1t676-1">
   <w.rf>
    <LM>w#w-d1t676-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m144-d1t676-2">
   <w.rf>
    <LM>w#w-d1t676-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t676-3">
   <w.rf>
    <LM>w#w-d1t676-3</LM>
   </w.rf>
   <form>přestal</form>
   <lemma>přestat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t676-4">
   <w.rf>
    <LM>w#w-d1t676-4</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m144-d1t676-5">
   <w.rf>
    <LM>w#w-d1t676-5</LM>
   </w.rf>
   <form>chozen</form>
   <lemma>chodit</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m144-d-id87448-punct">
   <w.rf>
    <LM>w#w-d-id87448-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t676-7">
   <w.rf>
    <LM>w#w-d1t676-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t676-8">
   <w.rf>
    <LM>w#w-d1t676-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t676-9">
   <w.rf>
    <LM>w#w-d1t676-9</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m144-d1t676-10">
   <w.rf>
    <LM>w#w-d1t676-10</LM>
   </w.rf>
   <form>1949</form>
   <lemma>1949</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m144-d1t676-13">
   <w.rf>
    <LM>w#w-d1t676-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t676-14">
   <w.rf>
    <LM>w#w-d1t676-14</LM>
   </w.rf>
   <form>skauting</form>
   <lemma>skauting</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m144-d1t676-15">
   <w.rf>
    <LM>w#w-d1t676-15</LM>
   </w.rf>
   <form>oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1e671-x2-555">
   <w.rf>
    <LM>w#w-d1e671-x2-555</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t676-17">
   <w.rf>
    <LM>w#w-d1t676-17</LM>
   </w.rf>
   <form>nuceně</form>
   <lemma>nuceně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t676-18">
   <w.rf>
    <LM>w#w-d1t676-18</LM>
   </w.rf>
   <form>rozpuštěn</form>
   <lemma>rozpustit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m144-d1e671-x2-553">
   <w.rf>
    <LM>w#w-d1e671-x2-553</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-554">
  <m id="m144-d1t678-7">
   <w.rf>
    <LM>w#w-d1t678-7</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t678-8">
   <w.rf>
    <LM>w#w-d1t678-8</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m144-d1t678-9">
   <w.rf>
    <LM>w#w-d1t678-9</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t678-10">
   <w.rf>
    <LM>w#w-d1t678-10</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t678-11">
   <w.rf>
    <LM>w#w-d1t678-11</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t678-12">
   <w.rf>
    <LM>w#w-d1t678-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t678-13">
   <w.rf>
    <LM>w#w-d1t678-13</LM>
   </w.rf>
   <form>předpokládám</form>
   <lemma>předpokládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d-id87846-punct">
   <w.rf>
    <LM>w#w-d-id87846-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t678-15">
   <w.rf>
    <LM>w#w-d1t678-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t678-16">
   <w.rf>
    <LM>w#w-d1t678-16</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m144-d1t678-17">
   <w.rf>
    <LM>w#w-d1t678-17</LM>
   </w.rf>
   <form>skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t678-18">
   <w.rf>
    <LM>w#w-d1t678-18</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t678-19">
   <w.rf>
    <LM>w#w-d1t678-19</LM>
   </w.rf>
   <form>rover</form>
   <lemma>rover</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-554-556">
   <w.rf>
    <LM>w#w-554-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-557">
  <m id="m144-d1t680-1">
   <w.rf>
    <LM>w#w-d1t680-1</LM>
   </w.rf>
   <form>Roveři</form>
   <lemma>rover</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m144-d1t680-3">
   <w.rf>
    <LM>w#w-d1t680-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t680-4">
   <w.rf>
    <LM>w#w-d1t680-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t682-1">
   <w.rf>
    <LM>w#w-d1t682-1</LM>
   </w.rf>
   <form>bývalí</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m144-d1t682-2">
   <w.rf>
    <LM>w#w-d1t682-2</LM>
   </w.rf>
   <form>skauti</form>
   <lemma>skaut</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m144-d-id88050-punct">
   <w.rf>
    <LM>w#w-d-id88050-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t682-4">
   <w.rf>
    <LM>w#w-d1t682-4</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m144-d1t682-5">
   <w.rf>
    <LM>w#w-d1t682-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t682-6">
   <w.rf>
    <LM>w#w-d1t682-6</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t682-7">
   <w.rf>
    <LM>w#w-d1t682-7</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t682-8">
   <w.rf>
    <LM>w#w-d1t682-8</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m144-d1t682-9">
   <w.rf>
    <LM>w#w-d1t682-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t682-10">
   <w.rf>
    <LM>w#w-d1t682-10</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-557-563">
   <w.rf>
    <LM>w#w-557-563</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t685-1">
   <w.rf>
    <LM>w#w-d1t685-1</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m144-d1t685-2">
   <w.rf>
    <LM>w#w-d1t685-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t685-3">
   <w.rf>
    <LM>w#w-d1t685-3</LM>
   </w.rf>
   <form>cítili</form>
   <lemma>cítit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t685-4">
   <w.rf>
    <LM>w#w-d1t685-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t685-5">
   <w.rf>
    <LM>w#w-d1t685-5</LM>
   </w.rf>
   <form>skauty</form>
   <lemma>skaut</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m144-557-565">
   <w.rf>
    <LM>w#w-557-565</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-566">
  <m id="m144-d1t687-1">
   <w.rf>
    <LM>w#w-d1t687-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t687-2">
   <w.rf>
    <LM>w#w-d1t687-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t687-3">
   <w.rf>
    <LM>w#w-d1t687-3</LM>
   </w.rf>
   <form>oddílu</form>
   <lemma>oddíl</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m144-d1t687-4">
   <w.rf>
    <LM>w#w-d1t687-4</LM>
   </w.rf>
   <form>takzvaných</form>
   <lemma>takzvaný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m144-d1t687-5">
   <w.rf>
    <LM>w#w-d1t687-5</LM>
   </w.rf>
   <form>roverů</form>
   <lemma>rover</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m144-566-567">
   <w.rf>
    <LM>w#w-566-567</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t687-6">
   <w.rf>
    <LM>w#w-d1t687-6</LM>
   </w.rf>
   <form>poutníků</form>
   <lemma>poutník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m144-d-id88363-punct">
   <w.rf>
    <LM>w#w-d-id88363-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t689-1">
   <w.rf>
    <LM>w#w-d1t689-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m144-d1t689-2">
   <w.rf>
    <LM>w#w-d1t689-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t689-3">
   <w.rf>
    <LM>w#w-d1t689-3</LM>
   </w.rf>
   <form>volným</form>
   <lemma>volný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m144-d1t689-4">
   <w.rf>
    <LM>w#w-d1t689-4</LM>
   </w.rf>
   <form>sdružením</form>
   <lemma>sdružení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m144-566-223">
   <w.rf>
    <LM>w#w-566-223</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-226">
  <m id="m144-d1t689-6">
   <w.rf>
    <LM>w#w-d1t689-6</LM>
   </w.rf>
   <form>Neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m144-d1t689-7">
   <w.rf>
    <LM>w#w-d1t689-7</LM>
   </w.rf>
   <form>běžné</form>
   <lemma>běžný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m144-d1t689-8">
   <w.rf>
    <LM>w#w-d1t689-8</LM>
   </w.rf>
   <form>schůzky</form>
   <lemma>schůzka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m144-566-582">
   <w.rf>
    <LM>w#w-566-582</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t691-1">
   <w.rf>
    <LM>w#w-d1t691-1</LM>
   </w.rf>
   <form>sešli</form>
   <lemma>sejít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m144-d1t691-2">
   <w.rf>
    <LM>w#w-d1t691-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t691-3">
   <w.rf>
    <LM>w#w-d1t691-3</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t691-4">
   <w.rf>
    <LM>w#w-d1t691-4</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m144-d1t691-5">
   <w.rf>
    <LM>w#w-d1t691-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t691-6">
   <w.rf>
    <LM>w#w-d1t691-6</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-566-580">
   <w.rf>
    <LM>w#w-566-580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-581">
  <m id="m144-d1t693-1">
   <w.rf>
    <LM>w#w-d1t693-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t693-2">
   <w.rf>
    <LM>w#w-d1t693-2</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t693-5">
   <w.rf>
    <LM>w#w-d1t693-5</LM>
   </w.rf>
   <form>vypomáhat</form>
   <lemma>vypomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m144-d1t693-3">
   <w.rf>
    <LM>w#w-d1t693-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t693-4">
   <w.rf>
    <LM>w#w-d1t693-4</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-566-579">
   <w.rf>
    <LM>w#w-566-579</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e671-x3">
  <m id="m144-d1t693-8">
   <w.rf>
    <LM>w#w-d1t693-8</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t693-9">
   <w.rf>
    <LM>w#w-d1t693-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t693-10">
   <w.rf>
    <LM>w#w-d1t693-10</LM>
   </w.rf>
   <form>takoví</form>
   <lemma>takový</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m144-d1t693-11">
   <w.rf>
    <LM>w#w-d1t693-11</LM>
   </w.rf>
   <form>čestní</form>
   <lemma>čestný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m144-d1t693-12">
   <w.rf>
    <LM>w#w-d1t693-12</LM>
   </w.rf>
   <form>členové</form>
   <lemma>člen-2</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m144-d1t695-1">
   <w.rf>
    <LM>w#w-d1t695-1</LM>
   </w.rf>
   <form>skautingu</form>
   <lemma>skauting</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m144-d1e671-x3-584">
   <w.rf>
    <LM>w#w-d1e671-x3-584</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-585">
  <m id="m144-d1t698-1">
   <w.rf>
    <LM>w#w-d1t698-1</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t698-2">
   <w.rf>
    <LM>w#w-d1t698-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m144-d1t698-3">
   <w.rf>
    <LM>w#w-d1t698-3</LM>
   </w.rf>
   <form>skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t698-4">
   <w.rf>
    <LM>w#w-d1t698-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t698-5">
   <w.rf>
    <LM>w#w-d1t698-5</LM>
   </w.rf>
   <form>rover</form>
   <lemma>rover</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-585-586">
   <w.rf>
    <LM>w#w-585-586</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-587">
  <m id="m144-d1t700-1">
   <w.rf>
    <LM>w#w-d1t700-1</LM>
   </w.rf>
   <form>Skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t700-2">
   <w.rf>
    <LM>w#w-d1t700-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t700-3">
   <w.rf>
    <LM>w#w-d1t700-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t700-4">
   <w.rf>
    <LM>w#w-d1t700-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t700-5">
   <w.rf>
    <LM>w#w-d1t700-5</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m144-d1t700-6">
   <w.rf>
    <LM>w#w-d1t700-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m144-d1t700-8">
   <w.rf>
    <LM>w#w-d1t700-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t700-9">
   <w.rf>
    <LM>w#w-d1t700-9</LM>
   </w.rf>
   <form>skaut</form>
   <lemma>skaut</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d-m-d1e671-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e671-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e701-x2">
  <m id="m144-d1t704-2">
   <w.rf>
    <LM>w#w-d1t704-2</LM>
   </w.rf>
   <form>Cítíte</form>
   <lemma>cítit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m144-d1t704-3">
   <w.rf>
    <LM>w#w-d1t704-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t704-4">
   <w.rf>
    <LM>w#w-d1t704-4</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t704-5">
   <w.rf>
    <LM>w#w-d1t704-5</LM>
   </w.rf>
   <form>skautem</form>
   <lemma>skaut</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m144-d-id89268-punct">
   <w.rf>
    <LM>w#w-d-id89268-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e705-x2">
  <m id="m144-d1t708-1">
   <w.rf>
    <LM>w#w-d1t708-1</LM>
   </w.rf>
   <form>Skautem</form>
   <lemma>skaut</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m144-d1t708-2">
   <w.rf>
    <LM>w#w-d1t708-2</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m144-d-id89361-punct">
   <w.rf>
    <LM>w#w-d-id89361-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t708-4">
   <w.rf>
    <LM>w#w-d1t708-4</LM>
   </w.rf>
   <form>skautem</form>
   <lemma>skaut</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m144-d1t708-5">
   <w.rf>
    <LM>w#w-d1t708-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t708-6">
   <w.rf>
    <LM>w#w-d1t708-6</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m144-d1t708-7">
   <w.rf>
    <LM>w#w-d1t708-7</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d1e705-x2-591">
   <w.rf>
    <LM>w#w-d1e705-x2-591</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-592">
  <m id="m144-d1t710-1">
   <w.rf>
    <LM>w#w-d1t710-1</LM>
   </w.rf>
   <form>Stačí</form>
   <lemma>stačit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-d-id89463-punct">
   <w.rf>
    <LM>w#w-d-id89463-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e711-x2">
  <m id="m144-d1t714-1">
   <w.rf>
    <LM>w#w-d1t714-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m144-d1e711-x2-594">
   <w.rf>
    <LM>w#w-d1e711-x2-594</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-595">
  <m id="m144-d1t716-1">
   <w.rf>
    <LM>w#w-d1t716-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m144-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m144-d1t716-3">
   <w.rf>
    <LM>w#w-d1t716-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d-id89601-punct">
   <w.rf>
    <LM>w#w-d-id89601-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e717-x2">
  <m id="m144-d1t722-2">
   <w.rf>
    <LM>w#w-d1t722-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t722-3">
   <w.rf>
    <LM>w#w-d1t722-3</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m144-d1t722-4">
   <w.rf>
    <LM>w#w-d1t722-4</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSMS4-S1-------</tag>
  </m>
  <m id="m144-d1t722-5">
   <w.rf>
    <LM>w#w-d1t722-5</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m144-d1e717-x2-606">
   <w.rf>
    <LM>w#w-d1e717-x2-606</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-607">
  <m id="m144-d1t724-2">
   <w.rf>
    <LM>w#w-d1t724-2</LM>
   </w.rf>
   <form>Odbočuju</form>
   <lemma>odbočovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t724-3">
   <w.rf>
    <LM>w#w-d1t724-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m144-d1t724-4">
   <w.rf>
    <LM>w#w-d1t724-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m144-d-id89827-punct">
   <w.rf>
    <LM>w#w-d-id89827-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t724-6">
   <w.rf>
    <LM>w#w-d1t724-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t724-7">
   <w.rf>
    <LM>w#w-d1t724-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t724-9">
   <w.rf>
    <LM>w#w-d1t724-9</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t724-8">
   <w.rf>
    <LM>w#w-d1t724-8</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d-id89914-punct">
   <w.rf>
    <LM>w#w-d-id89914-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t724-12">
   <w.rf>
    <LM>w#w-d1t724-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t724-14">
   <w.rf>
    <LM>w#w-d1t724-14</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m144-d1t724-13">
   <w.rf>
    <LM>w#w-d1t724-13</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t724-15">
   <w.rf>
    <LM>w#w-d1t724-15</LM>
   </w.rf>
   <form>pletla</form>
   <lemma>plést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t724-16">
   <w.rf>
    <LM>w#w-d1t724-16</LM>
   </w.rf>
   <form>kočárky</form>
   <lemma>kočárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m144-607-240">
   <w.rf>
    <LM>w#w-607-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-242">
  <m id="m144-d1t724-19">
   <w.rf>
    <LM>w#w-d1t724-19</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t724-20">
   <w.rf>
    <LM>w#w-d1t724-20</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m144-d1t724-21">
   <w.rf>
    <LM>w#w-d1t724-21</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m144-d1t724-22">
   <w.rf>
    <LM>w#w-d1t724-22</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m144-d-id90086-punct">
   <w.rf>
    <LM>w#w-d-id90086-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t724-24">
   <w.rf>
    <LM>w#w-d1t724-24</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m144-d1t724-25">
   <w.rf>
    <LM>w#w-d1t724-25</LM>
   </w.rf>
   <form>kočárky</form>
   <lemma>kočárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m144-d1t724-26">
   <w.rf>
    <LM>w#w-d1t724-26</LM>
   </w.rf>
   <form>pletla</form>
   <lemma>plést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-607-608">
   <w.rf>
    <LM>w#w-607-608</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-609">
  <m id="m144-d1t726-3">
   <w.rf>
    <LM>w#w-d1t726-3</LM>
   </w.rf>
   <form>Takovýchto</form>
   <lemma>takovýto</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m144-d1t726-5">
   <w.rf>
    <LM>w#w-d1t726-5</LM>
   </w.rf>
   <form>kočárků</form>
   <lemma>kočárek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m144-d-id90235-punct">
   <w.rf>
    <LM>w#w-d-id90235-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t726-7">
   <w.rf>
    <LM>w#w-d1t726-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m144-d1t726-8">
   <w.rf>
    <LM>w#w-d1t726-8</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m144-609-610">
   <w.rf>
    <LM>w#w-609-610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t726-10">
   <w.rf>
    <LM>w#w-d1t726-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t728-2">
   <w.rf>
    <LM>w#w-d1t728-2</LM>
   </w.rf>
   <form>odvezl</form>
   <lemma>odvézt</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t728-3">
   <w.rf>
    <LM>w#w-d1t728-3</LM>
   </w.rf>
   <form>stovky</form>
   <lemma>stovka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m144-d1t728-1">
   <w.rf>
    <LM>w#w-d1t728-1</LM>
   </w.rf>
   <form>upletených</form>
   <lemma>upletený_^(*5ést)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m144-d1t728-4">
   <w.rf>
    <LM>w#w-d1t728-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t728-5">
   <w.rf>
    <LM>w#w-d1t728-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m144-d1t728-6">
   <w.rf>
    <LM>w#w-d1t728-6</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m144-d1t728-7">
   <w.rf>
    <LM>w#w-d1t728-7</LM>
   </w.rf>
   <form>vzorem</form>
   <lemma>vzor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m144-609-611">
   <w.rf>
    <LM>w#w-609-611</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-612">
  <m id="m144-d1t731-1">
   <w.rf>
    <LM>w#w-d1t731-1</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t731-2">
   <w.rf>
    <LM>w#w-d1t731-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t731-3">
   <w.rf>
    <LM>w#w-d1t731-3</LM>
   </w.rf>
   <form>pletly</form>
   <lemma>plést</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m144-d1t731-5">
   <w.rf>
    <LM>w#w-d1t731-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t731-7">
   <w.rf>
    <LM>w#w-d1t731-7</LM>
   </w.rf>
   <form>Mělnicku</form>
   <lemma>Mělnicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m144-d1t731-4">
   <w.rf>
    <LM>w#w-d1t731-4</LM>
   </w.rf>
   <form>kočárky</form>
   <lemma>kočárek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m144-612-613">
   <w.rf>
    <LM>w#w-612-613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-614">
  <m id="m144-d1t733-3">
   <w.rf>
    <LM>w#w-d1t733-3</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m144-d1t733-4">
   <w.rf>
    <LM>w#w-d1t733-4</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t733-6">
   <w.rf>
    <LM>w#w-d1t733-6</LM>
   </w.rf>
   <form>Ivouš</form>
   <lemma>Ivouš_;Y_,e</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t733-8">
   <w.rf>
    <LM>w#w-d1t733-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-d1t733-9">
   <w.rf>
    <LM>w#w-d1t733-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t733-10">
   <w.rf>
    <LM>w#w-d1t733-10</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t733-11">
   <w.rf>
    <LM>w#w-d1t733-11</LM>
   </w.rf>
   <form>lebedí</form>
   <lemma>lebedit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-614-615">
   <w.rf>
    <LM>w#w-614-615</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e741-x2">
  <m id="m144-d1t744-1">
   <w.rf>
    <LM>w#w-d1t744-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t744-2">
   <w.rf>
    <LM>w#w-d1t744-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t744-3">
   <w.rf>
    <LM>w#w-d1t744-3</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t744-4">
   <w.rf>
    <LM>w#w-d1t744-4</LM>
   </w.rf>
   <form>pletla</form>
   <lemma>plést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t744-5">
   <w.rf>
    <LM>w#w-d1t744-5</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m144-d1t744-6">
   <w.rf>
    <LM>w#w-d1t744-6</LM>
   </w.rf>
   <form>kočárek</form>
   <lemma>kočárek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d-id90937-punct">
   <w.rf>
    <LM>w#w-d-id90937-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e745-x2">
  <m id="m144-d1t748-2">
   <w.rf>
    <LM>w#w-d1t748-2</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m144-d-id91030-punct">
   <w.rf>
    <LM>w#w-d-id91030-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t748-4">
   <w.rf>
    <LM>w#w-d1t748-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t748-5">
   <w.rf>
    <LM>w#w-d1t748-5</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m144-d1t748-6">
   <w.rf>
    <LM>w#w-d1t748-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m144-d1t748-7">
   <w.rf>
    <LM>w#w-d1t748-7</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t748-8">
   <w.rf>
    <LM>w#w-d1t748-8</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m144-d-id91116-punct">
   <w.rf>
    <LM>w#w-d-id91116-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e745-x3">
  <m id="m144-d1t752-1">
   <w.rf>
    <LM>w#w-d1t752-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m144-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m144-d1t752-5">
   <w.rf>
    <LM>w#w-d1t752-5</LM>
   </w.rf>
   <form>špatné</form>
   <lemma>špatný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m144-d1e745-x3-629">
   <w.rf>
    <LM>w#w-d1e745-x3-629</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-630">
  <m id="m144-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t752-9">
   <w.rf>
    <LM>w#w-d1t752-9</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m144-d1t752-10">
   <w.rf>
    <LM>w#w-d1t752-10</LM>
   </w.rf>
   <form>dojem</form>
   <lemma>dojem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d-id91297-punct">
   <w.rf>
    <LM>w#w-d-id91297-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t752-12">
   <w.rf>
    <LM>w#w-d1t752-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t752-13">
   <w.rf>
    <LM>w#w-d1t752-13</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m144-d1t752-14">
   <w.rf>
    <LM>w#w-d1t752-14</LM>
   </w.rf>
   <form>pletla</form>
   <lemma>plést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t752-15">
   <w.rf>
    <LM>w#w-d1t752-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t752-16">
   <w.rf>
    <LM>w#w-d1t752-16</LM>
   </w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-2</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m144-630-632">
   <w.rf>
    <LM>w#w-630-632</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-633">
  <m id="m144-d1t754-1">
   <w.rf>
    <LM>w#w-d1t754-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m144-d1t754-2">
   <w.rf>
    <LM>w#w-d1t754-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t754-3">
   <w.rf>
    <LM>w#w-d1t754-3</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m144-d1t754-4">
   <w.rf>
    <LM>w#w-d1t754-4</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m144-d1t754-7">
   <w.rf>
    <LM>w#w-d1t754-7</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m144-d1t754-8">
   <w.rf>
    <LM>w#w-d1t754-8</LM>
   </w.rf>
   <form>pletla</form>
   <lemma>plést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-633-634">
   <w.rf>
    <LM>w#w-633-634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-635">
  <m id="m144-d1t756-1">
   <w.rf>
    <LM>w#w-d1t756-1</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m144-d1t756-2">
   <w.rf>
    <LM>w#w-d1t756-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t756-4">
   <w.rf>
    <LM>w#w-d1t756-4</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m144-d1t756-5">
   <w.rf>
    <LM>w#w-d1t756-5</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m144-d1t756-3">
   <w.rf>
    <LM>w#w-d1t756-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t756-6">
   <w.rf>
    <LM>w#w-d1t756-6</LM>
   </w.rf>
   <form>předpřipravenou</form>
   <lemma>předpřipravený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m144-635-264">
   <w.rf>
    <LM>w#w-635-264</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-267">
  <m id="m144-d1t756-9">
   <w.rf>
    <LM>w#w-d1t756-9</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m144-d1t756-10">
   <w.rf>
    <LM>w#w-d1t756-10</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>útky</form>
   <lemma>útek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m144-635-636">
   <w.rf>
    <LM>w#w-635-636</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t756-12">
   <w.rf>
    <LM>w#w-d1t756-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t756-13">
   <w.rf>
    <LM>w#w-d1t756-13</LM>
   </w.rf>
   <form>jest</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI-2</tag>
  </m>
  <m id="m144-d1t756-14">
   <w.rf>
    <LM>w#w-d1t756-14</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m144-d1t756-15">
   <w.rf>
    <LM>w#w-d1t756-15</LM>
   </w.rf>
   <form>svislé</form>
   <lemma>svislý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m144-d1t756-16">
   <w.rf>
    <LM>w#w-d1t756-16</LM>
   </w.rf>
   <form>proutky</form>
   <lemma>proutek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m144-d-id91766-punct">
   <w.rf>
    <LM>w#w-d-id91766-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t756-18">
   <w.rf>
    <LM>w#w-d1t756-18</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m144-d1t756-19">
   <w.rf>
    <LM>w#w-d1t756-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t756-20">
   <w.rf>
    <LM>w#w-d1t756-20</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m144-635-637">
   <w.rf>
    <LM>w#w-635-637</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d-id91821-punct">
   <w.rf>
    <LM>w#w-d-id91821-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t756-22">
   <w.rf>
    <LM>w#w-d1t756-22</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m144-d1t756-23">
   <w.rf>
    <LM>w#w-d1t756-23</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t756-24">
   <w.rf>
    <LM>w#w-d1t756-24</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m144-d1t756-25">
   <w.rf>
    <LM>w#w-d1t756-25</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t756-27">
   <w.rf>
    <LM>w#w-d1t756-27</LM>
   </w.rf>
   <form>nabil</form>
   <lemma>nabít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-635-638">
   <w.rf>
    <LM>w#w-635-638</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-639">
  <m id="m144-d1t759-1">
   <w.rf>
    <LM>w#w-d1t759-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t759-2">
   <w.rf>
    <LM>w#w-d1t759-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t759-3">
   <w.rf>
    <LM>w#w-d1t759-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m144-d1t759-4">
   <w.rf>
    <LM>w#w-d1t759-4</LM>
   </w.rf>
   <form>dělba</form>
   <lemma>dělba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t759-5">
   <w.rf>
    <LM>w#w-d1t759-5</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m144-639-640">
   <w.rf>
    <LM>w#w-639-640</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-641">
  <m id="m144-d1t761-1">
   <w.rf>
    <LM>w#w-d1t761-1</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t761-2">
   <w.rf>
    <LM>w#w-d1t761-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t761-3">
   <w.rf>
    <LM>w#w-d1t761-3</LM>
   </w.rf>
   <form>šikovný</form>
   <lemma>šikovný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m144-d1t761-4">
   <w.rf>
    <LM>w#w-d1t761-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t761-8">
   <w.rf>
    <LM>w#w-d1t761-8</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m144-d1t761-6">
   <w.rf>
    <LM>w#w-d1t761-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t761-7">
   <w.rf>
    <LM>w#w-d1t761-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t761-9">
   <w.rf>
    <LM>w#w-d1t761-9</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t761-10">
   <w.rf>
    <LM>w#w-d1t761-10</LM>
   </w.rf>
   <form>umět</form>
   <lemma>umět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m144-641-652">
   <w.rf>
    <LM>w#w-641-652</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e745-x4">
  <m id="m144-d1t761-14">
   <w.rf>
    <LM>w#w-d1t761-14</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t761-13">
   <w.rf>
    <LM>w#w-d1t761-13</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m144-d-id92242-punct">
   <w.rf>
    <LM>w#w-d-id92242-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t761-16">
   <w.rf>
    <LM>w#w-d1t761-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t761-18">
   <w.rf>
    <LM>w#w-d1t761-18</LM>
   </w.rf>
   <form>natloukání</form>
   <lemma>natloukání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m144-d1t761-19">
   <w.rf>
    <LM>w#w-d1t761-19</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>útků</form>
   <lemma>útek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m144-d1t761-20">
   <w.rf>
    <LM>w#w-d1t761-20</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t763-1">
   <w.rf>
    <LM>w#w-d1t763-1</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m144-d1t763-3">
   <w.rf>
    <LM>w#w-d1t763-3</LM>
   </w.rf>
   <form>řemeslnická</form>
   <lemma>řemeslnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m144-d1t763-4">
   <w.rf>
    <LM>w#w-d1t763-4</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1e745-x4-653">
   <w.rf>
    <LM>w#w-d1e745-x4-653</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-654">
  <m id="m144-d1t765-2">
   <w.rf>
    <LM>w#w-d1t765-2</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t765-3">
   <w.rf>
    <LM>w#w-d1t765-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m144-d1t765-4">
   <w.rf>
    <LM>w#w-d1t765-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m144-d1t765-5">
   <w.rf>
    <LM>w#w-d1t765-5</LM>
   </w.rf>
   <form>natloukl</form>
   <lemma>natlouci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-654-655">
   <w.rf>
    <LM>w#w-654-655</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t767-1">
   <w.rf>
    <LM>w#w-d1t767-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t767-2">
   <w.rf>
    <LM>w#w-d1t767-2</LM>
   </w.rf>
   <form>postavil</form>
   <lemma>postavit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t767-3">
   <w.rf>
    <LM>w#w-d1t767-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m144-d1t767-5">
   <w.rf>
    <LM>w#w-d1t767-5</LM>
   </w.rf>
   <form>kostru</form>
   <lemma>kostra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m144-654-272">
   <w.rf>
    <LM>w#w-654-272</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-273">
  <m id="m144-d1t767-9">
   <w.rf>
    <LM>w#w-d1t767-9</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t767-8">
   <w.rf>
    <LM>w#w-d1t767-8</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m144-d1t767-10">
   <w.rf>
    <LM>w#w-d1t767-10</LM>
   </w.rf>
   <form>vyplétala</form>
   <lemma>vyplétat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t769-1">
   <w.rf>
    <LM>w#w-d1t769-1</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t769-2">
   <w.rf>
    <LM>w#w-d1t769-2</LM>
   </w.rf>
   <form>pedigem</form>
   <lemma>pedig_^(přírodní_materiál)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m144-d1t769-4">
   <w.rf>
    <LM>w#w-d1t769-4</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t769-7">
   <w.rf>
    <LM>w#w-d1t769-7</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m144-d1t769-5">
   <w.rf>
    <LM>w#w-d1t769-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t769-6">
   <w.rf>
    <LM>w#w-d1t769-6</LM>
   </w.rf>
   <form>vyplétala</form>
   <lemma>vyplétat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t769-8">
   <w.rf>
    <LM>w#w-d1t769-8</LM>
   </w.rf>
   <form>vlákny</form>
   <lemma>vlákno</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m144-d1t769-9">
   <w.rf>
    <LM>w#w-d1t769-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t769-10">
   <w.rf>
    <LM>w#w-d1t769-10</LM>
   </w.rf>
   <form>umělých</form>
   <lemma>umělý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m144-d1t769-11">
   <w.rf>
    <LM>w#w-d1t769-11</LM>
   </w.rf>
   <form>hmot</form>
   <lemma>hmota</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m144-d-m-d1e745-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e745-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e776-x2">
  <m id="m144-d1t779-1">
   <w.rf>
    <LM>w#w-d1t779-1</LM>
   </w.rf>
   <form>Pamatujete</form>
   <lemma>pamatovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m144-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-d1t779-3">
   <w.rf>
    <LM>w#w-d1t779-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t779-4">
   <w.rf>
    <LM>w#w-d1t779-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m144-d1t779-5">
   <w.rf>
    <LM>w#w-d1t779-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m144-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m144-d1t779-7">
   <w.rf>
    <LM>w#w-d1t779-7</LM>
   </w.rf>
   <form>útlého</form>
   <lemma>útlý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m144-d1t779-8">
   <w.rf>
    <LM>w#w-d1t779-8</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-d-id93065-punct">
   <w.rf>
    <LM>w#w-d-id93065-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e780-x2">
  <m id="m144-d1t783-1">
   <w.rf>
    <LM>w#w-d1t783-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m144-d1e780-x2-667">
   <w.rf>
    <LM>w#w-d1e780-x2-667</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-668">
  <m id="m144-d1t785-1">
   <w.rf>
    <LM>w#w-d1t785-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-d1t785-2">
   <w.rf>
    <LM>w#w-d1t785-2</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m144-d-id93188-punct">
   <w.rf>
    <LM>w#w-d-id93188-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t787-1">
   <w.rf>
    <LM>w#w-d1t787-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m144-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t787-6">
   <w.rf>
    <LM>w#w-d1t787-6</LM>
   </w.rf>
   <form>Slovensku</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m144-d-id93300-punct">
   <w.rf>
    <LM>w#w-d-id93300-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t787-9">
   <w.rf>
    <LM>w#w-d1t787-9</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t787-11">
   <w.rf>
    <LM>w#w-d1t787-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t787-10">
   <w.rf>
    <LM>w#w-d1t787-10</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1t787-12">
   <w.rf>
    <LM>w#w-d1t787-12</LM>
   </w.rf>
   <form>zaměstnaný</form>
   <lemma>zaměstnaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m144-d1t787-13">
   <w.rf>
    <LM>w#w-d1t787-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t787-14">
   <w.rf>
    <LM>w#w-d1t787-14</LM>
   </w.rf>
   <form>cukrovaru</form>
   <lemma>cukrovar</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m144-668-670">
   <w.rf>
    <LM>w#w-668-670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-671">
  <m id="m144-d1t789-3">
   <w.rf>
    <LM>w#w-d1t789-3</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m144-d1t789-4">
   <w.rf>
    <LM>w#w-d1t789-4</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m144-d1t789-5">
   <w.rf>
    <LM>w#w-d1t789-5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m144-d1t789-6">
   <w.rf>
    <LM>w#w-d1t789-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t789-7">
   <w.rf>
    <LM>w#w-d1t789-7</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m144-d1t789-8">
   <w.rf>
    <LM>w#w-d1t789-8</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m144-d1t794-1">
   <w.rf>
    <LM>w#w-d1t794-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t794-4">
   <w.rf>
    <LM>w#w-d1t794-4</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-671-672">
   <w.rf>
    <LM>w#w-671-672</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t794-5">
   <w.rf>
    <LM>w#w-d1t794-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t794-6">
   <w.rf>
    <LM>w#w-d1t794-6</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t794-8">
   <w.rf>
    <LM>w#w-d1t794-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m144-d1t794-9">
   <w.rf>
    <LM>w#w-d1t794-9</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m144-d1t794-7">
   <w.rf>
    <LM>w#w-d1t794-7</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t794-10">
   <w.rf>
    <LM>w#w-d1t794-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t794-11">
   <w.rf>
    <LM>w#w-d1t794-11</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-671-673">
   <w.rf>
    <LM>w#w-671-673</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t794-12">
   <w.rf>
    <LM>w#w-d1t794-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t794-14">
   <w.rf>
    <LM>w#w-d1t794-14</LM>
   </w.rf>
   <form>Nitry</form>
   <lemma>Nitra_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m144-671-680">
   <w.rf>
    <LM>w#w-671-680</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-681">
  <m id="m144-d1t796-1">
   <w.rf>
    <LM>w#w-d1t796-1</LM>
   </w.rf>
   <form>Postavila</form>
   <lemma>postavit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m144-d1t796-2">
   <w.rf>
    <LM>w#w-d1t796-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m144-d1t796-3">
   <w.rf>
    <LM>w#w-d1t796-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t796-5">
   <w.rf>
    <LM>w#w-d1t796-5</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t796-6">
   <w.rf>
    <LM>w#w-d1t796-6</LM>
   </w.rf>
   <form>obchod</form>
   <lemma>obchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d1t796-7">
   <w.rf>
    <LM>w#w-d1t796-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t796-8">
   <w.rf>
    <LM>w#w-d1t796-8</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m144-671-675">
   <w.rf>
    <LM>w#w-671-675</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-671-676">
   <w.rf>
    <LM>w#w-671-676</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t796-10">
   <w.rf>
    <LM>w#w-d1t796-10</LM>
   </w.rf>
   <form>Počkej</form>
   <lemma>počkat</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m144-671-677">
   <w.rf>
    <LM>w#w-671-677</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t796-11">
   <w.rf>
    <LM>w#w-d1t796-11</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m144-681-682">
   <w.rf>
    <LM>w#w-681-682</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-671-678">
   <w.rf>
    <LM>w#w-671-678</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t796-12">
   <w.rf>
    <LM>w#w-d1t796-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t796-14">
   <w.rf>
    <LM>w#w-d1t796-14</LM>
   </w.rf>
   <form>vešla</form>
   <lemma>vejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m144-d1t796-15">
   <w.rf>
    <LM>w#w-d1t796-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t796-16">
   <w.rf>
    <LM>w#w-d1t796-16</LM>
   </w.rf>
   <form>obchodu</form>
   <lemma>obchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m144-681-695">
   <w.rf>
    <LM>w#w-681-695</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e780-x3">
  <m id="m144-d1t798-3">
   <w.rf>
    <LM>w#w-d1t798-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t798-2">
   <w.rf>
    <LM>w#w-d1t798-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t800-4">
   <w.rf>
    <LM>w#w-d1t800-4</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m144-d1t800-5">
   <w.rf>
    <LM>w#w-d1t800-5</LM>
   </w.rf>
   <form>hošík</form>
   <lemma>hošík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m144-d1e780-x3-696">
   <w.rf>
    <LM>w#w-d1e780-x3-696</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t804-1">
   <w.rf>
    <LM>w#w-d1t804-1</LM>
   </w.rf>
   <form>nudil</form>
   <lemma>nudit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t804-2">
   <w.rf>
    <LM>w#w-d1t804-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t804-3">
   <w.rf>
    <LM>w#w-d1t804-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d-id94291-punct">
   <w.rf>
    <LM>w#w-d-id94291-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t804-5">
   <w.rf>
    <LM>w#w-d1t804-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t804-6">
   <w.rf>
    <LM>w#w-d1t804-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t804-7">
   <w.rf>
    <LM>w#w-d1t804-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m144-d1t804-8">
   <w.rf>
    <LM>w#w-d1t804-8</LM>
   </w.rf>
   <form>sebral</form>
   <lemma>sebrat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t804-9">
   <w.rf>
    <LM>w#w-d1t804-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t804-10">
   <w.rf>
    <LM>w#w-d1t804-10</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t804-11">
   <w.rf>
    <LM>w#w-d1t804-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t804-12">
   <w.rf>
    <LM>w#w-d1t804-12</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t804-13">
   <w.rf>
    <LM>w#w-d1t804-13</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1e780-x3-697">
   <w.rf>
    <LM>w#w-d1e780-x3-697</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-698">
  <m id="m144-d1t807-2">
   <w.rf>
    <LM>w#w-d1t807-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t807-3">
   <w.rf>
    <LM>w#w-d1t807-3</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-d1t807-4">
   <w.rf>
    <LM>w#w-d1t807-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m144-d1t807-6">
   <w.rf>
    <LM>w#w-d1t807-6</LM>
   </w.rf>
   <form>cukrovaru</form>
   <lemma>cukrovar</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m144-d1t807-7">
   <w.rf>
    <LM>w#w-d1t807-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t807-8">
   <w.rf>
    <LM>w#w-d1t807-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m144-d1t807-1">
   <w.rf>
    <LM>w#w-d1t807-1</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t807-9">
   <w.rf>
    <LM>w#w-d1t807-9</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t807-10">
   <w.rf>
    <LM>w#w-d1t807-10</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-698-705">
   <w.rf>
    <LM>w#w-698-705</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-706">
  <m id="m144-d1t809-4">
   <w.rf>
    <LM>w#w-d1t809-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t809-2">
   <w.rf>
    <LM>w#w-d1t809-2</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m144-d1t809-3">
   <w.rf>
    <LM>w#w-d1t809-3</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t809-5">
   <w.rf>
    <LM>w#w-d1t809-5</LM>
   </w.rf>
   <form>vyšla</form>
   <lemma>vyjít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m144-d1t809-6">
   <w.rf>
    <LM>w#w-d1t809-6</LM>
   </w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d-id94719-punct">
   <w.rf>
    <LM>w#w-d-id94719-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t809-8">
   <w.rf>
    <LM>w#w-d1t809-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t809-9">
   <w.rf>
    <LM>w#w-d1t809-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m144-d1t809-10">
   <w.rf>
    <LM>w#w-d1t809-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t809-11">
   <w.rf>
    <LM>w#w-d1t809-11</LM>
   </w.rf>
   <form>nenašla</form>
   <lemma>najít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m144-706-707">
   <w.rf>
    <LM>w#w-706-707</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-708">
  <m id="m144-d1t811-1">
   <w.rf>
    <LM>w#w-d1t811-1</LM>
   </w.rf>
   <form>Ztratila</form>
   <lemma>ztratit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m144-d1t811-2">
   <w.rf>
    <LM>w#w-d1t811-2</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t811-3">
   <w.rf>
    <LM>w#w-d1t811-3</LM>
   </w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m144-d1t811-4">
   <w.rf>
    <LM>w#w-d1t811-4</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m144-d-id94867-punct">
   <w.rf>
    <LM>w#w-d-id94867-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t811-6">
   <w.rf>
    <LM>w#w-d1t811-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t811-7">
   <w.rf>
    <LM>w#w-d1t811-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m144-d1t811-9">
   <w.rf>
    <LM>w#w-d1t811-9</LM>
   </w.rf>
   <form>hledala</form>
   <lemma>hledat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t811-14">
   <w.rf>
    <LM>w#w-d1t811-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m144-d1t811-15">
   <w.rf>
    <LM>w#w-d1t811-15</LM>
   </w.rf>
   <form>blízkém</form>
   <lemma>blízký</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m144-d1t811-16">
   <w.rf>
    <LM>w#w-d1t811-16</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m144-708-709">
   <w.rf>
    <LM>w#w-708-709</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-710">
  <m id="m144-d1t813-1">
   <w.rf>
    <LM>w#w-d1t813-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t813-2">
   <w.rf>
    <LM>w#w-d1t813-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m144-d1t813-3">
   <w.rf>
    <LM>w#w-d1t813-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t813-4">
   <w.rf>
    <LM>w#w-d1t813-4</LM>
   </w.rf>
   <form>napadlo</form>
   <lemma>napadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m144-d1t813-5">
   <w.rf>
    <LM>w#w-d1t813-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t813-7">
   <w.rf>
    <LM>w#w-d1t813-7</LM>
   </w.rf>
   <form>běžela</form>
   <lemma>běžet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t813-8">
   <w.rf>
    <LM>w#w-d1t813-8</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-710-711">
   <w.rf>
    <LM>w#w-710-711</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-712">
  <m id="m144-d1t815-2">
   <w.rf>
    <LM>w#w-d1t815-2</LM>
   </w.rf>
   <form>Doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t815-3">
   <w.rf>
    <LM>w#w-d1t815-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t815-4">
   <w.rf>
    <LM>w#w-d1t815-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t815-5">
   <w.rf>
    <LM>w#w-d1t815-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-d1t815-7">
   <w.rf>
    <LM>w#w-d1t815-7</LM>
   </w.rf>
   <form>hrál</form>
   <lemma>hrát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m144-d1t815-8">
   <w.rf>
    <LM>w#w-d1t815-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t817-1">
   <w.rf>
    <LM>w#w-d1t817-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t817-2">
   <w.rf>
    <LM>w#w-d1t817-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t817-3">
   <w.rf>
    <LM>w#w-d1t817-3</LM>
   </w.rf>
   <form>nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m144-712-730">
   <w.rf>
    <LM>w#w-712-730</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t817-4">
   <w.rf>
    <LM>w#w-d1t817-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t817-5">
   <w.rf>
    <LM>w#w-d1t817-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t817-6">
   <w.rf>
    <LM>w#w-d1t817-6</LM>
   </w.rf>
   <form>schytal</form>
   <lemma>schytat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m144-d1t817-7">
   <w.rf>
    <LM>w#w-d1t817-7</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m144-d1t817-8">
   <w.rf>
    <LM>w#w-d1t817-8</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m144-d1t817-9">
   <w.rf>
    <LM>w#w-d1t817-9</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP2----------</tag>
  </m>
  <m id="m144-d1t817-10">
   <w.rf>
    <LM>w#w-d1t817-10</LM>
   </w.rf>
   <form>dětských</form>
   <lemma>dětský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m144-d1t817-11">
   <w.rf>
    <LM>w#w-d1t817-11</LM>
   </w.rf>
   <form>výprasků</form>
   <lemma>výprask</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m144-712-731">
   <w.rf>
    <LM>w#w-712-731</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e780-x4">
  <m id="m144-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t820-2">
   <w.rf>
    <LM>w#w-d1t820-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-d1t820-3">
   <w.rf>
    <LM>w#w-d1t820-3</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m144-d1t820-4">
   <w.rf>
    <LM>w#w-d1t820-4</LM>
   </w.rf>
   <form>vzpomínka</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t820-7">
   <w.rf>
    <LM>w#w-d1t820-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t820-8">
   <w.rf>
    <LM>w#w-d1t820-8</LM>
   </w.rf>
   <form>útlého</form>
   <lemma>útlý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m144-d1t820-9">
   <w.rf>
    <LM>w#w-d1t820-9</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-d1e780-x4-746">
   <w.rf>
    <LM>w#w-d1e780-x4-746</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-747">
  <m id="m144-d1t822-2">
   <w.rf>
    <LM>w#w-d1t822-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t822-6">
   <w.rf>
    <LM>w#w-d1t822-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-d1t822-7">
   <w.rf>
    <LM>w#w-d1t822-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t822-8">
   <w.rf>
    <LM>w#w-d1t822-8</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d1t822-3">
   <w.rf>
    <LM>w#w-d1t822-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t822-4">
   <w.rf>
    <LM>w#w-d1t822-4</LM>
   </w.rf>
   <form>útlého</form>
   <lemma>útlý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m144-d1t822-5">
   <w.rf>
    <LM>w#w-d1t822-5</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-747-748">
   <w.rf>
    <LM>w#w-747-748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t822-9">
   <w.rf>
    <LM>w#w-d1t822-9</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t822-11">
   <w.rf>
    <LM>w#w-d1t822-11</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m144-d1t822-14">
   <w.rf>
    <LM>w#w-d1t822-14</LM>
   </w.rf>
   <form>Slovenska</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m144-d1t822-16">
   <w.rf>
    <LM>w#w-d1t822-16</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m144-d1t822-18">
   <w.rf>
    <LM>w#w-d1t822-18</LM>
   </w.rf>
   <form>čtyřech</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m144-d1t822-19">
   <w.rf>
    <LM>w#w-d1t822-19</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m144-d-id95949-punct">
   <w.rf>
    <LM>w#w-d-id95949-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t822-21">
   <w.rf>
    <LM>w#w-d1t822-21</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t824-2">
   <w.rf>
    <LM>w#w-d1t824-2</LM>
   </w.rf>
   <form>Slováci</form>
   <lemma>Slovák_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m144-d1t824-4">
   <w.rf>
    <LM>w#w-d1t824-4</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m144-747-749">
   <w.rf>
    <LM>w#w-747-749</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-747-750">
   <w.rf>
    <LM>w#w-747-750</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t824-6">
   <w.rf>
    <LM>w#w-d1t824-6</LM>
   </w.rf>
   <form>Čehůni</form>
   <lemma>Čehůni-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m144-d1t824-8">
   <w.rf>
    <LM>w#w-d1t824-8</LM>
   </w.rf>
   <form>domou</form>
   <lemma>domou-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m144-747-25">
   <w.rf>
    <LM>w#w-747-25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-747-752">
   <w.rf>
    <LM>w#w-747-752</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-31">
  <m id="m144-d1t826-2">
   <w.rf>
    <LM>w#w-d1t826-2</LM>
   </w.rf>
   <form>Stěhovali</form>
   <lemma>stěhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t826-3">
   <w.rf>
    <LM>w#w-d1t826-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m144-d1t826-4">
   <w.rf>
    <LM>w#w-d1t826-4</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t826-5">
   <w.rf>
    <LM>w#w-d1t826-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t826-7">
   <w.rf>
    <LM>w#w-d1t826-7</LM>
   </w.rf>
   <form>Čech</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m144-747-753">
   <w.rf>
    <LM>w#w-747-753</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-754">
  <m id="m144-d1t828-2">
   <w.rf>
    <LM>w#w-d1t828-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t828-3">
   <w.rf>
    <LM>w#w-d1t828-3</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t828-4">
   <w.rf>
    <LM>w#w-d1t828-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m144-d1t828-5">
   <w.rf>
    <LM>w#w-d1t828-5</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m144-d1t828-6">
   <w.rf>
    <LM>w#w-d1t828-6</LM>
   </w.rf>
   <form>neříkejme</form>
   <lemma>říkat</lemma>
   <tag>Vi-P---1--N-I--</tag>
  </m>
  <m id="m144-d1t828-7">
   <w.rf>
    <LM>w#w-d1t828-7</LM>
   </w.rf>
   <form>mobilizace</form>
   <lemma>mobilizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d-id96330-punct">
   <w.rf>
    <LM>w#w-d-id96330-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t828-9">
   <w.rf>
    <LM>w#w-d1t828-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t828-10">
   <w.rf>
    <LM>w#w-d1t828-10</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m144-d1t828-11">
   <w.rf>
    <LM>w#w-d1t828-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t828-12">
   <w.rf>
    <LM>w#w-d1t828-12</LM>
   </w.rf>
   <form>posádek</form>
   <lemma>posádka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m144-d1t828-15">
   <w.rf>
    <LM>w#w-d1t828-15</LM>
   </w.rf>
   <form>zajišťovali</form>
   <lemma>zajišťovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1t828-16">
   <w.rf>
    <LM>w#w-d1t828-16</LM>
   </w.rf>
   <form>pořádek</form>
   <lemma>pořádek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d-id96456-punct">
   <w.rf>
    <LM>w#w-d-id96456-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t828-18">
   <w.rf>
    <LM>w#w-d1t828-18</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m144-d1t828-19">
   <w.rf>
    <LM>w#w-d1t828-19</LM>
   </w.rf>
   <form>reakce</form>
   <lemma>reakce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m144-d1t828-21">
   <w.rf>
    <LM>w#w-d1t828-21</LM>
   </w.rf>
   <form>Slováků</form>
   <lemma>Slovák_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m144-d1t828-23">
   <w.rf>
    <LM>w#w-d1t828-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t828-24">
   <w.rf>
    <LM>w#w-d1t828-24</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSIS4-P1-------</tag>
  </m>
  <m id="m144-d1t828-25">
   <w.rf>
    <LM>w#w-d1t828-25</LM>
   </w.rf>
   <form>odchod</form>
   <lemma>odchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m144-d1t828-26">
   <w.rf>
    <LM>w#w-d1t828-26</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m144-d1t828-27">
   <w.rf>
    <LM>w#w-d1t828-27</LM>
   </w.rf>
   <form>radostná</form>
   <lemma>radostný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m144-d1t828-29">
   <w.rf>
    <LM>w#w-d1t828-29</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t830-1">
   <w.rf>
    <LM>w#w-d1t830-1</LM>
   </w.rf>
   <form>vyzývavě</form>
   <lemma>vyzývavě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m144-d1t830-2">
   <w.rf>
    <LM>w#w-d1t830-2</LM>
   </w.rf>
   <form>provokativní</form>
   <lemma>provokativní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m144-754-773">
   <w.rf>
    <LM>w#w-754-773</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-d1e780-x5">
  <m id="m144-d1t833-2">
   <w.rf>
    <LM>w#w-d1t833-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t833-3">
   <w.rf>
    <LM>w#w-d1t833-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m144-d1t833-4">
   <w.rf>
    <LM>w#w-d1t833-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m144-d1t833-5">
   <w.rf>
    <LM>w#w-d1t833-5</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m144-d-id96770-punct">
   <w.rf>
    <LM>w#w-d-id96770-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t833-7">
   <w.rf>
    <LM>w#w-d1t833-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t833-9">
   <w.rf>
    <LM>w#w-d1t833-9</LM>
   </w.rf>
   <form>vojáky</form>
   <lemma>voják</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m144-d1t835-1">
   <w.rf>
    <LM>w#w-d1t835-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m144-d1t835-2">
   <w.rf>
    <LM>w#w-d1t835-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m144-d1t835-3">
   <w.rf>
    <LM>w#w-d1t835-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m144-d1e780-x5-774">
   <w.rf>
    <LM>w#w-d1e780-x5-774</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m144-d1t835-4">
   <w.rf>
    <LM>w#w-d1t835-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t835-5">
   <w.rf>
    <LM>w#w-d1t835-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m144-d1t835-6">
   <w.rf>
    <LM>w#w-d1t835-6</LM>
   </w.rf>
   <form>narychlo</form>
   <lemma>narychlo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t835-7">
   <w.rf>
    <LM>w#w-d1t835-7</LM>
   </w.rf>
   <form>odcházeli</form>
   <lemma>odcházet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m144-d1e780-x5-775">
   <w.rf>
    <LM>w#w-d1e780-x5-775</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m144-776">
  <m id="m144-d1t837-1">
   <w.rf>
    <LM>w#w-d1t837-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m144-d1t837-2">
   <w.rf>
    <LM>w#w-d1t837-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m144-d1t837-3">
   <w.rf>
    <LM>w#w-d1t837-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m144-d1t837-4">
   <w.rf>
    <LM>w#w-d1t837-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m144-d1t837-5">
   <w.rf>
    <LM>w#w-d1t837-5</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m144-d1t837-7">
   <w.rf>
    <LM>w#w-d1t837-7</LM>
   </w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m144-d1t837-8">
   <w.rf>
    <LM>w#w-d1t837-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m144-776-777">
   <w.rf>
    <LM>w#w-776-777</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
