<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_056.03.w.gz" />
  </references>
 </head>
 <s id="m056-d1e920-x2">
  <m id="m056-d1t923-1">
   <w.rf>
    <LM>w#w-d1t923-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t923-2">
   <w.rf>
    <LM>w#w-d1t923-2</LM>
   </w.rf>
   <form>hrajete</form>
   <lemma>hrát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t923-3">
   <w.rf>
    <LM>w#w-d1t923-3</LM>
   </w.rf>
   <form>tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d-id82289-punct">
   <w.rf>
    <LM>w#w-d-id82289-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e924-x2">
  <m id="m056-d1t929-2">
   <w.rf>
    <LM>w#w-d1t929-2</LM>
   </w.rf>
   <form>Tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d1t929-1">
   <w.rf>
    <LM>w#w-d1t929-1</LM>
   </w.rf>
   <form>hrajeme</form>
   <lemma>hrát</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t929-3">
   <w.rf>
    <LM>w#w-d1t929-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t929-5">
   <w.rf>
    <LM>w#w-d1t929-5</LM>
   </w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m056-d1t929-6">
   <w.rf>
    <LM>w#w-d1t929-6</LM>
   </w.rf>
   <form>Huti</form>
   <lemma>huť</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-d1e924-x2-386">
   <w.rf>
    <LM>w#w-d1e924-x2-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-387">
  <m id="m056-d1t931-3">
   <w.rf>
    <LM>w#w-d1t931-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t931-1">
   <w.rf>
    <LM>w#w-d1t931-1</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m056-d1t931-2">
   <w.rf>
    <LM>w#w-d1t931-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t931-4">
   <w.rf>
    <LM>w#w-d1t931-4</LM>
   </w.rf>
   <form>sedmdesát</form>
   <lemma>sedmdesát`70</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m056-d1t931-5">
   <w.rf>
    <LM>w#w-d1t931-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t931-6">
   <w.rf>
    <LM>w#w-d1t931-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t931-7">
   <w.rf>
    <LM>w#w-d1t931-7</LM>
   </w.rf>
   <form>hraju</form>
   <lemma>hrát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t931-8">
   <w.rf>
    <LM>w#w-d1t931-8</LM>
   </w.rf>
   <form>tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e924-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e924-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e934-x2">
  <m id="m056-d1t941-1">
   <w.rf>
    <LM>w#w-d1t941-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t941-2">
   <w.rf>
    <LM>w#w-d1t941-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t941-3">
   <w.rf>
    <LM>w#w-d1t941-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t949-1">
   <w.rf>
    <LM>w#w-d1t949-1</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d-m-d1e934-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e934-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e951-x2">
  <m id="m056-d1t956-2">
   <w.rf>
    <LM>w#w-d1t956-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t956-4">
   <w.rf>
    <LM>w#w-d1t956-4</LM>
   </w.rf>
   <form>teda</form>
   <lemma>teda-1_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t956-3">
   <w.rf>
    <LM>w#w-d1t956-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1e951-x2-408">
   <w.rf>
    <LM>w#w-d1e951-x2-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-409">
  <m id="m056-d1t962-2">
   <w.rf>
    <LM>w#w-d1t962-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m056-d1t962-3">
   <w.rf>
    <LM>w#w-d1t962-3</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t962-4">
   <w.rf>
    <LM>w#w-d1t962-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t962-5">
   <w.rf>
    <LM>w#w-d1t962-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t962-7">
   <w.rf>
    <LM>w#w-d1t962-7</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-423-427">
   <w.rf>
    <LM>w#w-423-427</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t962-11">
   <w.rf>
    <LM>w#w-d1t962-11</LM>
   </w.rf>
   <form>hraje</form>
   <lemma>hrát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t962-16">
   <w.rf>
    <LM>w#w-d1t962-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t962-13">
   <w.rf>
    <LM>w#w-d1t962-13</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m056-d1t962-14">
   <w.rf>
    <LM>w#w-d1t962-14</LM>
   </w.rf>
   <form>nižší</form>
   <lemma>nízký</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m056-d1t962-15">
   <w.rf>
    <LM>w#w-d1t962-15</LM>
   </w.rf>
   <form>třídu</form>
   <lemma>třída</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m056-409-430">
   <w.rf>
    <LM>w#w-409-430</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t962-20">
   <w.rf>
    <LM>w#w-d1t962-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t962-21">
   <w.rf>
    <LM>w#w-d1t962-21</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m056-d1t962-22">
   <w.rf>
    <LM>w#w-d1t962-22</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t962-25">
   <w.rf>
    <LM>w#w-d1t962-25</LM>
   </w.rf>
   <form>hraje</form>
   <lemma>hrát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-409-431">
   <w.rf>
    <LM>w#w-409-431</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t962-27">
   <w.rf>
    <LM>w#w-d1t962-27</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t962-29">
   <w.rf>
    <LM>w#w-d1t962-29</LM>
   </w.rf>
   <form>Prazdroji</form>
   <lemma>Prazdroj_;m</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m056-d-id83373-punct">
   <w.rf>
    <LM>w#w-d-id83373-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t962-32">
   <w.rf>
    <LM>w#w-d1t962-32</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t962-33">
   <w.rf>
    <LM>w#w-d1t962-33</LM>
   </w.rf>
   <form>přestoupil</form>
   <lemma>přestoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-d1t962-34">
   <w.rf>
    <LM>w#w-d1t962-34</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t962-36">
   <w.rf>
    <LM>w#w-d1t962-36</LM>
   </w.rf>
   <form>Slavoj</form>
   <lemma>Slavoj-2_;m</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-425-428">
   <w.rf>
    <LM>w#w-425-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-429">
  <m id="m056-d1t965-2">
   <w.rf>
    <LM>w#w-d1t965-2</LM>
   </w.rf>
   <form>Hraje</form>
   <lemma>hrát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t965-3">
   <w.rf>
    <LM>w#w-d1t965-3</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t965-4">
   <w.rf>
    <LM>w#w-d1t965-4</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-429-433">
   <w.rf>
    <LM>w#w-429-433</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-434">
  <m id="m056-d1t965-7">
   <w.rf>
    <LM>w#w-d1t965-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t965-8">
   <w.rf>
    <LM>w#w-d1t965-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t965-9">
   <w.rf>
    <LM>w#w-d1t965-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m056-d1t965-11">
   <w.rf>
    <LM>w#w-d1t965-11</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m056-434-435">
   <w.rf>
    <LM>w#w-434-435</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-436">
  <m id="m056-d1t967-2">
   <w.rf>
    <LM>w#w-d1t967-2</LM>
   </w.rf>
   <form>Zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-d1t967-1">
   <w.rf>
    <LM>w#w-d1t967-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-436-441">
   <w.rf>
    <LM>w#w-436-441</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1e968-x3-442">
   <w.rf>
    <LM>w#w-d1e968-x3-442</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t977-1">
   <w.rf>
    <LM>w#w-d1t977-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t977-3">
   <w.rf>
    <LM>w#w-d1t977-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t981-2">
   <w.rf>
    <LM>w#w-d1t981-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t981-4">
   <w.rf>
    <LM>w#w-d1t981-4</LM>
   </w.rf>
   <form>Huti</form>
   <lemma>Huť_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-d1t981-1">
   <w.rf>
    <LM>w#w-d1t981-1</LM>
   </w.rf>
   <form>tenisový</form>
   <lemma>tenisový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m056-d1t977-5">
   <w.rf>
    <LM>w#w-d1t977-5</LM>
   </w.rf>
   <form>turnaj</form>
   <lemma>turnaj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m056-d-id83929-punct">
   <w.rf>
    <LM>w#w-d-id83929-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t983-1">
   <w.rf>
    <LM>w#w-d1t983-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t983-3">
   <w.rf>
    <LM>w#w-d1t983-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t983-4">
   <w.rf>
    <LM>w#w-d1t983-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t983-5">
   <w.rf>
    <LM>w#w-d1t983-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m056-d1t983-6">
   <w.rf>
    <LM>w#w-d1t983-6</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m056-d1t983-7">
   <w.rf>
    <LM>w#w-d1t983-7</LM>
   </w.rf>
   <form>generace</form>
   <lemma>generace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m056-d1e978-x2-443">
   <w.rf>
    <LM>w#w-d1e978-x2-443</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t987-1">
   <w.rf>
    <LM>w#w-d1t987-1</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d-id84097-punct">
   <w.rf>
    <LM>w#w-d-id84097-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t987-5">
   <w.rf>
    <LM>w#w-d1t987-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t987-7">
   <w.rf>
    <LM>w#w-d1t987-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t987-6">
   <w.rf>
    <LM>w#w-d1t987-6</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d-m-d1e978-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e978-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-449">
  <m id="m056-d1t1011-1">
   <w.rf>
    <LM>w#w-d1t1011-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t1011-2">
   <w.rf>
    <LM>w#w-d1t1011-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1011-3">
   <w.rf>
    <LM>w#w-d1t1011-3</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m056-d-m-d1e1004-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1004-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1004-x2">
  <m id="m056-d1t1009-1">
   <w.rf>
    <LM>w#w-d1t1009-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1009-2">
   <w.rf>
    <LM>w#w-d1t1009-2</LM>
   </w.rf>
   <form>probíhala</form>
   <lemma>probíhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m056-d1t1015-1">
   <w.rf>
    <LM>w#w-d1t1015-1</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m056-d1t1015-2">
   <w.rf>
    <LM>w#w-d1t1015-2</LM>
   </w.rf>
   <form>oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d-id84584-punct">
   <w.rf>
    <LM>w#w-d-id84584-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1016-x2">
  <m id="m056-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1021-3">
   <w.rf>
    <LM>w#w-d1t1021-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t1021-5">
   <w.rf>
    <LM>w#w-d1t1021-5</LM>
   </w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-2_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m056-d1t1021-8">
   <w.rf>
    <LM>w#w-d1t1021-8</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1021-10">
   <w.rf>
    <LM>w#w-d1t1021-10</LM>
   </w.rf>
   <form>Veselých</form>
   <lemma>Veselý_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m056-d1e1016-x2-457">
   <w.rf>
    <LM>w#w-d1e1016-x2-457</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-458">
  <m id="m056-d1t1023-4">
   <w.rf>
    <LM>w#w-d1t1023-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m056-458-459">
   <w.rf>
    <LM>w#w-458-459</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1023-2">
   <w.rf>
    <LM>w#w-d1t1023-2</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m056-d1t1023-3">
   <w.rf>
    <LM>w#w-d1t1023-3</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-458-460">
   <w.rf>
    <LM>w#w-458-460</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-461">
  <m id="m056-d1t1023-7">
   <w.rf>
    <LM>w#w-d1t1023-7</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1023-8">
   <w.rf>
    <LM>w#w-d1t1023-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1023-9">
   <w.rf>
    <LM>w#w-d1t1023-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t1023-10">
   <w.rf>
    <LM>w#w-d1t1023-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1023-6">
   <w.rf>
    <LM>w#w-d1t1023-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1023-11">
   <w.rf>
    <LM>w#w-d1t1023-11</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1023-12">
   <w.rf>
    <LM>w#w-d1t1023-12</LM>
   </w.rf>
   <form>zrušené</form>
   <lemma>zrušený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-461-462">
   <w.rf>
    <LM>w#w-461-462</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-463">
  <m id="m056-d1t1023-14">
   <w.rf>
    <LM>w#w-d1t1023-14</LM>
   </w.rf>
   <form>Udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m056-d1t1023-15">
   <w.rf>
    <LM>w#w-d1t1023-15</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1023-16">
   <w.rf>
    <LM>w#w-d1t1023-16</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m056-d1t1023-17">
   <w.rf>
    <LM>w#w-d1t1023-17</LM>
   </w.rf>
   <form>ubytovnu</form>
   <lemma>ubytovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m056-463-464">
   <w.rf>
    <LM>w#w-463-464</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-465">
  <m id="m056-d1t1023-19">
   <w.rf>
    <LM>w#w-d1t1023-19</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1023-20">
   <w.rf>
    <LM>w#w-d1t1023-20</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1023-21">
   <w.rf>
    <LM>w#w-d1t1023-21</LM>
   </w.rf>
   <form>nechodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m056-d-m-d1e1016-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1016-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1024-x2">
  <m id="m056-d1t1027-1">
   <w.rf>
    <LM>w#w-d1t1027-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m056-d1t1027-2">
   <w.rf>
    <LM>w#w-d1t1027-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1027-3">
   <w.rf>
    <LM>w#w-d1t1027-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1027-4">
   <w.rf>
    <LM>w#w-d1t1027-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1027-5">
   <w.rf>
    <LM>w#w-d1t1027-5</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1027-6">
   <w.rf>
    <LM>w#w-d1t1027-6</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m056-d-id85226-punct">
   <w.rf>
    <LM>w#w-d-id85226-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1028-x2">
  <m id="m056-d1t1033-2">
   <w.rf>
    <LM>w#w-d1t1033-2</LM>
   </w.rf>
   <form>Takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m056-d1t1033-3">
   <w.rf>
    <LM>w#w-d1t1033-3</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m056-d1e1028-x2-470">
   <w.rf>
    <LM>w#w-d1e1028-x2-470</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-471">
  <m id="m056-d1t1033-11">
   <w.rf>
    <LM>w#w-d1t1033-11</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1033-14">
   <w.rf>
    <LM>w#w-d1t1033-14</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1033-12">
   <w.rf>
    <LM>w#w-d1t1033-12</LM>
   </w.rf>
   <form>nejsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m056-d1t1033-13">
   <w.rf>
    <LM>w#w-d1t1033-13</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m056-471-472">
   <w.rf>
    <LM>w#w-471-472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1033-8">
   <w.rf>
    <LM>w#w-d1t1033-8</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m056-d1t1033-7">
   <w.rf>
    <LM>w#w-d1t1033-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1033-9">
   <w.rf>
    <LM>w#w-d1t1033-9</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-471-473">
   <w.rf>
    <LM>w#w-471-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-474">
  <m id="m056-d1t1035-1">
   <w.rf>
    <LM>w#w-d1t1035-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1035-2">
   <w.rf>
    <LM>w#w-d1t1035-2</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m056-474-475">
   <w.rf>
    <LM>w#w-474-475</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1037-1">
   <w.rf>
    <LM>w#w-d1t1037-1</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m056-d-m-d1e1028-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1028-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1043-x2">
  <m id="m056-d1t1046-2">
   <w.rf>
    <LM>w#w-d1t1046-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1046-3">
   <w.rf>
    <LM>w#w-d1t1046-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t1046-4">
   <w.rf>
    <LM>w#w-d1t1046-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d-m-d1e1043-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1043-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1048-x2">
  <m id="m056-d1t1055-1">
   <w.rf>
    <LM>w#w-d1t1055-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1055-2">
   <w.rf>
    <LM>w#w-d1t1055-2</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d-m-d1e1048-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1048-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1056-x2">
  <m id="m056-d1t1061-1">
   <w.rf>
    <LM>w#w-d1t1061-1</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1061-2">
   <w.rf>
    <LM>w#w-d1t1061-2</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m056-d1t1061-3">
   <w.rf>
    <LM>w#w-d1t1061-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m056-d1t1061-4">
   <w.rf>
    <LM>w#w-d1t1061-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m056-d1t1061-5">
   <w.rf>
    <LM>w#w-d1t1061-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m056-d1t1061-6">
   <w.rf>
    <LM>w#w-d1t1061-6</LM>
   </w.rf>
   <form>povíte</form>
   <lemma>povědět</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m056-d-id86063-punct">
   <w.rf>
    <LM>w#w-d-id86063-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1062-x2">
  <m id="m056-d1t1065-7">
   <w.rf>
    <LM>w#w-d1t1065-7</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m056-d1t1065-8">
   <w.rf>
    <LM>w#w-d1t1065-8</LM>
   </w.rf>
   <form>fabrika</form>
   <lemma>fabrika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d1t1065-10">
   <w.rf>
    <LM>w#w-d1t1065-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m056-d1t1065-11">
   <w.rf>
    <LM>w#w-d1t1065-11</LM>
   </w.rf>
   <form>zrušená</form>
   <lemma>zrušený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m056-d1e1062-x2-494">
   <w.rf>
    <LM>w#w-d1e1062-x2-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-495">
  <m id="m056-d1t1065-13">
   <w.rf>
    <LM>w#w-d1t1065-13</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m056-495-497">
   <w.rf>
    <LM>w#w-495-497</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1067-1">
   <w.rf>
    <LM>w#w-d1t1067-1</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m056-d1t1067-2">
   <w.rf>
    <LM>w#w-d1t1067-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1067-3">
   <w.rf>
    <LM>w#w-d1t1067-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-495-496">
   <w.rf>
    <LM>w#w-495-496</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1065-18">
   <w.rf>
    <LM>w#w-d1t1065-18</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m056-d1t1065-19">
   <w.rf>
    <LM>w#w-d1t1065-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1065-21">
   <w.rf>
    <LM>w#w-d1t1065-21</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d-id86416-punct">
   <w.rf>
    <LM>w#w-d-id86416-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-495-498">
   <w.rf>
    <LM>w#w-495-498</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m056-d1t1065-24">
   <w.rf>
    <LM>w#w-d1t1065-24</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1065-25">
   <w.rf>
    <LM>w#w-d1t1065-25</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1065-26">
   <w.rf>
    <LM>w#w-d1t1065-26</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t1065-27">
   <w.rf>
    <LM>w#w-d1t1065-27</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m056-d-id86496-punct">
   <w.rf>
    <LM>w#w-d-id86496-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1067-7">
   <w.rf>
    <LM>w#w-d1t1067-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t1067-8">
   <w.rf>
    <LM>w#w-d1t1067-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t1067-9">
   <w.rf>
    <LM>w#w-d1t1067-9</LM>
   </w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m056-d1t1067-10">
   <w.rf>
    <LM>w#w-d1t1067-10</LM>
   </w.rf>
   <form>pracovišti</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m056-495-499">
   <w.rf>
    <LM>w#w-495-499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-500">
  <m id="m056-d1t1071-2">
   <w.rf>
    <LM>w#w-d1t1071-2</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1071-3">
   <w.rf>
    <LM>w#w-d1t1071-3</LM>
   </w.rf>
   <form>tenhleten</form>
   <lemma>tenhleten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m056-d1t1071-4">
   <w.rf>
    <LM>w#w-d1t1071-4</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m056-d-id86757-punct">
   <w.rf>
    <LM>w#w-d-id86757-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1071-10">
   <w.rf>
    <LM>w#w-d1t1071-10</LM>
   </w.rf>
   <form>Jarda</form>
   <lemma>Jarda_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t1071-11">
   <w.rf>
    <LM>w#w-d1t1071-11</LM>
   </w.rf>
   <form>Kotva</form>
   <lemma>Kotva-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d-id86847-punct">
   <w.rf>
    <LM>w#w-d-id86847-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1071-19">
   <w.rf>
    <LM>w#w-d1t1071-19</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1071-21">
   <w.rf>
    <LM>w#w-d1t1071-21</LM>
   </w.rf>
   <form>normovač</form>
   <lemma>normovač</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-500-501">
   <w.rf>
    <LM>w#w-500-501</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1076-1">
   <w.rf>
    <LM>w#w-d1t1076-1</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1076-2">
   <w.rf>
    <LM>w#w-d1t1076-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1076-3">
   <w.rf>
    <LM>w#w-d1t1076-3</LM>
   </w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-d1t1076-6">
   <w.rf>
    <LM>w#w-d1t1076-6</LM>
   </w.rf>
   <form>Schwarzmüller</form>
   <lemma>Schwarzmüller_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m056-500-503">
   <w.rf>
    <LM>w#w-500-503</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-504">
  <m id="m056-d1t1080-3">
   <w.rf>
    <LM>w#w-d1t1080-3</LM>
   </w.rf>
   <form>Pozval</form>
   <lemma>pozvat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-d1t1080-1">
   <w.rf>
    <LM>w#w-d1t1080-1</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m056-d1t1080-2">
   <w.rf>
    <LM>w#w-d1t1080-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-504-522">
   <w.rf>
    <LM>w#w-504-522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1062-x3">
  <m id="m056-d1t1080-5">
   <w.rf>
    <LM>w#w-d1t1080-5</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1080-6">
   <w.rf>
    <LM>w#w-d1t1080-6</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m056-d1t1080-7">
   <w.rf>
    <LM>w#w-d1t1080-7</LM>
   </w.rf>
   <form>otevřených</form>
   <lemma>otevřený_^(*3ít)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m056-d1t1080-8">
   <w.rf>
    <LM>w#w-d1t1080-8</LM>
   </w.rf>
   <form>dveří</form>
   <lemma>dveře</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m056-d1t1082-1">
   <w.rf>
    <LM>w#w-d1t1082-1</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m056-d1t1082-2">
   <w.rf>
    <LM>w#w-d1t1082-2</LM>
   </w.rf>
   <form>haly</form>
   <lemma>hala</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-d1e1062-x3-557">
   <w.rf>
    <LM>w#w-d1e1062-x3-557</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-558">
  <m id="m056-d1t1082-6">
   <w.rf>
    <LM>w#w-d1t1082-6</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m056-d1t1082-7">
   <w.rf>
    <LM>w#w-d1t1082-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t1082-9">
   <w.rf>
    <LM>w#w-d1t1082-9</LM>
   </w.rf>
   <form>uplatnili</form>
   <lemma>uplatnit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m056-d1t1084-1">
   <w.rf>
    <LM>w#w-d1t1084-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1084-2">
   <w.rf>
    <LM>w#w-d1t1084-2</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m056-d1t1084-4">
   <w.rf>
    <LM>w#w-d1t1084-4</LM>
   </w.rf>
   <form>pracují</form>
   <lemma>pracovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m056-558-559">
   <w.rf>
    <LM>w#w-558-559</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-560">
  <m id="m056-d1t1086-1">
   <w.rf>
    <LM>w#w-d1t1086-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1086-2">
   <w.rf>
    <LM>w#w-d1t1086-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1086-3">
   <w.rf>
    <LM>w#w-d1t1086-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-560-561">
   <w.rf>
    <LM>w#w-560-561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-562">
  <m id="m056-d1t1086-11">
   <w.rf>
    <LM>w#w-d1t1086-11</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1086-10">
   <w.rf>
    <LM>w#w-d1t1086-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1086-8">
   <w.rf>
    <LM>w#w-d1t1086-8</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m056-d1t1086-9">
   <w.rf>
    <LM>w#w-d1t1086-9</LM>
   </w.rf>
   <form>raut</form>
   <lemma>raut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m056-564-567">
   <w.rf>
    <LM>w#w-564-567</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1089-1">
   <w.rf>
    <LM>w#w-d1t1089-1</LM>
   </w.rf>
   <form>grilovalo</form>
   <lemma>grilovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1089-2">
   <w.rf>
    <LM>w#w-d1t1089-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-562-576">
   <w.rf>
    <LM>w#w-562-576</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-577">
  <m id="m056-564-571">
   <w.rf>
    <LM>w#w-564-571</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1091-1">
   <w.rf>
    <LM>w#w-d1t1091-1</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m056-d1t1091-2">
   <w.rf>
    <LM>w#w-d1t1091-2</LM>
   </w.rf>
   <form>druhů</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m056-d1t1091-3">
   <w.rf>
    <LM>w#w-d1t1091-3</LM>
   </w.rf>
   <form>zmrzliny</form>
   <lemma>zmrzlina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-564-570">
   <w.rf>
    <LM>w#w-564-570</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1091-5">
   <w.rf>
    <LM>w#w-d1t1091-5</LM>
   </w.rf>
   <form>ovoce</form>
   <lemma>ovoce</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m056-d1t1091-6">
   <w.rf>
    <LM>w#w-d1t1091-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1105-1">
   <w.rf>
    <LM>w#w-d1t1105-1</LM>
   </w.rf>
   <form>kotlety</form>
   <lemma>kotleta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m056-d-m-d1e1062-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1062-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1109-x2">
  <m id="m056-d1t1114-3">
   <w.rf>
    <LM>w#w-d1t1114-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1114-2">
   <w.rf>
    <LM>w#w-d1t1114-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1114-1">
   <w.rf>
    <LM>w#w-d1t1114-1</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-d1e1109-x2-584">
   <w.rf>
    <LM>w#w-d1e1109-x2-584</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-585">
  <m id="m056-d1t1116-6">
   <w.rf>
    <LM>w#w-d1t1116-6</LM>
   </w.rf>
   <form>Scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1116-4">
   <w.rf>
    <LM>w#w-d1t1116-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-585-590">
   <w.rf>
    <LM>w#w-585-590</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1116-5">
   <w.rf>
    <LM>w#w-d1t1116-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1118-1">
   <w.rf>
    <LM>w#w-d1t1118-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m056-d1t1118-4">
   <w.rf>
    <LM>w#w-d1t1118-4</LM>
   </w.rf>
   <form>pracovištích</form>
   <lemma>pracoviště</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m056-d-id88187-punct">
   <w.rf>
    <LM>w#w-d-id88187-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1118-6">
   <w.rf>
    <LM>w#w-d1t1118-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1118-8">
   <w.rf>
    <LM>w#w-d1t1118-8</LM>
   </w.rf>
   <form>kolegové</form>
   <lemma>kolega</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m056-d1t1118-10">
   <w.rf>
    <LM>w#w-d1t1118-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1118-9">
   <w.rf>
    <LM>w#w-d1t1118-9</LM>
   </w.rf>
   <form>pracujou</form>
   <lemma>pracovat</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m056-585-588">
   <w.rf>
    <LM>w#w-585-588</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-589">
  <m id="m056-d1t1120-3">
   <w.rf>
    <LM>w#w-d1t1120-3</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m056-d1t1120-4">
   <w.rf>
    <LM>w#w-d1t1120-4</LM>
   </w.rf>
   <form>důchodci</form>
   <lemma>důchodce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m056-d1t1120-8">
   <w.rf>
    <LM>w#w-d1t1120-8</LM>
   </w.rf>
   <form>hrajeme</form>
   <lemma>hrát</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1120-10">
   <w.rf>
    <LM>w#w-d1t1120-10</LM>
   </w.rf>
   <form>tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d-id88419-punct">
   <w.rf>
    <LM>w#w-d-id88419-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1120-12">
   <w.rf>
    <LM>w#w-d1t1120-12</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t1120-13">
   <w.rf>
    <LM>w#w-d1t1120-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t1120-14">
   <w.rf>
    <LM>w#w-d1t1120-14</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1120-15">
   <w.rf>
    <LM>w#w-d1t1120-15</LM>
   </w.rf>
   <form>sejdeme</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m056-589-593">
   <w.rf>
    <LM>w#w-589-593</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-594">
  <m id="m056-d1t1120-17">
   <w.rf>
    <LM>w#w-d1t1120-17</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t1120-18">
   <w.rf>
    <LM>w#w-d1t1120-18</LM>
   </w.rf>
   <form>tenisu</form>
   <lemma>tenis</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m056-d1t1120-20">
   <w.rf>
    <LM>w#w-d1t1120-20</LM>
   </w.rf>
   <form>jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1120-21">
   <w.rf>
    <LM>w#w-d1t1120-21</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t1120-22">
   <w.rf>
    <LM>w#w-d1t1120-22</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m056-d1t1120-23">
   <w.rf>
    <LM>w#w-d1t1120-23</LM>
   </w.rf>
   <form>piva</form>
   <lemma>pivo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e1109-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1109-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1127-x2">
  <m id="m056-d1t1130-1">
   <w.rf>
    <LM>w#w-d1t1130-1</LM>
   </w.rf>
   <form>Popovídáme</form>
   <lemma>popovídat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m056-d1t1130-2">
   <w.rf>
    <LM>w#w-d1t1130-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m056-d1e1127-x2-598">
   <w.rf>
    <LM>w#w-d1e1127-x2-598</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-599">
  <m id="m056-d1t1130-5">
   <w.rf>
    <LM>w#w-d1t1130-5</LM>
   </w.rf>
   <form>Pohoda</form>
   <lemma>pohoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d-m-d1e1127-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1127-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1135-x2">
  <m id="m056-d1t1138-1">
   <w.rf>
    <LM>w#w-d1t1138-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1138-2">
   <w.rf>
    <LM>w#w-d1t1138-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t1138-3">
   <w.rf>
    <LM>w#w-d1t1138-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t1138-4">
   <w.rf>
    <LM>w#w-d1t1138-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1138-5">
   <w.rf>
    <LM>w#w-d1t1138-5</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1138-6">
   <w.rf>
    <LM>w#w-d1t1138-6</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m056-d-id88951-punct">
   <w.rf>
    <LM>w#w-d-id88951-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1139-x2">
  <m id="m056-d1t1144-9">
   <w.rf>
    <LM>w#w-d1t1144-9</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1144-7">
   <w.rf>
    <LM>w#w-d1t1144-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1144-8">
   <w.rf>
    <LM>w#w-d1t1144-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1144-10">
   <w.rf>
    <LM>w#w-d1t1144-10</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1144-11">
   <w.rf>
    <LM>w#w-d1t1144-11</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m056-d1t1144-12">
   <w.rf>
    <LM>w#w-d1t1144-12</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m056-d1e1139-x2-611">
   <w.rf>
    <LM>w#w-d1e1139-x2-611</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-612">
  <m id="m056-d1t1144-14">
   <w.rf>
    <LM>w#w-d1t1144-14</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1144-15">
   <w.rf>
    <LM>w#w-d1t1144-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t1144-16">
   <w.rf>
    <LM>w#w-d1t1144-16</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m056-d1t1144-17">
   <w.rf>
    <LM>w#w-d1t1144-17</LM>
   </w.rf>
   <form>fabrika</form>
   <lemma>fabrika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d1t1144-18">
   <w.rf>
    <LM>w#w-d1t1144-18</LM>
   </w.rf>
   <form>zavřela</form>
   <lemma>zavřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m056-612-613">
   <w.rf>
    <LM>w#w-612-613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-614">
  <m id="m056-d1t1148-3">
   <w.rf>
    <LM>w#w-d1t1148-3</LM>
   </w.rf>
   <form>Šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1148-2">
   <w.rf>
    <LM>w#w-d1t1148-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1148-4">
   <w.rf>
    <LM>w#w-d1t1148-4</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m056-d1t1148-5">
   <w.rf>
    <LM>w#w-d1t1148-5</LM>
   </w.rf>
   <form>vedoucího</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m056-d1t1148-6">
   <w.rf>
    <LM>w#w-d1t1148-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1148-7">
   <w.rf>
    <LM>w#w-d1t1148-7</LM>
   </w.rf>
   <form>strojírny</form>
   <lemma>strojírna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-614-615">
   <w.rf>
    <LM>w#w-614-615</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t1148-10">
   <w.rf>
    <LM>w#w-d1t1148-10</LM>
   </w.rf>
   <form>firma</form>
   <lemma>firma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d1t1148-12">
   <w.rf>
    <LM>w#w-d1t1148-12</LM>
   </w.rf>
   <form>Hájek</form>
   <lemma>Hájek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-614-616">
   <w.rf>
    <LM>w#w-614-616</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-617">
  <m id="m056-d1t1148-16">
   <w.rf>
    <LM>w#w-d1t1148-16</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1148-15">
   <w.rf>
    <LM>w#w-d1t1148-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1148-14">
   <w.rf>
    <LM>w#w-d1t1148-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1148-20">
   <w.rf>
    <LM>w#w-d1t1148-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t1148-21">
   <w.rf>
    <LM>w#w-d1t1148-21</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m056-d1t1148-17">
   <w.rf>
    <LM>w#w-d1t1148-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t1148-18">
   <w.rf>
    <LM>w#w-d1t1148-18</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m056-d1t1148-19">
   <w.rf>
    <LM>w#w-d1t1148-19</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m056-617-618">
   <w.rf>
    <LM>w#w-617-618</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-619">
  <m id="m056-d1t1150-2">
   <w.rf>
    <LM>w#w-d1t1150-2</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m056-d1t1150-1">
   <w.rf>
    <LM>w#w-d1t1150-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1150-3">
   <w.rf>
    <LM>w#w-d1t1150-3</LM>
   </w.rf>
   <form>veliké</form>
   <lemma>veliký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-619-620">
   <w.rf>
    <LM>w#w-619-620</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-621">
  <m id="m056-d1t1153-1">
   <w.rf>
    <LM>w#w-d1t1153-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1153-2">
   <w.rf>
    <LM>w#w-d1t1153-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1153-3">
   <w.rf>
    <LM>w#w-d1t1153-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1153-4">
   <w.rf>
    <LM>w#w-d1t1153-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m056-d1t1153-5">
   <w.rf>
    <LM>w#w-d1t1153-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1153-6">
   <w.rf>
    <LM>w#w-d1t1153-6</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m056-d1t1153-7">
   <w.rf>
    <LM>w#w-d1t1153-7</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m056-d1t1153-9">
   <w.rf>
    <LM>w#w-d1t1153-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1153-10">
   <w.rf>
    <LM>w#w-d1t1153-10</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1153-27">
   <w.rf>
    <LM>w#w-d1t1153-27</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1153-12">
   <w.rf>
    <LM>w#w-d1t1153-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t1153-13">
   <w.rf>
    <LM>w#w-d1t1153-13</LM>
   </w.rf>
   <form>vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-d1t1153-14">
   <w.rf>
    <LM>w#w-d1t1153-14</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1153-22">
   <w.rf>
    <LM>w#w-d1t1153-22</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1153-25">
   <w.rf>
    <LM>w#w-d1t1153-25</LM>
   </w.rf>
   <form>Atmosu</form>
   <lemma>Atmos_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m056-621-622">
   <w.rf>
    <LM>w#w-621-622</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-623">
  <m id="m056-d1t1153-19">
   <w.rf>
    <LM>w#w-d1t1153-19</LM>
   </w.rf>
   <form>Vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m056-d1t1153-18">
   <w.rf>
    <LM>w#w-d1t1153-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m056-d1t1153-20">
   <w.rf>
    <LM>w#w-d1t1153-20</LM>
   </w.rf>
   <form>soukromníci</form>
   <lemma>soukromník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m056-623-624">
   <w.rf>
    <LM>w#w-623-624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1139-x3">
  <m id="m056-d1t1153-35">
   <w.rf>
    <LM>w#w-d1t1153-35</LM>
   </w.rf>
   <form>Dodělal</form>
   <lemma>dodělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-d1t1153-33">
   <w.rf>
    <LM>w#w-d1t1153-33</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1153-34">
   <w.rf>
    <LM>w#w-d1t1153-34</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m056-d1t1153-32">
   <w.rf>
    <LM>w#w-d1t1153-32</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1153-36">
   <w.rf>
    <LM>w#w-d1t1153-36</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t1153-37">
   <w.rf>
    <LM>w#w-d1t1153-37</LM>
   </w.rf>
   <form>penze</form>
   <lemma>penze</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-d1e1154-x3-629">
   <w.rf>
    <LM>w#w-d1e1154-x3-629</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1e1154-x3-630">
   <w.rf>
    <LM>w#w-d1e1154-x3-630</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t1163-5">
   <w.rf>
    <LM>w#w-d1t1163-5</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t1163-6">
   <w.rf>
    <LM>w#w-d1t1163-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m056-d1t1163-7">
   <w.rf>
    <LM>w#w-d1t1163-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1167-1">
   <w.rf>
    <LM>w#w-d1t1167-1</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d-m-d1e1154-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1154-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e1164-x2">
  <m id="m056-d1t1167-9">
   <w.rf>
    <LM>w#w-d1t1167-9</LM>
   </w.rf>
   <form>Dodělali</form>
   <lemma>dodělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m056-d1t1167-6">
   <w.rf>
    <LM>w#w-d1t1167-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t1167-7">
   <w.rf>
    <LM>w#w-d1t1167-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m056-d1t1167-8">
   <w.rf>
    <LM>w#w-d1t1167-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1e1164-x2-633">
   <w.rf>
    <LM>w#w-d1e1164-x2-633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-634">
  <m id="m056-d1t1169-4">
   <w.rf>
    <LM>w#w-d1t1169-4</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d1t1169-3">
   <w.rf>
    <LM>w#w-d1t1169-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t1169-2">
   <w.rf>
    <LM>w#w-d1t1169-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t1169-1">
   <w.rf>
    <LM>w#w-d1t1169-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t1169-5">
   <w.rf>
    <LM>w#w-d1t1169-5</LM>
   </w.rf>
   <form>poloviční</form>
   <lemma>poloviční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m056-d1t1169-6">
   <w.rf>
    <LM>w#w-d1t1169-6</LM>
   </w.rf>
   <form>obsazení</form>
   <lemma>obsazení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m056-634-636">
   <w.rf>
    <LM>w#w-634-636</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-637">
  <m id="m056-d1t1169-10">
   <w.rf>
    <LM>w#w-d1t1169-10</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t1169-11">
   <w.rf>
    <LM>w#w-d1t1169-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m056-d1t1169-12">
   <w.rf>
    <LM>w#w-d1t1169-12</LM>
   </w.rf>
   <form>zredukovali</form>
   <lemma>zredukovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m056-d-m-d1e1164-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1164-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
