<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_019.04.w.gz" />
  </references>
 </head>
 <s id="m019-214">
  <m id="m019-d1t1360-1">
   <w.rf>
    <LM>w#w-d1t1360-1</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1360-2">
   <w.rf>
    <LM>w#w-d1t1360-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1360-3">
   <w.rf>
    <LM>w#w-d1t1360-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1360-4">
   <w.rf>
    <LM>w#w-d1t1360-4</LM>
   </w.rf>
   <form>expedici</form>
   <lemma>expedice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d1e1353-x2-610">
   <w.rf>
    <LM>w#w-d1e1353-x2-610</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-612">
  <m id="m019-d1t1362-1">
   <w.rf>
    <LM>w#w-d1t1362-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1362-2">
   <w.rf>
    <LM>w#w-d1t1362-2</LM>
   </w.rf>
   <form>ukázat</form>
   <lemma>ukázat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m019-d-id92790-punct">
   <w.rf>
    <LM>w#w-d-id92790-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1362-4">
   <w.rf>
    <LM>w#w-d1t1362-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1362-5">
   <w.rf>
    <LM>w#w-d1t1362-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d-id92829-punct">
   <w.rf>
    <LM>w#w-d-id92829-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1370-x2">
  <m id="m019-d1t1373-1">
   <w.rf>
    <LM>w#w-d1t1373-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1373-2">
   <w.rf>
    <LM>w#w-d1t1373-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m019-d1t1373-4">
   <w.rf>
    <LM>w#w-d1t1373-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1373-6">
   <w.rf>
    <LM>w#w-d1t1373-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1377-2">
   <w.rf>
    <LM>w#w-d1t1377-2</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m019-d1t1387-2">
   <w.rf>
    <LM>w#w-d1t1387-2</LM>
   </w.rf>
   <form>cukrárny</form>
   <lemma>cukrárna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1370-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1370-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1378-x3">
  <m id="m019-d1t1392-1">
   <w.rf>
    <LM>w#w-d1t1392-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m019-d1t1392-2">
   <w.rf>
    <LM>w#w-d1t1392-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1392-3">
   <w.rf>
    <LM>w#w-d1t1392-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m019-d1t1392-4">
   <w.rf>
    <LM>w#w-d1t1392-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1392-5">
   <w.rf>
    <LM>w#w-d1t1392-5</LM>
   </w.rf>
   <form>cukrárnu</form>
   <lemma>cukrárna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d-id93294-punct">
   <w.rf>
    <LM>w#w-d-id93294-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1395-x2">
  <m id="m019-d1t1398-2">
   <w.rf>
    <LM>w#w-d1t1398-2</LM>
   </w.rf>
   <form>Výrobna</form>
   <lemma>výrobna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d1e1395-x2-224">
   <w.rf>
    <LM>w#w-d1e1395-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-225">
  <m id="m019-d1t1402-1">
   <w.rf>
    <LM>w#w-d1t1402-1</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1402-2">
   <w.rf>
    <LM>w#w-d1t1402-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1402-3">
   <w.rf>
    <LM>w#w-d1t1402-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1402-4">
   <w.rf>
    <LM>w#w-d1t1402-4</LM>
   </w.rf>
   <form>firma</form>
   <lemma>firma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d1t1402-6">
   <w.rf>
    <LM>w#w-d1t1402-6</LM>
   </w.rf>
   <form>Pondělík</form>
   <lemma>Pondělík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m019-d1e1395-x2-222">
   <w.rf>
    <LM>w#w-d1e1395-x2-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-223">
  <m id="m019-d1t1402-9">
   <w.rf>
    <LM>w#w-d1t1402-9</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1e1395-x2-634">
   <w.rf>
    <LM>w#w-d1e1395-x2-634</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1402-10">
   <w.rf>
    <LM>w#w-d1t1402-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1404-1">
   <w.rf>
    <LM>w#w-d1t1404-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1404-7">
   <w.rf>
    <LM>w#w-d1t1404-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1404-6">
   <w.rf>
    <LM>w#w-d1t1404-6</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m019-d1t1404-3">
   <w.rf>
    <LM>w#w-d1t1404-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1404-4">
   <w.rf>
    <LM>w#w-d1t1404-4</LM>
   </w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m019-d1t1404-5">
   <w.rf>
    <LM>w#w-d1t1404-5</LM>
   </w.rf>
   <form>okrese</form>
   <lemma>okres</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1395-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1395-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1405-x2">
  <m id="m019-d1t1408-1">
   <w.rf>
    <LM>w#w-d1t1408-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m019-d1t1408-2">
   <w.rf>
    <LM>w#w-d1t1408-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1408-3">
   <w.rf>
    <LM>w#w-d1t1408-3</LM>
   </w.rf>
   <form>vyráběli</form>
   <lemma>vyrábět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m019-d-id93837-punct">
   <w.rf>
    <LM>w#w-d-id93837-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1409-x2">
  <m id="m019-d1t1412-2">
   <w.rf>
    <LM>w#w-d1t1412-2</LM>
   </w.rf>
   <form>Zákusky</form>
   <lemma>zákusek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m019-d-id93930-punct">
   <w.rf>
    <LM>w#w-d-id93930-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1412-4">
   <w.rf>
    <LM>w#w-d1t1412-4</LM>
   </w.rf>
   <form>dorty</form>
   <lemma>dort</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m019-d1e1409-x2-642">
   <w.rf>
    <LM>w#w-d1e1409-x2-642</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1422-2">
   <w.rf>
    <LM>w#w-d1t1422-2</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1422-1">
   <w.rf>
    <LM>w#w-d1t1422-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m019-d-m-d1e1409-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1409-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1423-x2">
  <m id="m019-d1t1426-1">
   <w.rf>
    <LM>w#w-d1t1426-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1426-2">
   <w.rf>
    <LM>w#w-d1t1426-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1426-3">
   <w.rf>
    <LM>w#w-d1t1426-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1426-4">
   <w.rf>
    <LM>w#w-d1t1426-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1426-5">
   <w.rf>
    <LM>w#w-d1t1426-5</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d-id94205-punct">
   <w.rf>
    <LM>w#w-d-id94205-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1427-x2">
  <m id="m019-d1t1430-1">
   <w.rf>
    <LM>w#w-d1t1430-1</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m019-d1t1430-3">
   <w.rf>
    <LM>w#w-d1t1430-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1427-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1427-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1435-x2">
  <m id="m019-d1t1438-1">
   <w.rf>
    <LM>w#w-d1t1438-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1438-2">
   <w.rf>
    <LM>w#w-d1t1438-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1438-3">
   <w.rf>
    <LM>w#w-d1t1438-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m019-d1t1438-4">
   <w.rf>
    <LM>w#w-d1t1438-4</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d1t1438-5">
   <w.rf>
    <LM>w#w-d1t1438-5</LM>
   </w.rf>
   <form>vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d-id94462-punct">
   <w.rf>
    <LM>w#w-d-id94462-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1439-x2">
  <m id="m019-d1t1442-1">
   <w.rf>
    <LM>w#w-d1t1442-1</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1442-2">
   <w.rf>
    <LM>w#w-d1t1442-2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m019-d1t1442-3">
   <w.rf>
    <LM>w#w-d1t1442-3</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d1t1442-4">
   <w.rf>
    <LM>w#w-d1t1442-4</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1442-5">
   <w.rf>
    <LM>w#w-d1t1442-5</LM>
   </w.rf>
   <form>bavila</form>
   <lemma>bavit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1e1439-x2-648">
   <w.rf>
    <LM>w#w-d1e1439-x2-648</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1444-1">
   <w.rf>
    <LM>w#w-d1t1444-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1444-2">
   <w.rf>
    <LM>w#w-d1t1444-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1444-4">
   <w.rf>
    <LM>w#w-d1t1444-4</LM>
   </w.rf>
   <form>expedici</form>
   <lemma>expedice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d1t1444-5">
   <w.rf>
    <LM>w#w-d1t1444-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1446-1">
   <w.rf>
    <LM>w#w-d1t1446-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m019-d1t1446-2">
   <w.rf>
    <LM>w#w-d1t1446-2</LM>
   </w.rf>
   <form>dávala</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1446-3">
   <w.rf>
    <LM>w#w-d1t1446-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m019-d1t1446-5">
   <w.rf>
    <LM>w#w-d1t1446-5</LM>
   </w.rf>
   <form>dřevěných</form>
   <lemma>dřevěný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m019-d1t1446-6">
   <w.rf>
    <LM>w#w-d1t1446-6</LM>
   </w.rf>
   <form>kartonů</form>
   <lemma>karton_,s_^(^DD**kartón)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m019-d1t1448-2">
   <w.rf>
    <LM>w#w-d1t1448-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1448-4">
   <w.rf>
    <LM>w#w-d1t1448-4</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m019-d1t1448-3">
   <w.rf>
    <LM>w#w-d1t1448-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1448-5">
   <w.rf>
    <LM>w#w-d1t1448-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1448-6">
   <w.rf>
    <LM>w#w-d1t1448-6</LM>
   </w.rf>
   <form>prodejny</form>
   <lemma>prodejna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m019-d1e1439-x2-652">
   <w.rf>
    <LM>w#w-d1e1439-x2-652</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-654">
  <m id="m019-d1t1450-3">
   <w.rf>
    <LM>w#w-d1t1450-3</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m019-d1t1450-4">
   <w.rf>
    <LM>w#w-d1t1450-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1450-5">
   <w.rf>
    <LM>w#w-d1t1450-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1450-6">
   <w.rf>
    <LM>w#w-d1t1450-6</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m019-654-656">
   <w.rf>
    <LM>w#w-654-656</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1460-1">
   <w.rf>
    <LM>w#w-d1t1460-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1460-2">
   <w.rf>
    <LM>w#w-d1t1460-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1467-1">
   <w.rf>
    <LM>w#w-d1t1467-1</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1460-3">
   <w.rf>
    <LM>w#w-d1t1460-3</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1467-3">
   <w.rf>
    <LM>w#w-d1t1467-3</LM>
   </w.rf>
   <form>světlý</form>
   <lemma>světlý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m019-d1t1467-2">
   <w.rf>
    <LM>w#w-d1t1467-2</LM>
   </w.rf>
   <form>pruh</form>
   <lemma>pruh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m019-654-660">
   <w.rf>
    <LM>w#w-654-660</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1467-5">
   <w.rf>
    <LM>w#w-d1t1467-5</LM>
   </w.rf>
   <form>tmavý</form>
   <lemma>tmavý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m019-d1t1467-4">
   <w.rf>
    <LM>w#w-d1t1467-4</LM>
   </w.rf>
   <form>pruh</form>
   <lemma>pruh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m019-d1t1467-7">
   <w.rf>
    <LM>w#w-d1t1467-7</LM>
   </w.rf>
   <form>zákusků</form>
   <lemma>zákusek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m019-654-662">
   <w.rf>
    <LM>w#w-654-662</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-664">
  <m id="m019-d1t1471-6">
   <w.rf>
    <LM>w#w-d1t1471-6</LM>
   </w.rf>
   <form>Vyhrála</form>
   <lemma>vyhrát</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d1t1471-2">
   <w.rf>
    <LM>w#w-d1t1471-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1471-3">
   <w.rf>
    <LM>w#w-d1t1471-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m019-d1t1471-4">
   <w.rf>
    <LM>w#w-d1t1471-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1471-5">
   <w.rf>
    <LM>w#w-d1t1471-5</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m019-d-m-d1e1462-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1462-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1472-x2">
  <m id="m019-d1t1477-1">
   <w.rf>
    <LM>w#w-d1t1477-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m019-d1t1477-2">
   <w.rf>
    <LM>w#w-d1t1477-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m019-d1t1477-3">
   <w.rf>
    <LM>w#w-d1t1477-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1477-4">
   <w.rf>
    <LM>w#w-d1t1477-4</LM>
   </w.rf>
   <form>bavilo</form>
   <lemma>bavit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m019-d1t1477-5">
   <w.rf>
    <LM>w#w-d1t1477-5</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m019-d-id95510-punct">
   <w.rf>
    <LM>w#w-d-id95510-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1472-x4">
  <m id="m019-d1t1479-1">
   <w.rf>
    <LM>w#w-d1t1479-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1479-2">
   <w.rf>
    <LM>w#w-d1t1479-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1479-3">
   <w.rf>
    <LM>w#w-d1t1479-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m019-d1t1479-4">
   <w.rf>
    <LM>w#w-d1t1479-4</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d1t1479-5">
   <w.rf>
    <LM>w#w-d1t1479-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m019-d-m-d1e1472-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1472-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1480-x2">
  <m id="m019-d1t1483-2">
   <w.rf>
    <LM>w#w-d1t1483-2</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m019-d1t1483-3">
   <w.rf>
    <LM>w#w-d1t1483-3</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1483-4">
   <w.rf>
    <LM>w#w-d1t1483-4</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m019-d1e1480-x2-672">
   <w.rf>
    <LM>w#w-d1e1480-x2-672</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1485-3">
   <w.rf>
    <LM>w#w-d1t1485-3</LM>
   </w.rf>
   <form>papíry</form>
   <lemma>papír</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m019-d1t1485-7">
   <w.rf>
    <LM>w#w-d1t1485-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1485-8">
   <w.rf>
    <LM>w#w-d1t1485-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1485-9">
   <w.rf>
    <LM>w#w-d1t1485-9</LM>
   </w.rf>
   <form>nebavily</form>
   <lemma>bavit</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m019-d1t1487-1">
   <w.rf>
    <LM>w#w-d1t1487-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1497-1">
   <w.rf>
    <LM>w#w-d1t1497-1</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m019-d1t1497-2">
   <w.rf>
    <LM>w#w-d1t1497-2</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1480-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1480-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1498-x2">
  <m id="m019-d1t1501-1">
   <w.rf>
    <LM>w#w-d1t1501-1</LM>
   </w.rf>
   <form>Pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1501-2">
   <w.rf>
    <LM>w#w-d1t1501-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1501-3">
   <w.rf>
    <LM>w#w-d1t1501-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1501-4">
   <w.rf>
    <LM>w#w-d1t1501-4</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1501-5">
   <w.rf>
    <LM>w#w-d1t1501-5</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d-id96138-punct">
   <w.rf>
    <LM>w#w-d-id96138-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1502-x2">
  <m id="m019-d1t1505-5">
   <w.rf>
    <LM>w#w-d1t1505-5</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1505-4">
   <w.rf>
    <LM>w#w-d1t1505-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1509-4">
   <w.rf>
    <LM>w#w-d1t1509-4</LM>
   </w.rf>
   <form>ženskou</form>
   <lemma>ženský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m019-d1t1505-6">
   <w.rf>
    <LM>w#w-d1t1505-6</LM>
   </w.rf>
   <form>operaci</form>
   <lemma>operace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d-id96286-punct">
   <w.rf>
    <LM>w#w-d-id96286-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1505-8">
   <w.rf>
    <LM>w#w-d1t1505-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1505-9">
   <w.rf>
    <LM>w#w-d1t1505-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1505-10">
   <w.rf>
    <LM>w#w-d1t1505-10</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1505-11">
   <w.rf>
    <LM>w#w-d1t1505-11</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m019-d1t1505-12">
   <w.rf>
    <LM>w#w-d1t1505-12</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m019-d1t1505-13">
   <w.rf>
    <LM>w#w-d1t1505-13</LM>
   </w.rf>
   <form>nechat</form>
   <lemma>nechat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m019-d-id96388-punct">
   <w.rf>
    <LM>w#w-d-id96388-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1505-15">
   <w.rf>
    <LM>w#w-d1t1505-15</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1507-1">
   <w.rf>
    <LM>w#w-d1t1507-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1507-2">
   <w.rf>
    <LM>w#w-d1t1507-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1507-3">
   <w.rf>
    <LM>w#w-d1t1507-3</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1507-4">
   <w.rf>
    <LM>w#w-d1t1507-4</LM>
   </w.rf>
   <form>zvedat</form>
   <lemma>zvedat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m019-d1t1507-6">
   <w.rf>
    <LM>w#w-d1t1507-6</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m019-d1t1507-7">
   <w.rf>
    <LM>w#w-d1t1507-7</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m019-d1e1502-x2-682">
   <w.rf>
    <LM>w#w-d1e1502-x2-682</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-694">
  <m id="m019-d1t1511-6">
   <w.rf>
    <LM>w#w-d1t1511-6</LM>
   </w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1511-7">
   <w.rf>
    <LM>w#w-d1t1511-7</LM>
   </w.rf>
   <form>důchodem</form>
   <lemma>důchod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m019-d1t1511-3">
   <w.rf>
    <LM>w#w-d1t1511-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1511-4">
   <w.rf>
    <LM>w#w-d1t1511-4</LM>
   </w.rf>
   <form>dělávala</form>
   <lemma>dělávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1513-1">
   <w.rf>
    <LM>w#w-d1t1513-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1513-2">
   <w.rf>
    <LM>w#w-d1t1513-2</LM>
   </w.rf>
   <form>novinovém</form>
   <lemma>novinový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m019-d1t1513-3">
   <w.rf>
    <LM>w#w-d1t1513-3</LM>
   </w.rf>
   <form>stánku</form>
   <lemma>stánek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m019-d1t1516-1">
   <w.rf>
    <LM>w#w-d1t1516-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1516-2">
   <w.rf>
    <LM>w#w-d1t1516-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1516-3">
   <w.rf>
    <LM>w#w-d1t1516-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1516-4">
   <w.rf>
    <LM>w#w-d1t1516-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1516-5">
   <w.rf>
    <LM>w#w-d1t1516-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1516-6">
   <w.rf>
    <LM>w#w-d1t1516-6</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1516-7">
   <w.rf>
    <LM>w#w-d1t1516-7</LM>
   </w.rf>
   <form>šťastná</form>
   <lemma>šťastný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m019-d-m-d1e1502-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1502-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1517-x2">
  <m id="m019-d1t1524-1">
   <w.rf>
    <LM>w#w-d1t1524-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1524-2">
   <w.rf>
    <LM>w#w-d1t1524-2</LM>
   </w.rf>
   <form>kým</form>
   <lemma>kdo</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m019-d1t1524-3">
   <w.rf>
    <LM>w#w-d1t1524-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m019-d1t1524-5">
   <w.rf>
    <LM>w#w-d1t1524-5</LM>
   </w.rf>
   <form>vašich</form>
   <lemma>váš</lemma>
   <tag>PSXP2-P2-------</tag>
  </m>
  <m id="m019-d1t1524-6">
   <w.rf>
    <LM>w#w-d1t1524-6</LM>
   </w.rf>
   <form>kolegů</form>
   <lemma>kolega</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m019-d1t1524-7">
   <w.rf>
    <LM>w#w-d1t1524-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m019-d1t1524-8">
   <w.rf>
    <LM>w#w-d1t1524-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1524-9">
   <w.rf>
    <LM>w#w-d1t1524-9</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m019-d1t1524-10">
   <w.rf>
    <LM>w#w-d1t1524-10</LM>
   </w.rf>
   <form>přátelila</form>
   <lemma>přátelit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d-id97126-punct">
   <w.rf>
    <LM>w#w-d-id97126-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1525-x2">
  <m id="m019-d1t1530-1">
   <w.rf>
    <LM>w#w-d1t1530-1</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m019-d1t1530-2">
   <w.rf>
    <LM>w#w-d1t1530-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1530-3">
   <w.rf>
    <LM>w#w-d1t1530-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1530-5">
   <w.rf>
    <LM>w#w-d1t1530-5</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m019-d1t1530-4">
   <w.rf>
    <LM>w#w-d1t1530-4</LM>
   </w.rf>
   <form>nejvěrnější</form>
   <lemma>věrný</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m019-d1t1530-6">
   <w.rf>
    <LM>w#w-d1t1530-6</LM>
   </w.rf>
   <form>kamarádka</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d1e1525-x2-700">
   <w.rf>
    <LM>w#w-d1e1525-x2-700</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-702">
  <m id="m019-d1t1534-3">
   <w.rf>
    <LM>w#w-d1t1534-3</LM>
   </w.rf>
   <form>Bývala</form>
   <lemma>bývat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1534-2">
   <w.rf>
    <LM>w#w-d1t1534-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m019-d1t1534-4">
   <w.rf>
    <LM>w#w-d1t1534-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1534-5">
   <w.rf>
    <LM>w#w-d1t1534-5</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m019-d1t1534-6">
   <w.rf>
    <LM>w#w-d1t1534-6</LM>
   </w.rf>
   <form>dýchala</form>
   <lemma>dýchat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-702-233">
   <w.rf>
    <LM>w#w-702-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-234">
  <m id="m019-d1t1534-10">
   <w.rf>
    <LM>w#w-d1t1534-10</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1534-9">
   <w.rf>
    <LM>w#w-d1t1534-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1534-11">
   <w.rf>
    <LM>w#w-d1t1534-11</LM>
   </w.rf>
   <form>zradila</form>
   <lemma>zradit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-702-704">
   <w.rf>
    <LM>w#w-702-704</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1536-4">
   <w.rf>
    <LM>w#w-d1t1536-4</LM>
   </w.rf>
   <form>bolí</form>
   <lemma>bolet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1536-3">
   <w.rf>
    <LM>w#w-d1t1536-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1536-2">
   <w.rf>
    <LM>w#w-d1t1536-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1536-5">
   <w.rf>
    <LM>w#w-d1t1536-5</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d-m-d1e1525-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1525-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1537-x2">
  <m id="m019-d1t1540-1">
   <w.rf>
    <LM>w#w-d1t1540-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1540-2">
   <w.rf>
    <LM>w#w-d1t1540-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1540-3">
   <w.rf>
    <LM>w#w-d1t1540-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m019-d-id97736-punct">
   <w.rf>
    <LM>w#w-d-id97736-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1541-x2">
  <m id="m019-d1t1544-3">
   <w.rf>
    <LM>w#w-d1t1544-3</LM>
   </w.rf>
   <form>Králová</form>
   <lemma>Králová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1541-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1541-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1546-x2">
  <m id="m019-d1t1551-1">
   <w.rf>
    <LM>w#w-d1t1551-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m019-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m019-d1t1551-3">
   <w.rf>
    <LM>w#w-d1t1551-3</LM>
   </w.rf>
   <form>udělala</form>
   <lemma>udělat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d-id97949-punct">
   <w.rf>
    <LM>w#w-d-id97949-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1556-x2">
  <m id="m019-d1t1561-5">
   <w.rf>
    <LM>w#w-d1t1561-5</LM>
   </w.rf>
   <form>Pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d1t1561-3">
   <w.rf>
    <LM>w#w-d1t1561-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1561-4">
   <w.rf>
    <LM>w#w-d1t1561-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m019-d1t1561-6">
   <w.rf>
    <LM>w#w-d1t1561-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1561-7">
   <w.rf>
    <LM>w#w-d1t1561-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m019-d1t1561-8">
   <w.rf>
    <LM>w#w-d1t1561-8</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--3----------</tag>
  </m>
  <m id="m019-d1e1556-x2-720">
   <w.rf>
    <LM>w#w-d1e1556-x2-720</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1559-5">
   <w.rf>
    <LM>w#w-d1t1559-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1559-6">
   <w.rf>
    <LM>w#w-d1t1559-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m019-d1t1559-7">
   <w.rf>
    <LM>w#w-d1t1559-7</LM>
   </w.rf>
   <form>operaci</form>
   <lemma>operace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d1t1559-3">
   <w.rf>
    <LM>w#w-d1t1559-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1559-8">
   <w.rf>
    <LM>w#w-d1t1559-8</LM>
   </w.rf>
   <form>připravila</form>
   <lemma>připravit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d1t1559-9">
   <w.rf>
    <LM>w#w-d1t1559-9</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1559-11">
   <w.rf>
    <LM>w#w-d1t1559-11</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSNS4-S1-------</tag>
  </m>
  <m id="m019-d1t1559-12">
   <w.rf>
    <LM>w#w-d1t1559-12</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1556-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1556-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1562-x2">
  <m id="m019-d1t1565-1">
   <w.rf>
    <LM>w#w-d1t1565-1</LM>
   </w.rf>
   <form>Jakto</form>
   <lemma>jakto_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d-id98418-punct">
   <w.rf>
    <LM>w#w-d-id98418-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1566-x2">
  <m id="m019-d1t1571-4">
   <w.rf>
    <LM>w#w-d1t1571-4</LM>
   </w.rf>
   <form>Přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d1t1571-3">
   <w.rf>
    <LM>w#w-d1t1571-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1571-5">
   <w.rf>
    <LM>w#w-d1t1571-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1571-6">
   <w.rf>
    <LM>w#w-d1t1571-6</LM>
   </w.rf>
   <form>uklízela</form>
   <lemma>uklízet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1e1566-x2-242">
   <w.rf>
    <LM>w#w-d1e1566-x2-242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-245">
  <m id="m019-d1t1585-3">
   <w.rf>
    <LM>w#w-d1t1585-3</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1581-3">
   <w.rf>
    <LM>w#w-d1t1581-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1585-1">
   <w.rf>
    <LM>w#w-d1t1585-1</LM>
   </w.rf>
   <form>panu</form>
   <lemma>pan</lemma>
   <tag>NNMS3-----A---1</tag>
  </m>
  <m id="m019-d1t1585-2">
   <w.rf>
    <LM>w#w-d1t1585-2</LM>
   </w.rf>
   <form>vedoucímu</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m019-d1e1566-x2-734">
   <w.rf>
    <LM>w#w-d1e1566-x2-734</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1e1566-x2-736">
   <w.rf>
    <LM>w#w-d1e1566-x2-736</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1585-5">
   <w.rf>
    <LM>w#w-d1t1585-5</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m019-d1t1585-6">
   <w.rf>
    <LM>w#w-d1t1585-6</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3------1</tag>
  </m>
  <m id="m019-d1t1585-9">
   <w.rf>
    <LM>w#w-d1t1585-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1585-10">
   <w.rf>
    <LM>w#w-d1t1585-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m019-d1t1585-11">
   <w.rf>
    <LM>w#w-d1t1585-11</LM>
   </w.rf>
   <form>uklízení</form>
   <lemma>uklízení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m019-d1t1585-7">
   <w.rf>
    <LM>w#w-d1t1585-7</LM>
   </w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d1e1566-x2-738">
   <w.rf>
    <LM>w#w-d1e1566-x2-738</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d-id98844-punct">
   <w.rf>
    <LM>w#w-d-id98844-punct</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-740">
  <m id="m019-d1t1587-7">
   <w.rf>
    <LM>w#w-d1t1587-7</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m019-d1t1587-4">
   <w.rf>
    <LM>w#w-d1t1587-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m019-d1t1587-5">
   <w.rf>
    <LM>w#w-d1t1587-5</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------6</tag>
  </m>
  <m id="m019-d1t1587-8">
   <w.rf>
    <LM>w#w-d1t1587-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m019-d1t1587-9">
   <w.rf>
    <LM>w#w-d1t1587-9</LM>
   </w.rf>
   <form>expedice</form>
   <lemma>expedice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m019-740-744">
   <w.rf>
    <LM>w#w-740-744</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1587-13">
   <w.rf>
    <LM>w#w-d1t1587-13</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1587-14">
   <w.rf>
    <LM>w#w-d1t1587-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1587-15">
   <w.rf>
    <LM>w#w-d1t1587-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1587-16">
   <w.rf>
    <LM>w#w-d1t1587-16</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m019-d1t1587-17">
   <w.rf>
    <LM>w#w-d1t1587-17</LM>
   </w.rf>
   <form>zvrtlo</form>
   <lemma>zvrtnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m019-740-742">
   <w.rf>
    <LM>w#w-740-742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-732">
  <m id="m019-d1t1589-1">
   <w.rf>
    <LM>w#w-d1t1589-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1589-3">
   <w.rf>
    <LM>w#w-d1t1589-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1589-4">
   <w.rf>
    <LM>w#w-d1t1589-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1589-2">
   <w.rf>
    <LM>w#w-d1t1589-2</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m019-d1t1589-6">
   <w.rf>
    <LM>w#w-d1t1589-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1589-7">
   <w.rf>
    <LM>w#w-d1t1589-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m019-d1t1589-5">
   <w.rf>
    <LM>w#w-d1t1589-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1589-8">
   <w.rf>
    <LM>w#w-d1t1589-8</LM>
   </w.rf>
   <form>mluvit</form>
   <lemma>mluvit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m019-d-m-d1e1582-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1582-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1590-x2">
  <m id="m019-d1t1593-2">
   <w.rf>
    <LM>w#w-d1t1593-2</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m019-d1t1593-3">
   <w.rf>
    <LM>w#w-d1t1593-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m019-d1t1593-4">
   <w.rf>
    <LM>w#w-d1t1593-4</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m019-d1t1593-5">
   <w.rf>
    <LM>w#w-d1t1593-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1593-6">
   <w.rf>
    <LM>w#w-d1t1593-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1593-7">
   <w.rf>
    <LM>w#w-d1t1593-7</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m019-d1t1593-8">
   <w.rf>
    <LM>w#w-d1t1593-8</LM>
   </w.rf>
   <form>nebavíte</form>
   <lemma>bavit</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m019-d-id99432-punct">
   <w.rf>
    <LM>w#w-d-id99432-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1594-x2">
  <m id="m019-d1t1597-1">
   <w.rf>
    <LM>w#w-d1t1597-1</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1597-2">
   <w.rf>
    <LM>w#w-d1t1597-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1597-3">
   <w.rf>
    <LM>w#w-d1t1597-3</LM>
   </w.rf>
   <form>pozdravíme</form>
   <lemma>pozdravit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m019-d1t1597-4">
   <w.rf>
    <LM>w#w-d1t1597-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1597-5">
   <w.rf>
    <LM>w#w-d1t1597-5</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1597-6">
   <w.rf>
    <LM>w#w-d1t1597-6</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m019-d1e1594-x2-750">
   <w.rf>
    <LM>w#w-d1e1594-x2-750</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-752">
  <m id="m019-d1t1601-4">
   <w.rf>
    <LM>w#w-d1t1601-4</LM>
   </w.rf>
   <form>Pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1601-5">
   <w.rf>
    <LM>w#w-d1t1601-5</LM>
   </w.rf>
   <form>pojmem</form>
   <lemma>pojem_^(termín,_označení,...)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m019-d1t1601-6">
   <w.rf>
    <LM>w#w-d1t1601-6</LM>
   </w.rf>
   <form>přátelství</form>
   <lemma>přátelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m019-d1t1601-2">
   <w.rf>
    <LM>w#w-d1t1601-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1601-3">
   <w.rf>
    <LM>w#w-d1t1601-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m019-d1t1603-1">
   <w.rf>
    <LM>w#w-d1t1603-1</LM>
   </w.rf>
   <form>představovala</form>
   <lemma>představovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1603-2">
   <w.rf>
    <LM>w#w-d1t1603-2</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1603-3">
   <w.rf>
    <LM>w#w-d1t1603-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m019-d1t1603-4">
   <w.rf>
    <LM>w#w-d1t1603-4</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m019-d-m-d1e1594-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1594-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1604-x2">
  <m id="m019-d1t1607-1">
   <w.rf>
    <LM>w#w-d1t1607-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1607-2">
   <w.rf>
    <LM>w#w-d1t1607-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1607-3">
   <w.rf>
    <LM>w#w-d1t1607-3</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m019-d-m-d1e1604-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1604-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1612-x2">
  <m id="m019-d1t1615-1">
   <w.rf>
    <LM>w#w-d1t1615-1</LM>
   </w.rf>
   <form>Sejdete</form>
   <lemma>sejít</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m019-d1t1615-2">
   <w.rf>
    <LM>w#w-d1t1615-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1615-3">
   <w.rf>
    <LM>w#w-d1t1615-3</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1615-4">
   <w.rf>
    <LM>w#w-d1t1615-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m019-d1t1615-5">
   <w.rf>
    <LM>w#w-d1t1615-5</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1615-6">
   <w.rf>
    <LM>w#w-d1t1615-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1615-7">
   <w.rf>
    <LM>w#w-d1t1615-7</LM>
   </w.rf>
   <form>bývalými</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m019-d1t1615-8">
   <w.rf>
    <LM>w#w-d1t1615-8</LM>
   </w.rf>
   <form>kolegy</form>
   <lemma>kolega</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m019-d-id100124-punct">
   <w.rf>
    <LM>w#w-d-id100124-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1617-x2">
  <m id="m019-d1t1620-4">
   <w.rf>
    <LM>w#w-d1t1620-4</LM>
   </w.rf>
   <form>Pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m019-d1t1620-5">
   <w.rf>
    <LM>w#w-d1t1620-5</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m019-d-id100303-punct">
   <w.rf>
    <LM>w#w-d-id100303-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1622-3">
   <w.rf>
    <LM>w#w-d1t1622-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1622-4">
   <w.rf>
    <LM>w#w-d1t1622-4</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m019-d1t1622-5">
   <w.rf>
    <LM>w#w-d1t1622-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1622-9">
   <w.rf>
    <LM>w#w-d1t1622-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m019-d1t1622-8">
   <w.rf>
    <LM>w#w-d1t1622-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1622-6">
   <w.rf>
    <LM>w#w-d1t1622-6</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m019-d1t1622-11">
   <w.rf>
    <LM>w#w-d1t1622-11</LM>
   </w.rf>
   <form>bavila</form>
   <lemma>bavit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d-id100444-punct">
   <w.rf>
    <LM>w#w-d-id100444-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1622-14">
   <w.rf>
    <LM>w#w-d1t1622-14</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m019-d1t1622-15">
   <w.rf>
    <LM>w#w-d1t1622-15</LM>
   </w.rf>
   <form>bezvadný</form>
   <lemma>bezvadný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m019-d1e1617-x2-255">
   <w.rf>
    <LM>w#w-d1e1617-x2-255</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-256">
  <m id="m019-d1t1624-2">
   <w.rf>
    <LM>w#w-d1t1624-2</LM>
   </w.rf>
   <form>Zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m019-d1t1624-3">
   <w.rf>
    <LM>w#w-d1t1624-3</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1624-4">
   <w.rf>
    <LM>w#w-d1t1624-4</LM>
   </w.rf>
   <form>měsícem</form>
   <lemma>měsíc</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m019-d1t1626-1">
   <w.rf>
    <LM>w#w-d1t1626-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1626-2">
   <w.rf>
    <LM>w#w-d1t1626-2</LM>
   </w.rf>
   <form>rakovinu</form>
   <lemma>rakovina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d1t1626-3">
   <w.rf>
    <LM>w#w-d1t1626-3</LM>
   </w.rf>
   <form>plic</form>
   <lemma>plíce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m019-d1e1617-x2-772">
   <w.rf>
    <LM>w#w-d1e1617-x2-772</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-774">
  <m id="m019-d1t1626-5">
   <w.rf>
    <LM>w#w-d1t1626-5</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1626-6">
   <w.rf>
    <LM>w#w-d1t1626-6</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m019-d1t1626-7">
   <w.rf>
    <LM>w#w-d1t1626-7</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m019-d1t1626-8">
   <w.rf>
    <LM>w#w-d1t1626-8</LM>
   </w.rf>
   <form>cigaretu</form>
   <lemma>cigareta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m019-d1t1626-9">
   <w.rf>
    <LM>w#w-d1t1626-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1626-10">
   <w.rf>
    <LM>w#w-d1t1626-10</LM>
   </w.rf>
   <form>puse</form>
   <lemma>pusa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d-id100733-punct">
   <w.rf>
    <LM>w#w-d-id100733-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1628-3">
   <w.rf>
    <LM>w#w-d1t1628-3</LM>
   </w.rf>
   <form>veselý</form>
   <lemma>veselý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m019-d1t1628-4">
   <w.rf>
    <LM>w#w-d1t1628-4</LM>
   </w.rf>
   <form>chlapec</form>
   <lemma>chlapec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m019-d1t1628-6">
   <w.rf>
    <LM>w#w-d1t1628-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1628-7">
   <w.rf>
    <LM>w#w-d1t1628-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1628-8">
   <w.rf>
    <LM>w#w-d1t1628-8</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d-m-d1e1617-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1617-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1629-x2">
  <m id="m019-d1t1632-1">
   <w.rf>
    <LM>w#w-d1t1632-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1632-2">
   <w.rf>
    <LM>w#w-d1t1632-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1632-3">
   <w.rf>
    <LM>w#w-d1t1632-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1632-4">
   <w.rf>
    <LM>w#w-d1t1632-4</LM>
   </w.rf>
   <form>bývá</form>
   <lemma>bývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d-m-d1e1629-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1629-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1633-x2">
  <m id="m019-d1t1638-1">
   <w.rf>
    <LM>w#w-d1t1638-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m019-d1t1638-2">
   <w.rf>
    <LM>w#w-d1t1638-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m019-d1t1638-3">
   <w.rf>
    <LM>w#w-d1t1638-3</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d-m-d1e1633-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1633-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1639-x2">
  <m id="m019-d1t1642-1">
   <w.rf>
    <LM>w#w-d1t1642-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m019-d1t1642-2">
   <w.rf>
    <LM>w#w-d1t1642-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m019-d1t1642-3">
   <w.rf>
    <LM>w#w-d1t1642-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1642-4">
   <w.rf>
    <LM>w#w-d1t1642-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m019-d1t1642-5">
   <w.rf>
    <LM>w#w-d1t1642-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1642-6">
   <w.rf>
    <LM>w#w-d1t1642-6</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m019-d1t1642-7">
   <w.rf>
    <LM>w#w-d1t1642-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d-id101253-punct">
   <w.rf>
    <LM>w#w-d-id101253-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-20_2">
  <m id="m019-d1t1648-6">
   <w.rf>
    <LM>w#w-d1t1648-6</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1648-4">
   <w.rf>
    <LM>w#w-d1t1648-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1648-5">
   <w.rf>
    <LM>w#w-d1t1648-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1648-14">
   <w.rf>
    <LM>w#w-d1t1648-14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1648-15">
   <w.rf>
    <LM>w#w-d1t1648-15</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m019-d1t1648-8">
   <w.rf>
    <LM>w#w-d1t1648-8</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m019-d1t1648-9">
   <w.rf>
    <LM>w#w-d1t1648-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m019-d1t1648-11">
   <w.rf>
    <LM>w#w-d1t1648-11</LM>
   </w.rf>
   <form>styku</form>
   <lemma>styk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m019-20_2-274">
   <w.rf>
    <LM>w#w-20_2-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-275">
  <m id="m019-d1t1652-1">
   <w.rf>
    <LM>w#w-d1t1652-1</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1652-2">
   <w.rf>
    <LM>w#w-d1t1652-2</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d-id101564-punct">
   <w.rf>
    <LM>w#w-d-id101564-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1652-6">
   <w.rf>
    <LM>w#w-d1t1652-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1652-7">
   <w.rf>
    <LM>w#w-d1t1652-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m019-d1t1652-8">
   <w.rf>
    <LM>w#w-d1t1652-8</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m019-d1t1652-9">
   <w.rf>
    <LM>w#w-d1t1652-9</LM>
   </w.rf>
   <form>dodala</form>
   <lemma>dodat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d-id101653-punct">
   <w.rf>
    <LM>w#w-d-id101653-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1652-11">
   <w.rf>
    <LM>w#w-d1t1652-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m019-d1t1652-20">
   <w.rf>
    <LM>w#w-d1t1652-20</LM>
   </w.rf>
   <form>kamarádka</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m019-d-id101692-punct">
   <w.rf>
    <LM>w#w-d-id101692-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1652-14">
   <w.rf>
    <LM>w#w-d1t1652-14</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m019-d1t1652-15">
   <w.rf>
    <LM>w#w-d1t1652-15</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m019-d1t1652-16">
   <w.rf>
    <LM>w#w-d1t1652-16</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1652-17">
   <w.rf>
    <LM>w#w-d1t1652-17</LM>
   </w.rf>
   <form>ublížila</form>
   <lemma>ublížit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m019-d-id101763-punct">
   <w.rf>
    <LM>w#w-d-id101763-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1654-3">
   <w.rf>
    <LM>w#w-d1t1654-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1654-4">
   <w.rf>
    <LM>w#w-d1t1654-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1654-5">
   <w.rf>
    <LM>w#w-d1t1654-5</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1654-6">
   <w.rf>
    <LM>w#w-d1t1654-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1654-8">
   <w.rf>
    <LM>w#w-d1t1654-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d1t1654-9">
   <w.rf>
    <LM>w#w-d1t1654-9</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m019-d1t1654-10">
   <w.rf>
    <LM>w#w-d1t1654-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1654-11">
   <w.rf>
    <LM>w#w-d1t1654-11</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m019-d1t1654-12">
   <w.rf>
    <LM>w#w-d1t1654-12</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m019-d1t1654-13">
   <w.rf>
    <LM>w#w-d1t1654-13</LM>
   </w.rf>
   <form>vyhodil</form>
   <lemma>vyhodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m019-20-24">
   <w.rf>
    <LM>w#w-20-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-26">
  <m id="m019-d1t1657-4">
   <w.rf>
    <LM>w#w-d1t1657-4</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m019-d1t1657-5">
   <w.rf>
    <LM>w#w-d1t1657-5</LM>
   </w.rf>
   <form>nevyhodil</form>
   <lemma>vyhodit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m019-d-id102104-punct">
   <w.rf>
    <LM>w#w-d-id102104-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m019-d1t1657-9">
   <w.rf>
    <LM>w#w-d1t1657-9</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1657-8">
   <w.rf>
    <LM>w#w-d1t1657-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1657-10">
   <w.rf>
    <LM>w#w-d1t1657-10</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m019-d-m-d1e1643-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1643-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1658-x2">
  <m id="m019-d1t1663-1">
   <w.rf>
    <LM>w#w-d1t1663-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m019-d-id102247-punct">
   <w.rf>
    <LM>w#w-d-id102247-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m019-d1e1658-x4">
  <m id="m019-d1t1669-4">
   <w.rf>
    <LM>w#w-d1t1669-4</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m019-d1t1669-5">
   <w.rf>
    <LM>w#w-d1t1669-5</LM>
   </w.rf>
   <form>prvé</form>
   <lemma>prvý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m019-d1t1669-6">
   <w.rf>
    <LM>w#w-d1t1669-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1669-7">
   <w.rf>
    <LM>w#w-d1t1669-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m019-d1t1669-8">
   <w.rf>
    <LM>w#w-d1t1669-8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m019-d1t1669-10">
   <w.rf>
    <LM>w#w-d1t1669-10</LM>
   </w.rf>
   <form>operaci</form>
   <lemma>operace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m019-d1t1671-1">
   <w.rf>
    <LM>w#w-d1t1671-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m019-d1t1671-2">
   <w.rf>
    <LM>w#w-d1t1671-2</LM>
   </w.rf>
   <form>nervově</form>
   <lemma>nervově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m019-d1t1671-3">
   <w.rf>
    <LM>w#w-d1t1671-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m019-d1t1671-4">
   <w.rf>
    <LM>w#w-d1t1671-4</LM>
   </w.rf>
   <form>nesnesla</form>
   <lemma>snést</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m019-d1t1671-5">
   <w.rf>
    <LM>w#w-d1t1671-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m019-d1t1671-6">
   <w.rf>
    <LM>w#w-d1t1671-6</LM>
   </w.rf>
   <form>napětí</form>
   <lemma>napětí_^(elektrické,_mechanické,_ve_vztazích)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m019-d1t1671-7">
   <w.rf>
    <LM>w#w-d1t1671-7</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m019-d1t1671-8">
   <w.rf>
    <LM>w#w-d1t1671-8</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m019-d1t1671-9">
   <w.rf>
    <LM>w#w-d1t1671-9</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m019-d1e1658-x4-280">
   <w.rf>
    <LM>w#w-d1e1658-x4-280</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
