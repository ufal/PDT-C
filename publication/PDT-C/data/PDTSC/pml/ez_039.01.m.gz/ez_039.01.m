<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_039.01.w.gz" />
  </references>
 </head>
 <s id="m039-173">
  <m id="m039-173-268">
   <w.rf>
    <LM>w#w-173-268</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-173-267">
   <w.rf>
    <LM>w#w-173-267</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m039-173-266">
   <w.rf>
    <LM>w#w-173-266</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-173-265">
   <w.rf>
    <LM>w#w-173-265</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-173-264">
   <w.rf>
    <LM>w#w-173-264</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m039-173-263">
   <w.rf>
    <LM>w#w-173-263</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m039-173-262">
   <w.rf>
    <LM>w#w-173-262</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m039-173-261">
   <w.rf>
    <LM>w#w-173-261</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m039-173-260">
   <w.rf>
    <LM>w#w-173-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e383-x2">
  <m id="m039-d1t386-1">
   <w.rf>
    <LM>w#w-d1t386-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t386-2">
   <w.rf>
    <LM>w#w-d1t386-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t386-3">
   <w.rf>
    <LM>w#w-d1t386-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m039-d1t386-4">
   <w.rf>
    <LM>w#w-d1t386-4</LM>
   </w.rf>
   <form>poznávací</form>
   <lemma>poznávací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m039-d1t386-5">
   <w.rf>
    <LM>w#w-d1t386-5</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-d-id64824-punct">
   <w.rf>
    <LM>w#w-d-id64824-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e388-x2">
  <m id="m039-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1e388-x2-175">
   <w.rf>
    <LM>w#w-d1e388-x2-175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>poznávací</form>
   <lemma>poznávací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m039-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-d-m-d1e388-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e388-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e398-x2">
  <m id="m039-d1t401-1">
   <w.rf>
    <LM>w#w-d1t401-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m039-d1t401-2">
   <w.rf>
    <LM>w#w-d1t401-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t401-3">
   <w.rf>
    <LM>w#w-d1t401-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m039-d1t401-4">
   <w.rf>
    <LM>w#w-d1t401-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t401-5">
   <w.rf>
    <LM>w#w-d1t401-5</LM>
   </w.rf>
   <form>nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m039-d1t401-6">
   <w.rf>
    <LM>w#w-d1t401-6</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d-id65078-punct">
   <w.rf>
    <LM>w#w-d-id65078-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e402-x2">
  <m id="m039-d1e402-x2-322">
   <w.rf>
    <LM>w#w-d1e402-x2-322</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1e402-x2-321">
   <w.rf>
    <LM>w#w-d1e402-x2-321</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-320">
   <w.rf>
    <LM>w#w-d1e402-x2-320</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-319">
   <w.rf>
    <LM>w#w-d1e402-x2-319</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1e402-x2-290">
   <w.rf>
    <LM>w#w-d1e402-x2-290</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1e402-x2-318">
   <w.rf>
    <LM>w#w-d1e402-x2-318</LM>
   </w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m039-d1e402-x2-317">
   <w.rf>
    <LM>w#w-d1e402-x2-317</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-316">
   <w.rf>
    <LM>w#w-d1e402-x2-316</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-315">
   <w.rf>
    <LM>w#w-d1e402-x2-315</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1e402-x2-314">
   <w.rf>
    <LM>w#w-d1e402-x2-314</LM>
   </w.rf>
   <form>Modré</form>
   <lemma>modrý_;o</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m039-d1e402-x2-313">
   <w.rf>
    <LM>w#w-d1e402-x2-313</LM>
   </w.rf>
   <form>mešity</form>
   <lemma>mešita</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-312">
   <w.rf>
    <LM>w#w-d1e402-x2-312</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1e402-x2-311">
   <w.rf>
    <LM>w#w-d1e402-x2-311</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1e402-x2-310">
   <w.rf>
    <LM>w#w-d1e402-x2-310</LM>
   </w.rf>
   <form>bazaru</form>
   <lemma>bazar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-309">
   <w.rf>
    <LM>w#w-d1e402-x2-309</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1e402-x2-308">
   <w.rf>
    <LM>w#w-d1e402-x2-308</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1e402-x2-307">
   <w.rf>
    <LM>w#w-d1e402-x2-307</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1e402-x2-306">
   <w.rf>
    <LM>w#w-d1e402-x2-306</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-305">
   <w.rf>
    <LM>w#w-d1e402-x2-305</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1e402-x2-304">
   <w.rf>
    <LM>w#w-d1e402-x2-304</LM>
   </w.rf>
   <form>zastavila</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m039-d1e402-x2-303">
   <w.rf>
    <LM>w#w-d1e402-x2-303</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1e402-x2-302">
   <w.rf>
    <LM>w#w-d1e402-x2-302</LM>
   </w.rf>
   <form>výlohy</form>
   <lemma>výloha_^(v_obchodě,_reklamní,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-301">
   <w.rf>
    <LM>w#w-d1e402-x2-301</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1e402-x2-300">
   <w.rf>
    <LM>w#w-d1e402-x2-300</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1e402-x2-299">
   <w.rf>
    <LM>w#w-d1e402-x2-299</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m039-d1e402-x2-298">
   <w.rf>
    <LM>w#w-d1e402-x2-298</LM>
   </w.rf>
   <form>obchodníci</form>
   <lemma>obchodník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-297">
   <w.rf>
    <LM>w#w-d1e402-x2-297</LM>
   </w.rf>
   <form>tahali</form>
   <lemma>tahat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-296">
   <w.rf>
    <LM>w#w-d1e402-x2-296</LM>
   </w.rf>
   <form>dovnitř</form>
   <lemma>dovnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1e402-x2-295">
   <w.rf>
    <LM>w#w-d1e402-x2-295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1e402-x2-294">
   <w.rf>
    <LM>w#w-d1e402-x2-294</LM>
   </w.rf>
   <form>nabízeli</form>
   <lemma>nabízet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1e402-x2-293">
   <w.rf>
    <LM>w#w-d1e402-x2-293</LM>
   </w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m039-d1e402-x2-292">
   <w.rf>
    <LM>w#w-d1e402-x2-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-206">
  <m id="m039-d1t422-4">
   <w.rf>
    <LM>w#w-d1t422-4</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m039-d1t422-3">
   <w.rf>
    <LM>w#w-d1t422-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-206-291">
   <w.rf>
    <LM>w#w-206-291</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t424-4">
   <w.rf>
    <LM>w#w-d1t424-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t424-5">
   <w.rf>
    <LM>w#w-d1t424-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m039-d1t424-9">
   <w.rf>
    <LM>w#w-d1t424-9</LM>
   </w.rf>
   <form>obchody</form>
   <lemma>obchod</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m039-d1t424-7">
   <w.rf>
    <LM>w#w-d1t424-7</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-206-218">
   <w.rf>
    <LM>w#w-206-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-219">
  <m id="m039-d1t431-2">
   <w.rf>
    <LM>w#w-d1t431-2</LM>
   </w.rf>
   <form>Zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m039-d1t431-4">
   <w.rf>
    <LM>w#w-d1t431-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m039-d1t431-5">
   <w.rf>
    <LM>w#w-d1t431-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t431-6">
   <w.rf>
    <LM>w#w-d1t431-6</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t431-8">
   <w.rf>
    <LM>w#w-d1t431-8</LM>
   </w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m039-d1t431-9">
   <w.rf>
    <LM>w#w-d1t431-9</LM>
   </w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m039-219-6">
   <w.rf>
    <LM>w#w-219-6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t431-11">
   <w.rf>
    <LM>w#w-d1t431-11</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m039-d1t431-16">
   <w.rf>
    <LM>w#w-d1t431-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t431-12">
   <w.rf>
    <LM>w#w-d1t431-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t431-14">
   <w.rf>
    <LM>w#w-d1t431-14</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t431-13">
   <w.rf>
    <LM>w#w-d1t431-13</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t431-15">
   <w.rf>
    <LM>w#w-d1t431-15</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-219-367">
   <w.rf>
    <LM>w#w-219-367</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-366">
  <m id="m039-d1t435-3">
   <w.rf>
    <LM>w#w-d1t435-3</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t435-4">
   <w.rf>
    <LM>w#w-d1t435-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m039-d1t435-5">
   <w.rf>
    <LM>w#w-d1t435-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t431-18">
   <w.rf>
    <LM>w#w-d1t431-18</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t435-7">
   <w.rf>
    <LM>w#w-d1t435-7</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t435-6">
   <w.rf>
    <LM>w#w-d1t435-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t435-8">
   <w.rf>
    <LM>w#w-d1t435-8</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m039-d1t435-9">
   <w.rf>
    <LM>w#w-d1t435-9</LM>
   </w.rf>
   <form>překvapení</form>
   <lemma>překvapení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m039-d1e402-x3-7">
   <w.rf>
    <LM>w#w-d1e402-x3-7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t435-11">
   <w.rf>
    <LM>w#w-d1t435-11</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t435-12">
   <w.rf>
    <LM>w#w-d1t435-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t435-13">
   <w.rf>
    <LM>w#w-d1t435-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t437-1">
   <w.rf>
    <LM>w#w-d1t437-1</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1t437-2">
   <w.rf>
    <LM>w#w-d1t437-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t437-4">
   <w.rf>
    <LM>w#w-d1t437-4</LM>
   </w.rf>
   <form>devadesátém</form>
   <lemma>devadesátý</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m039-d1t437-5">
   <w.rf>
    <LM>w#w-d1t437-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m039-d1t437-6">
   <w.rf>
    <LM>w#w-d1t437-6</LM>
   </w.rf>
   <form>minulého</form>
   <lemma>minulý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m039-d1t437-7">
   <w.rf>
    <LM>w#w-d1t437-7</LM>
   </w.rf>
   <form>století</form>
   <lemma>století</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m039-366-368">
   <w.rf>
    <LM>w#w-366-368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e438-x2">
  <m id="m039-d1t443-1">
   <w.rf>
    <LM>w#w-d1t443-1</LM>
   </w.rf>
   <form>Jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m039-d1t443-2">
   <w.rf>
    <LM>w#w-d1t443-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m039-d1t443-3">
   <w.rf>
    <LM>w#w-d1t443-3</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t443-4">
   <w.rf>
    <LM>w#w-d1t443-4</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m039-d-id66734-punct">
   <w.rf>
    <LM>w#w-d-id66734-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e444-x2">
  <m id="m039-d1t449-1">
   <w.rf>
    <LM>w#w-d1t449-1</LM>
   </w.rf>
   <form>Cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t449-2">
   <w.rf>
    <LM>w#w-d1t449-2</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m039-d1t449-3">
   <w.rf>
    <LM>w#w-d1t449-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m039-d1t449-5">
   <w.rf>
    <LM>w#w-d1t449-5</LM>
   </w.rf>
   <form>výborná</form>
   <lemma>výborný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m039-d1e444-x2-17">
   <w.rf>
    <LM>w#w-d1e444-x2-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-18">
  <m id="m039-d1t449-9">
   <w.rf>
    <LM>w#w-d1t449-9</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t449-8">
   <w.rf>
    <LM>w#w-d1t449-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t453-1">
   <w.rf>
    <LM>w#w-d1t453-1</LM>
   </w.rf>
   <form>spoluzaměstnanci</form>
   <lemma>spoluzaměstnanec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m039-d1t453-2">
   <w.rf>
    <LM>w#w-d1t453-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t453-3">
   <w.rf>
    <LM>w#w-d1t453-3</LM>
   </w.rf>
   <form>manželkami</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m039-18-19">
   <w.rf>
    <LM>w#w-18-19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t460-3">
   <w.rf>
    <LM>w#w-d1t460-3</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m039-d1t460-1">
   <w.rf>
    <LM>w#w-d1t460-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t460-2">
   <w.rf>
    <LM>w#w-d1t460-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t460-4">
   <w.rf>
    <LM>w#w-d1t460-4</LM>
   </w.rf>
   <form>znali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d-id67027-punct">
   <w.rf>
    <LM>w#w-d-id67027-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t453-5">
   <w.rf>
    <LM>w#w-d1t453-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t455-1">
   <w.rf>
    <LM>w#w-d1t455-1</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t455-2">
   <w.rf>
    <LM>w#w-d1t455-2</LM>
   </w.rf>
   <form>utíkala</form>
   <lemma>utíkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m039-18-381">
   <w.rf>
    <LM>w#w-18-381</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t460-7">
   <w.rf>
    <LM>w#w-d1t460-7</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m039-d1t460-8">
   <w.rf>
    <LM>w#w-d1t460-8</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWIP1----------</tag>
  </m>
  <m id="m039-d1t460-9">
   <w.rf>
    <LM>w#w-d1t460-9</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m039-18-20">
   <w.rf>
    <LM>w#w-18-20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e461-x2">
  <m id="m039-d1t464-1">
   <w.rf>
    <LM>w#w-d1t464-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t464-2">
   <w.rf>
    <LM>w#w-d1t464-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1t464-3">
   <w.rf>
    <LM>w#w-d1t464-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t464-4">
   <w.rf>
    <LM>w#w-d1t464-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t464-5">
   <w.rf>
    <LM>w#w-d1t464-5</LM>
   </w.rf>
   <form>jede</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d-id67412-punct">
   <w.rf>
    <LM>w#w-d-id67412-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e465-x2">
  <m id="m039-d1t470-1">
   <w.rf>
    <LM>w#w-d1t470-1</LM>
   </w.rf>
   <form>Jelo</form>
   <lemma>jet-1</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t470-2">
   <w.rf>
    <LM>w#w-d1t470-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t470-3">
   <w.rf>
    <LM>w#w-d1t470-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t472-6">
   <w.rf>
    <LM>w#w-d1t472-6</LM>
   </w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m039-d1t472-7">
   <w.rf>
    <LM>w#w-d1t472-7</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t472-8">
   <w.rf>
    <LM>w#w-d1t472-8</LM>
   </w.rf>
   <form>čtyřicet</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m039-d1t472-9">
   <w.rf>
    <LM>w#w-d1t472-9</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m039-d-m-d1e465-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e465-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e475-x2">
  <m id="m039-d1t480-1">
   <w.rf>
    <LM>w#w-d1t480-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t480-2">
   <w.rf>
    <LM>w#w-d1t480-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t480-5">
   <w.rf>
    <LM>w#w-d1t480-5</LM>
   </w.rf>
   <form>lehátkové</form>
   <lemma>lehátkový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m039-d1t480-6">
   <w.rf>
    <LM>w#w-d1t480-6</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m039-d-id67849-punct">
   <w.rf>
    <LM>w#w-d-id67849-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t480-8">
   <w.rf>
    <LM>w#w-d1t480-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t480-9">
   <w.rf>
    <LM>w#w-d1t480-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t480-10">
   <w.rf>
    <LM>w#w-d1t480-10</LM>
   </w.rf>
   <form>spalo</form>
   <lemma>spát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d-m-d1e475-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e475-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e485-x2">
  <m id="m039-d1t490-2">
   <w.rf>
    <LM>w#w-d1t490-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t490-3">
   <w.rf>
    <LM>w#w-d1t490-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t490-4">
   <w.rf>
    <LM>w#w-d1t490-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1t490-5">
   <w.rf>
    <LM>w#w-d1t490-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t490-6">
   <w.rf>
    <LM>w#w-d1t490-6</LM>
   </w.rf>
   <form>občerstvením</form>
   <lemma>občerstvení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m039-d1t490-7">
   <w.rf>
    <LM>w#w-d1t490-7</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m039-d1t490-8">
   <w.rf>
    <LM>w#w-d1t490-8</LM>
   </w.rf>
   <form>vlaku</form>
   <lemma>vlak</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m039-d1e485-x2-35">
   <w.rf>
    <LM>w#w-d1e485-x2-35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-36">
  <m id="m039-d1t492-1">
   <w.rf>
    <LM>w#w-d1t492-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t492-2">
   <w.rf>
    <LM>w#w-d1t492-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m039-d-m-d1e485-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e485-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e493-x2">
  <m id="m039-d1t496-1">
   <w.rf>
    <LM>w#w-d1t496-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t496-2">
   <w.rf>
    <LM>w#w-d1t496-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t496-3">
   <w.rf>
    <LM>w#w-d1t496-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m039-d1e493-x2-37">
   <w.rf>
    <LM>w#w-d1e493-x2-37</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-38">
  <m id="m039-d1t496-4">
   <w.rf>
    <LM>w#w-d1t496-4</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t496-5">
   <w.rf>
    <LM>w#w-d1t496-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m039-d1t496-6">
   <w.rf>
    <LM>w#w-d1t496-6</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1t496-7">
   <w.rf>
    <LM>w#w-d1t496-7</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t496-8">
   <w.rf>
    <LM>w#w-d1t496-8</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m039-d-id68366-punct">
   <w.rf>
    <LM>w#w-d-id68366-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e497-x2">
  <m id="m039-d1t502-4">
   <w.rf>
    <LM>w#w-d1t502-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t502-3">
   <w.rf>
    <LM>w#w-d1t502-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t502-5">
   <w.rf>
    <LM>w#w-d1t502-5</LM>
   </w.rf>
   <form>železničáři</form>
   <lemma>železničář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m039-d-id68508-punct">
   <w.rf>
    <LM>w#w-d-id68508-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t502-7">
   <w.rf>
    <LM>w#w-d1t502-7</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t502-8">
   <w.rf>
    <LM>w#w-d1t502-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t502-10">
   <w.rf>
    <LM>w#w-d1t502-10</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t502-11">
   <w.rf>
    <LM>w#w-d1t502-11</LM>
   </w.rf>
   <form>zadarmo</form>
   <lemma>zadarmo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d-m-d1e497-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e497-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e515-x2">
  <m id="m039-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>Cestujete</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m039-d1t518-2">
   <w.rf>
    <LM>w#w-d1t518-2</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t518-3">
   <w.rf>
    <LM>w#w-d1t518-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d-id68750-punct">
   <w.rf>
    <LM>w#w-d-id68750-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e519-x2">
  <m id="m039-d1t524-1">
   <w.rf>
    <LM>w#w-d1t524-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1e519-x2-59">
   <w.rf>
    <LM>w#w-d1e519-x2-59</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t524-2">
   <w.rf>
    <LM>w#w-d1t524-2</LM>
   </w.rf>
   <form>cestujeme</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t524-3">
   <w.rf>
    <LM>w#w-d1t524-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t524-4">
   <w.rf>
    <LM>w#w-d1t524-4</LM>
   </w.rf>
   <form>manželkou</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m039-d1t524-5">
   <w.rf>
    <LM>w#w-d1t524-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1e519-x2-63">
   <w.rf>
    <LM>w#w-d1e519-x2-63</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-64">
  <m id="m039-d1t524-9">
   <w.rf>
    <LM>w#w-d1t524-9</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t526-1">
   <w.rf>
    <LM>w#w-d1t526-1</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m039-d1t524-7">
   <w.rf>
    <LM>w#w-d1t524-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t528-1">
   <w.rf>
    <LM>w#w-d1t528-1</LM>
   </w.rf>
   <form>nebaví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m039-d1t528-2">
   <w.rf>
    <LM>w#w-d1t528-2</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m039-d1t528-3">
   <w.rf>
    <LM>w#w-d1t528-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t528-4">
   <w.rf>
    <LM>w#w-d1t528-4</LM>
   </w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m039-64-398">
   <w.rf>
    <LM>w#w-64-398</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t528-6">
   <w.rf>
    <LM>w#w-d1t528-6</LM>
   </w.rf>
   <form>cestujeme</form>
   <lemma>cestovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-64-313">
   <w.rf>
    <LM>w#w-64-313</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t530-1">
   <w.rf>
    <LM>w#w-d1t530-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t530-2">
   <w.rf>
    <LM>w#w-d1t530-2</LM>
   </w.rf>
   <form>vnitrozemí</form>
   <lemma>vnitrozemí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m039-d1e519-x2-60">
   <w.rf>
    <LM>w#w-d1e519-x2-60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-61">
  <m id="m039-d1t537-1">
   <w.rf>
    <LM>w#w-d1t537-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t537-2">
   <w.rf>
    <LM>w#w-d1t537-2</LM>
   </w.rf>
   <form>únoru</form>
   <lemma>únor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m039-d1t535-3">
   <w.rf>
    <LM>w#w-d1t535-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t535-4">
   <w.rf>
    <LM>w#w-d1t535-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t537-3">
   <w.rf>
    <LM>w#w-d1t537-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t537-4">
   <w.rf>
    <LM>w#w-d1t537-4</LM>
   </w.rf>
   <form>seniorském</form>
   <lemma>seniorský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m039-d1t537-5">
   <w.rf>
    <LM>w#w-d1t537-5</LM>
   </w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m039-d1t539-5">
   <w.rf>
    <LM>w#w-d1t539-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t539-6">
   <w.rf>
    <LM>w#w-d1t539-6</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m039-d1t539-1">
   <w.rf>
    <LM>w#w-d1t539-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t539-3">
   <w.rf>
    <LM>w#w-d1t539-3</LM>
   </w.rf>
   <form>Třeboni</form>
   <lemma>Třeboň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-61-68">
   <w.rf>
    <LM>w#w-61-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-69">
  <m id="m039-69-321">
   <w.rf>
    <LM>w#w-69-321</LM>
   </w.rf>
   <form>Takovýhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m039-d1t539-12">
   <w.rf>
    <LM>w#w-d1t539-12</LM>
   </w.rf>
   <form>týdenní</form>
   <lemma>týdenní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m039-d1t541-1">
   <w.rf>
    <LM>w#w-d1t541-1</LM>
   </w.rf>
   <form>vnitrostátní</form>
   <lemma>vnitrostátní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m039-61-66">
   <w.rf>
    <LM>w#w-61-66</LM>
   </w.rf>
   <form>pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m039-61-67">
   <w.rf>
    <LM>w#w-61-67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t541-2">
   <w.rf>
    <LM>w#w-d1t541-2</LM>
   </w.rf>
   <form>popřípadě</form>
   <lemma>popřípadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t541-3">
   <w.rf>
    <LM>w#w-d1t541-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t541-5">
   <w.rf>
    <LM>w#w-d1t541-5</LM>
   </w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m039-69-70">
   <w.rf>
    <LM>w#w-69-70</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t543-2">
   <w.rf>
    <LM>w#w-d1t543-2</LM>
   </w.rf>
   <form>absolvujeme</form>
   <lemma>absolvovat</lemma>
   <tag>VB-P---1P-AAB--</tag>
  </m>
  <m id="m039-d1t543-3">
   <w.rf>
    <LM>w#w-d1t543-3</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m039-d-id69599-punct">
   <w.rf>
    <LM>w#w-d-id69599-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t546-1">
   <w.rf>
    <LM>w#w-d1t546-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t546-2">
   <w.rf>
    <LM>w#w-d1t546-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t546-3">
   <w.rf>
    <LM>w#w-d1t546-3</LM>
   </w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m039-d1t546-4">
   <w.rf>
    <LM>w#w-d1t546-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t546-5">
   <w.rf>
    <LM>w#w-d1t546-5</LM>
   </w.rf>
   <form>dlouhé</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m039-d1t546-6">
   <w.rf>
    <LM>w#w-d1t546-6</LM>
   </w.rf>
   <form>cesty</form>
   <lemma>cesta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m039-d1t546-7">
   <w.rf>
    <LM>w#w-d1t546-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t546-9">
   <w.rf>
    <LM>w#w-d1t546-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m039-d1t546-10">
   <w.rf>
    <LM>w#w-d1t546-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t546-11">
   <w.rf>
    <LM>w#w-d1t546-11</LM>
   </w.rf>
   <form>neláká</form>
   <lemma>lákat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m039-d-m-d1e519-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e519-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e547-x2">
  <m id="m039-d1t552-1">
   <w.rf>
    <LM>w#w-d1t552-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m039-d1e547-x2-14">
   <w.rf>
    <LM>w#w-d1e547-x2-14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-15">
  <m id="m039-d1t552-3">
   <w.rf>
    <LM>w#w-d1t552-3</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t552-4">
   <w.rf>
    <LM>w#w-d1t552-4</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m039-d1t552-5">
   <w.rf>
    <LM>w#w-d1t552-5</LM>
   </w.rf>
   <form>vyšlo</form>
   <lemma>vyjít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m039-d1t552-6">
   <w.rf>
    <LM>w#w-d1t552-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t552-8">
   <w.rf>
    <LM>w#w-d1t552-8</LM>
   </w.rf>
   <form>Turecku</form>
   <lemma>Turecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m039-d1t552-10">
   <w.rf>
    <LM>w#w-d1t552-10</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m039-d-m-d1e547-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e547-x2-punct-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e553-x2">
  <m id="m039-d1t558-3">
   <w.rf>
    <LM>w#w-d1t558-3</LM>
   </w.rf>
   <form>Výborně</form>
   <lemma>výborně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1e553-x2-17">
   <w.rf>
    <LM>w#w-d1e553-x2-17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t558-4">
   <w.rf>
    <LM>w#w-d1t558-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t558-5">
   <w.rf>
    <LM>w#w-d1t558-5</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d-m-d1e553-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e553-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e559-x3">
  <m id="m039-d1t566-1">
   <w.rf>
    <LM>w#w-d1t566-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m039-d1t566-2">
   <w.rf>
    <LM>w#w-d1t566-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1t566-3">
   <w.rf>
    <LM>w#w-d1t566-3</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m039-d1t566-4">
   <w.rf>
    <LM>w#w-d1t566-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1t566-5">
   <w.rf>
    <LM>w#w-d1t566-5</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m039-d1t566-6">
   <w.rf>
    <LM>w#w-d1t566-6</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m039-d1t566-7">
   <w.rf>
    <LM>w#w-d1t566-7</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m039-d-id70335-punct">
   <w.rf>
    <LM>w#w-d-id70335-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e567-x2">
  <m id="m039-d1t570-3">
   <w.rf>
    <LM>w#w-d1t570-3</LM>
   </w.rf>
   <form>Zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m039-d1t570-5">
   <w.rf>
    <LM>w#w-d1t570-5</LM>
   </w.rf>
   <form>zážitky</form>
   <lemma>zážitek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m039-d1t570-6">
   <w.rf>
    <LM>w#w-d1t570-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m039-d-id70509-punct">
   <w.rf>
    <LM>w#w-d-id70509-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t572-3">
   <w.rf>
    <LM>w#w-d1t572-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t574-1">
   <w.rf>
    <LM>w#w-d1t574-1</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t572-6">
   <w.rf>
    <LM>w#w-d1t572-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t572-5">
   <w.rf>
    <LM>w#w-d1t572-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t574-2">
   <w.rf>
    <LM>w#w-d1t574-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t574-3">
   <w.rf>
    <LM>w#w-d1t574-3</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-d1t576-1">
   <w.rf>
    <LM>w#w-d1t576-1</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1t576-2">
   <w.rf>
    <LM>w#w-d1t576-2</LM>
   </w.rf>
   <form>neviděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m039-d1e567-x2-50">
   <w.rf>
    <LM>w#w-d1e567-x2-50</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t576-3">
   <w.rf>
    <LM>w#w-d1t576-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t576-4">
   <w.rf>
    <LM>w#w-d1t576-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d-id70699-punct">
   <w.rf>
    <LM>w#w-d-id70699-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t576-6">
   <w.rf>
    <LM>w#w-d1t576-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1t576-7">
   <w.rf>
    <LM>w#w-d1t576-7</LM>
   </w.rf>
   <form>zahalená</form>
   <lemma>zahalený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m039-d-m-d1e567-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e567-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e587-x2">
  <m id="m039-d1t590-1">
   <w.rf>
    <LM>w#w-d1t590-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t590-2">
   <w.rf>
    <LM>w#w-d1t590-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t590-3">
   <w.rf>
    <LM>w#w-d1t590-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m039-d-m-d1e587-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e587-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e597-x2">
  <m id="m039-d1t602-2">
   <w.rf>
    <LM>w#w-d1t602-2</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m039-d1t602-3">
   <w.rf>
    <LM>w#w-d1t602-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t602-4">
   <w.rf>
    <LM>w#w-d1t602-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m039-d1t602-5">
   <w.rf>
    <LM>w#w-d1t602-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m039-d-id71092-punct">
   <w.rf>
    <LM>w#w-d-id71092-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e597-x4">
  <m id="m039-d1t604-3">
   <w.rf>
    <LM>w#w-d1t604-3</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d-m-d1e597-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e597-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e612-x2">
  <m id="m039-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m039-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1t615-3">
   <w.rf>
    <LM>w#w-d1t615-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t615-4">
   <w.rf>
    <LM>w#w-d1t615-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d-id71264-punct">
   <w.rf>
    <LM>w#w-d-id71264-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e616-x2">
  <m id="m039-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t621-5">
   <w.rf>
    <LM>w#w-d1t621-5</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t621-6">
   <w.rf>
    <LM>w#w-d1t621-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSXP4-S1-------</tag>
  </m>
  <m id="m039-d1t621-7">
   <w.rf>
    <LM>w#w-d1t621-7</LM>
   </w.rf>
   <form>sedmdesátiny</form>
   <lemma>sedmdesátiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m039-d1e616-x2-47">
   <w.rf>
    <LM>w#w-d1e616-x2-47</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-48">
  <m id="m039-d1t623-1">
   <w.rf>
    <LM>w#w-d1t623-1</LM>
   </w.rf>
   <form>Zleva</form>
   <lemma>zleva</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t623-2">
   <w.rf>
    <LM>w#w-d1t623-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t623-3">
   <w.rf>
    <LM>w#w-d1t623-3</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m039-d1t623-4">
   <w.rf>
    <LM>w#w-d1t623-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t623-5">
   <w.rf>
    <LM>w#w-d1t623-5</LM>
   </w.rf>
   <form>zprava</form>
   <lemma>zprava</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t623-6">
   <w.rf>
    <LM>w#w-d1t623-6</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-48-49">
   <w.rf>
    <LM>w#w-48-49</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-50">
  <m id="m039-d1t627-3">
   <w.rf>
    <LM>w#w-d1t627-3</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m039-d1t627-2">
   <w.rf>
    <LM>w#w-d1t627-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t627-4">
   <w.rf>
    <LM>w#w-d1t627-4</LM>
   </w.rf>
   <form>sedmdesátiny</form>
   <lemma>sedmdesátiny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m039-d-id71592-punct">
   <w.rf>
    <LM>w#w-d-id71592-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t627-6">
   <w.rf>
    <LM>w#w-d1t627-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m039-d1t627-7">
   <w.rf>
    <LM>w#w-d1t627-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m039-50-51">
   <w.rf>
    <LM>w#w-50-51</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m039-d1t627-8">
   <w.rf>
    <LM>w#w-d1t627-8</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t627-9">
   <w.rf>
    <LM>w#w-d1t627-9</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m039-d1t627-10">
   <w.rf>
    <LM>w#w-d1t627-10</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m039-50-52">
   <w.rf>
    <LM>w#w-50-52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-53">
  <m id="m039-d1t632-2">
   <w.rf>
    <LM>w#w-d1t632-2</LM>
   </w.rf>
   <form>Fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t632-3">
   <w.rf>
    <LM>w#w-d1t632-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t634-1">
   <w.rf>
    <LM>w#w-d1t634-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1t634-2">
   <w.rf>
    <LM>w#w-d1t634-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m039-d1t634-3">
   <w.rf>
    <LM>w#w-d1t634-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1t634-4">
   <w.rf>
    <LM>w#w-d1t634-4</LM>
   </w.rf>
   <form>jídelny</form>
   <lemma>jídelna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-53-54">
   <w.rf>
    <LM>w#w-53-54</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-55">
  <m id="m039-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>Obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-55-56">
   <w.rf>
    <LM>w#w-55-56</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t636-6">
   <w.rf>
    <LM>w#w-d1t636-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m039-d1t636-7">
   <w.rf>
    <LM>w#w-d1t636-7</LM>
   </w.rf>
   <form>visí</form>
   <lemma>viset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>napravo</form>
   <lemma>napravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d-id71901-punct">
   <w.rf>
    <LM>w#w-d-id71901-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t636-9">
   <w.rf>
    <LM>w#w-d1t636-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m039-d1t638-2">
   <w.rf>
    <LM>w#w-d1t638-2</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m039-d1t638-3">
   <w.rf>
    <LM>w#w-d1t638-3</LM>
   </w.rf>
   <form>rodný</form>
   <lemma>rodný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m039-d1t638-4">
   <w.rf>
    <LM>w#w-d1t638-4</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-d1t638-5">
   <w.rf>
    <LM>w#w-d1t638-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t638-6">
   <w.rf>
    <LM>w#w-d1t638-6</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-d1t643-5">
   <w.rf>
    <LM>w#w-d1t643-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t643-7">
   <w.rf>
    <LM>w#w-d1t643-7</LM>
   </w.rf>
   <form>Horaždovicku</form>
   <lemma>Horaždovicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m039-55-57">
   <w.rf>
    <LM>w#w-55-57</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t638-7">
   <w.rf>
    <LM>w#w-d1t638-7</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m039-d1t638-8">
   <w.rf>
    <LM>w#w-d1t638-8</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m039-d1t638-9">
   <w.rf>
    <LM>w#w-d1t638-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m039-d1t638-10">
   <w.rf>
    <LM>w#w-d1t638-10</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-55-58">
   <w.rf>
    <LM>w#w-55-58</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t643-1">
   <w.rf>
    <LM>w#w-d1t643-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m039-d1t643-2">
   <w.rf>
    <LM>w#w-d1t643-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1t643-3">
   <w.rf>
    <LM>w#w-d1t643-3</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m039-d1t643-4">
   <w.rf>
    <LM>w#w-d1t643-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m039-d-m-d1e616-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e616-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e644-x2">
  <m id="m039-d1t649-3">
   <w.rf>
    <LM>w#w-d1t649-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t649-4">
   <w.rf>
    <LM>w#w-d1t649-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m039-d1t649-5">
   <w.rf>
    <LM>w#w-d1t649-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t649-6">
   <w.rf>
    <LM>w#w-d1t649-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m039-d1t649-7">
   <w.rf>
    <LM>w#w-d1t649-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m039-d-m-d1e644-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e644-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e644-x3">
  <m id="m039-d1t651-1">
   <w.rf>
    <LM>w#w-d1t651-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t651-2">
   <w.rf>
    <LM>w#w-d1t651-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t651-3">
   <w.rf>
    <LM>w#w-d1t651-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d-id72444-punct">
   <w.rf>
    <LM>w#w-d-id72444-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e652-x2">
  <m id="m039-d1t655-1">
   <w.rf>
    <LM>w#w-d1t655-1</LM>
   </w.rf>
   <form>Obec</form>
   <lemma>obec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t655-2">
   <w.rf>
    <LM>w#w-d1t655-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t655-3">
   <w.rf>
    <LM>w#w-d1t655-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m039-d1t655-5">
   <w.rf>
    <LM>w#w-d1t655-5</LM>
   </w.rf>
   <form>Hlupín</form>
   <lemma>Hlupín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m039-d-m-d1e652-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e652-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e662-x2">
  <m id="m039-d1t665-1">
   <w.rf>
    <LM>w#w-d1t665-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t665-2">
   <w.rf>
    <LM>w#w-d1t665-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t665-3">
   <w.rf>
    <LM>w#w-d1t665-3</LM>
   </w.rf>
   <form>jmenují</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---3P-AAB--</tag>
  </m>
  <m id="m039-d1t665-4">
   <w.rf>
    <LM>w#w-d1t665-4</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m039-d1t665-5">
   <w.rf>
    <LM>w#w-d1t665-5</LM>
   </w.rf>
   <form>sourozenci</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m039-d-id72702-punct">
   <w.rf>
    <LM>w#w-d-id72702-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e666-x2">
  <m id="m039-d1t671-1">
   <w.rf>
    <LM>w#w-d1t671-1</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m039-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m039-d1t673-5">
   <w.rf>
    <LM>w#w-d1t673-5</LM>
   </w.rf>
   <form>Hana</form>
   <lemma>Hana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1e666-x2-75">
   <w.rf>
    <LM>w#w-d1e666-x2-75</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-76">
  <m id="m039-d1t675-3">
   <w.rf>
    <LM>w#w-d1t675-3</LM>
   </w.rf>
   <form>Narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m039-d1t675-2">
   <w.rf>
    <LM>w#w-d1t675-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t677-1">
   <w.rf>
    <LM>w#w-d1t677-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t677-3">
   <w.rf>
    <LM>w#w-d1t677-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m039-d1t677-2">
   <w.rf>
    <LM>w#w-d1t677-2</LM>
   </w.rf>
   <form>1946</form>
   <lemma>1946</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m039-76-77">
   <w.rf>
    <LM>w#w-76-77</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-78">
  <m id="m039-d1t680-2">
   <w.rf>
    <LM>w#w-d1t680-2</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t690-1">
   <w.rf>
    <LM>w#w-d1t690-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t693-4">
   <w.rf>
    <LM>w#w-d1t693-4</LM>
   </w.rf>
   <form>děvčatům</form>
   <lemma>děvče</lemma>
   <tag>NNNP3-----A----</tag>
  </m>
  <m id="m039-d1t690-3">
   <w.rf>
    <LM>w#w-d1t690-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m039-d1t690-2">
   <w.rf>
    <LM>w#w-d1t690-2</LM>
   </w.rf>
   <form>dávalo</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m039-d1t693-1">
   <w.rf>
    <LM>w#w-d1t693-1</LM>
   </w.rf>
   <form>křestní</form>
   <lemma>křestní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m039-d1t693-2">
   <w.rf>
    <LM>w#w-d1t693-2</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m039-d1t695-2">
   <w.rf>
    <LM>w#w-d1t695-2</LM>
   </w.rf>
   <form>Hana</form>
   <lemma>Hana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t686-1">
   <w.rf>
    <LM>w#w-d1t686-1</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m039-d1t688-1">
   <w.rf>
    <LM>w#w-d1t688-1</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1t688-2">
   <w.rf>
    <LM>w#w-d1t688-2</LM>
   </w.rf>
   <form>prezidentové</form>
   <lemma>prezidentová</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1t688-4">
   <w.rf>
    <LM>w#w-d1t688-4</LM>
   </w.rf>
   <form>Hany</form>
   <lemma>Hana_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d1t688-5">
   <w.rf>
    <LM>w#w-d1t688-5</LM>
   </w.rf>
   <form>Benešové</form>
   <lemma>Benešová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-78-79">
   <w.rf>
    <LM>w#w-78-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-80">
  <m id="m039-d1t697-3">
   <w.rf>
    <LM>w#w-d1t697-3</LM>
   </w.rf>
   <form>Náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m039-d1t697-4">
   <w.rf>
    <LM>w#w-d1t697-4</LM>
   </w.rf>
   <form>kmotr</form>
   <lemma>kmotr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m039-d1t701-1">
   <w.rf>
    <LM>w#w-d1t701-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t701-2">
   <w.rf>
    <LM>w#w-d1t701-2</LM>
   </w.rf>
   <form>kmotrou</form>
   <lemma>kmotra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m039-d1t703-2">
   <w.rf>
    <LM>w#w-d1t703-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d1t708-2">
   <w.rf>
    <LM>w#w-d1t708-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m039-d1t708-3">
   <w.rf>
    <LM>w#w-d1t708-3</LM>
   </w.rf>
   <form>republiku</form>
   <lemma>republika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m039-d-id73791-punct">
   <w.rf>
    <LM>w#w-d-id73791-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t708-5">
   <w.rf>
    <LM>w#w-d1t708-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m039-d1t710-3">
   <w.rf>
    <LM>w#w-d1t710-3</LM>
   </w.rf>
   <form>přáli</form>
   <lemma>přát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m039-d-id73870-punct">
   <w.rf>
    <LM>w#w-d-id73870-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1t710-5">
   <w.rf>
    <LM>w#w-d1t710-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m039-d1t710-7">
   <w.rf>
    <LM>w#w-d1t710-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t710-6">
   <w.rf>
    <LM>w#w-d1t710-6</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t710-8">
   <w.rf>
    <LM>w#w-d1t710-8</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m039-d1t710-10">
   <w.rf>
    <LM>w#w-d1t710-10</LM>
   </w.rf>
   <form>Hana</form>
   <lemma>Hana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t710-12">
   <w.rf>
    <LM>w#w-d1t710-12</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t710-13">
   <w.rf>
    <LM>w#w-d1t710-13</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-d1t710-15">
   <w.rf>
    <LM>w#w-d1t710-15</LM>
   </w.rf>
   <form>Benešové</form>
   <lemma>Benešová_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-80-96">
   <w.rf>
    <LM>w#w-80-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e666-x3">
  <m id="m039-d1t710-19">
   <w.rf>
    <LM>w#w-d1t710-19</LM>
   </w.rf>
   <form>Bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m039-d1t710-20">
   <w.rf>
    <LM>w#w-d1t710-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m039-d1t710-21">
   <w.rf>
    <LM>w#w-d1t710-21</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m039-d1t710-23">
   <w.rf>
    <LM>w#w-d1t710-23</LM>
   </w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m039-d-m-d1e666-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e666-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e711-x2">
  <m id="m039-d1t716-1">
   <w.rf>
    <LM>w#w-d1t716-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m039-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m039-d1t716-3">
   <w.rf>
    <LM>w#w-d1t716-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m039-d1t716-4">
   <w.rf>
    <LM>w#w-d1t716-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t716-5">
   <w.rf>
    <LM>w#w-d1t716-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m039-d1t716-6">
   <w.rf>
    <LM>w#w-d1t716-6</LM>
   </w.rf>
   <form>oslavě</form>
   <lemma>oslava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m039-d-id74276-punct">
   <w.rf>
    <LM>w#w-d-id74276-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e717-x2">
  <m id="m039-d1t724-2">
   <w.rf>
    <LM>w#w-d1t724-2</LM>
   </w.rf>
   <form>Oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d1t724-3">
   <w.rf>
    <LM>w#w-d1t724-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m039-d1t726-6">
   <w.rf>
    <LM>w#w-d1t726-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t726-7">
   <w.rf>
    <LM>w#w-d1t726-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m039-d1t726-8">
   <w.rf>
    <LM>w#w-d1t726-8</LM>
   </w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m039-d1e717-x2-20">
   <w.rf>
    <LM>w#w-d1e717-x2-20</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m039-d1e717-x2-21">
   <w.rf>
    <LM>w#w-d1e717-x2-21</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m039-d1t726-2">
   <w.rf>
    <LM>w#w-d1t726-2</LM>
   </w.rf>
   <form>bratrovou</form>
   <lemma>bratrův_^(*2)</lemma>
   <tag>AUFS7M---------</tag>
  </m>
  <m id="m039-d1t726-1">
   <w.rf>
    <LM>w#w-d1t726-1</LM>
   </w.rf>
   <form>manželkou</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m039-d1t726-3">
   <w.rf>
    <LM>w#w-d1t726-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m039-d1t726-4">
   <w.rf>
    <LM>w#w-d1t726-4</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m039-d1t726-5">
   <w.rf>
    <LM>w#w-d1t726-5</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m039-d-m-d1e717-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e717-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m039-d1e727-x2">
  <m id="m039-d1t732-3">
   <w.rf>
    <LM>w#w-d1t732-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m039-d1t732-2">
   <w.rf>
    <LM>w#w-d1t732-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m039-d1t732-4">
   <w.rf>
    <LM>w#w-d1t732-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m039-d1t732-5">
   <w.rf>
    <LM>w#w-d1t732-5</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m039-d1t732-6">
   <w.rf>
    <LM>w#w-d1t732-6</LM>
   </w.rf>
   <form>rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m039-d1t732-7">
   <w.rf>
    <LM>w#w-d1t732-7</LM>
   </w.rf>
   <form>oslava</form>
   <lemma>oslava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m039-d-id74751-punct">
   <w.rf>
    <LM>w#w-d-id74751-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
