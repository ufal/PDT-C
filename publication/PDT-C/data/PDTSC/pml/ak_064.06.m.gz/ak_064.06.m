<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_064.06.w.gz" />
  </references>
 </head>
 <s id="m064-139">
  <m id="m064-d1t1569-9">
   <w.rf>
    <LM>w#w-d1t1569-9</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1569-10">
   <w.rf>
    <LM>w#w-d1t1569-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1569-11">
   <w.rf>
    <LM>w#w-d1t1569-11</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1569-12">
   <w.rf>
    <LM>w#w-d1t1569-12</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m064-d1t1569-13">
   <w.rf>
    <LM>w#w-d1t1569-13</LM>
   </w.rf>
   <form>mami</form>
   <lemma>mami_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m064-d1t1569-14">
   <w.rf>
    <LM>w#w-d1t1569-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1569-16">
   <w.rf>
    <LM>w#w-d1t1569-16</LM>
   </w.rf>
   <form>Bolkově</form>
   <lemma>Bolkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m064-d1t1571-1">
   <w.rf>
    <LM>w#w-d1t1571-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1571-2">
   <w.rf>
    <LM>w#w-d1t1571-2</LM>
   </w.rf>
   <form>dvorku</form>
   <lemma>dvorek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1566-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1566-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1572-x2">
  <m id="m064-d1t1577-1">
   <w.rf>
    <LM>w#w-d1t1577-1</LM>
   </w.rf>
   <form>Pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m064-d1t1577-2">
   <w.rf>
    <LM>w#w-d1t1577-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1577-5">
   <w.rf>
    <LM>w#w-d1t1577-5</LM>
   </w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d-m-d1e1572-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1572-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1572-x3">
  <m id="m064-d1t1579-1">
   <w.rf>
    <LM>w#w-d1t1579-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1579-2">
   <w.rf>
    <LM>w#w-d1t1579-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-d1t1579-3">
   <w.rf>
    <LM>w#w-d1t1579-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m064-d-id107470-punct">
   <w.rf>
    <LM>w#w-d-id107470-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1580-x2">
  <m id="m064-d1t1583-1">
   <w.rf>
    <LM>w#w-d1t1583-1</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m064-d1t1583-2">
   <w.rf>
    <LM>w#w-d1t1583-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-d1t1583-4">
   <w.rf>
    <LM>w#w-d1t1583-4</LM>
   </w.rf>
   <form>Alexandr</form>
   <lemma>Alexandr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1580-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1580-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1584-x2">
  <m id="m064-d1t1589-2">
   <w.rf>
    <LM>w#w-d1t1589-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1589-3">
   <w.rf>
    <LM>w#w-d1t1589-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m064-d1t1589-4">
   <w.rf>
    <LM>w#w-d1t1589-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1589-6">
   <w.rf>
    <LM>w#w-d1t1589-6</LM>
   </w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m064-d1t1589-8">
   <w.rf>
    <LM>w#w-d1t1589-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m064-d1e1584-x2-150">
   <w.rf>
    <LM>w#w-d1e1584-x2-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-151">
  <m id="m064-d1t1589-10">
   <w.rf>
    <LM>w#w-d1t1589-10</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1589-11">
   <w.rf>
    <LM>w#w-d1t1589-11</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m064-d1t1589-12">
   <w.rf>
    <LM>w#w-d1t1589-12</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m064-151-152">
   <w.rf>
    <LM>w#w-151-152</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1591-1">
   <w.rf>
    <LM>w#w-d1t1591-1</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1t1591-2">
   <w.rf>
    <LM>w#w-d1t1591-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1591-4">
   <w.rf>
    <LM>w#w-d1t1591-4</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1584-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1584-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1584-x3">
  <m id="m064-d1t1595-1">
   <w.rf>
    <LM>w#w-d1t1595-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m064-d1t1595-2">
   <w.rf>
    <LM>w#w-d1t1595-2</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d-id107946-punct">
   <w.rf>
    <LM>w#w-d-id107946-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1596-x2">
  <m id="m064-d1t1599-5">
   <w.rf>
    <LM>w#w-d1t1599-5</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1599-6">
   <w.rf>
    <LM>w#w-d1t1599-6</LM>
   </w.rf>
   <form>stavební</form>
   <lemma>stavební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m064-d1t1599-7">
   <w.rf>
    <LM>w#w-d1t1599-7</LM>
   </w.rf>
   <form>průmyslovku</form>
   <lemma>průmyslovka_,h</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1t1601-1">
   <w.rf>
    <LM>w#w-d1t1601-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1601-2">
   <w.rf>
    <LM>w#w-d1t1601-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1601-3">
   <w.rf>
    <LM>w#w-d1t1601-3</LM>
   </w.rf>
   <form>zaměstnaný</form>
   <lemma>zaměstnaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m064-d1t1601-4">
   <w.rf>
    <LM>w#w-d1t1601-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m064-d1t1601-5">
   <w.rf>
    <LM>w#w-d1t1601-5</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m064-d1t1601-6">
   <w.rf>
    <LM>w#w-d1t1601-6</LM>
   </w.rf>
   <form>otcem</form>
   <lemma>otec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m064-d1e1596-x2-159">
   <w.rf>
    <LM>w#w-d1e1596-x2-159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-160">
  <m id="m064-d1t1605-3">
   <w.rf>
    <LM>w#w-d1t1605-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1605-4">
   <w.rf>
    <LM>w#w-d1t1605-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1605-1">
   <w.rf>
    <LM>w#w-d1t1605-1</LM>
   </w.rf>
   <form>stavba</form>
   <lemma>stavba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d1t1605-2">
   <w.rf>
    <LM>w#w-d1t1605-2</LM>
   </w.rf>
   <form>silnic</form>
   <lemma>silnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m064-160-161">
   <w.rf>
    <LM>w#w-160-161</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-162">
  <m id="m064-d1t1605-7">
   <w.rf>
    <LM>w#w-d1t1605-7</LM>
   </w.rf>
   <form>Staví</form>
   <lemma>stavět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1605-8">
   <w.rf>
    <LM>w#w-d1t1605-8</LM>
   </w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1596-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1596-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1612-x3">
  <m id="m064-d1t1619-1">
   <w.rf>
    <LM>w#w-d1t1619-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1619-2">
   <w.rf>
    <LM>w#w-d1t1619-2</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1619-3">
   <w.rf>
    <LM>w#w-d1t1619-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m064-d1t1619-4">
   <w.rf>
    <LM>w#w-d1t1619-4</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m064-d1t1619-5">
   <w.rf>
    <LM>w#w-d1t1619-5</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m064-d1t1619-6">
   <w.rf>
    <LM>w#w-d1t1619-6</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d-id108614-punct">
   <w.rf>
    <LM>w#w-d-id108614-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1620-x2">
  <m id="m064-d1t1623-5">
   <w.rf>
    <LM>w#w-d1t1623-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1623-4">
   <w.rf>
    <LM>w#w-d1t1623-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1623-6">
   <w.rf>
    <LM>w#w-d1t1623-6</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1623-10">
   <w.rf>
    <LM>w#w-d1t1623-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1623-11">
   <w.rf>
    <LM>w#w-d1t1623-11</LM>
   </w.rf>
   <form>jaře</form>
   <lemma>jaro</lemma>
   <tag>NNNS6-----A---1</tag>
  </m>
  <m id="m064-d1e1620-x2-175">
   <w.rf>
    <LM>w#w-d1e1620-x2-175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1625-5">
   <w.rf>
    <LM>w#w-d1t1625-5</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1625-4">
   <w.rf>
    <LM>w#w-d1t1625-4</LM>
   </w.rf>
   <form>květen</form>
   <lemma>květen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1620-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1620-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1627-x2">
  <m id="m064-d1t1630-1">
   <w.rf>
    <LM>w#w-d1t1630-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1630-2">
   <w.rf>
    <LM>w#w-d1t1630-2</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1630-3">
   <w.rf>
    <LM>w#w-d1t1630-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1630-4">
   <w.rf>
    <LM>w#w-d1t1630-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1630-5">
   <w.rf>
    <LM>w#w-d1t1630-5</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m064-d-id109051-punct">
   <w.rf>
    <LM>w#w-d-id109051-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1631-x2">
  <m id="m064-d1t1634-3">
   <w.rf>
    <LM>w#w-d1t1634-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1634-4">
   <w.rf>
    <LM>w#w-d1t1634-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1634-6">
   <w.rf>
    <LM>w#w-d1t1634-6</LM>
   </w.rf>
   <form>Bolkov</form>
   <lemma>Bolkov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m064-d1e1631-x2-188">
   <w.rf>
    <LM>w#w-d1e1631-x2-188</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1634-10">
   <w.rf>
    <LM>w#w-d1t1634-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1634-9">
   <w.rf>
    <LM>w#w-d1t1634-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1636-5">
   <w.rf>
    <LM>w#w-d1t1636-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1636-6">
   <w.rf>
    <LM>w#w-d1t1636-6</LM>
   </w.rf>
   <form>třináct</form>
   <lemma>třináct`13</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m064-d1t1636-7">
   <w.rf>
    <LM>w#w-d1t1636-7</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m064-d1t1636-8">
   <w.rf>
    <LM>w#w-d1t1636-8</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1636-10">
   <w.rf>
    <LM>w#w-d1t1636-10</LM>
   </w.rf>
   <form>Přeštic</form>
   <lemma>Přeštice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1631-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1631-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1643-x2">
  <m id="m064-d1t1646-3">
   <w.rf>
    <LM>w#w-d1t1646-3</LM>
   </w.rf>
   <form>Blízko</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1646-1">
   <w.rf>
    <LM>w#w-d1t1646-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1646-2">
   <w.rf>
    <LM>w#w-d1t1646-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1646-4">
   <w.rf>
    <LM>w#w-d1t1646-4</LM>
   </w.rf>
   <form>les</form>
   <lemma>les</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m064-d1e1643-x2-205">
   <w.rf>
    <LM>w#w-d1e1643-x2-205</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-206">
  <m id="m064-d1t1648-3">
   <w.rf>
    <LM>w#w-d1t1648-3</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1648-5">
   <w.rf>
    <LM>w#w-d1t1648-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1648-6">
   <w.rf>
    <LM>w#w-d1t1648-6</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m064-d1t1648-7">
   <w.rf>
    <LM>w#w-d1t1648-7</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-206-207">
   <w.rf>
    <LM>w#w-206-207</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-208">
  <m id="m064-d1t1652-6">
   <w.rf>
    <LM>w#w-d1t1652-6</LM>
   </w.rf>
   <form>Jezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1652-5">
   <w.rf>
    <LM>w#w-d1t1652-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1652-7">
   <w.rf>
    <LM>w#w-d1t1652-7</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m064-d1t1652-8">
   <w.rf>
    <LM>w#w-d1t1652-8</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m064-208-209">
   <w.rf>
    <LM>w#w-208-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-210">
  <m id="m064-d1t1654-5">
   <w.rf>
    <LM>w#w-d1t1654-5</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1654-6">
   <w.rf>
    <LM>w#w-d1t1654-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1654-8">
   <w.rf>
    <LM>w#w-d1t1654-8</LM>
   </w.rf>
   <form>Kolíně</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m064-210-245">
   <w.rf>
    <LM>w#w-210-245</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-246">
  <m id="m064-d1t1654-11">
   <w.rf>
    <LM>w#w-d1t1654-11</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1654-12">
   <w.rf>
    <LM>w#w-d1t1654-12</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1654-13">
   <w.rf>
    <LM>w#w-d1t1654-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1654-15">
   <w.rf>
    <LM>w#w-d1t1654-15</LM>
   </w.rf>
   <form>Kolíně</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m064-d-id110013-punct">
   <w.rf>
    <LM>w#w-d-id110013-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1654-18">
   <w.rf>
    <LM>w#w-d1t1654-18</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1654-19">
   <w.rf>
    <LM>w#w-d1t1654-19</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1654-21">
   <w.rf>
    <LM>w#w-d1t1654-21</LM>
   </w.rf>
   <form>Kolína</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m064-246-250">
   <w.rf>
    <LM>w#w-246-250</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-251">
  <m id="m064-246-247">
   <w.rf>
    <LM>w#w-246-247</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m064-246-248">
   <w.rf>
    <LM>w#w-246-248</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-246-249">
   <w.rf>
    <LM>w#w-246-249</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1654-25">
   <w.rf>
    <LM>w#w-d1t1654-25</LM>
   </w.rf>
   <form>Ohrada</form>
   <lemma>ohrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d1t1654-26">
   <w.rf>
    <LM>w#w-d1t1654-26</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1654-27">
   <w.rf>
    <LM>w#w-d1t1654-27</LM>
   </w.rf>
   <form>Kolína</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m064-251-252">
   <w.rf>
    <LM>w#w-251-252</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-253">
  <m id="m064-d1t1659-6">
   <w.rf>
    <LM>w#w-d1t1659-6</LM>
   </w.rf>
   <form>Často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1659-7">
   <w.rf>
    <LM>w#w-d1t1659-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-d1t1659-8">
   <w.rf>
    <LM>w#w-d1t1659-8</LM>
   </w.rf>
   <form>nevidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m064-d-id110293-punct">
   <w.rf>
    <LM>w#w-d-id110293-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1659-10">
   <w.rf>
    <LM>w#w-d1t1659-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m064-d1t1659-11">
   <w.rf>
    <LM>w#w-d1t1659-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1659-12">
   <w.rf>
    <LM>w#w-d1t1659-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1659-13">
   <w.rf>
    <LM>w#w-d1t1659-13</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1659-14">
   <w.rf>
    <LM>w#w-d1t1659-14</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d-m-d1e1643-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1643-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1662-x2">
  <m id="m064-d1t1665-1">
   <w.rf>
    <LM>w#w-d1t1665-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1665-2">
   <w.rf>
    <LM>w#w-d1t1665-2</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1665-3">
   <w.rf>
    <LM>w#w-d1t1665-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1665-5">
   <w.rf>
    <LM>w#w-d1t1665-5</LM>
   </w.rf>
   <form>Bolkova</form>
   <lemma>Bolkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m064-d-id110553-punct">
   <w.rf>
    <LM>w#w-d-id110553-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1666-x2">
  <m id="m064-d1t1669-1">
   <w.rf>
    <LM>w#w-d1t1669-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1669-2">
   <w.rf>
    <LM>w#w-d1t1669-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1669-3">
   <w.rf>
    <LM>w#w-d1t1669-3</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1e1666-x2-258">
   <w.rf>
    <LM>w#w-d1e1666-x2-258</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-259">
  <m id="m064-d1t1669-12">
   <w.rf>
    <LM>w#w-d1t1669-12</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m064-d1t1669-8">
   <w.rf>
    <LM>w#w-d1t1669-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1669-9">
   <w.rf>
    <LM>w#w-d1t1669-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1669-10">
   <w.rf>
    <LM>w#w-d1t1669-10</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m064-d1t1669-11">
   <w.rf>
    <LM>w#w-d1t1669-11</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1666-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1666-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1670-x2">
  <m id="m064-d1e1674">
   <w.rf>
    <LM>w#w-d1e1674</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m064-d-m-d1e1670-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1670-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1676-x2">
  <m id="m064-d1t1683-4">
   <w.rf>
    <LM>w#w-d1t1683-4</LM>
   </w.rf>
   <form>Jezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1683-5">
   <w.rf>
    <LM>w#w-d1t1683-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1e1676-x2-263">
   <w.rf>
    <LM>w#w-d1e1676-x2-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-264">
  <m id="m064-d1t1679-7">
   <w.rf>
    <LM>w#w-d1t1679-7</LM>
   </w.rf>
   <form>Nakupuju</form>
   <lemma>nakupovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1679-6">
   <w.rf>
    <LM>w#w-d1t1679-6</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m064-264-265">
   <w.rf>
    <LM>w#w-264-265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-267">
  <m id="m064-d1t1683-7">
   <w.rf>
    <LM>w#w-d1t1683-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1683-8">
   <w.rf>
    <LM>w#w-d1t1683-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1683-9">
   <w.rf>
    <LM>w#w-d1t1683-9</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m064-d1t1683-10">
   <w.rf>
    <LM>w#w-d1t1683-10</LM>
   </w.rf>
   <form>zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-267-268">
   <w.rf>
    <LM>w#w-267-268</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-269">
  <m id="m064-d1t1683-12">
   <w.rf>
    <LM>w#w-d1t1683-12</LM>
   </w.rf>
   <form>Seču</form>
   <lemma>síci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1683-13">
   <w.rf>
    <LM>w#w-d1t1683-13</LM>
   </w.rf>
   <form>trávu</form>
   <lemma>tráva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1t1685-2">
   <w.rf>
    <LM>w#w-d1t1685-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1685-3">
   <w.rf>
    <LM>w#w-d1t1685-3</LM>
   </w.rf>
   <form>pomáhám</form>
   <lemma>pomáhat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1685-4">
   <w.rf>
    <LM>w#w-d1t1685-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m064-d1t1685-5">
   <w.rf>
    <LM>w#w-d1t1685-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d-m-d1e1676-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1676-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1686-x2">
  <m id="m064-d1t1689-1">
   <w.rf>
    <LM>w#w-d1t1689-1</LM>
   </w.rf>
   <form>Bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1689-2">
   <w.rf>
    <LM>w#w-d1t1689-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1689-3">
   <w.rf>
    <LM>w#w-d1t1689-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1689-4">
   <w.rf>
    <LM>w#w-d1t1689-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m064-d1t1689-5">
   <w.rf>
    <LM>w#w-d1t1689-5</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m064-d-id111439-punct">
   <w.rf>
    <LM>w#w-d-id111439-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1690-x2">
  <m id="m064-d1t1693-7">
   <w.rf>
    <LM>w#w-d1t1693-7</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1e1690-x2-274">
   <w.rf>
    <LM>w#w-d1e1690-x2-274</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1693-4">
   <w.rf>
    <LM>w#w-d1t1693-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m064-d1t1693-5">
   <w.rf>
    <LM>w#w-d1t1693-5</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m064-d1t1693-2">
   <w.rf>
    <LM>w#w-d1t1693-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1693-3">
   <w.rf>
    <LM>w#w-d1t1693-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1693-1">
   <w.rf>
    <LM>w#w-d1t1693-1</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1701-1">
   <w.rf>
    <LM>w#w-d1t1701-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m064-d1t1701-2">
   <w.rf>
    <LM>w#w-d1t1701-2</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m064-d1t1701-3">
   <w.rf>
    <LM>w#w-d1t1701-3</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1694-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1694-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1694-x3">
  <m id="m064-d1t1703-1">
   <w.rf>
    <LM>w#w-d1t1703-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m064-d1t1703-2">
   <w.rf>
    <LM>w#w-d1t1703-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1703-3">
   <w.rf>
    <LM>w#w-d1t1703-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1703-4">
   <w.rf>
    <LM>w#w-d1t1703-4</LM>
   </w.rf>
   <form>strávila</form>
   <lemma>strávit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m064-d1t1703-5">
   <w.rf>
    <LM>w#w-d1t1703-5</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m064-d-id111794-punct">
   <w.rf>
    <LM>w#w-d-id111794-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1694-x4">
  <m id="m064-d1t1708-7">
   <w.rf>
    <LM>w#w-d1t1708-7</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1e1694-x4-282">
   <w.rf>
    <LM>w#w-d1e1694-x4-282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1708-2">
   <w.rf>
    <LM>w#w-d1t1708-2</LM>
   </w.rf>
   <form>strávila</form>
   <lemma>strávit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m064-d1t1708-3">
   <w.rf>
    <LM>w#w-d1t1708-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1708-4">
   <w.rf>
    <LM>w#w-d1t1708-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1708-5">
   <w.rf>
    <LM>w#w-d1t1708-5</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1694-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1694-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1694-x5">
  <m id="m064-d1t1710-1">
   <w.rf>
    <LM>w#w-d1t1710-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m064-d1t1710-2">
   <w.rf>
    <LM>w#w-d1t1710-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1710-3">
   <w.rf>
    <LM>w#w-d1t1710-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m064-d-m-d1e1694-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1694-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1712-x2">
  <m id="m064-d1t1715-3">
   <w.rf>
    <LM>w#w-d1t1715-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1715-4">
   <w.rf>
    <LM>w#w-d1t1715-4</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1t1715-5">
   <w.rf>
    <LM>w#w-d1t1715-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1715-6">
   <w.rf>
    <LM>w#w-d1t1715-6</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m064-d1t1715-8">
   <w.rf>
    <LM>w#w-d1t1715-8</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1715-9">
   <w.rf>
    <LM>w#w-d1t1715-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1715-12">
   <w.rf>
    <LM>w#w-d1t1715-12</LM>
   </w.rf>
   <form>Ohradě</form>
   <lemma>ohrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m064-d1t1715-13">
   <w.rf>
    <LM>w#w-d1t1715-13</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1715-14">
   <w.rf>
    <LM>w#w-d1t1715-14</LM>
   </w.rf>
   <form>Kolína</form>
   <lemma>Kolín-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m064-d1e1712-x2-292">
   <w.rf>
    <LM>w#w-d1e1712-x2-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-293">
  <m id="m064-d1t1715-19">
   <w.rf>
    <LM>w#w-d1t1715-19</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1715-17">
   <w.rf>
    <LM>w#w-d1t1715-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1715-20">
   <w.rf>
    <LM>w#w-d1t1715-20</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1715-22">
   <w.rf>
    <LM>w#w-d1t1715-22</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m064-d1t1715-23">
   <w.rf>
    <LM>w#w-d1t1715-23</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m064-293-294">
   <w.rf>
    <LM>w#w-293-294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-295">
  <m id="m064-d1t1719-2">
   <w.rf>
    <LM>w#w-d1t1719-2</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1719-3">
   <w.rf>
    <LM>w#w-d1t1719-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1719-4">
   <w.rf>
    <LM>w#w-d1t1719-4</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d-id112396-punct">
   <w.rf>
    <LM>w#w-d-id112396-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1719-6">
   <w.rf>
    <LM>w#w-d1t1719-6</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m064-d1t1719-7">
   <w.rf>
    <LM>w#w-d1t1719-7</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1719-10">
   <w.rf>
    <LM>w#w-d1t1719-10</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1719-12">
   <w.rf>
    <LM>w#w-d1t1719-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1719-14">
   <w.rf>
    <LM>w#w-d1t1719-14</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m064-295-296">
   <w.rf>
    <LM>w#w-295-296</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-297">
  <m id="m064-d1t1719-19">
   <w.rf>
    <LM>w#w-d1t1719-19</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1719-22">
   <w.rf>
    <LM>w#w-d1t1719-22</LM>
   </w.rf>
   <form>Ohradě</form>
   <lemma>ohrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m064-d1t1719-24">
   <w.rf>
    <LM>w#w-d1t1719-24</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m064-d1t1719-25">
   <w.rf>
    <LM>w#w-d1t1719-25</LM>
   </w.rf>
   <form>staví</form>
   <lemma>stavit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m064-d1t1719-26">
   <w.rf>
    <LM>w#w-d1t1719-26</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1719-27">
   <w.rf>
    <LM>w#w-d1t1719-27</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1712-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1712-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1720-x2">
  <m id="m064-d1t1727-1">
   <w.rf>
    <LM>w#w-d1t1727-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1e1720-x2-300">
   <w.rf>
    <LM>w#w-d1e1720-x2-300</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-301">
  <m id="m064-d1t1729-1">
   <w.rf>
    <LM>w#w-d1t1729-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1729-2">
   <w.rf>
    <LM>w#w-d1t1729-2</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m064-d1t1729-3">
   <w.rf>
    <LM>w#w-d1t1729-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m064-d1t1729-4">
   <w.rf>
    <LM>w#w-d1t1729-4</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m064-d1t1729-5">
   <w.rf>
    <LM>w#w-d1t1729-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m064-d1t1729-7">
   <w.rf>
    <LM>w#w-d1t1729-7</LM>
   </w.rf>
   <form>Bolkov</form>
   <lemma>Bolkov_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1720-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1720-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1730-x2">
  <m id="m064-d1t1733-1">
   <w.rf>
    <LM>w#w-d1t1733-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d-m-d1e1730-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1730-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1734-x2">
  <m id="m064-d1t1737-1">
   <w.rf>
    <LM>w#w-d1t1737-1</LM>
   </w.rf>
   <form>Chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1737-2">
   <w.rf>
    <LM>w#w-d1t1737-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1737-3">
   <w.rf>
    <LM>w#w-d1t1737-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1737-4">
   <w.rf>
    <LM>w#w-d1t1737-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1737-5">
   <w.rf>
    <LM>w#w-d1t1737-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1737-6">
   <w.rf>
    <LM>w#w-d1t1737-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m064-d-id113131-punct">
   <w.rf>
    <LM>w#w-d-id113131-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1738-x2">
  <m id="m064-d1t1743-3">
   <w.rf>
    <LM>w#w-d1t1743-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1743-4">
   <w.rf>
    <LM>w#w-d1t1743-4</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d1t1743-5">
   <w.rf>
    <LM>w#w-d1t1743-5</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m064-d1e1738-x2-319">
   <w.rf>
    <LM>w#w-d1e1738-x2-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-320">
  <m id="m064-d1t1745-3">
   <w.rf>
    <LM>w#w-d1t1745-3</LM>
   </w.rf>
   <form>Nejdřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m064-d1t1745-2">
   <w.rf>
    <LM>w#w-d1t1745-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1745-1">
   <w.rf>
    <LM>w#w-d1t1745-1</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1745-4">
   <w.rf>
    <LM>w#w-d1t1745-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1745-6">
   <w.rf>
    <LM>w#w-d1t1745-6</LM>
   </w.rf>
   <form>Otěšic</form>
   <lemma>Otěšice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m064-d-id113422-punct">
   <w.rf>
    <LM>w#w-d-id113422-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1745-9">
   <w.rf>
    <LM>w#w-d1t1745-9</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m064-d1t1745-10">
   <w.rf>
    <LM>w#w-d1t1745-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1745-11">
   <w.rf>
    <LM>w#w-d1t1745-11</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m064-d1t1745-12">
   <w.rf>
    <LM>w#w-d1t1745-12</LM>
   </w.rf>
   <form>kilometry</form>
   <lemma>kilometr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m064-320-321">
   <w.rf>
    <LM>w#w-320-321</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-323">
  <m id="m064-d1t1747-2">
   <w.rf>
    <LM>w#w-d1t1747-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1747-3">
   <w.rf>
    <LM>w#w-d1t1747-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1747-4">
   <w.rf>
    <LM>w#w-d1t1747-4</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1747-7">
   <w.rf>
    <LM>w#w-d1t1747-7</LM>
   </w.rf>
   <form>jednotřídka</form>
   <lemma>jednotřídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-323-324">
   <w.rf>
    <LM>w#w-323-324</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1747-10">
   <w.rf>
    <LM>w#w-d1t1747-10</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m064-d1t1747-11">
   <w.rf>
    <LM>w#w-d1t1747-11</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1747-12">
   <w.rf>
    <LM>w#w-d1t1747-12</LM>
   </w.rf>
   <form>čtvrtá</form>
   <lemma>čtvrtý</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m064-d1t1747-13">
   <w.rf>
    <LM>w#w-d1t1747-13</LM>
   </w.rf>
   <form>třída</form>
   <lemma>třída</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d1t1747-14">
   <w.rf>
    <LM>w#w-d1t1747-14</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-323-325">
   <w.rf>
    <LM>w#w-323-325</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-326">
  <m id="m064-d1t1749-6">
   <w.rf>
    <LM>w#w-d1t1749-6</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1749-8">
   <w.rf>
    <LM>w#w-d1t1749-8</LM>
   </w.rf>
   <form>páté</form>
   <lemma>pátý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m064-d1t1749-9">
   <w.rf>
    <LM>w#w-d1t1749-9</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m064-326-329">
   <w.rf>
    <LM>w#w-326-329</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-326-330">
   <w.rf>
    <LM>w#w-326-330</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1749-10">
   <w.rf>
    <LM>w#w-d1t1749-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1749-12">
   <w.rf>
    <LM>w#w-d1t1749-12</LM>
   </w.rf>
   <form>Merklína</form>
   <lemma>Merklín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m064-326-327">
   <w.rf>
    <LM>w#w-326-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-328">
  <m id="m064-d1t1752-1">
   <w.rf>
    <LM>w#w-d1t1752-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1752-2">
   <w.rf>
    <LM>w#w-d1t1752-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1752-3">
   <w.rf>
    <LM>w#w-d1t1752-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m064-d1t1752-4">
   <w.rf>
    <LM>w#w-d1t1752-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m064-d1t1752-5">
   <w.rf>
    <LM>w#w-d1t1752-5</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m064-d1t1752-6">
   <w.rf>
    <LM>w#w-d1t1752-6</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m064-d1t1752-7">
   <w.rf>
    <LM>w#w-d1t1752-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1752-9">
   <w.rf>
    <LM>w#w-d1t1752-9</LM>
   </w.rf>
   <form>Přešticích</form>
   <lemma>Přeštice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m064-d-id114059-punct">
   <w.rf>
    <LM>w#w-d-id114059-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1752-12">
   <w.rf>
    <LM>w#w-d1t1752-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m064-d1t1752-14">
   <w.rf>
    <LM>w#w-d1t1752-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1752-15">
   <w.rf>
    <LM>w#w-d1t1752-15</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1752-20">
   <w.rf>
    <LM>w#w-d1t1752-20</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1752-21">
   <w.rf>
    <LM>w#w-d1t1752-21</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m064-d1t1752-16">
   <w.rf>
    <LM>w#w-d1t1752-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m064-d1t1752-18">
   <w.rf>
    <LM>w#w-d1t1752-18</LM>
   </w.rf>
   <form>Přešticích</form>
   <lemma>Přeštice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1738-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1738-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1755-x3">
  <m id="m064-d1t1764-1">
   <w.rf>
    <LM>w#w-d1t1764-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1764-2">
   <w.rf>
    <LM>w#w-d1t1764-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1764-3">
   <w.rf>
    <LM>w#w-d1t1764-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-d1t1764-4">
   <w.rf>
    <LM>w#w-d1t1764-4</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m064-d1t1764-5">
   <w.rf>
    <LM>w#w-d1t1764-5</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1764-6">
   <w.rf>
    <LM>w#w-d1t1764-6</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1e1755-x3-351">
   <w.rf>
    <LM>w#w-d1e1755-x3-351</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-352">
  <m id="m064-d1t1766-1">
   <w.rf>
    <LM>w#w-d1t1766-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1766-2">
   <w.rf>
    <LM>w#w-d1t1766-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m064-d1t1766-3">
   <w.rf>
    <LM>w#w-d1t1766-3</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m064-d1t1766-4">
   <w.rf>
    <LM>w#w-d1t1766-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m064-d1t1766-5">
   <w.rf>
    <LM>w#w-d1t1766-5</LM>
   </w.rf>
   <form>dvanáctiletku</form>
   <lemma>dvanáctiletka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m064-d1t1766-11">
   <w.rf>
    <LM>w#w-d1t1766-11</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m064-d1t1766-6">
   <w.rf>
    <LM>w#w-d1t1766-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m064-d1t1766-8">
   <w.rf>
    <LM>w#w-d1t1766-8</LM>
   </w.rf>
   <form>Přeštic</form>
   <lemma>Přeštice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m064-d-m-d1e1755-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1755-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m064-d1e1767-x2">
  <m id="m064-d1t1770-1">
   <w.rf>
    <LM>w#w-d1t1770-1</LM>
   </w.rf>
   <form>Vybavuje</form>
   <lemma>vybavovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m064-d1t1770-2">
   <w.rf>
    <LM>w#w-d1t1770-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m064-d1t1770-3">
   <w.rf>
    <LM>w#w-d1t1770-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m064-d1t1770-4">
   <w.rf>
    <LM>w#w-d1t1770-4</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m064-d1t1770-5">
   <w.rf>
    <LM>w#w-d1t1770-5</LM>
   </w.rf>
   <form>lumpárna</form>
   <lemma>lumpárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m064-d-id114702-punct">
   <w.rf>
    <LM>w#w-d-id114702-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m064-d1t1770-7">
   <w.rf>
    <LM>w#w-d1t1770-7</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m064-d1t1770-8">
   <w.rf>
    <LM>w#w-d1t1770-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m064-d1t1770-9">
   <w.rf>
    <LM>w#w-d1t1770-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m064-d1t1770-10">
   <w.rf>
    <LM>w#w-d1t1770-10</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m064-d1t1770-11">
   <w.rf>
    <LM>w#w-d1t1770-11</LM>
   </w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m064-d-id114788-punct">
   <w.rf>
    <LM>w#w-d-id114788-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
