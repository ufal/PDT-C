<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_017.05.w.gz" />
  </references>
 </head>
 <s id="m017-494_1">
  <m id="m017-d1t1456-2">
   <w.rf>
    <LM>w#w-d1t1456-2</LM>
   </w.rf>
   <form>Píchli</form>
   <lemma>píchnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m017-d1t1454-5">
   <w.rf>
    <LM>w#w-d1t1454-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1456-1">
   <w.rf>
    <LM>w#w-d1t1456-1</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m017-d-id106036-punct">
   <w.rf>
    <LM>w#w-d-id106036-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-494_1-574">
   <w.rf>
    <LM>w#w-494_1-574</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1456-6">
   <w.rf>
    <LM>w#w-d1t1456-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1456-4">
   <w.rf>
    <LM>w#w-d1t1456-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1456-5">
   <w.rf>
    <LM>w#w-d1t1456-5</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m017-d1t1456-7">
   <w.rf>
    <LM>w#w-d1t1456-7</LM>
   </w.rf>
   <form>chytili</form>
   <lemma>chytit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d-m-d1e1447-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1447-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1466-x2">
  <m id="m017-d1t1469-4">
   <w.rf>
    <LM>w#w-d1t1469-4</LM>
   </w.rf>
   <form>Kamarád</form>
   <lemma>kamarád</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t1469-5">
   <w.rf>
    <LM>w#w-d1t1469-5</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1469-6">
   <w.rf>
    <LM>w#w-d1t1469-6</LM>
   </w.rf>
   <form>příhodu</form>
   <lemma>příhoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-id106357-punct">
   <w.rf>
    <LM>w#w-d-id106357-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1469-9">
   <w.rf>
    <LM>w#w-d1t1469-9</LM>
   </w.rf>
   <form>vdával</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1469-10">
   <w.rf>
    <LM>w#w-d1t1469-10</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t1471-1">
   <w.rf>
    <LM>w#w-d1t1471-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1471-2">
   <w.rf>
    <LM>w#w-d1t1471-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1471-3">
   <w.rf>
    <LM>w#w-d1t1471-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1471-4">
   <w.rf>
    <LM>w#w-d1t1471-4</LM>
   </w.rf>
   <form>prase</form>
   <lemma>prase</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m017-d1e1466-x2-34">
   <w.rf>
    <LM>w#w-d1e1466-x2-34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-36_2">
  <m id="m017-d1t1471-7">
   <w.rf>
    <LM>w#w-d1t1471-7</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1471-8">
   <w.rf>
    <LM>w#w-d1t1471-8</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1471-9">
   <w.rf>
    <LM>w#w-d1t1471-9</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m017-d1t1471-10">
   <w.rf>
    <LM>w#w-d1t1471-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t1471-15">
   <w.rf>
    <LM>w#w-d1t1471-15</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1473-1">
   <w.rf>
    <LM>w#w-d1t1473-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1473-3">
   <w.rf>
    <LM>w#w-d1t1473-3</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-36_2-60">
   <w.rf>
    <LM>w#w-36_2-60</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1473-11">
   <w.rf>
    <LM>w#w-d1t1473-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1473-12">
   <w.rf>
    <LM>w#w-d1t1473-12</LM>
   </w.rf>
   <form>káře</form>
   <lemma>kára</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d1t1473-14">
   <w.rf>
    <LM>w#w-d1t1473-14</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1473-15">
   <w.rf>
    <LM>w#w-d1t1473-15</LM>
   </w.rf>
   <form>půjčenou</form>
   <lemma>půjčený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m017-d1t1473-16">
   <w.rf>
    <LM>w#w-d1t1473-16</LM>
   </w.rf>
   <form>klec</form>
   <lemma>klec</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t1473-17">
   <w.rf>
    <LM>w#w-d1t1473-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1473-18">
   <w.rf>
    <LM>w#w-d1t1473-18</LM>
   </w.rf>
   <form>prase</form>
   <lemma>prase</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m017-36_2-305">
   <w.rf>
    <LM>w#w-36_2-305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-306">
  <m id="m017-d1t1473-22">
   <w.rf>
    <LM>w#w-d1t1473-22</LM>
   </w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1473-21">
   <w.rf>
    <LM>w#w-d1t1473-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1473-23">
   <w.rf>
    <LM>w#w-d1t1473-23</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d1t1473-24">
   <w.rf>
    <LM>w#w-d1t1473-24</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t1473-25">
   <w.rf>
    <LM>w#w-d1t1473-25</LM>
   </w.rf>
   <form>klece</form>
   <lemma>klec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m017-36-64">
   <w.rf>
    <LM>w#w-36-64</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-36-62">
   <w.rf>
    <LM>w#w-36-62</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1480-2">
   <w.rf>
    <LM>w#w-d1t1480-2</LM>
   </w.rf>
   <form>klec</form>
   <lemma>klec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t1480-3">
   <w.rf>
    <LM>w#w-d1t1480-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m017-d1t1480-4">
   <w.rf>
    <LM>w#w-d1t1480-4</LM>
   </w.rf>
   <form>chatrná</form>
   <lemma>chatrný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-36-66">
   <w.rf>
    <LM>w#w-36-66</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-68">
  <m id="m017-d1t1482-1">
   <w.rf>
    <LM>w#w-d1t1482-1</LM>
   </w.rf>
   <form>Najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1482-2">
   <w.rf>
    <LM>w#w-d1t1482-2</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-68-80">
   <w.rf>
    <LM>w#w-68-80</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-68-82">
   <w.rf>
    <LM>w#w-68-82</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1482-4">
   <w.rf>
    <LM>w#w-d1t1482-4</LM>
   </w.rf>
   <form>Počkej</form>
   <lemma>počkat</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m017-68-84">
   <w.rf>
    <LM>w#w-68-84</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1482-5">
   <w.rf>
    <LM>w#w-d1t1482-5</LM>
   </w.rf>
   <form>zastav</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m017-d-id107190-punct">
   <w.rf>
    <LM>w#w-d-id107190-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1482-7">
   <w.rf>
    <LM>w#w-d1t1482-7</LM>
   </w.rf>
   <form>podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m017-d1t1482-8">
   <w.rf>
    <LM>w#w-d1t1482-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-68-108">
   <w.rf>
    <LM>w#w-68-108</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1484-1">
   <w.rf>
    <LM>w#w-d1t1484-1</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1484-5">
   <w.rf>
    <LM>w#w-d1t1484-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1484-2">
   <w.rf>
    <LM>w#w-d1t1484-2</LM>
   </w.rf>
   <form>prase</form>
   <lemma>prase</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m017-d1t1484-6">
   <w.rf>
    <LM>w#w-d1t1484-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-68-104">
   <w.rf>
    <LM>w#w-68-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-68-106">
   <w.rf>
    <LM>w#w-68-106</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1466-x3">
  <m id="m017-d1t1484-10">
   <w.rf>
    <LM>w#w-d1t1484-10</LM>
   </w.rf>
   <form>Otevřeli</form>
   <lemma>otevřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d-id107360-punct">
   <w.rf>
    <LM>w#w-d-id107360-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1484-12">
   <w.rf>
    <LM>w#w-d1t1484-12</LM>
   </w.rf>
   <form>vylezli</form>
   <lemma>vylézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d1t1484-13">
   <w.rf>
    <LM>w#w-d1t1484-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t1484-14">
   <w.rf>
    <LM>w#w-d1t1484-14</LM>
   </w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m017-d-id107408-punct">
   <w.rf>
    <LM>w#w-d-id107408-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1488-1">
   <w.rf>
    <LM>w#w-d1t1488-1</LM>
   </w.rf>
   <form>klec</form>
   <lemma>klec</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t1488-2">
   <w.rf>
    <LM>w#w-d1t1488-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m017-d1t1488-3">
   <w.rf>
    <LM>w#w-d1t1488-3</LM>
   </w.rf>
   <form>rozbouraná</form>
   <lemma>rozbouraný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t1488-4">
   <w.rf>
    <LM>w#w-d1t1488-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1484-16">
   <w.rf>
    <LM>w#w-d1t1484-16</LM>
   </w.rf>
   <form>prase</form>
   <lemma>prase</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m017-d1t1484-17">
   <w.rf>
    <LM>w#w-d1t1484-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1484-18">
   <w.rf>
    <LM>w#w-d1t1484-18</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m017-d1e1466-x3-12">
   <w.rf>
    <LM>w#w-d1e1466-x3-12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1488-7">
   <w.rf>
    <LM>w#w-d1t1488-7</LM>
   </w.rf>
   <form>uteklo</form>
   <lemma>utéci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m017-d1t1488-6">
   <w.rf>
    <LM>w#w-d1t1488-6</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m017-d-id107576-punct">
   <w.rf>
    <LM>w#w-d-id107576-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1488-9">
   <w.rf>
    <LM>w#w-d1t1488-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1488-10">
   <w.rf>
    <LM>w#w-d1t1488-10</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t1488-11">
   <w.rf>
    <LM>w#w-d1t1488-11</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d1t1488-12">
   <w.rf>
    <LM>w#w-d1t1488-12</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m017-d1t1490-1">
   <w.rf>
    <LM>w#w-d1t1490-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1490-2">
   <w.rf>
    <LM>w#w-d1t1490-2</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d1t1490-3">
   <w.rf>
    <LM>w#w-d1t1490-3</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m017-d1e1466-x3-14">
   <w.rf>
    <LM>w#w-d1e1466-x3-14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-16">
  <m id="m017-d1t1490-7">
   <w.rf>
    <LM>w#w-d1t1490-7</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m017-d1t1490-8">
   <w.rf>
    <LM>w#w-d1t1490-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m017-d1t1490-9">
   <w.rf>
    <LM>w#w-d1t1490-9</LM>
   </w.rf>
   <form>pochutnal</form>
   <lemma>pochutnat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d-m-d1e1466-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1466-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1491-x3">
  <m id="m017-d1t1502-2">
   <w.rf>
    <LM>w#w-d1t1502-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1502-3">
   <w.rf>
    <LM>w#w-d1t1502-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1502-4">
   <w.rf>
    <LM>w#w-d1t1502-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m017-d1t1509-1">
   <w.rf>
    <LM>w#w-d1t1509-1</LM>
   </w.rf>
   <form>výjimečný</form>
   <lemma>výjimečný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m017-d1t1509-2">
   <w.rf>
    <LM>w#w-d1t1509-2</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1491-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1491-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1510-x2">
  <m id="m017-d1t1513-1">
   <w.rf>
    <LM>w#w-d1t1513-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m017-d1t1513-2">
   <w.rf>
    <LM>w#w-d1t1513-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m017-d1t1513-3">
   <w.rf>
    <LM>w#w-d1t1513-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t1513-4">
   <w.rf>
    <LM>w#w-d1t1513-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m017-d1t1513-5">
   <w.rf>
    <LM>w#w-d1t1513-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m017-d1t1513-6">
   <w.rf>
    <LM>w#w-d1t1513-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1513-7">
   <w.rf>
    <LM>w#w-d1t1513-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m017-d-id108164-punct">
   <w.rf>
    <LM>w#w-d-id108164-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1514-x2">
  <m id="m017-d1t1517-2">
   <w.rf>
    <LM>w#w-d1t1517-2</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1517-3">
   <w.rf>
    <LM>w#w-d1t1517-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d-m-d1e1514-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1514-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1518-x2">
  <m id="m017-d1t1521-1">
   <w.rf>
    <LM>w#w-d1t1521-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1e1518-x2-28">
   <w.rf>
    <LM>w#w-d1e1518-x2-28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1523-1">
   <w.rf>
    <LM>w#w-d1t1523-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1523-2">
   <w.rf>
    <LM>w#w-d1t1523-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1523-3">
   <w.rf>
    <LM>w#w-d1t1523-3</LM>
   </w.rf>
   <form>podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m017-d1t1523-4">
   <w.rf>
    <LM>w#w-d1t1523-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1e1518-x2-30">
   <w.rf>
    <LM>w#w-d1e1518-x2-30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-32">
  <m id="m017-d1t1525-1">
   <w.rf>
    <LM>w#w-d1t1525-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m017-d1t1525-2">
   <w.rf>
    <LM>w#w-d1t1525-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1525-3">
   <w.rf>
    <LM>w#w-d1t1525-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1525-4">
   <w.rf>
    <LM>w#w-d1t1525-4</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d-id108495-punct">
   <w.rf>
    <LM>w#w-d-id108495-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1526-x2">
  <m id="m017-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1531-4">
   <w.rf>
    <LM>w#w-d1t1531-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m017-d1t1531-6">
   <w.rf>
    <LM>w#w-d1t1531-6</LM>
   </w.rf>
   <form>motorák</form>
   <lemma>motorák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d1e1526-x2-328">
   <w.rf>
    <LM>w#w-d1e1526-x2-328</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-329">
  <m id="m017-d1t1531-14">
   <w.rf>
    <LM>w#w-d1t1531-14</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d1t1531-15">
   <w.rf>
    <LM>w#w-d1t1531-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1531-16">
   <w.rf>
    <LM>w#w-d1t1531-16</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1531-17">
   <w.rf>
    <LM>w#w-d1t1531-17</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m017-329-330">
   <w.rf>
    <LM>w#w-329-330</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-331">
  <m id="m017-d1t1535-1">
   <w.rf>
    <LM>w#w-d1t1535-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1535-2">
   <w.rf>
    <LM>w#w-d1t1535-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1535-3">
   <w.rf>
    <LM>w#w-d1t1535-3</LM>
   </w.rf>
   <form>focené</form>
   <lemma>focený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d1t1535-4">
   <w.rf>
    <LM>w#w-d1t1535-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1535-6">
   <w.rf>
    <LM>w#w-d1t1535-6</LM>
   </w.rf>
   <form>Orlíku</form>
   <lemma>Orlík_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-d1e1526-x2-50">
   <w.rf>
    <LM>w#w-d1e1526-x2-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-52">
  <m id="m017-d1t1535-10">
   <w.rf>
    <LM>w#w-d1t1535-10</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1535-11">
   <w.rf>
    <LM>w#w-d1t1535-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1535-12">
   <w.rf>
    <LM>w#w-d1t1535-12</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1537-1">
   <w.rf>
    <LM>w#w-d1t1537-1</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d1t1537-2">
   <w.rf>
    <LM>w#w-d1t1537-2</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1t1537-3">
   <w.rf>
    <LM>w#w-d1t1537-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1537-4">
   <w.rf>
    <LM>w#w-d1t1537-4</LM>
   </w.rf>
   <form>vodě</form>
   <lemma>voda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1526-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1526-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1538-x3">
  <m id="m017-d1t1547-1">
   <w.rf>
    <LM>w#w-d1t1547-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m017-d1t1547-2">
   <w.rf>
    <LM>w#w-d1t1547-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1547-3">
   <w.rf>
    <LM>w#w-d1t1547-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1547-4">
   <w.rf>
    <LM>w#w-d1t1547-4</LM>
   </w.rf>
   <form>motorák</form>
   <lemma>motorák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-id109169-punct">
   <w.rf>
    <LM>w#w-d-id109169-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1548-x2">
  <m id="m017-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1551-3">
   <w.rf>
    <LM>w#w-d1t1551-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1551-4">
   <w.rf>
    <LM>w#w-d1t1551-4</LM>
   </w.rf>
   <form>motorový</form>
   <lemma>motorový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m017-d1t1551-5">
   <w.rf>
    <LM>w#w-d1t1551-5</LM>
   </w.rf>
   <form>člun</form>
   <lemma>člun</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d1e1548-x2-130">
   <w.rf>
    <LM>w#w-d1e1548-x2-130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-132">
  <m id="m017-d1t1553-1">
   <w.rf>
    <LM>w#w-d1t1553-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1553-2">
   <w.rf>
    <LM>w#w-d1t1553-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1553-3">
   <w.rf>
    <LM>w#w-d1t1553-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m017-d1t1553-4">
   <w.rf>
    <LM>w#w-d1t1553-4</LM>
   </w.rf>
   <form>sedím</form>
   <lemma>sedět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d-id109466-punct">
   <w.rf>
    <LM>w#w-d-id109466-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1553-7">
   <w.rf>
    <LM>w#w-d1t1553-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1553-12">
   <w.rf>
    <LM>w#w-d1t1553-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1553-13">
   <w.rf>
    <LM>w#w-d1t1553-13</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t1555-1">
   <w.rf>
    <LM>w#w-d1t1555-1</LM>
   </w.rf>
   <form>motor</form>
   <lemma>motor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-132-22">
   <w.rf>
    <LM>w#w-132-22</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t1553-14">
   <w.rf>
    <LM>w#w-d1t1553-14</LM>
   </w.rf>
   <form>wartburga</form>
   <lemma>wartburg</lemma>
   <tag>NNIS4-----A---1</tag>
  </m>
  <m id="m017-132-346">
   <w.rf>
    <LM>w#w-132-346</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-347">
  <m id="m017-d1t1555-10">
   <w.rf>
    <LM>w#w-d1t1555-10</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1555-11">
   <w.rf>
    <LM>w#w-d1t1555-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1555-12">
   <w.rf>
    <LM>w#w-d1t1555-12</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1557-1">
   <w.rf>
    <LM>w#w-d1t1557-1</LM>
   </w.rf>
   <form>pracné</form>
   <lemma>pracný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d-id109779-punct">
   <w.rf>
    <LM>w#w-d-id109779-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1559-3">
   <w.rf>
    <LM>w#w-d1t1559-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1559-1">
   <w.rf>
    <LM>w#w-d1t1559-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1559-5">
   <w.rf>
    <LM>w#w-d1t1559-5</LM>
   </w.rf>
   <form>udělaná</form>
   <lemma>udělaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t1559-4">
   <w.rf>
    <LM>w#w-d1t1559-4</LM>
   </w.rf>
   <form>převodovka</form>
   <lemma>převodovka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t1562-1">
   <w.rf>
    <LM>w#w-d1t1562-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1562-3">
   <w.rf>
    <LM>w#w-d1t1562-3</LM>
   </w.rf>
   <form>náhony</form>
   <lemma>náhon</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m017-d1t1562-5">
   <w.rf>
    <LM>w#w-d1t1562-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1562-6">
   <w.rf>
    <LM>w#w-d1t1562-6</LM>
   </w.rf>
   <form>vrtuli</form>
   <lemma>vrtule</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t1562-7">
   <w.rf>
    <LM>w#w-d1t1562-7</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1562-9">
   <w.rf>
    <LM>w#w-d1t1562-9</LM>
   </w.rf>
   <form>kormidlo</form>
   <lemma>kormidlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m017-132-24">
   <w.rf>
    <LM>w#w-132-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-26">
  <m id="m017-d1t1564-9">
   <w.rf>
    <LM>w#w-d1t1564-9</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1564-10">
   <w.rf>
    <LM>w#w-d1t1564-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1564-11">
   <w.rf>
    <LM>w#w-d1t1564-11</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m017-d1t1564-12">
   <w.rf>
    <LM>w#w-d1t1564-12</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m017-d1t1564-13">
   <w.rf>
    <LM>w#w-d1t1564-13</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1548-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1548-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1567-x2">
  <m id="m017-d1t1570-2">
   <w.rf>
    <LM>w#w-d1t1570-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d1t1570-3">
   <w.rf>
    <LM>w#w-d1t1570-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t1570-4">
   <w.rf>
    <LM>w#w-d1t1570-4</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t1570-5">
   <w.rf>
    <LM>w#w-d1t1570-5</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m017-d-id110344-punct">
   <w.rf>
    <LM>w#w-d-id110344-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1571-x2">
  <m id="m017-d1t1574-1">
   <w.rf>
    <LM>w#w-d1t1574-1</LM>
   </w.rf>
   <form>Sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m017-d1e1571-x2-352">
   <w.rf>
    <LM>w#w-d1e1571-x2-352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-353">
  <m id="m017-d1t1576-1">
   <w.rf>
    <LM>w#w-d1t1576-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1576-3">
   <w.rf>
    <LM>w#w-d1t1576-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1576-4">
   <w.rf>
    <LM>w#w-d1t1576-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1576-2">
   <w.rf>
    <LM>w#w-d1t1576-2</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t1576-5">
   <w.rf>
    <LM>w#w-d1t1576-5</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m017-d-id110516-punct">
   <w.rf>
    <LM>w#w-d-id110516-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1576-7">
   <w.rf>
    <LM>w#w-d1t1576-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1576-8">
   <w.rf>
    <LM>w#w-d1t1576-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m017-d1t1576-9">
   <w.rf>
    <LM>w#w-d1t1576-9</LM>
   </w.rf>
   <form>pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d-m-d1e1571-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1571-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1578-x2">
  <m id="m017-d1t1581-1">
   <w.rf>
    <LM>w#w-d1t1581-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1581-2">
   <w.rf>
    <LM>w#w-d1t1581-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t1581-3">
   <w.rf>
    <LM>w#w-d1t1581-3</LM>
   </w.rf>
   <form>šikovný</form>
   <lemma>šikovný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m017-d-m-d1e1578-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1578-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1582-x2">
  <m id="m017-d1t1587-3">
   <w.rf>
    <LM>w#w-d1t1587-3</LM>
   </w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t1587-2">
   <w.rf>
    <LM>w#w-d1t1587-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1587-5">
   <w.rf>
    <LM>w#w-d1t1587-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1587-4">
   <w.rf>
    <LM>w#w-d1t1587-4</LM>
   </w.rf>
   <form>mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m017-d-m-d1e1582-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1582-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1588-x2">
  <m id="m017-d1t1591-1">
   <w.rf>
    <LM>w#w-d1t1591-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1591-3">
   <w.rf>
    <LM>w#w-d1t1591-3</LM>
   </w.rf>
   <form>Orlíku</form>
   <lemma>Orlík_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-d1t1591-5">
   <w.rf>
    <LM>w#w-d1t1591-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t1591-6">
   <w.rf>
    <LM>w#w-d1t1591-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t1591-7">
   <w.rf>
    <LM>w#w-d1t1591-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1591-8">
   <w.rf>
    <LM>w#w-d1t1591-8</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d-id110960-punct">
   <w.rf>
    <LM>w#w-d-id110960-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1588-x3">
  <m id="m017-d1t1595-4">
   <w.rf>
    <LM>w#w-d1t1595-4</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t1595-3">
   <w.rf>
    <LM>w#w-d1t1595-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1595-2">
   <w.rf>
    <LM>w#w-d1t1595-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id111073-punct">
   <w.rf>
    <LM>w#w-d-id111073-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1595-9">
   <w.rf>
    <LM>w#w-d1t1595-9</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m017-d1t1595-10">
   <w.rf>
    <LM>w#w-d1t1595-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t1595-11">
   <w.rf>
    <LM>w#w-d1t1595-11</LM>
   </w.rf>
   <form>kolikátého</form>
   <lemma>kolikátý</lemma>
   <tag>CwZS2----------</tag>
  </m>
  <m id="m017-d1t1595-12">
   <w.rf>
    <LM>w#w-d1t1595-12</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m017-d1e1588-x3-90">
   <w.rf>
    <LM>w#w-d1e1588-x3-90</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1595-13">
   <w.rf>
    <LM>w#w-d1t1595-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d1t1595-14">
   <w.rf>
    <LM>w#w-d1t1595-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1595-15">
   <w.rf>
    <LM>w#w-d1t1595-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m017-d1t1595-16">
   <w.rf>
    <LM>w#w-d1t1595-16</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m017-d1e1588-x3-364">
   <w.rf>
    <LM>w#w-d1e1588-x3-364</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-365">
  <m id="m017-d1t1597-7">
   <w.rf>
    <LM>w#w-d1t1597-7</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1597-8">
   <w.rf>
    <LM>w#w-d1t1597-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1597-9">
   <w.rf>
    <LM>w#w-d1t1597-9</LM>
   </w.rf>
   <form>nejezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m017-d1e1588-x3-94">
   <w.rf>
    <LM>w#w-d1e1588-x3-94</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1597-11">
   <w.rf>
    <LM>w#w-d1t1597-11</LM>
   </w.rf>
   <form>kdyžtak</form>
   <lemma>kdyžtak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1597-15">
   <w.rf>
    <LM>w#w-d1t1597-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1597-13">
   <w.rf>
    <LM>w#w-d1t1597-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1597-14">
   <w.rf>
    <LM>w#w-d1t1597-14</LM>
   </w.rf>
   <form>jedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1597-16">
   <w.rf>
    <LM>w#w-d1t1597-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1597-17">
   <w.rf>
    <LM>w#w-d1t1597-17</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m017-d1t1597-18">
   <w.rf>
    <LM>w#w-d1t1597-18</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d-id111430-punct">
   <w.rf>
    <LM>w#w-d-id111430-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1604-1">
   <w.rf>
    <LM>w#w-d1t1604-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1604-2">
   <w.rf>
    <LM>w#w-d1t1604-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1604-3">
   <w.rf>
    <LM>w#w-d1t1604-3</LM>
   </w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1e1588-x3-102">
   <w.rf>
    <LM>w#w-d1e1588-x3-102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1606-2">
   <w.rf>
    <LM>w#w-d1t1606-2</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1606-3">
   <w.rf>
    <LM>w#w-d1t1606-3</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1606-4">
   <w.rf>
    <LM>w#w-d1t1606-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t1606-5">
   <w.rf>
    <LM>w#w-d1t1606-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1606-6">
   <w.rf>
    <LM>w#w-d1t1606-6</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1e1588-x3-100">
   <w.rf>
    <LM>w#w-d1e1588-x3-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-98">
  <m id="m017-d1t1608-3">
   <w.rf>
    <LM>w#w-d1t1608-3</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t1608-4">
   <w.rf>
    <LM>w#w-d1t1608-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1608-5">
   <w.rf>
    <LM>w#w-d1t1608-5</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1608-6">
   <w.rf>
    <LM>w#w-d1t1608-6</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id111704-punct">
   <w.rf>
    <LM>w#w-d-id111704-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1610-1">
   <w.rf>
    <LM>w#w-d1t1610-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1610-2">
   <w.rf>
    <LM>w#w-d1t1610-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1610-3">
   <w.rf>
    <LM>w#w-d1t1610-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1610-4">
   <w.rf>
    <LM>w#w-d1t1610-4</LM>
   </w.rf>
   <form>partu</form>
   <lemma>parta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-98-373">
   <w.rf>
    <LM>w#w-98-373</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-372">
  <m id="m017-d1t1610-9">
   <w.rf>
    <LM>w#w-d1t1610-9</LM>
   </w.rf>
   <form>Kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m017-d1t1610-8">
   <w.rf>
    <LM>w#w-d1t1610-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1610-7">
   <w.rf>
    <LM>w#w-d1t1610-7</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1610-11">
   <w.rf>
    <LM>w#w-d1t1610-11</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m017-d1t1610-10">
   <w.rf>
    <LM>w#w-d1t1610-10</LM>
   </w.rf>
   <form>plachetnice</form>
   <lemma>plachetnice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m017-d-id111873-punct">
   <w.rf>
    <LM>w#w-d-id111873-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1610-13">
   <w.rf>
    <LM>w#w-d1t1610-13</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1610-14">
   <w.rf>
    <LM>w#w-d1t1610-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1610-15">
   <w.rf>
    <LM>w#w-d1t1610-15</LM>
   </w.rf>
   <form>motoráky</form>
   <lemma>motorák</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m017-98-126">
   <w.rf>
    <LM>w#w-98-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-128">
  <m id="m017-d1t1612-1">
   <w.rf>
    <LM>w#w-d1t1612-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1612-3">
   <w.rf>
    <LM>w#w-d1t1612-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1612-4">
   <w.rf>
    <LM>w#w-d1t1612-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1612-5">
   <w.rf>
    <LM>w#w-d1t1612-5</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1612-6">
   <w.rf>
    <LM>w#w-d1t1612-6</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-m-d1e1588-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1588-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1613-x2">
  <m id="m017-d1t1620-1">
   <w.rf>
    <LM>w#w-d1t1620-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t1620-2">
   <w.rf>
    <LM>w#w-d1t1620-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1620-3">
   <w.rf>
    <LM>w#w-d1t1620-3</LM>
   </w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-id112163-punct">
   <w.rf>
    <LM>w#w-d-id112163-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1621-x2">
  <m id="m017-d1t1628-1">
   <w.rf>
    <LM>w#w-d1t1628-1</LM>
   </w.rf>
   <form>Chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t1628-2">
   <w.rf>
    <LM>w#w-d1t1628-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1628-3">
   <w.rf>
    <LM>w#w-d1t1628-3</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m017-d-id112282-punct">
   <w.rf>
    <LM>w#w-d-id112282-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1628-5">
   <w.rf>
    <LM>w#w-d1t1628-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1628-6">
   <w.rf>
    <LM>w#w-d1t1628-6</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1628-7">
   <w.rf>
    <LM>w#w-d1t1628-7</LM>
   </w.rf>
   <form>přívěs</form>
   <lemma>přívěs</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d1e1621-x2-381">
   <w.rf>
    <LM>w#w-d1e1621-x2-381</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-382">
  <m id="m017-d1t1628-14">
   <w.rf>
    <LM>w#w-d1t1628-14</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1628-12">
   <w.rf>
    <LM>w#w-d1t1628-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1628-13">
   <w.rf>
    <LM>w#w-d1t1628-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1628-15">
   <w.rf>
    <LM>w#w-d1t1628-15</LM>
   </w.rf>
   <form>zatáhne</form>
   <lemma>zatáhnout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m017-d1t1628-18">
   <w.rf>
    <LM>w#w-d1t1628-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1628-20">
   <w.rf>
    <LM>w#w-d1t1628-20</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m017-d1t1628-21">
   <w.rf>
    <LM>w#w-d1t1628-21</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m017-d-id112521-punct">
   <w.rf>
    <LM>w#w-d-id112521-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1628-23">
   <w.rf>
    <LM>w#w-d1t1628-23</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m017-d1t1628-24">
   <w.rf>
    <LM>w#w-d1t1628-24</LM>
   </w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m017-d1e1621-x2-144">
   <w.rf>
    <LM>w#w-d1e1621-x2-144</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1628-25">
   <w.rf>
    <LM>w#w-d1t1628-25</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m017-d1t1628-26">
   <w.rf>
    <LM>w#w-d1t1628-26</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1628-27">
   <w.rf>
    <LM>w#w-d1t1628-27</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id112600-punct">
   <w.rf>
    <LM>w#w-d-id112600-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1630-1">
   <w.rf>
    <LM>w#w-d1t1630-1</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1630-2">
   <w.rf>
    <LM>w#w-d1t1630-2</LM>
   </w.rf>
   <form>vegetujou</form>
   <lemma>vegetovat</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m017-d1t1630-3">
   <w.rf>
    <LM>w#w-d1t1630-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1630-5">
   <w.rf>
    <LM>w#w-d1t1630-5</LM>
   </w.rf>
   <form>přívěsu</form>
   <lemma>přívěs</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1621-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1621-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1631-x2">
  <m id="m017-d1t1638-1">
   <w.rf>
    <LM>w#w-d1t1638-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1638-2">
   <w.rf>
    <LM>w#w-d1t1638-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1638-3">
   <w.rf>
    <LM>w#w-d1t1638-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1638-4">
   <w.rf>
    <LM>w#w-d1t1638-4</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d-id112843-punct">
   <w.rf>
    <LM>w#w-d-id112843-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1639-x2">
  <m id="m017-d1t1644-2">
   <w.rf>
    <LM>w#w-d1t1644-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1644-1">
   <w.rf>
    <LM>w#w-d1t1644-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1644-3">
   <w.rf>
    <LM>w#w-d1t1644-3</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d1t1644-4">
   <w.rf>
    <LM>w#w-d1t1644-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1644-8">
   <w.rf>
    <LM>w#w-d1t1644-8</LM>
   </w.rf>
   <form>Orlíku</form>
   <lemma>Orlík_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-d1t1644-10">
   <w.rf>
    <LM>w#w-d1t1644-10</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t1644-11">
   <w.rf>
    <LM>w#w-d1t1644-11</LM>
   </w.rf>
   <form>zámku</form>
   <lemma>zámek</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m017-d-id113050-punct">
   <w.rf>
    <LM>w#w-d-id113050-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1646-1">
   <w.rf>
    <LM>w#w-d1t1646-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1646-2">
   <w.rf>
    <LM>w#w-d1t1646-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t1646-3">
   <w.rf>
    <LM>w#w-d1t1646-3</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m017-d1t1646-4">
   <w.rf>
    <LM>w#w-d1t1646-4</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1639-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1639-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1647-x2">
  <m id="m017-d1t1654-1">
   <w.rf>
    <LM>w#w-d1t1654-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id113209-punct">
   <w.rf>
    <LM>w#w-d-id113209-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1655-x2">
  <m id="m017-d1t1660-1">
   <w.rf>
    <LM>w#w-d1t1660-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d1t1660-2">
   <w.rf>
    <LM>w#w-d1t1660-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m017-d1t1660-3">
   <w.rf>
    <LM>w#w-d1t1660-3</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m017-d1e1655-x2-395">
   <w.rf>
    <LM>w#w-d1e1655-x2-395</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-397">
  <m id="m017-d1t1664-1">
   <w.rf>
    <LM>w#w-d1t1664-1</LM>
   </w.rf>
   <form>Paměť</form>
   <lemma>paměť</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t1664-4">
   <w.rf>
    <LM>w#w-d1t1664-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1664-5">
   <w.rf>
    <LM>w#w-d1t1664-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1e1655-x2-170">
   <w.rf>
    <LM>w#w-d1e1655-x2-170</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1664-2">
   <w.rf>
    <LM>w#w-d1t1664-2</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1664-3">
   <w.rf>
    <LM>w#w-d1t1664-3</LM>
   </w.rf>
   <form>nesahá</form>
   <lemma>sahat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d-id113488-punct">
   <w.rf>
    <LM>w#w-d-id113488-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1666-1">
   <w.rf>
    <LM>w#w-d1t1666-1</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m017-d1t1666-3">
   <w.rf>
    <LM>w#w-d1t1666-3</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1666-4">
   <w.rf>
    <LM>w#w-d1t1666-4</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1666-5">
   <w.rf>
    <LM>w#w-d1t1666-5</LM>
   </w.rf>
   <form>datum</form>
   <lemma>datum-1_^(kalendářní)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m017-d1e1655-x2-172">
   <w.rf>
    <LM>w#w-d1e1655-x2-172</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1666-6">
   <w.rf>
    <LM>w#w-d1t1666-6</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1666-7">
   <w.rf>
    <LM>w#w-d1t1666-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1666-8">
   <w.rf>
    <LM>w#w-d1t1666-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d-id113629-punct">
   <w.rf>
    <LM>w#w-d-id113629-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1666-10">
   <w.rf>
    <LM>w#w-d1t1666-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1669-4">
   <w.rf>
    <LM>w#w-d1t1669-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1669-5">
   <w.rf>
    <LM>w#w-d1t1669-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1669-6">
   <w.rf>
    <LM>w#w-d1t1669-6</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t1669-7">
   <w.rf>
    <LM>w#w-d1t1669-7</LM>
   </w.rf>
   <form>nějakými</form>
   <lemma>nějaký</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m017-d1t1669-8">
   <w.rf>
    <LM>w#w-d1t1669-8</LM>
   </w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m017-d1t1669-9">
   <w.rf>
    <LM>w#w-d1t1669-9</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m017-d-id113788-punct">
   <w.rf>
    <LM>w#w-d-id113788-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1669-11">
   <w.rf>
    <LM>w#w-d1t1669-11</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1669-12">
   <w.rf>
    <LM>w#w-d1t1669-12</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1669-13">
   <w.rf>
    <LM>w#w-d1t1669-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1669-15">
   <w.rf>
    <LM>w#w-d1t1669-15</LM>
   </w.rf>
   <form>motorák</form>
   <lemma>motorák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d1t1669-16">
   <w.rf>
    <LM>w#w-d1t1669-16</LM>
   </w.rf>
   <form>předělával</form>
   <lemma>předělávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-397-398">
   <w.rf>
    <LM>w#w-397-398</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-399">
  <m id="m017-d1t1677-1">
   <w.rf>
    <LM>w#w-d1t1677-1</LM>
   </w.rf>
   <form>Dával</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1677-2">
   <w.rf>
    <LM>w#w-d1t1677-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1677-3">
   <w.rf>
    <LM>w#w-d1t1677-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1677-4">
   <w.rf>
    <LM>w#w-d1t1677-4</LM>
   </w.rf>
   <form>závěsný</form>
   <lemma>závěsný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m017-d1t1677-5">
   <w.rf>
    <LM>w#w-d1t1677-5</LM>
   </w.rf>
   <form>motor</form>
   <lemma>motor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1672-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1672-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1684-x2">
  <m id="m017-d1t1687-10">
   <w.rf>
    <LM>w#w-d1t1687-10</LM>
   </w.rf>
   <form>Může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1687-9">
   <w.rf>
    <LM>w#w-d1t1687-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1687-11">
   <w.rf>
    <LM>w#w-d1t1687-11</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1t1687-3">
   <w.rf>
    <LM>w#w-d1t1687-3</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t1687-4">
   <w.rf>
    <LM>w#w-d1t1687-4</LM>
   </w.rf>
   <form>nějakými</form>
   <lemma>nějaký</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m017-d1t1687-5">
   <w.rf>
    <LM>w#w-d1t1687-5</LM>
   </w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m017-d-id114185-punct">
   <w.rf>
    <LM>w#w-d-id114185-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1687-7">
   <w.rf>
    <LM>w#w-d1t1687-7</LM>
   </w.rf>
   <form>dvanácti</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m017-d1t1687-8">
   <w.rf>
    <LM>w#w-d1t1687-8</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m017-d-m-d1e1684-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1684-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1689-x2">
  <m id="m017-d1t1692-1">
   <w.rf>
    <LM>w#w-d1t1692-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1e1689-x2-192">
   <w.rf>
    <LM>w#w-d1e1689-x2-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-194">
  <m id="m017-d1t1694-2">
   <w.rf>
    <LM>w#w-d1t1694-2</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t1694-3">
   <w.rf>
    <LM>w#w-d1t1694-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t1694-4">
   <w.rf>
    <LM>w#w-d1t1694-4</LM>
   </w.rf>
   <form>vodních</form>
   <lemma>vodní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m017-d1t1694-5">
   <w.rf>
    <LM>w#w-d1t1694-5</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m017-d-id114433-punct">
   <w.rf>
    <LM>w#w-d-id114433-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1695-x2">
  <m id="m017-d1t1702-1">
   <w.rf>
    <LM>w#w-d1t1702-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m017-d1t1702-2">
   <w.rf>
    <LM>w#w-d1t1702-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1e1695-x2-413">
   <w.rf>
    <LM>w#w-d1e1695-x2-413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-414">
  <m id="m017-d1t1702-5">
   <w.rf>
    <LM>w#w-d1t1702-5</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t1702-6">
   <w.rf>
    <LM>w#w-d1t1702-6</LM>
   </w.rf>
   <form>mou</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1------1</tag>
  </m>
  <m id="m017-d1t1702-7">
   <w.rf>
    <LM>w#w-d1t1702-7</LM>
   </w.rf>
   <form>váhu</form>
   <lemma>váha_^(na_vážení;_hmotnost)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t1702-9">
   <w.rf>
    <LM>w#w-d1t1702-9</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m017-d1t1702-8">
   <w.rf>
    <LM>w#w-d1t1702-8</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t1702-10">
   <w.rf>
    <LM>w#w-d1t1702-10</LM>
   </w.rf>
   <form>potřeboval</form>
   <lemma>potřebovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t1702-13">
   <w.rf>
    <LM>w#w-d1t1702-13</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1702-14">
   <w.rf>
    <LM>w#w-d1t1702-14</LM>
   </w.rf>
   <form>široké</form>
   <lemma>široký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m017-d1t1702-12">
   <w.rf>
    <LM>w#w-d1t1702-12</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m017-d-id114724-punct">
   <w.rf>
    <LM>w#w-d-id114724-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1702-16">
   <w.rf>
    <LM>w#w-d1t1702-16</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1710-1">
   <w.rf>
    <LM>w#w-d1t1710-1</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1710-2">
   <w.rf>
    <LM>w#w-d1t1710-2</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1e1695-x2-214">
   <w.rf>
    <LM>w#w-d1e1695-x2-214</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1722-3">
   <w.rf>
    <LM>w#w-d1t1722-3</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1722-2">
   <w.rf>
    <LM>w#w-d1t1722-2</LM>
   </w.rf>
   <form>vnuci</form>
   <lemma>vnuk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m017-d1t1724-5">
   <w.rf>
    <LM>w#w-d1t1724-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1724-6">
   <w.rf>
    <LM>w#w-d1t1724-6</LM>
   </w.rf>
   <form>snacha</form>
   <lemma>snacha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t1724-8">
   <w.rf>
    <LM>w#w-d1t1724-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1724-7">
   <w.rf>
    <LM>w#w-d1t1724-7</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d-m-d1e1695-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1695-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1727-x2">
  <m id="m017-d1t1732-1">
   <w.rf>
    <LM>w#w-d1t1732-1</LM>
   </w.rf>
   <form>Využívají</form>
   <lemma>využívat_^(*3t)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1732-2">
   <w.rf>
    <LM>w#w-d1t1732-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d-id115283-punct">
   <w.rf>
    <LM>w#w-d-id115283-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1732-7">
   <w.rf>
    <LM>w#w-d1t1732-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1732-5">
   <w.rf>
    <LM>w#w-d1t1732-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1732-6">
   <w.rf>
    <LM>w#w-d1t1732-6</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1732-8">
   <w.rf>
    <LM>w#w-d1t1732-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1e1727-x2-220">
   <w.rf>
    <LM>w#w-d1e1727-x2-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1e1727-x2-222">
   <w.rf>
    <LM>w#w-d1e1727-x2-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1e1727-x2-224">
   <w.rf>
    <LM>w#w-d1e1727-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1727-x3">
  <m id="m017-d1t1736-1">
   <w.rf>
    <LM>w#w-d1t1736-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1736-2">
   <w.rf>
    <LM>w#w-d1t1736-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t1736-3">
   <w.rf>
    <LM>w#w-d1t1736-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1736-4">
   <w.rf>
    <LM>w#w-d1t1736-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1736-5">
   <w.rf>
    <LM>w#w-d1t1736-5</LM>
   </w.rf>
   <form>nevidí</form>
   <lemma>vidět</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d-m-d1e1727-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1727-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1737-x2">
  <m id="m017-d1t1740-2">
   <w.rf>
    <LM>w#w-d1t1740-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1740-3">
   <w.rf>
    <LM>w#w-d1t1740-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1740-4">
   <w.rf>
    <LM>w#w-d1t1740-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1740-6">
   <w.rf>
    <LM>w#w-d1t1740-6</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t1740-5">
   <w.rf>
    <LM>w#w-d1t1740-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t1740-7">
   <w.rf>
    <LM>w#w-d1t1740-7</LM>
   </w.rf>
   <form>drahá</form>
   <lemma>drahý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t1740-8">
   <w.rf>
    <LM>w#w-d1t1740-8</LM>
   </w.rf>
   <form>záležitost</form>
   <lemma>záležitost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d-id115595-punct">
   <w.rf>
    <LM>w#w-d-id115595-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1740-10">
   <w.rf>
    <LM>w#w-d1t1740-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t1740-12">
   <w.rf>
    <LM>w#w-d1t1740-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1740-13">
   <w.rf>
    <LM>w#w-d1t1740-13</LM>
   </w.rf>
   <form>drahý</form>
   <lemma>drahý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m017-d1t1740-14">
   <w.rf>
    <LM>w#w-d1t1740-14</LM>
   </w.rf>
   <form>benzín</form>
   <lemma>benzín</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-id115674-punct">
   <w.rf>
    <LM>w#w-d-id115674-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t1742-4">
   <w.rf>
    <LM>w#w-d1t1742-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t1742-5">
   <w.rf>
    <LM>w#w-d1t1742-5</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1742-6">
   <w.rf>
    <LM>w#w-d1t1742-6</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d-m-d1e1737-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1737-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e1743-x2">
  <m id="m017-d1t1746-1">
   <w.rf>
    <LM>w#w-d1t1746-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t1746-2">
   <w.rf>
    <LM>w#w-d1t1746-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t1746-3">
   <w.rf>
    <LM>w#w-d1t1746-3</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d-id115893-punct">
   <w.rf>
    <LM>w#w-d-id115893-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
