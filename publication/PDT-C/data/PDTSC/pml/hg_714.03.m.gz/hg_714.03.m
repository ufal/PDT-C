<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_714.03.w.gz" />
  </references>
 </head>
 <s id="m714-26171_04-2542">
  <m id="m714-d1t601-3">
   <w.rf>
    <LM>w#w-d1t601-3</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t601-2">
   <w.rf>
    <LM>w#w-d1t601-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m714-d1t601-4">
   <w.rf>
    <LM>w#w-d1t601-4</LM>
   </w.rf>
   <form>zplnoletnit</form>
   <lemma>zplnoletnit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d-id90364">
   <w.rf>
    <LM>w#w-d-id90364</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t601-6">
   <w.rf>
    <LM>w#w-d1t601-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t601-7">
   <w.rf>
    <LM>w#w-d1t601-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t601-9">
   <w.rf>
    <LM>w#w-d1t601-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t601-8">
   <w.rf>
    <LM>w#w-d1t601-8</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m714-d1t601-10">
   <w.rf>
    <LM>w#w-d1t601-10</LM>
   </w.rf>
   <form>plnoletá</form>
   <lemma>plnoletý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-2542-2552">
   <w.rf>
    <LM>w#w-2542-2552</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t603-1">
   <w.rf>
    <LM>w#w-d1t603-1</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t603-2">
   <w.rf>
    <LM>w#w-d1t603-2</LM>
   </w.rf>
   <form>scházel</form>
   <lemma>scházet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t603-4">
   <w.rf>
    <LM>w#w-d1t603-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t603-5">
   <w.rf>
    <LM>w#w-d1t603-5</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m714-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m714-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-2542-222">
   <w.rf>
    <LM>w#w-2542-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-224">
  <m id="m714-d1t607-7">
   <w.rf>
    <LM>w#w-d1t607-7</LM>
   </w.rf>
   <form>Vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t607-5">
   <w.rf>
    <LM>w#w-d1t607-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t607-6">
   <w.rf>
    <LM>w#w-d1t607-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t607-8">
   <w.rf>
    <LM>w#w-d1t607-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t607-9">
   <w.rf>
    <LM>w#w-d1t607-9</LM>
   </w.rf>
   <form>červenci</form>
   <lemma>červenec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t607-10">
   <w.rf>
    <LM>w#w-d1t607-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t607-13">
   <w.rf>
    <LM>w#w-d1t607-13</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t607-11">
   <w.rf>
    <LM>w#w-d1t607-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t607-12">
   <w.rf>
    <LM>w#w-d1t607-12</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m714-d1t607-14">
   <w.rf>
    <LM>w#w-d1t607-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t607-15">
   <w.rf>
    <LM>w#w-d1t607-15</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t607-16">
   <w.rf>
    <LM>w#w-d1t607-16</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m714-d-id90791">
   <w.rf>
    <LM>w#w-d-id90791</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x59">
  <m id="m714-d1t612-6">
   <w.rf>
    <LM>w#w-d1t612-6</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t612-5">
   <w.rf>
    <LM>w#w-d1t612-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t612-7">
   <w.rf>
    <LM>w#w-d1t612-7</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t614-1">
   <w.rf>
    <LM>w#w-d1t614-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1e24-x59-2751">
   <w.rf>
    <LM>w#w-d1e24-x59-2751</LM>
   </w.rf>
   <form>garsonce</form>
   <lemma>garsonka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1e24-x59-2746">
   <w.rf>
    <LM>w#w-d1e24-x59-2746</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t616-1">
   <w.rf>
    <LM>w#w-d1t616-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t616-2">
   <w.rf>
    <LM>w#w-d1t616-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t616-5">
   <w.rf>
    <LM>w#w-d1t616-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t616-3">
   <w.rf>
    <LM>w#w-d1t616-3</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t616-4">
   <w.rf>
    <LM>w#w-d1t616-4</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-d1t616-6">
   <w.rf>
    <LM>w#w-d1t616-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t616-7">
   <w.rf>
    <LM>w#w-d1t616-7</LM>
   </w.rf>
   <form>dítětem</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m714-d1t616-9">
   <w.rf>
    <LM>w#w-d1t616-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t616-10">
   <w.rf>
    <LM>w#w-d1t616-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t616-12">
   <w.rf>
    <LM>w#w-d1t616-12</LM>
   </w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m714-d1t616-11">
   <w.rf>
    <LM>w#w-d1t616-11</LM>
   </w.rf>
   <form>psem</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m714-d1e24-x59-237">
   <w.rf>
    <LM>w#w-d1e24-x59-237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-238">
  <m id="m714-d1t618-3">
   <w.rf>
    <LM>w#w-d1t618-3</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m714-d1t618-4">
   <w.rf>
    <LM>w#w-d1t618-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t618-5">
   <w.rf>
    <LM>w#w-d1t618-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t618-1">
   <w.rf>
    <LM>w#w-d1t618-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t618-6">
   <w.rf>
    <LM>w#w-d1t618-6</LM>
   </w.rf>
   <form>sehnali</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-238-239">
   <w.rf>
    <LM>w#w-238-239</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-241">
  <m id="m714-d1t620-4">
   <w.rf>
    <LM>w#w-d1t620-4</LM>
   </w.rf>
   <form>Sehnali</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-241-242">
   <w.rf>
    <LM>w#w-241-242</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t620-5">
   <w.rf>
    <LM>w#w-d1t620-5</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t620-6">
   <w.rf>
    <LM>w#w-d1t620-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t620-7">
   <w.rf>
    <LM>w#w-d1t620-7</LM>
   </w.rf>
   <form>Štěpánské</form>
   <lemma>štěpánský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-d1e24-x59-2757">
   <w.rf>
    <LM>w#w-d1e24-x59-2757</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t623-2">
   <w.rf>
    <LM>w#w-d1t623-2</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t623-3">
   <w.rf>
    <LM>w#w-d1t623-3</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tří`3</lemma>
   <tag>S2--------A----</tag>
  </m>
  <m id="m714-241-305">
   <w.rf>
    <LM>w#w-241-305</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t623-4">
   <w.rf>
    <LM>w#w-d1t623-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t623-5">
   <w.rf>
    <LM>w#w-d1t623-5</LM>
   </w.rf>
   <form>čtyřpokojový</form>
   <lemma>čtyřpokojový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m714-d1t623-7">
   <w.rf>
    <LM>w#w-d1t623-7</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-241-243">
   <w.rf>
    <LM>w#w-241-243</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-244">
  <m id="m714-d1t623-8">
   <w.rf>
    <LM>w#w-d1t623-8</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t623-9">
   <w.rf>
    <LM>w#w-d1t623-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t623-10">
   <w.rf>
    <LM>w#w-d1t623-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t623-11">
   <w.rf>
    <LM>w#w-d1t623-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t623-21">
   <w.rf>
    <LM>w#w-d1t623-21</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m714-d1t623-22">
   <w.rf>
    <LM>w#w-d1t623-22</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t623-23">
   <w.rf>
    <LM>w#w-d1t623-23</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t623-20">
   <w.rf>
    <LM>w#w-d1t623-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t623-13">
   <w.rf>
    <LM>w#w-d1t623-13</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m714-d1t623-14">
   <w.rf>
    <LM>w#w-d1t623-14</LM>
   </w.rf>
   <form>samotné</form>
   <lemma>samotný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m714-d1t623-15">
   <w.rf>
    <LM>w#w-d1t623-15</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-d1t623-16">
   <w.rf>
    <LM>w#w-d1t623-16</LM>
   </w.rf>
   <form>bydlely</form>
   <lemma>bydlet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t623-17">
   <w.rf>
    <LM>w#w-d1t623-17</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m714-d1t623-18">
   <w.rf>
    <LM>w#w-d1t623-18</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP6----------</tag>
  </m>
  <m id="m714-d1t623-19">
   <w.rf>
    <LM>w#w-d1t623-19</LM>
   </w.rf>
   <form>pokojích</form>
   <lemma>pokoj</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m714-d-id91774">
   <w.rf>
    <LM>w#w-d-id91774</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x60">
  <m id="m714-d1t625-1">
   <w.rf>
    <LM>w#w-d1t625-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m714-d1t625-2">
   <w.rf>
    <LM>w#w-d1t625-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t625-3">
   <w.rf>
    <LM>w#w-d1t625-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t625-4">
   <w.rf>
    <LM>w#w-d1t625-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m714-d1t625-5">
   <w.rf>
    <LM>w#w-d1t625-5</LM>
   </w.rf>
   <form>pokoje</form>
   <lemma>pokoj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1t625-6">
   <w.rf>
    <LM>w#w-d1t625-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t625-7">
   <w.rf>
    <LM>w#w-d1t625-7</LM>
   </w.rf>
   <form>ony</form>
   <lemma>onen</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m714-d1t625-8">
   <w.rf>
    <LM>w#w-d1t625-8</LM>
   </w.rf>
   <form>každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d1t625-9">
   <w.rf>
    <LM>w#w-d1t625-9</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m714-d1t625-10">
   <w.rf>
    <LM>w#w-d1t625-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t625-11">
   <w.rf>
    <LM>w#w-d1t625-11</LM>
   </w.rf>
   <form>společnou</form>
   <lemma>společný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m714-d1t625-12">
   <w.rf>
    <LM>w#w-d1t625-12</LM>
   </w.rf>
   <form>kuchyň</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d-id91971">
   <w.rf>
    <LM>w#w-d-id91971</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x61">
  <m id="m714-d1t631-5">
   <w.rf>
    <LM>w#w-d1t631-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t631-4">
   <w.rf>
    <LM>w#w-d1t631-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t631-6">
   <w.rf>
    <LM>w#w-d1t631-6</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t631-7">
   <w.rf>
    <LM>w#w-d1t631-7</LM>
   </w.rf>
   <form>určitou</form>
   <lemma>určitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m714-d1t631-8">
   <w.rf>
    <LM>w#w-d1t631-8</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d-id92130">
   <w.rf>
    <LM>w#w-d-id92130</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t631-10">
   <w.rf>
    <LM>w#w-d1t631-10</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t631-11">
   <w.rf>
    <LM>w#w-d1t631-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t631-12">
   <w.rf>
    <LM>w#w-d1t631-12</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d1t631-19">
   <w.rf>
    <LM>w#w-d1t631-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t631-13">
   <w.rf>
    <LM>w#w-d1t631-13</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m714-d1t631-14">
   <w.rf>
    <LM>w#w-d1t631-14</LM>
   </w.rf>
   <form>vyměnit</form>
   <lemma>vyměnit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1e24-x61-3073">
   <w.rf>
    <LM>w#w-d1e24-x61-3073</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t631-15">
   <w.rf>
    <LM>w#w-d1t631-15</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1t631-16">
   <w.rf>
    <LM>w#w-d1t631-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t631-17">
   <w.rf>
    <LM>w#w-d1t631-17</LM>
   </w.rf>
   <form>jakým</form>
   <lemma>jaký</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m714-d1t631-18">
   <w.rf>
    <LM>w#w-d1t631-18</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m714-d1e24-x61-3075">
   <w.rf>
    <LM>w#w-d1e24-x61-3075</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t631-20">
   <w.rf>
    <LM>w#w-d1t631-20</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t631-21">
   <w.rf>
    <LM>w#w-d1t631-21</LM>
   </w.rf>
   <form>domovnický</form>
   <lemma>domovnický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m714-d1t631-22">
   <w.rf>
    <LM>w#w-d1t631-22</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t631-23">
   <w.rf>
    <LM>w#w-d1t631-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t631-24">
   <w.rf>
    <LM>w#w-d1t631-24</LM>
   </w.rf>
   <form>Havelské</form>
   <lemma>havelský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-d1e24-x61-259">
   <w.rf>
    <LM>w#w-d1e24-x61-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-260">
  <m id="m714-d1t633-1">
   <w.rf>
    <LM>w#w-d1t633-1</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t633-2">
   <w.rf>
    <LM>w#w-d1t633-2</LM>
   </w.rf>
   <form>domovnický</form>
   <lemma>domovnický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t633-3">
   <w.rf>
    <LM>w#w-d1t633-3</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1t633-4">
   <w.rf>
    <LM>w#w-d1t633-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m714-d1t633-5">
   <w.rf>
    <LM>w#w-d1t633-5</LM>
   </w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrNS6----------</tag>
  </m>
  <m id="m714-d1t633-6">
   <w.rf>
    <LM>w#w-d1t633-6</LM>
   </w.rf>
   <form>poschodí</form>
   <lemma>poschodí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m714-260-261">
   <w.rf>
    <LM>w#w-260-261</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t636-2">
   <w.rf>
    <LM>w#w-d1t636-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m714-d-id92514">
   <w.rf>
    <LM>w#w-d-id92514</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t636-9">
   <w.rf>
    <LM>w#w-d1t636-9</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-d1t636-11">
   <w.rf>
    <LM>w#w-d1t636-11</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m714-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>domovnictví</form>
   <lemma>domovnictví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d1t636-12">
   <w.rf>
    <LM>w#w-d1t636-12</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d-id92663">
   <w.rf>
    <LM>w#w-d-id92663</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t638-1">
   <w.rf>
    <LM>w#w-d1t638-1</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m714-d1t638-2">
   <w.rf>
    <LM>w#w-d1t638-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t638-3">
   <w.rf>
    <LM>w#w-d1t638-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t638-4">
   <w.rf>
    <LM>w#w-d1t638-4</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m714-d1t638-5">
   <w.rf>
    <LM>w#w-d1t638-5</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-260-262">
   <w.rf>
    <LM>w#w-260-262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-263">
  <m id="m714-d1t638-9">
   <w.rf>
    <LM>w#w-d1t638-9</LM>
   </w.rf>
   <form>Vybírala</form>
   <lemma>vybírat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t638-8">
   <w.rf>
    <LM>w#w-d1t638-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t638-10">
   <w.rf>
    <LM>w#w-d1t638-10</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1t638-11">
   <w.rf>
    <LM>w#w-d1t638-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t638-12">
   <w.rf>
    <LM>w#w-d1t638-12</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m714-d1t638-13">
   <w.rf>
    <LM>w#w-d1t638-13</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m714-d1t638-14">
   <w.rf>
    <LM>w#w-d1t638-14</LM>
   </w.rf>
   <form>domovnický</form>
   <lemma>domovnický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t638-15">
   <w.rf>
    <LM>w#w-d1t638-15</LM>
   </w.rf>
   <form>plat</form>
   <lemma>plat_^(mzda)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1t642-1">
   <w.rf>
    <LM>w#w-d1t642-1</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t638-17">
   <w.rf>
    <LM>w#w-d1t638-17</LM>
   </w.rf>
   <form>de</form>
   <lemma>de-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m714-d1t638-18">
   <w.rf>
    <LM>w#w-d1t638-18</LM>
   </w.rf>
   <form>facto</form>
   <lemma>facto-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m714-d1t642-3">
   <w.rf>
    <LM>w#w-d1t642-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t642-4">
   <w.rf>
    <LM>w#w-d1t642-4</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m714-d1t642-5">
   <w.rf>
    <LM>w#w-d1t642-5</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d-id93054">
   <w.rf>
    <LM>w#w-d-id93054</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x62">
  <m id="m714-d1t644-3">
   <w.rf>
    <LM>w#w-d1t644-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t646-2">
   <w.rf>
    <LM>w#w-d1t646-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>splašili</form>
   <lemma>splašit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x62-3226">
   <w.rf>
    <LM>w#w-d1e24-x62-3226</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t646-5">
   <w.rf>
    <LM>w#w-d1t646-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t646-6">
   <w.rf>
    <LM>w#w-d1t646-6</LM>
   </w.rf>
   <form>utečeme</form>
   <lemma>utéci</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d-id93226">
   <w.rf>
    <LM>w#w-d-id93226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x63">
  <m id="m714-d1t653-7">
   <w.rf>
    <LM>w#w-d1t653-7</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t653-9">
   <w.rf>
    <LM>w#w-d1t653-9</LM>
   </w.rf>
   <form>Štěpánské</form>
   <lemma>štěpánský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-d1t653-11">
   <w.rf>
    <LM>w#w-d1t653-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t653-10">
   <w.rf>
    <LM>w#w-d1t653-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t653-12">
   <w.rf>
    <LM>w#w-d1t653-12</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t653-13">
   <w.rf>
    <LM>w#w-d1t653-13</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d-id93470">
   <w.rf>
    <LM>w#w-d-id93470</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t653-15">
   <w.rf>
    <LM>w#w-d1t653-15</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m714-d1t653-16">
   <w.rf>
    <LM>w#w-d1t653-16</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d-id93509">
   <w.rf>
    <LM>w#w-d-id93509</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t653-18">
   <w.rf>
    <LM>w#w-d1t653-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1e24-x63-282">
   <w.rf>
    <LM>w#w-d1e24-x63-282</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m714-d1t653-19">
   <w.rf>
    <LM>w#w-d1t653-19</LM>
   </w.rf>
   <form>1949</form>
   <lemma>1949</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m714-d1e24-x63-283">
   <w.rf>
    <LM>w#w-d1e24-x63-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-284">
  <m id="m714-d1t655-5">
   <w.rf>
    <LM>w#w-d1t655-5</LM>
   </w.rf>
   <form>Domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t655-3">
   <w.rf>
    <LM>w#w-d1t655-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t655-4">
   <w.rf>
    <LM>w#w-d1t655-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1e24-x63-3362">
   <w.rf>
    <LM>w#w-d1e24-x63-3362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t655-7">
   <w.rf>
    <LM>w#w-d1t655-7</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1t655-8">
   <w.rf>
    <LM>w#w-d1t655-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t655-9">
   <w.rf>
    <LM>w#w-d1t655-9</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-284-285">
   <w.rf>
    <LM>w#w-284-285</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-284-286">
   <w.rf>
    <LM>w#w-284-286</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t655-10">
   <w.rf>
    <LM>w#w-d1t655-10</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-284-288">
   <w.rf>
    <LM>w#w-284-288</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-284-287">
   <w.rf>
    <LM>w#w-284-287</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-289">
  <m id="m714-d1t659-1">
   <w.rf>
    <LM>w#w-d1t659-1</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t659-2">
   <w.rf>
    <LM>w#w-d1t659-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t659-3">
   <w.rf>
    <LM>w#w-d1t659-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t659-4">
   <w.rf>
    <LM>w#w-d1t659-4</LM>
   </w.rf>
   <form>nevěděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m714-d-id93796">
   <w.rf>
    <LM>w#w-d-id93796</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t659-6">
   <w.rf>
    <LM>w#w-d1t659-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t659-7">
   <w.rf>
    <LM>w#w-d1t659-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t659-8">
   <w.rf>
    <LM>w#w-d1t659-8</LM>
   </w.rf>
   <form>uděláme</form>
   <lemma>udělat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t659-9">
   <w.rf>
    <LM>w#w-d1t659-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m714-d1t659-10">
   <w.rf>
    <LM>w#w-d1t659-10</LM>
   </w.rf>
   <form>psem</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m714-d-id93882">
   <w.rf>
    <LM>w#w-d-id93882</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t659-12">
   <w.rf>
    <LM>w#w-d1t659-12</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t659-13">
   <w.rf>
    <LM>w#w-d1t659-13</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m714-d1t659-14">
   <w.rf>
    <LM>w#w-d1t659-14</LM>
   </w.rf>
   <form>moct</form>
   <lemma>moci</lemma>
   <tag>Vf--------A-I-1</tag>
  </m>
  <m id="m714-d1t659-16">
   <w.rf>
    <LM>w#w-d1t659-16</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t659-17">
   <w.rf>
    <LM>w#w-d1t659-17</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t659-18">
   <w.rf>
    <LM>w#w-d1t659-18</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m714-d1t659-19">
   <w.rf>
    <LM>w#w-d1t659-19</LM>
   </w.rf>
   <form>moct</form>
   <lemma>moci</lemma>
   <tag>Vf--------A-I-1</tag>
  </m>
  <m id="m714-d1t659-21">
   <w.rf>
    <LM>w#w-d1t659-21</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1e24-x63-3371">
   <w.rf>
    <LM>w#w-d1e24-x63-3371</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1e24-x63-3372">
   <w.rf>
    <LM>w#w-d1e24-x63-3372</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m714-d-id94040">
   <w.rf>
    <LM>w#w-d-id94040</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x64">
  <m id="m714-d1t664-2">
   <w.rf>
    <LM>w#w-d1t664-2</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t664-3">
   <w.rf>
    <LM>w#w-d1t664-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t664-4">
   <w.rf>
    <LM>w#w-d1t664-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t664-5">
   <w.rf>
    <LM>w#w-d1t664-5</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m714-d1t664-6">
   <w.rf>
    <LM>w#w-d1t664-6</LM>
   </w.rf>
   <form>domluvený</form>
   <lemma>domluvený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d-id94166">
   <w.rf>
    <LM>w#w-d-id94166</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x65">
  <m id="m714-d1t670-2">
   <w.rf>
    <LM>w#w-d1t670-2</LM>
   </w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t670-3">
   <w.rf>
    <LM>w#w-d1t670-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t670-4">
   <w.rf>
    <LM>w#w-d1t670-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t670-5">
   <w.rf>
    <LM>w#w-d1t670-5</LM>
   </w.rf>
   <form>domovnický</form>
   <lemma>domovnický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t670-6">
   <w.rf>
    <LM>w#w-d1t670-6</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x65-3654">
   <w.rf>
    <LM>w#w-d1e24-x65-3654</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t670-7">
   <w.rf>
    <LM>w#w-d1t670-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t670-8">
   <w.rf>
    <LM>w#w-d1t670-8</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t670-9">
   <w.rf>
    <LM>w#w-d1t670-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m714-d1t670-11">
   <w.rf>
    <LM>w#w-d1t670-11</LM>
   </w.rf>
   <form>nehledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m714-d1e24-x65-3655">
   <w.rf>
    <LM>w#w-d1e24-x65-3655</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t672-1">
   <w.rf>
    <LM>w#w-d1t672-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t672-2">
   <w.rf>
    <LM>w#w-d1t672-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t672-3">
   <w.rf>
    <LM>w#w-d1t672-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m714-d1t672-4">
   <w.rf>
    <LM>w#w-d1t672-4</LM>
   </w.rf>
   <form>nahlásili</form>
   <lemma>nahlásit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d-id94448">
   <w.rf>
    <LM>w#w-d-id94448</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t672-6">
   <w.rf>
    <LM>w#w-d1t672-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t672-7">
   <w.rf>
    <LM>w#w-d1t672-7</LM>
   </w.rf>
   <form>dáváme</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t672-8">
   <w.rf>
    <LM>w#w-d1t672-8</LM>
   </w.rf>
   <form>výpověď</form>
   <lemma>výpověď</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t672-26">
   <w.rf>
    <LM>w#w-d1t672-26</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t675-1">
   <w.rf>
    <LM>w#w-d1t675-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t675-2">
   <w.rf>
    <LM>w#w-d1t675-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t675-3">
   <w.rf>
    <LM>w#w-d1t675-3</LM>
   </w.rf>
   <form>stěhujeme</form>
   <lemma>stěhovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t675-5">
   <w.rf>
    <LM>w#w-d1t675-5</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x65-310">
   <w.rf>
    <LM>w#w-d1e24-x65-310</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-311">
  <m id="m714-311-312">
   <w.rf>
    <LM>w#w-311-312</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-311-313">
   <w.rf>
    <LM>w#w-311-313</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t672-14">
   <w.rf>
    <LM>w#w-d1t672-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t672-9">
   <w.rf>
    <LM>w#w-d1t672-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t672-11">
   <w.rf>
    <LM>w#w-d1t672-11</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t672-12">
   <w.rf>
    <LM>w#w-d1t672-12</LM>
   </w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t672-15">
   <w.rf>
    <LM>w#w-d1t672-15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t672-16">
   <w.rf>
    <LM>w#w-d1t672-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t672-17">
   <w.rf>
    <LM>w#w-d1t672-17</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id94566">
   <w.rf>
    <LM>w#w-d-id94566</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t672-21">
   <w.rf>
    <LM>w#w-d1t672-21</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t672-22">
   <w.rf>
    <LM>w#w-d1t672-22</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t672-23">
   <w.rf>
    <LM>w#w-d1t672-23</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m714-d1t672-24">
   <w.rf>
    <LM>w#w-d1t672-24</LM>
   </w.rf>
   <form>lhůta</form>
   <lemma>lhůta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x65-304">
   <w.rf>
    <LM>w#w-d1e24-x65-304</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-305">
  <m id="m714-d1t675-8">
   <w.rf>
    <LM>w#w-d1t675-8</LM>
   </w.rf>
   <form>Prodali</form>
   <lemma>prodat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t675-9">
   <w.rf>
    <LM>w#w-d1t675-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t675-10">
   <w.rf>
    <LM>w#w-d1t675-10</LM>
   </w.rf>
   <form>nábytek</form>
   <lemma>nábytek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x65-3660">
   <w.rf>
    <LM>w#w-d1e24-x65-3660</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t675-11">
   <w.rf>
    <LM>w#w-d1t675-11</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m714-d1e24-x65-6748">
   <w.rf>
    <LM>w#w-d1e24-x65-6748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t675-12">
   <w.rf>
    <LM>w#w-d1t675-12</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m714-d1t675-13">
   <w.rf>
    <LM>w#w-d1t675-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t675-14">
   <w.rf>
    <LM>w#w-d1t675-14</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x65-302">
   <w.rf>
    <LM>w#w-d1e24-x65-302</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-303">
  <m id="m714-d1t675-16">
   <w.rf>
    <LM>w#w-d1t675-16</LM>
   </w.rf>
   <form>Sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t675-17">
   <w.rf>
    <LM>w#w-d1t675-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t675-18">
   <w.rf>
    <LM>w#w-d1t675-18</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m714-d1t675-19">
   <w.rf>
    <LM>w#w-d1t675-19</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t675-20">
   <w.rf>
    <LM>w#w-d1t675-20</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m714-d-id95081">
   <w.rf>
    <LM>w#w-d-id95081</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x65-3663">
   <w.rf>
    <LM>w#w-d1e24-x65-3663</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t677-1">
   <w.rf>
    <LM>w#w-d1t677-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m714-d1t677-2">
   <w.rf>
    <LM>w#w-d1t677-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t677-3">
   <w.rf>
    <LM>w#w-d1t677-3</LM>
   </w.rf>
   <form>dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t677-4">
   <w.rf>
    <LM>w#w-d1t677-4</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x65-300">
   <w.rf>
    <LM>w#w-d1e24-x65-300</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-301">
  <m id="m714-d1t681-2">
   <w.rf>
    <LM>w#w-d1t681-2</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m714-d1t681-3">
   <w.rf>
    <LM>w#w-d1t681-3</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t681-4">
   <w.rf>
    <LM>w#w-d1t681-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t681-5">
   <w.rf>
    <LM>w#w-d1t681-5</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t681-6">
   <w.rf>
    <LM>w#w-d1t681-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t681-7">
   <w.rf>
    <LM>w#w-d1t681-7</LM>
   </w.rf>
   <form>matračkách</form>
   <lemma>matračka_,h</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m714-d1t681-8">
   <w.rf>
    <LM>w#w-d1t681-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t681-9">
   <w.rf>
    <LM>w#w-d1t681-9</LM>
   </w.rf>
   <form>zemi</form>
   <lemma>země</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id95318">
   <w.rf>
    <LM>w#w-d-id95318</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t681-11">
   <w.rf>
    <LM>w#w-d1t681-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t681-12">
   <w.rf>
    <LM>w#w-d1t681-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t681-13">
   <w.rf>
    <LM>w#w-d1t681-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1t681-14">
   <w.rf>
    <LM>w#w-d1t681-14</LM>
   </w.rf>
   <form>připadali</form>
   <lemma>připadat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t681-15">
   <w.rf>
    <LM>w#w-d1t681-15</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t681-16">
   <w.rf>
    <LM>w#w-d1t681-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t681-17">
   <w.rf>
    <LM>w#w-d1t681-17</LM>
   </w.rf>
   <form>koncentráku</form>
   <lemma>koncentrák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d-id95408">
   <w.rf>
    <LM>w#w-d-id95408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x66">
  <m id="m714-d1t685-4">
   <w.rf>
    <LM>w#w-d1t685-4</LM>
   </w.rf>
   <form>Ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t685-5">
   <w.rf>
    <LM>w#w-d1t685-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t685-6">
   <w.rf>
    <LM>w#w-d1t685-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t685-7">
   <w.rf>
    <LM>w#w-d1t685-7</LM>
   </w.rf>
   <form>dozvěděli</form>
   <lemma>dozvědět</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d-id95542">
   <w.rf>
    <LM>w#w-d-id95542</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t685-9">
   <w.rf>
    <LM>w#w-d1t685-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t685-10">
   <w.rf>
    <LM>w#w-d1t685-10</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m714-d1t685-11">
   <w.rf>
    <LM>w#w-d1t685-11</LM>
   </w.rf>
   <form>pána</form>
   <lemma>pán</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m714-d1t685-12">
   <w.rf>
    <LM>w#w-d1t685-12</LM>
   </w.rf>
   <form>zavřeli</form>
   <lemma>zavřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d-id95613">
   <w.rf>
    <LM>w#w-d-id95613</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t690-1">
   <w.rf>
    <LM>w#w-d1t690-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t690-2">
   <w.rf>
    <LM>w#w-d1t690-2</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m714-d1e24-x66-327">
   <w.rf>
    <LM>w#w-d1e24-x66-327</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t690-3">
   <w.rf>
    <LM>w#w-d1t690-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x66-328">
   <w.rf>
    <LM>w#w-d1e24-x66-328</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t690-4">
   <w.rf>
    <LM>w#w-d1t690-4</LM>
   </w.rf>
   <form>beze</form>
   <lemma>bez-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m714-d1t690-5">
   <w.rf>
    <LM>w#w-d1t690-5</LM>
   </w.rf>
   <form>všeho</form>
   <lemma>všechen</lemma>
   <tag>PLZS2----------</tag>
  </m>
  <m id="m714-d1t690-6">
   <w.rf>
    <LM>w#w-d1t690-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t690-7">
   <w.rf>
    <LM>w#w-d1t690-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t690-8">
   <w.rf>
    <LM>w#w-d1t690-8</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x66-329">
   <w.rf>
    <LM>w#w-d1e24-x66-329</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-330">
  <m id="m714-d1e24-x66-4117">
   <w.rf>
    <LM>w#w-d1e24-x66-4117</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t692-1">
   <w.rf>
    <LM>w#w-d1t692-1</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t692-3">
   <w.rf>
    <LM>w#w-d1t692-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t692-4">
   <w.rf>
    <LM>w#w-d1t692-4</LM>
   </w.rf>
   <form>nemohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m714-d1t692-5">
   <w.rf>
    <LM>w#w-d1t692-5</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d-id95865">
   <w.rf>
    <LM>w#w-d-id95865</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t692-7">
   <w.rf>
    <LM>w#w-d1t692-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t692-8">
   <w.rf>
    <LM>w#w-d1t692-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t692-9">
   <w.rf>
    <LM>w#w-d1t692-9</LM>
   </w.rf>
   <form>výpověď</form>
   <lemma>výpověď</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-330-331">
   <w.rf>
    <LM>w#w-330-331</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-332">
  <m id="m714-d1t696-4">
   <w.rf>
    <LM>w#w-d1t696-4</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t696-5">
   <w.rf>
    <LM>w#w-d1t696-5</LM>
   </w.rf>
   <form>humorem</form>
   <lemma>humor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m714-d1t696-6">
   <w.rf>
    <LM>w#w-d1t696-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t696-7">
   <w.rf>
    <LM>w#w-d1t696-7</LM>
   </w.rf>
   <form>řikali</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x66-4122">
   <w.rf>
    <LM>w#w-d1e24-x66-4122</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x66-4121">
   <w.rf>
    <LM>w#w-d1e24-x66-4121</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t696-8">
   <w.rf>
    <LM>w#w-d1t696-8</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m714-d1t696-9">
   <w.rf>
    <LM>w#w-d1t696-9</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x66-4124">
   <w.rf>
    <LM>w#w-d1e24-x66-4124</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x66-4125">
   <w.rf>
    <LM>w#w-d1e24-x66-4125</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x68">
  <m id="m714-d1t698-3">
   <w.rf>
    <LM>w#w-d1t698-3</LM>
   </w.rf>
   <form>Šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t698-2">
   <w.rf>
    <LM>w#w-d1t698-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t698-4">
   <w.rf>
    <LM>w#w-d1t698-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t698-5">
   <w.rf>
    <LM>w#w-d1t698-5</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d-id96167">
   <w.rf>
    <LM>w#w-d-id96167</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t705-1">
   <w.rf>
    <LM>w#w-d1t705-1</LM>
   </w.rf>
   <form>zní</form>
   <lemma>znít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t705-2">
   <w.rf>
    <LM>w#w-d1t705-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t705-3">
   <w.rf>
    <LM>w#w-d1t705-3</LM>
   </w.rf>
   <form>legračně</form>
   <lemma>legračně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d-id96249">
   <w.rf>
    <LM>w#w-d-id96249</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t705-5">
   <w.rf>
    <LM>w#w-d1t705-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t705-6">
   <w.rf>
    <LM>w#w-d1t705-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t705-7">
   <w.rf>
    <LM>w#w-d1t705-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t705-8">
   <w.rf>
    <LM>w#w-d1t705-8</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d-id96313">
   <w.rf>
    <LM>w#w-d-id96313</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t707-1">
   <w.rf>
    <LM>w#w-d1t707-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t707-2">
   <w.rf>
    <LM>w#w-d1t707-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m714-d1t707-3">
   <w.rf>
    <LM>w#w-d1t707-3</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t707-4">
   <w.rf>
    <LM>w#w-d1t707-4</LM>
   </w.rf>
   <form>jízdenku</form>
   <lemma>jízdenka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t707-5">
   <w.rf>
    <LM>w#w-d1t707-5</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t707-7">
   <w.rf>
    <LM>w#w-d1t707-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t707-8">
   <w.rf>
    <LM>w#w-d1t707-8</LM>
   </w.rf>
   <form>severních</form>
   <lemma>severní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m714-d1t707-9">
   <w.rf>
    <LM>w#w-d1t707-9</LM>
   </w.rf>
   <form>Čech</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m714-d-id96457">
   <w.rf>
    <LM>w#w-d-id96457</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x69">
  <m id="m714-d1e24-x69-4334">
   <w.rf>
    <LM>w#w-d1e24-x69-4334</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t709-1">
   <w.rf>
    <LM>w#w-d1t709-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id96496">
   <w.rf>
    <LM>w#w-d-id96496</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x69-4335">
   <w.rf>
    <LM>w#w-d1e24-x69-4335</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x70">
  <m id="m714-d1t711-2">
   <w.rf>
    <LM>w#w-d1t711-2</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x70-4367">
   <w.rf>
    <LM>w#w-d1e24-x70-4367</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x70-348">
   <w.rf>
    <LM>w#w-d1e24-x70-348</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t711-5">
   <w.rf>
    <LM>w#w-d1t711-5</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d-id96591">
   <w.rf>
    <LM>w#w-d-id96591</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t711-7">
   <w.rf>
    <LM>w#w-d1t711-7</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x70-6772">
   <w.rf>
    <LM>w#w-d1e24-x70-6772</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t711-8">
   <w.rf>
    <LM>w#w-d1t711-8</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t711-9">
   <w.rf>
    <LM>w#w-d1t711-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t711-10">
   <w.rf>
    <LM>w#w-d1t711-10</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d-id96648">
   <w.rf>
    <LM>w#w-d-id96648</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x70-4370">
   <w.rf>
    <LM>w#w-d1e24-x70-4370</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x71">
  <m id="m714-d1t718-2">
   <w.rf>
    <LM>w#w-d1t718-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t718-3">
   <w.rf>
    <LM>w#w-d1t718-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t718-4">
   <w.rf>
    <LM>w#w-d1t718-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t718-5">
   <w.rf>
    <LM>w#w-d1t718-5</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t718-6">
   <w.rf>
    <LM>w#w-d1t718-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t718-7">
   <w.rf>
    <LM>w#w-d1t718-7</LM>
   </w.rf>
   <form>Děčínu</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m714-d1e24-x71-4569">
   <w.rf>
    <LM>w#w-d1e24-x71-4569</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t718-8">
   <w.rf>
    <LM>w#w-d1t718-8</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t718-9">
   <w.rf>
    <LM>w#w-d1t718-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t718-10">
   <w.rf>
    <LM>w#w-d1t718-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t718-11">
   <w.rf>
    <LM>w#w-d1t718-11</LM>
   </w.rf>
   <form>Děčína</form>
   <lemma>Děčín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1e24-x71-369">
   <w.rf>
    <LM>w#w-d1e24-x71-369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-370">
  <m id="m714-d1t718-13">
   <w.rf>
    <LM>w#w-d1t718-13</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t718-14">
   <w.rf>
    <LM>w#w-d1t718-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t718-15">
   <w.rf>
    <LM>w#w-d1t718-15</LM>
   </w.rf>
   <form>mluvili</form>
   <lemma>mluvit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t718-16">
   <w.rf>
    <LM>w#w-d1t718-16</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t718-17">
   <w.rf>
    <LM>w#w-d1t718-17</LM>
   </w.rf>
   <form>autobusáky</form>
   <lemma>autobusák-2_,h</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m714-d1t720-1">
   <w.rf>
    <LM>w#w-d1t720-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t720-2">
   <w.rf>
    <LM>w#w-d1t720-2</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m714-d1t720-3">
   <w.rf>
    <LM>w#w-d1t720-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d1t720-4">
   <w.rf>
    <LM>w#w-d1t720-4</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d-id97017">
   <w.rf>
    <LM>w#w-d-id97017</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t720-6">
   <w.rf>
    <LM>w#w-d1t720-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1e24-x71-4576">
   <w.rf>
    <LM>w#w-d1e24-x71-4576</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t722-1">
   <w.rf>
    <LM>w#w-d1t722-1</LM>
   </w.rf>
   <form>Jetřichovicích</form>
   <lemma>Jetřichovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m714-d1t722-4">
   <w.rf>
    <LM>w#w-d1t722-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t722-5">
   <w.rf>
    <LM>w#w-d1t722-5</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t722-6">
   <w.rf>
    <LM>w#w-d1t722-6</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-370-371">
   <w.rf>
    <LM>w#w-370-371</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-372">
  <m id="m714-d1t724-1">
   <w.rf>
    <LM>w#w-d1t724-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t724-2">
   <w.rf>
    <LM>w#w-d1t724-2</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m714-d1t724-3">
   <w.rf>
    <LM>w#w-d1t724-3</LM>
   </w.rf>
   <form>sehnali</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t724-5">
   <w.rf>
    <LM>w#w-d1t724-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t724-4">
   <w.rf>
    <LM>w#w-d1t724-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t724-6">
   <w.rf>
    <LM>w#w-d1t724-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m714-d1t724-8">
   <w.rf>
    <LM>w#w-d1t724-8</LM>
   </w.rf>
   <form>bydlení</form>
   <lemma>bydlení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x71-4580">
   <w.rf>
    <LM>w#w-d1e24-x71-4580</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t724-10">
   <w.rf>
    <LM>w#w-d1t724-10</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m714-d1t724-11">
   <w.rf>
    <LM>w#w-d1t724-11</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d1t724-12">
   <w.rf>
    <LM>w#w-d1t724-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t724-13">
   <w.rf>
    <LM>w#w-d1t724-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t724-14">
   <w.rf>
    <LM>w#w-d1t724-14</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id97358">
   <w.rf>
    <LM>w#w-d-id97358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x72">
  <m id="m714-d1t729-2">
   <w.rf>
    <LM>w#w-d1t729-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t729-3">
   <w.rf>
    <LM>w#w-d1t729-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t729-4">
   <w.rf>
    <LM>w#w-d1t729-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t729-5">
   <w.rf>
    <LM>w#w-d1t729-5</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x72-379">
   <w.rf>
    <LM>w#w-d1e24-x72-379</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-380">
  <m id="m714-d1t731-1">
   <w.rf>
    <LM>w#w-d1t731-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t731-2">
   <w.rf>
    <LM>w#w-d1t731-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t731-3">
   <w.rf>
    <LM>w#w-d1t731-3</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x72-4797">
   <w.rf>
    <LM>w#w-d1e24-x72-4797</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t731-4">
   <w.rf>
    <LM>w#w-d1t731-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t731-5">
   <w.rf>
    <LM>w#w-d1t731-5</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t731-6">
   <w.rf>
    <LM>w#w-d1t731-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m714-d1t731-7">
   <w.rf>
    <LM>w#w-d1t731-7</LM>
   </w.rf>
   <form>sežene</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m714-380-381">
   <w.rf>
    <LM>w#w-380-381</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-382">
  <m id="m714-d1t731-9">
   <w.rf>
    <LM>w#w-d1t731-9</LM>
   </w.rf>
   <form>Šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t731-10">
   <w.rf>
    <LM>w#w-d1t731-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t731-11">
   <w.rf>
    <LM>w#w-d1t731-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t731-12">
   <w.rf>
    <LM>w#w-d1t731-12</LM>
   </w.rf>
   <form>hospody</form>
   <lemma>hospoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-382-383">
   <w.rf>
    <LM>w#w-382-383</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-384">
  <m id="m714-d1t733-1">
   <w.rf>
    <LM>w#w-d1t733-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t733-2">
   <w.rf>
    <LM>w#w-d1t733-2</LM>
   </w.rf>
   <form>hospodě</form>
   <lemma>hospoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t733-3">
   <w.rf>
    <LM>w#w-d1t733-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t733-4">
   <w.rf>
    <LM>w#w-d1t733-4</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m714-d1t735-1">
   <w.rf>
    <LM>w#w-d1t735-1</LM>
   </w.rf>
   <form>předsíňce</form>
   <lemma>předsíňka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t735-4">
   <w.rf>
    <LM>w#w-d1t735-4</LM>
   </w.rf>
   <form>ležel</form>
   <lemma>ležet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t735-5">
   <w.rf>
    <LM>w#w-d1t735-5</LM>
   </w.rf>
   <form>nádherný</form>
   <lemma>nádherný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t735-6">
   <w.rf>
    <LM>w#w-d1t735-6</LM>
   </w.rf>
   <form>černý</form>
   <lemma>černý_;o</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t735-7">
   <w.rf>
    <LM>w#w-d1t735-7</LM>
   </w.rf>
   <form>vlčák</form>
   <lemma>vlčák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t737-1">
   <w.rf>
    <LM>w#w-d1t737-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t737-2">
   <w.rf>
    <LM>w#w-d1t737-2</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHP1-P1-------</tag>
  </m>
  <m id="m714-d1t737-3">
   <w.rf>
    <LM>w#w-d1t737-3</LM>
   </w.rf>
   <form>děcka</form>
   <lemma>děcko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m714-d1t737-4">
   <w.rf>
    <LM>w#w-d1t737-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t737-5">
   <w.rf>
    <LM>w#w-d1t737-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m714-d1t737-6">
   <w.rf>
    <LM>w#w-d1t737-6</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m714-d-id97942">
   <w.rf>
    <LM>w#w-d-id97942</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t742-1">
   <w.rf>
    <LM>w#w-d1t742-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t742-2">
   <w.rf>
    <LM>w#w-d1t742-2</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m714-d1t742-3">
   <w.rf>
    <LM>w#w-d1t742-3</LM>
   </w.rf>
   <form>Patrik</form>
   <lemma>Patrik_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t742-4">
   <w.rf>
    <LM>w#w-d1t742-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t742-5">
   <w.rf>
    <LM>w#w-d1t742-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t742-6">
   <w.rf>
    <LM>w#w-d1t742-6</LM>
   </w.rf>
   <form>němu</form>
   <lemma>on-1</lemma>
   <tag>PEZS3--3------1</tag>
  </m>
  <m id="m714-d1t742-7">
   <w.rf>
    <LM>w#w-d1t742-7</LM>
   </w.rf>
   <form>sklonil</form>
   <lemma>sklonit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-384-385">
   <w.rf>
    <LM>w#w-384-385</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-386">
  <m id="m714-d1t742-11">
   <w.rf>
    <LM>w#w-d1t742-11</LM>
   </w.rf>
   <form>Kousl</form>
   <lemma>kousnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m714-d1t742-10">
   <w.rf>
    <LM>w#w-d1t742-10</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m714-d1e24-x72-4803">
   <w.rf>
    <LM>w#w-d1e24-x72-4803</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t742-12">
   <w.rf>
    <LM>w#w-d1t742-12</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t742-13">
   <w.rf>
    <LM>w#w-d1t742-13</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t742-14">
   <w.rf>
    <LM>w#w-d1t742-14</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t742-15">
   <w.rf>
    <LM>w#w-d1t742-15</LM>
   </w.rf>
   <form>jizvu</form>
   <lemma>jizva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t744-1">
   <w.rf>
    <LM>w#w-d1t744-1</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t744-2">
   <w.rf>
    <LM>w#w-d1t744-2</LM>
   </w.rf>
   <form>nosem</form>
   <lemma>nos</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m714-d1t744-3">
   <w.rf>
    <LM>w#w-d1t744-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t744-4">
   <w.rf>
    <LM>w#w-d1t744-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t744-5">
   <w.rf>
    <LM>w#w-d1t744-5</LM>
   </w.rf>
   <form>nose</form>
   <lemma>nos</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1e24-x72-4805">
   <w.rf>
    <LM>w#w-d1e24-x72-4805</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t744-11">
   <w.rf>
    <LM>w#w-d1t744-11</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t744-12">
   <w.rf>
    <LM>w#w-d1t744-12</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t744-13">
   <w.rf>
    <LM>w#w-d1t744-13</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAMP1----3A----</tag>
  </m>
  <m id="m714-d1t744-14">
   <w.rf>
    <LM>w#w-d1t744-14</LM>
   </w.rf>
   <form>kamarádi</form>
   <lemma>kamarád</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m714-d-id98406">
   <w.rf>
    <LM>w#w-d-id98406</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x73">
  <m id="m714-d1t750-4">
   <w.rf>
    <LM>w#w-d1t750-4</LM>
   </w.rf>
   <form>Řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t750-3">
   <w.rf>
    <LM>w#w-d1t750-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m714-d-id98510">
   <w.rf>
    <LM>w#w-d-id98510</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t750-6">
   <w.rf>
    <LM>w#w-d1t750-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t750-7">
   <w.rf>
    <LM>w#w-d1t750-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t750-8">
   <w.rf>
    <LM>w#w-d1t750-8</LM>
   </w.rf>
   <form>volná</form>
   <lemma>volný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d1t750-9">
   <w.rf>
    <LM>w#w-d1t750-9</LM>
   </w.rf>
   <form>hospoda</form>
   <lemma>hospoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t753-1">
   <w.rf>
    <LM>w#w-d1t753-1</LM>
   </w.rf>
   <form>nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t753-2">
   <w.rf>
    <LM>w#w-d1t753-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t753-3">
   <w.rf>
    <LM>w#w-d1t753-3</LM>
   </w.rf>
   <form>Rinarticích</form>
   <lemma>Rinartice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m714-d-id98645">
   <w.rf>
    <LM>w#w-d-id98645</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t753-5">
   <w.rf>
    <LM>w#w-d1t753-5</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t753-6">
   <w.rf>
    <LM>w#w-d1t753-6</LM>
   </w.rf>
   <form>nechceme</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m714-d1t753-7">
   <w.rf>
    <LM>w#w-d1t753-7</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t753-8">
   <w.rf>
    <LM>w#w-d1t753-8</LM>
   </w.rf>
   <form>hostinské</form>
   <lemma>hostinský-1_^(člověk)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m714-d-id98703">
   <w.rf>
    <LM>w#w-d-id98703</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x74">
  <m id="m714-d1t757-3">
   <w.rf>
    <LM>w#w-d1t757-3</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t757-2">
   <w.rf>
    <LM>w#w-d1t757-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x74-5022">
   <w.rf>
    <LM>w#w-d1e24-x74-5022</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x74-5021">
   <w.rf>
    <LM>w#w-d1e24-x74-5021</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t757-5">
   <w.rf>
    <LM>w#w-d1t757-5</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t757-6">
   <w.rf>
    <LM>w#w-d1t757-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-2_^(cože;_ale_co)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1e24-x74-5024">
   <w.rf>
    <LM>w#w-d1e24-x74-5024</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t757-8">
   <w.rf>
    <LM>w#w-d1t757-8</LM>
   </w.rf>
   <form>zkusíme</form>
   <lemma>zkusit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t757-9">
   <w.rf>
    <LM>w#w-d1t757-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d-id98854">
   <w.rf>
    <LM>w#w-d-id98854</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x74-5025">
   <w.rf>
    <LM>w#w-d1e24-x74-5025</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x75">
  <m id="m714-d1t763-4">
   <w.rf>
    <LM>w#w-d1t763-4</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t763-5">
   <w.rf>
    <LM>w#w-d1t763-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t763-6">
   <w.rf>
    <LM>w#w-d1t763-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t763-7">
   <w.rf>
    <LM>w#w-d1t763-7</LM>
   </w.rf>
   <form>naučila</form>
   <lemma>naučit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t763-8">
   <w.rf>
    <LM>w#w-d1t763-8</LM>
   </w.rf>
   <form>čepovat</form>
   <lemma>čepovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t763-9">
   <w.rf>
    <LM>w#w-d1t763-9</LM>
   </w.rf>
   <form>pivo</form>
   <lemma>pivo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d1t763-10">
   <w.rf>
    <LM>w#w-d1t763-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t763-11">
   <w.rf>
    <LM>w#w-d1t763-11</LM>
   </w.rf>
   <form>narážet</form>
   <lemma>narážet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t763-12">
   <w.rf>
    <LM>w#w-d1t763-12</LM>
   </w.rf>
   <form>sudy</form>
   <lemma>sud</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1t766-2">
   <w.rf>
    <LM>w#w-d1t766-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t766-3">
   <w.rf>
    <LM>w#w-d1t766-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t766-4">
   <w.rf>
    <LM>w#w-d1t766-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t766-5">
   <w.rf>
    <LM>w#w-d1t766-5</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m714-d1t766-6">
   <w.rf>
    <LM>w#w-d1t766-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t766-7">
   <w.rf>
    <LM>w#w-d1t766-7</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d-id99181">
   <w.rf>
    <LM>w#w-d-id99181</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t766-9">
   <w.rf>
    <LM>w#w-d1t766-9</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t766-10">
   <w.rf>
    <LM>w#w-d1t766-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t766-11">
   <w.rf>
    <LM>w#w-d1t766-11</LM>
   </w.rf>
   <form>jezdily</form>
   <lemma>jezdit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t766-12">
   <w.rf>
    <LM>w#w-d1t766-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t766-13">
   <w.rf>
    <LM>w#w-d1t766-13</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m714-d1t766-17">
   <w.rf>
    <LM>w#w-d1t766-17</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m714-d1t766-15">
   <w.rf>
    <LM>w#w-d1t766-15</LM>
   </w.rf>
   <form>výpravy</form>
   <lemma>výprava</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-d1e24-x75-405">
   <w.rf>
    <LM>w#w-d1e24-x75-405</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-406">
  <m id="m714-d1t766-24">
   <w.rf>
    <LM>w#w-d1t766-24</LM>
   </w.rf>
   <form>Vařila</form>
   <lemma>vařit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t766-20">
   <w.rf>
    <LM>w#w-d1t766-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t766-22">
   <w.rf>
    <LM>w#w-d1t766-22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t766-23">
   <w.rf>
    <LM>w#w-d1t766-23</LM>
   </w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>guláš</form>
   <lemma>guláš</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x75-5233">
   <w.rf>
    <LM>w#w-d1e24-x75-5233</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t768-2">
   <w.rf>
    <LM>w#w-d1t768-2</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t768-3">
   <w.rf>
    <LM>w#w-d1t768-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t768-4">
   <w.rf>
    <LM>w#w-d1t768-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t768-5">
   <w.rf>
    <LM>w#w-d1t768-5</LM>
   </w.rf>
   <form>jednotné</form>
   <lemma>jednotný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-d-id99517">
   <w.rf>
    <LM>w#w-d-id99517</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t768-7">
   <w.rf>
    <LM>w#w-d1t768-7</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t768-8">
   <w.rf>
    <LM>w#w-d1t768-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t768-9">
   <w.rf>
    <LM>w#w-d1t768-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t768-10">
   <w.rf>
    <LM>w#w-d1t768-10</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m714-d1t768-11">
   <w.rf>
    <LM>w#w-d1t768-11</LM>
   </w.rf>
   <form>ohřát</form>
   <lemma>ohřát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d-id99603">
   <w.rf>
    <LM>w#w-d-id99603</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t768-13">
   <w.rf>
    <LM>w#w-d1t768-13</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t768-14">
   <w.rf>
    <LM>w#w-d1t768-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t768-15">
   <w.rf>
    <LM>w#w-d1t768-15</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t768-16">
   <w.rf>
    <LM>w#w-d1t768-16</LM>
   </w.rf>
   <form>nachystané</form>
   <lemma>nachystaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-406-407">
   <w.rf>
    <LM>w#w-406-407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-408">
  <m id="m714-d1t768-19">
   <w.rf>
    <LM>w#w-d1t768-19</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t768-20">
   <w.rf>
    <LM>w#w-d1t768-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t768-21">
   <w.rf>
    <LM>w#w-d1t768-21</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t768-22">
   <w.rf>
    <LM>w#w-d1t768-22</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t768-23">
   <w.rf>
    <LM>w#w-d1t768-23</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x75-5242">
   <w.rf>
    <LM>w#w-d1e24-x75-5242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-5243">
  <m id="m714-d1t770-1">
   <w.rf>
    <LM>w#w-d1t770-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t770-2">
   <w.rf>
    <LM>w#w-d1t770-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t770-3">
   <w.rf>
    <LM>w#w-d1t770-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t770-4">
   <w.rf>
    <LM>w#w-d1t770-4</LM>
   </w.rf>
   <form>odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t770-5">
   <w.rf>
    <LM>w#w-d1t770-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t770-6">
   <w.rf>
    <LM>w#w-d1t770-6</LM>
   </w.rf>
   <form>Chřibské</form>
   <lemma>Chřibská_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-5243-5253">
   <w.rf>
    <LM>w#w-5243-5253</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t772-1">
   <w.rf>
    <LM>w#w-d1t772-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t772-2">
   <w.rf>
    <LM>w#w-d1t772-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t772-3">
   <w.rf>
    <LM>w#w-d1t772-3</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t772-4">
   <w.rf>
    <LM>w#w-d1t772-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t772-6">
   <w.rf>
    <LM>w#w-d1t772-6</LM>
   </w.rf>
   <form>niťárně</form>
   <lemma>niťárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-5243-5256">
   <w.rf>
    <LM>w#w-5243-5256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t772-7">
   <w.rf>
    <LM>w#w-d1t772-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t772-8">
   <w.rf>
    <LM>w#w-d1t772-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t772-9">
   <w.rf>
    <LM>w#w-d1t772-9</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t772-10">
   <w.rf>
    <LM>w#w-d1t772-10</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t772-11">
   <w.rf>
    <LM>w#w-d1t772-11</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t772-12">
   <w.rf>
    <LM>w#w-d1t772-12</LM>
   </w.rf>
   <form>naproti</form>
   <lemma>naproti-1_^(komu/čemu)</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t774-2">
   <w.rf>
    <LM>w#w-d1t774-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m714-d1t774-3">
   <w.rf>
    <LM>w#w-d1t774-3</LM>
   </w.rf>
   <form>fabrice</form>
   <lemma>fabrika</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m714-5243-411">
   <w.rf>
    <LM>w#w-5243-411</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-412">
  <m id="m714-d1t774-7">
   <w.rf>
    <LM>w#w-d1t774-7</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t774-6">
   <w.rf>
    <LM>w#w-d1t774-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-5243-5260">
   <w.rf>
    <LM>w#w-5243-5260</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m714-5243-5264">
   <w.rf>
    <LM>w#w-5243-5264</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-412-413">
   <w.rf>
    <LM>w#w-412-413</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t776-1">
   <w.rf>
    <LM>w#w-d1t776-1</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-412-414">
   <w.rf>
    <LM>w#w-412-414</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-412-415">
   <w.rf>
    <LM>w#w-412-415</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t776-3">
   <w.rf>
    <LM>w#w-d1t776-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t776-4">
   <w.rf>
    <LM>w#w-d1t776-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t776-5">
   <w.rf>
    <LM>w#w-d1t776-5</LM>
   </w.rf>
   <form>jmenovalo</form>
   <lemma>jmenovat</lemma>
   <tag>VpNS----R-AAB--</tag>
  </m>
  <m id="m714-d1t776-2">
   <w.rf>
    <LM>w#w-d1t776-2</LM>
   </w.rf>
   <form>Sponit</form>
   <lemma>Sponit_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-5243-5266">
   <w.rf>
    <LM>w#w-5243-5266</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t776-8">
   <w.rf>
    <LM>w#w-d1t776-8</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5243-5267">
   <w.rf>
    <LM>w#w-5243-5267</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m714-412-416">
   <w.rf>
    <LM>w#w-412-416</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t776-9">
   <w.rf>
    <LM>w#w-d1t776-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t776-10">
   <w.rf>
    <LM>w#w-d1t776-10</LM>
   </w.rf>
   <form>napadlo</form>
   <lemma>napadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m714-d-id100326">
   <w.rf>
    <LM>w#w-d-id100326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x76">
  <m id="m714-d1t781-1">
   <w.rf>
    <LM>w#w-d1t781-1</LM>
   </w.rf>
   <form>Nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m714-d1t781-2">
   <w.rf>
    <LM>w#w-d1t781-2</LM>
   </w.rf>
   <form>niťárna</form>
   <lemma>niťárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d-id100390">
   <w.rf>
    <LM>w#w-d-id100390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x77">
  <m id="m714-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t787-6">
   <w.rf>
    <LM>w#w-d1t787-6</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m714-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-d-id100494">
   <w.rf>
    <LM>w#w-d-id100494</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t787-8">
   <w.rf>
    <LM>w#w-d1t787-8</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d-id100549">
   <w.rf>
    <LM>w#w-d-id100549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t787-10">
   <w.rf>
    <LM>w#w-d1t787-10</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t787-11">
   <w.rf>
    <LM>w#w-d1t787-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t787-12">
   <w.rf>
    <LM>w#w-d1t787-12</LM>
   </w.rf>
   <form>znělo</form>
   <lemma>znít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x77-424">
   <w.rf>
    <LM>w#w-d1e24-x77-424</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-425">
  <m id="m714-d1t796-1">
   <w.rf>
    <LM>w#w-d1t796-1</LM>
   </w.rf>
   <form>Hledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t798-3">
   <w.rf>
    <LM>w#w-d1t798-3</LM>
   </w.rf>
   <form>zaměstnance</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m714-d1t798-1">
   <w.rf>
    <LM>w#w-d1t798-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t798-2">
   <w.rf>
    <LM>w#w-d1t798-2</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>důl</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m714-d1t796-2">
   <w.rf>
    <LM>w#w-d1t796-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t796-3">
   <w.rf>
    <LM>w#w-d1t796-3</LM>
   </w.rf>
   <form>Ostravy</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d-id100766">
   <w.rf>
    <LM>w#w-d-id100766</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x78">
  <m id="m714-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>Jedni</form>
   <lemma>jedny`1</lemma>
   <tag>CdMP1----------</tag>
  </m>
  <m id="m714-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>manželé</form>
   <lemma>manžel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m714-d1e24-x78-1747">
   <w.rf>
    <LM>w#w-d1e24-x78-1747</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t805-5">
   <w.rf>
    <LM>w#w-d1t805-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m714-d1t805-6">
   <w.rf>
    <LM>w#w-d1t805-6</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m714-d1t805-7">
   <w.rf>
    <LM>w#w-d1t805-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t805-8">
   <w.rf>
    <LM>w#w-d1t805-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t805-9">
   <w.rf>
    <LM>w#w-d1t805-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t805-11">
   <w.rf>
    <LM>w#w-d1t805-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t805-12">
   <w.rf>
    <LM>w#w-d1t805-12</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t805-10">
   <w.rf>
    <LM>w#w-d1t805-10</LM>
   </w.rf>
   <form>přátelili</form>
   <lemma>přátelit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x78-5517">
   <w.rf>
    <LM>w#w-d1e24-x78-5517</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t805-14">
   <w.rf>
    <LM>w#w-d1t805-14</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m714-d1t805-16">
   <w.rf>
    <LM>w#w-d1t805-16</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t805-17">
   <w.rf>
    <LM>w#w-d1t805-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t805-18">
   <w.rf>
    <LM>w#w-d1t805-18</LM>
   </w.rf>
   <form>přihlásil</form>
   <lemma>přihlásit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x78-428">
   <w.rf>
    <LM>w#w-d1e24-x78-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-429">
  <m id="m714-d1t805-20">
   <w.rf>
    <LM>w#w-d1t805-20</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t805-19">
   <w.rf>
    <LM>w#w-d1t805-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t807-1">
   <w.rf>
    <LM>w#w-d1t807-1</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t807-2">
   <w.rf>
    <LM>w#w-d1t807-2</LM>
   </w.rf>
   <form>komunista</form>
   <lemma>komunista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x78-5610">
   <w.rf>
    <LM>w#w-d1e24-x78-5610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t807-3">
   <w.rf>
    <LM>w#w-d1t807-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t807-4">
   <w.rf>
    <LM>w#w-d1t807-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m714-d1t807-5">
   <w.rf>
    <LM>w#w-d1t807-5</LM>
   </w.rf>
   <form>slušný</form>
   <lemma>slušný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t807-6">
   <w.rf>
    <LM>w#w-d1t807-6</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t809-1">
   <w.rf>
    <LM>w#w-d1t809-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t809-2">
   <w.rf>
    <LM>w#w-d1t809-2</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t809-3">
   <w.rf>
    <LM>w#w-d1t809-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id101268">
   <w.rf>
    <LM>w#w-d-id101268</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x79">
  <m id="m714-d1t811-2">
   <w.rf>
    <LM>w#w-d1t811-2</LM>
   </w.rf>
   <form>Hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t813-1">
   <w.rf>
    <LM>w#w-d1t813-1</LM>
   </w.rf>
   <form>psal</form>
   <lemma>psát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x79-5616">
   <w.rf>
    <LM>w#w-d1e24-x79-5616</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t815-1">
   <w.rf>
    <LM>w#w-d1t815-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t815-2">
   <w.rf>
    <LM>w#w-d1t815-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t815-3">
   <w.rf>
    <LM>w#w-d1t815-3</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m714-d1t815-4">
   <w.rf>
    <LM>w#w-d1t815-4</LM>
   </w.rf>
   <form>týdnů</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m714-d1t815-6">
   <w.rf>
    <LM>w#w-d1t815-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t815-5">
   <w.rf>
    <LM>w#w-d1t815-5</LM>
   </w.rf>
   <form>dostaneme</form>
   <lemma>dostat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m714-d1t815-7">
   <w.rf>
    <LM>w#w-d1t815-7</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t815-8">
   <w.rf>
    <LM>w#w-d1t815-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t815-9">
   <w.rf>
    <LM>w#w-d1t815-9</LM>
   </w.rf>
   <form>novostavbě</form>
   <lemma>novostavba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id101495">
   <w.rf>
    <LM>w#w-d-id101495</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x80">
  <m id="m714-d1t818-3">
   <w.rf>
    <LM>w#w-d1t818-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t818-5">
   <w.rf>
    <LM>w#w-d1t818-5</LM>
   </w.rf>
   <form>Chřibské</form>
   <lemma>Chřibská_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t818-6">
   <w.rf>
    <LM>w#w-d1t818-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t818-7">
   <w.rf>
    <LM>w#w-d1t818-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t818-8">
   <w.rf>
    <LM>w#w-d1t818-8</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m714-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t820-3">
   <w.rf>
    <LM>w#w-d1t820-3</LM>
   </w.rf>
   <form>malinký</form>
   <lemma>malinký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-d1t820-2">
   <w.rf>
    <LM>w#w-d1t820-2</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x80-7199">
   <w.rf>
    <LM>w#w-d1e24-x80-7199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t820-4">
   <w.rf>
    <LM>w#w-d1t820-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t820-5">
   <w.rf>
    <LM>w#w-d1t820-5</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id101722">
   <w.rf>
    <LM>w#w-d-id101722</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x81">
  <m id="m714-d1t824-3">
   <w.rf>
    <LM>w#w-d1t824-3</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1t824-4">
   <w.rf>
    <LM>w#w-d1t824-4</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x81-5747">
   <w.rf>
    <LM>w#w-d1e24-x81-5747</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x81-5748">
   <w.rf>
    <LM>w#w-d1e24-x81-5748</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t824-9">
   <w.rf>
    <LM>w#w-d1t824-9</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-d1t824-10">
   <w.rf>
    <LM>w#w-d1t824-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t824-11">
   <w.rf>
    <LM>w#w-d1t824-11</LM>
   </w.rf>
   <form>stane</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m714-d1e24-x81-442">
   <w.rf>
    <LM>w#w-d1e24-x81-442</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x81-5750">
   <w.rf>
    <LM>w#w-d1e24-x81-5750</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x82">
  <m id="m714-d1t828-2">
   <w.rf>
    <LM>w#w-d1t828-2</LM>
   </w.rf>
   <form>Jel</form>
   <lemma>jet-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t828-3">
   <w.rf>
    <LM>w#w-d1t828-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t833-1">
   <w.rf>
    <LM>w#w-d1t833-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t833-2">
   <w.rf>
    <LM>w#w-d1t833-2</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m714-d1t833-3">
   <w.rf>
    <LM>w#w-d1t833-3</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1e24-x82-5914">
   <w.rf>
    <LM>w#w-d1e24-x82-5914</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t833-5">
   <w.rf>
    <LM>w#w-d1t833-5</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m714-d1t833-6">
   <w.rf>
    <LM>w#w-d1t833-6</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-d1e24-x82-5915">
   <w.rf>
    <LM>w#w-d1e24-x82-5915</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t833-7">
   <w.rf>
    <LM>w#w-d1t833-7</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t833-10">
   <w.rf>
    <LM>w#w-d1t833-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t833-9">
   <w.rf>
    <LM>w#w-d1t833-9</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t833-11">
   <w.rf>
    <LM>w#w-d1t833-11</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m714-d1t833-12">
   <w.rf>
    <LM>w#w-d1t833-12</LM>
   </w.rf>
   <form>nedělo</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m714-d-id102188">
   <w.rf>
    <LM>w#w-d-id102188</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t833-16">
   <w.rf>
    <LM>w#w-d1t833-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t833-17">
   <w.rf>
    <LM>w#w-d1t833-17</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1t833-15">
   <w.rf>
    <LM>w#w-d1t833-15</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t833-18">
   <w.rf>
    <LM>w#w-d1t833-18</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m714-d1t833-19">
   <w.rf>
    <LM>w#w-d1t833-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t833-20">
   <w.rf>
    <LM>w#w-d1t833-20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t833-21">
   <w.rf>
    <LM>w#w-d1t833-21</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1e24-x82-448">
   <w.rf>
    <LM>w#w-d1e24-x82-448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
