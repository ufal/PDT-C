<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="dk_103.01.w.gz" />
  </references>
 </head>
 <s id="m103-60">
  <m id="m103-d1t163-6">
   <w.rf>
    <LM>w#w-d1t163-6</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t163-5">
   <w.rf>
    <LM>w#w-d1t163-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1t163-7">
   <w.rf>
    <LM>w#w-d1t163-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m103-d1t163-8">
   <w.rf>
    <LM>w#w-d1t163-8</LM>
   </w.rf>
   <form>dvojčat</form>
   <lemma>dvojče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m103-60-125">
   <w.rf>
    <LM>w#w-60-125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t163-9">
   <w.rf>
    <LM>w#w-d1t163-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t163-10">
   <w.rf>
    <LM>w#w-d1t163-10</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m103-60-124">
   <w.rf>
    <LM>w#w-60-124</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d1t163-11">
   <w.rf>
    <LM>w#w-d1t163-11</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m103-d-id62225-punct">
   <w.rf>
    <LM>w#w-d-id62225-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t163-13">
   <w.rf>
    <LM>w#w-d1t163-13</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t163-15">
   <w.rf>
    <LM>w#w-d1t163-15</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t163-14">
   <w.rf>
    <LM>w#w-d1t163-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t163-16">
   <w.rf>
    <LM>w#w-d1t163-16</LM>
   </w.rf>
   <form>maličká</form>
   <lemma>maličký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m103-60-127">
   <w.rf>
    <LM>w#w-60-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-67">
  <m id="m103-d1t165-4">
   <w.rf>
    <LM>w#w-d1t165-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t165-3">
   <w.rf>
    <LM>w#w-d1t165-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t165-5">
   <w.rf>
    <LM>w#w-d1t165-5</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m103-67-68">
   <w.rf>
    <LM>w#w-67-68</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t165-7">
   <w.rf>
    <LM>w#w-d1t165-7</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m103-d1t165-8">
   <w.rf>
    <LM>w#w-d1t165-8</LM>
   </w.rf>
   <form>bráchové</form>
   <lemma>brácha</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m103-d1t165-9">
   <w.rf>
    <LM>w#w-d1t165-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t165-10">
   <w.rf>
    <LM>w#w-d1t165-10</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m103-d1t165-11">
   <w.rf>
    <LM>w#w-d1t165-11</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m103-67-69">
   <w.rf>
    <LM>w#w-67-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-71">
  <m id="m103-d1t165-13">
   <w.rf>
    <LM>w#w-d1t165-13</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t165-12">
   <w.rf>
    <LM>w#w-d1t165-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t165-16">
   <w.rf>
    <LM>w#w-d1t165-16</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m103-d1t165-17">
   <w.rf>
    <LM>w#w-d1t165-17</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m103-71-72">
   <w.rf>
    <LM>w#w-71-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e166-x2">
  <m id="m103-d1t169-1">
   <w.rf>
    <LM>w#w-d1t169-1</LM>
   </w.rf>
   <form>Přejděme</form>
   <lemma>přejít</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m103-d1t169-2">
   <w.rf>
    <LM>w#w-d1t169-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m103-d1t169-3">
   <w.rf>
    <LM>w#w-d1t169-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m103-d1t169-4">
   <w.rf>
    <LM>w#w-d1t169-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m103-d-m-d1e166-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e166-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e170-x2">
  <m id="m103-d1t173-1">
   <w.rf>
    <LM>w#w-d1t173-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d-m-d1e170-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e170-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e176-x2">
  <m id="m103-d1t181-1">
   <w.rf>
    <LM>w#w-d1t181-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m103-d1t181-2">
   <w.rf>
    <LM>w#w-d1t181-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t181-3">
   <w.rf>
    <LM>w#w-d1t181-3</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m103-d1t181-4">
   <w.rf>
    <LM>w#w-d1t181-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t181-5">
   <w.rf>
    <LM>w#w-d1t181-5</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m103-d-id62946-punct">
   <w.rf>
    <LM>w#w-d-id62946-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e176-x4">
  <m id="m103-d1t183-1">
   <w.rf>
    <LM>w#w-d1t183-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t183-2">
   <w.rf>
    <LM>w#w-d1t183-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t183-3">
   <w.rf>
    <LM>w#w-d1t183-3</LM>
   </w.rf>
   <form>sousedovic</form>
   <lemma>sousedův_^(*2)</lemma>
   <tag>AUXXXM--------5</tag>
  </m>
  <m id="m103-d1t183-4">
   <w.rf>
    <LM>w#w-d1t183-4</LM>
   </w.rf>
   <form>holčička</form>
   <lemma>holčička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d1e176-x4-77">
   <w.rf>
    <LM>w#w-d1e176-x4-77</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-79">
  <m id="m103-d1t183-6">
   <w.rf>
    <LM>w#w-d1t183-6</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t183-7">
   <w.rf>
    <LM>w#w-d1t183-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d-id63072-punct">
   <w.rf>
    <LM>w#w-d-id63072-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t183-9">
   <w.rf>
    <LM>w#w-d1t183-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m103-d1t183-10">
   <w.rf>
    <LM>w#w-d1t183-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-79-80">
   <w.rf>
    <LM>w#w-79-80</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t183-11">
   <w.rf>
    <LM>w#w-d1t183-11</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m103-d1t183-12">
   <w.rf>
    <LM>w#w-d1t183-12</LM>
   </w.rf>
   <form>kytka</form>
   <lemma>kytka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d-id63142-punct">
   <w.rf>
    <LM>w#w-d-id63142-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t183-15">
   <w.rf>
    <LM>w#w-d1t183-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t183-16">
   <w.rf>
    <LM>w#w-d1t183-16</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m103-d1t183-17">
   <w.rf>
    <LM>w#w-d1t183-17</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m103-d-m-d1e176-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e176-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e185-x2">
  <m id="m103-d1t188-3">
   <w.rf>
    <LM>w#w-d1t188-3</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t188-6">
   <w.rf>
    <LM>w#w-d1t188-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m103-d1t188-8">
   <w.rf>
    <LM>w#w-d1t188-8</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m103-d-id63376-punct">
   <w.rf>
    <LM>w#w-d-id63376-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t188-10">
   <w.rf>
    <LM>w#w-d1t188-10</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t188-15">
   <w.rf>
    <LM>w#w-d1t188-15</LM>
   </w.rf>
   <form>jezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1e185-x2-84">
   <w.rf>
    <LM>w#w-d1e185-x2-84</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t188-11">
   <w.rf>
    <LM>w#w-d1t188-11</LM>
   </w.rf>
   <form>chodívám</form>
   <lemma>chodívat_^(*4it)</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1t188-12">
   <w.rf>
    <LM>w#w-d1t188-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m103-d1t188-14">
   <w.rf>
    <LM>w#w-d1t188-14</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m103-d1e185-x2-82">
   <w.rf>
    <LM>w#w-d1e185-x2-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-83">
  <m id="m103-d1t188-17">
   <w.rf>
    <LM>w#w-d1t188-17</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t188-18">
   <w.rf>
    <LM>w#w-d1t188-18</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t188-20">
   <w.rf>
    <LM>w#w-d1t188-20</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m103-d1t188-21">
   <w.rf>
    <LM>w#w-d1t188-21</LM>
   </w.rf>
   <form>rodičové</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m103-d-m-d1e185-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e185-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e189-x2">
  <m id="m103-d1t192-1">
   <w.rf>
    <LM>w#w-d1t192-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t192-2">
   <w.rf>
    <LM>w#w-d1t192-2</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m103-d1t192-3">
   <w.rf>
    <LM>w#w-d1t192-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m103-d1t192-4">
   <w.rf>
    <LM>w#w-d1t192-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m103-d1t192-5">
   <w.rf>
    <LM>w#w-d1t192-5</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m103-d-id63694-punct">
   <w.rf>
    <LM>w#w-d-id63694-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e193-x2">
  <m id="m103-d1t196-9">
   <w.rf>
    <LM>w#w-d1t196-9</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d1t196-11">
   <w.rf>
    <LM>w#w-d1t196-11</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>třípokojový</form>
   <lemma>třípokojový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m103-d1t196-12">
   <w.rf>
    <LM>w#w-d1t196-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1e193-x2-99">
   <w.rf>
    <LM>w#w-d1e193-x2-99</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t196-13">
   <w.rf>
    <LM>w#w-d1t196-13</LM>
   </w.rf>
   <form>kuchyň</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d1e193-x2-145">
   <w.rf>
    <LM>w#w-d1e193-x2-145</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t196-15">
   <w.rf>
    <LM>w#w-d1t196-15</LM>
   </w.rf>
   <form>komora</form>
   <lemma>komora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d1e193-x2-100">
   <w.rf>
    <LM>w#w-d1e193-x2-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-101">
  <m id="m103-d1t198-5">
   <w.rf>
    <LM>w#w-d1t198-5</LM>
   </w.rf>
   <form>Vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t198-4">
   <w.rf>
    <LM>w#w-d1t198-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t198-3">
   <w.rf>
    <LM>w#w-d1t198-3</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m103-101-102">
   <w.rf>
    <LM>w#w-101-102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-103">
  <m id="m103-d1t200-1">
   <w.rf>
    <LM>w#w-d1t200-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t200-2">
   <w.rf>
    <LM>w#w-d1t200-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t200-3">
   <w.rf>
    <LM>w#w-d1t200-3</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m103-103-104">
   <w.rf>
    <LM>w#w-103-104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t200-5">
   <w.rf>
    <LM>w#w-d1t200-5</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m103-d-id64165-punct">
   <w.rf>
    <LM>w#w-d-id64165-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t200-7">
   <w.rf>
    <LM>w#w-d1t200-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t200-8">
   <w.rf>
    <LM>w#w-d1t200-8</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t200-9">
   <w.rf>
    <LM>w#w-d1t200-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t200-10">
   <w.rf>
    <LM>w#w-d1t200-10</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m103-d1t200-11">
   <w.rf>
    <LM>w#w-d1t200-11</LM>
   </w.rf>
   <form>hlavic</form>
   <lemma>hlavice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m103-d1t200-12">
   <w.rf>
    <LM>w#w-d1t200-12</LM>
   </w.rf>
   <form>vína</form>
   <lemma>víno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m103-d1t200-14">
   <w.rf>
    <LM>w#w-d1t200-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t200-16">
   <w.rf>
    <LM>w#w-d1t200-16</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m103-d1t200-15">
   <w.rf>
    <LM>w#w-d1t200-15</LM>
   </w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m103-103-105">
   <w.rf>
    <LM>w#w-103-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e207-x2">
  <m id="m103-d1t212-1">
   <w.rf>
    <LM>w#w-d1t212-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t212-2">
   <w.rf>
    <LM>w#w-d1t212-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1e207-x2-98">
   <w.rf>
    <LM>w#w-d1e207-x2-98</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m103-d-m-d1e207-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e207-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e207-x3">
  <m id="m103-d1t214-1">
   <w.rf>
    <LM>w#w-d1t214-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t214-2">
   <w.rf>
    <LM>w#w-d1t214-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t214-3">
   <w.rf>
    <LM>w#w-d1t214-3</LM>
   </w.rf>
   <form>trávila</form>
   <lemma>trávit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t214-4">
   <w.rf>
    <LM>w#w-d1t214-4</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m103-d-id64483-punct">
   <w.rf>
    <LM>w#w-d-id64483-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e215-x2">
  <m id="m103-d1t218-1">
   <w.rf>
    <LM>w#w-d1t218-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d-id64560-punct">
   <w.rf>
    <LM>w#w-d-id64560-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e219-x2">
  <m id="m103-d1t222-1">
   <w.rf>
    <LM>w#w-d1t222-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t222-2">
   <w.rf>
    <LM>w#w-d1t222-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t222-3">
   <w.rf>
    <LM>w#w-d1t222-3</LM>
   </w.rf>
   <form>trávila</form>
   <lemma>trávit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t222-4">
   <w.rf>
    <LM>w#w-d1t222-4</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m103-d-id64684-punct">
   <w.rf>
    <LM>w#w-d-id64684-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e223-x2">
  <m id="m103-d1t226-1">
   <w.rf>
    <LM>w#w-d1t226-1</LM>
   </w.rf>
   <form>Léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m103-d-id64761-punct">
   <w.rf>
    <LM>w#w-d-id64761-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e223-x3">
  <m id="m103-d1t228-4">
   <w.rf>
    <LM>w#w-d1t228-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t228-3">
   <w.rf>
    <LM>w#w-d1t228-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t228-5">
   <w.rf>
    <LM>w#w-d1t228-5</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d-id64862-punct">
   <w.rf>
    <LM>w#w-d-id64862-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t228-11">
   <w.rf>
    <LM>w#w-d1t228-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m103-d1t228-12">
   <w.rf>
    <LM>w#w-d1t228-12</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m103-d1t228-8">
   <w.rf>
    <LM>w#w-d1t228-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t228-10">
   <w.rf>
    <LM>w#w-d1t228-10</LM>
   </w.rf>
   <form>nikde</form>
   <lemma>nikde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t228-9">
   <w.rf>
    <LM>w#w-d1t228-9</LM>
   </w.rf>
   <form>nejezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m103-d1e223-x3-115">
   <w.rf>
    <LM>w#w-d1e223-x3-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-114">
  <m id="m103-d1t230-6">
   <w.rf>
    <LM>w#w-d1t230-6</LM>
   </w.rf>
   <form>Jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m103-d1t230-5">
   <w.rf>
    <LM>w#w-d1t230-5</LM>
   </w.rf>
   <form>nerad</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------N----</tag>
  </m>
  <m id="m103-d1t230-7">
   <w.rf>
    <LM>w#w-d1t230-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t230-8">
   <w.rf>
    <LM>w#w-d1t230-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m103-d1t230-10">
   <w.rf>
    <LM>w#w-d1t230-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1t230-9">
   <w.rf>
    <LM>w#w-d1t230-9</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t230-11">
   <w.rf>
    <LM>w#w-d1t230-11</LM>
   </w.rf>
   <form>nerada</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------N----</tag>
  </m>
  <m id="m103-d1t230-12">
   <w.rf>
    <LM>w#w-d1t230-12</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t230-13">
   <w.rf>
    <LM>w#w-d1t230-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m103-d1t230-14">
   <w.rf>
    <LM>w#w-d1t230-14</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m103-d1t230-15">
   <w.rf>
    <LM>w#w-d1t230-15</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m103-d1t230-16">
   <w.rf>
    <LM>w#w-d1t230-16</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t230-17">
   <w.rf>
    <LM>w#w-d1t230-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d-m-d1e223-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e223-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e231-x3">
  <m id="m103-d1t240-1">
   <w.rf>
    <LM>w#w-d1t240-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t240-2">
   <w.rf>
    <LM>w#w-d1t240-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t240-3">
   <w.rf>
    <LM>w#w-d1t240-3</LM>
   </w.rf>
   <form>trávila</form>
   <lemma>trávit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t240-4">
   <w.rf>
    <LM>w#w-d1t240-4</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m103-d1t240-5">
   <w.rf>
    <LM>w#w-d1t240-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t240-6">
   <w.rf>
    <LM>w#w-d1t240-6</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m103-d-id65521-punct">
   <w.rf>
    <LM>w#w-d-id65521-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e241-x2">
  <m id="m103-d1t246-1">
   <w.rf>
    <LM>w#w-d1t246-1</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t246-2">
   <w.rf>
    <LM>w#w-d1t246-2</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m103-d1t246-3">
   <w.rf>
    <LM>w#w-d1t246-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t246-4">
   <w.rf>
    <LM>w#w-d1t246-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t246-5">
   <w.rf>
    <LM>w#w-d1t246-5</LM>
   </w.rf>
   <form>nejezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m103-d-id65662-punct">
   <w.rf>
    <LM>w#w-d-id65662-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t246-7">
   <w.rf>
    <LM>w#w-d1t246-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t246-12">
   <w.rf>
    <LM>w#w-d1t246-12</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m103-d1t246-8">
   <w.rf>
    <LM>w#w-d1t246-8</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m103-d1t246-9">
   <w.rf>
    <LM>w#w-d1t246-9</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m103-d1e241-x2-126">
   <w.rf>
    <LM>w#w-d1e241-x2-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-127">
  <m id="m103-d1t246-16">
   <w.rf>
    <LM>w#w-d1t246-16</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m103-127-131">
   <w.rf>
    <LM>w#w-127-131</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t246-17">
   <w.rf>
    <LM>w#w-d1t246-17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t246-18">
   <w.rf>
    <LM>w#w-d1t246-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t246-19">
   <w.rf>
    <LM>w#w-d1t246-19</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t246-20">
   <w.rf>
    <LM>w#w-d1t246-20</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-127-136">
   <w.rf>
    <LM>w#w-127-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-137">
  <m id="m103-d1t246-23">
   <w.rf>
    <LM>w#w-d1t246-23</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m103-d1t246-22">
   <w.rf>
    <LM>w#w-d1t246-22</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t246-24">
   <w.rf>
    <LM>w#w-d1t246-24</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d1t246-25">
   <w.rf>
    <LM>w#w-d1t246-25</LM>
   </w.rf>
   <form>chudobné</form>
   <lemma>chudobný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m103-137-140">
   <w.rf>
    <LM>w#w-137-140</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-141">
  <m id="m103-d1t248-4">
   <w.rf>
    <LM>w#w-d1t248-4</LM>
   </w.rf>
   <form>Museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t248-2">
   <w.rf>
    <LM>w#w-d1t248-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t248-3">
   <w.rf>
    <LM>w#w-d1t248-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t248-5">
   <w.rf>
    <LM>w#w-d1t248-5</LM>
   </w.rf>
   <form>uskrovňovat</form>
   <lemma>uskrovňovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m103-127-132">
   <w.rf>
    <LM>w#w-127-132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t250-1">
   <w.rf>
    <LM>w#w-d1t250-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t250-2">
   <w.rf>
    <LM>w#w-d1t250-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t250-3">
   <w.rf>
    <LM>w#w-d1t250-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t250-5">
   <w.rf>
    <LM>w#w-d1t250-5</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t250-4">
   <w.rf>
    <LM>w#w-d1t250-4</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-127-134">
   <w.rf>
    <LM>w#w-127-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-135">
  <m id="m103-d1t250-6">
   <w.rf>
    <LM>w#w-d1t250-6</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d1t250-7">
   <w.rf>
    <LM>w#w-d1t250-7</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t250-9">
   <w.rf>
    <LM>w#w-d1t250-9</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m103-135-144">
   <w.rf>
    <LM>w#w-135-144</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m103-135-145">
   <w.rf>
    <LM>w#w-135-145</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-135-146">
   <w.rf>
    <LM>w#w-135-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-147">
  <m id="m103-d1t250-14">
   <w.rf>
    <LM>w#w-d1t250-14</LM>
   </w.rf>
   <form>Hrávali</form>
   <lemma>hrávat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m103-d1t250-12">
   <w.rf>
    <LM>w#w-d1t250-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t250-13">
   <w.rf>
    <LM>w#w-d1t250-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m103-d1t252-1">
   <w.rf>
    <LM>w#w-d1t252-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t252-2">
   <w.rf>
    <LM>w#w-d1t252-2</LM>
   </w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m103-d1t252-3">
   <w.rf>
    <LM>w#w-d1t252-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t252-4">
   <w.rf>
    <LM>w#w-d1t252-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-147-148">
   <w.rf>
    <LM>w#w-147-148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-149">
  <m id="m103-d1t255-3">
   <w.rf>
    <LM>w#w-d1t255-3</LM>
   </w.rf>
   <form>Nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m103-d1t255-2">
   <w.rf>
    <LM>w#w-d1t255-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t255-4">
   <w.rf>
    <LM>w#w-d1t255-4</LM>
   </w.rf>
   <form>takoví</form>
   <lemma>takový</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m103-d1t255-5">
   <w.rf>
    <LM>w#w-d1t255-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t255-6">
   <w.rf>
    <LM>w#w-d1t255-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d-m-d1e241-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e241-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e256-x2">
  <m id="m103-d1t259-1">
   <w.rf>
    <LM>w#w-d1t259-1</LM>
   </w.rf>
   <form>Kamarádily</form>
   <lemma>kamarádit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t259-2">
   <w.rf>
    <LM>w#w-d1t259-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t259-3">
   <w.rf>
    <LM>w#w-d1t259-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t259-4">
   <w.rf>
    <LM>w#w-d1t259-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m103-d1t259-5">
   <w.rf>
    <LM>w#w-d1t259-5</LM>
   </w.rf>
   <form>děvčetem</form>
   <lemma>děvče</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m103-d1t259-6">
   <w.rf>
    <LM>w#w-d1t259-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t259-7">
   <w.rf>
    <LM>w#w-d1t259-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m103-d-id66645-punct">
   <w.rf>
    <LM>w#w-d-id66645-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e260-x2">
  <m id="m103-d1t263-1">
   <w.rf>
    <LM>w#w-d1t263-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d-id66722-punct">
   <w.rf>
    <LM>w#w-d-id66722-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t263-4">
   <w.rf>
    <LM>w#w-d1t263-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t263-5">
   <w.rf>
    <LM>w#w-d1t263-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t263-6">
   <w.rf>
    <LM>w#w-d1t263-6</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m103-d-id66793-punct">
   <w.rf>
    <LM>w#w-d-id66793-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t267-2">
   <w.rf>
    <LM>w#w-d1t267-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m103-d1t267-3">
   <w.rf>
    <LM>w#w-d1t267-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t267-4">
   <w.rf>
    <LM>w#w-d1t267-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1t267-5">
   <w.rf>
    <LM>w#w-d1t267-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t267-7">
   <w.rf>
    <LM>w#w-d1t267-7</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t267-6">
   <w.rf>
    <LM>w#w-d1t267-6</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m103-d1e260-x2-156">
   <w.rf>
    <LM>w#w-d1e260-x2-156</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-157">
  <m id="m103-d1t269-1">
   <w.rf>
    <LM>w#w-d1t269-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-157-158">
   <w.rf>
    <LM>w#w-157-158</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t269-2">
   <w.rf>
    <LM>w#w-d1t269-2</LM>
   </w.rf>
   <form>sousedovic</form>
   <lemma>sousedův_^(*2)</lemma>
   <tag>AUXXXM--------5</tag>
  </m>
  <m id="m103-d1t269-3">
   <w.rf>
    <LM>w#w-d1t269-3</LM>
   </w.rf>
   <form>kamarádky</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m103-d1t269-4">
   <w.rf>
    <LM>w#w-d1t269-4</LM>
   </w.rf>
   <form>dceruška</form>
   <lemma>dceruška</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d-m-d1e260-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e260-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e270-x2">
  <m id="m103-d1t273-2">
   <w.rf>
    <LM>w#w-d1t273-2</LM>
   </w.rf>
   <form>Nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t273-3">
   <w.rf>
    <LM>w#w-d1t273-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m103-d1t273-4">
   <w.rf>
    <LM>w#w-d1t273-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m103-d1e270-x2-160">
   <w.rf>
    <LM>w#w-d1e270-x2-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-161">
  <m id="m103-d1t275-1">
   <w.rf>
    <LM>w#w-d1t275-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m103-d1t275-2">
   <w.rf>
    <LM>w#w-d1t275-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t275-3">
   <w.rf>
    <LM>w#w-d1t275-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t275-4">
   <w.rf>
    <LM>w#w-d1t275-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t275-5">
   <w.rf>
    <LM>w#w-d1t275-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m103-d-id67260-punct">
   <w.rf>
    <LM>w#w-d-id67260-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e276-x2">
  <m id="m103-d1t279-2">
   <w.rf>
    <LM>w#w-d1t279-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m103-d1t279-3">
   <w.rf>
    <LM>w#w-d1t279-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t279-4">
   <w.rf>
    <LM>w#w-d1t279-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m103-d1t279-5">
   <w.rf>
    <LM>w#w-d1t279-5</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m103-d-id67399-punct">
   <w.rf>
    <LM>w#w-d-id67399-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t279-7">
   <w.rf>
    <LM>w#w-d1t279-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t279-8">
   <w.rf>
    <LM>w#w-d1t279-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t279-11">
   <w.rf>
    <LM>w#w-d1t279-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t279-12">
   <w.rf>
    <LM>w#w-d1t279-12</LM>
   </w.rf>
   <form>procházely</form>
   <lemma>procházet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1e276-x2-167">
   <w.rf>
    <LM>w#w-d1e276-x2-167</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t281-1">
   <w.rf>
    <LM>w#w-d1t281-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d1t281-2">
   <w.rf>
    <LM>w#w-d1t281-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t281-3">
   <w.rf>
    <LM>w#w-d1t281-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t281-4">
   <w.rf>
    <LM>w#w-d1t281-4</LM>
   </w.rf>
   <form>fotily</form>
   <lemma>fotit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1e276-x2-168">
   <w.rf>
    <LM>w#w-d1e276-x2-168</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-169">
  <m id="m103-d1t281-9">
   <w.rf>
    <LM>w#w-d1t281-9</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t281-7">
   <w.rf>
    <LM>w#w-d1t281-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t281-8">
   <w.rf>
    <LM>w#w-d1t281-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t281-6">
   <w.rf>
    <LM>w#w-d1t281-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t281-10">
   <w.rf>
    <LM>w#w-d1t281-10</LM>
   </w.rf>
   <form>rády</form>
   <lemma>rád-1</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m103-169-173">
   <w.rf>
    <LM>w#w-169-173</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-174">
  <m id="m103-d1t281-13">
   <w.rf>
    <LM>w#w-d1t281-13</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t281-14">
   <w.rf>
    <LM>w#w-d1t281-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m103-d1t281-15">
   <w.rf>
    <LM>w#w-d1t281-15</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m103-d1t281-16">
   <w.rf>
    <LM>w#w-d1t281-16</LM>
   </w.rf>
   <form>neviděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m103-d1t281-17">
   <w.rf>
    <LM>w#w-d1t281-17</LM>
   </w.rf>
   <form>mnoho</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m103-d1t281-18">
   <w.rf>
    <LM>w#w-d1t281-18</LM>
   </w.rf>
   <form>roků</form>
   <lemma>rok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m103-174-179">
   <w.rf>
    <LM>w#w-174-179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-180">
  <m id="m103-d1t281-20">
   <w.rf>
    <LM>w#w-d1t281-20</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m103-174-175">
   <w.rf>
    <LM>w#w-174-175</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t281-21">
   <w.rf>
    <LM>w#w-d1t281-21</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t283-1">
   <w.rf>
    <LM>w#w-d1t283-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t283-2">
   <w.rf>
    <LM>w#w-d1t283-2</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d-id67885-punct">
   <w.rf>
    <LM>w#w-d-id67885-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t283-4">
   <w.rf>
    <LM>w#w-d1t283-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t283-5">
   <w.rf>
    <LM>w#w-d1t283-5</LM>
   </w.rf>
   <form>nežije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m103-d-m-d1e276-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e276-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e284-x2">
  <m id="m103-d1t287-1">
   <w.rf>
    <LM>w#w-d1t287-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t287-2">
   <w.rf>
    <LM>w#w-d1t287-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t287-3">
   <w.rf>
    <LM>w#w-d1t287-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t287-4">
   <w.rf>
    <LM>w#w-d1t287-4</LM>
   </w.rf>
   <form>poznaly</form>
   <lemma>poznat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m103-d-id68040-punct">
   <w.rf>
    <LM>w#w-d-id68040-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e289-x2">
  <m id="m103-d1t294-5">
   <w.rf>
    <LM>w#w-d1t294-5</LM>
   </w.rf>
   <form>Bydlely</form>
   <lemma>bydlet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t294-4">
   <w.rf>
    <LM>w#w-d1t294-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t294-2">
   <w.rf>
    <LM>w#w-d1t294-2</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-3</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m103-d1t294-3">
   <w.rf>
    <LM>w#w-d1t294-3</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m103-d-id68235-punct">
   <w.rf>
    <LM>w#w-d-id68235-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t294-7">
   <w.rf>
    <LM>w#w-d1t294-7</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m103-d1t294-8">
   <w.rf>
    <LM>w#w-d1t294-8</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m103-d1e289-x2-193">
   <w.rf>
    <LM>w#w-d1e289-x2-193</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-194">
  <m id="m103-d1t294-9">
   <w.rf>
    <LM>w#w-d1t294-9</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t294-13">
   <w.rf>
    <LM>w#w-d1t294-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t294-15">
   <w.rf>
    <LM>w#w-d1t294-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t294-14">
   <w.rf>
    <LM>w#w-d1t294-14</LM>
   </w.rf>
   <form>poznaly</form>
   <lemma>poznat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m103-194-195">
   <w.rf>
    <LM>w#w-194-195</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-196">
  <m id="m103-d1t296-2">
   <w.rf>
    <LM>w#w-d1t296-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m103-d1t296-4">
   <w.rf>
    <LM>w#w-d1t296-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m103-d1t296-5">
   <w.rf>
    <LM>w#w-d1t296-5</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m103-d1t296-6">
   <w.rf>
    <LM>w#w-d1t296-6</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m103-196-197">
   <w.rf>
    <LM>w#w-196-197</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-198">
  <m id="m103-d1t296-12">
   <w.rf>
    <LM>w#w-d1t296-12</LM>
   </w.rf>
   <form>Znaly</form>
   <lemma>znát</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t296-10">
   <w.rf>
    <LM>w#w-d1t296-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t296-11">
   <w.rf>
    <LM>w#w-d1t296-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t296-13">
   <w.rf>
    <LM>w#w-d1t296-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t296-14">
   <w.rf>
    <LM>w#w-d1t296-14</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d1t296-15">
   <w.rf>
    <LM>w#w-d1t296-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t296-16">
   <w.rf>
    <LM>w#w-d1t296-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t296-17">
   <w.rf>
    <LM>w#w-d1t296-17</LM>
   </w.rf>
   <form>kamarádily</form>
   <lemma>kamarádit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t298-3">
   <w.rf>
    <LM>w#w-d1t298-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m103-d1t298-1">
   <w.rf>
    <LM>w#w-d1t298-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t298-7">
   <w.rf>
    <LM>w#w-d1t298-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m103-d1t298-8">
   <w.rf>
    <LM>w#w-d1t298-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m103-d1t298-4">
   <w.rf>
    <LM>w#w-d1t298-4</LM>
   </w.rf>
   <form>svaz</form>
   <lemma>svaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m103-d1t298-5">
   <w.rf>
    <LM>w#w-d1t298-5</LM>
   </w.rf>
   <form>mládeže</form>
   <lemma>mládež</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m103-198-199">
   <w.rf>
    <LM>w#w-198-199</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-200">
  <m id="m103-d1t298-17">
   <w.rf>
    <LM>w#w-d1t298-17</LM>
   </w.rf>
   <form>Kamarádily</form>
   <lemma>kamarádit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d1t298-15">
   <w.rf>
    <LM>w#w-d1t298-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m103-d1t298-16">
   <w.rf>
    <LM>w#w-d1t298-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t298-18">
   <w.rf>
    <LM>w#w-d1t298-18</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d-m-d1e289-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e289-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e299-x2">
  <m id="m103-d1t302-1">
   <w.rf>
    <LM>w#w-d1t302-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t302-2">
   <w.rf>
    <LM>w#w-d1t302-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d1t302-3">
   <w.rf>
    <LM>w#w-d1t302-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t302-4">
   <w.rf>
    <LM>w#w-d1t302-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m103-d1t302-5">
   <w.rf>
    <LM>w#w-d1t302-5</LM>
   </w.rf>
   <form>vídaly</form>
   <lemma>vídat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m103-d-id69108-punct">
   <w.rf>
    <LM>w#w-d-id69108-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e303-x2">
  <m id="m103-d1t308-2">
   <w.rf>
    <LM>w#w-d1t308-2</LM>
   </w.rf>
   <form>Pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m103-d1t308-3">
   <w.rf>
    <LM>w#w-d1t308-3</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m103-d1t308-4">
   <w.rf>
    <LM>w#w-d1t308-4</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m103-d-id69240-punct">
   <w.rf>
    <LM>w#w-d-id69240-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m103-d1t308-10">
   <w.rf>
    <LM>w#w-d1t308-10</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t308-8">
   <w.rf>
    <LM>w#w-d1t308-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m103-d1t308-9">
   <w.rf>
    <LM>w#w-d1t308-9</LM>
   </w.rf>
   <form>večeru</form>
   <lemma>večer-1</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m103-d-m-d1e303-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e303-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e309-x2">
  <m id="m103-d1t312-1">
   <w.rf>
    <LM>w#w-d1t312-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m103-d1t312-2">
   <w.rf>
    <LM>w#w-d1t312-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m103-d1t312-3">
   <w.rf>
    <LM>w#w-d1t312-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m103-d1t312-4">
   <w.rf>
    <LM>w#w-d1t312-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t312-5">
   <w.rf>
    <LM>w#w-d1t312-5</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m103-d1t312-6">
   <w.rf>
    <LM>w#w-d1t312-6</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m103-d1t312-7">
   <w.rf>
    <LM>w#w-d1t312-7</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m103-d-id69481-punct">
   <w.rf>
    <LM>w#w-d-id69481-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e313-x2">
  <m id="m103-d1t316-1">
   <w.rf>
    <LM>w#w-d1t316-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t316-2">
   <w.rf>
    <LM>w#w-d1t316-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m103-d1t316-3">
   <w.rf>
    <LM>w#w-d1t316-3</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m103-d1t316-4">
   <w.rf>
    <LM>w#w-d1t316-4</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m103-d1t316-10">
   <w.rf>
    <LM>w#w-d1t316-10</LM>
   </w.rf>
   <form>šestnáct</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m103-d1t316-11">
   <w.rf>
    <LM>w#w-d1t316-11</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m103-d1t316-12">
   <w.rf>
    <LM>w#w-d1t316-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t316-13">
   <w.rf>
    <LM>w#w-d1t316-13</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1e313-x2-208">
   <w.rf>
    <LM>w#w-d1e313-x2-208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-209">
  <m id="m103-d1t316-16">
   <w.rf>
    <LM>w#w-d1t316-16</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m103-d1t316-14">
   <w.rf>
    <LM>w#w-d1t316-14</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m103-d1t316-19">
   <w.rf>
    <LM>w#w-d1t316-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m103-d1t316-20">
   <w.rf>
    <LM>w#w-d1t316-20</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m103-d1t316-21">
   <w.rf>
    <LM>w#w-d1t316-21</LM>
   </w.rf>
   <form>kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m103-d-m-d1e313-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e313-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m103-d1e319-x2">
  <m id="m103-d1t322-1">
   <w.rf>
    <LM>w#w-d1t322-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m103-d1t322-2">
   <w.rf>
    <LM>w#w-d1t322-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m103-d1t322-3">
   <w.rf>
    <LM>w#w-d1t322-3</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m103-d1t322-4">
   <w.rf>
    <LM>w#w-d1t322-4</LM>
   </w.rf>
   <form>sváteční</form>
   <lemma>sváteční</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m103-d1t322-5">
   <w.rf>
    <LM>w#w-d1t322-5</LM>
   </w.rf>
   <form>oděv</form>
   <lemma>oděv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m103-d-id69988-punct">
   <w.rf>
    <LM>w#w-d-id69988-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
