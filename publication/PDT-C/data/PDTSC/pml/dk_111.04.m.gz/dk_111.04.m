<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="dk_111.04.w.gz" />
  </references>
 </head>
 <s id="m111-1004">
  <m id="m111-d1t569-13">
   <w.rf>
    <LM>w#w-d1t569-13</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t569-15">
   <w.rf>
    <LM>w#w-d1t569-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t569-16">
   <w.rf>
    <LM>w#w-d1t569-16</LM>
   </w.rf>
   <form>mrňavá</form>
   <lemma>mrňavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m111-d1t569-17">
   <w.rf>
    <LM>w#w-d1t569-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t569-18">
   <w.rf>
    <LM>w#w-d1t569-18</LM>
   </w.rf>
   <form>stála</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t569-19">
   <w.rf>
    <LM>w#w-d1t569-19</LM>
   </w.rf>
   <form>přede</form>
   <lemma>před-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m111-d1t569-20">
   <w.rf>
    <LM>w#w-d1t569-20</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m111-d1t569-21">
   <w.rf>
    <LM>w#w-d1t569-21</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m111-d1t569-22">
   <w.rf>
    <LM>w#w-d1t569-22</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m111-d-id92046-punct">
   <w.rf>
    <LM>w#w-d-id92046-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t569-24">
   <w.rf>
    <LM>w#w-d1t569-24</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t569-25">
   <w.rf>
    <LM>w#w-d1t569-25</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t569-26">
   <w.rf>
    <LM>w#w-d1t569-26</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m111-d1t569-27">
   <w.rf>
    <LM>w#w-d1t569-27</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t569-28">
   <w.rf>
    <LM>w#w-d1t569-28</LM>
   </w.rf>
   <form>neviděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m111-1004-1012">
   <w.rf>
    <LM>w#w-1004-1012</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1013">
  <m id="m111-d1t571-2">
   <w.rf>
    <LM>w#w-d1t571-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t571-3">
   <w.rf>
    <LM>w#w-d1t571-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t571-4">
   <w.rf>
    <LM>w#w-d1t571-4</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t571-5">
   <w.rf>
    <LM>w#w-d1t571-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t571-7">
   <w.rf>
    <LM>w#w-d1t571-7</LM>
   </w.rf>
   <form>Cannes</form>
   <lemma>Cannes_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m111-1013-1021">
   <w.rf>
    <LM>w#w-1013-1021</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1022">
  <m id="m111-d1t573-3">
   <w.rf>
    <LM>w#w-d1t573-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t573-4">
   <w.rf>
    <LM>w#w-d1t573-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m111-d1t573-5">
   <w.rf>
    <LM>w#w-d1t573-5</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m111-1013-1019">
   <w.rf>
    <LM>w#w-1013-1019</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1020">
  <m id="m111-d1t573-8">
   <w.rf>
    <LM>w#w-d1t573-8</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t573-9">
   <w.rf>
    <LM>w#w-d1t573-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t573-10">
   <w.rf>
    <LM>w#w-d1t573-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t573-11">
   <w.rf>
    <LM>w#w-d1t573-11</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t573-12">
   <w.rf>
    <LM>w#w-d1t573-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t573-13">
   <w.rf>
    <LM>w#w-d1t573-13</LM>
   </w.rf>
   <form>vykoupali</form>
   <lemma>vykoupat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m111-d-m-d1e503-x6-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e503-x6-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e574-x2">
  <m id="m111-d1t579-2">
   <w.rf>
    <LM>w#w-d1t579-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t579-3">
   <w.rf>
    <LM>w#w-d1t579-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m111-d1t579-4">
   <w.rf>
    <LM>w#w-d1t579-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t579-5">
   <w.rf>
    <LM>w#w-d1t579-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m111-d-m-d1e574-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e574-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e574-x3">
  <m id="m111-d1t581-1">
   <w.rf>
    <LM>w#w-d1t581-1</LM>
   </w.rf>
   <form>Umíte</form>
   <lemma>umět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d1t581-2">
   <w.rf>
    <LM>w#w-d1t581-2</LM>
   </w.rf>
   <form>francouzsky</form>
   <lemma>francouzsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d-id92593-punct">
   <w.rf>
    <LM>w#w-d-id92593-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e582-x2">
  <m id="m111-d1e582-x2-1027">
   <w.rf>
    <LM>w#w-d1e582-x2-1027</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1e582-x2-1028">
   <w.rf>
    <LM>w#w-d1e582-x2-1028</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t585-2">
   <w.rf>
    <LM>w#w-d1t585-2</LM>
   </w.rf>
   <form>mluvím</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t585-3">
   <w.rf>
    <LM>w#w-d1t585-3</LM>
   </w.rf>
   <form>francouzsky</form>
   <lemma>francouzsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d-m-d1e582-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e582-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e593-x2">
  <m id="m111-d1t596-1">
   <w.rf>
    <LM>w#w-d1t596-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t596-2">
   <w.rf>
    <LM>w#w-d1t596-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d1t596-3">
   <w.rf>
    <LM>w#w-d1t596-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t596-4">
   <w.rf>
    <LM>w#w-d1t596-4</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d-id92796-punct">
   <w.rf>
    <LM>w#w-d-id92796-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e597-x2">
  <m id="m111-d1t602-3">
   <w.rf>
    <LM>w#w-d1t602-3</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t602-2">
   <w.rf>
    <LM>w#w-d1t602-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t602-4">
   <w.rf>
    <LM>w#w-d1t602-4</LM>
   </w.rf>
   <form>jazykovku</form>
   <lemma>jazykovka_,h</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1e597-x2-1041">
   <w.rf>
    <LM>w#w-d1e597-x2-1041</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1042">
  <m id="m111-d1t604-8">
   <w.rf>
    <LM>w#w-d1t604-8</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t604-7">
   <w.rf>
    <LM>w#w-d1t604-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t606-1">
   <w.rf>
    <LM>w#w-d1t606-1</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d-id93086-punct">
   <w.rf>
    <LM>w#w-d-id93086-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t606-3">
   <w.rf>
    <LM>w#w-d1t606-3</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m111-d1t606-4">
   <w.rf>
    <LM>w#w-d1t606-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m111-d1t606-5">
   <w.rf>
    <LM>w#w-d1t606-5</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t606-6">
   <w.rf>
    <LM>w#w-d1t606-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t606-7">
   <w.rf>
    <LM>w#w-d1t606-7</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m111-d1t606-8">
   <w.rf>
    <LM>w#w-d1t606-8</LM>
   </w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m111-d1t606-9">
   <w.rf>
    <LM>w#w-d1t606-9</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m111-1042-1052">
   <w.rf>
    <LM>w#w-1042-1052</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1053">
  <m id="m111-d1t606-12">
   <w.rf>
    <LM>w#w-d1t606-12</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t606-11">
   <w.rf>
    <LM>w#w-d1t606-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t606-15">
   <w.rf>
    <LM>w#w-d1t606-15</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známá-1_^(*3ý-1)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m111-d1t606-13">
   <w.rf>
    <LM>w#w-d1t606-13</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1-------</tag>
  </m>
  <m id="m111-d1t606-14">
   <w.rf>
    <LM>w#w-d1t606-14</LM>
   </w.rf>
   <form>mámy</form>
   <lemma>máma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-1053-1062">
   <w.rf>
    <LM>w#w-1053-1062</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1063">
  <m id="m111-d1t606-17">
   <w.rf>
    <LM>w#w-d1t606-17</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t606-18">
   <w.rf>
    <LM>w#w-d1t606-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t606-19">
   <w.rf>
    <LM>w#w-d1t606-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t606-20">
   <w.rf>
    <LM>w#w-d1t606-20</LM>
   </w.rf>
   <form>gymplu</form>
   <lemma>gympl_,h</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m111-d1t606-25">
   <w.rf>
    <LM>w#w-d1t606-25</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t606-26">
   <w.rf>
    <LM>w#w-d1t606-26</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1t606-27">
   <w.rf>
    <LM>w#w-d1t606-27</LM>
   </w.rf>
   <form>výběru</form>
   <lemma>výběr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m111-1063-189">
   <w.rf>
    <LM>w#w-1063-189</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t606-28">
   <w.rf>
    <LM>w#w-d1t606-28</LM>
   </w.rf>
   <form>angličtinu</form>
   <lemma>angličtina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-1063-190">
   <w.rf>
    <LM>w#w-1063-190</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t606-30">
   <w.rf>
    <LM>w#w-d1t606-30</LM>
   </w.rf>
   <form>francouzštinu</form>
   <lemma>francouzština</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-1063-191">
   <w.rf>
    <LM>w#w-1063-191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-202">
  <m id="m111-d1t606-35">
   <w.rf>
    <LM>w#w-d1t606-35</LM>
   </w.rf>
   <form>Pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t606-33">
   <w.rf>
    <LM>w#w-d1t606-33</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t606-34">
   <w.rf>
    <LM>w#w-d1t606-34</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m111-d1t606-36">
   <w.rf>
    <LM>w#w-d1t606-36</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m111-d1t606-37">
   <w.rf>
    <LM>w#w-d1t606-37</LM>
   </w.rf>
   <form>francouzštinu</form>
   <lemma>francouzština</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-1063-1070">
   <w.rf>
    <LM>w#w-1063-1070</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1071">
  <m id="m111-d1t608-14">
   <w.rf>
    <LM>w#w-d1t608-14</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-1071-1075">
   <w.rf>
    <LM>w#w-1071-1075</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m111-d1t608-15">
   <w.rf>
    <LM>w#w-d1t608-15</LM>
   </w.rf>
   <form>1968</form>
   <lemma>1968</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m111-d1t608-18">
   <w.rf>
    <LM>w#w-d1t608-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t608-19">
   <w.rf>
    <LM>w#w-d1t608-19</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m111-d1t608-20">
   <w.rf>
    <LM>w#w-d1t608-20</LM>
   </w.rf>
   <form>udělala</form>
   <lemma>udělat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m111-d1t608-22">
   <w.rf>
    <LM>w#w-d1t608-22</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t608-23">
   <w.rf>
    <LM>w#w-d1t608-23</LM>
   </w.rf>
   <form>jazykovce</form>
   <lemma>jazykovka_,h</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t608-21">
   <w.rf>
    <LM>w#w-d1t608-21</LM>
   </w.rf>
   <form>státnici</form>
   <lemma>státnice_^(*3ík)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t608-24">
   <w.rf>
    <LM>w#w-d1t608-24</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t608-25">
   <w.rf>
    <LM>w#w-d1t608-25</LM>
   </w.rf>
   <form>francouzštiny</form>
   <lemma>francouzština</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-1071-1076">
   <w.rf>
    <LM>w#w-1071-1076</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e597-x3">
  <m id="m111-d1t611-2">
   <w.rf>
    <LM>w#w-d1t611-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t611-3">
   <w.rf>
    <LM>w#w-d1t611-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t611-4">
   <w.rf>
    <LM>w#w-d1t611-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m111-d1t611-5">
   <w.rf>
    <LM>w#w-d1t611-5</LM>
   </w.rf>
   <form>používala</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t611-6">
   <w.rf>
    <LM>w#w-d1t611-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t611-7">
   <w.rf>
    <LM>w#w-d1t611-7</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t611-9">
   <w.rf>
    <LM>w#w-d1t611-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t611-12">
   <w.rf>
    <LM>w#w-d1t611-12</LM>
   </w.rf>
   <form>francouzskou</form>
   <lemma>francouzský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m111-d1t611-10">
   <w.rf>
    <LM>w#w-d1t611-10</LM>
   </w.rf>
   <form>korespondenci</form>
   <lemma>korespondence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1e597-x3-1086">
   <w.rf>
    <LM>w#w-d1e597-x3-1086</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e612-x2">
  <m id="m111-d1t617-10">
   <w.rf>
    <LM>w#w-d1t617-10</LM>
   </w.rf>
   <form>Francouzsky</form>
   <lemma>francouzsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>korespondovalo</form>
   <lemma>korespondovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m111-d1t617-4">
   <w.rf>
    <LM>w#w-d1t617-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t617-5">
   <w.rf>
    <LM>w#w-d1t617-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m111-d1t617-7">
   <w.rf>
    <LM>w#w-d1t617-7</LM>
   </w.rf>
   <form>Jugoslávci</form>
   <lemma>Jugoslávec_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m111-d-id94364-punct">
   <w.rf>
    <LM>w#w-d-id94364-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t617-11">
   <w.rf>
    <LM>w#w-d1t617-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m111-d1t617-13">
   <w.rf>
    <LM>w#w-d1t617-13</LM>
   </w.rf>
   <form>Španěly</form>
   <lemma>Španěl_;E</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m111-d1e612-x2-1095">
   <w.rf>
    <LM>w#w-d1e612-x2-1095</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t617-19">
   <w.rf>
    <LM>w#w-d1t617-19</LM>
   </w.rf>
   <form>pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t617-15">
   <w.rf>
    <LM>w#w-d1t617-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m111-d1t617-17">
   <w.rf>
    <LM>w#w-d1t617-17</LM>
   </w.rf>
   <form>Francií</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m111-d1e612-x2-1126">
   <w.rf>
    <LM>w#w-d1e612-x2-1126</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1e612-x2-1127">
   <w.rf>
    <LM>w#w-d1e612-x2-1127</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t627-3">
   <w.rf>
    <LM>w#w-d1t627-3</LM>
   </w.rf>
   <form>Italové</form>
   <lemma>Ital_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m111-d1t627-5">
   <w.rf>
    <LM>w#w-d1t627-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m111-d1t627-6">
   <w.rf>
    <LM>w#w-d1t627-6</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t627-7">
   <w.rf>
    <LM>w#w-d1t627-7</LM>
   </w.rf>
   <form>rozuměli</form>
   <lemma>rozumět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1e612-x2-1129">
   <w.rf>
    <LM>w#w-d1e612-x2-1129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1130">
  <m id="m111-d1t627-12">
   <w.rf>
    <LM>w#w-d1t627-12</LM>
   </w.rf>
   <form>Využila</form>
   <lemma>využít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m111-d1t627-10">
   <w.rf>
    <LM>w#w-d1t627-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t627-11">
   <w.rf>
    <LM>w#w-d1t627-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m111-d1t627-14">
   <w.rf>
    <LM>w#w-d1t627-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t627-15">
   <w.rf>
    <LM>w#w-d1t627-15</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1e612-x2-1128">
   <w.rf>
    <LM>w#w-d1e612-x2-1128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e628-x2">
  <m id="m111-d1t631-1">
   <w.rf>
    <LM>w#w-d1t631-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m111-d-m-d1e628-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e628-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e632-x2">
  <m id="m111-d1t637-1">
   <w.rf>
    <LM>w#w-d1t637-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m111-d1t637-2">
   <w.rf>
    <LM>w#w-d1t637-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t637-3">
   <w.rf>
    <LM>w#w-d1t637-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t637-4">
   <w.rf>
    <LM>w#w-d1t637-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m111-d1t637-5">
   <w.rf>
    <LM>w#w-d1t637-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d-m-d1e632-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e632-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e632-x3">
  <m id="m111-d1t639-4">
   <w.rf>
    <LM>w#w-d1t639-4</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1e632-x3-1137">
   <w.rf>
    <LM>w#w-d1e632-x3-1137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t639-1">
   <w.rf>
    <LM>w#w-d1t639-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t639-2">
   <w.rf>
    <LM>w#w-d1t639-2</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m111-d-id95036-punct">
   <w.rf>
    <LM>w#w-d-id95036-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t639-6">
   <w.rf>
    <LM>w#w-d1t639-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t639-7">
   <w.rf>
    <LM>w#w-d1t639-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t639-8">
   <w.rf>
    <LM>w#w-d1t639-8</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1e632-x3-1138">
   <w.rf>
    <LM>w#w-d1e632-x3-1138</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1139">
  <m id="m111-d1t643-1">
   <w.rf>
    <LM>w#w-d1t643-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t643-2">
   <w.rf>
    <LM>w#w-d1t643-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m111-d1t643-3">
   <w.rf>
    <LM>w#w-d1t643-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m111-d1t643-4">
   <w.rf>
    <LM>w#w-d1t643-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m111-d-id95192-punct">
   <w.rf>
    <LM>w#w-d-id95192-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e649-x2">
  <m id="m111-d1t652-1">
   <w.rf>
    <LM>w#w-d1t652-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t652-2">
   <w.rf>
    <LM>w#w-d1t652-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m111-d1t652-5">
   <w.rf>
    <LM>w#w-d1t652-5</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m111-d1t652-6">
   <w.rf>
    <LM>w#w-d1t652-6</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m111-d1e649-x2-18">
   <w.rf>
    <LM>w#w-d1e649-x2-18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-19">
  <m id="m111-d1t652-9">
   <w.rf>
    <LM>w#w-d1t652-9</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m111-d1t652-10">
   <w.rf>
    <LM>w#w-d1t652-10</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m111-d1t652-11">
   <w.rf>
    <LM>w#w-d1t652-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t652-12">
   <w.rf>
    <LM>w#w-d1t652-12</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t652-13">
   <w.rf>
    <LM>w#w-d1t652-13</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m111-d-id95497-punct">
   <w.rf>
    <LM>w#w-d-id95497-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t652-15">
   <w.rf>
    <LM>w#w-d1t652-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t652-17">
   <w.rf>
    <LM>w#w-d1t652-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t652-18">
   <w.rf>
    <LM>w#w-d1t652-18</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t652-19">
   <w.rf>
    <LM>w#w-d1t652-19</LM>
   </w.rf>
   <form>babičky</form>
   <lemma>babička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-d1t652-20">
   <w.rf>
    <LM>w#w-d1t652-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t652-21">
   <w.rf>
    <LM>w#w-d1t652-21</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t652-22">
   <w.rf>
    <LM>w#w-d1t652-22</LM>
   </w.rf>
   <form>dědy</form>
   <lemma>děda</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m111-d1t652-23">
   <w.rf>
    <LM>w#w-d1t652-23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t652-25">
   <w.rf>
    <LM>w#w-d1t652-25</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m111-d1t652-26">
   <w.rf>
    <LM>w#w-d1t652-26</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m111-d1t652-24">
   <w.rf>
    <LM>w#w-d1t652-24</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t652-27">
   <w.rf>
    <LM>w#w-d1t652-27</LM>
   </w.rf>
   <form>tenhleten</form>
   <lemma>tenhleten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m111-19-20">
   <w.rf>
    <LM>w#w-19-20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-21">
  <m id="m111-d1t652-31">
   <w.rf>
    <LM>w#w-d1t652-31</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m111-d1t652-30">
   <w.rf>
    <LM>w#w-d1t652-30</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m111-d1t652-32">
   <w.rf>
    <LM>w#w-d1t652-32</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t652-33">
   <w.rf>
    <LM>w#w-d1t652-33</LM>
   </w.rf>
   <form>jedenáct</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m111-21-51">
   <w.rf>
    <LM>w#w-21-51</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t652-35">
   <w.rf>
    <LM>w#w-d1t652-35</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m111-21-46">
   <w.rf>
    <LM>w#w-21-46</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-50">
  <m id="m111-d1t656-2">
   <w.rf>
    <LM>w#w-d1t656-2</LM>
   </w.rf>
   <form>Keňu</form>
   <lemma>keňa_^(loďka)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1t656-4">
   <w.rf>
    <LM>w#w-d1t656-4</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>támhle</form>
   <lemma>támhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t656-5">
   <w.rf>
    <LM>w#w-d1t656-5</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t656-6">
   <w.rf>
    <LM>w#w-d1t656-6</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m111-d1t656-8">
   <w.rf>
    <LM>w#w-d1t656-8</LM>
   </w.rf>
   <form>šňůrou</form>
   <lemma>šňůra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m111-50-57">
   <w.rf>
    <LM>w#w-50-57</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-58">
  <m id="m111-d1t656-12">
   <w.rf>
    <LM>w#w-d1t656-12</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t656-11">
   <w.rf>
    <LM>w#w-d1t656-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t656-14">
   <w.rf>
    <LM>w#w-d1t656-14</LM>
   </w.rf>
   <form>Lužnici</form>
   <lemma>Lužnice_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1e649-x2-8">
   <w.rf>
    <LM>w#w-d1e649-x2-8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-9">
  <m id="m111-d1t658-2">
   <w.rf>
    <LM>w#w-d1t658-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m111-d1t658-1">
   <w.rf>
    <LM>w#w-d1t658-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t658-4">
   <w.rf>
    <LM>w#w-d1t658-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m111-9-61">
   <w.rf>
    <LM>w#w-9-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-62">
  <m id="m111-d1t658-8">
   <w.rf>
    <LM>w#w-d1t658-8</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t658-7">
   <w.rf>
    <LM>w#w-d1t658-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t658-6">
   <w.rf>
    <LM>w#w-d1t658-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t658-9">
   <w.rf>
    <LM>w#w-d1t658-9</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m111-d1t658-10">
   <w.rf>
    <LM>w#w-d1t658-10</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m111-d-m-d1e649-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e649-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e659-x2">
  <m id="m111-d1t662-1">
   <w.rf>
    <LM>w#w-d1t662-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t662-2">
   <w.rf>
    <LM>w#w-d1t662-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m111-d1t662-3">
   <w.rf>
    <LM>w#w-d1t662-3</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m111-d1t662-4">
   <w.rf>
    <LM>w#w-d1t662-4</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m111-d-id96347-punct">
   <w.rf>
    <LM>w#w-d-id96347-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e663-x2">
  <m id="m111-d1t666-4">
   <w.rf>
    <LM>w#w-d1t666-4</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d-id96463-punct">
   <w.rf>
    <LM>w#w-d-id96463-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t666-6">
   <w.rf>
    <LM>w#w-d1t666-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t666-7">
   <w.rf>
    <LM>w#w-d1t666-7</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m111-d-id96503-punct">
   <w.rf>
    <LM>w#w-d-id96503-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-71">
  <m id="m111-d1t668-4">
   <w.rf>
    <LM>w#w-d1t668-4</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m111-d1t668-5">
   <w.rf>
    <LM>w#w-d1t668-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t668-6">
   <w.rf>
    <LM>w#w-d1t668-6</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t668-7">
   <w.rf>
    <LM>w#w-d1t668-7</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t668-8">
   <w.rf>
    <LM>w#w-d1t668-8</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWIS4----------</tag>
  </m>
  <m id="m111-d1t668-9">
   <w.rf>
    <LM>w#w-d1t668-9</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m111-d1t668-10">
   <w.rf>
    <LM>w#w-d1t668-10</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m111-71-78">
   <w.rf>
    <LM>w#w-71-78</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-79">
  <m id="m111-d1t670-1">
   <w.rf>
    <LM>w#w-d1t670-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m111-d1t670-2">
   <w.rf>
    <LM>w#w-d1t670-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t670-3">
   <w.rf>
    <LM>w#w-d1t670-3</LM>
   </w.rf>
   <form>zapomněla</form>
   <lemma>zapomenout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m111-79-80">
   <w.rf>
    <LM>w#w-79-80</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-84">
  <m id="m111-d1t672-1">
   <w.rf>
    <LM>w#w-d1t672-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m111-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t672-2">
   <w.rf>
    <LM>w#w-d1t672-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-84-86">
   <w.rf>
    <LM>w#w-84-86</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t672-4">
   <w.rf>
    <LM>w#w-d1t672-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t672-5">
   <w.rf>
    <LM>w#w-d1t672-5</LM>
   </w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PK--2----------</tag>
  </m>
  <m id="m111-d1t672-3">
   <w.rf>
    <LM>w#w-d1t672-3</LM>
   </w.rf>
   <form>půjčený</form>
   <lemma>půjčený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m111-d-m-d1e663-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e663-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e673-x2">
  <m id="m111-d1t680-1">
   <w.rf>
    <LM>w#w-d1t680-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t680-2">
   <w.rf>
    <LM>w#w-d1t680-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d1t680-3">
   <w.rf>
    <LM>w#w-d1t680-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t680-4">
   <w.rf>
    <LM>w#w-d1t680-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m111-d1t680-5">
   <w.rf>
    <LM>w#w-d1t680-5</LM>
   </w.rf>
   <form>vodáctví</form>
   <lemma>vodáctví</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m111-d1t680-6">
   <w.rf>
    <LM>w#w-d1t680-6</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m111-d-id97000-punct">
   <w.rf>
    <LM>w#w-d-id97000-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e681-x2">
  <m id="m111-d1t686-1">
   <w.rf>
    <LM>w#w-d1t686-1</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m111-d1t686-2">
   <w.rf>
    <LM>w#w-d1t686-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m111-d1t686-3">
   <w.rf>
    <LM>w#w-d1t686-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t686-4">
   <w.rf>
    <LM>w#w-d1t686-4</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m111-d1t686-5">
   <w.rf>
    <LM>w#w-d1t686-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t686-6">
   <w.rf>
    <LM>w#w-d1t686-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t686-7">
   <w.rf>
    <LM>w#w-d1t686-7</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m111-d1e681-x2-99">
   <w.rf>
    <LM>w#w-d1e681-x2-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-100">
  <m id="m111-d1t686-9">
   <w.rf>
    <LM>w#w-d1t686-9</LM>
   </w.rf>
   <form>Dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t686-10">
   <w.rf>
    <LM>w#w-d1t686-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m111-d1t686-11">
   <w.rf>
    <LM>w#w-d1t686-11</LM>
   </w.rf>
   <form>kamarády</form>
   <lemma>kamarád</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m111-d1t686-13">
   <w.rf>
    <LM>w#w-d1t686-13</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m111-d1t686-14">
   <w.rf>
    <LM>w#w-d1t686-14</LM>
   </w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m111-100-112">
   <w.rf>
    <LM>w#w-100-112</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-113">
  <m id="m111-d1t686-17">
   <w.rf>
    <LM>w#w-d1t686-17</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t686-18">
   <w.rf>
    <LM>w#w-d1t686-18</LM>
   </w.rf>
   <form>skaut</form>
   <lemma>skaut</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m111-d-id97336-punct">
   <w.rf>
    <LM>w#w-d-id97336-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-113-124">
   <w.rf>
    <LM>w#w-113-124</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t688-1">
   <w.rf>
    <LM>w#w-d1t688-1</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t688-2">
   <w.rf>
    <LM>w#w-d1t688-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m111-d1t688-3">
   <w.rf>
    <LM>w#w-d1t688-3</LM>
   </w.rf>
   <form>nenaskautoval</form>
   <lemma>naskautovat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m111-d-id97422-punct">
   <w.rf>
    <LM>w#w-d-id97422-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t688-5">
   <w.rf>
    <LM>w#w-d1t688-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t688-6">
   <w.rf>
    <LM>w#w-d1t688-6</LM>
   </w.rf>
   <form>komunisté</form>
   <lemma>komunista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m111-d1t688-7">
   <w.rf>
    <LM>w#w-d1t688-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m111-d1t688-9">
   <w.rf>
    <LM>w#w-d1t688-9</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t688-8">
   <w.rf>
    <LM>w#w-d1t688-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t688-10">
   <w.rf>
    <LM>w#w-d1t688-10</LM>
   </w.rf>
   <form>zatrhli</form>
   <lemma>zatrhnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m111-113-125">
   <w.rf>
    <LM>w#w-113-125</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-127">
  <m id="m111-d1t690-6">
   <w.rf>
    <LM>w#w-d1t690-6</LM>
   </w.rf>
   <form>Inklinoval</form>
   <lemma>inklinovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m111-d1t690-8">
   <w.rf>
    <LM>w#w-d1t690-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m111-d1t690-10">
   <w.rf>
    <LM>w#w-d1t690-10</LM>
   </w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m111-127-145">
   <w.rf>
    <LM>w#w-127-145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-146">
  <m id="m111-d1t690-17">
   <w.rf>
    <LM>w#w-d1t690-17</LM>
   </w.rf>
   <form>Koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m111-d1t690-15">
   <w.rf>
    <LM>w#w-d1t690-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t690-16">
   <w.rf>
    <LM>w#w-d1t690-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m111-d1t690-14">
   <w.rf>
    <LM>w#w-d1t690-14</LM>
   </w.rf>
   <form>keňu</form>
   <lemma>keňa_^(loďka)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-146-154">
   <w.rf>
    <LM>w#w-146-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-156">
  <m id="m111-d1t690-20">
   <w.rf>
    <LM>w#w-d1t690-20</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t690-19">
   <w.rf>
    <LM>w#w-d1t690-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t690-21">
   <w.rf>
    <LM>w#w-d1t690-21</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t690-22">
   <w.rf>
    <LM>w#w-d1t690-22</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m111-d1t690-23">
   <w.rf>
    <LM>w#w-d1t690-23</LM>
   </w.rf>
   <form>žebrovka</form>
   <lemma>žebrovka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m111-d-id97883-punct">
   <w.rf>
    <LM>w#w-d-id97883-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t690-25">
   <w.rf>
    <LM>w#w-d1t690-25</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m111-d1t690-26">
   <w.rf>
    <LM>w#w-d1t690-26</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t690-27">
   <w.rf>
    <LM>w#w-d1t690-27</LM>
   </w.rf>
   <form>dřevěná</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m111-156-157">
   <w.rf>
    <LM>w#w-156-157</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-159">
  <m id="m111-d1t690-31">
   <w.rf>
    <LM>w#w-d1t690-31</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t690-32">
   <w.rf>
    <LM>w#w-d1t690-32</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t690-33">
   <w.rf>
    <LM>w#w-d1t690-33</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m111-d1t690-34">
   <w.rf>
    <LM>w#w-d1t690-34</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m111-d1t690-43">
   <w.rf>
    <LM>w#w-d1t690-43</LM>
   </w.rf>
   <form>umělé</form>
   <lemma>umělý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m111-159-227">
   <w.rf>
    <LM>w#w-159-227</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t690-36">
   <w.rf>
    <LM>w#w-d1t690-36</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t690-37">
   <w.rf>
    <LM>w#w-d1t690-37</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t690-38">
   <w.rf>
    <LM>w#w-d1t690-38</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t690-39">
   <w.rf>
    <LM>w#w-d1t690-39</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m111-159-747">
   <w.rf>
    <LM>w#w-159-747</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e681-x3">
  <m id="m111-d1t692-2">
   <w.rf>
    <LM>w#w-d1t692-2</LM>
   </w.rf>
   <form>Tahleta</form>
   <lemma>tenhleten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m111-d1t692-3">
   <w.rf>
    <LM>w#w-d1t692-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t692-4">
   <w.rf>
    <LM>w#w-d1t692-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t692-5">
   <w.rf>
    <LM>w#w-d1t692-5</LM>
   </w.rf>
   <form>potopitelná</form>
   <lemma>potopitelný_^(*4)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m111-d-id98252-punct">
   <w.rf>
    <LM>w#w-d-id98252-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t692-7">
   <w.rf>
    <LM>w#w-d1t692-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t692-8">
   <w.rf>
    <LM>w#w-d1t692-8</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m111-d1t695-1">
   <w.rf>
    <LM>w#w-d1t695-1</LM>
   </w.rf>
   <form>komory</form>
   <lemma>komora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m111-d1e681-x3-173">
   <w.rf>
    <LM>w#w-d1e681-x3-173</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t695-2">
   <w.rf>
    <LM>w#w-d1t695-2</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t695-3">
   <w.rf>
    <LM>w#w-d1t695-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m111-d1t695-4">
   <w.rf>
    <LM>w#w-d1t695-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m111-d1t697-1">
   <w.rf>
    <LM>w#w-d1t697-1</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m111-d1e681-x3-171">
   <w.rf>
    <LM>w#w-d1e681-x3-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-172">
  <m id="m111-d1t697-4">
   <w.rf>
    <LM>w#w-d1t697-4</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t697-5">
   <w.rf>
    <LM>w#w-d1t697-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t697-6">
   <w.rf>
    <LM>w#w-d1t697-6</LM>
   </w.rf>
   <form>těžká</form>
   <lemma>těžký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m111-d-m-d1e681-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e681-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e699-x2">
  <m id="m111-d1t706-1">
   <w.rf>
    <LM>w#w-d1t706-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d1t706-2">
   <w.rf>
    <LM>w#w-d1t706-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m111-d-id98604-punct">
   <w.rf>
    <LM>w#w-d-id98604-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t706-4">
   <w.rf>
    <LM>w#w-d1t706-4</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t706-5">
   <w.rf>
    <LM>w#w-d1t706-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m111-d1t706-6">
   <w.rf>
    <LM>w#w-d1t706-6</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t706-7">
   <w.rf>
    <LM>w#w-d1t706-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t706-8">
   <w.rf>
    <LM>w#w-d1t706-8</LM>
   </w.rf>
   <form>lodi</form>
   <lemma>loď</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t706-9">
   <w.rf>
    <LM>w#w-d1t706-9</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d-id98705-punct">
   <w.rf>
    <LM>w#w-d-id98705-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e707-x2">
  <m id="m111-d1t710-5">
   <w.rf>
    <LM>w#w-d1t710-5</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m111-d1t710-6">
   <w.rf>
    <LM>w#w-d1t710-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m111-d1t710-1">
   <w.rf>
    <LM>w#w-d1t710-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>lodi</form>
   <lemma>loď</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t710-7">
   <w.rf>
    <LM>w#w-d1t710-7</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m111-d1t710-8">
   <w.rf>
    <LM>w#w-d1t710-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t710-9">
   <w.rf>
    <LM>w#w-d1t710-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m111-d1t710-10">
   <w.rf>
    <LM>w#w-d1t710-10</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m111-d1e707-x2-190">
   <w.rf>
    <LM>w#w-d1e707-x2-190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-191">
  <m id="m111-d1t710-14">
   <w.rf>
    <LM>w#w-d1t710-14</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t710-13">
   <w.rf>
    <LM>w#w-d1t710-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t710-15">
   <w.rf>
    <LM>w#w-d1t710-15</LM>
   </w.rf>
   <form>trávili</form>
   <lemma>trávit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t712-1">
   <w.rf>
    <LM>w#w-d1t712-1</LM>
   </w.rf>
   <form>letní</form>
   <lemma>letní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m111-d1t712-2">
   <w.rf>
    <LM>w#w-d1t712-2</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m111-d1t712-3">
   <w.rf>
    <LM>w#w-d1t712-3</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t712-4">
   <w.rf>
    <LM>w#w-d1t712-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t712-5">
   <w.rf>
    <LM>w#w-d1t712-5</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-d1t712-8">
   <w.rf>
    <LM>w#w-d1t712-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t712-9">
   <w.rf>
    <LM>w#w-d1t712-9</LM>
   </w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m111-d1t712-10">
   <w.rf>
    <LM>w#w-d1t712-10</LM>
   </w.rf>
   <form>táboře</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m111-191-205">
   <w.rf>
    <LM>w#w-191-205</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-206">
  <m id="m111-d1t712-13">
   <w.rf>
    <LM>w#w-d1t712-13</LM>
   </w.rf>
   <form>Naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m111-d1t712-14">
   <w.rf>
    <LM>w#w-d1t712-14</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t712-15">
   <w.rf>
    <LM>w#w-d1t712-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t712-16">
   <w.rf>
    <LM>w#w-d1t712-16</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m111-d1t712-17">
   <w.rf>
    <LM>w#w-d1t712-17</LM>
   </w.rf>
   <form>rodinný</form>
   <lemma>rodinný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m111-d1t712-18">
   <w.rf>
    <LM>w#w-d1t712-18</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m111-d-id99262-punct">
   <w.rf>
    <LM>w#w-d-id99262-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m111-d1t712-20">
   <w.rf>
    <LM>w#w-d1t712-20</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t712-21">
   <w.rf>
    <LM>w#w-d1t712-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m111-d1t712-22">
   <w.rf>
    <LM>w#w-d1t712-22</LM>
   </w.rf>
   <form>spalo</form>
   <lemma>spát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m111-d1t712-23">
   <w.rf>
    <LM>w#w-d1t712-23</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t712-25">
   <w.rf>
    <LM>w#w-d1t712-25</LM>
   </w.rf>
   <form>chatkách</form>
   <lemma>chatka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m111-206-218">
   <w.rf>
    <LM>w#w-206-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-219">
  <m id="m111-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t716-3">
   <w.rf>
    <LM>w#w-d1t716-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t716-4">
   <w.rf>
    <LM>w#w-d1t716-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m111-d1t716-5">
   <w.rf>
    <LM>w#w-d1t716-5</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m111-d1t716-23">
   <w.rf>
    <LM>w#w-d1t716-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m111-d1t716-25">
   <w.rf>
    <LM>w#w-d1t716-25</LM>
   </w.rf>
   <form>Sázavě</form>
   <lemma>Sázava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m111-d1t716-6">
   <w.rf>
    <LM>w#w-d1t716-6</LM>
   </w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d1t716-20">
   <w.rf>
    <LM>w#w-d1t716-20</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t716-21">
   <w.rf>
    <LM>w#w-d1t716-21</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-219-229">
   <w.rf>
    <LM>w#w-219-229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-230">
  <m id="m111-d1t716-33">
   <w.rf>
    <LM>w#w-d1t716-33</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m111-d1t716-31">
   <w.rf>
    <LM>w#w-d1t716-31</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t716-34">
   <w.rf>
    <LM>w#w-d1t716-34</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m111-d1t716-35">
   <w.rf>
    <LM>w#w-d1t716-35</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m111-d1t716-36">
   <w.rf>
    <LM>w#w-d1t716-36</LM>
   </w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m111-d1t716-37">
   <w.rf>
    <LM>w#w-d1t716-37</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m111-230-240">
   <w.rf>
    <LM>w#w-230-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e717-x2">
  <m id="m111-d1t720-1">
   <w.rf>
    <LM>w#w-d1t720-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m111-d1e717-x2-241">
   <w.rf>
    <LM>w#w-d1e717-x2-241</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
