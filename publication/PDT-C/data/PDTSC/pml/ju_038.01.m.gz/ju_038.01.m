<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_038.01.w.gz" />
  </references>
 </head>
 <s id="m038-d1e299-x3">
  <m id="m038-d1t308-1">
   <w.rf>
    <LM>w#w-d1t308-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t308-2">
   <w.rf>
    <LM>w#w-d1t308-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t308-3">
   <w.rf>
    <LM>w#w-d1t308-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t308-4">
   <w.rf>
    <LM>w#w-d1t308-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t308-5">
   <w.rf>
    <LM>w#w-d1t308-5</LM>
   </w.rf>
   <form>naposledy</form>
   <lemma>naposledy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t308-6">
   <w.rf>
    <LM>w#w-d1t308-6</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m038-d-id64883-punct">
   <w.rf>
    <LM>w#w-d-id64883-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e309-x2">
  <m id="m038-d1t314-4">
   <w.rf>
    <LM>w#w-d1t314-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t314-2">
   <w.rf>
    <LM>w#w-d1t314-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t314-3">
   <w.rf>
    <LM>w#w-d1t314-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t314-5">
   <w.rf>
    <LM>w#w-d1t314-5</LM>
   </w.rf>
   <form>vloni</form>
   <lemma>vloni_,s_^(^DD**loni)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t314-6">
   <w.rf>
    <LM>w#w-d1t314-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t314-7">
   <w.rf>
    <LM>w#w-d1t314-7</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1e309-x2-289">
   <w.rf>
    <LM>w#w-d1e309-x2-289</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-290">
  <m id="m038-d1t314-9">
   <w.rf>
    <LM>w#w-d1t314-9</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t314-10">
   <w.rf>
    <LM>w#w-d1t314-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t314-11">
   <w.rf>
    <LM>w#w-d1t314-11</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m038-d1t320-1">
   <w.rf>
    <LM>w#w-d1t320-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t320-2">
   <w.rf>
    <LM>w#w-d1t320-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t320-3">
   <w.rf>
    <LM>w#w-d1t320-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t320-4">
   <w.rf>
    <LM>w#w-d1t320-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t320-5">
   <w.rf>
    <LM>w#w-d1t320-5</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m038-d-m-d1e315-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e315-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e327-x2">
  <m id="m038-d1t330-1">
   <w.rf>
    <LM>w#w-d1t330-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m038-d1t330-2">
   <w.rf>
    <LM>w#w-d1t330-2</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t330-5">
   <w.rf>
    <LM>w#w-d1t330-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t330-6">
   <w.rf>
    <LM>w#w-d1t330-6</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m038-d1t330-3">
   <w.rf>
    <LM>w#w-d1t330-3</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m038-d1t330-4">
   <w.rf>
    <LM>w#w-d1t330-4</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m038-d-id65411-punct">
   <w.rf>
    <LM>w#w-d-id65411-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t332-1">
   <w.rf>
    <LM>w#w-d1t332-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t332-2">
   <w.rf>
    <LM>w#w-d1t332-2</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t332-3">
   <w.rf>
    <LM>w#w-d1t332-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t332-4">
   <w.rf>
    <LM>w#w-d1t332-4</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m038-d1e327-x2-313">
   <w.rf>
    <LM>w#w-d1e327-x2-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-314">
  <m id="m038-d1t334-8">
   <w.rf>
    <LM>w#w-d1t334-8</LM>
   </w.rf>
   <form>Švagr</form>
   <lemma>švagr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t334-6">
   <w.rf>
    <LM>w#w-d1t334-6</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t336-6">
   <w.rf>
    <LM>w#w-d1t336-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t336-7">
   <w.rf>
    <LM>w#w-d1t336-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m038-d1t336-8">
   <w.rf>
    <LM>w#w-d1t336-8</LM>
   </w.rf>
   <form>dojede</form>
   <lemma>dojet</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m038-d1t336-9">
   <w.rf>
    <LM>w#w-d1t336-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t336-11">
   <w.rf>
    <LM>w#w-d1t336-11</LM>
   </w.rf>
   <form>Sušice</form>
   <lemma>Sušice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1t338-1">
   <w.rf>
    <LM>w#w-d1t338-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t338-2">
   <w.rf>
    <LM>w#w-d1t338-2</LM>
   </w.rf>
   <form>odveze</form>
   <lemma>odvézt</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m038-d1t338-3">
   <w.rf>
    <LM>w#w-d1t338-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m038-d1t338-4">
   <w.rf>
    <LM>w#w-d1t338-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t338-7">
   <w.rf>
    <LM>w#w-d1t338-7</LM>
   </w.rf>
   <form>Vlastějova</form>
   <lemma>Vlastějov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m038-d-m-d1e327-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e327-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e340-x2">
  <m id="m038-d1t343-1">
   <w.rf>
    <LM>w#w-d1t343-1</LM>
   </w.rf>
   <form>Změnilo</form>
   <lemma>změnit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-d1t343-2">
   <w.rf>
    <LM>w#w-d1t343-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t343-3">
   <w.rf>
    <LM>w#w-d1t343-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t343-4">
   <w.rf>
    <LM>w#w-d1t343-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t343-5">
   <w.rf>
    <LM>w#w-d1t343-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t343-6">
   <w.rf>
    <LM>w#w-d1t343-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t343-7">
   <w.rf>
    <LM>w#w-d1t343-7</LM>
   </w.rf>
   <form>vašeho</form>
   <lemma>váš</lemma>
   <tag>PSZS2-P2-------</tag>
  </m>
  <m id="m038-d1t343-8">
   <w.rf>
    <LM>w#w-d1t343-8</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m038-d-id66067-punct">
   <w.rf>
    <LM>w#w-d-id66067-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e344-x2">
  <m id="m038-d1t353-1">
   <w.rf>
    <LM>w#w-d1t353-1</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t353-2">
   <w.rf>
    <LM>w#w-d1t353-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m038-d-id66201-punct">
   <w.rf>
    <LM>w#w-d-id66201-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t353-4">
   <w.rf>
    <LM>w#w-d1t353-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t353-5">
   <w.rf>
    <LM>w#w-d1t353-5</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t353-6">
   <w.rf>
    <LM>w#w-d1t353-6</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1e344-x2-327">
   <w.rf>
    <LM>w#w-d1e344-x2-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-328">
  <m id="m038-d1t353-11">
   <w.rf>
    <LM>w#w-d1t353-11</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t353-14">
   <w.rf>
    <LM>w#w-d1t353-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t353-10">
   <w.rf>
    <LM>w#w-d1t353-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t353-9">
   <w.rf>
    <LM>w#w-d1t353-9</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d1t353-15">
   <w.rf>
    <LM>w#w-d1t353-15</LM>
   </w.rf>
   <form>sousedi</form>
   <lemma>soused</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m038-d-id66383-punct">
   <w.rf>
    <LM>w#w-d-id66383-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t355-1">
   <w.rf>
    <LM>w#w-d1t355-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t355-2">
   <w.rf>
    <LM>w#w-d1t355-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t355-4">
   <w.rf>
    <LM>w#w-d1t355-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t355-7">
   <w.rf>
    <LM>w#w-d1t355-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m038-d1t355-6">
   <w.rf>
    <LM>w#w-d1t355-6</LM>
   </w.rf>
   <form>opravené</form>
   <lemma>opravený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-328-15">
   <w.rf>
    <LM>w#w-328-15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-16">
  <m id="m038-d1t358-4">
   <w.rf>
    <LM>w#w-d1t358-4</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m038-d1t358-5">
   <w.rf>
    <LM>w#w-d1t358-5</LM>
   </w.rf>
   <form>staří</form>
   <lemma>starý-1_^(manžel)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m038-d1t358-8">
   <w.rf>
    <LM>w#w-d1t358-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t358-11">
   <w.rf>
    <LM>w#w-d1t358-11</LM>
   </w.rf>
   <form>odešli</form>
   <lemma>odejít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d-id66690-punct">
   <w.rf>
    <LM>w#w-d-id66690-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t358-16">
   <w.rf>
    <LM>w#w-d1t358-16</LM>
   </w.rf>
   <form>umřeli</form>
   <lemma>umřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-16-9">
   <w.rf>
    <LM>w#w-16-9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-10">
  <m id="m038-d1t360-2">
   <w.rf>
    <LM>w#w-d1t360-2</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t360-6">
   <w.rf>
    <LM>w#w-d1t360-6</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m038-d1t360-7">
   <w.rf>
    <LM>w#w-d1t360-7</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m038-d-id66887-punct">
   <w.rf>
    <LM>w#w-d-id66887-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t360-9">
   <w.rf>
    <LM>w#w-d1t360-9</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m038-d1t360-10">
   <w.rf>
    <LM>w#w-d1t360-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t360-11">
   <w.rf>
    <LM>w#w-d1t360-11</LM>
   </w.rf>
   <form>zůstali</form>
   <lemma>zůstat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d-id66942-punct">
   <w.rf>
    <LM>w#w-d-id66942-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t364-2">
   <w.rf>
    <LM>w#w-d1t364-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t364-4">
   <w.rf>
    <LM>w#w-d1t364-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d-id67045-punct">
   <w.rf>
    <LM>w#w-d-id67045-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t366-1">
   <w.rf>
    <LM>w#w-d1t366-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t366-2">
   <w.rf>
    <LM>w#w-d1t366-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t366-3">
   <w.rf>
    <LM>w#w-d1t366-3</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m038-d1t366-4">
   <w.rf>
    <LM>w#w-d1t366-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t366-5">
   <w.rf>
    <LM>w#w-d1t366-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t366-6">
   <w.rf>
    <LM>w#w-d1t366-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t366-7">
   <w.rf>
    <LM>w#w-d1t366-7</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t366-9">
   <w.rf>
    <LM>w#w-d1t366-9</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t366-8">
   <w.rf>
    <LM>w#w-d1t366-8</LM>
   </w.rf>
   <form>změnilo</form>
   <lemma>změnit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-10-19">
   <w.rf>
    <LM>w#w-10-19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t366-10">
   <w.rf>
    <LM>w#w-d1t366-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t366-11">
   <w.rf>
    <LM>w#w-d1t366-11</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-10-20">
   <w.rf>
    <LM>w#w-10-20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e344-x3">
  <m id="m038-d1t366-13">
   <w.rf>
    <LM>w#w-d1t366-13</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t366-14">
   <w.rf>
    <LM>w#w-d1t366-14</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m038-d1t366-15">
   <w.rf>
    <LM>w#w-d1t366-15</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m038-d-m-d1e344-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e344-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e369-x2">
  <m id="m038-d1t376-1">
   <w.rf>
    <LM>w#w-d1t376-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t376-2">
   <w.rf>
    <LM>w#w-d1t376-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t376-3">
   <w.rf>
    <LM>w#w-d1t376-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t376-4">
   <w.rf>
    <LM>w#w-d1t376-4</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t376-5">
   <w.rf>
    <LM>w#w-d1t376-5</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m038-d1t376-6">
   <w.rf>
    <LM>w#w-d1t376-6</LM>
   </w.rf>
   <form>rekreanti</form>
   <lemma>rekreant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m038-d-id67460-punct">
   <w.rf>
    <LM>w#w-d-id67460-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e379-x2">
  <m id="m038-d1t384-2">
   <w.rf>
    <LM>w#w-d1t384-2</LM>
   </w.rf>
   <form>Nějací</form>
   <lemma>nějaký</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m038-d1t384-5">
   <w.rf>
    <LM>w#w-d1t384-5</LM>
   </w.rf>
   <form>rekreanti</form>
   <lemma>rekreant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m038-d1t384-3">
   <w.rf>
    <LM>w#w-d1t384-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t384-4">
   <w.rf>
    <LM>w#w-d1t384-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t384-1">
   <w.rf>
    <LM>w#w-d1t384-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id67617-punct">
   <w.rf>
    <LM>w#w-d-id67617-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t384-7">
   <w.rf>
    <LM>w#w-d1t384-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t384-8">
   <w.rf>
    <LM>w#w-d1t384-8</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m038-d1t384-9">
   <w.rf>
    <LM>w#w-d1t384-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t384-10">
   <w.rf>
    <LM>w#w-d1t384-10</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m038-d1t384-11">
   <w.rf>
    <LM>w#w-d1t384-11</LM>
   </w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m038-d1t384-13">
   <w.rf>
    <LM>w#w-d1t384-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t384-14">
   <w.rf>
    <LM>w#w-d1t384-14</LM>
   </w.rf>
   <form>zůstal</form>
   <lemma>zůstat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t384-15">
   <w.rf>
    <LM>w#w-d1t384-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t384-16">
   <w.rf>
    <LM>w#w-d1t384-16</LM>
   </w.rf>
   <form>hospodaří</form>
   <lemma>hospodařit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1e379-x2-26">
   <w.rf>
    <LM>w#w-d1e379-x2-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-27">
  <m id="m038-d1t386-3">
   <w.rf>
    <LM>w#w-d1t386-3</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t386-4">
   <w.rf>
    <LM>w#w-d1t386-4</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t386-5">
   <w.rf>
    <LM>w#w-d1t386-5</LM>
   </w.rf>
   <form>dobytek</form>
   <lemma>dobytek-1_^(zvířata)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-27-28">
   <w.rf>
    <LM>w#w-27-28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t386-8">
   <w.rf>
    <LM>w#w-d1t386-8</LM>
   </w.rf>
   <form>pozemky</form>
   <lemma>pozemek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d1t386-10">
   <w.rf>
    <LM>w#w-d1t386-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t386-12">
   <w.rf>
    <LM>w#w-d1t386-12</LM>
   </w.rf>
   <form>zkrátka</form>
   <lemma>zkrátka-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t386-13">
   <w.rf>
    <LM>w#w-d1t386-13</LM>
   </w.rf>
   <form>hospodaří</form>
   <lemma>hospodařit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e379-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e379-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e387-x2">
  <m id="m038-d1t392-1">
   <w.rf>
    <LM>w#w-d1t392-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1e387-x2-34">
   <w.rf>
    <LM>w#w-d1e387-x2-34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-35">
  <m id="m038-d1t394-1">
   <w.rf>
    <LM>w#w-d1t394-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t394-3">
   <w.rf>
    <LM>w#w-d1t394-3</LM>
   </w.rf>
   <form>tamodtud</form>
   <lemma>tamodtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t394-4">
   <w.rf>
    <LM>w#w-d1t394-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m038-d1t394-5">
   <w.rf>
    <LM>w#w-d1t394-5</LM>
   </w.rf>
   <form>vzpomínku</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d-id68121-punct">
   <w.rf>
    <LM>w#w-d-id68121-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e395-x2">
  <m id="m038-d1t398-2">
   <w.rf>
    <LM>w#w-d1t398-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t398-3">
   <w.rf>
    <LM>w#w-d1t398-3</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m038-d-id68229-punct">
   <w.rf>
    <LM>w#w-d-id68229-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e405-x2">
  <m id="m038-d1t410-2">
   <w.rf>
    <LM>w#w-d1t410-2</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t410-3">
   <w.rf>
    <LM>w#w-d1t410-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t410-4">
   <w.rf>
    <LM>w#w-d1t410-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t410-5">
   <w.rf>
    <LM>w#w-d1t410-5</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1t410-6">
   <w.rf>
    <LM>w#w-d1t410-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t410-8">
   <w.rf>
    <LM>w#w-d1t410-8</LM>
   </w.rf>
   <form>Těšova</form>
   <lemma>Těšov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m038-d1e405-x2-68">
   <w.rf>
    <LM>w#w-d1e405-x2-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-69">
  <m id="m038-d1t412-1">
   <w.rf>
    <LM>w#w-d1t412-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t412-2">
   <w.rf>
    <LM>w#w-d1t412-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t412-3">
   <w.rf>
    <LM>w#w-d1t412-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t412-7">
   <w.rf>
    <LM>w#w-d1t412-7</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m038-d1t412-8">
   <w.rf>
    <LM>w#w-d1t412-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m038-d1t412-4">
   <w.rf>
    <LM>w#w-d1t412-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t412-5">
   <w.rf>
    <LM>w#w-d1t412-5</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m038-69-70">
   <w.rf>
    <LM>w#w-69-70</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-id68642-punct">
   <w.rf>
    <LM>w#w-d-id68642-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t414-1">
   <w.rf>
    <LM>w#w-d1t414-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t414-2">
   <w.rf>
    <LM>w#w-d1t414-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t414-3">
   <w.rf>
    <LM>w#w-d1t414-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t416-2">
   <w.rf>
    <LM>w#w-d1t416-2</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m038-d1t419-1">
   <w.rf>
    <LM>w#w-d1t419-1</LM>
   </w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m038-69-71">
   <w.rf>
    <LM>w#w-69-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-72">
  <m id="m038-d1t421-3">
   <w.rf>
    <LM>w#w-d1t421-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t421-4">
   <w.rf>
    <LM>w#w-d1t421-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t421-5">
   <w.rf>
    <LM>w#w-d1t421-5</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t421-6">
   <w.rf>
    <LM>w#w-d1t421-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t421-7">
   <w.rf>
    <LM>w#w-d1t421-7</LM>
   </w.rf>
   <form>měšťanky</form>
   <lemma>měšťanka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-72-73">
   <w.rf>
    <LM>w#w-72-73</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-74">
  <m id="m038-d1t421-9">
   <w.rf>
    <LM>w#w-d1t421-9</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m038-d1t421-15">
   <w.rf>
    <LM>w#w-d1t421-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t421-10">
   <w.rf>
    <LM>w#w-d1t421-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t421-11">
   <w.rf>
    <LM>w#w-d1t421-11</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t421-16">
   <w.rf>
    <LM>w#w-d1t421-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t421-17">
   <w.rf>
    <LM>w#w-d1t421-17</LM>
   </w.rf>
   <form>měšťanky</form>
   <lemma>měšťanka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1t421-12">
   <w.rf>
    <LM>w#w-d1t421-12</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t421-13">
   <w.rf>
    <LM>w#w-d1t421-13</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m038-d1t421-14">
   <w.rf>
    <LM>w#w-d1t421-14</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d-id69038-punct">
   <w.rf>
    <LM>w#w-d-id69038-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t423-1">
   <w.rf>
    <LM>w#w-d1t423-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t423-2">
   <w.rf>
    <LM>w#w-d1t423-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t423-4">
   <w.rf>
    <LM>w#w-d1t423-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t423-3">
   <w.rf>
    <LM>w#w-d1t423-3</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-74-75">
   <w.rf>
    <LM>w#w-74-75</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-76">
  <m id="m038-d1t425-5">
   <w.rf>
    <LM>w#w-d1t425-5</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t425-4">
   <w.rf>
    <LM>w#w-d1t425-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t425-6">
   <w.rf>
    <LM>w#w-d1t425-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m038-d1t425-7">
   <w.rf>
    <LM>w#w-d1t425-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d1t425-8">
   <w.rf>
    <LM>w#w-d1t425-8</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-id69268-punct">
   <w.rf>
    <LM>w#w-d-id69268-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t425-10">
   <w.rf>
    <LM>w#w-d1t425-10</LM>
   </w.rf>
   <form>pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t425-11">
   <w.rf>
    <LM>w#w-d1t425-11</LM>
   </w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m038-76-96">
   <w.rf>
    <LM>w#w-76-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-97">
  <m id="m038-d1t425-13">
   <w.rf>
    <LM>w#w-d1t425-13</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m038-d1t425-14">
   <w.rf>
    <LM>w#w-d1t425-14</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t425-15">
   <w.rf>
    <LM>w#w-d1t425-15</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t425-17">
   <w.rf>
    <LM>w#w-d1t425-17</LM>
   </w.rf>
   <form>zemědělství</form>
   <lemma>zemědělství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m038-d-id69394-punct">
   <w.rf>
    <LM>w#w-d-id69394-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t427-1">
   <w.rf>
    <LM>w#w-d1t427-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t427-2">
   <w.rf>
    <LM>w#w-d1t427-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t427-3">
   <w.rf>
    <LM>w#w-d1t427-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m038-d1t427-4">
   <w.rf>
    <LM>w#w-d1t427-4</LM>
   </w.rf>
   <form>pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d-id69474-punct">
   <w.rf>
    <LM>w#w-d-id69474-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t427-6">
   <w.rf>
    <LM>w#w-d1t427-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t427-8">
   <w.rf>
    <LM>w#w-d1t427-8</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t427-9">
   <w.rf>
    <LM>w#w-d1t427-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m038-d1t427-10">
   <w.rf>
    <LM>w#w-d1t427-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t427-11">
   <w.rf>
    <LM>w#w-d1t427-11</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t429-1">
   <w.rf>
    <LM>w#w-d1t429-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t429-2">
   <w.rf>
    <LM>w#w-d1t429-2</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m038-d1t429-4">
   <w.rf>
    <LM>w#w-d1t429-4</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t429-6">
   <w.rf>
    <LM>w#w-d1t429-6</LM>
   </w.rf>
   <form>Mařenka</form>
   <lemma>Mařenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t429-11">
   <w.rf>
    <LM>w#w-d1t429-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t429-12">
   <w.rf>
    <LM>w#w-d1t429-12</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t429-13">
   <w.rf>
    <LM>w#w-d1t429-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t429-15">
   <w.rf>
    <LM>w#w-d1t429-15</LM>
   </w.rf>
   <form>Sušice</form>
   <lemma>Sušice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1t429-17">
   <w.rf>
    <LM>w#w-d1t429-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t429-18">
   <w.rf>
    <LM>w#w-d1t429-18</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-m-d1e405-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e405-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e433-x2">
  <m id="m038-d1t438-2">
   <w.rf>
    <LM>w#w-d1t438-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t438-1">
   <w.rf>
    <LM>w#w-d1t438-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t438-3">
   <w.rf>
    <LM>w#w-d1t438-3</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m038-d1t438-4">
   <w.rf>
    <LM>w#w-d1t438-4</LM>
   </w.rf>
   <form>účetnická</form>
   <lemma>účetnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1t438-5">
   <w.rf>
    <LM>w#w-d1t438-5</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e433-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e433-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e445-x2">
  <m id="m038-d1t448-2">
   <w.rf>
    <LM>w#w-d1t448-2</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t448-4">
   <w.rf>
    <LM>w#w-d1t448-4</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m038-d1t448-5">
   <w.rf>
    <LM>w#w-d1t448-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t448-6">
   <w.rf>
    <LM>w#w-d1t448-6</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t448-10">
   <w.rf>
    <LM>w#w-d1t448-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t448-11">
   <w.rf>
    <LM>w#w-d1t448-11</LM>
   </w.rf>
   <form>měšťanky</form>
   <lemma>měšťanka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1e445-x2-158">
   <w.rf>
    <LM>w#w-d1e445-x2-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-159">
  <m id="m038-d1t450-6">
   <w.rf>
    <LM>w#w-d1t450-6</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m038-d1t450-7">
   <w.rf>
    <LM>w#w-d1t450-7</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m038-d1t450-9">
   <w.rf>
    <LM>w#w-d1t450-9</LM>
   </w.rf>
   <form>pomahat</form>
   <lemma>pomahat_,h_^(^GC**pomáhat)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m038-d-id70353-punct">
   <w.rf>
    <LM>w#w-d-id70353-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t450-11">
   <w.rf>
    <LM>w#w-d1t450-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t450-12">
   <w.rf>
    <LM>w#w-d1t450-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t450-13">
   <w.rf>
    <LM>w#w-d1t450-13</LM>
   </w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t450-14">
   <w.rf>
    <LM>w#w-d1t450-14</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-159-175">
   <w.rf>
    <LM>w#w-159-175</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-177">
  <m id="m038-d1t452-3">
   <w.rf>
    <LM>w#w-d1t452-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-177-178">
   <w.rf>
    <LM>w#w-177-178</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t452-4">
   <w.rf>
    <LM>w#w-d1t452-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t452-5">
   <w.rf>
    <LM>w#w-d1t452-5</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t452-6">
   <w.rf>
    <LM>w#w-d1t452-6</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t452-7">
   <w.rf>
    <LM>w#w-d1t452-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t452-8">
   <w.rf>
    <LM>w#w-d1t452-8</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-id70558-punct">
   <w.rf>
    <LM>w#w-d-id70558-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t454-2">
   <w.rf>
    <LM>w#w-d1t454-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t454-4">
   <w.rf>
    <LM>w#w-d1t454-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t454-6">
   <w.rf>
    <LM>w#w-d1t454-6</LM>
   </w.rf>
   <form>učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m038-d1t454-7">
   <w.rf>
    <LM>w#w-d1t454-7</LM>
   </w.rf>
   <form>prodavačkou</form>
   <lemma>prodavačka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d-m-d1e445-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e445-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e468-x2">
  <m id="m038-d1t471-4">
   <w.rf>
    <LM>w#w-d1t471-4</LM>
   </w.rf>
   <form>Učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t471-2">
   <w.rf>
    <LM>w#w-d1t471-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t471-3">
   <w.rf>
    <LM>w#w-d1t471-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t471-5">
   <w.rf>
    <LM>w#w-d1t471-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m038-d1t471-7">
   <w.rf>
    <LM>w#w-d1t471-7</LM>
   </w.rf>
   <form>Velharticích</form>
   <lemma>Velhartice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m038-d1t473-2">
   <w.rf>
    <LM>w#w-d1t473-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t473-3">
   <w.rf>
    <LM>w#w-d1t473-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t473-4">
   <w.rf>
    <LM>w#w-d1t473-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t473-5">
   <w.rf>
    <LM>w#w-d1t473-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1e468-x2-199">
   <w.rf>
    <LM>w#w-d1e468-x2-199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t473-11">
   <w.rf>
    <LM>w#w-d1t473-11</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t473-12">
   <w.rf>
    <LM>w#w-d1t473-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t473-13">
   <w.rf>
    <LM>w#w-d1t473-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t473-14">
   <w.rf>
    <LM>w#w-d1t473-14</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1e468-x2-200">
   <w.rf>
    <LM>w#w-d1e468-x2-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-201">
  <m id="m038-d1t475-3">
   <w.rf>
    <LM>w#w-d1t475-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t475-2">
   <w.rf>
    <LM>w#w-d1t475-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t475-1">
   <w.rf>
    <LM>w#w-d1t475-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t479-2">
   <w.rf>
    <LM>w#w-d1t479-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t479-3">
   <w.rf>
    <LM>w#w-d1t479-3</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m038-d1t479-4">
   <w.rf>
    <LM>w#w-d1t479-4</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-201-58">
   <w.rf>
    <LM>w#w-201-58</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t479-6">
   <w.rf>
    <LM>w#w-d1t479-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m038-d1t479-7">
   <w.rf>
    <LM>w#w-d1t479-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m038-d1t479-8">
   <w.rf>
    <LM>w#w-d1t479-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t479-9">
   <w.rf>
    <LM>w#w-d1t479-9</LM>
   </w.rf>
   <form>sedmnáct</form>
   <lemma>sedmnáct`17</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-201-202">
   <w.rf>
    <LM>w#w-201-202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-203">
  <m id="m038-d1t482-1">
   <w.rf>
    <LM>w#w-d1t482-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t482-2">
   <w.rf>
    <LM>w#w-d1t482-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t482-3">
   <w.rf>
    <LM>w#w-d1t482-3</LM>
   </w.rf>
   <form>střídala</form>
   <lemma>střídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t482-5">
   <w.rf>
    <LM>w#w-d1t482-5</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m038-d1t486-1">
   <w.rf>
    <LM>w#w-d1t486-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t486-3">
   <w.rf>
    <LM>w#w-d1t486-3</LM>
   </w.rf>
   <form>prodejnách</form>
   <lemma>prodejna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m038-d-id71562-punct">
   <w.rf>
    <LM>w#w-d-id71562-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t486-5">
   <w.rf>
    <LM>w#w-d1t486-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t486-7">
   <w.rf>
    <LM>w#w-d1t486-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t486-8">
   <w.rf>
    <LM>w#w-d1t486-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t486-9">
   <w.rf>
    <LM>w#w-d1t486-9</LM>
   </w.rf>
   <form>vyučila</form>
   <lemma>vyučit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t486-10">
   <w.rf>
    <LM>w#w-d1t486-10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t490-1">
   <w.rf>
    <LM>w#w-d1t490-1</LM>
   </w.rf>
   <form>prodavačka</form>
   <lemma>prodavačka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t490-2">
   <w.rf>
    <LM>w#w-d1t490-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t490-3">
   <w.rf>
    <LM>w#w-d1t490-3</LM>
   </w.rf>
   <form>potravinách</form>
   <lemma>potravina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m038-d-id71728-punct">
   <w.rf>
    <LM>w#w-d-id71728-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t502-1">
   <w.rf>
    <LM>w#w-d1t502-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t502-2">
   <w.rf>
    <LM>w#w-d1t502-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t502-5">
   <w.rf>
    <LM>w#w-d1t502-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t502-4">
   <w.rf>
    <LM>w#w-d1t502-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t502-6">
   <w.rf>
    <LM>w#w-d1t502-6</LM>
   </w.rf>
   <form>střídala</form>
   <lemma>střídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e468-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e468-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e499-x2">
  <m id="m038-d1t502-10">
   <w.rf>
    <LM>w#w-d1t502-10</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t502-11">
   <w.rf>
    <LM>w#w-d1t502-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t502-12">
   <w.rf>
    <LM>w#w-d1t502-12</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t502-13">
   <w.rf>
    <LM>w#w-d1t502-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t502-15">
   <w.rf>
    <LM>w#w-d1t502-15</LM>
   </w.rf>
   <form>Těšovo</form>
   <lemma>Těšovo_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m038-d-id72105-punct">
   <w.rf>
    <LM>w#w-d-id72105-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t502-18">
   <w.rf>
    <LM>w#w-d1t502-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t502-19">
   <w.rf>
    <LM>w#w-d1t502-19</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t502-21">
   <w.rf>
    <LM>w#w-d1t502-21</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t502-22">
   <w.rf>
    <LM>w#w-d1t502-22</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m038-d1t502-20">
   <w.rf>
    <LM>w#w-d1t502-20</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t504-1">
   <w.rf>
    <LM>w#w-d1t504-1</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m038-d1t504-2">
   <w.rf>
    <LM>w#w-d1t504-2</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m038-d1t504-3">
   <w.rf>
    <LM>w#w-d1t504-3</LM>
   </w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m038-d-id72240-punct">
   <w.rf>
    <LM>w#w-d-id72240-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t506-2">
   <w.rf>
    <LM>w#w-d1t506-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t506-3">
   <w.rf>
    <LM>w#w-d1t506-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t506-4">
   <w.rf>
    <LM>w#w-d1t506-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t506-6">
   <w.rf>
    <LM>w#w-d1t506-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t506-5">
   <w.rf>
    <LM>w#w-d1t506-5</LM>
   </w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1e499-x2-223">
   <w.rf>
    <LM>w#w-d1e499-x2-223</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t506-7">
   <w.rf>
    <LM>w#w-d1t506-7</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t506-8">
   <w.rf>
    <LM>w#w-d1t506-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t506-9">
   <w.rf>
    <LM>w#w-d1t506-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t506-10">
   <w.rf>
    <LM>w#w-d1t506-10</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1e499-x2-224">
   <w.rf>
    <LM>w#w-d1e499-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-225">
  <m id="m038-d1t508-1">
   <w.rf>
    <LM>w#w-d1t508-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t508-2">
   <w.rf>
    <LM>w#w-d1t508-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t508-3">
   <w.rf>
    <LM>w#w-d1t508-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t508-5">
   <w.rf>
    <LM>w#w-d1t508-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t508-6">
   <w.rf>
    <LM>w#w-d1t508-6</LM>
   </w.rf>
   <form>prodejně</form>
   <lemma>prodejna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t508-4">
   <w.rf>
    <LM>w#w-d1t508-4</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m038-d1t510-2">
   <w.rf>
    <LM>w#w-d1t510-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t510-5">
   <w.rf>
    <LM>w#w-d1t510-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t510-4">
   <w.rf>
    <LM>w#w-d1t510-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t510-3">
   <w.rf>
    <LM>w#w-d1t510-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t510-6">
   <w.rf>
    <LM>w#w-d1t510-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t513-1">
   <w.rf>
    <LM>w#w-d1t513-1</LM>
   </w.rf>
   <form>necelých</form>
   <lemma>celý</lemma>
   <tag>AANP2----1N----</tag>
  </m>
  <m id="m038-d1t513-2">
   <w.rf>
    <LM>w#w-d1t513-2</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d1t513-3">
   <w.rf>
    <LM>w#w-d1t513-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m038-225-227">
   <w.rf>
    <LM>w#w-225-227</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-228">
  <m id="m038-d1t515-3">
   <w.rf>
    <LM>w#w-d1t515-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t515-4">
   <w.rf>
    <LM>w#w-d1t515-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t515-5">
   <w.rf>
    <LM>w#w-d1t515-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t515-6">
   <w.rf>
    <LM>w#w-d1t515-6</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-228-261">
   <w.rf>
    <LM>w#w-228-261</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t515-8">
   <w.rf>
    <LM>w#w-d1t515-8</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t515-9">
   <w.rf>
    <LM>w#w-d1t515-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t515-10">
   <w.rf>
    <LM>w#w-d1t515-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t515-13">
   <w.rf>
    <LM>w#w-d1t515-13</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1e526-x2-240">
   <w.rf>
    <LM>w#w-d1e526-x2-240</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t529-1">
   <w.rf>
    <LM>w#w-d1t529-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t529-2">
   <w.rf>
    <LM>w#w-d1t529-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t529-4">
   <w.rf>
    <LM>w#w-d1t529-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t529-5">
   <w.rf>
    <LM>w#w-d1t529-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-m-d1e516-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e516-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e532-x2">
  <m id="m038-d1t535-1">
   <w.rf>
    <LM>w#w-d1t535-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t535-2">
   <w.rf>
    <LM>w#w-d1t535-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t535-3">
   <w.rf>
    <LM>w#w-d1t535-3</LM>
   </w.rf>
   <form>jmenovali</form>
   <lemma>jmenovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m038-d1t535-4">
   <w.rf>
    <LM>w#w-d1t535-4</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m038-d1t535-5">
   <w.rf>
    <LM>w#w-d1t535-5</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m038-d-id73291-punct">
   <w.rf>
    <LM>w#w-d-id73291-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e538-x2">
  <m id="m038-d1t545-1">
   <w.rf>
    <LM>w#w-d1t545-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t545-2">
   <w.rf>
    <LM>w#w-d1t545-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t545-3">
   <w.rf>
    <LM>w#w-d1t545-3</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m038-d1t545-5">
   <w.rf>
    <LM>w#w-d1t545-5</LM>
   </w.rf>
   <form>Rozálie</form>
   <lemma>Rozálie_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t547-1">
   <w.rf>
    <LM>w#w-d1t547-1</LM>
   </w.rf>
   <form>Waltmannová</form>
   <lemma>Waltmannová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1e538-x2-279">
   <w.rf>
    <LM>w#w-d1e538-x2-279</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t547-3">
   <w.rf>
    <LM>w#w-d1t547-3</LM>
   </w.rf>
   <form>psalo</form>
   <lemma>psát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t547-4">
   <w.rf>
    <LM>w#w-d1t547-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t547-5">
   <w.rf>
    <LM>w#w-d1t547-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t547-6">
   <w.rf>
    <LM>w#w-d1t547-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>dvojité</form>
   <lemma>dvojitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d1t547-7">
   <w.rf>
    <LM>w#w-d1t547-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m038-d1t549-1">
   <w.rf>
    <LM>w#w-d1t549-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t549-2">
   <w.rf>
    <LM>w#w-d1t549-2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m038-d1t549-3">
   <w.rf>
    <LM>w#w-d1t549-3</LM>
   </w.rf>
   <form>n</form>
   <lemma>n-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m038-d-id73596-punct">
   <w.rf>
    <LM>w#w-d-id73596-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e538-x2-280">
   <w.rf>
    <LM>w#w-d1e538-x2-280</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t552-1">
   <w.rf>
    <LM>w#w-d1t552-1</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t552-3">
   <w.rf>
    <LM>w#w-d1t552-3</LM>
   </w.rf>
   <form>Bernard</form>
   <lemma>Bernard_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1e538-x2-281">
   <w.rf>
    <LM>w#w-d1e538-x2-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-282">
  <m id="m038-d1t552-7">
   <w.rf>
    <LM>w#w-d1t552-7</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t552-6">
   <w.rf>
    <LM>w#w-d1t552-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t552-8">
   <w.rf>
    <LM>w#w-d1t552-8</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDNP1----------</tag>
  </m>
  <m id="m038-d1t552-10">
   <w.rf>
    <LM>w#w-d1t552-10</LM>
   </w.rf>
   <form>dřívější</form>
   <lemma>dřívější</lemma>
   <tag>AANP1----2A----</tag>
  </m>
  <m id="m038-d1t552-9">
   <w.rf>
    <LM>w#w-d1t552-9</LM>
   </w.rf>
   <form>jména</form>
   <lemma>jméno</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m038-282-283">
   <w.rf>
    <LM>w#w-282-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-284">
  <m id="m038-d1t554-3">
   <w.rf>
    <LM>w#w-d1t554-3</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t554-5">
   <w.rf>
    <LM>w#w-d1t554-5</LM>
   </w.rf>
   <form>umřela</form>
   <lemma>umřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t554-6">
   <w.rf>
    <LM>w#w-d1t554-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t554-7">
   <w.rf>
    <LM>w#w-d1t554-7</LM>
   </w.rf>
   <form>81</form>
   <lemma>81</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-id73855-punct">
   <w.rf>
    <LM>w#w-d-id73855-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t554-10">
   <w.rf>
    <LM>w#w-d1t554-10</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t554-11">
   <w.rf>
    <LM>w#w-d1t554-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t554-13">
   <w.rf>
    <LM>w#w-d1t554-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t556-2">
   <w.rf>
    <LM>w#w-d1t556-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-284-289">
   <w.rf>
    <LM>w#w-284-289</LM>
   </w.rf>
   <form>nemohoucí</form>
   <lemma>nemohoucí</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d-id73990-punct">
   <w.rf>
    <LM>w#w-d-id73990-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t556-5">
   <w.rf>
    <LM>w#w-d1t556-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t556-6">
   <w.rf>
    <LM>w#w-d1t556-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t556-7">
   <w.rf>
    <LM>w#w-d1t556-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t556-9">
   <w.rf>
    <LM>w#w-d1t556-9</LM>
   </w.rf>
   <form>Mařenky</form>
   <lemma>Mařenka_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-284-290">
   <w.rf>
    <LM>w#w-284-290</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t556-12">
   <w.rf>
    <LM>w#w-d1t556-12</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m038-d1t556-13">
   <w.rf>
    <LM>w#w-d1t556-13</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-284-291">
   <w.rf>
    <LM>w#w-284-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-292">
  <m id="m038-d1t558-3">
   <w.rf>
    <LM>w#w-d1t558-3</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t558-5">
   <w.rf>
    <LM>w#w-d1t558-5</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t558-6">
   <w.rf>
    <LM>w#w-d1t558-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t558-7">
   <w.rf>
    <LM>w#w-d1t558-7</LM>
   </w.rf>
   <form>75</form>
   <lemma>75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-id74244-punct">
   <w.rf>
    <LM>w#w-d-id74244-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t558-9">
   <w.rf>
    <LM>w#w-d1t558-9</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m038-d1t558-11">
   <w.rf>
    <LM>w#w-d1t558-11</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t558-12">
   <w.rf>
    <LM>w#w-d1t558-12</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m038-d-m-d1e538-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e538-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e559-x2">
  <m id="m038-d1t562-1">
   <w.rf>
    <LM>w#w-d1t562-1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m038-d1t562-2">
   <w.rf>
    <LM>w#w-d1t562-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id74399-punct">
   <w.rf>
    <LM>w#w-d-id74399-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e563-x2">
  <m id="m038-d1t568-3">
   <w.rf>
    <LM>w#w-d1t568-3</LM>
   </w.rf>
   <form>Hospodařili</form>
   <lemma>hospodařit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t568-6">
   <w.rf>
    <LM>w#w-d1t568-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t568-7">
   <w.rf>
    <LM>w#w-d1t568-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m038-d1t568-8">
   <w.rf>
    <LM>w#w-d1t568-8</LM>
   </w.rf>
   <form>zemědělství</form>
   <lemma>zemědělství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m038-d1t570-1">
   <w.rf>
    <LM>w#w-d1t570-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t570-2">
   <w.rf>
    <LM>w#w-d1t570-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t570-3">
   <w.rf>
    <LM>w#w-d1t570-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t570-4">
   <w.rf>
    <LM>w#w-d1t570-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t570-5">
   <w.rf>
    <LM>w#w-d1t570-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t570-6">
   <w.rf>
    <LM>w#w-d1t570-6</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m038-d1t570-7">
   <w.rf>
    <LM>w#w-d1t570-7</LM>
   </w.rf>
   <form>hospůdku</form>
   <lemma>hospůdka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d-id74700-punct">
   <w.rf>
    <LM>w#w-d-id74700-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t572-1">
   <w.rf>
    <LM>w#w-d1t572-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t572-2">
   <w.rf>
    <LM>w#w-d1t572-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t572-3">
   <w.rf>
    <LM>w#w-d1t572-3</LM>
   </w.rf>
   <form>čepovali</form>
   <lemma>čepovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t572-4">
   <w.rf>
    <LM>w#w-d1t572-4</LM>
   </w.rf>
   <form>pivo</form>
   <lemma>pivo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m038-d-m-d1e563-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e563-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e588-x2">
  <m id="m038-d1t591-1">
   <w.rf>
    <LM>w#w-d1t591-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m038-d1t591-2">
   <w.rf>
    <LM>w#w-d1t591-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t591-3">
   <w.rf>
    <LM>w#w-d1t591-3</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-m-d1e588-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e588-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e593-x2">
  <m id="m038-d1t596-1">
   <w.rf>
    <LM>w#w-d1t596-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1e593-x2-301">
   <w.rf>
    <LM>w#w-d1e593-x2-301</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-302">
  <m id="m038-d1t598-1">
   <w.rf>
    <LM>w#w-d1t598-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t598-2">
   <w.rf>
    <LM>w#w-d1t598-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t598-3">
   <w.rf>
    <LM>w#w-d1t598-3</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m038-d1t598-4">
   <w.rf>
    <LM>w#w-d1t598-4</LM>
   </w.rf>
   <form>hospůdka</form>
   <lemma>hospůdka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-id75164-punct">
   <w.rf>
    <LM>w#w-d-id75164-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e599-x2">
  <m id="m038-d1t604-1">
   <w.rf>
    <LM>w#w-d1t604-1</LM>
   </w.rf>
   <form>Hospůdku</form>
   <lemma>hospůdka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t604-2">
   <w.rf>
    <LM>w#w-d1t604-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t604-3">
   <w.rf>
    <LM>w#w-d1t604-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t604-4">
   <w.rf>
    <LM>w#w-d1t604-4</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t604-5">
   <w.rf>
    <LM>w#w-d1t604-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m038-d1t604-8">
   <w.rf>
    <LM>w#w-d1t604-8</LM>
   </w.rf>
   <form>Vlastějově</form>
   <lemma>Vlastějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m038-d1e599-x2-319">
   <w.rf>
    <LM>w#w-d1e599-x2-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-320">
  <m id="m038-d1t606-1">
   <w.rf>
    <LM>w#w-d1t606-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t606-2">
   <w.rf>
    <LM>w#w-d1t606-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t606-3">
   <w.rf>
    <LM>w#w-d1t606-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t606-4">
   <w.rf>
    <LM>w#w-d1t606-4</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id75433-punct">
   <w.rf>
    <LM>w#w-d-id75433-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t606-9">
   <w.rf>
    <LM>w#w-d1t606-9</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t606-7">
   <w.rf>
    <LM>w#w-d1t606-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t606-8">
   <w.rf>
    <LM>w#w-d1t606-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t606-10">
   <w.rf>
    <LM>w#w-d1t606-10</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m038-d1t606-11">
   <w.rf>
    <LM>w#w-d1t606-11</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m038-d1t606-16">
   <w.rf>
    <LM>w#w-d1t606-16</LM>
   </w.rf>
   <form>šenkovnu</form>
   <lemma>šenkovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-320-321">
   <w.rf>
    <LM>w#w-320-321</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t608-1">
   <w.rf>
    <LM>w#w-d1t608-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t608-2">
   <w.rf>
    <LM>w#w-d1t608-2</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t608-3">
   <w.rf>
    <LM>w#w-d1t608-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t608-4">
   <w.rf>
    <LM>w#w-d1t608-4</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m038-320-322">
   <w.rf>
    <LM>w#w-320-322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-323">
  <m id="m038-d1t608-10">
   <w.rf>
    <LM>w#w-d1t608-10</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t608-9">
   <w.rf>
    <LM>w#w-d1t608-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t608-11">
   <w.rf>
    <LM>w#w-d1t608-11</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m038-d1t608-12">
   <w.rf>
    <LM>w#w-d1t608-12</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m038-d1t608-13">
   <w.rf>
    <LM>w#w-d1t608-13</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m038-d1t608-14">
   <w.rf>
    <LM>w#w-d1t608-14</LM>
   </w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m038-d-id75838-punct">
   <w.rf>
    <LM>w#w-d-id75838-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t610-1">
   <w.rf>
    <LM>w#w-d1t610-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t610-2">
   <w.rf>
    <LM>w#w-d1t610-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t610-3">
   <w.rf>
    <LM>w#w-d1t610-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t610-4">
   <w.rf>
    <LM>w#w-d1t610-4</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id75926-punct">
   <w.rf>
    <LM>w#w-d-id75926-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t610-9">
   <w.rf>
    <LM>w#w-d1t610-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t610-10">
   <w.rf>
    <LM>w#w-d1t610-10</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m038-d1t610-11">
   <w.rf>
    <LM>w#w-d1t610-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t610-12">
   <w.rf>
    <LM>w#w-d1t610-12</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t610-13">
   <w.rf>
    <LM>w#w-d1t610-13</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id76024-punct">
   <w.rf>
    <LM>w#w-d-id76024-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t610-15">
   <w.rf>
    <LM>w#w-d1t610-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t610-16">
   <w.rf>
    <LM>w#w-d1t610-16</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m038-d1t610-18">
   <w.rf>
    <LM>w#w-d1t610-18</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-323-324">
   <w.rf>
    <LM>w#w-323-324</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-325">
  <m id="m038-d1t613-3">
   <w.rf>
    <LM>w#w-d1t613-3</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t613-4">
   <w.rf>
    <LM>w#w-d1t613-4</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t613-5">
   <w.rf>
    <LM>w#w-d1t613-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t613-6">
   <w.rf>
    <LM>w#w-d1t613-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t613-7">
   <w.rf>
    <LM>w#w-d1t613-7</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t613-8">
   <w.rf>
    <LM>w#w-d1t613-8</LM>
   </w.rf>
   <form>stěhovali</form>
   <lemma>stěhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t613-9">
   <w.rf>
    <LM>w#w-d1t613-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t613-10">
   <w.rf>
    <LM>w#w-d1t613-10</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m038-d1t613-11">
   <w.rf>
    <LM>w#w-d1t613-11</LM>
   </w.rf>
   <form>teplejší</form>
   <lemma>teplý</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m038-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t615-4">
   <w.rf>
    <LM>w#w-d1t615-4</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t615-3">
   <w.rf>
    <LM>w#w-d1t615-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t615-5">
   <w.rf>
    <LM>w#w-d1t615-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t615-6">
   <w.rf>
    <LM>w#w-d1t615-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m038-d1t615-7">
   <w.rf>
    <LM>w#w-d1t615-7</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m038-d-m-d1e599-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e599-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e618-x2">
  <m id="m038-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t621-2">
   <w.rf>
    <LM>w#w-d1t621-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t621-3">
   <w.rf>
    <LM>w#w-d1t621-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d-m-d1e618-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e618-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e628-x2">
  <m id="m038-d1t631-1">
   <w.rf>
    <LM>w#w-d1t631-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m038-d1t631-2">
   <w.rf>
    <LM>w#w-d1t631-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m038-d1t631-4">
   <w.rf>
    <LM>w#w-d1t631-4</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t631-5">
   <w.rf>
    <LM>w#w-d1t631-5</LM>
   </w.rf>
   <form>vyfotil</form>
   <lemma>vyfotit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d-id76713-punct">
   <w.rf>
    <LM>w#w-d-id76713-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e632-x2">
  <m id="m038-d1t643-16">
   <w.rf>
    <LM>w#w-d1t643-16</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t643-17">
   <w.rf>
    <LM>w#w-d1t643-17</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d-id77091-punct">
   <w.rf>
    <LM>w#w-d-id77091-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t646-2">
   <w.rf>
    <LM>w#w-d1t646-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m038-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m038-d1t646-4">
   <w.rf>
    <LM>w#w-d1t646-4</LM>
   </w.rf>
   <form>přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d1t646-5">
   <w.rf>
    <LM>w#w-d1t646-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t646-7">
   <w.rf>
    <LM>w#w-d1t646-7</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1t648-2">
   <w.rf>
    <LM>w#w-d1t648-2</LM>
   </w.rf>
   <form>Tonuška</form>
   <lemma>Tonuška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-id77255-punct">
   <w.rf>
    <LM>w#w-d-id77255-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t648-5">
   <w.rf>
    <LM>w#w-d1t648-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t648-6">
   <w.rf>
    <LM>w#w-d1t648-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t648-7">
   <w.rf>
    <LM>w#w-d1t648-7</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m038-d1t650-1">
   <w.rf>
    <LM>w#w-d1t650-1</LM>
   </w.rf>
   <form>sestřenice</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-id77334-punct">
   <w.rf>
    <LM>w#w-d-id77334-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t652-1">
   <w.rf>
    <LM>w#w-d1t652-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t652-2">
   <w.rf>
    <LM>w#w-d1t652-2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m038-d1t652-3">
   <w.rf>
    <LM>w#w-d1t652-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m038-d1t652-4">
   <w.rf>
    <LM>w#w-d1t652-4</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t652-5">
   <w.rf>
    <LM>w#w-d1t652-5</LM>
   </w.rf>
   <form>vyfotila</form>
   <lemma>vyfotit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d-m-d1e632-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e632-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
