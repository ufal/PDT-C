<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_791.03.w.gz" />
  </references>
 </head>
 <s id="m791-16379_01-2087">
  <m id="m791-d1t726-4">
   <w.rf>
    <LM>w#w-d1t726-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t726-5">
   <w.rf>
    <LM>w#w-d1t726-5</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m791-d-id87933">
   <w.rf>
    <LM>w#w-d-id87933</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t726-7">
   <w.rf>
    <LM>w#w-d1t726-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t726-11">
   <w.rf>
    <LM>w#w-d1t726-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t726-12">
   <w.rf>
    <LM>w#w-d1t726-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t726-10">
   <w.rf>
    <LM>w#w-d1t726-10</LM>
   </w.rf>
   <form>nesměli</form>
   <lemma>smět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m791-d1t726-13">
   <w.rf>
    <LM>w#w-d1t726-13</LM>
   </w.rf>
   <form>vzdálit</form>
   <lemma>vzdálit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m791-d1t726-14">
   <w.rf>
    <LM>w#w-d1t726-14</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t726-15">
   <w.rf>
    <LM>w#w-d1t726-15</LM>
   </w.rf>
   <form>Kyjova</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m791-2087-2290">
   <w.rf>
    <LM>w#w-2087-2290</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t728-1">
   <w.rf>
    <LM>w#w-d1t728-1</LM>
   </w.rf>
   <form>nesměli</form>
   <lemma>smět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m791-d1t728-2">
   <w.rf>
    <LM>w#w-d1t728-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t728-3">
   <w.rf>
    <LM>w#w-d1t728-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t728-4">
   <w.rf>
    <LM>w#w-d1t728-4</LM>
   </w.rf>
   <form>parku</form>
   <lemma>park</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m791-d-id88161">
   <w.rf>
    <LM>w#w-d-id88161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t728-6">
   <w.rf>
    <LM>w#w-d1t728-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t728-7">
   <w.rf>
    <LM>w#w-d1t728-7</LM>
   </w.rf>
   <form>žádných</form>
   <lemma>žádný</lemma>
   <tag>PWXP2----------</tag>
  </m>
  <m id="m791-d1t728-8">
   <w.rf>
    <LM>w#w-d1t728-8</LM>
   </w.rf>
   <form>veřejných</form>
   <lemma>veřejný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m791-d1t728-9">
   <w.rf>
    <LM>w#w-d1t728-9</LM>
   </w.rf>
   <form>prostředků</form>
   <lemma>prostředek_^(střed,způsob,_nástroj)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m791-2087-2293">
   <w.rf>
    <LM>w#w-2087-2293</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t728-10">
   <w.rf>
    <LM>w#w-d1t728-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t728-13">
   <w.rf>
    <LM>w#w-d1t728-13</LM>
   </w.rf>
   <form>divadla</form>
   <lemma>divadlo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m791-d-id88293">
   <w.rf>
    <LM>w#w-d-id88293</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t728-15">
   <w.rf>
    <LM>w#w-d1t728-15</LM>
   </w.rf>
   <form>kina</form>
   <lemma>kino</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m791-d-id88318">
   <w.rf>
    <LM>w#w-d-id88318</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t728-18">
   <w.rf>
    <LM>w#w-d1t728-18</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t728-12">
   <w.rf>
    <LM>w#w-d1t728-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t728-17">
   <w.rf>
    <LM>w#w-d1t728-17</LM>
   </w.rf>
   <form>koncerty</form>
   <lemma>koncert</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m791-d-id88358">
   <w.rf>
    <LM>w#w-d-id88358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x6">
  <m id="m791-d1t730-2">
   <w.rf>
    <LM>w#w-d1t730-2</LM>
   </w.rf>
   <form>Jediná</form>
   <lemma>jediný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m791-d1t730-3">
   <w.rf>
    <LM>w#w-d1t730-3</LM>
   </w.rf>
   <form>vycházka</form>
   <lemma>vycházka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d-id88428">
   <w.rf>
    <LM>w#w-d-id88428</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t730-5">
   <w.rf>
    <LM>w#w-d1t730-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m791-d1t730-6">
   <w.rf>
    <LM>w#w-d1t730-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t730-7">
   <w.rf>
    <LM>w#w-d1t730-7</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1e710-x6-2298">
   <w.rf>
    <LM>w#w-d1e710-x6-2298</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t730-8">
   <w.rf>
    <LM>w#w-d1t730-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t730-9">
   <w.rf>
    <LM>w#w-d1t730-9</LM>
   </w.rf>
   <form>Bukovanská</form>
   <lemma>bukovanský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m791-d1t730-10">
   <w.rf>
    <LM>w#w-d1t730-10</LM>
   </w.rf>
   <form>alej</form>
   <lemma>alej</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t730-12">
   <w.rf>
    <LM>w#w-d1t730-12</LM>
   </w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m791-d1t730-13">
   <w.rf>
    <LM>w#w-d1t730-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t730-14">
   <w.rf>
    <LM>w#w-d1t730-14</LM>
   </w.rf>
   <form>Bukovany</form>
   <lemma>Bukovany_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m791-d1e710-x6-2527">
   <w.rf>
    <LM>w#w-d1e710-x6-2527</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t732-1">
   <w.rf>
    <LM>w#w-d1t732-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t732-2">
   <w.rf>
    <LM>w#w-d1t732-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m791-d1t732-3">
   <w.rf>
    <LM>w#w-d1t732-3</LM>
   </w.rf>
   <form>zatáčce</form>
   <lemma>zatáčka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m791-d-id88578">
   <w.rf>
    <LM>w#w-d-id88578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x7">
  <m id="m791-d1t732-5">
   <w.rf>
    <LM>w#w-d1t732-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t732-6">
   <w.rf>
    <LM>w#w-d1t732-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t732-7">
   <w.rf>
    <LM>w#w-d1t732-7</LM>
   </w.rf>
   <form>jmenovalo</form>
   <lemma>jmenovat</lemma>
   <tag>VpNS----R-AAB--</tag>
  </m>
  <m id="m791-d1t732-8">
   <w.rf>
    <LM>w#w-d1t732-8</LM>
   </w.rf>
   <form>Kohoutek</form>
   <lemma>kohoutek-2_^(květina,_uzávěr)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m791-d-id88726">
   <w.rf>
    <LM>w#w-d-id88726</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t732-11">
   <w.rf>
    <LM>w#w-d1t732-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t732-10">
   <w.rf>
    <LM>w#w-d1t732-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t732-13">
   <w.rf>
    <LM>w#w-d1t732-13</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m791-d1t732-14">
   <w.rf>
    <LM>w#w-d1t732-14</LM>
   </w.rf>
   <form>soška</form>
   <lemma>soška</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t732-15">
   <w.rf>
    <LM>w#w-d1t732-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t732-20">
   <w.rf>
    <LM>w#w-d1t732-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t732-21">
   <w.rf>
    <LM>w#w-d1t732-21</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m791-d1t732-22">
   <w.rf>
    <LM>w#w-d1t732-22</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t734-1">
   <w.rf>
    <LM>w#w-d1t734-1</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t732-19">
   <w.rf>
    <LM>w#w-d1t732-19</LM>
   </w.rf>
   <form>kohout</form>
   <lemma>kohout-1_^(pták)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d-id88958">
   <w.rf>
    <LM>w#w-d-id88958</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x8">
  <m id="m791-d1t737-3">
   <w.rf>
    <LM>w#w-d1t737-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t737-2">
   <w.rf>
    <LM>w#w-d1t737-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t739-1">
   <w.rf>
    <LM>w#w-d1t739-1</LM>
   </w.rf>
   <form>Alej</form>
   <lemma>alej</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t739-2">
   <w.rf>
    <LM>w#w-d1t739-2</LM>
   </w.rf>
   <form>vzdechů</form>
   <lemma>vzdech</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m791-d1e710-x8-2560">
   <w.rf>
    <LM>w#w-d1e710-x8-2560</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1e710-x8-2561">
   <w.rf>
    <LM>w#w-d1e710-x8-2561</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t739-3">
   <w.rf>
    <LM>w#w-d1t739-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t739-4">
   <w.rf>
    <LM>w#w-d1t739-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m791-d1t739-5">
   <w.rf>
    <LM>w#w-d1t739-5</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d-id89130">
   <w.rf>
    <LM>w#w-d-id89130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x9">
  <m id="m791-d1t745-5">
   <w.rf>
    <LM>w#w-d1t745-5</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m791-d1t745-4">
   <w.rf>
    <LM>w#w-d1t745-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t745-6">
   <w.rf>
    <LM>w#w-d1t745-6</LM>
   </w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m791-d1t745-7">
   <w.rf>
    <LM>w#w-d1t745-7</LM>
   </w.rf>
   <form>meze</form>
   <lemma>mez</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m791-d1t745-9">
   <w.rf>
    <LM>w#w-d1t745-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t745-11">
   <w.rf>
    <LM>w#w-d1t745-11</LM>
   </w.rf>
   <form>silnice</form>
   <lemma>silnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t745-12">
   <w.rf>
    <LM>w#w-d1t745-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t745-14">
   <w.rf>
    <LM>w#w-d1t745-14</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1e710-x9-2831">
   <w.rf>
    <LM>w#w-d1e710-x9-2831</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t743-1">
   <w.rf>
    <LM>w#w-d1t743-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t743-2">
   <w.rf>
    <LM>w#w-d1t743-2</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d1t745-16">
   <w.rf>
    <LM>w#w-d1t745-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t745-18">
   <w.rf>
    <LM>w#w-d1t745-18</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t745-17">
   <w.rf>
    <LM>w#w-d1t745-17</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t745-19">
   <w.rf>
    <LM>w#w-d1t745-19</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m791-d1t745-20">
   <w.rf>
    <LM>w#w-d1t745-20</LM>
   </w.rf>
   <form>zaváté</form>
   <lemma>zavátý_^(*1)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m791-d1t745-21">
   <w.rf>
    <LM>w#w-d1t745-21</LM>
   </w.rf>
   <form>sněhem</form>
   <lemma>sníh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m791-d1e710-x9-2835">
   <w.rf>
    <LM>w#w-d1e710-x9-2835</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-2836">
  <m id="m791-d1t743-4">
   <w.rf>
    <LM>w#w-d1t743-4</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t743-3">
   <w.rf>
    <LM>w#w-d1t743-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t743-6">
   <w.rf>
    <LM>w#w-d1t743-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t743-7">
   <w.rf>
    <LM>w#w-d1t743-7</LM>
   </w.rf>
   <form>potěšení</form>
   <lemma>potěšení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d-id89265">
   <w.rf>
    <LM>w#w-d-id89265</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t743-9">
   <w.rf>
    <LM>w#w-d1t743-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t745-25">
   <w.rf>
    <LM>w#w-d1t745-25</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t745-26">
   <w.rf>
    <LM>w#w-d1t745-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t745-27">
   <w.rf>
    <LM>w#w-d1t745-27</LM>
   </w.rf>
   <form>narukovali</form>
   <lemma>narukovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m791-d1t745-28">
   <w.rf>
    <LM>w#w-d1t745-28</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m791-d1t745-29">
   <w.rf>
    <LM>w#w-d1t745-29</LM>
   </w.rf>
   <form>lopatami</form>
   <lemma>lopata</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m791-d1t747-1">
   <w.rf>
    <LM>w#w-d1t747-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t747-2">
   <w.rf>
    <LM>w#w-d1t747-2</LM>
   </w.rf>
   <form>vyhazovali</form>
   <lemma>vyhazovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t747-3">
   <w.rf>
    <LM>w#w-d1t747-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t747-5">
   <w.rf>
    <LM>w#w-d1t747-5</LM>
   </w.rf>
   <form>sníh</form>
   <lemma>sníh</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-d-id89822">
   <w.rf>
    <LM>w#w-d-id89822</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t747-7">
   <w.rf>
    <LM>w#w-d1t747-7</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t747-9">
   <w.rf>
    <LM>w#w-d1t747-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t747-8">
   <w.rf>
    <LM>w#w-d1t747-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t747-10">
   <w.rf>
    <LM>w#w-d1t747-10</LM>
   </w.rf>
   <form>průjezdné</form>
   <lemma>průjezdný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m791-d1e710-x9-2819">
   <w.rf>
    <LM>w#w-d1e710-x9-2819</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-2820">
  <m id="m791-d1t747-12">
   <w.rf>
    <LM>w#w-d1t747-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t747-13">
   <w.rf>
    <LM>w#w-d1t747-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t747-15">
   <w.rf>
    <LM>w#w-d1t747-15</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m791-d1t747-16">
   <w.rf>
    <LM>w#w-d1t747-16</LM>
   </w.rf>
   <form>zimy</form>
   <lemma>zima-1</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m791-d1t747-17">
   <w.rf>
    <LM>w#w-d1t747-17</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m791-d1t747-18">
   <w.rf>
    <LM>w#w-d1t747-18</LM>
   </w.rf>
   <form>zábava</form>
   <lemma>zábava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d-id90010">
   <w.rf>
    <LM>w#w-d-id90010</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x10">
  <m id="m791-d1t750-1">
   <w.rf>
    <LM>w#w-d1t750-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t752-1">
   <w.rf>
    <LM>w#w-d1t752-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m791-d1t752-5">
   <w.rf>
    <LM>w#w-d1t752-5</LM>
   </w.rf>
   <form>veselí</form>
   <lemma>veselý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m791-d-id90135">
   <w.rf>
    <LM>w#w-d-id90135</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t752-7">
   <w.rf>
    <LM>w#w-d1t752-7</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m791-d1t752-9">
   <w.rf>
    <LM>w#w-d1t752-9</LM>
   </w.rf>
   <form>strýc</form>
   <lemma>strýc</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t752-18">
   <w.rf>
    <LM>w#w-d1t752-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t752-19">
   <w.rf>
    <LM>w#w-d1t752-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t752-10">
   <w.rf>
    <LM>w#w-d1t752-10</LM>
   </w.rf>
   <form>složil</form>
   <lemma>složit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1t752-14">
   <w.rf>
    <LM>w#w-d1t752-14</LM>
   </w.rf>
   <form>veselou</form>
   <lemma>veselý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m791-d1t752-11">
   <w.rf>
    <LM>w#w-d1t752-11</LM>
   </w.rf>
   <form>písničku</form>
   <lemma>písnička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m791-d-id90222">
   <w.rf>
    <LM>w#w-d-id90222</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t752-16">
   <w.rf>
    <LM>w#w-d1t752-16</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m791-d1t752-17">
   <w.rf>
    <LM>w#w-d1t752-17</LM>
   </w.rf>
   <form>kuplet</form>
   <lemma>kuplet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-d-id90332">
   <w.rf>
    <LM>w#w-d-id90332</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x11">
  <m id="m791-d1t758-4">
   <w.rf>
    <LM>w#w-d1t758-4</LM>
   </w.rf>
   <form>Ptala</form>
   <lemma>ptát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t758-2">
   <w.rf>
    <LM>w#w-d1t758-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m791-d1t758-3">
   <w.rf>
    <LM>w#w-d1t758-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1e710-x11-2937">
   <w.rf>
    <LM>w#w-d1e710-x11-2937</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t758-6">
   <w.rf>
    <LM>w#w-d1t758-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t758-7">
   <w.rf>
    <LM>w#w-d1t758-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t758-8">
   <w.rf>
    <LM>w#w-d1t758-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t758-9">
   <w.rf>
    <LM>w#w-d1t758-9</LM>
   </w.rf>
   <form>bavili</form>
   <lemma>bavit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1e710-x11-2938">
   <w.rf>
    <LM>w#w-d1e710-x11-2938</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-2939">
  <m id="m791-d1t758-12">
   <w.rf>
    <LM>w#w-d1t758-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t758-13">
   <w.rf>
    <LM>w#w-d1t758-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m791-d1t758-14">
   <w.rf>
    <LM>w#w-d1t758-14</LM>
   </w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m791-d-id90576">
   <w.rf>
    <LM>w#w-d-id90576</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e710-x12">
  <m id="m791-d1t763-1">
   <w.rf>
    <LM>w#w-d1t763-1</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t763-2">
   <w.rf>
    <LM>w#w-d1t763-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t763-3">
   <w.rf>
    <LM>w#w-d1t763-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t763-4">
   <w.rf>
    <LM>w#w-d1t763-4</LM>
   </w.rf>
   <form>Kyjově</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t763-5">
   <w.rf>
    <LM>w#w-d1t763-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t763-6">
   <w.rf>
    <LM>w#w-d1t763-6</LM>
   </w.rf>
   <form>židovském</form>
   <lemma>židovský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m791-d1t763-7">
   <w.rf>
    <LM>w#w-d1t763-7</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t763-9">
   <w.rf>
    <LM>w#w-d1t763-9</LM>
   </w.rf>
   <form>židovský</form>
   <lemma>židovský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m791-d1t763-8">
   <w.rf>
    <LM>w#w-d1t763-8</LM>
   </w.rf>
   <form>klub</form>
   <lemma>klub</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m791-d-id90742">
   <w.rf>
    <LM>w#w-d-id90742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x2">
  <m id="m791-d1t775-1">
   <w.rf>
    <LM>w#w-d1t775-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m791-d1t775-2">
   <w.rf>
    <LM>w#w-d1t775-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t775-3">
   <w.rf>
    <LM>w#w-d1t775-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t775-4">
   <w.rf>
    <LM>w#w-d1t775-4</LM>
   </w.rf>
   <form>zrušen</form>
   <lemma>zrušit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m791-d1t775-5">
   <w.rf>
    <LM>w#w-d1t775-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t777-1">
   <w.rf>
    <LM>w#w-d1t777-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t779-1">
   <w.rf>
    <LM>w#w-d1t779-1</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m791-d1t779-8">
   <w.rf>
    <LM>w#w-d1t779-8</LM>
   </w.rf>
   <form>zezadu</form>
   <lemma>zezadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t779-4">
   <w.rf>
    <LM>w#w-d1t779-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t779-5">
   <w.rf>
    <LM>w#w-d1t779-5</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>Slávia</form>
   <lemma>Slávie_;m</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m791-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>přidělena</form>
   <lemma>přidělit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m791-d1t779-11">
   <w.rf>
    <LM>w#w-d1t779-11</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m791-d1t779-12">
   <w.rf>
    <LM>w#w-d1t779-12</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t779-13">
   <w.rf>
    <LM>w#w-d1t779-13</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t781-1">
   <w.rf>
    <LM>w#w-d1t781-1</LM>
   </w.rf>
   <form>klubovna</form>
   <lemma>klubovna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d-id91298">
   <w.rf>
    <LM>w#w-d-id91298</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x3">
  <m id="m791-d1t784-1">
   <w.rf>
    <LM>w#w-d1t784-1</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t784-2">
   <w.rf>
    <LM>w#w-d1t784-2</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d-id91353">
   <w.rf>
    <LM>w#w-d-id91353</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t784-4">
   <w.rf>
    <LM>w#w-d1t784-4</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t784-5">
   <w.rf>
    <LM>w#w-d1t784-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t784-6">
   <w.rf>
    <LM>w#w-d1t784-6</LM>
   </w.rf>
   <form>přehled</form>
   <lemma>přehled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m791-d-id91408">
   <w.rf>
    <LM>w#w-d-id91408</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t784-8">
   <w.rf>
    <LM>w#w-d1t784-8</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m791-d1e770-x3-3068">
   <w.rf>
    <LM>w#w-d1e770-x3-3068</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t784-10">
   <w.rf>
    <LM>w#w-d1t784-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m791-d1t784-11">
   <w.rf>
    <LM>w#w-d1t784-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t784-12">
   <w.rf>
    <LM>w#w-d1t784-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d-id91494">
   <w.rf>
    <LM>w#w-d-id91494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x4">
  <m id="m791-d1t788-1">
   <w.rf>
    <LM>w#w-d1t788-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t788-3">
   <w.rf>
    <LM>w#w-d1t788-3</LM>
   </w.rf>
   <form>zákonů</form>
   <lemma>zákon</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m791-d1t788-4">
   <w.rf>
    <LM>w#w-d1t788-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t788-5">
   <w.rf>
    <LM>w#w-d1t788-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t788-6">
   <w.rf>
    <LM>w#w-d1t788-6</LM>
   </w.rf>
   <form>vztahoval</form>
   <lemma>vztahovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t790-1">
   <w.rf>
    <LM>w#w-d1t790-1</LM>
   </w.rf>
   <form>zákaz</form>
   <lemma>zákaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m791-d1t790-2">
   <w.rf>
    <LM>w#w-d1t790-2</LM>
   </w.rf>
   <form>návštěvy</form>
   <lemma>návštěva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m791-d1t790-3">
   <w.rf>
    <LM>w#w-d1t790-3</LM>
   </w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m791-d-id91684">
   <w.rf>
    <LM>w#w-d-id91684</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t790-5">
   <w.rf>
    <LM>w#w-d1t790-5</LM>
   </w.rf>
   <form>veškerých</form>
   <lemma>veškerý</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m791-d1t790-6">
   <w.rf>
    <LM>w#w-d1t790-6</LM>
   </w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m791-d-id91724">
   <w.rf>
    <LM>w#w-d-id91724</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t790-8">
   <w.rf>
    <LM>w#w-d1t790-8</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t790-9">
   <w.rf>
    <LM>w#w-d1t790-9</LM>
   </w.rf>
   <form>Židy</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m791-d-id91763">
   <w.rf>
    <LM>w#w-d-id91763</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t790-12">
   <w.rf>
    <LM>w#w-d1t790-12</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m791-d1t790-13">
   <w.rf>
    <LM>w#w-d1t790-13</LM>
   </w.rf>
   <form>pádem</form>
   <lemma>pád</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m791-d1t790-14">
   <w.rf>
    <LM>w#w-d1t790-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t790-15">
   <w.rf>
    <LM>w#w-d1t790-15</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m791-d1t790-17">
   <w.rf>
    <LM>w#w-d1t790-17</LM>
   </w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m791-d1t790-18">
   <w.rf>
    <LM>w#w-d1t790-18</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m791-d1t790-21">
   <w.rf>
    <LM>w#w-d1t790-21</LM>
   </w.rf>
   <form>reálného</form>
   <lemma>reálný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m791-d1t790-22">
   <w.rf>
    <LM>w#w-d1t790-22</LM>
   </w.rf>
   <form>gymnázia</form>
   <lemma>gymnázium</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m791-d1t790-23">
   <w.rf>
    <LM>w#w-d1t790-23</LM>
   </w.rf>
   <form>skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d-id91984">
   <w.rf>
    <LM>w#w-d-id91984</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x5">
  <m id="m791-d1t794-1">
   <w.rf>
    <LM>w#w-d1t794-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m791-d1t794-2">
   <w.rf>
    <LM>w#w-d1t794-2</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m791-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>potravinové</form>
   <lemma>potravinový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m791-d1t794-4">
   <w.rf>
    <LM>w#w-d1t794-4</LM>
   </w.rf>
   <form>lístky</form>
   <lemma>lístek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m791-d1t794-5">
   <w.rf>
    <LM>w#w-d1t794-5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t794-6">
   <w.rf>
    <LM>w#w-d1t794-6</LM>
   </w.rf>
   <form>Židy</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m791-d1e770-x5-638">
   <w.rf>
    <LM>w#w-d1e770-x5-638</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-639">
  <m id="m791-d1t797-2">
   <w.rf>
    <LM>w#w-d1t797-2</LM>
   </w.rf>
   <form>Zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m791-d1t797-3">
   <w.rf>
    <LM>w#w-d1t797-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m791-d1t797-1">
   <w.rf>
    <LM>w#w-d1t797-1</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t797-4">
   <w.rf>
    <LM>w#w-d1t797-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t797-5">
   <w.rf>
    <LM>w#w-d1t797-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m791-d-id92206">
   <w.rf>
    <LM>w#w-d-id92206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t797-10">
   <w.rf>
    <LM>w#w-d1t797-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t797-11">
   <w.rf>
    <LM>w#w-d1t797-11</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m791-d1t797-12">
   <w.rf>
    <LM>w#w-d1t797-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t797-13">
   <w.rf>
    <LM>w#w-d1t797-13</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m791-d1e770-x5-3299">
   <w.rf>
    <LM>w#w-d1e770-x5-3299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3300">
  <m id="m791-3300-3307">
   <w.rf>
    <LM>w#w-3300-3307</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m791-d1t801-1">
   <w.rf>
    <LM>w#w-d1t801-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t801-2">
   <w.rf>
    <LM>w#w-d1t801-2</LM>
   </w.rf>
   <form>šatenky</form>
   <lemma>šatenka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m791-d1t801-6">
   <w.rf>
    <LM>w#w-d1t801-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t801-9">
   <w.rf>
    <LM>w#w-d1t801-9</LM>
   </w.rf>
   <form>ošacení</form>
   <lemma>ošacení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d-id92317">
   <w.rf>
    <LM>w#w-d-id92317</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x7">
  <m id="m791-d1t803-2">
   <w.rf>
    <LM>w#w-d1t803-2</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t803-4">
   <w.rf>
    <LM>w#w-d1t803-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m791-d-id92562">
   <w.rf>
    <LM>w#w-d-id92562</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t803-6">
   <w.rf>
    <LM>w#w-d1t803-6</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t803-7">
   <w.rf>
    <LM>w#w-d1t803-7</LM>
   </w.rf>
   <form>šatenky</form>
   <lemma>šatenka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m791-d1t803-8">
   <w.rf>
    <LM>w#w-d1t803-8</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m791-d1t803-9">
   <w.rf>
    <LM>w#w-d1t803-9</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t803-10">
   <w.rf>
    <LM>w#w-d1t803-10</LM>
   </w.rf>
   <form>Židy</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m791-d-id92628">
   <w.rf>
    <LM>w#w-d-id92628</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x8">
  <m id="m791-d1t805-1">
   <w.rf>
    <LM>w#w-d1t805-1</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d-id92668">
   <w.rf>
    <LM>w#w-d-id92668</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t805-5">
   <w.rf>
    <LM>w#w-d1t805-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d-id92722">
   <w.rf>
    <LM>w#w-d-id92722</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x9">
  <m id="m791-d1t814-2">
   <w.rf>
    <LM>w#w-d1t814-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t814-3">
   <w.rf>
    <LM>w#w-d1t814-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t814-4">
   <w.rf>
    <LM>w#w-d1t814-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m791-d1t814-6">
   <w.rf>
    <LM>w#w-d1t814-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t814-5">
   <w.rf>
    <LM>w#w-d1t814-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t814-7">
   <w.rf>
    <LM>w#w-d1t814-7</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t814-8">
   <w.rf>
    <LM>w#w-d1t814-8</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m791-d-id92978">
   <w.rf>
    <LM>w#w-d-id92978</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x11">
  <m id="m791-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t820-2">
   <w.rf>
    <LM>w#w-d1t820-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m791-d1t823-1">
   <w.rf>
    <LM>w#w-d1t823-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t823-3">
   <w.rf>
    <LM>w#w-d1t823-3</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m791-d1t823-2">
   <w.rf>
    <LM>w#w-d1t823-2</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m791-d1t823-4">
   <w.rf>
    <LM>w#w-d1t823-4</LM>
   </w.rf>
   <form>historku</form>
   <lemma>historka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m791-d-id93121">
   <w.rf>
    <LM>w#w-d-id93121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t825-2">
   <w.rf>
    <LM>w#w-d1t825-2</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m791-d1t825-3">
   <w.rf>
    <LM>w#w-d1t825-3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m791-d1t825-5">
   <w.rf>
    <LM>w#w-d1t825-5</LM>
   </w.rf>
   <form>vztah</form>
   <lemma>vztah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-d1t825-6">
   <w.rf>
    <LM>w#w-d1t825-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m791-d1t825-7">
   <w.rf>
    <LM>w#w-d1t825-7</LM>
   </w.rf>
   <form>antisemitismu</form>
   <lemma>antisemitismus_,s_^(^DD**antisemitizmus)</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m791-d1e770-x11-3588">
   <w.rf>
    <LM>w#w-d1e770-x11-3588</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3589">
  <m id="m791-d1t831-1">
   <w.rf>
    <LM>w#w-d1t831-1</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m791-d1t831-2">
   <w.rf>
    <LM>w#w-d1t831-2</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m791-d1t831-3">
   <w.rf>
    <LM>w#w-d1t831-3</LM>
   </w.rf>
   <form>spolužák</form>
   <lemma>spolužák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t831-11">
   <w.rf>
    <LM>w#w-d1t831-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t831-12">
   <w.rf>
    <LM>w#w-d1t831-12</LM>
   </w.rf>
   <form>gymnázia</form>
   <lemma>gymnázium</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m791-d1t831-6">
   <w.rf>
    <LM>w#w-d1t831-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t831-5">
   <w.rf>
    <LM>w#w-d1t831-5</LM>
   </w.rf>
   <form>jmenoval</form>
   <lemma>jmenovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m791-d1t831-7">
   <w.rf>
    <LM>w#w-d1t831-7</LM>
   </w.rf>
   <form>Vodička</form>
   <lemma>Vodička_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-3589-3600">
   <w.rf>
    <LM>w#w-3589-3600</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-3589-3601">
   <w.rf>
    <LM>w#w-3589-3601</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t831-8">
   <w.rf>
    <LM>w#w-d1t831-8</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m791-d1t831-9">
   <w.rf>
    <LM>w#w-d1t831-9</LM>
   </w.rf>
   <form>Stražovic</form>
   <lemma>Stražovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m791-3589-3603">
   <w.rf>
    <LM>w#w-3589-3603</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3604">
  <m id="m791-d1t833-3">
   <w.rf>
    <LM>w#w-d1t833-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t833-5">
   <w.rf>
    <LM>w#w-d1t833-5</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t833-4">
   <w.rf>
    <LM>w#w-d1t833-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t833-7">
   <w.rf>
    <LM>w#w-d1t833-7</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t833-9">
   <w.rf>
    <LM>w#w-d1t833-9</LM>
   </w.rf>
   <form>pocit</form>
   <lemma>pocit</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-d-id93596">
   <w.rf>
    <LM>w#w-d-id93596</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t833-11">
   <w.rf>
    <LM>w#w-d1t833-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t833-13">
   <w.rf>
    <LM>w#w-d1t833-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m791-d1t833-14">
   <w.rf>
    <LM>w#w-d1t833-14</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m791-3604-3624">
   <w.rf>
    <LM>w#w-3604-3624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3604-3625">
   <w.rf>
    <LM>w#w-3604-3625</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3604-3626">
   <w.rf>
    <LM>w#w-3604-3626</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3617">
  <m id="m791-d1t836-1">
   <w.rf>
    <LM>w#w-d1t836-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t836-2">
   <w.rf>
    <LM>w#w-d1t836-2</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m791-d1t836-3">
   <w.rf>
    <LM>w#w-d1t836-3</LM>
   </w.rf>
   <form>protektorátu</form>
   <lemma>protektorát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m791-d1t838-1">
   <w.rf>
    <LM>w#w-d1t838-1</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m791-3617-3630">
   <w.rf>
    <LM>w#w-3617-3630</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3617-3631">
   <w.rf>
    <LM>w#w-3617-3631</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m791-3617-3632">
   <w.rf>
    <LM>w#w-3617-3632</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t838-2">
   <w.rf>
    <LM>w#w-d1t838-2</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnMS4----------</tag>
  </m>
  <m id="m791-d1t838-3">
   <w.rf>
    <LM>w#w-d1t838-3</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m791-3617-3633">
   <w.rf>
    <LM>w#w-3617-3633</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t838-4">
   <w.rf>
    <LM>w#w-d1t838-4</LM>
   </w.rf>
   <form>potkal</form>
   <lemma>potkat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1t838-5">
   <w.rf>
    <LM>w#w-d1t838-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t838-10">
   <w.rf>
    <LM>w#w-d1t838-10</LM>
   </w.rf>
   <form>Nerudově</form>
   <lemma>Nerudův_;Y_^(*2a)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m791-d1t838-6">
   <w.rf>
    <LM>w#w-d1t838-6</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-3617-3636">
   <w.rf>
    <LM>w#w-3617-3636</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3637">
  <m id="m791-d1t838-12">
   <w.rf>
    <LM>w#w-d1t838-12</LM>
   </w.rf>
   <form>Úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t838-13">
   <w.rf>
    <LM>w#w-d1t838-13</LM>
   </w.rf>
   <form>drze</form>
   <lemma>drze_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t838-14">
   <w.rf>
    <LM>w#w-d1t838-14</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t838-15">
   <w.rf>
    <LM>w#w-d1t838-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t838-16">
   <w.rf>
    <LM>w#w-d1t838-16</LM>
   </w.rf>
   <form>nehodlal</form>
   <lemma>hodlat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m791-d1t838-17">
   <w.rf>
    <LM>w#w-d1t838-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t838-18">
   <w.rf>
    <LM>w#w-d1t838-18</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m791-d1t838-19">
   <w.rf>
    <LM>w#w-d1t838-19</LM>
   </w.rf>
   <form>vyhnout</form>
   <lemma>vyhnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m791-d-id94030">
   <w.rf>
    <LM>w#w-d-id94030</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t838-21">
   <w.rf>
    <LM>w#w-d1t838-21</LM>
   </w.rf>
   <form>vrazil</form>
   <lemma>vrazit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1t838-22">
   <w.rf>
    <LM>w#w-d1t838-22</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t838-23">
   <w.rf>
    <LM>w#w-d1t838-23</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m791-d1t838-25">
   <w.rf>
    <LM>w#w-d1t838-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t838-26">
   <w.rf>
    <LM>w#w-d1t838-26</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1t838-27">
   <w.rf>
    <LM>w#w-d1t838-27</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m791-d1t838-28">
   <w.rf>
    <LM>w#w-d1t838-28</LM>
   </w.rf>
   <form>nadávat</form>
   <lemma>nadávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m791-3637-3647">
   <w.rf>
    <LM>w#w-3637-3647</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t838-30">
   <w.rf>
    <LM>w#w-d1t838-30</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t838-31">
   <w.rf>
    <LM>w#w-d1t838-31</LM>
   </w.rf>
   <form>Židáci</form>
   <lemma>židák_,h</lemma>
   <tag>NNMP5-----A----</tag>
  </m>
  <m id="m791-3637-3649">
   <w.rf>
    <LM>w#w-3637-3649</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3637-3656">
   <w.rf>
    <LM>w#w-3637-3656</LM>
   </w.rf>
   <form>patříte</form>
   <lemma>patřit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m791-3637-3657">
   <w.rf>
    <LM>w#w-3637-3657</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3637-3658">
   <w.rf>
    <LM>w#w-3637-3658</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-3637-3659">
   <w.rf>
    <LM>w#w-3637-3659</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-2351">
  <m id="m791-d1t838-35">
   <w.rf>
    <LM>w#w-d1t838-35</LM>
   </w.rf>
   <form>Nemáte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m791-d1t838-36">
   <w.rf>
    <LM>w#w-d1t838-36</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t838-37">
   <w.rf>
    <LM>w#w-d1t838-37</LM>
   </w.rf>
   <form>chodníku</form>
   <lemma>chodník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-3637-3653">
   <w.rf>
    <LM>w#w-3637-3653</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t838-38">
   <w.rf>
    <LM>w#w-d1t838-38</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m791-d1t838-39">
   <w.rf>
    <LM>w#w-d1t838-39</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m791-3637-3655">
   <w.rf>
    <LM>w#w-3637-3655</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d-id94299">
   <w.rf>
    <LM>w#w-d-id94299</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x12">
  <m id="m791-d1t842-5">
   <w.rf>
    <LM>w#w-d1t842-5</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t842-3">
   <w.rf>
    <LM>w#w-d1t842-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t842-4">
   <w.rf>
    <LM>w#w-d1t842-4</LM>
   </w.rf>
   <form>býval</form>
   <lemma>bývat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t842-6">
   <w.rf>
    <LM>w#w-d1t842-6</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t842-7">
   <w.rf>
    <LM>w#w-d1t842-7</LM>
   </w.rf>
   <form>rvavý</form>
   <lemma>rvavý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m791-d1t842-8">
   <w.rf>
    <LM>w#w-d1t842-8</LM>
   </w.rf>
   <form>hoch</form>
   <lemma>hoch</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1e770-x12-1191">
   <w.rf>
    <LM>w#w-d1e770-x12-1191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-1192">
  <m id="m791-d1t842-11">
   <w.rf>
    <LM>w#w-d1t842-11</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t842-12">
   <w.rf>
    <LM>w#w-d1t842-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t842-13">
   <w.rf>
    <LM>w#w-d1t842-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t842-14">
   <w.rf>
    <LM>w#w-d1t842-14</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m791-d1e770-x12-3757">
   <w.rf>
    <LM>w#w-d1e770-x12-3757</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t842-19">
   <w.rf>
    <LM>w#w-d1t842-19</LM>
   </w.rf>
   <form>nenechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m791-d1t842-16">
   <w.rf>
    <LM>w#w-d1t842-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t842-17">
   <w.rf>
    <LM>w#w-d1t842-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t842-18">
   <w.rf>
    <LM>w#w-d1t842-18</LM>
   </w.rf>
   <form>písku</form>
   <lemma>písek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t842-20">
   <w.rf>
    <LM>w#w-d1t842-20</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m791-d1t842-21">
   <w.rf>
    <LM>w#w-d1t842-21</LM>
   </w.rf>
   <form>děcko</form>
   <lemma>děcko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d1t842-22">
   <w.rf>
    <LM>w#w-d1t842-22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t842-23">
   <w.rf>
    <LM>w#w-d1t842-23</LM>
   </w.rf>
   <form>klidu</form>
   <lemma>klid</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1e770-x12-3759">
   <w.rf>
    <LM>w#w-d1e770-x12-3759</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t853-1">
   <w.rf>
    <LM>w#w-d1t853-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t853-2">
   <w.rf>
    <LM>w#w-d1t853-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t853-3">
   <w.rf>
    <LM>w#w-d1t853-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t853-4">
   <w.rf>
    <LM>w#w-d1t853-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m791-d1t853-5">
   <w.rf>
    <LM>w#w-d1t853-5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t853-6">
   <w.rf>
    <LM>w#w-d1t853-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m791-d1e770-x12-3760">
   <w.rf>
    <LM>w#w-d1e770-x12-3760</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-3761">
  <m id="m791-d1t853-10">
   <w.rf>
    <LM>w#w-d1t853-10</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t853-11">
   <w.rf>
    <LM>w#w-d1t853-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t855-2">
   <w.rf>
    <LM>w#w-d1t855-2</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t855-3">
   <w.rf>
    <LM>w#w-d1t855-3</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t855-4">
   <w.rf>
    <LM>w#w-d1t855-4</LM>
   </w.rf>
   <form>Buksmanovi</form>
   <lemma>Buksmanův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m791-3761-3883">
   <w.rf>
    <LM>w#w-3761-3883</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t857-1">
   <w.rf>
    <LM>w#w-d1t857-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t857-2">
   <w.rf>
    <LM>w#w-d1t857-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t857-3">
   <w.rf>
    <LM>w#w-d1t857-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t857-4">
   <w.rf>
    <LM>w#w-d1t857-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t857-6">
   <w.rf>
    <LM>w#w-d1t857-6</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d-id95007">
   <w.rf>
    <LM>w#w-d-id95007</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x13">
  <m id="m791-d1t857-8">
   <w.rf>
    <LM>w#w-d1t857-8</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1e770-x13-3889">
   <w.rf>
    <LM>w#w-d1e770-x13-3889</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t857-9">
   <w.rf>
    <LM>w#w-d1t857-9</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t857-11">
   <w.rf>
    <LM>w#w-d1t857-11</LM>
   </w.rf>
   <form>Otýne</form>
   <lemma>Otýn_;Y</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m791-d1e770-x13-3891">
   <w.rf>
    <LM>w#w-d1e770-x13-3891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t857-12">
   <w.rf>
    <LM>w#w-d1t857-12</LM>
   </w.rf>
   <form>otevři</form>
   <lemma>otevřít</lemma>
   <tag>Vi-S---2--A-P--</tag>
  </m>
  <m id="m791-d1t857-13">
   <w.rf>
    <LM>w#w-d1t857-13</LM>
   </w.rf>
   <form>vrata</form>
   <lemma>vrata</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m791-d-id95206">
   <w.rf>
    <LM>w#w-d-id95206</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1e770-x13-3892">
   <w.rf>
    <LM>w#w-d1e770-x13-3892</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x14">
  <m id="m791-d1t859-4">
   <w.rf>
    <LM>w#w-d1t859-4</LM>
   </w.rf>
   <form>Chytl</form>
   <lemma>chytnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m791-d1t859-2">
   <w.rf>
    <LM>w#w-d1t859-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t859-3">
   <w.rf>
    <LM>w#w-d1t859-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d-id95291">
   <w.rf>
    <LM>w#w-d-id95291</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t859-6">
   <w.rf>
    <LM>w#w-d1t859-6</LM>
   </w.rf>
   <form>hodil</form>
   <lemma>hodit-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1t859-7">
   <w.rf>
    <LM>w#w-d1t859-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t859-8">
   <w.rf>
    <LM>w#w-d1t859-8</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t859-9">
   <w.rf>
    <LM>w#w-d1t859-9</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t859-10">
   <w.rf>
    <LM>w#w-d1t859-10</LM>
   </w.rf>
   <form>vrata</form>
   <lemma>vrata</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m791-d1t859-11">
   <w.rf>
    <LM>w#w-d1t859-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t859-12">
   <w.rf>
    <LM>w#w-d1t859-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t859-13">
   <w.rf>
    <LM>w#w-d1t859-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t859-14">
   <w.rf>
    <LM>w#w-d1t859-14</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t859-15">
   <w.rf>
    <LM>w#w-d1t859-15</LM>
   </w.rf>
   <form>zmydlil</form>
   <lemma>zmydlit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d1e770-x14-4078">
   <w.rf>
    <LM>w#w-d1e770-x14-4078</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-4079">
  <m id="m791-d1t859-18">
   <w.rf>
    <LM>w#w-d1t859-18</LM>
   </w.rf>
   <form>Vypadl</form>
   <lemma>vypadnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m791-d1t859-19">
   <w.rf>
    <LM>w#w-d1t859-19</LM>
   </w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t859-20">
   <w.rf>
    <LM>w#w-d1t859-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t859-23">
   <w.rf>
    <LM>w#w-d1t859-23</LM>
   </w.rf>
   <form>hrozil</form>
   <lemma>hrozit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t859-24">
   <w.rf>
    <LM>w#w-d1t859-24</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m791-d-id95567">
   <w.rf>
    <LM>w#w-d-id95567</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t859-26">
   <w.rf>
    <LM>w#w-d1t859-26</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t859-27">
   <w.rf>
    <LM>w#w-d1t859-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t859-28">
   <w.rf>
    <LM>w#w-d1t859-28</LM>
   </w.rf>
   <form>řekne</form>
   <lemma>říci</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m791-d1t859-29">
   <w.rf>
    <LM>w#w-d1t859-29</LM>
   </w.rf>
   <form>Hamsálovi</form>
   <lemma>Hamsál_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m791-4079-693">
   <w.rf>
    <LM>w#w-4079-693</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-694">
  <m id="m791-d1t859-32">
   <w.rf>
    <LM>w#w-d1t859-32</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t859-33">
   <w.rf>
    <LM>w#w-d1t859-33</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t859-34">
   <w.rf>
    <LM>w#w-d1t859-34</LM>
   </w.rf>
   <form>Němec</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d-id95708">
   <w.rf>
    <LM>w#w-d-id95708</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t859-36">
   <w.rf>
    <LM>w#w-d1t859-36</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m791-d1t859-37">
   <w.rf>
    <LM>w#w-d1t859-37</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t864-1">
   <w.rf>
    <LM>w#w-d1t864-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t864-2">
   <w.rf>
    <LM>w#w-d1t864-2</LM>
   </w.rf>
   <form>Kyjově</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t859-39">
   <w.rf>
    <LM>w#w-d1t859-39</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t859-40">
   <w.rf>
    <LM>w#w-d1t859-40</LM>
   </w.rf>
   <form>komando</form>
   <lemma>komando</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d-id95794">
   <w.rf>
    <LM>w#w-d-id95794</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x16">
  <m id="m791-d1e770-x16-4219">
   <w.rf>
    <LM>w#w-d1e770-x16-4219</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m791-d1e770-x16-4220">
   <w.rf>
    <LM>w#w-d1e770-x16-4220</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t866-1">
   <w.rf>
    <LM>w#w-d1t866-1</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t866-2">
   <w.rf>
    <LM>w#w-d1t866-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m791-d1t866-3">
   <w.rf>
    <LM>w#w-d1t866-3</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d-id95922">
   <w.rf>
    <LM>w#w-d-id95922</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t866-5">
   <w.rf>
    <LM>w#w-d1t866-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t866-6">
   <w.rf>
    <LM>w#w-d1t866-6</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d-id95962">
   <w.rf>
    <LM>w#w-d-id95962</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t866-8">
   <w.rf>
    <LM>w#w-d1t866-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t866-10">
   <w.rf>
    <LM>w#w-d1t866-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t866-11">
   <w.rf>
    <LM>w#w-d1t866-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t866-12">
   <w.rf>
    <LM>w#w-d1t866-12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t866-13">
   <w.rf>
    <LM>w#w-d1t866-13</LM>
   </w.rf>
   <form>něm</form>
   <lemma>on-1</lemma>
   <tag>PEZS6--3-------</tag>
  </m>
  <m id="m791-d1t866-15">
   <w.rf>
    <LM>w#w-d1t866-15</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t866-14">
   <w.rf>
    <LM>w#w-d1t866-14</LM>
   </w.rf>
   <form>neslyšel</form>
   <lemma>slyšet</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m791-d1e770-x16-4223">
   <w.rf>
    <LM>w#w-d1e770-x16-4223</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-4224">
  <m id="m791-d1t866-17">
   <w.rf>
    <LM>w#w-d1t866-17</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t866-18">
   <w.rf>
    <LM>w#w-d1t866-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m791-d1t866-19">
   <w.rf>
    <LM>w#w-d1t866-19</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t866-20">
   <w.rf>
    <LM>w#w-d1t866-20</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t866-21">
   <w.rf>
    <LM>w#w-d1t866-21</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t866-22">
   <w.rf>
    <LM>w#w-d1t866-22</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d1t866-23">
   <w.rf>
    <LM>w#w-d1t866-23</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m791-d1t866-24">
   <w.rf>
    <LM>w#w-d1t866-24</LM>
   </w.rf>
   <form>zahlédl</form>
   <lemma>zahlédnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m791-4224-4334">
   <w.rf>
    <LM>w#w-4224-4334</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t870-1">
   <w.rf>
    <LM>w#w-d1t870-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t870-2">
   <w.rf>
    <LM>w#w-d1t870-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t870-4">
   <w.rf>
    <LM>w#w-d1t870-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m791-d1t870-5">
   <w.rf>
    <LM>w#w-d1t870-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t870-3">
   <w.rf>
    <LM>w#w-d1t870-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t870-6">
   <w.rf>
    <LM>w#w-d1t870-6</LM>
   </w.rf>
   <form>předčasné</form>
   <lemma>předčasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m791-d-id96353">
   <w.rf>
    <LM>w#w-d-id96353</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t870-8">
   <w.rf>
    <LM>w#w-d1t870-8</LM>
   </w.rf>
   <form>kdybych</form>
   <lemma>kdyby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m791-d1t870-9">
   <w.rf>
    <LM>w#w-d1t870-9</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t870-10">
   <w.rf>
    <LM>w#w-d1t870-10</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m791-d1t870-11">
   <w.rf>
    <LM>w#w-d1t870-11</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d-id96424">
   <w.rf>
    <LM>w#w-d-id96424</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x18">
  <m id="m791-d1t875-2">
   <w.rf>
    <LM>w#w-d1t875-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t875-3">
   <w.rf>
    <LM>w#w-d1t875-3</LM>
   </w.rf>
   <form>Kyjově</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t875-4">
   <w.rf>
    <LM>w#w-d1t875-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1t875-5">
   <w.rf>
    <LM>w#w-d1t875-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t875-6">
   <w.rf>
    <LM>w#w-d1t875-6</LM>
   </w.rf>
   <form>vlajkařů</form>
   <lemma>vlajkař_,h</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m791-d1e770-x18-711">
   <w.rf>
    <LM>w#w-d1e770-x18-711</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-712">
  <m id="m791-d1t875-8">
   <w.rf>
    <LM>w#w-d1t875-8</LM>
   </w.rf>
   <form>Vlajka</form>
   <lemma>Vlajka_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t875-10">
   <w.rf>
    <LM>w#w-d1t875-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t875-11">
   <w.rf>
    <LM>w#w-d1t875-11</LM>
   </w.rf>
   <form>fašistická</form>
   <lemma>fašistický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m791-d1t875-12">
   <w.rf>
    <LM>w#w-d1t875-12</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d-id96636">
   <w.rf>
    <LM>w#w-d-id96636</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t877-1">
   <w.rf>
    <LM>w#w-d1t877-1</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m791-d1t877-2">
   <w.rf>
    <LM>w#w-d1t877-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m791-d1t877-3">
   <w.rf>
    <LM>w#w-d1t877-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t877-4">
   <w.rf>
    <LM>w#w-d1t877-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m791-d1e770-x18-4394">
   <w.rf>
    <LM>w#w-d1e770-x18-4394</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t877-5">
   <w.rf>
    <LM>w#w-d1t877-5</LM>
   </w.rf>
   <form>kolaborantů</form>
   <lemma>kolaborant</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m791-d1e770-x18-709">
   <w.rf>
    <LM>w#w-d1e770-x18-709</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-710">
  <m id="m791-d1t877-9">
   <w.rf>
    <LM>w#w-d1t877-9</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t877-8">
   <w.rf>
    <LM>w#w-d1t877-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t877-10">
   <w.rf>
    <LM>w#w-d1t877-10</LM>
   </w.rf>
   <form>vesměs</form>
   <lemma>vesměs</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t877-11">
   <w.rf>
    <LM>w#w-d1t877-11</LM>
   </w.rf>
   <form>Češi</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m791-d1t879-1">
   <w.rf>
    <LM>w#w-d1t879-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t879-2">
   <w.rf>
    <LM>w#w-d1t879-2</LM>
   </w.rf>
   <form>takoví</form>
   <lemma>takový</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m791-d1t879-3">
   <w.rf>
    <LM>w#w-d1t879-3</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m791-d-id96888">
   <w.rf>
    <LM>w#w-d-id96888</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t879-5">
   <w.rf>
    <LM>w#w-d1t879-5</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m791-d1t879-9">
   <w.rf>
    <LM>w#w-d1t879-9</LM>
   </w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m791-d1t879-6">
   <w.rf>
    <LM>w#w-d1t879-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m791-d1t879-7">
   <w.rf>
    <LM>w#w-d1t879-7</LM>
   </w.rf>
   <form>Němců</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m791-d1t879-8">
   <w.rf>
    <LM>w#w-d1t879-8</LM>
   </w.rf>
   <form>hlášeni</form>
   <lemma>hlásit</lemma>
   <tag>VsMP----X-API--</tag>
  </m>
  <m id="m791-d1e770-x18-4518">
   <w.rf>
    <LM>w#w-d1e770-x18-4518</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x19">
  <m id="m791-d1t881-2">
   <w.rf>
    <LM>w#w-d1t881-2</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t881-3">
   <w.rf>
    <LM>w#w-d1t881-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t881-4">
   <w.rf>
    <LM>w#w-d1t881-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t881-5">
   <w.rf>
    <LM>w#w-d1t881-5</LM>
   </w.rf>
   <form>uniformách</form>
   <lemma>uniforma</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m791-d-id97078">
   <w.rf>
    <LM>w#w-d-id97078</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t881-7">
   <w.rf>
    <LM>w#w-d1t881-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t883-3">
   <w.rf>
    <LM>w#w-d1t883-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1t883-4">
   <w.rf>
    <LM>w#w-d1t883-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m791-d1t883-2">
   <w.rf>
    <LM>w#w-d1t883-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t883-5">
   <w.rf>
    <LM>w#w-d1t883-5</LM>
   </w.rf>
   <form>znali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1e770-x19-4533">
   <w.rf>
    <LM>w#w-d1e770-x19-4533</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1e770-x19-4534">
   <w.rf>
    <LM>w#w-d1e770-x19-4534</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d-id97188">
   <w.rf>
    <LM>w#w-d-id97188</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m791-d1e770-x19-4535">
   <w.rf>
    <LM>w#w-d1e770-x19-4535</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t883-12">
   <w.rf>
    <LM>w#w-d1t883-12</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m791-d1t883-13">
   <w.rf>
    <LM>w#w-d1t883-13</LM>
   </w.rf>
   <form>udávali</form>
   <lemma>udávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d-id97299">
   <w.rf>
    <LM>w#w-d-id97299</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t883-15">
   <w.rf>
    <LM>w#w-d1t883-15</LM>
   </w.rf>
   <form>hlídali</form>
   <lemma>hlídat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t883-16">
   <w.rf>
    <LM>w#w-d1t883-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t883-17">
   <w.rf>
    <LM>w#w-d1t883-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1e770-x19-4524">
   <w.rf>
    <LM>w#w-d1e770-x19-4524</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-4525">
  <m id="m791-d1t883-7">
   <w.rf>
    <LM>w#w-d1t883-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t883-8">
   <w.rf>
    <LM>w#w-d1t883-8</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m791-d1t883-9">
   <w.rf>
    <LM>w#w-d1t883-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t883-10">
   <w.rf>
    <LM>w#w-d1t883-10</LM>
   </w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m791-4525-4690">
   <w.rf>
    <LM>w#w-4525-4690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-4691">
  <m id="m791-d1t888-2">
   <w.rf>
    <LM>w#w-d1t888-2</LM>
   </w.rf>
   <form>Nejnebezpečnější</form>
   <lemma>bezpečný</lemma>
   <tag>AAMS1----3N----</tag>
  </m>
  <m id="m791-d1t890-1">
   <w.rf>
    <LM>w#w-d1t890-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t888-3">
   <w.rf>
    <LM>w#w-d1t888-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t888-4">
   <w.rf>
    <LM>w#w-d1t888-4</LM>
   </w.rf>
   <form>Kyjově</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t890-2">
   <w.rf>
    <LM>w#w-d1t890-2</LM>
   </w.rf>
   <form>drogista</form>
   <lemma>drogista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t890-3">
   <w.rf>
    <LM>w#w-d1t890-3</LM>
   </w.rf>
   <form>Chyba</form>
   <lemma>Chyba_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-4691-4701">
   <w.rf>
    <LM>w#w-4691-4701</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x21">
  <m id="m791-d1t892-2">
   <w.rf>
    <LM>w#w-d1t892-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m791-d1t892-4">
   <w.rf>
    <LM>w#w-d1t892-4</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t892-5">
   <w.rf>
    <LM>w#w-d1t892-5</LM>
   </w.rf>
   <form>skrytý</form>
   <lemma>skrytý_^(*3ýt)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m791-d1e770-x21-732">
   <w.rf>
    <LM>w#w-d1e770-x21-732</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-733">
  <m id="m791-d1t892-11">
   <w.rf>
    <LM>w#w-d1t892-11</LM>
   </w.rf>
   <form>Živil</form>
   <lemma>živit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t892-8">
   <w.rf>
    <LM>w#w-d1t892-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m791-d1t892-10">
   <w.rf>
    <LM>w#w-d1t892-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d-id97691">
   <w.rf>
    <LM>w#w-d-id97691</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t892-13">
   <w.rf>
    <LM>w#w-d1t892-13</LM>
   </w.rf>
   <form>přikrmoval</form>
   <lemma>přikrmovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d-id97716">
   <w.rf>
    <LM>w#w-d-id97716</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t892-16">
   <w.rf>
    <LM>w#w-d1t892-16</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t892-20">
   <w.rf>
    <LM>w#w-d1t892-20</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t892-21">
   <w.rf>
    <LM>w#w-d1t892-21</LM>
   </w.rf>
   <form>drogista</form>
   <lemma>drogista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t892-17">
   <w.rf>
    <LM>w#w-d1t892-17</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m791-d1t892-18">
   <w.rf>
    <LM>w#w-d1t892-18</LM>
   </w.rf>
   <form>alkoholy</form>
   <lemma>alkohol</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m791-d1e770-x21-5041">
   <w.rf>
    <LM>w#w-d1e770-x21-5041</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t894-1">
   <w.rf>
    <LM>w#w-d1t894-1</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m791-d1t894-2">
   <w.rf>
    <LM>w#w-d1t894-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m791-d1t894-3">
   <w.rf>
    <LM>w#w-d1t894-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t894-4">
   <w.rf>
    <LM>w#w-d1t894-4</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m791-d1t894-5">
   <w.rf>
    <LM>w#w-d1t894-5</LM>
   </w.rf>
   <form>napájet</form>
   <lemma>napájet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m791-d-id97826">
   <w.rf>
    <LM>w#w-d-id97826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x22">
  <m id="m791-d1t894-8">
   <w.rf>
    <LM>w#w-d1t894-8</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t894-9">
   <w.rf>
    <LM>w#w-d1t894-9</LM>
   </w.rf>
   <form>drogerii</form>
   <lemma>drogerie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m791-d1t896-1">
   <w.rf>
    <LM>w#w-d1t896-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d-id98013">
   <w.rf>
    <LM>w#w-d-id98013</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t896-3">
   <w.rf>
    <LM>w#w-d1t896-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t896-7">
   <w.rf>
    <LM>w#w-d1t896-7</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t896-8">
   <w.rf>
    <LM>w#w-d1t896-8</LM>
   </w.rf>
   <form>přehlédl</form>
   <lemma>přehlédnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m791-d1t896-5">
   <w.rf>
    <LM>w#w-d1t896-5</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m791-d1t896-6">
   <w.rf>
    <LM>w#w-d1t896-6</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d1e770-x22-5046">
   <w.rf>
    <LM>w#w-d1e770-x22-5046</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-5047">
  <m id="m791-d1t896-10">
   <w.rf>
    <LM>w#w-d1t896-10</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m791-d1t896-11">
   <w.rf>
    <LM>w#w-d1t896-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t896-12">
   <w.rf>
    <LM>w#w-d1t896-12</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m791-d1t896-13">
   <w.rf>
    <LM>w#w-d1t896-13</LM>
   </w.rf>
   <form>stejném</form>
   <lemma>stejný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m791-d1t896-14">
   <w.rf>
    <LM>w#w-d1t896-14</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t896-15">
   <w.rf>
    <LM>w#w-d1t896-15</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m791-d1t896-16">
   <w.rf>
    <LM>w#w-d1t896-16</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m791-d1t896-17">
   <w.rf>
    <LM>w#w-d1t896-17</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m791-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t901-4">
   <w.rf>
    <LM>w#w-d1t901-4</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t901-5">
   <w.rf>
    <LM>w#w-d1t901-5</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m791-d1t901-2">
   <w.rf>
    <LM>w#w-d1t901-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t901-8">
   <w.rf>
    <LM>w#w-d1t901-8</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t901-6">
   <w.rf>
    <LM>w#w-d1t901-6</LM>
   </w.rf>
   <form>potíže</form>
   <lemma>potíž</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m791-5047-5313">
   <w.rf>
    <LM>w#w-5047-5313</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t905-2">
   <w.rf>
    <LM>w#w-d1t905-2</LM>
   </w.rf>
   <form>hlídal</form>
   <lemma>hlídat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t905-3">
   <w.rf>
    <LM>w#w-d1t905-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m791-d-id98400">
   <w.rf>
    <LM>w#w-d-id98400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x25">
  <m id="m791-d1t909-1">
   <w.rf>
    <LM>w#w-d1t909-1</LM>
   </w.rf>
   <form>Tohoto</form>
   <lemma>tento</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m791-d1t909-2">
   <w.rf>
    <LM>w#w-d1t909-2</LM>
   </w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m791-d1t909-3">
   <w.rf>
    <LM>w#w-d1t909-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t909-4">
   <w.rf>
    <LM>w#w-d1t909-4</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d1t909-5">
   <w.rf>
    <LM>w#w-d1t909-5</LM>
   </w.rf>
   <form>chytli</form>
   <lemma>chytnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m791-d1t909-6">
   <w.rf>
    <LM>w#w-d1t909-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t909-7">
   <w.rf>
    <LM>w#w-d1t909-7</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d1t909-9">
   <w.rf>
    <LM>w#w-d1t909-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t909-10">
   <w.rf>
    <LM>w#w-d1t909-10</LM>
   </w.rf>
   <form>uniformě</form>
   <lemma>uniforma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d1t909-11">
   <w.rf>
    <LM>w#w-d1t909-11</LM>
   </w.rf>
   <form>barikádníků</form>
   <lemma>barikádník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m791-d-id98677">
   <w.rf>
    <LM>w#w-d-id98677</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t909-13">
   <w.rf>
    <LM>w#w-d1t909-13</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t909-14">
   <w.rf>
    <LM>w#w-d1t909-14</LM>
   </w.rf>
   <form>vozil</form>
   <lemma>vozit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t911-1">
   <w.rf>
    <LM>w#w-d1t911-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m791-d1t911-2">
   <w.rf>
    <LM>w#w-d1t911-2</LM>
   </w.rf>
   <form>šofér</form>
   <lemma>šofér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t909-16">
   <w.rf>
    <LM>w#w-d1t909-16</LM>
   </w.rf>
   <form>nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFP4----3A----</tag>
  </m>
  <m id="m791-d1t909-17">
   <w.rf>
    <LM>w#w-d1t909-17</LM>
   </w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m791-d1t909-18">
   <w.rf>
    <LM>w#w-d1t909-18</LM>
   </w.rf>
   <form>povstání</form>
   <lemma>povstání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m791-d-id98778">
   <w.rf>
    <LM>w#w-d-id98778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-d1e770-x27">
  <m id="m791-d1t914-1">
   <w.rf>
    <LM>w#w-d1t914-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t914-2">
   <w.rf>
    <LM>w#w-d1t914-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t914-3">
   <w.rf>
    <LM>w#w-d1t914-3</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m791-d1t914-4">
   <w.rf>
    <LM>w#w-d1t914-4</LM>
   </w.rf>
   <form>Kyjovák</form>
   <lemma>Kyjovák_;E_,h</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t914-5">
   <w.rf>
    <LM>w#w-d1t914-5</LM>
   </w.rf>
   <form>uviděl</form>
   <lemma>uvidět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m791-d-id98928">
   <w.rf>
    <LM>w#w-d-id98928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t914-7">
   <w.rf>
    <LM>w#w-d1t914-7</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t914-8">
   <w.rf>
    <LM>w#w-d1t914-8</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m791-d1t914-9">
   <w.rf>
    <LM>w#w-d1t914-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t914-10">
   <w.rf>
    <LM>w#w-d1t914-10</LM>
   </w.rf>
   <form>čapli</form>
   <lemma>čapnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m791-d1e770-x27-749">
   <w.rf>
    <LM>w#w-d1e770-x27-749</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-750">
  <m id="m791-d1t914-12">
   <w.rf>
    <LM>w#w-d1t914-12</LM>
   </w.rf>
   <form>Jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m791-d1t914-14">
   <w.rf>
    <LM>w#w-d1t914-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t914-15">
   <w.rf>
    <LM>w#w-d1t914-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t914-17">
   <w.rf>
    <LM>w#w-d1t914-17</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m791-d1t916-1">
   <w.rf>
    <LM>w#w-d1t916-1</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t916-2">
   <w.rf>
    <LM>w#w-d1t916-2</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t916-5">
   <w.rf>
    <LM>w#w-d1t916-5</LM>
   </w.rf>
   <form>převratu</form>
   <lemma>převrat</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m791-d-id99174">
   <w.rf>
    <LM>w#w-d-id99174</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t916-8">
   <w.rf>
    <LM>w#w-d1t916-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t916-9">
   <w.rf>
    <LM>w#w-d1t916-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m791-d1t916-12">
   <w.rf>
    <LM>w#w-d1t916-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m791-d1e770-x27-5544">
   <w.rf>
    <LM>w#w-d1e770-x27-5544</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m791-d1t916-13">
   <w.rf>
    <LM>w#w-d1t916-13</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m791-d1t916-15">
   <w.rf>
    <LM>w#w-d1t916-15</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-d1t916-16">
   <w.rf>
    <LM>w#w-d1t916-16</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m791-d1e770-x27-5534">
   <w.rf>
    <LM>w#w-d1e770-x27-5534</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-5535">
  <m id="m791-d1t916-20">
   <w.rf>
    <LM>w#w-d1t916-20</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t916-19">
   <w.rf>
    <LM>w#w-d1t916-19</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t916-21">
   <w.rf>
    <LM>w#w-d1t916-21</LM>
   </w.rf>
   <form>majetek</form>
   <lemma>majetek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m791-5535-5548">
   <w.rf>
    <LM>w#w-5535-5548</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m791-16379_01-5549">
  <m id="m791-d1t916-27">
   <w.rf>
    <LM>w#w-d1t916-27</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t916-26">
   <w.rf>
    <LM>w#w-d1t916-26</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m791-d1t916-28">
   <w.rf>
    <LM>w#w-d1t916-28</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m791-d1t916-29">
   <w.rf>
    <LM>w#w-d1t916-29</LM>
   </w.rf>
   <form>vazbě</form>
   <lemma>vazba_^(všechny_významy)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m791-d-id99512">
   <w.rf>
    <LM>w#w-d-id99512</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-d1t916-31">
   <w.rf>
    <LM>w#w-d1t916-31</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-d1t918-1">
   <w.rf>
    <LM>w#w-d1t918-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t918-2">
   <w.rf>
    <LM>w#w-d1t918-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m791-d1t918-3">
   <w.rf>
    <LM>w#w-d1t918-3</LM>
   </w.rf>
   <form>Kyjově</form>
   <lemma>Kyjov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m791-d1t918-4">
   <w.rf>
    <LM>w#w-d1t918-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m791-d1t918-5">
   <w.rf>
    <LM>w#w-d1t918-5</LM>
   </w.rf>
   <form>vězení</form>
   <lemma>vězení_^(místo_výkonu_trestu)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m791-d-id99622">
   <w.rf>
    <LM>w#w-d-id99622</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m791-5549-5559">
   <w.rf>
    <LM>w#w-5549-5559</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m791-5549-5560">
   <w.rf>
    <LM>w#w-5549-5560</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m791-5549-5561">
   <w.rf>
    <LM>w#w-5549-5561</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m791-d1t920-1">
   <w.rf>
    <LM>w#w-d1t920-1</LM>
   </w.rf>
   <form>nosil</form>
   <lemma>nosit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m791-d1t920-2">
   <w.rf>
    <LM>w#w-d1t920-2</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m791-d-id99671">
   <w.rf>
    <LM>w#w-d-id99671</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
