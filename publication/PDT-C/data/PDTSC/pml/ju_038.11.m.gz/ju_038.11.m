<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_038.11.w.gz" />
  </references>
 </head>
 <s id="m038-d1e3386-x2">
  <m id="m038-d1t3391-2">
   <w.rf>
    <LM>w#w-d1t3391-2</LM>
   </w.rf>
   <form>Fandovi</form>
   <lemma>Fanda_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m038-d1t3391-4">
   <w.rf>
    <LM>w#w-d1t3391-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3391-6">
   <w.rf>
    <LM>w#w-d1t3391-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3391-7">
   <w.rf>
    <LM>w#w-d1t3391-7</LM>
   </w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d1t3391-12">
   <w.rf>
    <LM>w#w-d1t3391-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3391-13">
   <w.rf>
    <LM>w#w-d1t3391-13</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t3391-14">
   <w.rf>
    <LM>w#w-d1t3391-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1e3386-x2-597">
   <w.rf>
    <LM>w#w-d1e3386-x2-597</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3386-x2-598">
   <w.rf>
    <LM>w#w-d1e3386-x2-598</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3386-x2-599">
   <w.rf>
    <LM>w#w-d1e3386-x2-599</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-600">
  <m id="m038-d1t3393-1">
   <w.rf>
    <LM>w#w-d1t3393-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m038-d1t3393-2">
   <w.rf>
    <LM>w#w-d1t3393-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3393-3">
   <w.rf>
    <LM>w#w-d1t3393-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3393-4">
   <w.rf>
    <LM>w#w-d1t3393-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3393-5">
   <w.rf>
    <LM>w#w-d1t3393-5</LM>
   </w.rf>
   <form>nemyslí</form>
   <lemma>myslit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d-id166757-punct">
   <w.rf>
    <LM>w#w-d-id166757-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3400-1">
   <w.rf>
    <LM>w#w-d1t3400-1</LM>
   </w.rf>
   <form>nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d1t3400-2">
   <w.rf>
    <LM>w#w-d1t3400-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d-id166854-punct">
   <w.rf>
    <LM>w#w-d-id166854-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3402-x2">
  <m id="m038-d1t3407-1">
   <w.rf>
    <LM>w#w-d1t3407-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3407-2">
   <w.rf>
    <LM>w#w-d1t3407-2</LM>
   </w.rf>
   <form>nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d-m-d1e3402-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3402-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3402-x3">
  <m id="m038-d1t3409-1">
   <w.rf>
    <LM>w#w-d1t3409-1</LM>
   </w.rf>
   <form>Nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d-m-d1e3402-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3402-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3410-x2">
  <m id="m038-d1t3413-1">
   <w.rf>
    <LM>w#w-d1t3413-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3413-2">
   <w.rf>
    <LM>w#w-d1t3413-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t3413-3">
   <w.rf>
    <LM>w#w-d1t3413-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t3413-4">
   <w.rf>
    <LM>w#w-d1t3413-4</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t3413-5">
   <w.rf>
    <LM>w#w-d1t3413-5</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-id167105-punct">
   <w.rf>
    <LM>w#w-d-id167105-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3410-x3">
  <m id="m038-d1t3415-1">
   <w.rf>
    <LM>w#w-d1t3415-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3415-2">
   <w.rf>
    <LM>w#w-d1t3415-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t3415-3">
   <w.rf>
    <LM>w#w-d1t3415-3</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1t3415-4">
   <w.rf>
    <LM>w#w-d1t3415-4</LM>
   </w.rf>
   <form>hostina</form>
   <lemma>hostina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-id167191-punct">
   <w.rf>
    <LM>w#w-d-id167191-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3416-x2">
  <m id="m038-d1t3419-1">
   <w.rf>
    <LM>w#w-d1t3419-1</LM>
   </w.rf>
   <form>Svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m038-d1t3419-2">
   <w.rf>
    <LM>w#w-d1t3419-2</LM>
   </w.rf>
   <form>hostinu</form>
   <lemma>hostina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t3419-3">
   <w.rf>
    <LM>w#w-d1t3419-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t3421-1">
   <w.rf>
    <LM>w#w-d1t3421-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3421-2">
   <w.rf>
    <LM>w#w-d1t3421-2</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t3419-4">
   <w.rf>
    <LM>w#w-d1t3419-4</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3419-5">
   <w.rf>
    <LM>w#w-d1t3419-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m038-d1t3419-7">
   <w.rf>
    <LM>w#w-d1t3419-7</LM>
   </w.rf>
   <form>Škvrňanech</form>
   <lemma>Škvrňany_;G_,h_^(^GC**Skvrňany)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m038-d1e3416-x2-365">
   <w.rf>
    <LM>w#w-d1e3416-x2-365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-366">
  <m id="m038-d1t3421-9">
   <w.rf>
    <LM>w#w-d1t3421-9</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3421-10">
   <w.rf>
    <LM>w#w-d1t3421-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m038-d1t3421-11">
   <w.rf>
    <LM>w#w-d1t3421-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3421-12">
   <w.rf>
    <LM>w#w-d1t3421-12</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-id167531-punct">
   <w.rf>
    <LM>w#w-d-id167531-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3421-17">
   <w.rf>
    <LM>w#w-d1t3421-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3421-18">
   <w.rf>
    <LM>w#w-d1t3421-18</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3421-19">
   <w.rf>
    <LM>w#w-d1t3421-19</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t3421-20">
   <w.rf>
    <LM>w#w-d1t3421-20</LM>
   </w.rf>
   <form>čtyřiceti</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m038-366-1945">
   <w.rf>
    <LM>w#w-366-1945</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3421-23">
   <w.rf>
    <LM>w#w-d1t3421-23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3421-24">
   <w.rf>
    <LM>w#w-d1t3421-24</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t3421-25">
   <w.rf>
    <LM>w#w-d1t3421-25</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3421-26">
   <w.rf>
    <LM>w#w-d1t3421-26</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1t3421-27">
   <w.rf>
    <LM>w#w-d1t3421-27</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3416-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3416-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3422-x2">
  <m id="m038-d1t3427-3">
   <w.rf>
    <LM>w#w-d1t3427-3</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3427-4">
   <w.rf>
    <LM>w#w-d1t3427-4</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m038-d1t3427-5">
   <w.rf>
    <LM>w#w-d1t3427-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3427-6">
   <w.rf>
    <LM>w#w-d1t3427-6</LM>
   </w.rf>
   <form>vydrželo</form>
   <lemma>vydržet</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-d-id167929-punct">
   <w.rf>
    <LM>w#w-d-id167929-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3427-10">
   <w.rf>
    <LM>w#w-d1t3427-10</LM>
   </w.rf>
   <form>zaplať</form>
   <lemma>zaplatit</lemma>
   <tag>Vi-S---3--A-P-4</tag>
  </m>
  <m id="m038-d1t3427-11">
   <w.rf>
    <LM>w#w-d1t3427-11</LM>
   </w.rf>
   <form>pánbůh</form>
   <lemma>pánbůh</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3422-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3422-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3422-x3">
  <m id="m038-d1t3444-1">
   <w.rf>
    <LM>w#w-d1t3444-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3444-2">
   <w.rf>
    <LM>w#w-d1t3444-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3444-3">
   <w.rf>
    <LM>w#w-d1t3444-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-m-d1e3422-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3422-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-1955">
  <m id="m038-d1t3440-1">
   <w.rf>
    <LM>w#w-d1t3440-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-1955-1965">
   <w.rf>
    <LM>w#w-1955-1965</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3445-x2">
  <m id="m038-d1t3448-2">
   <w.rf>
    <LM>w#w-d1t3448-2</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3448-5">
   <w.rf>
    <LM>w#w-d1t3448-5</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m038-d1t3448-6">
   <w.rf>
    <LM>w#w-d1t3448-6</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m038-d-id168285-punct">
   <w.rf>
    <LM>w#w-d-id168285-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3448-9">
   <w.rf>
    <LM>w#w-d1t3448-9</LM>
   </w.rf>
   <form>Karolínku</form>
   <lemma>Karolínka_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t3448-11">
   <w.rf>
    <LM>w#w-d1t3448-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3448-13">
   <w.rf>
    <LM>w#w-d1t3448-13</LM>
   </w.rf>
   <form>Martina</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m038-d1e3445-x2-1975">
   <w.rf>
    <LM>w#w-d1e3445-x2-1975</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-1976">
  <m id="m038-d1t3448-17">
   <w.rf>
    <LM>w#w-d1t3448-17</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m038-d1t3448-18">
   <w.rf>
    <LM>w#w-d1t3448-18</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t3448-19">
   <w.rf>
    <LM>w#w-d1t3448-19</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m038-d1t3448-23">
   <w.rf>
    <LM>w#w-d1t3448-23</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3448-24">
   <w.rf>
    <LM>w#w-d1t3448-24</LM>
   </w.rf>
   <form>baráku</form>
   <lemma>barák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m038-d1e3445-x2-383">
   <w.rf>
    <LM>w#w-d1e3445-x2-383</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-385">
  <m id="m038-d1t3448-27">
   <w.rf>
    <LM>w#w-d1t3448-27</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m038-d1t3448-28">
   <w.rf>
    <LM>w#w-d1t3448-28</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m038-d1t3448-29">
   <w.rf>
    <LM>w#w-d1t3448-29</LM>
   </w.rf>
   <form>nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3448-31">
   <w.rf>
    <LM>w#w-d1t3448-31</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3448-32">
   <w.rf>
    <LM>w#w-d1t3448-32</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m038-d1t3448-33">
   <w.rf>
    <LM>w#w-d1t3448-33</LM>
   </w.rf>
   <form>bydlíme</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3448-35">
   <w.rf>
    <LM>w#w-d1t3448-35</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-m-d1e3445-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3445-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3459-x2">
  <m id="m038-d1t3462-2">
   <w.rf>
    <LM>w#w-d1t3462-2</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3462-3">
   <w.rf>
    <LM>w#w-d1t3462-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3462-4">
   <w.rf>
    <LM>w#w-d1t3462-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3462-5">
   <w.rf>
    <LM>w#w-d1t3462-5</LM>
   </w.rf>
   <form>poznali</form>
   <lemma>poznat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d-id168920-punct">
   <w.rf>
    <LM>w#w-d-id168920-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3463-x2">
  <m id="m038-d1t3468-2">
   <w.rf>
    <LM>w#w-d1t3468-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t3468-4">
   <w.rf>
    <LM>w#w-d1t3468-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3468-6">
   <w.rf>
    <LM>w#w-d1t3468-6</LM>
   </w.rf>
   <form>pořádně</form>
   <lemma>pořádně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t3468-5">
   <w.rf>
    <LM>w#w-d1t3468-5</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m038-d1e3463-x2-393">
   <w.rf>
    <LM>w#w-d1e3463-x2-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-394">
  <m id="m038-d1t3468-9">
   <w.rf>
    <LM>w#w-d1t3468-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t3468-10">
   <w.rf>
    <LM>w#w-d1t3468-10</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m038-d1t3468-11">
   <w.rf>
    <LM>w#w-d1t3468-11</LM>
   </w.rf>
   <form>nepovím</form>
   <lemma>povědět</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m038-394-395">
   <w.rf>
    <LM>w#w-394-395</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-397">
  <m id="m038-d1t3468-15">
   <w.rf>
    <LM>w#w-d1t3468-15</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3468-16">
   <w.rf>
    <LM>w#w-d1t3468-16</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3468-17">
   <w.rf>
    <LM>w#w-d1t3468-17</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m038-d1t3470-1">
   <w.rf>
    <LM>w#w-d1t3470-1</LM>
   </w.rf>
   <form>tancovačce</form>
   <lemma>tancovačka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t3470-2">
   <w.rf>
    <LM>w#w-d1t3470-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3470-3">
   <w.rf>
    <LM>w#w-d1t3470-3</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3470-4">
   <w.rf>
    <LM>w#w-d1t3470-4</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m038-d1t3470-5">
   <w.rf>
    <LM>w#w-d1t3470-5</LM>
   </w.rf>
   <form>zábavě</form>
   <lemma>zábava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3463-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3463-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3471-x2">
  <m id="m038-d1t3478-1">
   <w.rf>
    <LM>w#w-d1t3478-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3478-2">
   <w.rf>
    <LM>w#w-d1t3478-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m038-d1t3478-3">
   <w.rf>
    <LM>w#w-d1t3478-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m038-d1t3478-4">
   <w.rf>
    <LM>w#w-d1t3478-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3478-5">
   <w.rf>
    <LM>w#w-d1t3478-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m038-d1t3478-6">
   <w.rf>
    <LM>w#w-d1t3478-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m038-d1t3478-7">
   <w.rf>
    <LM>w#w-d1t3478-7</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m038-d1t3478-8">
   <w.rf>
    <LM>w#w-d1t3478-8</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m038-d-id169494-punct">
   <w.rf>
    <LM>w#w-d-id169494-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3479-x2">
  <m id="m038-d1t3484-4">
   <w.rf>
    <LM>w#w-d1t3484-4</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3484-5">
   <w.rf>
    <LM>w#w-d1t3484-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e3479-x2-402">
   <w.rf>
    <LM>w#w-d1e3479-x2-402</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-404">
  <m id="m038-d1t3484-7">
   <w.rf>
    <LM>w#w-d1t3484-7</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t3484-8">
   <w.rf>
    <LM>w#w-d1t3484-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3484-9">
   <w.rf>
    <LM>w#w-d1t3484-9</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1t3484-10">
   <w.rf>
    <LM>w#w-d1t3484-10</LM>
   </w.rf>
   <form>veselka</form>
   <lemma>veselka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-404-405">
   <w.rf>
    <LM>w#w-404-405</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3484-11">
   <w.rf>
    <LM>w#w-d1t3484-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3484-12">
   <w.rf>
    <LM>w#w-d1t3484-12</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d-id169716-punct">
   <w.rf>
    <LM>w#w-d-id169716-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3484-14">
   <w.rf>
    <LM>w#w-d1t3484-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3484-15">
   <w.rf>
    <LM>w#w-d1t3484-15</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3484-17">
   <w.rf>
    <LM>w#w-d1t3484-17</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m038-d1t3484-18">
   <w.rf>
    <LM>w#w-d1t3484-18</LM>
   </w.rf>
   <form>konkrétního</form>
   <lemma>konkrétní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m038-d1t3484-19">
   <w.rf>
    <LM>w#w-d1t3484-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3486-1">
   <w.rf>
    <LM>w#w-d1t3486-1</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d-m-d1e3479-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3479-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3488-x2">
  <m id="m038-d1t3491-1">
   <w.rf>
    <LM>w#w-d1t3491-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1e3488-x2-407">
   <w.rf>
    <LM>w#w-d1e3488-x2-407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-408">
  <m id="m038-d1t3491-3">
   <w.rf>
    <LM>w#w-d1t3491-3</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d1t3491-4">
   <w.rf>
    <LM>w#w-d1t3491-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-m-d1e3488-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3488-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3494-x2">
  <m id="m038-d1t3499-1">
   <w.rf>
    <LM>w#w-d1t3499-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d-m-d1e3494-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3494-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3500-x3">
  <m id="m038-d1t3511-1">
   <w.rf>
    <LM>w#w-d1t3511-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m038-d1t3511-2">
   <w.rf>
    <LM>w#w-d1t3511-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3511-3">
   <w.rf>
    <LM>w#w-d1t3511-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3511-4">
   <w.rf>
    <LM>w#w-d1t3511-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m038-d1t3511-5">
   <w.rf>
    <LM>w#w-d1t3511-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d-id170213-punct">
   <w.rf>
    <LM>w#w-d-id170213-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3512-x2">
  <m id="m038-d1t3515-2">
   <w.rf>
    <LM>w#w-d1t3515-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3515-3">
   <w.rf>
    <LM>w#w-d1t3515-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3515-4">
   <w.rf>
    <LM>w#w-d1t3515-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m038-d1t3515-5">
   <w.rf>
    <LM>w#w-d1t3515-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t3515-6">
   <w.rf>
    <LM>w#w-d1t3515-6</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d1t3517-3">
   <w.rf>
    <LM>w#w-d1t3517-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m038-d1t3517-5">
   <w.rf>
    <LM>w#w-d1t3517-5</LM>
   </w.rf>
   <form>Slovanském</form>
   <lemma>slovanský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m038-d1t3517-6">
   <w.rf>
    <LM>w#w-d1t3517-6</LM>
   </w.rf>
   <form>údolí</form>
   <lemma>údolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m038-d1t3519-1">
   <w.rf>
    <LM>w#w-d1t3519-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3523-1">
   <w.rf>
    <LM>w#w-d1t3523-1</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t3519-6">
   <w.rf>
    <LM>w#w-d1t3519-6</LM>
   </w.rf>
   <form>Alenky</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d1e3512-x2-416">
   <w.rf>
    <LM>w#w-d1e3512-x2-416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-418">
  <m id="m038-d1t3523-3">
   <w.rf>
    <LM>w#w-d1t3523-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3523-4">
   <w.rf>
    <LM>w#w-d1t3523-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-418-419">
   <w.rf>
    <LM>w#w-418-419</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m038-d1t3523-5">
   <w.rf>
    <LM>w#w-d1t3523-5</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známá-1_^(*3ý-1)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3512-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3512-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3524-x2">
  <m id="m038-d1t3529-1">
   <w.rf>
    <LM>w#w-d1t3529-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3529-2">
   <w.rf>
    <LM>w#w-d1t3529-2</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m038-d1t3529-3">
   <w.rf>
    <LM>w#w-d1t3529-3</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3529-4">
   <w.rf>
    <LM>w#w-d1t3529-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t3529-5">
   <w.rf>
    <LM>w#w-d1t3529-5</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m038-d-m-d1e3524-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3524-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3524-x2-422">
   <w.rf>
    <LM>w#w-d1e3524-x2-422</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3524-x2-423">
   <w.rf>
    <LM>w#w-d1e3524-x2-423</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3536-x2">
  <m id="m038-d1t3539-3">
   <w.rf>
    <LM>w#w-d1t3539-3</LM>
   </w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m038-d1t3539-5">
   <w.rf>
    <LM>w#w-d1t3539-5</LM>
   </w.rf>
   <form>Zdenkou</form>
   <lemma>Zdenka_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d1t3539-7">
   <w.rf>
    <LM>w#w-d1t3539-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3539-9">
   <w.rf>
    <LM>w#w-d1t3539-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t3539-10">
   <w.rf>
    <LM>w#w-d1t3539-10</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m038-d1t3539-11">
   <w.rf>
    <LM>w#w-d1t3539-11</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1t3539-8">
   <w.rf>
    <LM>w#w-d1t3539-8</LM>
   </w.rf>
   <form>vařily</form>
   <lemma>vařit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1e3536-x2-428">
   <w.rf>
    <LM>w#w-d1e3536-x2-428</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3542-x2-427">
   <w.rf>
    <LM>w#w-d1e3542-x2-427</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3547-3">
   <w.rf>
    <LM>w#w-d1t3547-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m038-d1t3547-4">
   <w.rf>
    <LM>w#w-d1t3547-4</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3547-5">
   <w.rf>
    <LM>w#w-d1t3547-5</LM>
   </w.rf>
   <form>vyfotili</form>
   <lemma>vyfotit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d-m-d1e3542-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3542-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3542-x3">
  <m id="m038-d1t3549-1">
   <w.rf>
    <LM>w#w-d1t3549-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3549-2">
   <w.rf>
    <LM>w#w-d1t3549-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3549-3">
   <w.rf>
    <LM>w#w-d1t3549-3</LM>
   </w.rf>
   <form>vařily</form>
   <lemma>vařit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1t3549-4">
   <w.rf>
    <LM>w#w-d1t3549-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t3549-5">
   <w.rf>
    <LM>w#w-d1t3549-5</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m038-d1t3549-6">
   <w.rf>
    <LM>w#w-d1t3549-6</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d-id171239-punct">
   <w.rf>
    <LM>w#w-d-id171239-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3550-x2">
  <m id="m038-d1t3553-2">
   <w.rf>
    <LM>w#w-d1t3553-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d-id171331-punct">
   <w.rf>
    <LM>w#w-d-id171331-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3553-8">
   <w.rf>
    <LM>w#w-d1t3553-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3553-6">
   <w.rf>
    <LM>w#w-d1t3553-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m038-d1t3553-7">
   <w.rf>
    <LM>w#w-d1t3553-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3553-9">
   <w.rf>
    <LM>w#w-d1t3553-9</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t3553-10">
   <w.rf>
    <LM>w#w-d1t3553-10</LM>
   </w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d1t3555-1">
   <w.rf>
    <LM>w#w-d1t3555-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3555-5">
   <w.rf>
    <LM>w#w-d1t3555-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3555-3">
   <w.rf>
    <LM>w#w-d1t3555-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m038-d1t3555-2">
   <w.rf>
    <LM>w#w-d1t3555-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3555-4">
   <w.rf>
    <LM>w#w-d1t3555-4</LM>
   </w.rf>
   <form>pomáhali</form>
   <lemma>pomáhat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id171544-punct">
   <w.rf>
    <LM>w#w-d-id171544-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3557-1">
   <w.rf>
    <LM>w#w-d1t3557-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3557-3">
   <w.rf>
    <LM>w#w-d1t3557-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m038-d1t3557-6">
   <w.rf>
    <LM>w#w-d1t3557-6</LM>
   </w.rf>
   <form>Zdenkou</form>
   <lemma>Zdenka_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d1t3557-8">
   <w.rf>
    <LM>w#w-d1t3557-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3557-9">
   <w.rf>
    <LM>w#w-d1t3557-9</LM>
   </w.rf>
   <form>vařily</form>
   <lemma>vařit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e3550-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3550-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3558-x2">
  <m id="m038-d1t3563-1">
   <w.rf>
    <LM>w#w-d1t3563-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3563-2">
   <w.rf>
    <LM>w#w-d1t3563-2</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3563-3">
   <w.rf>
    <LM>w#w-d1t3563-3</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m038-d1t3563-4">
   <w.rf>
    <LM>w#w-d1t3563-4</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t3563-5">
   <w.rf>
    <LM>w#w-d1t3563-5</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3558-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3558-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3558-x3">
  <m id="m038-d1t3567-3">
   <w.rf>
    <LM>w#w-d1t3567-3</LM>
   </w.rf>
   <form>Napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3567-4">
   <w.rf>
    <LM>w#w-d1t3567-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3567-7">
   <w.rf>
    <LM>w#w-d1t3567-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t3567-6">
   <w.rf>
    <LM>w#w-d1t3567-6</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m038-d1t3567-5">
   <w.rf>
    <LM>w#w-d1t3567-5</LM>
   </w.rf>
   <form>upekly</form>
   <lemma>upéci</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m038-d1t3573-1">
   <w.rf>
    <LM>w#w-d1t3573-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3573-2">
   <w.rf>
    <LM>w#w-d1t3573-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t3573-3">
   <w.rf>
    <LM>w#w-d1t3573-3</LM>
   </w.rf>
   <form>vaření</form>
   <lemma>vaření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m038-d1t3573-4">
   <w.rf>
    <LM>w#w-d1t3573-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3573-5">
   <w.rf>
    <LM>w#w-d1t3573-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t3573-6">
   <w.rf>
    <LM>w#w-d1t3573-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3558-x3-638">
   <w.rf>
    <LM>w#w-d1e3558-x3-638</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3575-1">
   <w.rf>
    <LM>w#w-d1t3575-1</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m038-d1t3575-2">
   <w.rf>
    <LM>w#w-d1t3575-2</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1e3558-x3-639">
   <w.rf>
    <LM>w#w-d1e3558-x3-639</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3573-7">
   <w.rf>
    <LM>w#w-d1t3573-7</LM>
   </w.rf>
   <form>udělaly</form>
   <lemma>udělat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m038-d1t3573-8">
   <w.rf>
    <LM>w#w-d1t3573-8</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t3573-9">
   <w.rf>
    <LM>w#w-d1t3573-9</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3558-x3-450">
   <w.rf>
    <LM>w#w-d1e3558-x3-450</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3575-5">
   <w.rf>
    <LM>w#w-d1t3575-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3575-6">
   <w.rf>
    <LM>w#w-d1t3575-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3575-7">
   <w.rf>
    <LM>w#w-d1t3575-7</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m038-d1t3575-8">
   <w.rf>
    <LM>w#w-d1t3575-8</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3575-9">
   <w.rf>
    <LM>w#w-d1t3575-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3575-10">
   <w.rf>
    <LM>w#w-d1t3575-10</LM>
   </w.rf>
   <form>zlé</form>
   <lemma>zlý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d-id172273-punct">
   <w.rf>
    <LM>w#w-d-id172273-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3577-1">
   <w.rf>
    <LM>w#w-d1t3577-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3577-2">
   <w.rf>
    <LM>w#w-d1t3577-2</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d1e3570-x2-445">
   <w.rf>
    <LM>w#w-d1e3570-x2-445</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-447">
  <m id="m038-d1t3577-5">
   <w.rf>
    <LM>w#w-d1t3577-5</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t3577-6">
   <w.rf>
    <LM>w#w-d1t3577-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3577-7">
   <w.rf>
    <LM>w#w-d1t3577-7</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1t3577-8">
   <w.rf>
    <LM>w#w-d1t3577-8</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-447-448">
   <w.rf>
    <LM>w#w-447-448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-449">
  <m id="m038-d1t3577-10">
   <w.rf>
    <LM>w#w-d1t3577-10</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3577-11">
   <w.rf>
    <LM>w#w-d1t3577-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3577-12">
   <w.rf>
    <LM>w#w-d1t3577-12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m038-d1t3577-13">
   <w.rf>
    <LM>w#w-d1t3577-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3577-14">
   <w.rf>
    <LM>w#w-d1t3577-14</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3577-16">
   <w.rf>
    <LM>w#w-d1t3577-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3577-17">
   <w.rf>
    <LM>w#w-d1t3577-17</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d-id172533-punct">
   <w.rf>
    <LM>w#w-d-id172533-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3577-19">
   <w.rf>
    <LM>w#w-d1t3577-19</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3577-20">
   <w.rf>
    <LM>w#w-d1t3577-20</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3577-21">
   <w.rf>
    <LM>w#w-d1t3577-21</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m038-d1t3577-22">
   <w.rf>
    <LM>w#w-d1t3577-22</LM>
   </w.rf>
   <form>druhým</form>
   <lemma>druhý`2</lemma>
   <tag>CrMP3----------</tag>
  </m>
  <m id="m038-d-id172597-punct">
   <w.rf>
    <LM>w#w-d-id172597-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3577-24">
   <w.rf>
    <LM>w#w-d1t3577-24</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3577-25">
   <w.rf>
    <LM>w#w-d1t3577-25</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t3577-26">
   <w.rf>
    <LM>w#w-d1t3577-26</LM>
   </w.rf>
   <form>spokojení</form>
   <lemma>spokojený_^(*3it)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m038-d-m-d1e3570-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3570-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3578-x2">
  <m id="m038-d1t3581-1">
   <w.rf>
    <LM>w#w-d1t3581-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m038-d1t3581-2">
   <w.rf>
    <LM>w#w-d1t3581-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m038-d1t3581-3">
   <w.rf>
    <LM>w#w-d1t3581-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3581-4">
   <w.rf>
    <LM>w#w-d1t3581-4</LM>
   </w.rf>
   <form>vařily</form>
   <lemma>vařit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d-id172767-punct">
   <w.rf>
    <LM>w#w-d-id172767-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3603-x2">
  <m id="m038-d1e3603-x2-733">
   <w.rf>
    <LM>w#w-d1e3603-x2-733</LM>
   </w.rf>
   <form>Vařila</form>
   <lemma>vařit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-732">
   <w.rf>
    <LM>w#w-d1e3603-x2-732</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-731">
   <w.rf>
    <LM>w#w-d1e3603-x2-731</LM>
   </w.rf>
   <form>svíčková</form>
   <lemma>svíčková</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-730">
   <w.rf>
    <LM>w#w-d1e3603-x2-730</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-729">
   <w.rf>
    <LM>w#w-d1e3603-x2-729</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-728">
   <w.rf>
    <LM>w#w-d1e3603-x2-728</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-727">
   <w.rf>
    <LM>w#w-d1e3603-x2-727</LM>
   </w.rf>
   <form>sekaná</form>
   <lemma>sekaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d1e3603-x2-725">
   <w.rf>
    <LM>w#w-d1e3603-x2-725</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-726">
  <m id="m038-d1e3603-x2-724">
   <w.rf>
    <LM>w#w-d1e3603-x2-724</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-723">
   <w.rf>
    <LM>w#w-d1e3603-x2-723</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-722">
   <w.rf>
    <LM>w#w-d1e3603-x2-722</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-721">
   <w.rf>
    <LM>w#w-d1e3603-x2-721</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-720">
   <w.rf>
    <LM>w#w-d1e3603-x2-720</LM>
   </w.rf>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-718">
   <w.rf>
    <LM>w#w-d1e3603-x2-718</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-719">
  <m id="m038-d1e3603-x2-717">
   <w.rf>
    <LM>w#w-d1e3603-x2-717</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m038-d1e3603-x2-716">
   <w.rf>
    <LM>w#w-d1e3603-x2-716</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-715">
   <w.rf>
    <LM>w#w-d1e3603-x2-715</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-d1e3603-x2-714">
   <w.rf>
    <LM>w#w-d1e3603-x2-714</LM>
   </w.rf>
   <form>připravit</form>
   <lemma>připravit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m038-d1e3603-x2-713">
   <w.rf>
    <LM>w#w-d1e3603-x2-713</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-712">
   <w.rf>
    <LM>w#w-d1e3603-x2-712</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-711">
   <w.rf>
    <LM>w#w-d1e3603-x2-711</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-710">
   <w.rf>
    <LM>w#w-d1e3603-x2-710</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-709">
   <w.rf>
    <LM>w#w-d1e3603-x2-709</LM>
   </w.rf>
   <form>připravily</form>
   <lemma>připravit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m038-d1e3603-x2-707">
   <w.rf>
    <LM>w#w-d1e3603-x2-707</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-708">
  <m id="m038-d1e3603-x2-706">
   <w.rf>
    <LM>w#w-d1e3603-x2-706</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-705">
   <w.rf>
    <LM>w#w-d1e3603-x2-705</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-704">
   <w.rf>
    <LM>w#w-d1e3603-x2-704</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-703">
   <w.rf>
    <LM>w#w-d1e3603-x2-703</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-702">
   <w.rf>
    <LM>w#w-d1e3603-x2-702</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-701">
   <w.rf>
    <LM>w#w-d1e3603-x2-701</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-699">
   <w.rf>
    <LM>w#w-d1e3603-x2-699</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-700">
  <m id="m038-d1e3603-x2-698">
   <w.rf>
    <LM>w#w-d1e3603-x2-698</LM>
   </w.rf>
   <form>Upeklo</form>
   <lemma>upéci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-d1e3603-x2-697">
   <w.rf>
    <LM>w#w-d1e3603-x2-697</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-696">
   <w.rf>
    <LM>w#w-d1e3603-x2-696</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-695">
   <w.rf>
    <LM>w#w-d1e3603-x2-695</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m038-d1e3603-x2-694">
   <w.rf>
    <LM>w#w-d1e3603-x2-694</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-693">
   <w.rf>
    <LM>w#w-d1e3603-x2-693</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-692">
   <w.rf>
    <LM>w#w-d1e3603-x2-692</LM>
   </w.rf>
   <form>koláče</form>
   <lemma>koláč</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-691">
   <w.rf>
    <LM>w#w-d1e3603-x2-691</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-690">
   <w.rf>
    <LM>w#w-d1e3603-x2-690</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m038-d1e3603-x2-689">
   <w.rf>
    <LM>w#w-d1e3603-x2-689</LM>
   </w.rf>
   <form>cukroví</form>
   <lemma>cukroví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-688">
   <w.rf>
    <LM>w#w-d1e3603-x2-688</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-687">
   <w.rf>
    <LM>w#w-d1e3603-x2-687</LM>
   </w.rf>
   <form>sekaná</form>
   <lemma>sekaná_^(pečeně_z_mletého_masa)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-684">
   <w.rf>
    <LM>w#w-d1e3603-x2-684</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-686">
  <m id="m038-d1e3603-x2-683">
   <w.rf>
    <LM>w#w-d1e3603-x2-683</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-682">
   <w.rf>
    <LM>w#w-d1e3603-x2-682</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-681">
   <w.rf>
    <LM>w#w-d1e3603-x2-681</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-680">
   <w.rf>
    <LM>w#w-d1e3603-x2-680</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-679">
   <w.rf>
    <LM>w#w-d1e3603-x2-679</LM>
   </w.rf>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-677">
   <w.rf>
    <LM>w#w-d1e3603-x2-677</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-678">
  <m id="m038-d1e3603-x2-676">
   <w.rf>
    <LM>w#w-d1e3603-x2-676</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-675">
   <w.rf>
    <LM>w#w-d1e3603-x2-675</LM>
   </w.rf>
   <form>ono</form>
   <lemma>on-1</lemma>
   <tag>PENS1--3-------</tag>
  </m>
  <m id="m038-d1e3603-x2-674">
   <w.rf>
    <LM>w#w-d1e3603-x2-674</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-673">
   <w.rf>
    <LM>w#w-d1e3603-x2-673</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1e3603-x2-672">
   <w.rf>
    <LM>w#w-d1e3603-x2-672</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1e3603-x2-671">
   <w.rf>
    <LM>w#w-d1e3603-x2-671</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m038-d1e3603-x2-670">
   <w.rf>
    <LM>w#w-d1e3603-x2-670</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-669">
   <w.rf>
    <LM>w#w-d1e3603-x2-669</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-668">
   <w.rf>
    <LM>w#w-d1e3603-x2-668</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-667">
   <w.rf>
    <LM>w#w-d1e3603-x2-667</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1e3603-x2-666">
   <w.rf>
    <LM>w#w-d1e3603-x2-666</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-665">
   <w.rf>
    <LM>w#w-d1e3603-x2-665</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1e3603-x2-663">
   <w.rf>
    <LM>w#w-d1e3603-x2-663</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m038-d1e3603-x2-662">
   <w.rf>
    <LM>w#w-d1e3603-x2-662</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3603-x2-664">
   <w.rf>
    <LM>w#w-d1e3603-x2-664</LM>
   </w.rf>
   <form>nepamatuje</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-678-734">
   <w.rf>
    <LM>w#w-678-734</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-494">
  <m id="m038-d1t3619-2">
   <w.rf>
    <LM>w#w-d1t3619-2</LM>
   </w.rf>
   <form>Alenka</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t3619-4">
   <w.rf>
    <LM>w#w-d1t3619-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3619-5">
   <w.rf>
    <LM>w#w-d1t3619-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3619-6">
   <w.rf>
    <LM>w#w-d1t3619-6</LM>
   </w.rf>
   <form>vdaná</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m038-d-id174376-punct">
   <w.rf>
    <LM>w#w-d-id174376-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3619-8">
   <w.rf>
    <LM>w#w-d1t3619-8</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3619-9">
   <w.rf>
    <LM>w#w-d1t3619-9</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m038-d1t3619-11">
   <w.rf>
    <LM>w#w-d1t3619-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3619-12">
   <w.rf>
    <LM>w#w-d1t3619-12</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m038-d1t3619-13">
   <w.rf>
    <LM>w#w-d1t3619-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3619-14">
   <w.rf>
    <LM>w#w-d1t3619-14</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m038-d1t3619-15">
   <w.rf>
    <LM>w#w-d1t3619-15</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d-id174503-punct">
   <w.rf>
    <LM>w#w-d-id174503-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3619-17">
   <w.rf>
    <LM>w#w-d1t3619-17</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3619-18">
   <w.rf>
    <LM>w#w-d1t3619-18</LM>
   </w.rf>
   <form>ono</form>
   <lemma>on-1</lemma>
   <tag>PENS1--3-------</tag>
  </m>
  <m id="m038-d1t3619-19">
   <w.rf>
    <LM>w#w-d1t3619-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3619-20">
   <w.rf>
    <LM>w#w-d1t3619-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3619-21">
   <w.rf>
    <LM>w#w-d1t3619-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t3619-22">
   <w.rf>
    <LM>w#w-d1t3619-22</LM>
   </w.rf>
   <form>hezkých</form>
   <lemma>hezký</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m038-d1t3619-23">
   <w.rf>
    <LM>w#w-d1t3619-23</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m038-d1t3619-24">
   <w.rf>
    <LM>w#w-d1t3619-24</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m038-d-m-d1e3603-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3603-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3635-x2">
  <m id="m038-d1t3638-1">
   <w.rf>
    <LM>w#w-d1t3638-1</LM>
   </w.rf>
   <form>Dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1t3638-2">
   <w.rf>
    <LM>w#w-d1t3638-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t3638-3">
   <w.rf>
    <LM>w#w-d1t3638-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3638-4">
   <w.rf>
    <LM>w#w-d1t3638-4</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m038-d1t3638-5">
   <w.rf>
    <LM>w#w-d1t3638-5</LM>
   </w.rf>
   <form>dort</form>
   <lemma>dort</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d-id174845-punct">
   <w.rf>
    <LM>w#w-d-id174845-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3639-x2">
  <m id="m038-d1t3642-1">
   <w.rf>
    <LM>w#w-d1t3642-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t3642-2">
   <w.rf>
    <LM>w#w-d1t3642-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e3639-x2-520">
   <w.rf>
    <LM>w#w-d1e3639-x2-520</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-521">
  <m id="m038-d1t3644-1">
   <w.rf>
    <LM>w#w-d1t3644-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m038-d1t3644-2">
   <w.rf>
    <LM>w#w-d1t3644-2</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m038-d1t3644-4">
   <w.rf>
    <LM>w#w-d1t3644-4</LM>
   </w.rf>
   <form>veliký</form>
   <lemma>veliký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m038-d1t3644-9">
   <w.rf>
    <LM>w#w-d1t3644-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3644-10">
   <w.rf>
    <LM>w#w-d1t3644-10</LM>
   </w.rf>
   <form>objednal</form>
   <lemma>objednat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d-id175150-punct">
   <w.rf>
    <LM>w#w-d-id175150-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3646-1">
   <w.rf>
    <LM>w#w-d1t3646-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3646-2">
   <w.rf>
    <LM>w#w-d1t3646-2</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m038-d1t3646-3">
   <w.rf>
    <LM>w#w-d1t3646-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m038-d1t3646-4">
   <w.rf>
    <LM>w#w-d1t3646-4</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAIP4----2A----</tag>
  </m>
  <m id="m038-d1t3646-5">
   <w.rf>
    <LM>w#w-d1t3646-5</LM>
   </w.rf>
   <form>dorty</form>
   <lemma>dort</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d1t3646-6">
   <w.rf>
    <LM>w#w-d1t3646-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t3646-8">
   <w.rf>
    <LM>w#w-d1t3646-8</LM>
   </w.rf>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d1e3639-x2-517">
   <w.rf>
    <LM>w#w-d1e3639-x2-517</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-519">
  <m id="m038-d1t3648-3">
   <w.rf>
    <LM>w#w-d1t3648-3</LM>
   </w.rf>
   <form>Koláče</form>
   <lemma>koláč</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m038-d1t3648-4">
   <w.rf>
    <LM>w#w-d1t3648-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3648-5">
   <w.rf>
    <LM>w#w-d1t3648-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m038-d-id175402-punct">
   <w.rf>
    <LM>w#w-d-id175402-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3648-8">
   <w.rf>
    <LM>w#w-d1t3648-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t3648-9">
   <w.rf>
    <LM>w#w-d1t3648-9</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3648-10">
   <w.rf>
    <LM>w#w-d1t3648-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3648-11">
   <w.rf>
    <LM>w#w-d1t3648-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3648-13">
   <w.rf>
    <LM>w#w-d1t3648-13</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3648-14">
   <w.rf>
    <LM>w#w-d1t3648-14</LM>
   </w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id175520-punct">
   <w.rf>
    <LM>w#w-d-id175520-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3648-16">
   <w.rf>
    <LM>w#w-d1t3648-16</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3648-17">
   <w.rf>
    <LM>w#w-d1t3648-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3648-18">
   <w.rf>
    <LM>w#w-d1t3648-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3648-19">
   <w.rf>
    <LM>w#w-d1t3648-19</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m038-d1t3648-20">
   <w.rf>
    <LM>w#w-d1t3648-20</LM>
   </w.rf>
   <form>stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-519-535">
   <w.rf>
    <LM>w#w-519-535</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-537">
  <m id="m038-d1t3648-24">
   <w.rf>
    <LM>w#w-d1t3648-24</LM>
   </w.rf>
   <form>Alenka</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t3648-26">
   <w.rf>
    <LM>w#w-d1t3648-26</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t3648-27">
   <w.rf>
    <LM>w#w-d1t3648-27</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t3648-28">
   <w.rf>
    <LM>w#w-d1t3648-28</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-id175710-punct">
   <w.rf>
    <LM>w#w-d-id175710-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t3648-30">
   <w.rf>
    <LM>w#w-d1t3648-30</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t3648-31">
   <w.rf>
    <LM>w#w-d1t3648-31</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t3648-32">
   <w.rf>
    <LM>w#w-d1t3648-32</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3648-33">
   <w.rf>
    <LM>w#w-d1t3648-33</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t3648-34">
   <w.rf>
    <LM>w#w-d1t3648-34</LM>
   </w.rf>
   <form>udělalo</form>
   <lemma>udělat</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m038-519-534">
   <w.rf>
    <LM>w#w-519-534</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e3651-x2">
  <m id="m038-d1t3656-1">
   <w.rf>
    <LM>w#w-d1t3656-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t3656-2">
   <w.rf>
    <LM>w#w-d1t3656-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t3656-3">
   <w.rf>
    <LM>w#w-d1t3656-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d-m-d1e3651-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3651-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
