<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_035.11.w.gz" />
  </references>
 </head>
 <s id="m035-431">
  <m id="m035-d1t3262-2">
   <w.rf>
    <LM>w#w-d1t3262-2</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3262-3">
   <w.rf>
    <LM>w#w-d1t3262-3</LM>
   </w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m035-d1t3262-4">
   <w.rf>
    <LM>w#w-d1t3262-4</LM>
   </w.rf>
   <form>cenu</form>
   <lemma>cena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d-id172137-punct">
   <w.rf>
    <LM>w#w-d-id172137-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3258-12">
   <w.rf>
    <LM>w#w-d1t3258-12</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m035-d1t3258-13">
   <w.rf>
    <LM>w#w-d1t3258-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3258-14">
   <w.rf>
    <LM>w#w-d1t3258-14</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3260-1">
   <w.rf>
    <LM>w#w-d1t3260-1</LM>
   </w.rf>
   <form>poklusem</form>
   <lemma>poklus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3253-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3253-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3263-x2">
  <m id="m035-d1t3278-1">
   <w.rf>
    <LM>w#w-d1t3278-1</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1e3263-x2-446">
   <w.rf>
    <LM>w#w-d1e3263-x2-446</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m035-d1t3278-2">
   <w.rf>
    <LM>w#w-d1t3278-2</LM>
   </w.rf>
   <form>říkají</form>
   <lemma>říkat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1e3263-x2-447">
   <w.rf>
    <LM>w#w-d1e3263-x2-447</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e3263-x2-448">
   <w.rf>
    <LM>w#w-d1e3263-x2-448</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3278-7">
   <w.rf>
    <LM>w#w-d1t3278-7</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m035-d1t3278-8">
   <w.rf>
    <LM>w#w-d1t3278-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3278-9">
   <w.rf>
    <LM>w#w-d1t3278-9</LM>
   </w.rf>
   <form>upíchneš</form>
   <lemma>upíchnout</lemma>
   <tag>VB-S---2P-AAP--</tag>
  </m>
  <m id="m035-d1t3278-10">
   <w.rf>
    <LM>w#w-d1t3278-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m035-d1t3278-11">
   <w.rf>
    <LM>w#w-d1t3278-11</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m035-d1t3278-12">
   <w.rf>
    <LM>w#w-d1t3278-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3278-13">
   <w.rf>
    <LM>w#w-d1t3278-13</LM>
   </w.rf>
   <form>lehneš</form>
   <lemma>lehnout</lemma>
   <tag>VB-S---2P-AAP--</tag>
  </m>
  <m id="m035-d1t3278-14">
   <w.rf>
    <LM>w#w-d1t3278-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t3278-15">
   <w.rf>
    <LM>w#w-d1t3278-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1e3263-x2-449">
   <w.rf>
    <LM>w#w-d1e3263-x2-449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e3263-x2-450">
   <w.rf>
    <LM>w#w-d1e3263-x2-450</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-451">
  <m id="m035-d1t3280-2">
   <w.rf>
    <LM>w#w-d1t3280-2</LM>
   </w.rf>
   <form>Povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-451-452">
   <w.rf>
    <LM>w#w-451-452</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-451-453">
   <w.rf>
    <LM>w#w-451-453</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3280-4">
   <w.rf>
    <LM>w#w-d1t3280-4</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m035-d1t3280-3">
   <w.rf>
    <LM>w#w-d1t3280-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3280-5">
   <w.rf>
    <LM>w#w-d1t3280-5</LM>
   </w.rf>
   <form>stačí</form>
   <lemma>stačit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-451-454">
   <w.rf>
    <LM>w#w-451-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-451-455">
   <w.rf>
    <LM>w#w-451-455</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-456">
  <m id="m035-d1t3280-10">
   <w.rf>
    <LM>w#w-d1t3280-10</LM>
   </w.rf>
   <form>Jdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3280-9">
   <w.rf>
    <LM>w#w-d1t3280-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3280-11">
   <w.rf>
    <LM>w#w-d1t3280-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t3280-12">
   <w.rf>
    <LM>w#w-d1t3280-12</LM>
   </w.rf>
   <form>mořem</form>
   <lemma>moře</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m035-456-457">
   <w.rf>
    <LM>w#w-456-457</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3282-4">
   <w.rf>
    <LM>w#w-d1t3282-4</LM>
   </w.rf>
   <form>nejdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-456-458">
   <w.rf>
    <LM>w#w-456-458</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3282-5">
   <w.rf>
    <LM>w#w-d1t3282-5</LM>
   </w.rf>
   <form>lítat</form>
   <lemma>lítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-456-459">
   <w.rf>
    <LM>w#w-456-459</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3282-6">
   <w.rf>
    <LM>w#w-d1t3282-6</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m035-d1t3282-7">
   <w.rf>
    <LM>w#w-d1t3282-7</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3282-8">
   <w.rf>
    <LM>w#w-d1t3282-8</LM>
   </w.rf>
   <form>tamhle</form>
   <lemma>tamhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3282-9">
   <w.rf>
    <LM>w#w-d1t3282-9</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m035-456-460">
   <w.rf>
    <LM>w#w-456-460</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3282-11">
   <w.rf>
    <LM>w#w-d1t3282-11</LM>
   </w.rf>
   <form>tamhle</form>
   <lemma>tamhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3282-12">
   <w.rf>
    <LM>w#w-d1t3282-12</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m035-456-461">
   <w.rf>
    <LM>w#w-456-461</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-462">
  <m id="m035-462-463">
   <w.rf>
    <LM>w#w-462-463</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3286-2">
   <w.rf>
    <LM>w#w-d1t3286-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-462-464">
   <w.rf>
    <LM>w#w-462-464</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m035-d1t3286-3">
   <w.rf>
    <LM>w#w-d1t3286-3</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m035-462-465">
   <w.rf>
    <LM>w#w-462-465</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3286-4">
   <w.rf>
    <LM>w#w-d1t3286-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3286-6">
   <w.rf>
    <LM>w#w-d1t3286-6</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d-id173122-punct">
   <w.rf>
    <LM>w#w-d-id173122-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3286-8">
   <w.rf>
    <LM>w#w-d1t3286-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3289-1">
   <w.rf>
    <LM>w#w-d1t3289-1</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3289-6">
   <w.rf>
    <LM>w#w-d1t3289-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3289-8">
   <w.rf>
    <LM>w#w-d1t3289-8</LM>
   </w.rf>
   <form>letovisek</form>
   <lemma>letovisko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-d1t3289-9">
   <w.rf>
    <LM>w#w-d1t3289-9</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m035-462-466">
   <w.rf>
    <LM>w#w-462-466</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m035-d1t3289-11">
   <w.rf>
    <LM>w#w-d1t3289-11</LM>
   </w.rf>
   <form>vzácnosti</form>
   <lemma>vzácnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m035-462-467">
   <w.rf>
    <LM>w#w-462-467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-468">
  <m id="m035-d1t3291-3">
   <w.rf>
    <LM>w#w-d1t3291-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3291-4">
   <w.rf>
    <LM>w#w-d1t3291-4</LM>
   </w.rf>
   <form>krámech</form>
   <lemma>krám</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m035-d1t3291-8">
   <w.rf>
    <LM>w#w-d1t3291-8</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3291-7">
   <w.rf>
    <LM>w#w-d1t3291-7</LM>
   </w.rf>
   <form>zásadně</form>
   <lemma>zásadně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t3291-6">
   <w.rf>
    <LM>w#w-d1t3291-6</LM>
   </w.rf>
   <form>nechodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-468-469">
   <w.rf>
    <LM>w#w-468-469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-470">
  <m id="m035-d1t3291-10">
   <w.rf>
    <LM>w#w-d1t3291-10</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3291-12">
   <w.rf>
    <LM>w#w-d1t3291-12</LM>
   </w.rf>
   <form>manželce</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m035-d1t3291-11">
   <w.rf>
    <LM>w#w-d1t3291-11</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-470-479">
   <w.rf>
    <LM>w#w-470-479</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-470-480">
   <w.rf>
    <LM>w#w-470-480</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3291-14">
   <w.rf>
    <LM>w#w-d1t3291-14</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-470-481">
   <w.rf>
    <LM>w#w-470-481</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t3291-15">
   <w.rf>
    <LM>w#w-d1t3291-15</LM>
   </w.rf>
   <form>jdi</form>
   <lemma>jít</lemma>
   <tag>Vi-S---2--A-I--</tag>
  </m>
  <m id="m035-d1t3291-16">
   <w.rf>
    <LM>w#w-d1t3291-16</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3291-17">
   <w.rf>
    <LM>w#w-d1t3291-17</LM>
   </w.rf>
   <form>krámech</form>
   <lemma>krám</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m035-470-482">
   <w.rf>
    <LM>w#w-470-482</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-470-483">
   <w.rf>
    <LM>w#w-470-483</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3293-1">
   <w.rf>
    <LM>w#w-d1t3293-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m035-d1t3293-2">
   <w.rf>
    <LM>w#w-d1t3293-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3293-3">
   <w.rf>
    <LM>w#w-d1t3293-3</LM>
   </w.rf>
   <form>krámu</form>
   <lemma>krám</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d1t3293-4">
   <w.rf>
    <LM>w#w-d1t3293-4</LM>
   </w.rf>
   <form>nejdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-470-484">
   <w.rf>
    <LM>w#w-470-484</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-470-485">
   <w.rf>
    <LM>w#w-470-485</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-486">
  <m id="m035-d1t3293-9">
   <w.rf>
    <LM>w#w-d1t3293-9</LM>
   </w.rf>
   <form>Zaplať</form>
   <lemma>zaplatit</lemma>
   <tag>Vi-S---3--A-P-4</tag>
  </m>
  <m id="m035-d1t3293-10">
   <w.rf>
    <LM>w#w-d1t3293-10</LM>
   </w.rf>
   <form>Pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1t3293-11">
   <w.rf>
    <LM>w#w-d1t3293-11</LM>
   </w.rf>
   <form>Bůh</form>
   <lemma>bůh</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-486-487">
   <w.rf>
    <LM>w#w-486-487</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3293-5">
   <w.rf>
    <LM>w#w-d1t3293-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3293-6">
   <w.rf>
    <LM>w#w-d1t3293-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3293-8">
   <w.rf>
    <LM>w#w-d1t3293-8</LM>
   </w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3293-7">
   <w.rf>
    <LM>w#w-d1t3293-7</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-486-488">
   <w.rf>
    <LM>w#w-486-488</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-489">
  <m id="m035-d1t3295-1">
   <w.rf>
    <LM>w#w-d1t3295-1</LM>
   </w.rf>
   <form>Dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m035-489-490">
   <w.rf>
    <LM>w#w-489-490</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-489-491">
   <w.rf>
    <LM>w#w-489-491</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-489-492">
   <w.rf>
    <LM>w#w-489-492</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3295-6">
   <w.rf>
    <LM>w#w-d1t3295-6</LM>
   </w.rf>
   <form>Musíme</form>
   <lemma>muset</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3295-7">
   <w.rf>
    <LM>w#w-d1t3295-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m035-d1t3295-8">
   <w.rf>
    <LM>w#w-d1t3295-8</LM>
   </w.rf>
   <form>přinést</form>
   <lemma>přinést</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m035-d1t3295-9">
   <w.rf>
    <LM>w#w-d1t3295-9</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-489-495">
   <w.rf>
    <LM>w#w-489-495</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-489-494">
   <w.rf>
    <LM>w#w-489-494</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-497">
  <m id="m035-497-415">
   <w.rf>
    <LM>w#w-497-415</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-497-416">
   <w.rf>
    <LM>w#w-497-416</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-497-418">
   <w.rf>
    <LM>w#w-497-418</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-497-419">
   <w.rf>
    <LM>w#w-497-419</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3295-15">
   <w.rf>
    <LM>w#w-d1t3295-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-497-498">
   <w.rf>
    <LM>w#w-497-498</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3295-17">
   <w.rf>
    <LM>w#w-d1t3295-17</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-497-420">
   <w.rf>
    <LM>w#w-497-420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-497-421">
   <w.rf>
    <LM>w#w-497-421</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-422">
  <m id="m035-422-423">
   <w.rf>
    <LM>w#w-422-423</LM>
   </w.rf>
   <form>Teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-422-424">
   <w.rf>
    <LM>w#w-422-424</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-422-425">
   <w.rf>
    <LM>w#w-422-425</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-422-426">
   <w.rf>
    <LM>w#w-422-426</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3299-1">
   <w.rf>
    <LM>w#w-d1t3299-1</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3302-2">
   <w.rf>
    <LM>w#w-d1t3302-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3302-3">
   <w.rf>
    <LM>w#w-d1t3302-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3302-4">
   <w.rf>
    <LM>w#w-d1t3302-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3302-5">
   <w.rf>
    <LM>w#w-d1t3302-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m035-d-m-d1e3275-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3275-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3303-x3">
  <m id="m035-d1t3312-1">
   <w.rf>
    <LM>w#w-d1t3312-1</LM>
   </w.rf>
   <form>Žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1t3312-2">
   <w.rf>
    <LM>w#w-d1t3312-2</LM>
   </w.rf>
   <form>chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3312-3">
   <w.rf>
    <LM>w#w-d1t3312-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3312-4">
   <w.rf>
    <LM>w#w-d1t3312-4</LM>
   </w.rf>
   <form>krámech</form>
   <lemma>krám</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m035-d1t3312-5">
   <w.rf>
    <LM>w#w-d1t3312-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3312-6">
   <w.rf>
    <LM>w#w-d1t3312-6</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m035-d1t3312-7">
   <w.rf>
    <LM>w#w-d1t3312-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t3312-8">
   <w.rf>
    <LM>w#w-d1t3312-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3312-9">
   <w.rf>
    <LM>w#w-d1t3312-9</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m035-d-id174347-punct">
   <w.rf>
    <LM>w#w-d-id174347-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3313-x2">
  <m id="m035-d1t3316-9">
   <w.rf>
    <LM>w#w-d1t3316-9</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3316-10">
   <w.rf>
    <LM>w#w-d1t3316-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3316-11">
   <w.rf>
    <LM>w#w-d1t3316-11</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1e3313-x2-526">
   <w.rf>
    <LM>w#w-d1e3313-x2-526</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-527">
  <m id="m035-d1t3316-17">
   <w.rf>
    <LM>w#w-d1t3316-17</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-527-528">
   <w.rf>
    <LM>w#w-527-528</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3316-14">
   <w.rf>
    <LM>w#w-d1t3316-14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3316-15">
   <w.rf>
    <LM>w#w-d1t3316-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3316-13">
   <w.rf>
    <LM>w#w-d1t3316-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3316-16">
   <w.rf>
    <LM>w#w-d1t3316-16</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3316-18">
   <w.rf>
    <LM>w#w-d1t3316-18</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3316-20">
   <w.rf>
    <LM>w#w-d1t3316-20</LM>
   </w.rf>
   <form>Ruska</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m035-d-id174668-punct">
   <w.rf>
    <LM>w#w-d-id174668-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3316-29">
   <w.rf>
    <LM>w#w-d1t3316-29</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3316-25">
   <w.rf>
    <LM>w#w-d1t3316-25</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3316-26">
   <w.rf>
    <LM>w#w-d1t3316-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3316-24">
   <w.rf>
    <LM>w#w-d1t3316-24</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3316-27">
   <w.rf>
    <LM>w#w-d1t3316-27</LM>
   </w.rf>
   <form>třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m035-d-id174765-punct">
   <w.rf>
    <LM>w#w-d-id174765-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3318-2">
   <w.rf>
    <LM>w#w-d1t3318-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3318-3">
   <w.rf>
    <LM>w#w-d1t3318-3</LM>
   </w.rf>
   <form>kupovali</form>
   <lemma>kupovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3320-1">
   <w.rf>
    <LM>w#w-d1t3320-1</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-d1t3318-4">
   <w.rf>
    <LM>w#w-d1t3318-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3318-6">
   <w.rf>
    <LM>w#w-d1t3318-6</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-527-529">
   <w.rf>
    <LM>w#w-527-529</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3318-23">
   <w.rf>
    <LM>w#w-d1t3318-23</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3318-28">
   <w.rf>
    <LM>w#w-d1t3318-28</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3318-30">
   <w.rf>
    <LM>w#w-d1t3318-30</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3318-29">
   <w.rf>
    <LM>w#w-d1t3318-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3318-24">
   <w.rf>
    <LM>w#w-d1t3318-24</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3318-26">
   <w.rf>
    <LM>w#w-d1t3318-26</LM>
   </w.rf>
   <form>Ruska</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m035-d-id174887-punct">
   <w.rf>
    <LM>w#w-d-id174887-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3318-10">
   <w.rf>
    <LM>w#w-d1t3318-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3318-11">
   <w.rf>
    <LM>w#w-d1t3318-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3318-13">
   <w.rf>
    <LM>w#w-d1t3318-13</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m035-d1t3318-12">
   <w.rf>
    <LM>w#w-d1t3318-12</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-d-m-d1e3313-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3313-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3321-x2">
  <m id="m035-d1t3328-3">
   <w.rf>
    <LM>w#w-d1t3328-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m035-d1t3328-2">
   <w.rf>
    <LM>w#w-d1t3328-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3328-4">
   <w.rf>
    <LM>w#w-d1t3328-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3328-5">
   <w.rf>
    <LM>w#w-d1t3328-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m035-d1t3328-6">
   <w.rf>
    <LM>w#w-d1t3328-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d-id175350-punct">
   <w.rf>
    <LM>w#w-d-id175350-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3321-x3">
  <m id="m035-d1t3332-1">
   <w.rf>
    <LM>w#w-d1t3332-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m035-d1t3332-2">
   <w.rf>
    <LM>w#w-d1t3332-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3332-3">
   <w.rf>
    <LM>w#w-d1t3332-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3332-4">
   <w.rf>
    <LM>w#w-d1t3332-4</LM>
   </w.rf>
   <form>zač</form>
   <lemma>co-1</lemma>
   <tag>PQ--4--------z-</tag>
  </m>
  <m id="m035-d-id175445-punct">
   <w.rf>
    <LM>w#w-d-id175445-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3333-x2">
  <m id="m035-d1t3336-7">
   <w.rf>
    <LM>w#w-d1t3336-7</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3336-8">
   <w.rf>
    <LM>w#w-d1t3336-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m035-d1t3336-9">
   <w.rf>
    <LM>w#w-d1t3336-9</LM>
   </w.rf>
   <form>červené</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m035-d1t3336-10">
   <w.rf>
    <LM>w#w-d1t3336-10</LM>
   </w.rf>
   <form>kombinéze</form>
   <lemma>kombinéza</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t3338-2">
   <w.rf>
    <LM>w#w-d1t3338-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3338-3">
   <w.rf>
    <LM>w#w-d1t3338-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1e3333-x2-556">
   <w.rf>
    <LM>w#w-d1e3333-x2-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-557">
  <m id="m035-d1t3338-7">
   <w.rf>
    <LM>w#w-d1t3338-7</LM>
   </w.rf>
   <form>Podnikají</form>
   <lemma>podnikat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3338-9">
   <w.rf>
    <LM>w#w-d1t3338-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3338-11">
   <w.rf>
    <LM>w#w-d1t3338-11</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3338-14">
   <w.rf>
    <LM>w#w-d1t3338-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3338-16">
   <w.rf>
    <LM>w#w-d1t3338-16</LM>
   </w.rf>
   <form>Špičáku</form>
   <lemma>Špičák-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-d1t3338-13">
   <w.rf>
    <LM>w#w-d1t3338-13</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-557-558">
   <w.rf>
    <LM>w#w-557-558</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-559">
  <m id="m035-d1t3338-19">
   <w.rf>
    <LM>w#w-d1t3338-19</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3338-20">
   <w.rf>
    <LM>w#w-d1t3338-20</LM>
   </w.rf>
   <form>bernardýna</form>
   <lemma>bernardýn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-559-560">
   <w.rf>
    <LM>w#w-559-560</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-561">
  <m id="m035-d1t3338-27">
   <w.rf>
    <LM>w#w-d1t3338-27</LM>
   </w.rf>
   <form>Jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3338-26">
   <w.rf>
    <LM>w#w-d1t3338-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3338-29">
   <w.rf>
    <LM>w#w-d1t3338-29</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3338-30">
   <w.rf>
    <LM>w#w-d1t3338-30</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t3338-31">
   <w.rf>
    <LM>w#w-d1t3338-31</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m035-d-id176051-punct">
   <w.rf>
    <LM>w#w-d-id176051-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3338-38">
   <w.rf>
    <LM>w#w-d1t3338-38</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3338-37">
   <w.rf>
    <LM>w#w-d1t3338-37</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3338-36">
   <w.rf>
    <LM>w#w-d1t3338-36</LM>
   </w.rf>
   <form>pokaždé</form>
   <lemma>pokaždé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-561-562">
   <w.rf>
    <LM>w#w-561-562</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-563">
  <m id="m035-d1t3338-43">
   <w.rf>
    <LM>w#w-d1t3338-43</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-563-329">
   <w.rf>
    <LM>w#w-563-329</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3338-44">
   <w.rf>
    <LM>w#w-d1t3338-44</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m035-d1t3338-45">
   <w.rf>
    <LM>w#w-d1t3338-45</LM>
   </w.rf>
   <form>zachce</form>
   <lemma>zachtít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m035-563-564">
   <w.rf>
    <LM>w#w-563-564</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3338-46">
   <w.rf>
    <LM>w#w-d1t3338-46</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3338-48">
   <w.rf>
    <LM>w#w-d1t3338-48</LM>
   </w.rf>
   <form>jedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-563-565">
   <w.rf>
    <LM>w#w-563-565</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-566">
  <m id="m035-d1t3344-3">
   <w.rf>
    <LM>w#w-d1t3344-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3344-4">
   <w.rf>
    <LM>w#w-d1t3344-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3344-5">
   <w.rf>
    <LM>w#w-d1t3344-5</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-566-587">
   <w.rf>
    <LM>w#w-566-587</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3344-7">
   <w.rf>
    <LM>w#w-d1t3344-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3344-9">
   <w.rf>
    <LM>w#w-d1t3344-9</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-566-577">
   <w.rf>
    <LM>w#w-566-577</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-566-580">
   <w.rf>
    <LM>w#w-566-580</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m035-d1t3344-20">
   <w.rf>
    <LM>w#w-d1t3344-20</LM>
   </w.rf>
   <form>osmadvacetiletá</form>
   <lemma>osmadvacetiletý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m035-566-581">
   <w.rf>
    <LM>w#w-566-581</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3344-10">
   <w.rf>
    <LM>w#w-d1t3344-10</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3344-11">
   <w.rf>
    <LM>w#w-d1t3344-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3344-12">
   <w.rf>
    <LM>w#w-d1t3344-12</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-566-579">
   <w.rf>
    <LM>w#w-566-579</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-566-578">
   <w.rf>
    <LM>w#w-566-578</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3344-17">
   <w.rf>
    <LM>w#w-d1t3344-17</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3344-16">
   <w.rf>
    <LM>w#w-d1t3344-16</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3344-19">
   <w.rf>
    <LM>w#w-d1t3344-19</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-566-473">
   <w.rf>
    <LM>w#w-566-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-475">
  <m id="m035-566-585">
   <w.rf>
    <LM>w#w-566-585</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-566-586">
   <w.rf>
    <LM>w#w-566-586</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m035-d1t3347-7">
   <w.rf>
    <LM>w#w-d1t3347-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3347-8">
   <w.rf>
    <LM>w#w-d1t3347-8</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m035-566-582">
   <w.rf>
    <LM>w#w-566-582</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3333-x3">
  <m id="m035-d1t3349-2">
   <w.rf>
    <LM>w#w-d1t3349-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1e3333-x3-591">
   <w.rf>
    <LM>w#w-d1e3333-x3-591</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3349-5">
   <w.rf>
    <LM>w#w-d1t3349-5</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m035-d1t3349-6">
   <w.rf>
    <LM>w#w-d1t3349-6</LM>
   </w.rf>
   <form>skloněný</form>
   <lemma>skloněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1t3349-7">
   <w.rf>
    <LM>w#w-d1t3349-7</LM>
   </w.rf>
   <form>chlapec</form>
   <lemma>chlapec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1e3333-x3-592">
   <w.rf>
    <LM>w#w-d1e3333-x3-592</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3349-9">
   <w.rf>
    <LM>w#w-d1t3349-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3349-10">
   <w.rf>
    <LM>w#w-d1t3349-10</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3333-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3333-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-594">
  <m id="m035-d1t3355-4">
   <w.rf>
    <LM>w#w-d1t3355-4</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3355-3">
   <w.rf>
    <LM>w#w-d1t3355-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3355-2">
   <w.rf>
    <LM>w#w-d1t3355-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-594-595">
   <w.rf>
    <LM>w#w-594-595</LM>
   </w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t3355-6">
   <w.rf>
    <LM>w#w-d1t3355-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3350-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3350-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-596">
  <m id="m035-d1t3365-2">
   <w.rf>
    <LM>w#w-d1t3365-2</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3367-2">
   <w.rf>
    <LM>w#w-d1t3367-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-596-599">
   <w.rf>
    <LM>w#w-596-599</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3367-3">
   <w.rf>
    <LM>w#w-d1t3367-3</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3368-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3368-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3368-x3">
  <m id="m035-d1t3375-1">
   <w.rf>
    <LM>w#w-d1t3375-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3375-2">
   <w.rf>
    <LM>w#w-d1t3375-2</LM>
   </w.rf>
   <form>čem</form>
   <lemma>co-1</lemma>
   <tag>PQ--6----------</tag>
  </m>
  <m id="m035-d1t3375-3">
   <w.rf>
    <LM>w#w-d1t3375-3</LM>
   </w.rf>
   <form>podnikají</form>
   <lemma>podnikat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d-id177328-punct">
   <w.rf>
    <LM>w#w-d-id177328-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3376-x2">
  <m id="m035-d1e3376-x2-484">
   <w.rf>
    <LM>w#w-d1e3376-x2-484</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m035-d1t3381-2">
   <w.rf>
    <LM>w#w-d1t3381-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3381-3">
   <w.rf>
    <LM>w#w-d1t3381-3</LM>
   </w.rf>
   <form>firmu</form>
   <lemma>firma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d1t3385-5">
   <w.rf>
    <LM>w#w-d1t3385-5</LM>
   </w.rf>
   <form>Ermet</form>
   <lemma>Ermet-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m035-d1t3385-6">
   <w.rf>
    <LM>w#w-d1t3385-6</LM>
   </w.rf>
   <form>Bohemia</form>
   <lemma>Bohemia-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m035-d1t3381-4">
   <w.rf>
    <LM>w#w-d1t3381-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3381-5">
   <w.rf>
    <LM>w#w-d1t3381-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3381-7">
   <w.rf>
    <LM>w#w-d1t3381-7</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1e3376-x2-607">
   <w.rf>
    <LM>w#w-d1e3376-x2-607</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3381-9">
   <w.rf>
    <LM>w#w-d1t3381-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3381-10">
   <w.rf>
    <LM>w#w-d1t3381-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3383-1">
   <w.rf>
    <LM>w#w-d1t3383-1</LM>
   </w.rf>
   <form>konečná</form>
   <lemma>konečná</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1t3383-2">
   <w.rf>
    <LM>w#w-d1t3383-2</LM>
   </w.rf>
   <form>jedničky</form>
   <lemma>jednička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m035-d1e3376-x2-335">
   <w.rf>
    <LM>w#w-d1e3376-x2-335</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3394-1">
   <w.rf>
    <LM>w#w-d1t3394-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3394-2">
   <w.rf>
    <LM>w#w-d1t3394-2</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3394-3">
   <w.rf>
    <LM>w#w-d1t3394-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3394-4">
   <w.rf>
    <LM>w#w-d1t3394-4</LM>
   </w.rf>
   <form>formy</form>
   <lemma>forma</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d1t3394-5">
   <w.rf>
    <LM>w#w-d1t3394-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3394-6">
   <w.rf>
    <LM>w#w-d1t3394-6</LM>
   </w.rf>
   <form>umělé</form>
   <lemma>umělý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m035-d1t3394-7">
   <w.rf>
    <LM>w#w-d1t3394-7</LM>
   </w.rf>
   <form>hmoty</form>
   <lemma>hmota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3389-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3389-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3399-x2">
  <m id="m035-d1t3402-5">
   <w.rf>
    <LM>w#w-d1t3402-5</LM>
   </w.rf>
   <form>Osamostatnil</form>
   <lemma>osamostatnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1t3402-4">
   <w.rf>
    <LM>w#w-d1t3402-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1e3399-x2-630">
   <w.rf>
    <LM>w#w-d1e3399-x2-630</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3404-5">
   <w.rf>
    <LM>w#w-d1t3404-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3404-6">
   <w.rf>
    <LM>w#w-d1t3404-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t3404-7">
   <w.rf>
    <LM>w#w-d1t3404-7</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3404-8">
   <w.rf>
    <LM>w#w-d1t3404-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t3404-10">
   <w.rf>
    <LM>w#w-d1t3404-10</LM>
   </w.rf>
   <form>Němcem</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m035-d1t3404-13">
   <w.rf>
    <LM>w#w-d1t3404-13</LM>
   </w.rf>
   <form>napůl</form>
   <lemma>napůl</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-id178005-punct">
   <w.rf>
    <LM>w#w-d-id178005-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e3399-x2-631">
   <w.rf>
    <LM>w#w-d1e3399-x2-631</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3404-19">
   <w.rf>
    <LM>w#w-d1t3404-19</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-d1t3404-20">
   <w.rf>
    <LM>w#w-d1t3404-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t3404-3">
   <w.rf>
    <LM>w#w-d1t3404-3</LM>
   </w.rf>
   <form>prodal</form>
   <lemma>prodat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1e3399-x2-343">
   <w.rf>
    <LM>w#w-d1e3399-x2-343</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3404-18">
   <w.rf>
    <LM>w#w-d1t3404-18</LM>
   </w.rf>
   <form>nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1t3404-16">
   <w.rf>
    <LM>w#w-d1t3404-16</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-d1t3404-17">
   <w.rf>
    <LM>w#w-d1t3404-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1e3399-x2-632">
   <w.rf>
    <LM>w#w-d1e3399-x2-632</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-633">
  <m id="m035-d1t3406-5">
   <w.rf>
    <LM>w#w-d1t3406-5</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3406-8">
   <w.rf>
    <LM>w#w-d1t3406-8</LM>
   </w.rf>
   <form>postavený</form>
   <lemma>postavený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m035-d1t3406-6">
   <w.rf>
    <LM>w#w-d1t3406-6</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t3408-1">
   <w.rf>
    <LM>w#w-d1t3408-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m035-d1t3408-3">
   <w.rf>
    <LM>w#w-d1t3408-3</LM>
   </w.rf>
   <form>Starém</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m035-d1t3408-4">
   <w.rf>
    <LM>w#w-d1t3408-4</LM>
   </w.rf>
   <form>Bolevci</form>
   <lemma>Bolevec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-633-634">
   <w.rf>
    <LM>w#w-633-634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-635">
  <m id="m035-d1t3408-7">
   <w.rf>
    <LM>w#w-d1t3408-7</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3408-8">
   <w.rf>
    <LM>w#w-d1t3408-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3408-9">
   <w.rf>
    <LM>w#w-d1t3408-9</LM>
   </w.rf>
   <form>dílny</form>
   <lemma>dílna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d1t3408-10">
   <w.rf>
    <LM>w#w-d1t3408-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3408-21">
   <w.rf>
    <LM>w#w-d1t3408-21</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m035-d1t3408-22">
   <w.rf>
    <LM>w#w-d1t3408-22</LM>
   </w.rf>
   <form>lisů</form>
   <lemma>lis</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m035-d1t3408-24">
   <w.rf>
    <LM>w#w-d1t3408-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3408-25">
   <w.rf>
    <LM>w#w-d1t3408-25</LM>
   </w.rf>
   <form>lisuje</form>
   <lemma>lisovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3408-26">
   <w.rf>
    <LM>w#w-d1t3408-26</LM>
   </w.rf>
   <form>umělé</form>
   <lemma>umělý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m035-d1t3408-27">
   <w.rf>
    <LM>w#w-d1t3408-27</LM>
   </w.rf>
   <form>hmoty</form>
   <lemma>hmota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-635-639">
   <w.rf>
    <LM>w#w-635-639</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-638">
  <m id="m035-d1t3410-3">
   <w.rf>
    <LM>w#w-d1t3410-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3410-4">
   <w.rf>
    <LM>w#w-d1t3410-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t3410-5">
   <w.rf>
    <LM>w#w-d1t3410-5</LM>
   </w.rf>
   <form>koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m035-d1t3410-6">
   <w.rf>
    <LM>w#w-d1t3410-6</LM>
   </w.rf>
   <form>tuhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m035-d1t3413-8">
   <w.rf>
    <LM>w#w-d1t3413-8</LM>
   </w.rf>
   <form>krásnou</form>
   <lemma>krásný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m035-d1t3413-9">
   <w.rf>
    <LM>w#w-d1t3413-9</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-638-662">
   <w.rf>
    <LM>w#w-638-662</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-661">
  <m id="m035-d1t3417-3">
   <w.rf>
    <LM>w#w-d1t3417-3</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3417-4">
   <w.rf>
    <LM>w#w-d1t3417-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3417-6">
   <w.rf>
    <LM>w#w-d1t3417-6</LM>
   </w.rf>
   <form>psíka</form>
   <lemma>psík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-661-667">
   <w.rf>
    <LM>w#w-661-667</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-668">
  <m id="m035-d1t3419-4">
   <w.rf>
    <LM>w#w-d1t3419-4</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3419-2">
   <w.rf>
    <LM>w#w-d1t3419-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m035-d1t3419-3">
   <w.rf>
    <LM>w#w-d1t3419-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3419-9">
   <w.rf>
    <LM>w#w-d1t3419-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3419-5">
   <w.rf>
    <LM>w#w-d1t3419-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3419-7">
   <w.rf>
    <LM>w#w-d1t3419-7</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-668-669">
   <w.rf>
    <LM>w#w-668-669</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3419-13">
   <w.rf>
    <LM>w#w-d1t3419-13</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m035-d1t3419-10">
   <w.rf>
    <LM>w#w-d1t3419-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t3419-11">
   <w.rf>
    <LM>w#w-d1t3419-11</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m035-668-348">
   <w.rf>
    <LM>w#w-668-348</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3419-17">
   <w.rf>
    <LM>w#w-d1t3419-17</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m035-d1t3419-19">
   <w.rf>
    <LM>w#w-d1t3419-19</LM>
   </w.rf>
   <form>boxerem</form>
   <lemma>boxer-1</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m035-668-349">
   <w.rf>
    <LM>w#w-668-349</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3419-12">
   <w.rf>
    <LM>w#w-d1t3419-12</LM>
   </w.rf>
   <form>chodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3419-14">
   <w.rf>
    <LM>w#w-d1t3419-14</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t3419-15">
   <w.rf>
    <LM>w#w-d1t3419-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3419-16">
   <w.rf>
    <LM>w#w-d1t3419-16</LM>
   </w.rf>
   <form>procházku</form>
   <lemma>procházka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-668-670">
   <w.rf>
    <LM>w#w-668-670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-671">
  <m id="m035-d1t3429-1">
   <w.rf>
    <LM>w#w-d1t3429-1</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3429-2">
   <w.rf>
    <LM>w#w-d1t3429-2</LM>
   </w.rf>
   <form>dvůr</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t3429-3">
   <w.rf>
    <LM>w#w-d1t3429-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3429-4">
   <w.rf>
    <LM>w#w-d1t3429-4</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d-id179587-punct">
   <w.rf>
    <LM>w#w-d-id179587-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3429-6">
   <w.rf>
    <LM>w#w-d1t3429-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3429-7">
   <w.rf>
    <LM>w#w-d1t3429-7</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3429-8">
   <w.rf>
    <LM>w#w-d1t3429-8</LM>
   </w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-m-d1e3424-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3424-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3436-x2">
  <m id="m035-d1t3439-3">
   <w.rf>
    <LM>w#w-d1t3439-3</LM>
   </w.rf>
   <form>Nejšťastnější</form>
   <lemma>šťastný</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m035-d1t3439-4">
   <w.rf>
    <LM>w#w-d1t3439-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3439-1">
   <w.rf>
    <LM>w#w-d1t3439-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3439-5">
   <w.rf>
    <LM>w#w-d1t3439-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m035-d1t3439-6">
   <w.rf>
    <LM>w#w-d1t3439-6</LM>
   </w.rf>
   <form>sněhu</form>
   <lemma>sníh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-d1e3436-x2-683">
   <w.rf>
    <LM>w#w-d1e3436-x2-683</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-684">
  <m id="m035-d1t3439-12">
   <w.rf>
    <LM>w#w-d1t3439-12</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3439-11">
   <w.rf>
    <LM>w#w-d1t3439-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3439-13">
   <w.rf>
    <LM>w#w-d1t3439-13</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3439-14">
   <w.rf>
    <LM>w#w-d1t3439-14</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3436-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3436-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3442-x2">
  <m id="m035-d1t3447-3">
   <w.rf>
    <LM>w#w-d1t3447-3</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-d1t3447-6">
   <w.rf>
    <LM>w#w-d1t3447-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1e3442-x2-703">
   <w.rf>
    <LM>w#w-d1e3442-x2-703</LM>
   </w.rf>
   <form>zkrátka</form>
   <lemma>zkrátka-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3447-7">
   <w.rf>
    <LM>w#w-d1t3447-7</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3447-8">
   <w.rf>
    <LM>w#w-d1t3447-8</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S6--1-------</tag>
  </m>
  <m id="m035-d-m-d1e3442-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3442-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-704">
  <m id="m035-d1t3457-11">
   <w.rf>
    <LM>w#w-d1t3457-11</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3457-12">
   <w.rf>
    <LM>w#w-d1t3457-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3457-13">
   <w.rf>
    <LM>w#w-d1t3457-13</LM>
   </w.rf>
   <form>bydlel</form>
   <lemma>bydlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3457-16">
   <w.rf>
    <LM>w#w-d1t3457-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3457-19">
   <w.rf>
    <LM>w#w-d1t3457-19</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS6---------1</tag>
  </m>
  <m id="m035-d1t3457-17">
   <w.rf>
    <LM>w#w-d1t3457-17</LM>
   </w.rf>
   <form>chalupě</form>
   <lemma>chalupa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t3457-20">
   <w.rf>
    <LM>w#w-d1t3457-20</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3457-22">
   <w.rf>
    <LM>w#w-d1t3457-22</LM>
   </w.rf>
   <form>Tlučné</form>
   <lemma>Tlučná_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d-id180443-punct">
   <w.rf>
    <LM>w#w-d-id180443-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3457-27">
   <w.rf>
    <LM>w#w-d1t3457-27</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3457-26">
   <w.rf>
    <LM>w#w-d1t3457-26</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3457-30">
   <w.rf>
    <LM>w#w-d1t3457-30</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3457-28">
   <w.rf>
    <LM>w#w-d1t3457-28</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m035-d1t3457-29">
   <w.rf>
    <LM>w#w-d1t3457-29</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m035-704-24">
   <w.rf>
    <LM>w#w-704-24</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3457-32">
   <w.rf>
    <LM>w#w-d1t3457-32</LM>
   </w.rf>
   <form>vlčáka</form>
   <lemma>vlčák</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-d-id180556-punct">
   <w.rf>
    <LM>w#w-d-id180556-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3457-34">
   <w.rf>
    <LM>w#w-d1t3457-34</LM>
   </w.rf>
   <form>boxera</form>
   <lemma>boxer-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-704-25">
   <w.rf>
    <LM>w#w-704-25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-26">
  <m id="m035-d1t3461-1">
   <w.rf>
    <LM>w#w-d1t3461-1</LM>
   </w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3461-4">
   <w.rf>
    <LM>w#w-d1t3461-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3461-3">
   <w.rf>
    <LM>w#w-d1t3461-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3461-2">
   <w.rf>
    <LM>w#w-d1t3461-2</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3461-5">
   <w.rf>
    <LM>w#w-d1t3461-5</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m035-d1t3461-6">
   <w.rf>
    <LM>w#w-d1t3461-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-26-27">
   <w.rf>
    <LM>w#w-26-27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-28">
  <m id="m035-d1t3461-8">
   <w.rf>
    <LM>w#w-d1t3461-8</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m035-d1t3461-9">
   <w.rf>
    <LM>w#w-d1t3461-9</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1t3461-10">
   <w.rf>
    <LM>w#w-d1t3461-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3461-7">
   <w.rf>
    <LM>w#w-d1t3461-7</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3461-11">
   <w.rf>
    <LM>w#w-d1t3461-11</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m035-d1t3463-1">
   <w.rf>
    <LM>w#w-d1t3463-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3463-2">
   <w.rf>
    <LM>w#w-d1t3463-2</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m035-d1t3463-3">
   <w.rf>
    <LM>w#w-d1t3463-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-d1t3463-5">
   <w.rf>
    <LM>w#w-d1t3463-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3463-6">
   <w.rf>
    <LM>w#w-d1t3463-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3463-7">
   <w.rf>
    <LM>w#w-d1t3463-7</LM>
   </w.rf>
   <form>zemře</form>
   <lemma>zemřít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m035-28-29">
   <w.rf>
    <LM>w#w-28-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-30">
  <m id="m035-d1t3463-11">
   <w.rf>
    <LM>w#w-d1t3463-11</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-30-49">
   <w.rf>
    <LM>w#w-30-49</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3463-15">
   <w.rf>
    <LM>w#w-d1t3463-15</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3463-16">
   <w.rf>
    <LM>w#w-d1t3463-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t3463-17">
   <w.rf>
    <LM>w#w-d1t3463-17</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m035-d1t3463-20">
   <w.rf>
    <LM>w#w-d1t3463-20</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-30-50">
   <w.rf>
    <LM>w#w-30-50</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m035-d1t3463-24">
   <w.rf>
    <LM>w#w-d1t3463-24</LM>
   </w.rf>
   <form>Starém</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m035-d1t3463-25">
   <w.rf>
    <LM>w#w-d1t3463-25</LM>
   </w.rf>
   <form>Bolevci</form>
   <lemma>Bolevec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-d-id181123-punct">
   <w.rf>
    <LM>w#w-d-id181123-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3465-3">
   <w.rf>
    <LM>w#w-d1t3465-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m035-d1t3465-2">
   <w.rf>
    <LM>w#w-d1t3465-2</LM>
   </w.rf>
   <form>prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t3465-5">
   <w.rf>
    <LM>w#w-d1t3465-5</LM>
   </w.rf>
   <form>velkého</form>
   <lemma>velký</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m035-d1t3465-6">
   <w.rf>
    <LM>w#w-d1t3465-6</LM>
   </w.rf>
   <form>černého</form>
   <lemma>černý_;o</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m035-d1t3465-4">
   <w.rf>
    <LM>w#w-d1t3465-4</LM>
   </w.rf>
   <form>novofundláka</form>
   <lemma>novofundlák_,h</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-30-51">
   <w.rf>
    <LM>w#w-30-51</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-53">
  <m id="m035-d1t3468-3">
   <w.rf>
    <LM>w#w-d1t3468-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3468-4">
   <w.rf>
    <LM>w#w-d1t3468-4</LM>
   </w.rf>
   <form>dvanácti</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m035-d1t3468-5">
   <w.rf>
    <LM>w#w-d1t3468-5</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m035-d1t3468-2">
   <w.rf>
    <LM>w#w-d1t3468-2</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m035-d1t3468-6">
   <w.rf>
    <LM>w#w-d1t3468-6</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-53-54">
   <w.rf>
    <LM>w#w-53-54</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3470-2">
   <w.rf>
    <LM>w#w-d1t3470-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3470-3">
   <w.rf>
    <LM>w#w-d1t3470-3</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m035-d1t3470-5">
   <w.rf>
    <LM>w#w-d1t3470-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3470-6">
   <w.rf>
    <LM>w#w-d1t3470-6</LM>
   </w.rf>
   <form>velkého</form>
   <lemma>velký</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m035-d1t3470-7">
   <w.rf>
    <LM>w#w-d1t3470-7</LM>
   </w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-53-55">
   <w.rf>
    <LM>w#w-53-55</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3470-4">
   <w.rf>
    <LM>w#w-d1t3470-4</LM>
   </w.rf>
   <form>bernardýna</form>
   <lemma>bernardýn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-53-56">
   <w.rf>
    <LM>w#w-53-56</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-57">
  <m id="m035-d1t3470-11">
   <w.rf>
    <LM>w#w-d1t3470-11</LM>
   </w.rf>
   <form>Miluje</form>
   <lemma>milovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3470-12">
   <w.rf>
    <LM>w#w-d1t3470-12</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m035-d1t3470-13">
   <w.rf>
    <LM>w#w-d1t3470-13</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m035-57-65">
   <w.rf>
    <LM>w#w-57-65</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-57-66">
   <w.rf>
    <LM>w#w-57-66</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m035-57-63">
   <w.rf>
    <LM>w#w-57-63</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3472-1">
   <w.rf>
    <LM>w#w-d1t3472-1</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m035-d1t3472-2">
   <w.rf>
    <LM>w#w-d1t3472-2</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m035-d1t3470-16">
   <w.rf>
    <LM>w#w-d1t3470-16</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3470-17">
   <w.rf>
    <LM>w#w-d1t3470-17</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m035-d1t3470-18">
   <w.rf>
    <LM>w#w-d1t3470-18</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m035-57-64">
   <w.rf>
    <LM>w#w-57-64</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-61">
  <m id="m035-d1t3472-21">
   <w.rf>
    <LM>w#w-d1t3472-21</LM>
   </w.rf>
   <form>Vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m035-d1t3472-22">
   <w.rf>
    <LM>w#w-d1t3472-22</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t3472-23">
   <w.rf>
    <LM>w#w-d1t3472-23</LM>
   </w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-d1t3472-14">
   <w.rf>
    <LM>w#w-d1t3472-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3472-15">
   <w.rf>
    <LM>w#w-d1t3472-15</LM>
   </w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d1t3472-16">
   <w.rf>
    <LM>w#w-d1t3472-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3472-17">
   <w.rf>
    <LM>w#w-d1t3472-17</LM>
   </w.rf>
   <form>paneláku</form>
   <lemma>panelák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-d1t3472-19">
   <w.rf>
    <LM>w#w-d1t3472-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3472-20">
   <w.rf>
    <LM>w#w-d1t3472-20</LM>
   </w.rf>
   <form>katastrofa</form>
   <lemma>katastrofa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-61-67">
   <w.rf>
    <LM>w#w-61-67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3474-1">
   <w.rf>
    <LM>w#w-d1t3474-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t3474-2">
   <w.rf>
    <LM>w#w-d1t3474-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m035-d1t3474-5">
   <w.rf>
    <LM>w#w-d1t3474-5</LM>
   </w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m035-61-68">
   <w.rf>
    <LM>w#w-61-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-73">
  <m id="m035-d1t3474-9">
   <w.rf>
    <LM>w#w-d1t3474-9</LM>
   </w.rf>
   <form>Malé</form>
   <lemma>malý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m035-d1t3474-10">
   <w.rf>
    <LM>w#w-d1t3474-10</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m035-d1t3474-11">
   <w.rf>
    <LM>w#w-d1t3474-11</LM>
   </w.rf>
   <form>nesnáším</form>
   <lemma>snášet</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m035-d1t3474-12">
   <w.rf>
    <LM>w#w-d1t3474-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3474-13">
   <w.rf>
    <LM>w#w-d1t3474-13</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m035-d1t3474-14">
   <w.rf>
    <LM>w#w-d1t3474-14</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3474-15">
   <w.rf>
    <LM>w#w-d1t3474-15</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d-id182064-punct">
   <w.rf>
    <LM>w#w-d-id182064-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3474-17">
   <w.rf>
    <LM>w#w-d1t3474-17</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3474-18">
   <w.rf>
    <LM>w#w-d1t3474-18</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3474-19">
   <w.rf>
    <LM>w#w-d1t3474-19</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m035-d1t3474-20">
   <w.rf>
    <LM>w#w-d1t3474-20</LM>
   </w.rf>
   <form>psy</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3454-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3454-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3475-x3">
  <m id="m035-d1t3484-1">
   <w.rf>
    <LM>w#w-d1t3484-1</LM>
   </w.rf>
   <form>Velcí</form>
   <lemma>velký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d1t3484-2">
   <w.rf>
    <LM>w#w-d1t3484-2</LM>
   </w.rf>
   <form>psi</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-d1t3484-3">
   <w.rf>
    <LM>w#w-d1t3484-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3484-4">
   <w.rf>
    <LM>w#w-d1t3484-4</LM>
   </w.rf>
   <form>charakter</form>
   <lemma>charakter</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3475-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3475-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3485-x2">
  <m id="m035-d1e3485-x2-118">
   <w.rf>
    <LM>w#w-d1e3485-x2-118</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1e3485-x2-120">
   <w.rf>
    <LM>w#w-d1e3485-x2-120</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e3485-x2-119">
   <w.rf>
    <LM>w#w-d1e3485-x2-119</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3488-2">
   <w.rf>
    <LM>w#w-d1t3488-2</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t3488-5">
   <w.rf>
    <LM>w#w-d1t3488-5</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d1e3485-x2-121">
   <w.rf>
    <LM>w#w-d1e3485-x2-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-123">
  <m id="m035-d1t3488-9">
   <w.rf>
    <LM>w#w-d1t3488-9</LM>
   </w.rf>
   <form>Novofundláci</form>
   <lemma>novofundlák_,h</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-d1t3488-10">
   <w.rf>
    <LM>w#w-d1t3488-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3488-12">
   <w.rf>
    <LM>w#w-d1t3488-12</LM>
   </w.rf>
   <form>bernardýni</form>
   <lemma>bernardýn</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-d1t3488-14">
   <w.rf>
    <LM>w#w-d1t3488-14</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3488-19">
   <w.rf>
    <LM>w#w-d1t3488-19</LM>
   </w.rf>
   <form>takoví</form>
   <lemma>takový</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m035-d1t3488-20">
   <w.rf>
    <LM>w#w-d1t3488-20</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d-id182623-punct">
   <w.rf>
    <LM>w#w-d-id182623-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3488-22">
   <w.rf>
    <LM>w#w-d1t3488-22</LM>
   </w.rf>
   <form>vděční</form>
   <lemma>vděčný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d1t3488-23">
   <w.rf>
    <LM>w#w-d1t3488-23</LM>
   </w.rf>
   <form>psi</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-123-124">
   <w.rf>
    <LM>w#w-123-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-126">
  <m id="m035-d1t3488-31">
   <w.rf>
    <LM>w#w-d1t3488-31</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3488-32">
   <w.rf>
    <LM>w#w-d1t3488-32</LM>
   </w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m035-d1t3488-29">
   <w.rf>
    <LM>w#w-d1t3488-29</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m035-126-127">
   <w.rf>
    <LM>w#w-126-127</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3488-30">
   <w.rf>
    <LM>w#w-d1t3488-30</LM>
   </w.rf>
   <form>dýchal</form>
   <lemma>dýchat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-126-132">
   <w.rf>
    <LM>w#w-126-132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3490-1">
   <w.rf>
    <LM>w#w-d1t3490-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3490-2">
   <w.rf>
    <LM>w#w-d1t3490-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3492-2">
   <w.rf>
    <LM>w#w-d1t3492-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3490-4">
   <w.rf>
    <LM>w#w-d1t3490-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3492-3">
   <w.rf>
    <LM>w#w-d1t3492-3</LM>
   </w.rf>
   <form>nevycvičí</form>
   <lemma>vycvičit</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m035-126-134">
   <w.rf>
    <LM>w#w-126-134</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3492-4">
   <w.rf>
    <LM>w#w-d1t3492-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3492-6">
   <w.rf>
    <LM>w#w-d1t3492-6</LM>
   </w.rf>
   <form>vlčák</form>
   <lemma>vlčák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-126-133">
   <w.rf>
    <LM>w#w-126-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
