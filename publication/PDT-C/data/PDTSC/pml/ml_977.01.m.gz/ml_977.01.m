<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_977.01.w.gz" />
  </references>
 </head>
 <s id="m977-26797_07-1055">
  <m id="m977-id59484-6">
   <w.rf>
    <LM>w#w-id59484-6</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59484-7">
   <w.rf>
    <LM>w#w-id59484-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id59484-8">
   <w.rf>
    <LM>w#w-id59484-8</LM>
   </w.rf>
   <form>jdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59484-9">
   <w.rf>
    <LM>w#w-id59484-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id59484-10">
   <w.rf>
    <LM>w#w-id59484-10</LM>
   </w.rf>
   <form>rentgen</form>
   <lemma>rentgen</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-id59037-x11-789">
   <w.rf>
    <LM>w#w-id59037-x11-789</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59484-11">
   <w.rf>
    <LM>w#w-id59484-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59484-12">
   <w.rf>
    <LM>w#w-id59484-12</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m977-id59484-13">
   <w.rf>
    <LM>w#w-id59484-13</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-id59484-14">
   <w.rf>
    <LM>w#w-id59484-14</LM>
   </w.rf>
   <form>vylétne</form>
   <lemma>vylétnout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m977-id59037-x11-298">
   <w.rf>
    <LM>w#w-id59037-x11-298</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59037-x11-792">
   <w.rf>
    <LM>w#w-id59037-x11-792</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59484-15">
   <w.rf>
    <LM>w#w-id59484-15</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m977-id59484-16">
   <w.rf>
    <LM>w#w-id59484-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id59484-17">
   <w.rf>
    <LM>w#w-id59484-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59484-18">
   <w.rf>
    <LM>w#w-id59484-18</LM>
   </w.rf>
   <form>chlape</form>
   <lemma>chlap</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m977-id59484-19">
   <w.rf>
    <LM>w#w-id59484-19</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m977-id59037-x11-300">
   <w.rf>
    <LM>w#w-id59037-x11-300</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59037-x11-793">
   <w.rf>
    <LM>w#w-id59037-x11-793</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-301">
  <m id="m977-301-309">
   <w.rf>
    <LM>w#w-301-309</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59513-3">
   <w.rf>
    <LM>w#w-id59513-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59513-4">
   <w.rf>
    <LM>w#w-id59513-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59513-5">
   <w.rf>
    <LM>w#w-id59513-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-301-359">
   <w.rf>
    <LM>w#w-301-359</LM>
   </w.rf>
   <form>ozdravných</form>
   <lemma>ozdravný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m977-301-360">
   <w.rf>
    <LM>w#w-301-360</LM>
   </w.rf>
   <form>pobytech</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m977-301-311">
   <w.rf>
    <LM>w#w-301-311</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59513-8">
   <w.rf>
    <LM>w#w-id59513-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59513-9">
   <w.rf>
    <LM>w#w-id59513-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59513-10">
   <w.rf>
    <LM>w#w-id59513-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59513-11">
   <w.rf>
    <LM>w#w-id59513-11</LM>
   </w.rf>
   <form>vyléčil</form>
   <lemma>vyléčit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-301-353">
   <w.rf>
    <LM>w#w-301-353</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-346">
  <m id="m977-id59513-16">
   <w.rf>
    <LM>w#w-id59513-16</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m977-id59513-15">
   <w.rf>
    <LM>w#w-id59513-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m977-id59513-14">
   <w.rf>
    <LM>w#w-id59513-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59513-18">
   <w.rf>
    <LM>w#w-id59513-18</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59513-17">
   <w.rf>
    <LM>w#w-id59513-17</LM>
   </w.rf>
   <form>veselé</form>
   <lemma>veselý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m977-301-319">
   <w.rf>
    <LM>w#w-301-319</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59513-19">
   <w.rf>
    <LM>w#w-id59513-19</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m977-301-321">
   <w.rf>
    <LM>w#w-301-321</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-312">
  <m id="m977-id59542-1">
   <w.rf>
    <LM>w#w-id59542-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59542-2">
   <w.rf>
    <LM>w#w-id59542-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59542-3">
   <w.rf>
    <LM>w#w-id59542-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59542-4">
   <w.rf>
    <LM>w#w-id59542-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59542-5">
   <w.rf>
    <LM>w#w-id59542-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59542-6">
   <w.rf>
    <LM>w#w-id59542-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m977-id59542-8">
   <w.rf>
    <LM>w#w-id59542-8</LM>
   </w.rf>
   <form>rekonvalescenci</form>
   <lemma>rekonvalescence</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id59542-9">
   <w.rf>
    <LM>w#w-id59542-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m977-id59542-11">
   <w.rf>
    <LM>w#w-id59542-11</LM>
   </w.rf>
   <form>vojenských</form>
   <lemma>vojenský</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m977-id59542-12">
   <w.rf>
    <LM>w#w-id59542-12</LM>
   </w.rf>
   <form>srubech</form>
   <lemma>srub</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m977-id59542-13">
   <w.rf>
    <LM>w#w-id59542-13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m977-id59542-14">
   <w.rf>
    <LM>w#w-id59542-14</LM>
   </w.rf>
   <form>Vysokých</form>
   <lemma>vysoký</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m977-id59542-15">
   <w.rf>
    <LM>w#w-id59542-15</LM>
   </w.rf>
   <form>Tatrách</form>
   <lemma>Tatry_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m977-id59553-1">
   <w.rf>
    <LM>w#w-id59553-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59562-1">
   <w.rf>
    <LM>w#w-id59562-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59562-2">
   <w.rf>
    <LM>w#w-id59562-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59562-3">
   <w.rf>
    <LM>w#w-id59562-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59562-4">
   <w.rf>
    <LM>w#w-id59562-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59562-5">
   <w.rf>
    <LM>w#w-id59562-5</LM>
   </w.rf>
   <form>Popradu</form>
   <lemma>Poprad_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-id59571-2">
   <w.rf>
    <LM>w#w-id59571-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59571-3">
   <w.rf>
    <LM>w#w-id59571-3</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59571-4">
   <w.rf>
    <LM>w#w-id59571-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59571-5">
   <w.rf>
    <LM>w#w-id59571-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m977-id59571-6">
   <w.rf>
    <LM>w#w-id59571-6</LM>
   </w.rf>
   <form>raportu</form>
   <lemma>raport</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m977-312-343">
   <w.rf>
    <LM>w#w-312-343</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-332">
  <m id="m977-id59581-3">
   <w.rf>
    <LM>w#w-id59581-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59581-2">
   <w.rf>
    <LM>w#w-id59581-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59581-5">
   <w.rf>
    <LM>w#w-id59581-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m977-id59581-6">
   <w.rf>
    <LM>w#w-id59581-6</LM>
   </w.rf>
   <form>původní</form>
   <lemma>původní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m977-id59581-7">
   <w.rf>
    <LM>w#w-id59581-7</LM>
   </w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-id59581-8">
   <w.rf>
    <LM>w#w-id59581-8</LM>
   </w.rf>
   <form>praporu</form>
   <lemma>prapor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-d-id68333">
   <w.rf>
    <LM>w#w-d-id68333</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59581-10">
   <w.rf>
    <LM>w#w-id59581-10</LM>
   </w.rf>
   <form>plukovník</form>
   <lemma>plukovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-id59581-11">
   <w.rf>
    <LM>w#w-id59581-11</LM>
   </w.rf>
   <form>Fanta</form>
   <lemma>Fanta-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-332-366">
   <w.rf>
    <LM>w#w-332-366</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59591-1">
   <w.rf>
    <LM>w#w-id59591-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m977-id59591-2">
   <w.rf>
    <LM>w#w-id59591-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59591-3">
   <w.rf>
    <LM>w#w-id59591-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59591-4">
   <w.rf>
    <LM>w#w-id59591-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59591-5">
   <w.rf>
    <LM>w#w-id59591-5</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m977-id59591-7">
   <w.rf>
    <LM>w#w-id59591-7</LM>
   </w.rf>
   <form>raportu</form>
   <lemma>raport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-332-1060">
   <w.rf>
    <LM>w#w-332-1060</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1061">
  <m id="m977-id59591-9">
   <w.rf>
    <LM>w#w-id59591-9</LM>
   </w.rf>
   <form>Povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-332-370">
   <w.rf>
    <LM>w#w-332-370</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-332-369">
   <w.rf>
    <LM>w#w-332-369</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59591-10">
   <w.rf>
    <LM>w#w-id59591-10</LM>
   </w.rf>
   <form>Pane</form>
   <lemma>pan</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m977-id59591-11">
   <w.rf>
    <LM>w#w-id59591-11</LM>
   </w.rf>
   <form>plukovníku</form>
   <lemma>plukovník</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m977-332-372">
   <w.rf>
    <LM>w#w-332-372</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-332-373">
   <w.rf>
    <LM>w#w-332-373</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59615-2">
   <w.rf>
    <LM>w#w-id59615-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59615-3">
   <w.rf>
    <LM>w#w-id59615-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59615-4">
   <w.rf>
    <LM>w#w-id59615-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59615-7">
   <w.rf>
    <LM>w#w-id59615-7</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59625-1">
   <w.rf>
    <LM>w#w-id59625-1</LM>
   </w.rf>
   <form>poručík</form>
   <lemma>poručík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-332-375">
   <w.rf>
    <LM>w#w-332-375</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-332-377">
   <w.rf>
    <LM>w#w-332-377</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-332-380">
   <w.rf>
    <LM>w#w-332-380</LM>
   </w.rf>
   <form>poručík</form>
   <lemma>poručík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-332-381">
   <w.rf>
    <LM>w#w-332-381</LM>
   </w.rf>
   <form>Bedřich</form>
   <lemma>Bedřich_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-332-382">
   <w.rf>
    <LM>w#w-332-382</LM>
   </w.rf>
   <form>Seliger</form>
   <lemma>Seliger_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-332-383">
   <w.rf>
    <LM>w#w-332-383</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59643-1">
   <w.rf>
    <LM>w#w-id59643-1</LM>
   </w.rf>
   <form>hlásím</form>
   <lemma>hlásit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59643-2">
   <w.rf>
    <LM>w#w-id59643-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59643-3">
   <w.rf>
    <LM>w#w-id59643-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m977-id59643-4">
   <w.rf>
    <LM>w#w-id59643-4</LM>
   </w.rf>
   <form>návratu</form>
   <lemma>návrat</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m977-id59643-5">
   <w.rf>
    <LM>w#w-id59643-5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m977-id59643-6">
   <w.rf>
    <LM>w#w-id59643-6</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS3---------1</tag>
  </m>
  <m id="m977-id59643-7">
   <w.rf>
    <LM>w#w-id59643-7</LM>
   </w.rf>
   <form>jednotce</form>
   <lemma>jednotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m977-id59643-8">
   <w.rf>
    <LM>w#w-id59643-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id59643-9">
   <w.rf>
    <LM>w#w-id59643-9</LM>
   </w.rf>
   <form>frontu</form>
   <lemma>fronta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-d-id68861">
   <w.rf>
    <LM>w#w-d-id68861</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-332-376">
   <w.rf>
    <LM>w#w-332-376</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59037-x12">
  <m id="m977-id59667-6">
   <w.rf>
    <LM>w#w-id59667-6</LM>
   </w.rf>
   <form>Rozkročil</form>
   <lemma>rozkročit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59667-4">
   <w.rf>
    <LM>w#w-id59667-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59667-5">
   <w.rf>
    <LM>w#w-id59667-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59037-x12-839">
   <w.rf>
    <LM>w#w-id59037-x12-839</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59667-7">
   <w.rf>
    <LM>w#w-id59667-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59667-8">
   <w.rf>
    <LM>w#w-id59667-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id59667-9">
   <w.rf>
    <LM>w#w-id59667-9</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m977-id59667-10">
   <w.rf>
    <LM>w#w-id59667-10</LM>
   </w.rf>
   <form>umějí</form>
   <lemma>umět</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m977-id59037-x12-1065">
   <w.rf>
    <LM>w#w-id59037-x12-1065</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1066">
  <m id="m977-id59677-2">
   <w.rf>
    <LM>w#w-id59677-2</LM>
   </w.rf>
   <form>Povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-id59037-x12-840">
   <w.rf>
    <LM>w#w-id59037-x12-840</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59037-x12-841">
   <w.rf>
    <LM>w#w-id59037-x12-841</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59677-3">
   <w.rf>
    <LM>w#w-id59677-3</LM>
   </w.rf>
   <form>Poslyš</form>
   <lemma>slyšet</lemma>
   <tag>Vi-S---2--A-I-1</tag>
  </m>
  <m id="m977-d-id69099">
   <w.rf>
    <LM>w#w-d-id69099</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59677-4">
   <w.rf>
    <LM>w#w-id59677-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m977-id59677-5">
   <w.rf>
    <LM>w#w-id59677-5</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m977-id59677-6">
   <w.rf>
    <LM>w#w-id59677-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59677-7">
   <w.rf>
    <LM>w#w-id59677-7</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59677-8">
   <w.rf>
    <LM>w#w-id59677-8</LM>
   </w.rf>
   <form>zbláznil</form>
   <lemma>zbláznit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-d-id69172">
   <w.rf>
    <LM>w#w-d-id69172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59037-x13">
  <m id="m977-id59691-1">
   <w.rf>
    <LM>w#w-id59691-1</LM>
   </w.rf>
   <form>Nemáš</form>
   <lemma>mít</lemma>
   <tag>VB-S---2P-NAI--</tag>
  </m>
  <m id="m977-id59691-2">
   <w.rf>
    <LM>w#w-id59691-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m977-id59691-3">
   <w.rf>
    <LM>w#w-id59691-3</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id59691-4">
   <w.rf>
    <LM>w#w-id59691-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59691-6">
   <w.rf>
    <LM>w#w-id59691-6</LM>
   </w.rf>
   <form>Sokolova</form>
   <lemma>Sokolov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-d-id69285">
   <w.rf>
    <LM>w#w-d-id69285</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59037-x14">
  <m id="m977-id59697-1">
   <w.rf>
    <LM>w#w-id59697-1</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59697-2">
   <w.rf>
    <LM>w#w-id59697-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59697-3">
   <w.rf>
    <LM>w#w-id59697-3</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m977-id59697-4">
   <w.rf>
    <LM>w#w-id59697-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59697-5">
   <w.rf>
    <LM>w#w-id59697-5</LM>
   </w.rf>
   <form>jiní</form>
   <lemma>jiný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m977-d-id69373">
   <w.rf>
    <LM>w#w-d-id69373</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59697-9">
   <w.rf>
    <LM>w#w-id59697-9</LM>
   </w.rf>
   <form>potřebuju</form>
   <lemma>potřebovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59697-7">
   <w.rf>
    <LM>w#w-id59697-7</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m977-id59697-8">
   <w.rf>
    <LM>w#w-id59697-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59037-x14-913">
   <w.rf>
    <LM>w#w-id59037-x14-913</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59697-10">
   <w.rf>
    <LM>w#w-id59697-10</LM>
   </w.rf>
   <form>abys</form>
   <lemma>aby</lemma>
   <tag>J,-----------s-</tag>
  </m>
  <m id="m977-id59697-11">
   <w.rf>
    <LM>w#w-id59697-11</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m977-id59697-12">
   <w.rf>
    <LM>w#w-id59697-12</LM>
   </w.rf>
   <form>cvičil</form>
   <lemma>cvičit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59697-13">
   <w.rf>
    <LM>w#w-id59697-13</LM>
   </w.rf>
   <form>minometčíky</form>
   <lemma>minometčík</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m977-id59697-14">
   <w.rf>
    <LM>w#w-id59697-14</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id59697-15">
   <w.rf>
    <LM>w#w-id59697-15</LM>
   </w.rf>
   <form>čtvrtou</form>
   <lemma>čtvrtý</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m977-id59697-16">
   <w.rf>
    <LM>w#w-id59697-16</LM>
   </w.rf>
   <form>brigádu</form>
   <lemma>brigáda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-d-id69542">
   <w.rf>
    <LM>w#w-d-id69542</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59037-x14-916">
   <w.rf>
    <LM>w#w-id59037-x14-916</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59037-x15">
  <m id="m977-id59712-6">
   <w.rf>
    <LM>w#w-id59712-6</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59712-2">
   <w.rf>
    <LM>w#w-id59712-2</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59712-3">
   <w.rf>
    <LM>w#w-id59712-3</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m977-id59712-4">
   <w.rf>
    <LM>w#w-id59712-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m977-id59712-5">
   <w.rf>
    <LM>w#w-id59712-5</LM>
   </w.rf>
   <form>bojování</form>
   <lemma>bojování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m977-d-id69692">
   <w.rf>
    <LM>w#w-d-id69692</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59037-x16">
  <m id="m977-id59736-1">
   <w.rf>
    <LM>w#w-id59736-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59736-2">
   <w.rf>
    <LM>w#w-id59736-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59736-3">
   <w.rf>
    <LM>w#w-id59736-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59736-4">
   <w.rf>
    <LM>w#w-id59736-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59736-5">
   <w.rf>
    <LM>w#w-id59736-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id59736-6">
   <w.rf>
    <LM>w#w-id59736-6</LM>
   </w.rf>
   <form>frontu</form>
   <lemma>fronta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id59736-7">
   <w.rf>
    <LM>w#w-id59736-7</LM>
   </w.rf>
   <form>nedostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m977-id59037-x16-1164">
   <w.rf>
    <LM>w#w-id59037-x16-1164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1153">
  <m id="m977-id59745-5">
   <w.rf>
    <LM>w#w-id59745-5</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59745-6">
   <w.rf>
    <LM>w#w-id59745-6</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m977-id59745-7">
   <w.rf>
    <LM>w#w-id59745-7</LM>
   </w.rf>
   <form>rodného</form>
   <lemma>rodný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m977-id59745-8">
   <w.rf>
    <LM>w#w-id59745-8</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m977-id59745-2">
   <w.rf>
    <LM>w#w-id59745-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59745-3">
   <w.rf>
    <LM>w#w-id59745-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59745-1">
   <w.rf>
    <LM>w#w-id59745-1</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59745-10">
   <w.rf>
    <LM>w#w-id59745-10</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59745-11">
   <w.rf>
    <LM>w#w-id59745-11</LM>
   </w.rf>
   <form>sedmnáctého</form>
   <lemma>sedmnáctý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m977-id59745-12">
   <w.rf>
    <LM>w#w-id59745-12</LM>
   </w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-d-id70031">
   <w.rf>
    <LM>w#w-d-id70031</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59749-x1">
  <m id="m977-id59764-3">
   <w.rf>
    <LM>w#w-id59764-3</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59764-4">
   <w.rf>
    <LM>w#w-id59764-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m977-id59764-5">
   <w.rf>
    <LM>w#w-id59764-5</LM>
   </w.rf>
   <form>zažil</form>
   <lemma>zažít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59764-6">
   <w.rf>
    <LM>w#w-id59764-6</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-id59764-7">
   <w.rf>
    <LM>w#w-id59764-7</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m977-d-id70164">
   <w.rf>
    <LM>w#w-d-id70164</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59764-8">
   <w.rf>
    <LM>w#w-id59764-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m977-id59764-9">
   <w.rf>
    <LM>w#w-id59764-9</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-id59764-10">
   <w.rf>
    <LM>w#w-id59764-10</LM>
   </w.rf>
   <form>osmý</form>
   <lemma>osmý</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m977-id59764-11">
   <w.rf>
    <LM>w#w-id59764-11</LM>
   </w.rf>
   <form>květen</form>
   <lemma>květen</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-id59764-12">
   <w.rf>
    <LM>w#w-id59764-12</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m977-d-id70241">
   <w.rf>
    <LM>w#w-d-id70241</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59777-x1">
  <m id="m977-id59793-1">
   <w.rf>
    <LM>w#w-id59793-1</LM>
   </w.rf>
   <form>Osmý</form>
   <lemma>osmý</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m977-id59793-2">
   <w.rf>
    <LM>w#w-id59793-2</LM>
   </w.rf>
   <form>květen</form>
   <lemma>květen</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-id59793-3">
   <w.rf>
    <LM>w#w-id59793-3</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m977-id59793-5">
   <w.rf>
    <LM>w#w-id59793-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59793-6">
   <w.rf>
    <LM>w#w-id59793-6</LM>
   </w.rf>
   <form>zažil</form>
   <lemma>zažít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59802-1">
   <w.rf>
    <LM>w#w-id59802-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59802-2">
   <w.rf>
    <LM>w#w-id59802-2</LM>
   </w.rf>
   <form>radosti</form>
   <lemma>radost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id59812-1">
   <w.rf>
    <LM>w#w-id59812-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59812-2">
   <w.rf>
    <LM>w#w-id59812-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59812-3">
   <w.rf>
    <LM>w#w-id59812-3</LM>
   </w.rf>
   <form>obavách</form>
   <lemma>obava</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m977-d-id70488">
   <w.rf>
    <LM>w#w-d-id70488</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59777-x2">
  <m id="m977-id59826-1">
   <w.rf>
    <LM>w#w-id59826-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59826-2">
   <w.rf>
    <LM>w#w-id59826-2</LM>
   </w.rf>
   <form>radosti</form>
   <lemma>radost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id59777-x2-1312">
   <w.rf>
    <LM>w#w-id59777-x2-1312</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59826-3">
   <w.rf>
    <LM>w#w-id59826-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id59826-4">
   <w.rf>
    <LM>w#w-id59826-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-id59826-5">
   <w.rf>
    <LM>w#w-id59826-5</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m977-id59777-x2-1321">
   <w.rf>
    <LM>w#w-id59777-x2-1321</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59826-6">
   <w.rf>
    <LM>w#w-id59826-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id59826-7">
   <w.rf>
    <LM>w#w-id59826-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59826-8">
   <w.rf>
    <LM>w#w-id59826-8</LM>
   </w.rf>
   <form>obavách</form>
   <lemma>obava</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m977-id59777-x2-1310">
   <w.rf>
    <LM>w#w-id59777-x2-1310</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59777-x2-1308">
   <w.rf>
    <LM>w#w-id59777-x2-1308</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id59777-x2-1309">
   <w.rf>
    <LM>w#w-id59777-x2-1309</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59826-10">
   <w.rf>
    <LM>w#w-id59826-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59826-11">
   <w.rf>
    <LM>w#w-id59826-11</LM>
   </w.rf>
   <form>setkám</form>
   <lemma>setkat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m977-id59826-12">
   <w.rf>
    <LM>w#w-id59826-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m977-id59826-13">
   <w.rf>
    <LM>w#w-id59826-13</LM>
   </w.rf>
   <form>svojí</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS7----------</tag>
  </m>
  <m id="m977-id59826-14">
   <w.rf>
    <LM>w#w-id59826-14</LM>
   </w.rf>
   <form>rodinou</form>
   <lemma>rodina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m977-id59777-x2-1092">
   <w.rf>
    <LM>w#w-id59777-x2-1092</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1093">
  <m id="m977-id59850-5">
   <w.rf>
    <LM>w#w-id59850-5</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59850-2">
   <w.rf>
    <LM>w#w-id59850-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m977-id59850-3">
   <w.rf>
    <LM>w#w-id59850-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id59850-4">
   <w.rf>
    <LM>w#w-id59850-4</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m977-id59850-6">
   <w.rf>
    <LM>w#w-id59850-6</LM>
   </w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m977-id59860-1">
   <w.rf>
    <LM>w#w-id59860-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59860-2">
   <w.rf>
    <LM>w#w-id59860-2</LM>
   </w.rf>
   <form>osudu</form>
   <lemma>osud</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m977-id59860-3">
   <w.rf>
    <LM>w#w-id59860-3</LM>
   </w.rf>
   <form>Židů</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m977-id59865-1">
   <w.rf>
    <LM>w#w-id59865-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id59865-2">
   <w.rf>
    <LM>w#w-id59865-2</LM>
   </w.rf>
   <form>protektorátu</form>
   <lemma>protektorát</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m977-d-id70966">
   <w.rf>
    <LM>w#w-d-id70966</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59777-x5">
  <m id="m977-id59888-2">
   <w.rf>
    <LM>w#w-id59888-2</LM>
   </w.rf>
   <form>Než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id59888-3">
   <w.rf>
    <LM>w#w-id59888-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59888-4">
   <w.rf>
    <LM>w#w-id59888-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59888-6">
   <w.rf>
    <LM>w#w-id59888-6</LM>
   </w.rf>
   <form>Prostějova</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-id59888-7">
   <w.rf>
    <LM>w#w-id59888-7</LM>
   </w.rf>
   <form>jel</form>
   <lemma>jet-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-d-id71118">
   <w.rf>
    <LM>w#w-d-id71118</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59898-1">
   <w.rf>
    <LM>w#w-id59898-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59898-2">
   <w.rf>
    <LM>w#w-id59898-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id59898-3">
   <w.rf>
    <LM>w#w-id59898-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59898-4">
   <w.rf>
    <LM>w#w-id59898-4</LM>
   </w.rf>
   <form>setkal</form>
   <lemma>setkat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59907-1">
   <w.rf>
    <LM>w#w-id59907-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m977-id59907-2">
   <w.rf>
    <LM>w#w-id59907-2</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m977-id59907-3">
   <w.rf>
    <LM>w#w-id59907-3</LM>
   </w.rf>
   <form>naším</form>
   <lemma>náš</lemma>
   <tag>PSZS7-P1-------</tag>
  </m>
  <m id="m977-id59917-1">
   <w.rf>
    <LM>w#w-id59917-1</LM>
   </w.rf>
   <form>parašutistou</form>
   <lemma>parašutista</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m977-id59777-x5-1332">
   <w.rf>
    <LM>w#w-id59777-x5-1332</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59917-2">
   <w.rf>
    <LM>w#w-id59917-2</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m977-id59917-3">
   <w.rf>
    <LM>w#w-id59917-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59917-4">
   <w.rf>
    <LM>w#w-id59917-4</LM>
   </w.rf>
   <form>shozen</form>
   <lemma>shodit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m977-id59917-5">
   <w.rf>
    <LM>w#w-id59917-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id59917-6">
   <w.rf>
    <LM>w#w-id59917-6</LM>
   </w.rf>
   <form>diverzant</form>
   <lemma>diverzant</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-id59926-1">
   <w.rf>
    <LM>w#w-id59926-1</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id59926-2">
   <w.rf>
    <LM>w#w-id59926-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59926-3">
   <w.rf>
    <LM>w#w-id59926-3</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m977-id59926-4">
   <w.rf>
    <LM>w#w-id59926-4</LM>
   </w.rf>
   <form>Prostějova</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-id59777-x5-1101">
   <w.rf>
    <LM>w#w-id59777-x5-1101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1102">
  <m id="m977-id59945-4">
   <w.rf>
    <LM>w#w-id59945-4</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id59945-3">
   <w.rf>
    <LM>w#w-id59945-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m977-id59777-x5-1334">
   <w.rf>
    <LM>w#w-id59777-x5-1334</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59777-x5-1335">
   <w.rf>
    <LM>w#w-id59777-x5-1335</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59945-6">
   <w.rf>
    <LM>w#w-id59945-6</LM>
   </w.rf>
   <form>Buď</form>
   <lemma>být</lemma>
   <tag>Vi-S---2--A-I--</tag>
  </m>
  <m id="m977-id59945-7">
   <w.rf>
    <LM>w#w-id59945-7</LM>
   </w.rf>
   <form>silný</form>
   <lemma>silný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m977-d-id71570">
   <w.rf>
    <LM>w#w-d-id71570</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59777-x6">
  <m id="m977-id59960-5">
   <w.rf>
    <LM>w#w-id59960-5</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id59960-6">
   <w.rf>
    <LM>w#w-id59960-6</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m977-id59960-7">
   <w.rf>
    <LM>w#w-id59960-7</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m977-id59960-2">
   <w.rf>
    <LM>w#w-id59960-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id59960-3">
   <w.rf>
    <LM>w#w-id59960-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59960-1">
   <w.rf>
    <LM>w#w-id59960-1</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m977-id59960-4">
   <w.rf>
    <LM>w#w-id59960-4</LM>
   </w.rf>
   <form>nevrací</form>
   <lemma>vracet</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m977-d-id71579">
   <w.rf>
    <LM>w#w-d-id71579</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id59777-x6-1364">
   <w.rf>
    <LM>w#w-id59777-x6-1364</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59972-x1">
  <m id="m977-id59987-1">
   <w.rf>
    <LM>w#w-id59987-1</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m977-id59987-2">
   <w.rf>
    <LM>w#w-id59987-2</LM>
   </w.rf>
   <form>znal</form>
   <lemma>znát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id59987-4">
   <w.rf>
    <LM>w#w-id59987-4</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSFS4-P2-------</tag>
  </m>
  <m id="m977-id59972-x1-1378">
   <w.rf>
    <LM>w#w-id59972-x1-1378</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-d-id71762">
   <w.rf>
    <LM>w#w-d-id71762</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id59999-x1">
  <m id="m977-id60014-3">
   <w.rf>
    <LM>w#w-id60014-3</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id59999-x1-1450">
   <w.rf>
    <LM>w#w-id59999-x1-1450</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60014-5">
   <w.rf>
    <LM>w#w-id60014-5</LM>
   </w.rf>
   <form>neznal</form>
   <lemma>znát</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m977-d-id71875">
   <w.rf>
    <LM>w#w-d-id71875</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1487">
  <m id="m977-1487-1505">
   <w.rf>
    <LM>w#w-1487-1505</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m977-id60051-5">
   <w.rf>
    <LM>w#w-id60051-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id60051-6">
   <w.rf>
    <LM>w#w-id60051-6</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60051-4">
   <w.rf>
    <LM>w#w-id60051-4</LM>
   </w.rf>
   <form>všeobecně</form>
   <lemma>všeobecně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-1453-1485">
   <w.rf>
    <LM>w#w-1453-1485</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id60017-x1">
  <m id="m977-id60046-3">
   <w.rf>
    <LM>w#w-id60046-3</LM>
   </w.rf>
   <form>Všeobecně</form>
   <lemma>všeobecně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60046-1">
   <w.rf>
    <LM>w#w-id60046-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id60046-2">
   <w.rf>
    <LM>w#w-id60046-2</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60017-x1-1466">
   <w.rf>
    <LM>w#w-id60017-x1-1466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1474">
  <m id="m977-1474-1503">
   <w.rf>
    <LM>w#w-1474-1503</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-1474-1504">
   <w.rf>
    <LM>w#w-1474-1504</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-1474-1505">
   <w.rf>
    <LM>w#w-1474-1505</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id60088-1">
   <w.rf>
    <LM>w#w-id60088-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60088-3">
   <w.rf>
    <LM>w#w-id60088-3</LM>
   </w.rf>
   <form>Prostějova</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-1474-1665">
   <w.rf>
    <LM>w#w-1474-1665</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60061-5">
   <w.rf>
    <LM>w#w-id60061-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60061-4">
   <w.rf>
    <LM>w#w-id60061-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60079-2">
   <w.rf>
    <LM>w#w-id60079-2</LM>
   </w.rf>
   <form>nejprve</form>
   <lemma>nejprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60116-3">
   <w.rf>
    <LM>w#w-id60116-3</LM>
   </w.rf>
   <form>bydlel</form>
   <lemma>bydlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60116-4">
   <w.rf>
    <LM>w#w-id60116-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60125-1">
   <w.rf>
    <LM>w#w-id60125-1</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m977-id60125-2">
   <w.rf>
    <LM>w#w-id60125-2</LM>
   </w.rf>
   <form>spolubojovníka</form>
   <lemma>spolubojovník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m977-d-id72589">
   <w.rf>
    <LM>w#w-d-id72589</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60125-3">
   <w.rf>
    <LM>w#w-id60125-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60125-5">
   <w.rf>
    <LM>w#w-id60125-5</LM>
   </w.rf>
   <form>Šíka</form>
   <lemma>Šík_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m977-1474-1121">
   <w.rf>
    <LM>w#w-1474-1121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1122">
  <m id="m977-id60125-7">
   <w.rf>
    <LM>w#w-id60125-7</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60125-8">
   <w.rf>
    <LM>w#w-id60125-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60125-9">
   <w.rf>
    <LM>w#w-id60125-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60125-11">
   <w.rf>
    <LM>w#w-id60125-11</LM>
   </w.rf>
   <form>hudbě</form>
   <lemma>hudba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-1474-1678">
   <w.rf>
    <LM>w#w-1474-1678</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60125-13">
   <w.rf>
    <LM>w#w-id60125-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60125-15">
   <w.rf>
    <LM>w#w-id60125-15</LM>
   </w.rf>
   <form>houslista</form>
   <lemma>houslista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-1122-1123">
   <w.rf>
    <LM>w#w-1122-1123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1124">
  <m id="m977-id60136-3">
   <w.rf>
    <LM>w#w-id60136-3</LM>
   </w.rf>
   <form>Navštívil</form>
   <lemma>navštívit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id60136-4">
   <w.rf>
    <LM>w#w-id60136-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60136-5">
   <w.rf>
    <LM>w#w-id60136-5</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60136-7">
   <w.rf>
    <LM>w#w-id60136-7</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m977-id60146-1">
   <w.rf>
    <LM>w#w-id60146-1</LM>
   </w.rf>
   <form>dívky</form>
   <lemma>dívka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m977-d-id72909">
   <w.rf>
    <LM>w#w-d-id72909</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-1474-1676">
   <w.rf>
    <LM>w#w-1474-1676</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m977-id60146-2">
   <w.rf>
    <LM>w#w-id60146-2</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS7----------</tag>
  </m>
  <m id="m977-id60146-3">
   <w.rf>
    <LM>w#w-id60146-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60146-4">
   <w.rf>
    <LM>w#w-id60146-4</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60091-x1-283">
   <w.rf>
    <LM>w#w-id60091-x1-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-276">
  <m id="m977-id60155-4">
   <w.rf>
    <LM>w#w-id60155-4</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60155-5">
   <w.rf>
    <LM>w#w-id60155-5</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m977-id60155-3">
   <w.rf>
    <LM>w#w-id60155-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60155-2">
   <w.rf>
    <LM>w#w-id60155-2</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60155-6">
   <w.rf>
    <LM>w#w-id60155-6</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m977-276-285">
   <w.rf>
    <LM>w#w-276-285</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60155-7">
   <w.rf>
    <LM>w#w-id60155-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60155-8">
   <w.rf>
    <LM>w#w-id60155-8</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m977-id60155-10">
   <w.rf>
    <LM>w#w-id60155-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60155-9">
   <w.rf>
    <LM>w#w-id60155-9</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m977-276-1818">
   <w.rf>
    <LM>w#w-276-1818</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1811">
  <m id="m977-id60155-15">
   <w.rf>
    <LM>w#w-id60155-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m977-id60155-16">
   <w.rf>
    <LM>w#w-id60155-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60155-17">
   <w.rf>
    <LM>w#w-id60155-17</LM>
   </w.rf>
   <form>stává</form>
   <lemma>stávat-2_^(*5t-2)_(*5t-3)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-1811-1827">
   <w.rf>
    <LM>w#w-1811-1827</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1819">
  <m id="m977-id60175-3">
   <w.rf>
    <LM>w#w-id60175-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60175-4">
   <w.rf>
    <LM>w#w-id60175-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60175-5">
   <w.rf>
    <LM>w#w-id60175-5</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60175-6">
   <w.rf>
    <LM>w#w-id60175-6</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-1819-1132">
   <w.rf>
    <LM>w#w-1819-1132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60185-3">
   <w.rf>
    <LM>w#w-id60185-3</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60185-2">
   <w.rf>
    <LM>w#w-id60185-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-1819-1836">
   <w.rf>
    <LM>w#w-1819-1836</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60185-4">
   <w.rf>
    <LM>w#w-id60185-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60185-5">
   <w.rf>
    <LM>w#w-id60185-5</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m977-id60185-6">
   <w.rf>
    <LM>w#w-id60185-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60185-7">
   <w.rf>
    <LM>w#w-id60185-7</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60185-8">
   <w.rf>
    <LM>w#w-id60185-8</LM>
   </w.rf>
   <form>dočkám</form>
   <lemma>dočkat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m977-1819-1133">
   <w.rf>
    <LM>w#w-1819-1133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1134">
  <m id="m977-id60185-9">
   <w.rf>
    <LM>w#w-id60185-9</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60185-10">
   <w.rf>
    <LM>w#w-id60185-10</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60185-11">
   <w.rf>
    <LM>w#w-id60185-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60185-12">
   <w.rf>
    <LM>w#w-id60185-12</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-d-id73561">
   <w.rf>
    <LM>w#w-d-id73561</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60185-13">
   <w.rf>
    <LM>w#w-id60185-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60185-15">
   <w.rf>
    <LM>w#w-id60185-15</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60185-14">
   <w.rf>
    <LM>w#w-id60185-14</LM>
   </w.rf>
   <form>některá</form>
   <lemma>některý</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m977-id60185-16">
   <w.rf>
    <LM>w#w-id60185-16</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m977-id60185-18">
   <w.rf>
    <LM>w#w-id60185-18</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP2----------</tag>
  </m>
  <m id="m977-id60185-19">
   <w.rf>
    <LM>w#w-id60185-19</LM>
   </w.rf>
   <form>sester</form>
   <lemma>sestra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m977-1819-1838">
   <w.rf>
    <LM>w#w-1819-1838</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m977-id60196-2">
   <w.rf>
    <LM>w#w-id60196-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id60196-3">
   <w.rf>
    <LM>w#w-id60196-3</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m977-id60196-4">
   <w.rf>
    <LM>w#w-id60196-4</LM>
   </w.rf>
   <form>přežít</form>
   <lemma>přežít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m977-1819-1846">
   <w.rf>
    <LM>w#w-1819-1846</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1839">
  <m id="m977-id60196-5">
   <w.rf>
    <LM>w#w-id60196-5</LM>
   </w.rf>
   <form>Vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60196-6">
   <w.rf>
    <LM>w#w-id60196-6</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS3----------</tag>
  </m>
  <m id="m977-id60206-1">
   <w.rf>
    <LM>w#w-id60206-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m977-id60206-2">
   <w.rf>
    <LM>w#w-id60206-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60206-5">
   <w.rf>
    <LM>w#w-id60206-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m977-id60206-4">
   <w.rf>
    <LM>w#w-id60206-4</LM>
   </w.rf>
   <form>1942</form>
   <lemma>1942</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m977-id60206-8">
   <w.rf>
    <LM>w#w-id60206-8</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m977-id60206-9">
   <w.rf>
    <LM>w#w-id60206-9</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m977-id60206-10">
   <w.rf>
    <LM>w#w-id60206-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60206-11">
   <w.rf>
    <LM>w#w-id60206-11</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS3----------</tag>
  </m>
  <m id="m977-id60206-12">
   <w.rf>
    <LM>w#w-id60206-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m977-id60216-1">
   <w.rf>
    <LM>w#w-id60216-1</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m977-d-id74003">
   <w.rf>
    <LM>w#w-d-id74003</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id60091-x2">
  <m id="m977-id60221-3">
   <w.rf>
    <LM>w#w-id60221-3</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60221-4">
   <w.rf>
    <LM>w#w-id60221-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m977-id60221-5">
   <w.rf>
    <LM>w#w-id60221-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m977-id60221-6">
   <w.rf>
    <LM>w#w-id60221-6</LM>
   </w.rf>
   <form>nemohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m977-id60221-7">
   <w.rf>
    <LM>w#w-id60221-7</LM>
   </w.rf>
   <form>přežít</form>
   <lemma>přežít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m977-d-id74146">
   <w.rf>
    <LM>w#w-d-id74146</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id60091-x3">
  <m id="m977-id60244-2">
   <w.rf>
    <LM>w#w-id60244-2</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id60244-3">
   <w.rf>
    <LM>w#w-id60244-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m977-id60253-5">
   <w.rf>
    <LM>w#w-id60253-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60244-5">
   <w.rf>
    <LM>w#w-id60244-5</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m977-id60244-6">
   <w.rf>
    <LM>w#w-id60244-6</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m977-id60091-x3-873">
   <w.rf>
    <LM>w#w-id60091-x3-873</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60253-1">
   <w.rf>
    <LM>w#w-id60253-1</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m977-id60253-2">
   <w.rf>
    <LM>w#w-id60253-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m977-id60253-3">
   <w.rf>
    <LM>w#w-id60253-3</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id60253-4">
   <w.rf>
    <LM>w#w-id60253-4</LM>
   </w.rf>
   <form>pravdu</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60091-x3-874">
   <w.rf>
    <LM>w#w-id60091-x3-874</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60263-1">
   <w.rf>
    <LM>w#w-id60263-1</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m977-id60263-2">
   <w.rf>
    <LM>w#w-id60263-2</LM>
   </w.rf>
   <form>trauma</form>
   <lemma>trauma</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m977-d-id74401">
   <w.rf>
    <LM>w#w-d-id74401</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60263-4">
   <w.rf>
    <LM>w#w-id60263-4</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m977-id60263-5">
   <w.rf>
    <LM>w#w-id60263-5</LM>
   </w.rf>
   <form>trvá</form>
   <lemma>trvat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-id60263-6">
   <w.rf>
    <LM>w#w-id60263-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60263-7">
   <w.rf>
    <LM>w#w-id60263-7</LM>
   </w.rf>
   <form>dneška</form>
   <lemma>dnešek</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m977-id60091-x3-354">
   <w.rf>
    <LM>w#w-id60091-x3-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-347">
  <m id="m977-id60273-4">
   <w.rf>
    <LM>w#w-id60273-4</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60273-2">
   <w.rf>
    <LM>w#w-id60273-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60273-3">
   <w.rf>
    <LM>w#w-id60273-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m977-id60273-5">
   <w.rf>
    <LM>w#w-id60273-5</LM>
   </w.rf>
   <form>nezbavím</form>
   <lemma>zbavit</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m977-347-1147">
   <w.rf>
    <LM>w#w-347-1147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1149">
  <m id="m977-id60301-1">
   <w.rf>
    <LM>w#w-id60301-1</LM>
   </w.rf>
   <form>Záviděl</form>
   <lemma>závidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60292-1">
   <w.rf>
    <LM>w#w-id60292-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60310-2">
   <w.rf>
    <LM>w#w-id60310-2</LM>
   </w.rf>
   <form>spolubojovníkům</form>
   <lemma>spolubojovník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m977-d-id74720">
   <w.rf>
    <LM>w#w-d-id74720</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60310-3">
   <w.rf>
    <LM>w#w-id60310-3</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m977-id60310-4">
   <w.rf>
    <LM>w#w-id60310-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60310-5">
   <w.rf>
    <LM>w#w-id60310-5</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m977-id60310-6">
   <w.rf>
    <LM>w#w-id60310-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60310-7">
   <w.rf>
    <LM>w#w-id60310-7</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id60310-8">
   <w.rf>
    <LM>w#w-id60310-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m977-id60310-9">
   <w.rf>
    <LM>w#w-id60310-9</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m977-id60091-x3-879">
   <w.rf>
    <LM>w#w-id60091-x3-879</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60310-11">
   <w.rf>
    <LM>w#w-id60310-11</LM>
   </w.rf>
   <form>sourozenci</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m977-id60310-12">
   <w.rf>
    <LM>w#w-id60310-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60310-13">
   <w.rf>
    <LM>w#w-id60310-13</LM>
   </w.rf>
   <form>příbuzenstvo</form>
   <lemma>příbuzenstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m977-id60091-x3-891">
   <w.rf>
    <LM>w#w-id60091-x3-891</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-880">
  <m id="m977-id60321-2">
   <w.rf>
    <LM>w#w-id60321-2</LM>
   </w.rf>
   <form>Určitou</form>
   <lemma>určitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m977-id60321-3">
   <w.rf>
    <LM>w#w-id60321-3</LM>
   </w.rf>
   <form>bázi</form>
   <lemma>báze</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60321-7">
   <w.rf>
    <LM>w#w-id60321-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m977-id60321-9">
   <w.rf>
    <LM>w#w-id60321-9</LM>
   </w.rf>
   <form>budoucí</form>
   <lemma>budoucí</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m977-id60321-10">
   <w.rf>
    <LM>w#w-id60321-10</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-id60321-4">
   <w.rf>
    <LM>w#w-id60321-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id60321-5">
   <w.rf>
    <LM>w#w-id60321-5</LM>
   </w.rf>
   <form>připravenou</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m977-d-id75090">
   <w.rf>
    <LM>w#w-d-id75090</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60331-1">
   <w.rf>
    <LM>w#w-id60331-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m977-880-1154">
   <w.rf>
    <LM>w#w-880-1154</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60331-2">
   <w.rf>
    <LM>w#w-id60331-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m977-id60331-3">
   <w.rf>
    <LM>w#w-id60331-3</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60331-4">
   <w.rf>
    <LM>w#w-id60331-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60331-5">
   <w.rf>
    <LM>w#w-id60331-5</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m977-880-1155">
   <w.rf>
    <LM>w#w-880-1155</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1156">
  <m id="m977-id60341-2">
   <w.rf>
    <LM>w#w-id60341-2</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-1156-1157">
   <w.rf>
    <LM>w#w-1156-1157</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60341-3">
   <w.rf>
    <LM>w#w-id60341-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60341-4">
   <w.rf>
    <LM>w#w-id60341-4</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m977-id60350-1">
   <w.rf>
    <LM>w#w-id60350-1</LM>
   </w.rf>
   <form>pitomou</form>
   <lemma>pitomý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m977-id60350-2">
   <w.rf>
    <LM>w#w-id60350-2</LM>
   </w.rf>
   <form>uniformu</form>
   <lemma>uniforma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-880-893">
   <w.rf>
    <LM>w#w-880-893</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60350-9">
   <w.rf>
    <LM>w#w-id60350-9</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m977-id60350-10">
   <w.rf>
    <LM>w#w-id60350-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60350-11">
   <w.rf>
    <LM>w#w-id60350-11</LM>
   </w.rf>
   <form>vyfasoval</form>
   <lemma>vyfasovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-880-896">
   <w.rf>
    <LM>w#w-880-896</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-925">
  <m id="m977-id60361-1">
   <w.rf>
    <LM>w#w-id60361-1</LM>
   </w.rf>
   <form>Vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60361-3">
   <w.rf>
    <LM>w#w-id60361-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60379-2">
   <w.rf>
    <LM>w#w-id60379-2</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIP4----------</tag>
  </m>
  <m id="m977-id60379-3">
   <w.rf>
    <LM>w#w-id60379-3</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m977-id60389-1">
   <w.rf>
    <LM>w#w-id60389-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60389-2">
   <w.rf>
    <LM>w#w-id60389-2</LM>
   </w.rf>
   <form>osvobození</form>
   <lemma>osvobození_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m977-id60370-2">
   <w.rf>
    <LM>w#w-id60370-2</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60370-1">
   <w.rf>
    <LM>w#w-id60370-1</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m977-id60389-3">
   <w.rf>
    <LM>w#w-id60389-3</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m977-id60389-4">
   <w.rf>
    <LM>w#w-id60389-4</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60389-5">
   <w.rf>
    <LM>w#w-id60389-5</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60389-6">
   <w.rf>
    <LM>w#w-id60389-6</LM>
   </w.rf>
   <form>uniformy</form>
   <lemma>uniforma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m977-925-1160">
   <w.rf>
    <LM>w#w-925-1160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1161">
  <m id="m977-id60399-3">
   <w.rf>
    <LM>w#w-id60399-3</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60399-8">
   <w.rf>
    <LM>w#w-id60399-8</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m977-id60399-6">
   <w.rf>
    <LM>w#w-id60399-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m977-id60399-7">
   <w.rf>
    <LM>w#w-id60399-7</LM>
   </w.rf>
   <form>přítel</form>
   <lemma>přítel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m977-d-id75836">
   <w.rf>
    <LM>w#w-d-id75836</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60399-10">
   <w.rf>
    <LM>w#w-id60399-10</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60399-11">
   <w.rf>
    <LM>w#w-id60399-11</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m977-id60399-12">
   <w.rf>
    <LM>w#w-id60399-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60399-13">
   <w.rf>
    <LM>w#w-id60399-13</LM>
   </w.rf>
   <form>Irsku</form>
   <lemma>Irsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m977-880-900">
   <w.rf>
    <LM>w#w-880-900</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60409-1">
   <w.rf>
    <LM>w#w-id60409-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m977-id60409-2">
   <w.rf>
    <LM>w#w-id60409-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60409-4">
   <w.rf>
    <LM>w#w-id60409-4</LM>
   </w.rf>
   <form>konfekční</form>
   <lemma>konfekční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m977-id60409-5">
   <w.rf>
    <LM>w#w-id60409-5</LM>
   </w.rf>
   <form>fabriku</form>
   <lemma>fabrika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-880-902">
   <w.rf>
    <LM>w#w-880-902</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60409-6">
   <w.rf>
    <LM>w#w-id60409-6</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60419-2">
   <w.rf>
    <LM>w#w-id60419-2</LM>
   </w.rf>
   <form>vyšmátral</form>
   <lemma>vyšmátrat_,h</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id60428-2">
   <w.rf>
    <LM>w#w-id60428-2</LM>
   </w.rf>
   <form>látku</form>
   <lemma>látka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-1161-1162">
   <w.rf>
    <LM>w#w-1161-1162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1163">
  <m id="m977-id60428-5">
   <w.rf>
    <LM>w#w-id60428-5</LM>
   </w.rf>
   <form>Nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-1163-1164">
   <w.rf>
    <LM>w#w-1163-1164</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60428-4">
   <w.rf>
    <LM>w#w-id60428-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m977-id60428-6">
   <w.rf>
    <LM>w#w-id60428-6</LM>
   </w.rf>
   <form>ušít</form>
   <lemma>ušít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m977-id60428-9">
   <w.rf>
    <LM>w#w-id60428-9</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m977-id60428-7">
   <w.rf>
    <LM>w#w-id60428-7</LM>
   </w.rf>
   <form>civilní</form>
   <lemma>civilní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m977-id60428-8">
   <w.rf>
    <LM>w#w-id60428-8</LM>
   </w.rf>
   <form>oblek</form>
   <lemma>oblek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m977-880-912">
   <w.rf>
    <LM>w#w-880-912</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-905">
  <m id="m977-905-918">
   <w.rf>
    <LM>w#w-905-918</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m977-905-917">
   <w.rf>
    <LM>w#w-905-917</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m977-id60448-2">
   <w.rf>
    <LM>w#w-id60448-2</LM>
   </w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m977-905-916">
   <w.rf>
    <LM>w#w-905-916</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-905-919">
   <w.rf>
    <LM>w#w-905-919</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60457-1">
   <w.rf>
    <LM>w#w-id60457-1</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m977-id60457-4">
   <w.rf>
    <LM>w#w-id60457-4</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m977-id60457-5">
   <w.rf>
    <LM>w#w-id60457-5</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m977-905-914">
   <w.rf>
    <LM>w#w-905-914</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m977-id60457-6">
   <w.rf>
    <LM>w#w-id60457-6</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m977-id60457-7">
   <w.rf>
    <LM>w#w-id60457-7</LM>
   </w.rf>
   <form>radosti</form>
   <lemma>radost</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m977-d-id76440">
   <w.rf>
    <LM>w#w-d-id76440</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id60460-x1">
  <m id="m977-id60476-5">
   <w.rf>
    <LM>w#w-id60476-5</LM>
   </w.rf>
   <form>Stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-id60476-2">
   <w.rf>
    <LM>w#w-id60476-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m977-id60476-3">
   <w.rf>
    <LM>w#w-id60476-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60476-4">
   <w.rf>
    <LM>w#w-id60476-4</LM>
   </w.rf>
   <form>zdržoval</form>
   <lemma>zdržovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60476-6">
   <w.rf>
    <LM>w#w-id60476-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60476-7">
   <w.rf>
    <LM>w#w-id60476-7</LM>
   </w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m977-d-id76586">
   <w.rf>
    <LM>w#w-d-id76586</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-id60479-x1">
  <m id="m977-id60494-1">
   <w.rf>
    <LM>w#w-id60494-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60479-x1-1483">
   <w.rf>
    <LM>w#w-id60479-x1-1483</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60504-8">
   <w.rf>
    <LM>w#w-id60504-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60504-9">
   <w.rf>
    <LM>w#w-id60504-9</LM>
   </w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m977-id60522-1">
   <w.rf>
    <LM>w#w-id60522-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60522-2">
   <w.rf>
    <LM>w#w-id60522-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60522-3">
   <w.rf>
    <LM>w#w-id60522-3</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60479-x1-990">
   <w.rf>
    <LM>w#w-id60479-x1-990</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60532-1">
   <w.rf>
    <LM>w#w-id60532-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60532-6">
   <w.rf>
    <LM>w#w-id60532-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m977-id60532-4">
   <w.rf>
    <LM>w#w-id60532-4</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m977-id60532-5">
   <w.rf>
    <LM>w#w-id60532-5</LM>
   </w.rf>
   <form>posádka</form>
   <lemma>posádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m977-id60532-7">
   <w.rf>
    <LM>w#w-id60532-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60532-8">
   <w.rf>
    <LM>w#w-id60532-8</LM>
   </w.rf>
   <form>Kroměříži</form>
   <lemma>Kroměříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id60479-x1-937">
   <w.rf>
    <LM>w#w-id60479-x1-937</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-930">
  <m id="m977-id60542-1">
   <w.rf>
    <LM>w#w-id60542-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60542-2">
   <w.rf>
    <LM>w#w-id60542-2</LM>
   </w.rf>
   <form>Kroměříži</form>
   <lemma>Kroměříž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id60542-3">
   <w.rf>
    <LM>w#w-id60542-3</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m977-930-1370">
   <w.rf>
    <LM>w#w-930-1370</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-930-1371">
   <w.rf>
    <LM>w#w-930-1371</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60542-7">
   <w.rf>
    <LM>w#w-id60542-7</LM>
   </w.rf>
   <form>Potřebujeme</form>
   <lemma>potřebovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m977-id60542-6">
   <w.rf>
    <LM>w#w-id60542-6</LM>
   </w.rf>
   <form>tě</form>
   <lemma>ty</lemma>
   <tag>PH-S4--2-------</tag>
  </m>
  <m id="m977-id60542-9">
   <w.rf>
    <LM>w#w-id60542-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60542-10">
   <w.rf>
    <LM>w#w-id60542-10</LM>
   </w.rf>
   <form>sborovém</form>
   <lemma>sborový</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m977-id60542-11">
   <w.rf>
    <LM>w#w-id60542-11</LM>
   </w.rf>
   <form>velitelství</form>
   <lemma>velitelství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m977-930-1428">
   <w.rf>
    <LM>w#w-930-1428</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60542-13">
   <w.rf>
    <LM>w#w-id60542-13</LM>
   </w.rf>
   <form>budeš</form>
   <lemma>být</lemma>
   <tag>VB-S---2F-AAI--</tag>
  </m>
  <m id="m977-id60542-12">
   <w.rf>
    <LM>w#w-id60542-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60542-14">
   <w.rf>
    <LM>w#w-id60542-14</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m977-id60542-17">
   <w.rf>
    <LM>w#w-id60542-17</LM>
   </w.rf>
   <form>metodika</form>
   <lemma>metodik</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m977-930-1429">
   <w.rf>
    <LM>w#w-930-1429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-930-1430">
   <w.rf>
    <LM>w#w-930-1430</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1376">
  <m id="m977-id60553-2">
   <w.rf>
    <LM>w#w-id60553-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60553-3">
   <w.rf>
    <LM>w#w-id60553-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-1376-1775">
   <w.rf>
    <LM>w#w-1376-1775</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60553-4">
   <w.rf>
    <LM>w#w-id60553-4</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-1376-1771">
   <w.rf>
    <LM>w#w-1376-1771</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60553-11">
   <w.rf>
    <LM>w#w-id60553-11</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-1376-1772">
   <w.rf>
    <LM>w#w-1376-1772</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60553-12">
   <w.rf>
    <LM>w#w-id60553-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60553-13">
   <w.rf>
    <LM>w#w-id60553-13</LM>
   </w.rf>
   <form>nepředřel</form>
   <lemma>předřít</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m977-1376-1773">
   <w.rf>
    <LM>w#w-1376-1773</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60563-3">
   <w.rf>
    <LM>w#w-id60563-3</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m977-id60563-1">
   <w.rf>
    <LM>w#w-id60563-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60563-2">
   <w.rf>
    <LM>w#w-id60563-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60563-4">
   <w.rf>
    <LM>w#w-id60563-4</LM>
   </w.rf>
   <form>královský</form>
   <lemma>královský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m977-1376-1776">
   <w.rf>
    <LM>w#w-1376-1776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1777">
  <m id="m977-id60563-5">
   <w.rf>
    <LM>w#w-id60563-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60563-6">
   <w.rf>
    <LM>w#w-id60563-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60563-7">
   <w.rf>
    <LM>w#w-id60563-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60563-8">
   <w.rf>
    <LM>w#w-id60563-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60563-9">
   <w.rf>
    <LM>w#w-id60563-9</LM>
   </w.rf>
   <form>oženil</form>
   <lemma>oženit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-1777-1793">
   <w.rf>
    <LM>w#w-1777-1793</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60573-1">
   <w.rf>
    <LM>w#w-id60573-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60573-2">
   <w.rf>
    <LM>w#w-id60573-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60573-3">
   <w.rf>
    <LM>w#w-id60573-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60573-4">
   <w.rf>
    <LM>w#w-id60573-4</LM>
   </w.rf>
   <form>šťastně</form>
   <lemma>šťastně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-1777-137">
   <w.rf>
    <LM>w#w-1777-137</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-130">
  <m id="m977-id60573-8">
   <w.rf>
    <LM>w#w-id60573-8</LM>
   </w.rf>
   <form>Samota</form>
   <lemma>samota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m977-id60573-9">
   <w.rf>
    <LM>w#w-id60573-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m977-id60573-10">
   <w.rf>
    <LM>w#w-id60573-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m977-id60573-11">
   <w.rf>
    <LM>w#w-id60573-11</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m977-id60573-12">
   <w.rf>
    <LM>w#w-id60573-12</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60573-14">
   <w.rf>
    <LM>w#w-id60573-14</LM>
   </w.rf>
   <form>přihnala</form>
   <lemma>přihnat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m977-1777-1809">
   <w.rf>
    <LM>w#w-1777-1809</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60573-15">
   <w.rf>
    <LM>w#w-id60573-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60573-16">
   <w.rf>
    <LM>w#w-id60573-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60573-17">
   <w.rf>
    <LM>w#w-id60573-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60584-2">
   <w.rf>
    <LM>w#w-id60584-2</LM>
   </w.rf>
   <form>oženil</form>
   <lemma>oženit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m977-id60584-1">
   <w.rf>
    <LM>w#w-id60584-1</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m977-1777-1807">
   <w.rf>
    <LM>w#w-1777-1807</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-1795">
  <m id="m977-id60612-1">
   <w.rf>
    <LM>w#w-id60612-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60612-3">
   <w.rf>
    <LM>w#w-id60612-3</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m977-id60612-4">
   <w.rf>
    <LM>w#w-id60612-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m977-id60612-6">
   <w.rf>
    <LM>w#w-id60612-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m977-id60612-7">
   <w.rf>
    <LM>w#w-id60612-7</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m977-id60612-5">
   <w.rf>
    <LM>w#w-id60612-5</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60612-8">
   <w.rf>
    <LM>w#w-id60612-8</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m977-1795-1813">
   <w.rf>
    <LM>w#w-1795-1813</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60621-1">
   <w.rf>
    <LM>w#w-id60621-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60621-2">
   <w.rf>
    <LM>w#w-id60621-2</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m977-1795-2242">
   <w.rf>
    <LM>w#w-1795-2242</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60621-11">
   <w.rf>
    <LM>w#w-id60621-11</LM>
   </w.rf>
   <form>zahraniční</form>
   <lemma>zahraniční</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m977-id60621-12">
   <w.rf>
    <LM>w#w-id60621-12</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m977-1795-2244">
   <w.rf>
    <LM>w#w-1795-2244</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60621-13">
   <w.rf>
    <LM>w#w-id60621-13</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60621-14">
   <w.rf>
    <LM>w#w-id60621-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m977-id60621-15">
   <w.rf>
    <LM>w#w-id60621-15</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m977-id60621-16">
   <w.rf>
    <LM>w#w-id60621-16</LM>
   </w.rf>
   <form>východu</form>
   <lemma>východ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-1795-2245">
   <w.rf>
    <LM>w#w-1795-2245</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60621-17">
   <w.rf>
    <LM>w#w-id60621-17</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60621-18">
   <w.rf>
    <LM>w#w-id60621-18</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m977-id60621-19">
   <w.rf>
    <LM>w#w-id60621-19</LM>
   </w.rf>
   <form>západu</form>
   <lemma>západ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m977-1795-2243">
   <w.rf>
    <LM>w#w-1795-2243</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60621-3">
   <w.rf>
    <LM>w#w-id60621-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m977-id60621-4">
   <w.rf>
    <LM>w#w-id60621-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60621-21">
   <w.rf>
    <LM>w#w-id60621-21</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m977-id60621-22">
   <w.rf>
    <LM>w#w-id60621-22</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60621-5">
   <w.rf>
    <LM>w#w-id60621-5</LM>
   </w.rf>
   <form>platili</form>
   <lemma>platit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id60621-6">
   <w.rf>
    <LM>w#w-id60621-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60621-7">
   <w.rf>
    <LM>w#w-id60621-7</LM>
   </w.rf>
   <form>určitá</form>
   <lemma>určitý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m977-id60621-8">
   <w.rf>
    <LM>w#w-id60621-8</LM>
   </w.rf>
   <form>elita</form>
   <lemma>elita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m977-1795-2127">
   <w.rf>
    <LM>w#w-1795-2127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m977-26797_07-2114">
  <m id="m977-id60647-1">
   <w.rf>
    <LM>w#w-id60647-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id60647-2">
   <w.rf>
    <LM>w#w-id60647-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m977-id60647-3">
   <w.rf>
    <LM>w#w-id60647-3</LM>
   </w.rf>
   <form>lóži</form>
   <lemma>lóže</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m977-id60647-4">
   <w.rf>
    <LM>w#w-id60647-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m977-id60647-5">
   <w.rf>
    <LM>w#w-id60647-5</LM>
   </w.rf>
   <form>divadle</form>
   <lemma>divadlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m977-2114-2122">
   <w.rf>
    <LM>w#w-2114-2122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60647-8">
   <w.rf>
    <LM>w#w-id60647-8</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60647-9">
   <w.rf>
    <LM>w#w-id60647-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m977-id60647-10">
   <w.rf>
    <LM>w#w-id60647-10</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m977-id60647-11">
   <w.rf>
    <LM>w#w-id60647-11</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m977-id60647-14">
   <w.rf>
    <LM>w#w-id60647-14</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m977-id60657-2">
   <w.rf>
    <LM>w#w-id60657-2</LM>
   </w.rf>
   <form>čestní</form>
   <lemma>čestný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m977-id60657-3">
   <w.rf>
    <LM>w#w-id60657-3</LM>
   </w.rf>
   <form>hosté</form>
   <lemma>host</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m977-d-id78855">
   <w.rf>
    <LM>w#w-d-id78855</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m977-id60657-4">
   <w.rf>
    <LM>w#w-id60657-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m977-id60666-1">
   <w.rf>
    <LM>w#w-id60666-1</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m977-id60666-2">
   <w.rf>
    <LM>w#w-id60666-2</LM>
   </w.rf>
   <form>mejdany</form>
   <lemma>mejdan</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m977-id60666-3">
   <w.rf>
    <LM>w#w-id60666-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m977-id60666-4">
   <w.rf>
    <LM>w#w-id60666-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-id60666-5">
   <w.rf>
    <LM>w#w-id60666-5</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m977-1795-2113">
   <w.rf>
    <LM>w#w-1795-2113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
