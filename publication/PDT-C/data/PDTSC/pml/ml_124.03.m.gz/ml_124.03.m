<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_124.03.w.gz" />
  </references>
 </head>
 <s id="m124-75">
  <m id="m124-d1t546-1">
   <w.rf>
    <LM>w#w-d1t546-1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t546-2">
   <w.rf>
    <LM>w#w-d1t546-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-75-80">
   <w.rf>
    <LM>w#w-75-80</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t546-3">
   <w.rf>
    <LM>w#w-d1t546-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t546-5">
   <w.rf>
    <LM>w#w-d1t546-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t546-6">
   <w.rf>
    <LM>w#w-d1t546-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-75-81">
   <w.rf>
    <LM>w#w-75-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t546-7">
   <w.rf>
    <LM>w#w-d1t546-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t546-8">
   <w.rf>
    <LM>w#w-d1t546-8</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t546-9">
   <w.rf>
    <LM>w#w-d1t546-9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t546-10">
   <w.rf>
    <LM>w#w-d1t546-10</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t546-11">
   <w.rf>
    <LM>w#w-d1t546-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m124-d1t546-12">
   <w.rf>
    <LM>w#w-d1t546-12</LM>
   </w.rf>
   <form>večeru</form>
   <lemma>večer-1</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m124-d-id85426-punct">
   <w.rf>
    <LM>w#w-d-id85426-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t546-14">
   <w.rf>
    <LM>w#w-d1t546-14</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t546-15">
   <w.rf>
    <LM>w#w-d1t546-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t546-16">
   <w.rf>
    <LM>w#w-d1t546-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t546-17">
   <w.rf>
    <LM>w#w-d1t546-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t546-18">
   <w.rf>
    <LM>w#w-d1t546-18</LM>
   </w.rf>
   <form>ubytovali</form>
   <lemma>ubytovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m124-75-326">
   <w.rf>
    <LM>w#w-75-326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-330">
  <m id="m124-75-83">
   <w.rf>
    <LM>w#w-75-83</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m124-75-84">
   <w.rf>
    <LM>w#w-75-84</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t546-20">
   <w.rf>
    <LM>w#w-d1t546-20</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHP1-S1-------</tag>
  </m>
  <m id="m124-d1t546-21">
   <w.rf>
    <LM>w#w-d1t546-21</LM>
   </w.rf>
   <form>kolegyně</form>
   <lemma>kolegyně</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m124-d1t546-22">
   <w.rf>
    <LM>w#w-d1t546-22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t546-23">
   <w.rf>
    <LM>w#w-d1t546-23</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m124-d1t546-27">
   <w.rf>
    <LM>w#w-d1t546-27</LM>
   </w.rf>
   <form>šéf</form>
   <lemma>šéf</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m124-d1t546-31">
   <w.rf>
    <LM>w#w-d1t546-31</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t546-32">
   <w.rf>
    <LM>w#w-d1t546-32</LM>
   </w.rf>
   <form>relaxujeme</form>
   <lemma>relaxovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-75-85">
   <w.rf>
    <LM>w#w-75-85</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-86">
  <m id="m124-d1t548-3">
   <w.rf>
    <LM>w#w-d1t548-3</LM>
   </w.rf>
   <form>Exkurze</form>
   <lemma>exkurze</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m124-d1t548-4">
   <w.rf>
    <LM>w#w-d1t548-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t548-5">
   <w.rf>
    <LM>w#w-d1t548-5</LM>
   </w.rf>
   <form>pořádají</form>
   <lemma>pořádat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m124-d1t548-6">
   <w.rf>
    <LM>w#w-d1t548-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t548-7">
   <w.rf>
    <LM>w#w-d1t548-7</LM>
   </w.rf>
   <form>posluchače</form>
   <lemma>posluchač</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m124-d1t548-8">
   <w.rf>
    <LM>w#w-d1t548-8</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m124-d1t548-9">
   <w.rf>
    <LM>w#w-d1t548-9</LM>
   </w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m124-86-89">
   <w.rf>
    <LM>w#w-86-89</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-90">
  <m id="m124-d1t551-1">
   <w.rf>
    <LM>w#w-d1t551-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t551-2">
   <w.rf>
    <LM>w#w-d1t551-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t551-3">
   <w.rf>
    <LM>w#w-d1t551-3</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m124-d1t551-4">
   <w.rf>
    <LM>w#w-d1t551-4</LM>
   </w.rf>
   <form>veliký</form>
   <lemma>veliký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-d1t551-5">
   <w.rf>
    <LM>w#w-d1t551-5</LM>
   </w.rf>
   <form>zájem</form>
   <lemma>zájem</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-d-id85963-punct">
   <w.rf>
    <LM>w#w-d-id85963-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t551-7">
   <w.rf>
    <LM>w#w-d1t551-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t551-8">
   <w.rf>
    <LM>w#w-d1t551-8</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t551-9">
   <w.rf>
    <LM>w#w-d1t551-9</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m124-d1t551-10">
   <w.rf>
    <LM>w#w-d1t551-10</LM>
   </w.rf>
   <form>dnů</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m124-d1t551-11">
   <w.rf>
    <LM>w#w-d1t551-11</LM>
   </w.rf>
   <form>navštívíme</form>
   <lemma>navštívit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m124-d1t551-12">
   <w.rf>
    <LM>w#w-d1t551-12</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m124-d1t551-13">
   <w.rf>
    <LM>w#w-d1t551-13</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m124-d1t551-14">
   <w.rf>
    <LM>w#w-d1t551-14</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t551-15">
   <w.rf>
    <LM>w#w-d1t551-15</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m124-d1t551-17">
   <w.rf>
    <LM>w#w-d1t551-17</LM>
   </w.rf>
   <form>mimopražských</form>
   <lemma>mimopražský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t551-16">
   <w.rf>
    <LM>w#w-d1t551-16</LM>
   </w.rf>
   <form>knihoven</form>
   <lemma>knihovna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-90-92">
   <w.rf>
    <LM>w#w-90-92</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t551-19">
   <w.rf>
    <LM>w#w-d1t551-19</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t551-20">
   <w.rf>
    <LM>w#w-d1t551-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t551-21">
   <w.rf>
    <LM>w#w-d1t551-21</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t551-22">
   <w.rf>
    <LM>w#w-d1t551-22</LM>
   </w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m124-d1t551-23">
   <w.rf>
    <LM>w#w-d1t551-23</LM>
   </w.rf>
   <form>úrovni</form>
   <lemma>úroveň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d1e537-x3-93">
   <w.rf>
    <LM>w#w-d1e537-x3-93</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-94">
  <m id="m124-d1t553-3">
   <w.rf>
    <LM>w#w-d1t553-3</LM>
   </w.rf>
   <form>Studenti</form>
   <lemma>student</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m124-d1t553-2">
   <w.rf>
    <LM>w#w-d1t553-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t553-4">
   <w.rf>
    <LM>w#w-d1t553-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m124-d1t553-5">
   <w.rf>
    <LM>w#w-d1t553-5</LM>
   </w.rf>
   <form>naučí</form>
   <lemma>naučit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m124-d1t553-6">
   <w.rf>
    <LM>w#w-d1t553-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t553-7">
   <w.rf>
    <LM>w#w-d1t553-7</LM>
   </w.rf>
   <form>okouknou</form>
   <lemma>okouknout</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m124-d1t553-8">
   <w.rf>
    <LM>w#w-d1t553-8</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m124-d1t553-9">
   <w.rf>
    <LM>w#w-d1t553-9</LM>
   </w.rf>
   <form>novinky</form>
   <lemma>novinka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m124-d-m-d1e537-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e537-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e554-x2">
  <m id="m124-d1t557-1">
   <w.rf>
    <LM>w#w-d1t557-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t557-2">
   <w.rf>
    <LM>w#w-d1t557-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t557-3">
   <w.rf>
    <LM>w#w-d1t557-3</LM>
   </w.rf>
   <form>exkurze</form>
   <lemma>exkurze</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m124-d1t557-4">
   <w.rf>
    <LM>w#w-d1t557-4</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m124-d-id86507-punct">
   <w.rf>
    <LM>w#w-d-id86507-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e558-x2">
  <m id="m124-d1t561-1">
   <w.rf>
    <LM>w#w-d1t561-1</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t561-2">
   <w.rf>
    <LM>w#w-d1t561-2</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m124-d1t561-3">
   <w.rf>
    <LM>w#w-d1t561-3</LM>
   </w.rf>
   <form>republice</form>
   <lemma>republika</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d1e558-x2-112">
   <w.rf>
    <LM>w#w-d1e558-x2-112</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-114">
  <m id="m124-d1t563-1">
   <w.rf>
    <LM>w#w-d1t563-1</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t563-2">
   <w.rf>
    <LM>w#w-d1t563-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t563-3">
   <w.rf>
    <LM>w#w-d1t563-3</LM>
   </w.rf>
   <form>vybere</form>
   <lemma>vybrat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m124-d1t563-4">
   <w.rf>
    <LM>w#w-d1t563-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m124-d1t563-5">
   <w.rf>
    <LM>w#w-d1t563-5</LM>
   </w.rf>
   <form>kraj</form>
   <lemma>kraj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-d-id86708-punct">
   <w.rf>
    <LM>w#w-d-id86708-punct</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-7">
   <w.rf>
    <LM>w#w-d1t563-7</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t563-10">
   <w.rf>
    <LM>w#w-d1t563-10</LM>
   </w.rf>
   <form>Jihočeský</form>
   <lemma>jihočeský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-d1t563-11">
   <w.rf>
    <LM>w#w-d1t563-11</LM>
   </w.rf>
   <form>kraj</form>
   <lemma>kraj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-d-id86796-punct">
   <w.rf>
    <LM>w#w-d-id86796-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-16">
   <w.rf>
    <LM>w#w-d1t563-16</LM>
   </w.rf>
   <form>Jihomoravský</form>
   <lemma>jihomoravský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-d-id86854-punct">
   <w.rf>
    <LM>w#w-d-id86854-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-21">
   <w.rf>
    <LM>w#w-d1t563-21</LM>
   </w.rf>
   <form>Severočeský</form>
   <lemma>severočeský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-d-id86911-punct">
   <w.rf>
    <LM>w#w-d-id86911-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-24">
   <w.rf>
    <LM>w#w-d1t563-24</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t563-25">
   <w.rf>
    <LM>w#w-d1t563-25</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m124-114-122">
   <w.rf>
    <LM>w#w-114-122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-26">
   <w.rf>
    <LM>w#w-d1t563-26</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t563-27">
   <w.rf>
    <LM>w#w-d1t563-27</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t563-28">
   <w.rf>
    <LM>w#w-d1t563-28</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m124-d1t563-29">
   <w.rf>
    <LM>w#w-d1t563-29</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-114-115">
   <w.rf>
    <LM>w#w-114-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-116">
  <m id="m124-d1t563-31">
   <w.rf>
    <LM>w#w-d1t563-31</LM>
   </w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t563-32">
   <w.rf>
    <LM>w#w-d1t563-32</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t563-33">
   <w.rf>
    <LM>w#w-d1t563-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t563-34">
   <w.rf>
    <LM>w#w-d1t563-34</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t563-35">
   <w.rf>
    <LM>w#w-d1t563-35</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m124-d1t563-36">
   <w.rf>
    <LM>w#w-d1t563-36</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d-id87114-punct">
   <w.rf>
    <LM>w#w-d-id87114-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-38">
   <w.rf>
    <LM>w#w-d1t563-38</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t563-39">
   <w.rf>
    <LM>w#w-d1t563-39</LM>
   </w.rf>
   <form>vzdálenost</form>
   <lemma>vzdálenost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d1t563-40">
   <w.rf>
    <LM>w#w-d1t563-40</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t563-42">
   <w.rf>
    <LM>w#w-d1t563-42</LM>
   </w.rf>
   <form>jednotlivými</form>
   <lemma>jednotlivý</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m124-d1t563-43">
   <w.rf>
    <LM>w#w-d1t563-43</LM>
   </w.rf>
   <form>městy</form>
   <lemma>město</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m124-d1t563-44">
   <w.rf>
    <LM>w#w-d1t563-44</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m124-d1t563-45">
   <w.rf>
    <LM>w#w-d1t563-45</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t563-46">
   <w.rf>
    <LM>w#w-d1t563-46</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m124-d-id87263-punct">
   <w.rf>
    <LM>w#w-d-id87263-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-48">
   <w.rf>
    <LM>w#w-d1t563-48</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m124-d1t563-49">
   <w.rf>
    <LM>w#w-d1t563-49</LM>
   </w.rf>
   <form>zbytečně</form>
   <lemma>zbytečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t563-50">
   <w.rf>
    <LM>w#w-d1t563-50</LM>
   </w.rf>
   <form>neprojížděli</form>
   <lemma>projíždět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m124-d1t563-51">
   <w.rf>
    <LM>w#w-d1t563-51</LM>
   </w.rf>
   <form>kilometry</form>
   <lemma>kilometr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m124-d-id87334-punct">
   <w.rf>
    <LM>w#w-d-id87334-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t563-53">
   <w.rf>
    <LM>w#w-d1t563-53</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t563-54">
   <w.rf>
    <LM>w#w-d1t563-54</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m124-d1t563-55">
   <w.rf>
    <LM>w#w-d1t563-55</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m124-d1t563-56">
   <w.rf>
    <LM>w#w-d1t563-56</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t563-59">
   <w.rf>
    <LM>w#w-d1t563-59</LM>
   </w.rf>
   <form>náplň</form>
   <lemma>náplň</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d-id87451-punct">
   <w.rf>
    <LM>w#w-d-id87451-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t563-61">
   <w.rf>
    <LM>w#w-d1t563-61</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t563-62">
   <w.rf>
    <LM>w#w-d1t563-62</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t563-64">
   <w.rf>
    <LM>w#w-d1t563-64</LM>
   </w.rf>
   <form>posluchačům</form>
   <lemma>posluchač</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m124-d1t563-63">
   <w.rf>
    <LM>w#w-d1t563-63</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m124-d1t563-65">
   <w.rf>
    <LM>w#w-d1t563-65</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m124-116-117">
   <w.rf>
    <LM>w#w-116-117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-118">
  <m id="m124-d1t565-1">
   <w.rf>
    <LM>w#w-d1t565-1</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-118-119">
   <w.rf>
    <LM>w#w-118-119</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t565-2">
   <w.rf>
    <LM>w#w-d1t565-2</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t565-3">
   <w.rf>
    <LM>w#w-d1t565-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m124-d1t565-4">
   <w.rf>
    <LM>w#w-d1t565-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m124-d1t565-5">
   <w.rf>
    <LM>w#w-d1t565-5</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-d1t565-6">
   <w.rf>
    <LM>w#w-d1t565-6</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m124-118-120">
   <w.rf>
    <LM>w#w-118-120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e558-x3">
  <m id="m124-d1t565-8">
   <w.rf>
    <LM>w#w-d1t565-8</LM>
   </w.rf>
   <form>Fakulta</form>
   <lemma>fakulta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d1t565-9">
   <w.rf>
    <LM>w#w-d1t565-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t565-10">
   <w.rf>
    <LM>w#w-d1t565-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t565-11">
   <w.rf>
    <LM>w#w-d1t565-11</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m124-d1t565-12">
   <w.rf>
    <LM>w#w-d1t565-12</LM>
   </w.rf>
   <form>finančně</form>
   <lemma>finančně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t565-13">
   <w.rf>
    <LM>w#w-d1t565-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t565-14">
   <w.rf>
    <LM>w#w-d1t565-14</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d-id87763-punct">
   <w.rf>
    <LM>w#w-d-id87763-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t565-16">
   <w.rf>
    <LM>w#w-d1t565-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t565-17">
   <w.rf>
    <LM>w#w-d1t565-17</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m124-d1t565-19">
   <w.rf>
    <LM>w#w-d1t565-19</LM>
   </w.rf>
   <form>exkurzi</form>
   <lemma>exkurze</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d1t565-20">
   <w.rf>
    <LM>w#w-d1t565-20</LM>
   </w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m124-d1t565-21">
   <w.rf>
    <LM>w#w-d1t565-21</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m124-d1e558-x3-127">
   <w.rf>
    <LM>w#w-d1e558-x3-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-128">
  <m id="m124-d1t565-23">
   <w.rf>
    <LM>w#w-d1t565-23</LM>
   </w.rf>
   <form>Dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m124-d1t565-24">
   <w.rf>
    <LM>w#w-d1t565-24</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m124-d1t565-25">
   <w.rf>
    <LM>w#w-d1t565-25</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m124-d1t565-26">
   <w.rf>
    <LM>w#w-d1t565-26</LM>
   </w.rf>
   <form>platila</form>
   <lemma>platit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d-m-d1e558-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e558-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e567-x2">
  <m id="m124-d1t570-1">
   <w.rf>
    <LM>w#w-d1t570-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m124-d1t570-2">
   <w.rf>
    <LM>w#w-d1t570-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m124-d1t570-3">
   <w.rf>
    <LM>w#w-d1t570-3</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m124-d1t570-4">
   <w.rf>
    <LM>w#w-d1t570-4</LM>
   </w.rf>
   <form>novinky</form>
   <lemma>novinka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m124-d1t570-5">
   <w.rf>
    <LM>w#w-d1t570-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t570-6">
   <w.rf>
    <LM>w#w-d1t570-6</LM>
   </w.rf>
   <form>knihovnictví</form>
   <lemma>knihovnictví</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m124-d-id88082-punct">
   <w.rf>
    <LM>w#w-d-id88082-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t570-8">
   <w.rf>
    <LM>w#w-d1t570-8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m124-d1t570-9">
   <w.rf>
    <LM>w#w-d1t570-9</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m124-d1t570-10">
   <w.rf>
    <LM>w#w-d1t570-10</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t570-11">
   <w.rf>
    <LM>w#w-d1t570-11</LM>
   </w.rf>
   <form>zmínku</form>
   <lemma>zmínka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d-id88152-punct">
   <w.rf>
    <LM>w#w-d-id88152-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e571-x2">
  <m id="m124-d1t576-3">
   <w.rf>
    <LM>w#w-d1t576-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t576-4">
   <w.rf>
    <LM>w#w-d1t576-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t576-5">
   <w.rf>
    <LM>w#w-d1t576-5</LM>
   </w.rf>
   <form>zejména</form>
   <lemma>zejména-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t576-6">
   <w.rf>
    <LM>w#w-d1t576-6</LM>
   </w.rf>
   <form>automatizace</form>
   <lemma>automatizace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d1t576-7">
   <w.rf>
    <LM>w#w-d1t576-7</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m124-d1t576-8">
   <w.rf>
    <LM>w#w-d1t576-8</LM>
   </w.rf>
   <form>možných</form>
   <lemma>možný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t576-9">
   <w.rf>
    <LM>w#w-d1t576-9</LM>
   </w.rf>
   <form>služeb</form>
   <lemma>služba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d1t578-2">
   <w.rf>
    <LM>w#w-d1t578-2</LM>
   </w.rf>
   <form>počínaje</form>
   <lemma>počínat</lemma>
   <tag>VeYS------A-I--</tag>
  </m>
  <m id="m124-d1t578-1">
   <w.rf>
    <LM>w#w-d1t578-1</LM>
   </w.rf>
   <form>výpůjčními</form>
   <lemma>výpůjční</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m124-d-id88409-punct">
   <w.rf>
    <LM>w#w-d-id88409-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t578-4">
   <w.rf>
    <LM>w#w-d1t578-4</LM>
   </w.rf>
   <form>reprografickými</form>
   <lemma>reprografický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m124-d1e571-x2-135">
   <w.rf>
    <LM>w#w-d1e571-x2-135</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t578-5">
   <w.rf>
    <LM>w#w-d1t578-5</LM>
   </w.rf>
   <form>pokračuje</form>
   <lemma>pokračovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t580-1">
   <w.rf>
    <LM>w#w-d1t580-1</LM>
   </w.rf>
   <form>zavádění</form>
   <lemma>zavádění_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m124-d1t580-3">
   <w.rf>
    <LM>w#w-d1t580-3</LM>
   </w.rf>
   <form>nejrozmanitějších</form>
   <lemma>rozmanitý</lemma>
   <tag>AAFP2----3A----</tag>
  </m>
  <m id="m124-d1t580-4">
   <w.rf>
    <LM>w#w-d1t580-4</LM>
   </w.rf>
   <form>nových</form>
   <lemma>nový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t580-5">
   <w.rf>
    <LM>w#w-d1t580-5</LM>
   </w.rf>
   <form>technologií</form>
   <lemma>technologie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d1e571-x2-132">
   <w.rf>
    <LM>w#w-d1e571-x2-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-134">
  <m id="m124-d1t582-1">
   <w.rf>
    <LM>w#w-d1t582-1</LM>
   </w.rf>
   <form>Konečně</form>
   <lemma>konečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t582-2">
   <w.rf>
    <LM>w#w-d1t582-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t582-3">
   <w.rf>
    <LM>w#w-d1t582-3</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-134-136">
   <w.rf>
    <LM>w#w-134-136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t582-4">
   <w.rf>
    <LM>w#w-d1t582-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m124-d1t582-5">
   <w.rf>
    <LM>w#w-d1t582-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t582-6">
   <w.rf>
    <LM>w#w-d1t582-6</LM>
   </w.rf>
   <form>děláme</form>
   <lemma>dělat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-134-137">
   <w.rf>
    <LM>w#w-134-137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t582-7">
   <w.rf>
    <LM>w#w-d1t582-7</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m124-d1t582-8">
   <w.rf>
    <LM>w#w-d1t582-8</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t582-10">
   <w.rf>
    <LM>w#w-d1t582-10</LM>
   </w.rf>
   <form>jistě</form>
   <lemma>jistě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t582-9">
   <w.rf>
    <LM>w#w-d1t582-9</LM>
   </w.rf>
   <form>uplatněno</form>
   <lemma>uplatnit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m124-d1t585-1">
   <w.rf>
    <LM>w#w-d1t585-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t585-2">
   <w.rf>
    <LM>w#w-d1t585-2</LM>
   </w.rf>
   <form>řadě</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d1t585-3">
   <w.rf>
    <LM>w#w-d1t585-3</LM>
   </w.rf>
   <form>knihoven</form>
   <lemma>knihovna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d-m-d1e571-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e571-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e586-x2">
  <m id="m124-d1t589-2">
   <w.rf>
    <LM>w#w-d1t589-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m124-d1t589-3">
   <w.rf>
    <LM>w#w-d1t589-3</LM>
   </w.rf>
   <form>říkáte</form>
   <lemma>říkat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m124-d1t589-5">
   <w.rf>
    <LM>w#w-d1t589-5</LM>
   </w.rf>
   <form>Kaplického</form>
   <lemma>Kaplický_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m124-d1t589-7">
   <w.rf>
    <LM>w#w-d1t589-7</LM>
   </w.rf>
   <form>návrhu</form>
   <lemma>návrh</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m124-d1t589-8">
   <w.rf>
    <LM>w#w-d1t589-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t589-10">
   <w.rf>
    <LM>w#w-d1t589-10</LM>
   </w.rf>
   <form>Národní</form>
   <lemma>národní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m124-d1t589-11">
   <w.rf>
    <LM>w#w-d1t589-11</LM>
   </w.rf>
   <form>knihovnu</form>
   <lemma>knihovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d-id88974-punct">
   <w.rf>
    <LM>w#w-d-id88974-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e590-x2">
  <m id="m124-d1t593-2">
   <w.rf>
    <LM>w#w-d1t593-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t593-3">
   <w.rf>
    <LM>w#w-d1t593-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t593-4">
   <w.rf>
    <LM>w#w-d1t593-4</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m124-d1e590-x2-148">
   <w.rf>
    <LM>w#w-d1e590-x2-148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-149">
  <m id="m124-d1t597-1">
   <w.rf>
    <LM>w#w-d1t597-1</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m124-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m124-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m124-d-id89168-punct">
   <w.rf>
    <LM>w#w-d-id89168-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t597-5">
   <w.rf>
    <LM>w#w-d1t597-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t597-7">
   <w.rf>
    <LM>w#w-d1t597-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t597-8">
   <w.rf>
    <LM>w#w-d1t597-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t597-9">
   <w.rf>
    <LM>w#w-d1t597-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t597-10">
   <w.rf>
    <LM>w#w-d1t597-10</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m124-d1t597-11">
   <w.rf>
    <LM>w#w-d1t597-11</LM>
   </w.rf>
   <form>osobně</form>
   <lemma>osobně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t597-12">
   <w.rf>
    <LM>w#w-d1t597-12</LM>
   </w.rf>
   <form>znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d-id89301-punct">
   <w.rf>
    <LM>w#w-d-id89301-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t597-14">
   <w.rf>
    <LM>w#w-d1t597-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t597-15">
   <w.rf>
    <LM>w#w-d1t597-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t597-16">
   <w.rf>
    <LM>w#w-d1t597-16</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m124-d1t597-17">
   <w.rf>
    <LM>w#w-d1t597-17</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m124-d1t597-18">
   <w.rf>
    <LM>w#w-d1t597-18</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t597-24">
   <w.rf>
    <LM>w#w-d1t597-24</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t597-25">
   <w.rf>
    <LM>w#w-d1t597-25</LM>
   </w.rf>
   <form>pozitivní</form>
   <lemma>pozitivní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m124-d1t597-21">
   <w.rf>
    <LM>w#w-d1t597-21</LM>
   </w.rf>
   <form>poměr</form>
   <lemma>poměr_^(vztah_mezi_2_věcmi/lidmi)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m124-149-150">
   <w.rf>
    <LM>w#w-149-150</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t597-23">
   <w.rf>
    <LM>w#w-d1t597-23</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m124-d1t597-22">
   <w.rf>
    <LM>w#w-d1t597-22</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m124-149-366">
   <w.rf>
    <LM>w#w-149-366</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-369">
  <m id="m124-d1t597-27">
   <w.rf>
    <LM>w#w-d1t597-27</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t597-28">
   <w.rf>
    <LM>w#w-d1t597-28</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m124-d1t597-29">
   <w.rf>
    <LM>w#w-d1t597-29</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t597-30">
   <w.rf>
    <LM>w#w-d1t597-30</LM>
   </w.rf>
   <form>negativních</form>
   <lemma>negativní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m124-149-151">
   <w.rf>
    <LM>w#w-149-151</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-152">
  <m id="m124-d1t599-1">
   <w.rf>
    <LM>w#w-d1t599-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t599-2">
   <w.rf>
    <LM>w#w-d1t599-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m124-d-id89614-punct">
   <w.rf>
    <LM>w#w-d-id89614-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t599-4">
   <w.rf>
    <LM>w#w-d1t599-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t599-5">
   <w.rf>
    <LM>w#w-d1t599-5</LM>
   </w.rf>
   <form>kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t599-6">
   <w.rf>
    <LM>w#w-d1t599-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m124-d1t599-7">
   <w.rf>
    <LM>w#w-d1t599-7</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t599-8">
   <w.rf>
    <LM>w#w-d1t599-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t599-9">
   <w.rf>
    <LM>w#w-d1t599-9</LM>
   </w.rf>
   <form>vysoká</form>
   <lemma>vysoký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m124-d1t599-10">
   <w.rf>
    <LM>w#w-d1t599-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t599-11">
   <w.rf>
    <LM>w#w-d1t599-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t599-12">
   <w.rf>
    <LM>w#w-d1t599-12</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m124-d-id89762-punct">
   <w.rf>
    <LM>w#w-d-id89762-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t599-14">
   <w.rf>
    <LM>w#w-d1t599-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t599-16">
   <w.rf>
    <LM>w#w-d1t599-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t599-17">
   <w.rf>
    <LM>w#w-d1t599-17</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m124-d1t599-18">
   <w.rf>
    <LM>w#w-d1t599-18</LM>
   </w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m124-d1t599-19">
   <w.rf>
    <LM>w#w-d1t599-19</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t599-15">
   <w.rf>
    <LM>w#w-d1t599-15</LM>
   </w.rf>
   <form>klidně</form>
   <lemma>klidně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t599-20">
   <w.rf>
    <LM>w#w-d1t599-20</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-152-156">
   <w.rf>
    <LM>w#w-152-156</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-161">
  <m id="m124-d1t601-1">
   <w.rf>
    <LM>w#w-d1t601-1</LM>
   </w.rf>
   <form>Vnitřek</form>
   <lemma>vnitřek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-157-159">
   <w.rf>
    <LM>w#w-157-159</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t601-2">
   <w.rf>
    <LM>w#w-d1t601-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t601-3">
   <w.rf>
    <LM>w#w-d1t601-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t601-4">
   <w.rf>
    <LM>w#w-d1t601-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t601-5">
   <w.rf>
    <LM>w#w-d1t601-5</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d1t601-6">
   <w.rf>
    <LM>w#w-d1t601-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-d1t601-7">
   <w.rf>
    <LM>w#w-d1t601-7</LM>
   </w.rf>
   <form>projekt</form>
   <lemma>projekt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m124-157-160">
   <w.rf>
    <LM>w#w-157-160</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t601-19">
   <w.rf>
    <LM>w#w-d1t601-19</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m124-d1t601-12">
   <w.rf>
    <LM>w#w-d1t601-12</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t601-15">
   <w.rf>
    <LM>w#w-d1t601-15</LM>
   </w.rf>
   <form>uživatele</form>
   <lemma>uživatel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m124-d1t601-16">
   <w.rf>
    <LM>w#w-d1t601-16</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t601-17">
   <w.rf>
    <LM>w#w-d1t601-17</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t601-18">
   <w.rf>
    <LM>w#w-d1t601-18</LM>
   </w.rf>
   <form>zaměstnance</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m124-d1t601-20">
   <w.rf>
    <LM>w#w-d1t601-20</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t601-21">
   <w.rf>
    <LM>w#w-d1t601-21</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t601-22">
   <w.rf>
    <LM>w#w-d1t601-22</LM>
   </w.rf>
   <form>vymyšlený</form>
   <lemma>vymyšlený_^(*5slit)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-161-374">
   <w.rf>
    <LM>w#w-161-374</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-375">
  <m id="m124-d1t601-24">
   <w.rf>
    <LM>w#w-d1t601-24</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t601-25">
   <w.rf>
    <LM>w#w-d1t601-25</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m124-d-id90283-punct">
   <w.rf>
    <LM>w#w-d-id90283-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t601-27">
   <w.rf>
    <LM>w#w-d1t601-27</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t601-28">
   <w.rf>
    <LM>w#w-d1t601-28</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m124-d1t601-29">
   <w.rf>
    <LM>w#w-d1t601-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t601-30">
   <w.rf>
    <LM>w#w-d1t601-30</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t601-31">
   <w.rf>
    <LM>w#w-d1t601-31</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t601-32">
   <w.rf>
    <LM>w#w-d1t601-32</LM>
   </w.rf>
   <form>sloužilo</form>
   <lemma>sloužit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m124-d-m-d1e590-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e590-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e602-x2">
  <m id="m124-d1t605-1">
   <w.rf>
    <LM>w#w-d1t605-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m124-d1e602-x2-163">
   <w.rf>
    <LM>w#w-d1e602-x2-163</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-164">
  <m id="m124-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m124-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m124-d1t607-5">
   <w.rf>
    <LM>w#w-d1t607-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d-id90546-punct">
   <w.rf>
    <LM>w#w-d-id90546-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e608-x2">
  <m id="m124-d1t611-1">
   <w.rf>
    <LM>w#w-d1t611-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t611-2">
   <w.rf>
    <LM>w#w-d1t611-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m124-d1t611-3">
   <w.rf>
    <LM>w#w-d1t611-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d1t611-4">
   <w.rf>
    <LM>w#w-d1t611-4</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t611-5">
   <w.rf>
    <LM>w#w-d1t611-5</LM>
   </w.rf>
   <form>vzpomínku</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d1t611-6">
   <w.rf>
    <LM>w#w-d1t611-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t611-7">
   <w.rf>
    <LM>w#w-d1t611-7</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSNS4-S1------1</tag>
  </m>
  <m id="m124-d1t611-8">
   <w.rf>
    <LM>w#w-d1t611-8</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m124-d1e608-x2-382">
   <w.rf>
    <LM>w#w-d1e608-x2-382</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-383">
  <m id="m124-d1t611-12">
   <w.rf>
    <LM>w#w-d1t611-12</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t611-11">
   <w.rf>
    <LM>w#w-d1t611-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t611-13">
   <w.rf>
    <LM>w#w-d1t611-13</LM>
   </w.rf>
   <form>vodácký</form>
   <lemma>vodácký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m124-d1t611-14">
   <w.rf>
    <LM>w#w-d1t611-14</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-d1t611-18">
   <w.rf>
    <LM>w#w-d1t611-18</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t611-20">
   <w.rf>
    <LM>w#w-d1t611-20</LM>
   </w.rf>
   <form>Vltavy</form>
   <lemma>Vltava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m124-d1e608-x2-178">
   <w.rf>
    <LM>w#w-d1e608-x2-178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-179">
  <m id="m124-d1t613-1">
   <w.rf>
    <LM>w#w-d1t613-1</LM>
   </w.rf>
   <form>Která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m124-d1t613-2">
   <w.rf>
    <LM>w#w-d1t613-2</LM>
   </w.rf>
   <form>šlajsna</form>
   <lemma>šlajsna_,l</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d1t613-3">
   <w.rf>
    <LM>w#w-d1t613-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t613-4">
   <w.rf>
    <LM>w#w-d1t613-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-179-180">
   <w.rf>
    <LM>w#w-179-180</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t613-5">
   <w.rf>
    <LM>w#w-d1t613-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m124-d1t613-6">
   <w.rf>
    <LM>w#w-d1t613-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t613-7">
   <w.rf>
    <LM>w#w-d1t613-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t613-8">
   <w.rf>
    <LM>w#w-d1t613-8</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t613-9">
   <w.rf>
    <LM>w#w-d1t613-9</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m124-179-181">
   <w.rf>
    <LM>w#w-179-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-183">
  <m id="m124-d1t613-16">
   <w.rf>
    <LM>w#w-d1t613-16</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t613-17">
   <w.rf>
    <LM>w#w-d1t613-17</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m124-d1t613-18">
   <w.rf>
    <LM>w#w-d1t613-18</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m124-d1t613-19">
   <w.rf>
    <LM>w#w-d1t613-19</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t613-20">
   <w.rf>
    <LM>w#w-d1t613-20</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m124-d1t613-21">
   <w.rf>
    <LM>w#w-d1t613-21</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m124-183-194">
   <w.rf>
    <LM>w#w-183-194</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-183-195">
   <w.rf>
    <LM>w#w-183-195</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m124-d1t613-22">
   <w.rf>
    <LM>w#w-d1t613-22</LM>
   </w.rf>
   <form>pravidelné</form>
   <lemma>pravidelný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m124-d1t613-23">
   <w.rf>
    <LM>w#w-d1t613-23</LM>
   </w.rf>
   <form>zájezdy</form>
   <lemma>zájezd</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m124-d1t613-24">
   <w.rf>
    <LM>w#w-d1t613-24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t613-25">
   <w.rf>
    <LM>w#w-d1t613-25</LM>
   </w.rf>
   <form>červnu</form>
   <lemma>červen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m124-d1t613-26">
   <w.rf>
    <LM>w#w-d1t613-26</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t613-27">
   <w.rf>
    <LM>w#w-d1t613-27</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t613-28">
   <w.rf>
    <LM>w#w-d1t613-28</LM>
   </w.rf>
   <form>červenci</form>
   <lemma>červenec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m124-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP4----------</tag>
  </m>
  <m id="m124-d1t615-3">
   <w.rf>
    <LM>w#w-d1t615-3</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m124-d1t615-4">
   <w.rf>
    <LM>w#w-d1t615-4</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m124-d1t615-5">
   <w.rf>
    <LM>w#w-d1t615-5</LM>
   </w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m124-183-192">
   <w.rf>
    <LM>w#w-183-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-193">
  <m id="m124-d1t615-8">
   <w.rf>
    <LM>w#w-d1t615-8</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m124-d1t615-7">
   <w.rf>
    <LM>w#w-d1t615-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t615-6">
   <w.rf>
    <LM>w#w-d1t615-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t615-9">
   <w.rf>
    <LM>w#w-d1t615-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t615-11">
   <w.rf>
    <LM>w#w-d1t615-11</LM>
   </w.rf>
   <form>Slovensku</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m124-d1t615-13">
   <w.rf>
    <LM>w#w-d1t615-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t615-15">
   <w.rf>
    <LM>w#w-d1t615-15</LM>
   </w.rf>
   <form>Hornádu</form>
   <lemma>Hornád_;G_^(řeka)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m124-d-id91580-punct">
   <w.rf>
    <LM>w#w-d-id91580-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t615-18">
   <w.rf>
    <LM>w#w-d1t615-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t615-20">
   <w.rf>
    <LM>w#w-d1t615-20</LM>
   </w.rf>
   <form>Hronu</form>
   <lemma>Hron-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m124-193-216">
   <w.rf>
    <LM>w#w-193-216</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-217">
  <m id="m124-d1t617-1">
   <w.rf>
    <LM>w#w-d1t617-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m124-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m124-d1t617-4">
   <w.rf>
    <LM>w#w-d1t617-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t617-5">
   <w.rf>
    <LM>w#w-d1t617-5</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m124-d1t617-6">
   <w.rf>
    <LM>w#w-d1t617-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t617-7">
   <w.rf>
    <LM>w#w-d1t617-7</LM>
   </w.rf>
   <form>kánoích</form>
   <lemma>kánoe</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m124-217-219">
   <w.rf>
    <LM>w#w-217-219</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t619-1">
   <w.rf>
    <LM>w#w-d1t619-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t619-3">
   <w.rf>
    <LM>w#w-d1t619-3</LM>
   </w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m124-d1t619-5">
   <w.rf>
    <LM>w#w-d1t619-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t619-6">
   <w.rf>
    <LM>w#w-d1t619-6</LM>
   </w.rf>
   <form>kajacích</form>
   <lemma>kajak</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m124-217-220">
   <w.rf>
    <LM>w#w-217-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-218">
  <m id="m124-d1t619-8">
   <w.rf>
    <LM>w#w-d1t619-8</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t619-9">
   <w.rf>
    <LM>w#w-d1t619-9</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m124-d1t619-10">
   <w.rf>
    <LM>w#w-d1t619-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t619-11">
   <w.rf>
    <LM>w#w-d1t619-11</LM>
   </w.rf>
   <form>takzvané</form>
   <lemma>takzvaný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m124-d1t619-12">
   <w.rf>
    <LM>w#w-d1t619-12</LM>
   </w.rf>
   <form>skládací</form>
   <lemma>skládací_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m124-d1t619-13">
   <w.rf>
    <LM>w#w-d1t619-13</LM>
   </w.rf>
   <form>kajaky</form>
   <lemma>kajak</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m124-d-id91959-punct">
   <w.rf>
    <LM>w#w-d-id91959-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t619-15">
   <w.rf>
    <LM>w#w-d1t619-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t619-16">
   <w.rf>
    <LM>w#w-d1t619-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t619-17">
   <w.rf>
    <LM>w#w-d1t619-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t619-18">
   <w.rf>
    <LM>w#w-d1t619-18</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m124-d1t619-19">
   <w.rf>
    <LM>w#w-d1t619-19</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m124-d1t619-20">
   <w.rf>
    <LM>w#w-d1t619-20</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t619-21">
   <w.rf>
    <LM>w#w-d1t619-21</LM>
   </w.rf>
   <form>vlaku</form>
   <lemma>vlak</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m124-d1t619-22">
   <w.rf>
    <LM>w#w-d1t619-22</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t619-23">
   <w.rf>
    <LM>w#w-d1t619-23</LM>
   </w.rf>
   <form>spoluzavazadlo</form>
   <lemma>spoluzavazadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m124-218-226">
   <w.rf>
    <LM>w#w-218-226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-227">
  <m id="m124-d1t624-1">
   <w.rf>
    <LM>w#w-d1t624-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t626-1">
   <w.rf>
    <LM>w#w-d1t626-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t626-2">
   <w.rf>
    <LM>w#w-d1t626-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m124-d1t626-3">
   <w.rf>
    <LM>w#w-d1t626-3</LM>
   </w.rf>
   <form>šlajsně</form>
   <lemma>šlajsna_,l</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m124-d1t626-5">
   <w.rf>
    <LM>w#w-d1t626-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t626-6">
   <w.rf>
    <LM>w#w-d1t626-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m124-d1t626-7">
   <w.rf>
    <LM>w#w-d1t626-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m124-d1t626-8">
   <w.rf>
    <LM>w#w-d1t626-8</LM>
   </w.rf>
   <form>kamarádi</form>
   <lemma>kamarád</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m124-d-id92273-punct">
   <w.rf>
    <LM>w#w-d-id92273-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t626-10">
   <w.rf>
    <LM>w#w-d1t626-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t626-11">
   <w.rf>
    <LM>w#w-d1t626-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t626-12">
   <w.rf>
    <LM>w#w-d1t626-12</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t626-13">
   <w.rf>
    <LM>w#w-d1t626-13</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m124-d1t626-14">
   <w.rf>
    <LM>w#w-d1t626-14</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m124-d1t626-15">
   <w.rf>
    <LM>w#w-d1t626-15</LM>
   </w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d1t626-16">
   <w.rf>
    <LM>w#w-d1t626-16</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t626-17">
   <w.rf>
    <LM>w#w-d1t626-17</LM>
   </w.rf>
   <form>fakulty</form>
   <lemma>fakulta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m124-227-230">
   <w.rf>
    <LM>w#w-227-230</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-231">
  <m id="m124-d1t628-2">
   <w.rf>
    <LM>w#w-d1t628-2</LM>
   </w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t628-3">
   <w.rf>
    <LM>w#w-d1t628-3</LM>
   </w.rf>
   <form>dodržujeme</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t628-6">
   <w.rf>
    <LM>w#w-d1t628-6</LM>
   </w.rf>
   <form>kontakty</form>
   <lemma>kontakt</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m124-d1t628-4">
   <w.rf>
    <LM>w#w-d1t628-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t628-7">
   <w.rf>
    <LM>w#w-d1t628-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t628-8">
   <w.rf>
    <LM>w#w-d1t628-8</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t628-10">
   <w.rf>
    <LM>w#w-d1t628-10</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m124-d1t628-11">
   <w.rf>
    <LM>w#w-d1t628-11</LM>
   </w.rf>
   <form>vyšším</form>
   <lemma>vysoký</lemma>
   <tag>AAIS6----2A----</tag>
  </m>
  <m id="m124-231-232">
   <w.rf>
    <LM>w#w-231-232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t628-13">
   <w.rf>
    <LM>w#w-d1t628-13</LM>
   </w.rf>
   <form>ba</form>
   <lemma>ba</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t628-14">
   <w.rf>
    <LM>w#w-d1t628-14</LM>
   </w.rf>
   <form>vysokém</form>
   <lemma>vysoký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m124-d1t628-15">
   <w.rf>
    <LM>w#w-d1t628-15</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m124-d-m-d1e608-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e608-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e629-x2">
  <m id="m124-d1t632-1">
   <w.rf>
    <LM>w#w-d1t632-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t632-2">
   <w.rf>
    <LM>w#w-d1t632-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m124-d1t632-3">
   <w.rf>
    <LM>w#w-d1t632-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t632-4">
   <w.rf>
    <LM>w#w-d1t632-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m124-d1t632-5">
   <w.rf>
    <LM>w#w-d1t632-5</LM>
   </w.rf>
   <form>vodáctví</form>
   <lemma>vodáctví</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m124-d1t632-6">
   <w.rf>
    <LM>w#w-d1t632-6</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m124-d-id92800-punct">
   <w.rf>
    <LM>w#w-d-id92800-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e633-x2">
  <m id="m124-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t636-2">
   <w.rf>
    <LM>w#w-d1t636-2</LM>
   </w.rf>
   <form>malička</form>
   <lemma>maličko-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m124-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t636-5">
   <w.rf>
    <LM>w#w-d1t636-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m124-d1t636-6">
   <w.rf>
    <LM>w#w-d1t636-6</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d1e633-x2-246">
   <w.rf>
    <LM>w#w-d1e633-x2-246</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-247">
  <m id="m124-d1t638-2">
   <w.rf>
    <LM>w#w-d1t638-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t638-3">
   <w.rf>
    <LM>w#w-d1t638-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t638-4">
   <w.rf>
    <LM>w#w-d1t638-4</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m124-d1t638-5">
   <w.rf>
    <LM>w#w-d1t638-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t638-6">
   <w.rf>
    <LM>w#w-d1t638-6</LM>
   </w.rf>
   <form>fakultu</form>
   <lemma>fakulta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-d-id93063-punct">
   <w.rf>
    <LM>w#w-d-id93063-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t638-8">
   <w.rf>
    <LM>w#w-d1t638-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t638-9">
   <w.rf>
    <LM>w#w-d1t638-9</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m124-d1t638-10">
   <w.rf>
    <LM>w#w-d1t638-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t638-11">
   <w.rf>
    <LM>w#w-d1t638-11</LM>
   </w.rf>
   <form>nabídek</form>
   <lemma>nabídka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d1t638-12">
   <w.rf>
    <LM>w#w-d1t638-12</LM>
   </w.rf>
   <form>tělocviků</form>
   <lemma>tělocvik</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m124-d1t638-13">
   <w.rf>
    <LM>w#w-d1t638-13</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t638-14">
   <w.rf>
    <LM>w#w-d1t638-14</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t638-16">
   <w.rf>
    <LM>w#w-d1t638-16</LM>
   </w.rf>
   <form>prázdninových</form>
   <lemma>prázdninový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t638-17">
   <w.rf>
    <LM>w#w-d1t638-17</LM>
   </w.rf>
   <form>akcí</form>
   <lemma>akce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d1t638-19">
   <w.rf>
    <LM>w#w-d1t638-19</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t638-20">
   <w.rf>
    <LM>w#w-d1t638-20</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t638-21">
   <w.rf>
    <LM>w#w-d1t638-21</LM>
   </w.rf>
   <form>kanoistika</form>
   <lemma>kanoistika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-247-260">
   <w.rf>
    <LM>w#w-247-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-261">
  <m id="m124-d1t638-26">
   <w.rf>
    <LM>w#w-d1t638-26</LM>
   </w.rf>
   <form>Trénovat</form>
   <lemma>trénovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-d1t638-24">
   <w.rf>
    <LM>w#w-d1t638-24</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t638-25">
   <w.rf>
    <LM>w#w-d1t638-25</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m124-d1t638-27">
   <w.rf>
    <LM>w#w-d1t638-27</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t638-29">
   <w.rf>
    <LM>w#w-d1t638-29</LM>
   </w.rf>
   <form>Císařskou</form>
   <lemma>císařský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m124-d1t638-30">
   <w.rf>
    <LM>w#w-d1t638-30</LM>
   </w.rf>
   <form>louku</form>
   <lemma>louka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-261-273">
   <w.rf>
    <LM>w#w-261-273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-274">
  <m id="m124-274-421">
   <w.rf>
    <LM>w#w-274-421</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t640-4">
   <w.rf>
    <LM>w#w-d1t640-4</LM>
   </w.rf>
   <form>sobotách</form>
   <lemma>sobota</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m124-d1t640-5">
   <w.rf>
    <LM>w#w-d1t640-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t640-6">
   <w.rf>
    <LM>w#w-d1t640-6</LM>
   </w.rf>
   <form>nedělích</form>
   <lemma>neděle</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m124-d1t640-7">
   <w.rf>
    <LM>w#w-d1t640-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t640-8">
   <w.rf>
    <LM>w#w-d1t640-8</LM>
   </w.rf>
   <form>jara</form>
   <lemma>jaro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m124-d1t640-9">
   <w.rf>
    <LM>w#w-d1t640-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t640-10">
   <w.rf>
    <LM>w#w-d1t640-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t640-11">
   <w.rf>
    <LM>w#w-d1t640-11</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m124-d1t640-12">
   <w.rf>
    <LM>w#w-d1t640-12</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t640-13">
   <w.rf>
    <LM>w#w-d1t640-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t640-15">
   <w.rf>
    <LM>w#w-d1t640-15</LM>
   </w.rf>
   <form>Sázavu</form>
   <lemma>Sázava_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m124-274-288">
   <w.rf>
    <LM>w#w-274-288</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t640-17">
   <w.rf>
    <LM>w#w-d1t640-17</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t640-19">
   <w.rf>
    <LM>w#w-d1t640-19</LM>
   </w.rf>
   <form>Týnce</form>
   <lemma>Týnec_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m124-d1t640-21">
   <w.rf>
    <LM>w#w-d1t640-21</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t640-23">
   <w.rf>
    <LM>w#w-d1t640-23</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m124-274-285">
   <w.rf>
    <LM>w#w-274-285</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-287">
  <m id="m124-d1t642-5">
   <w.rf>
    <LM>w#w-d1t642-5</LM>
   </w.rf>
   <form>Delší</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIP1----2A----</tag>
  </m>
  <m id="m124-d1t644-1">
   <w.rf>
    <LM>w#w-d1t644-1</LM>
   </w.rf>
   <form>týdenní</form>
   <lemma>týdenní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m124-d1t642-6">
   <w.rf>
    <LM>w#w-d1t642-6</LM>
   </w.rf>
   <form>zájezdy</form>
   <lemma>zájezd</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m124-d1t644-3">
   <w.rf>
    <LM>w#w-d1t644-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m124-d1t644-5">
   <w.rf>
    <LM>w#w-d1t644-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-287-297">
   <w.rf>
    <LM>w#w-287-297</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t644-9">
   <w.rf>
    <LM>w#w-d1t644-9</LM>
   </w.rf>
   <form>červnu</form>
   <lemma>červen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m124-d1t644-11">
   <w.rf>
    <LM>w#w-d1t644-11</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t644-12">
   <w.rf>
    <LM>w#w-d1t644-12</LM>
   </w.rf>
   <form>koncem</form>
   <lemma>konec</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m124-d1t644-14">
   <w.rf>
    <LM>w#w-d1t644-14</LM>
   </w.rf>
   <form>školního</form>
   <lemma>školní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m124-d1t644-15">
   <w.rf>
    <LM>w#w-d1t644-15</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m124-d-m-d1e633-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e633-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e645-x2">
  <m id="m124-d1t648-1">
   <w.rf>
    <LM>w#w-d1t648-1</LM>
   </w.rf>
   <form>Jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t648-2">
   <w.rf>
    <LM>w#w-d1t648-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m124-d1t648-3">
   <w.rf>
    <LM>w#w-d1t648-3</LM>
   </w.rf>
   <form>vepředu</form>
   <lemma>vepředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1e645-x2-299">
   <w.rf>
    <LM>w#w-d1e645-x2-299</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t648-4">
   <w.rf>
    <LM>w#w-d1t648-4</LM>
   </w.rf>
   <form>či</form>
   <lemma>či-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t648-5">
   <w.rf>
    <LM>w#w-d1t648-5</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d-id94240-punct">
   <w.rf>
    <LM>w#w-d-id94240-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e649-x2">
  <m id="m124-d1t652-1">
   <w.rf>
    <LM>w#w-d1t652-1</LM>
   </w.rf>
   <form>Obojí</form>
   <lemma>obojí</lemma>
   <tag>CdXP1----------</tag>
  </m>
  <m id="m124-d-id94317-punct">
   <w.rf>
    <LM>w#w-d-id94317-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t652-3">
   <w.rf>
    <LM>w#w-d1t652-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t652-4">
   <w.rf>
    <LM>w#w-d1t652-4</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t652-5">
   <w.rf>
    <LM>w#w-d1t652-5</LM>
   </w.rf>
   <form>vepředu</form>
   <lemma>vepředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d-id94372-punct">
   <w.rf>
    <LM>w#w-d-id94372-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t652-7">
   <w.rf>
    <LM>w#w-d1t652-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t652-8">
   <w.rf>
    <LM>w#w-d1t652-8</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m124-d1t652-9">
   <w.rf>
    <LM>w#w-d1t652-9</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m124-d1t652-10">
   <w.rf>
    <LM>w#w-d1t652-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m124-d1t652-11">
   <w.rf>
    <LM>w#w-d1t652-11</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m124-d1t652-12">
   <w.rf>
    <LM>w#w-d1t652-12</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t652-13">
   <w.rf>
    <LM>w#w-d1t652-13</LM>
   </w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m124-d1t652-14">
   <w.rf>
    <LM>w#w-d1t652-14</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t652-15">
   <w.rf>
    <LM>w#w-d1t652-15</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m124-d-id94521-punct">
   <w.rf>
    <LM>w#w-d-id94521-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t652-17">
   <w.rf>
    <LM>w#w-d1t652-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t652-19">
   <w.rf>
    <LM>w#w-d1t652-19</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m124-d1t652-20">
   <w.rf>
    <LM>w#w-d1t652-20</LM>
   </w.rf>
   <form>vhodnější</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m124-d-id94592-punct">
   <w.rf>
    <LM>w#w-d-id94592-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t652-22">
   <w.rf>
    <LM>w#w-d1t652-22</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t652-23">
   <w.rf>
    <LM>w#w-d1t652-23</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m124-d1t652-25">
   <w.rf>
    <LM>w#w-d1t652-25</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t652-24">
   <w.rf>
    <LM>w#w-d1t652-24</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m124-d1e649-x2-305">
   <w.rf>
    <LM>w#w-d1e649-x2-305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-306">
  <m id="m124-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d1t654-3">
   <w.rf>
    <LM>w#w-d1t654-3</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m124-d1t654-4">
   <w.rf>
    <LM>w#w-d1t654-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t654-5">
   <w.rf>
    <LM>w#w-d1t654-5</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS7----------</tag>
  </m>
  <m id="m124-d1t654-6">
   <w.rf>
    <LM>w#w-d1t654-6</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m124-d-id94771-punct">
   <w.rf>
    <LM>w#w-d-id94771-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t654-8">
   <w.rf>
    <LM>w#w-d1t654-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t654-9">
   <w.rf>
    <LM>w#w-d1t654-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m124-d1t654-10">
   <w.rf>
    <LM>w#w-d1t654-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t654-11">
   <w.rf>
    <LM>w#w-d1t654-11</LM>
   </w.rf>
   <form>střídaly</form>
   <lemma>střídat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m124-d-m-d1e649-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e649-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e655-x2">
  <m id="m124-d1t658-1">
   <w.rf>
    <LM>w#w-d1t658-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t658-2">
   <w.rf>
    <LM>w#w-d1t658-2</LM>
   </w.rf>
   <form>vodáctví</form>
   <lemma>vodáctví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m124-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m124-d-id94941-punct">
   <w.rf>
    <LM>w#w-d-id94941-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e660-x2">
  <m id="m124-d1t663-1">
   <w.rf>
    <LM>w#w-d1t663-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t663-2">
   <w.rf>
    <LM>w#w-d1t663-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t663-3">
   <w.rf>
    <LM>w#w-d1t663-3</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t663-4">
   <w.rf>
    <LM>w#w-d1t663-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t663-5">
   <w.rf>
    <LM>w#w-d1t663-5</LM>
   </w.rf>
   <form>rozumem</form>
   <lemma>rozum</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m124-d-id95080-punct">
   <w.rf>
    <LM>w#w-d-id95080-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t663-7">
   <w.rf>
    <LM>w#w-d1t663-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t663-8">
   <w.rf>
    <LM>w#w-d1t663-8</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m124-d1e660-x2-312">
   <w.rf>
    <LM>w#w-d1e660-x2-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-313">
  <m id="m124-d1t665-1">
   <w.rf>
    <LM>w#w-d1t665-1</LM>
   </w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t665-2">
   <w.rf>
    <LM>w#w-d1t665-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t665-4">
   <w.rf>
    <LM>w#w-d1t665-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t665-3">
   <w.rf>
    <LM>w#w-d1t665-3</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t665-5">
   <w.rf>
    <LM>w#w-d1t665-5</LM>
   </w.rf>
   <form>umět</form>
   <lemma>umět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m124-313-314">
   <w.rf>
    <LM>w#w-313-314</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t667-1">
   <w.rf>
    <LM>w#w-d1t667-1</LM>
   </w.rf>
   <form>nejde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m124-d1t667-2">
   <w.rf>
    <LM>w#w-d1t667-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t667-3">
   <w.rf>
    <LM>w#w-d1t667-3</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t667-4">
   <w.rf>
    <LM>w#w-d1t667-4</LM>
   </w.rf>
   <form>tréninku</form>
   <lemma>trénink</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m124-313-315">
   <w.rf>
    <LM>w#w-313-315</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-316">
  <m id="m124-d1t669-4">
   <w.rf>
    <LM>w#w-d1t669-4</LM>
   </w.rf>
   <form>Základní</form>
   <lemma>základní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m124-d1t669-5">
   <w.rf>
    <LM>w#w-d1t669-5</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m124-d1t669-2">
   <w.rf>
    <LM>w#w-d1t669-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t669-1">
   <w.rf>
    <LM>w#w-d1t669-1</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t669-6">
   <w.rf>
    <LM>w#w-d1t669-6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m124-d1t669-7">
   <w.rf>
    <LM>w#w-d1t669-7</LM>
   </w.rf>
   <form>naučit</form>
   <lemma>naučit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m124-316-319">
   <w.rf>
    <LM>w#w-316-319</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t669-8">
   <w.rf>
    <LM>w#w-d1t669-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t669-9">
   <w.rf>
    <LM>w#w-d1t669-9</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t669-10">
   <w.rf>
    <LM>w#w-d1t669-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m124-d1t669-11">
   <w.rf>
    <LM>w#w-d1t669-11</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m124-d-id95476-punct">
   <w.rf>
    <LM>w#w-d-id95476-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t669-13">
   <w.rf>
    <LM>w#w-d1t669-13</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t669-14">
   <w.rf>
    <LM>w#w-d1t669-14</LM>
   </w.rf>
   <form>neriskuje</form>
   <lemma>riskovat</lemma>
   <tag>VB-S---3P-NAB--</tag>
  </m>
  <m id="m124-d1t669-15">
   <w.rf>
    <LM>w#w-d1t669-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t669-16">
   <w.rf>
    <LM>w#w-d1t669-16</LM>
   </w.rf>
   <form>zbytečně</form>
   <lemma>zbytečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t669-17">
   <w.rf>
    <LM>w#w-d1t669-17</LM>
   </w.rf>
   <form>vysokých</form>
   <lemma>vysoký</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m124-d1t669-18">
   <w.rf>
    <LM>w#w-d1t669-18</LM>
   </w.rf>
   <form>vln</form>
   <lemma>vlna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m124-d1t669-19">
   <w.rf>
    <LM>w#w-d1t669-19</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t669-20">
   <w.rf>
    <LM>w#w-d1t669-20</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m124-d1t669-21">
   <w.rf>
    <LM>w#w-d1t669-21</LM>
   </w.rf>
   <form>zbytečně</form>
   <lemma>zbytečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m124-d1t669-22">
   <w.rf>
    <LM>w#w-d1t669-22</LM>
   </w.rf>
   <form>nebezpečných</form>
   <lemma>bezpečný</lemma>
   <tag>AAIP2----1N----</tag>
  </m>
  <m id="m124-d1t669-23">
   <w.rf>
    <LM>w#w-d1t669-23</LM>
   </w.rf>
   <form>jezů</form>
   <lemma>jez</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m124-d-id95655-punct">
   <w.rf>
    <LM>w#w-d-id95655-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m124-d1t669-26">
   <w.rf>
    <LM>w#w-d1t669-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m124-d1t669-27">
   <w.rf>
    <LM>w#w-d1t669-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t669-28">
   <w.rf>
    <LM>w#w-d1t669-28</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m124-d1t669-29">
   <w.rf>
    <LM>w#w-d1t669-29</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m124-d-m-d1e660-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e660-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e670-x2">
  <m id="m124-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m124-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m124-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m124-d1t673-4">
   <w.rf>
    <LM>w#w-d1t673-4</LM>
   </w.rf>
   <form>vodáctví</form>
   <lemma>vodáctví</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m124-d1t673-5">
   <w.rf>
    <LM>w#w-d1t673-5</LM>
   </w.rf>
   <form>přitahuje</form>
   <lemma>přitahovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d-id95871-punct">
   <w.rf>
    <LM>w#w-d-id95871-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e674-x2">
  <m id="m124-d1t677-5">
   <w.rf>
    <LM>w#w-d1t677-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m124-d1t677-6">
   <w.rf>
    <LM>w#w-d1t677-6</LM>
   </w.rf>
   <form>kamarádské</form>
   <lemma>kamarádský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m124-d1t677-7">
   <w.rf>
    <LM>w#w-d1t677-7</LM>
   </w.rf>
   <form>ovzduší</form>
   <lemma>ovzduší</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m124-d1t681-1">
   <w.rf>
    <LM>w#w-d1t681-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t681-2">
   <w.rf>
    <LM>w#w-d1t681-2</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m124-d1t681-4">
   <w.rf>
    <LM>w#w-d1t681-4</LM>
   </w.rf>
   <form>kontakt</form>
   <lemma>kontakt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m124-d1t681-5">
   <w.rf>
    <LM>w#w-d1t681-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m124-d1t681-6">
   <w.rf>
    <LM>w#w-d1t681-6</LM>
   </w.rf>
   <form>vodou</form>
   <lemma>voda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m124-d1t681-7">
   <w.rf>
    <LM>w#w-d1t681-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m124-d1t681-8">
   <w.rf>
    <LM>w#w-d1t681-8</LM>
   </w.rf>
   <form>přírodou</form>
   <lemma>příroda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m124-d1t681-9">
   <w.rf>
    <LM>w#w-d1t681-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m124-d1t681-10">
   <w.rf>
    <LM>w#w-d1t681-10</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m124-d-m-d1e674-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e674-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-d1e682-x2">
  <m id="m124-d1t685-1">
   <w.rf>
    <LM>w#w-d1t685-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m124-d1e682-x2-322">
   <w.rf>
    <LM>w#w-d1e682-x2-322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m124-323">
  <m id="m124-d1t687-1">
   <w.rf>
    <LM>w#w-d1t687-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m124-d1t687-2">
   <w.rf>
    <LM>w#w-d1t687-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m124-d1t687-3">
   <w.rf>
    <LM>w#w-d1t687-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m124-d1t687-4">
   <w.rf>
    <LM>w#w-d1t687-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m124-d-id96367-punct">
   <w.rf>
    <LM>w#w-d-id96367-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
