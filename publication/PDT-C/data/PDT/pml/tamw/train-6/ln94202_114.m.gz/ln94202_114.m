<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94202_114.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94202-114-p1s1">
  <m id="m-ln94202-114-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p1s1w1</LM>
   </w.rf>
   <form>Fotbalový</form>
   <lemma>fotbalový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94202-114-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p1s1w2</LM>
   </w.rf>
   <form>servis</form>
   <lemma>servis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94202-114-p16s16">
  <m id="m-ln94202-114-p16s16w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p16s16w1</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-ln94202-114-p16s16w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p16s16w2</LM>
   </w.rf>
   <form>utkání</form>
   <lemma>utkání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94202-114-p16s16w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p16s16w3</LM>
   </w.rf>
   <form>španělského</form>
   <lemma>španělský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94202-114-p16s16w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p16s16w4</LM>
   </w.rf>
   <form>Superpoháru</form>
   <lemma>Superpohár_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94202-114-p16s16w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94202-114-p16s16w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
