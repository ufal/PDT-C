<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="cmpr9415_054.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-cmpr9415-054-p2s1">
  <m id="m-cmpr9415-054-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w2</LM>
   </w.rf>
   <form>zaplatí</form>
   <lemma>zaplatit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w3</LM>
   </w.rf>
   <form>Švýcar</form>
   <lemma>Švýcar_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w5</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w6</LM>
   </w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w7</LM>
   </w.rf>
   <form>telefonování</form>
   <lemma>telefonování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w8</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w10</LM>
   </w.rf>
   <form>CHF</form>
   <lemma>CHF-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-cmpr9415-054-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p2s1w11</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-cmpr9415-054-p5s1">
  <m id="m-cmpr9415-054-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p5s1w1</LM>
   </w.rf>
   <form>Velké</form>
   <lemma>velký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-cmpr9415-054-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p5s1w2</LM>
   </w.rf>
   <form>Británie</form>
   <lemma>Británie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-cmpr9415-054-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-cmpr9415-054-p5s1w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
