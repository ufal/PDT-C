<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94210_123.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94210-123-p1s1">
  <m id="m-ln94210-123-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p1s1w1</LM>
   </w.rf>
   <form>Výsledkový</form>
   <lemma>výsledkový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94210-123-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p1s1w2</LM>
   </w.rf>
   <form>servis</form>
   <lemma>servis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94210-123-p5s2">
  <m id="m-ln94210-123-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w1</LM>
   </w.rf>
   <form>Naše</form>
   <lemma>náš</lemma>
   <tag>PSHP1-P1-------</tag>
  </m>
  <m id="m-ln94210-123-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w2</LM>
   </w.rf>
   <form>reprezentantky</form>
   <lemma>reprezentantka_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94210-123-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w3</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94210-123-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w4</LM>
   </w.rf>
   <form>postupují</form>
   <lemma>postupovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94210-123-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94210-123-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w6</LM>
   </w.rf>
   <form>semifinále</form>
   <lemma>semifinále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94210-123-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-123-p5s2w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
