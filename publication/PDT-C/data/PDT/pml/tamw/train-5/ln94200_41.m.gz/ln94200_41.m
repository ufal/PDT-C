<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94200_41.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94200-41-p1s1">
  <m id="m-ln94200-41-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w1</LM>
   </w.rf>
   <form>Soukromé</form>
   <lemma>soukromý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94200-41-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w2</LM>
   </w.rf>
   <form>zemědělské</form>
   <lemma>zemědělský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94200-41-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w3</LM>
   </w.rf>
   <form>farmy</form>
   <lemma>farma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94200-41-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94200-41-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94200-41-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94200-41-p1s1w6</LM>
   </w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
</mdata>
