<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf930709_054.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf930709-054-p1s1">
  <m id="m-mf930709-054-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-mf930709-054-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w3</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m-mf930709-054-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w5</LM>
   </w.rf>
   <form>Indie</form>
   <lemma>Indie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p1s1w7</LM>
   </w.rf>
   <form>Kouřimi</form>
   <lemma>Kouřim_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s1">
  <m id="m-mf930709-054-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w1</LM>
   </w.rf>
   <form>Natáčení</form>
   <lemma>natáčení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w2</LM>
   </w.rf>
   <form>televizního</form>
   <lemma>televizní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w3</LM>
   </w.rf>
   <form>seriálu</form>
   <lemma>seriál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w4</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w6</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w8</LM>
   </w.rf>
   <form>inspirovaného</form>
   <lemma>inspirovaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w9</LM>
   </w.rf>
   <form>stejnojmenným</form>
   <lemma>stejnojmenný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w10</LM>
   </w.rf>
   <form>románem</form>
   <lemma>román</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w11</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w12</LM>
   </w.rf>
   <form>Poláčka</form>
   <lemma>Poláček_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w14</LM>
   </w.rf>
   <form>zahájí</form>
   <lemma>zahájit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w15</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w17</LM>
   </w.rf>
   <form>července</form>
   <lemma>červenec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w18</LM>
   </w.rf>
   <form>režisér</form>
   <lemma>režisér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w19</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w20</LM>
   </w.rf>
   <form>Smyczek</form>
   <lemma>Smyczek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s1w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s2">
  <m id="m-mf930709-054-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w1</LM>
   </w.rf>
   <form>Zeptali</form>
   <lemma>zeptat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS2--3-------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w6</LM>
   </w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w9</LM>
   </w.rf>
   <form>vybral</form>
   <lemma>vybrat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w10</LM>
   </w.rf>
   <form>vhodnou</form>
   <lemma>vhodný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w11</LM>
   </w.rf>
   <form>lokalitu</form>
   <lemma>lokalita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w12</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w13</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w14</LM>
   </w.rf>
   <form>Převážnou</form>
   <lemma>převážný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w15</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w16</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w17</LM>
   </w.rf>
   <form>točit</form>
   <lemma>točit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w19</LM>
   </w.rf>
   <form>městečku</form>
   <lemma>městečko</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w20</LM>
   </w.rf>
   <form>Kouřim</form>
   <lemma>Kouřim_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w22</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w23</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w24</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m-mf930709-054-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w25</LM>
   </w.rf>
   <form>názoru</form>
   <lemma>názor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w26</LM>
   </w.rf>
   <form>odpovídá</form>
   <lemma>odpovídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w27</LM>
   </w.rf>
   <form>laskavé</form>
   <lemma>laskavý</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w28</LM>
   </w.rf>
   <form>poláčkovské</form>
   <lemma>poláčkovský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w29</LM>
   </w.rf>
   <form>atmosféře</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s2w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s3">
  <m id="m-mf930709-054-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w1</LM>
   </w.rf>
   <form>Trochu</form>
   <lemma>trocha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w2</LM>
   </w.rf>
   <form>problémů</form>
   <lemma>problém</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w6</LM>
   </w.rf>
   <form>přepisem</form>
   <lemma>přepis</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w8</LM>
   </w.rf>
   <form>respektive</form>
   <lemma>respektive</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w9</LM>
   </w.rf>
   <form>zjednodušením</form>
   <lemma>zjednodušení_^(*2t)_(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w10</LM>
   </w.rf>
   <form>snových</form>
   <lemma>snový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w11</LM>
   </w.rf>
   <form>pasáží</form>
   <lemma>pasáž</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w14</LM>
   </w.rf>
   <form>nichž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P4XP6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w16</LM>
   </w.rf>
   <form>hrdinové</form>
   <lemma>hrdina</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w17</LM>
   </w.rf>
   <form>ocitají</form>
   <lemma>ocitat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w19</LM>
   </w.rf>
   <form>indických</form>
   <lemma>indický</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w20</LM>
   </w.rf>
   <form>reáliích</form>
   <lemma>reálie</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s3w22</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s4">
  <m id="m-mf930709-054-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s4w1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-mf930709-054-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s4w2</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s4w3</LM>
   </w.rf>
   <form>herecké</form>
   <lemma>herecký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s4w4</LM>
   </w.rf>
   <form>obsazení</form>
   <lemma>obsazení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s4w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s5">
  <m id="m-mf930709-054-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w2</LM>
   </w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w3</LM>
   </w.rf>
   <form>dětských</form>
   <lemma>dětský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w4</LM>
   </w.rf>
   <form>představitelů</form>
   <lemma>představitel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w7</LM>
   </w.rf>
   <form>rolích</form>
   <lemma>role_^(svitek_poslání_pozemek)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w8</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w9</LM>
   </w.rf>
   <form>Petra</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w10</LM>
   </w.rf>
   <form>Bajzy</form>
   <lemma>Bajza_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w11</LM>
   </w.rf>
   <form>objeví</form>
   <lemma>objevit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w12</LM>
   </w.rf>
   <form>Oldřich</form>
   <lemma>Oldřich_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w13</LM>
   </w.rf>
   <form>Navrátil</form>
   <lemma>Navrátil_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w15</LM>
   </w.rf>
   <form>Dagmar</form>
   <lemma>Dagmar_;Y_;m</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w16</LM>
   </w.rf>
   <form>Veškrnová</form>
   <lemma>Veškrnová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w18</LM>
   </w.rf>
   <form>zajímavou</form>
   <lemma>zajímavý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w19</LM>
   </w.rf>
   <form>postavu</form>
   <lemma>postava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w20</LM>
   </w.rf>
   <form>ztvární</form>
   <lemma>ztvárnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w21</LM>
   </w.rf>
   <form>Jiřina</form>
   <lemma>Jiřina_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w22</LM>
   </w.rf>
   <form>Jirásková</form>
   <lemma>Jirásková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w24</LM>
   </w.rf>
   <form>legendárního</form>
   <lemma>legendární</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w25</LM>
   </w.rf>
   <form>pana</form>
   <lemma>pan</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w26</LM>
   </w.rf>
   <form>Zilvara</form>
   <lemma>Zilvar_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w27</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w28</LM>
   </w.rf>
   <form>chudobince</form>
   <lemma>chudobinec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w29</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s5w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w30</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-mf930709-054-p2s5w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w31</LM>
   </w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w32</LM>
   </w.rf>
   <form>Pecha</form>
   <lemma>Pecha_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s5w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s5w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s5w35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s6">
  <m id="m-mf930709-054-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w5</LM>
   </w.rf>
   <form>získal</form>
   <lemma>získat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-mf930709-054-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w6</LM>
   </w.rf>
   <form>optimální</form>
   <lemma>optimální</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w7</LM>
   </w.rf>
   <form>představitele</form>
   <lemma>představitel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w9</LM>
   </w.rf>
   <form>nicméně</form>
   <lemma>nicméně</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w10</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w11</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w12</LM>
   </w.rf>
   <form>dalším</form>
   <lemma>další</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w13</LM>
   </w.rf>
   <form>natáčení</form>
   <lemma>natáčení_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w14</LM>
   </w.rf>
   <form>zjišťuji</form>
   <lemma>zjišťovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-mf930709-054-p2s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w16</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w17</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w18</LM>
   </w.rf>
   <form>někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w19</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w20</LM>
   </w.rf>
   <form>chybějí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w21</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w22</LM>
   </w.rf>
   <form>pánové</form>
   <lemma>pán</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w23</LM>
   </w.rf>
   <form>Jegorov</form>
   <lemma>Jegorov_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w24</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w25</LM>
   </w.rf>
   <form>Štibich</form>
   <lemma>Štibich_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s6w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s6w28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s7">
  <m id="m-mf930709-054-p2s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w1</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930709-054-p2s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w2</LM>
   </w.rf>
   <form>mne</form>
   <lemma>já</lemma>
   <tag>PP-S4--1-------</tag>
  </m>
  <m id="m-mf930709-054-p2s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w3</LM>
   </w.rf>
   <form>znamenali</form>
   <lemma>znamenat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w4</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-mf930709-054-p2s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w5</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w6</LM>
   </w.rf>
   <form>maskoty</form>
   <lemma>maskot</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-mf930709-054-p2s7w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w7</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s7w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s7w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930709-054-p2s8">
  <m id="m-mf930709-054-p2s8w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w1</LM>
   </w.rf>
   <form>Stýská</form>
   <lemma>stýskat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-mf930709-054-p2s8w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-mf930709-054-p2s8w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-mf930709-054-p2s8w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf930709-054-p2s8w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w5</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP6--3-------</tag>
  </m>
  <m id="m-mf930709-054-p2s8w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930709-054-p2s8w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930709-054-p2s8w7</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
