<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94105_103.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94105-103-p1s1">
  <m id="m-lnd94105-103-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-103-p1s1w1</LM>
   </w.rf>
   <form>Bukač</form>
   <lemma>Bukač_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94105-103-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-103-p1s1w2</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94105-103-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-103-p1s1w3</LM>
   </w.rf>
   <form>zůstává</form>
   <lemma>zůstávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
 </s>
</mdata>
