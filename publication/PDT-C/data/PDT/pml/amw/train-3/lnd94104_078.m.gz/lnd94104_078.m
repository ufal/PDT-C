<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94104_078.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94104-078-p1s1A">
  <m id="m-lnd94104-078-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw1</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw6</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw7</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw8</LM>
   </w.rf>
   <form>LN</form>
   <lemma>LN-1_;m_^(Lidové_noviny)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw9</LM>
   </w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw11</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw13</LM>
   </w.rf>
   <form>1994</form>
   <lemma>1994</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Aw14</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s1B">
  <m id="m-lnd94104-078-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw2</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw4</LM>
   </w.rf>
   <form>pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw5</LM>
   </w.rf>
   <form>Just</form>
   <lemma>Just_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw6</LM>
   </w.rf>
   <form>napsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s1Bw7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s2">
  <m id="m-lnd94104-078-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w1</LM>
   </w.rf>
   <form>Mohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w2</LM>
   </w.rf>
   <form>posloužit</form>
   <lemma>posloužit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w3</LM>
   </w.rf>
   <form>příběhem</form>
   <lemma>příběh</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w5</LM>
   </w.rf>
   <form>pitoresknějším</form>
   <lemma>pitoreskní</lemma>
   <tag>AAIS7----2A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w7</LM>
   </w.rf>
   <form>pověstí</form>
   <lemma>pověst</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w9</LM>
   </w.rf>
   <form>blahodárném</form>
   <lemma>blahodárný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w10</LM>
   </w.rf>
   <form>působení</form>
   <lemma>působení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w11</LM>
   </w.rf>
   <form>Pražské</form>
   <lemma>pražský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w12</LM>
   </w.rf>
   <form>správy</form>
   <lemma>správa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w13</LM>
   </w.rf>
   <form>sociálního</form>
   <lemma>sociální</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w14</LM>
   </w.rf>
   <form>zabezpečení</form>
   <lemma>zabezpečení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s2w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s3">
  <m id="m-lnd94104-078-p1s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w1</LM>
   </w.rf>
   <form>Maje</form>
   <lemma>mít</lemma>
   <tag>VeYS------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w3</LM>
   </w.rf>
   <form>r</form>
   <lemma>rok</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w5</LM>
   </w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w6</LM>
   </w.rf>
   <form>živnost</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w8</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w10</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w11</LM>
   </w.rf>
   <form>manželky</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w13</LM>
   </w.rf>
   <form>čtyř</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w14</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w15</LM>
   </w.rf>
   <form>živila</form>
   <lemma>živit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w17</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w18</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w19</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w20</LM>
   </w.rf>
   <form>skromně</form>
   <lemma>skromně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w22</LM>
   </w.rf>
   <form>platil</form>
   <lemma>platit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w23</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w24</LM>
   </w.rf>
   <form>přiměřeně</form>
   <lemma>přiměřeně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w25</LM>
   </w.rf>
   <form>tučné</form>
   <lemma>tučný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w26</LM>
   </w.rf>
   <form>pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s3w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s4">
  <m id="m-lnd94104-078-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w1</LM>
   </w.rf>
   <form>Začátkem</form>
   <lemma>začátek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w3</LM>
   </w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w5</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w6</LM>
   </w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w8</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w10</LM>
   </w.rf>
   <form>živnost</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w11</LM>
   </w.rf>
   <form>provozoval</form>
   <lemma>provozovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w12</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w13</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w14</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w15</LM>
   </w.rf>
   <form>volném</form>
   <lemma>volný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w16</LM>
   </w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w18</LM>
   </w.rf>
   <form>doplňkový</form>
   <lemma>doplňkový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w19</LM>
   </w.rf>
   <form>zdroj</form>
   <lemma>zdroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w20</LM>
   </w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s4w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s5">
  <m id="m-lnd94104-078-p1s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w1</LM>
   </w.rf>
   <form>Pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w3</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w4</LM>
   </w.rf>
   <form>nutno</form>
   <lemma>nutný</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w5</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w6</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w7</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w8</LM>
   </w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w10</LM>
   </w.rf>
   <form>minulého</form>
   <lemma>minulý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w11</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w13</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w15</LM>
   </w.rf>
   <form>náhle</form>
   <lemma>náhle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w16</LM>
   </w.rf>
   <form>platil</form>
   <lemma>platit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w18</LM>
   </w.rf>
   <form>pojistném</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w19</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w21</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w22</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w23</LM>
   </w.rf>
   <form>živnost</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w24</LM>
   </w.rf>
   <form>vynášela</form>
   <lemma>vynášet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s5w25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s7">
  <m id="m-lnd94104-078-p1s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w1</LM>
   </w.rf>
   <form>Kladné</form>
   <lemma>kladný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w2</LM>
   </w.rf>
   <form>rozhodnutí</form>
   <lemma>rozhodnutí_^(*3out)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w4</LM>
   </w.rf>
   <form>kalendářní</form>
   <lemma>kalendářní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w5</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w6</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w8</LM>
   </w.rf>
   <form>říjen</form>
   <lemma>říjen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w10</LM>
   </w.rf>
   <form>listopad</form>
   <lemma>listopad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w12</LM>
   </w.rf>
   <form>datováno</form>
   <lemma>datovat</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w13</LM>
   </w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w15</LM>
   </w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w17</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w18</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w19</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w20</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w21</LM>
   </w.rf>
   <form>jasné</form>
   <lemma>jasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w23</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w24</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w25</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w26</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w27</LM>
   </w.rf>
   <form>říjen</form>
   <lemma>říjen</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w28</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w29</LM>
   </w.rf>
   <form>nepoužitelné</form>
   <lemma>použitelný_^(*6ít)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w31</LM>
   </w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w32</LM>
   </w.rf>
   <form>zatímco</form>
   <lemma>zatímco</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w33</LM>
   </w.rf>
   <form>úřad</form>
   <lemma>úřad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w34</LM>
   </w.rf>
   <form>zvažoval</form>
   <lemma>zvažovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w35</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w36</LM>
   </w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w37</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w38</LM>
   </w.rf>
   <form>vyhoví</form>
   <lemma>vyhovět</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w39</LM>
   </w.rf>
   <form>či</form>
   <lemma>či-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w40</LM>
   </w.rf>
   <form>nikoliv</form>
   <lemma>nikoliv_,s_^(^DD**nikoli)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w42</LM>
   </w.rf>
   <form>termíny</form>
   <lemma>termín</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w43</LM>
   </w.rf>
   <form>splatnosti</form>
   <lemma>splatnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w44</LM>
   </w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>CnXP2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w45</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w46</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w47</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w48</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w49</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w50</LM>
   </w.rf>
   <form>předchozího</form>
   <lemma>předchozí</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w51</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w52</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w53</LM>
   </w.rf>
   <form>uplynuly</form>
   <lemma>uplynout</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w54</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w55</LM>
   </w.rf>
   <form>pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w56</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w57</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w58</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w59</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w60</LM>
   </w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w61</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w62</LM>
   </w.rf>
   <form>nemaje</form>
   <lemma>mít</lemma>
   <tag>VeYS------N-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w63</LM>
   </w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w64</LM>
   </w.rf>
   <form>kýženého</form>
   <lemma>kýžený</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w65">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w65</LM>
   </w.rf>
   <form>souhlasu</form>
   <lemma>souhlas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w66">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w66</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w67">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w67</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w68">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w68</LM>
   </w.rf>
   <form>původní</form>
   <lemma>původní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w69">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w69</LM>
   </w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s7w70">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s7w70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s8">
  <m id="m-lnd94104-078-p1s8w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w1</LM>
   </w.rf>
   <form>Nu</form>
   <lemma>nu</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w2</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrá-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w4</LM>
   </w.rf>
   <form>šiml</form>
   <lemma>šiml</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w6</LM>
   </w.rf>
   <form>přehlédl</form>
   <lemma>přehlédnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w8</LM>
   </w.rf>
   <form>kalendáři</form>
   <lemma>kalendář</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w11</LM>
   </w.rf>
   <form>koneckonců</form>
   <lemma>koneckonců</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w12</LM>
   </w.rf>
   <form>uznal</form>
   <lemma>uznat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w15</LM>
   </w.rf>
   <form>nemohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI-1</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w16</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w17</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w18</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w19</LM>
   </w.rf>
   <form>vydělávám</form>
   <lemma>vydělávat_^(*4at)</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w22</LM>
   </w.rf>
   <form>alespoň</form>
   <lemma>alespoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w24</LM>
   </w.rf>
   <form>listopad</form>
   <lemma>listopad</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w25</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w26</LM>
   </w.rf>
   <form>zbavil</form>
   <lemma>zbavit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w27</LM>
   </w.rf>
   <form>povinnosti</form>
   <lemma>povinnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w28</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w29</LM>
   </w.rf>
   <form>bezúročně</form>
   <lemma>bezúročně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w30</LM>
   </w.rf>
   <form>úvěrovat</form>
   <lemma>úvěrovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s8w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s8w31</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s9">
  <m id="m-lnd94104-078-p1s9w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w2</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w3</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w5</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w6</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w7</LM>
   </w.rf>
   <form>podat</form>
   <lemma>podat_^(něco_[někomu]_[někam])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w8</LM>
   </w.rf>
   <form>žádost</form>
   <lemma>žádost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w9</LM>
   </w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s9w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s9w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s10">
  <m id="m-lnd94104-078-p1s10w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w1</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w2</LM>
   </w.rf>
   <form>troše</form>
   <lemma>trocha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w3</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w5</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w6</LM>
   </w.rf>
   <form>schválí</form>
   <lemma>schválit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w7</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w8</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w9</LM>
   </w.rf>
   <form>vánoc</form>
   <lemma>vánoce_,i_^(^DS**Vánoce)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w11</LM>
   </w.rf>
   <form>počítám</form>
   <lemma>počítat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s10w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s10w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s11">
  <m id="m-lnd94104-078-p1s11w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w2</LM>
   </w.rf>
   <form>čemu</form>
   <lemma>co-1</lemma>
   <tag>PQ--3----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w4</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w5</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w8</LM>
   </w.rf>
   <form>prosinec</form>
   <lemma>prosinec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w9</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w10</LM>
   </w.rf>
   <form>zaplatit</form>
   <lemma>zaplatit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w12</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w14</LM>
   </w.rf>
   <form>listopadu</form>
   <lemma>listopad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s11w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s11w15</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s12">
  <m id="m-lnd94104-078-p1s12w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w1</LM>
   </w.rf>
   <form>Nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w2</LM>
   </w.rf>
   <form>očividně</form>
   <lemma>očividně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w3</LM>
   </w.rf>
   <form>přetížený</form>
   <lemma>přetížený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w4</LM>
   </w.rf>
   <form>úřad</form>
   <lemma>úřad</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w5</LM>
   </w.rf>
   <form>zatěžovat</form>
   <lemma>zatěžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w6</LM>
   </w.rf>
   <form>dalšími</form>
   <lemma>další</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w7</LM>
   </w.rf>
   <form>suplikami</form>
   <lemma>suplika</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w9</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w10</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w11</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w12</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w13</LM>
   </w.rf>
   <form>průtahům</form>
   <lemma>průtah</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w14</LM>
   </w.rf>
   <form>předplaceno</form>
   <lemma>předplatit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w16</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w17</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w18</LM>
   </w.rf>
   <form>dopředu</form>
   <lemma>dopředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w20</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w21</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w22</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w23</LM>
   </w.rf>
   <form>nemusel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w24</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w25</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w26</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w27</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w28</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w29</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w30</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w31</LM>
   </w.rf>
   <form>tisíc</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w32</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w33</LM>
   </w.rf>
   <form>vracet</form>
   <lemma>vracet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w34</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w35</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w36</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w37</LM>
   </w.rf>
   <form>daňového</form>
   <lemma>daňový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w38</LM>
   </w.rf>
   <form>přiznání</form>
   <lemma>přiznání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w39</LM>
   </w.rf>
   <form>zjistí</form>
   <lemma>zjistit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w40</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSYP4-S1------1</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w41</LM>
   </w.rf>
   <form>skutečné</form>
   <lemma>skutečný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w42</LM>
   </w.rf>
   <form>příjmy</form>
   <lemma>příjem</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w43</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w44</LM>
   </w.rf>
   <form>našeptává</form>
   <lemma>našeptávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w45</LM>
   </w.rf>
   <form>selský</form>
   <lemma>selský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w46</LM>
   </w.rf>
   <form>rozum</form>
   <lemma>rozum</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s12w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s12w47</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s13">
  <m id="m-lnd94104-078-p1s13w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s13w1</LM>
   </w.rf>
   <form>Chyba</form>
   <lemma>chyba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s13w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s13w2</LM>
   </w.rf>
   <form>lávky</form>
   <lemma>lávka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s13w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s13w3</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s14">
  <m id="m-lnd94104-078-p1s14w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w1</LM>
   </w.rf>
   <form>Selským</form>
   <lemma>selský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w2</LM>
   </w.rf>
   <form>rozumem</form>
   <lemma>rozum</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w4</LM>
   </w.rf>
   <form>úřady</form>
   <lemma>úřad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w5</LM>
   </w.rf>
   <form>neřídí</form>
   <lemma>řídit</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w7</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w9</LM>
   </w.rf>
   <form>řídí</form>
   <lemma>řídit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w10</LM>
   </w.rf>
   <form>předpisy</form>
   <lemma>předpis</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s14w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s14w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s15">
  <m id="m-lnd94104-078-p1s15w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w1</LM>
   </w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w2</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w4</LM>
   </w.rf>
   <form>jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w7</LM>
   </w.rf>
   <form>prosinec</form>
   <lemma>prosinec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w9</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w10</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w11</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w12</LM>
   </w.rf>
   <form>snížení</form>
   <lemma>snížení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w13</LM>
   </w.rf>
   <form>nepožádal</form>
   <lemma>požádat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w15</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w16</LM>
   </w.rf>
   <form>doplatit</form>
   <lemma>doplatit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w17</LM>
   </w.rf>
   <form>pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w19</LM>
   </w.rf>
   <form>nesnížené</form>
   <lemma>snížený_^(*3it)</lemma>
   <tag>AAFS6----1N----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w20</LM>
   </w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w22</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w23</LM>
   </w.rf>
   <form>penále</form>
   <lemma>penále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w24</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w25</LM>
   </w.rf>
   <form>prodlení</form>
   <lemma>prodlení_^(*3ít)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w26</LM>
   </w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w28</LM>
   </w.rf>
   <form>ačkoli</form>
   <lemma>ačkoli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w29</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w30</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w31</LM>
   </w.rf>
   <form>daňového</form>
   <lemma>daňový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w32</LM>
   </w.rf>
   <form>přiznání</form>
   <lemma>přiznání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w33</LM>
   </w.rf>
   <form>tentýž</form>
   <lemma>tentýž</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w34</LM>
   </w.rf>
   <form>úřad</form>
   <lemma>úřad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w35</LM>
   </w.rf>
   <form>dluží</form>
   <lemma>dlužit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w36</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w37</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w38</LM>
   </w.rf>
   <form>tisíc</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s15w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s15w39</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s16">
  <m id="m-lnd94104-078-p1s16w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s16w1</LM>
   </w.rf>
   <form>Vskutku</form>
   <lemma>vskutku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s16w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s16w2</LM>
   </w.rf>
   <form>důvtipné</form>
   <lemma>důvtipný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s16w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s16w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s17">
  <m id="m-lnd94104-078-p1s17w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w1</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w2</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w3</LM>
   </w.rf>
   <form>přeplatku</form>
   <lemma>přeplatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w4</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w5</LM>
   </w.rf>
   <form>dlužné</form>
   <lemma>dlužný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w6</LM>
   </w.rf>
   <form>pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w7</LM>
   </w.rf>
   <form>uhradit</form>
   <lemma>uhradit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w8</LM>
   </w.rf>
   <form>nelze</form>
   <lemma>lze</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w10</LM>
   </w.rf>
   <form>neboť</form>
   <lemma>neboť</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w11</LM>
   </w.rf>
   <form>obojí</form>
   <lemma>obojí</lemma>
   <tag>CdXS1----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w13</LM>
   </w.rf>
   <form>vede</form>
   <lemma>vést</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w15</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w16</LM>
   </w.rf>
   <form>účtech</form>
   <lemma>účet</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w18</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w20</LM>
   </w.rf>
   <form>poučen</form>
   <lemma>poučit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s17w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s17w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s18">
  <m id="m-lnd94104-078-p1s18w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w1</LM>
   </w.rf>
   <form>Jářku</form>
   <lemma>jářku</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w5</LM>
   </w.rf>
   <form>neumějí</form>
   <lemma>umět</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w7</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w9</LM>
   </w.rf>
   <form>neporadí</form>
   <lemma>poradit</lemma>
   <tag>VB-P---3P-NAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w10</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w12</LM>
   </w.rf>
   <form>Všeobecnou</form>
   <lemma>všeobecný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w13</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w14</LM>
   </w.rf>
   <form>pojišťovnou</form>
   <lemma>pojišťovna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w16</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w17</LM>
   </w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w18</LM>
   </w.rf>
   <form>pojistné</form>
   <lemma>pojistné_^(poplatek)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w19</LM>
   </w.rf>
   <form>zálohují</form>
   <lemma>zálohovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w20</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w21</LM>
   </w.rf>
   <form>loňských</form>
   <lemma>loňský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w22</LM>
   </w.rf>
   <form>přeplatků</form>
   <lemma>přeplatek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w23</LM>
   </w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w24</LM>
   </w.rf>
   <form>běžně</form>
   <lemma>běžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s18w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s18w25</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s19">
  <m id="m-lnd94104-078-p1s19w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w2</LM>
   </w.rf>
   <form>vrácení</form>
   <lemma>vrácení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w3</LM>
   </w.rf>
   <form>přeplatku</form>
   <lemma>přeplatek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w5</LM>
   </w.rf>
   <form>požádal</form>
   <lemma>požádat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w6</LM>
   </w.rf>
   <form>koncem</form>
   <lemma>konec</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w7</LM>
   </w.rf>
   <form>února</form>
   <lemma>únor</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-lnd94104-078-p1s19w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s19w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s20">
  <m id="m-lnd94104-078-p1s20w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w2</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w3</LM>
   </w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w5</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w6</LM>
   </w.rf>
   <form>nikde</form>
   <lemma>nikde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s20w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s20w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s21">
  <m id="m-lnd94104-078-p1s21w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w2</LM>
   </w.rf>
   <form>spořitelně</form>
   <lemma>spořitelna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w5</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w6</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w7</LM>
   </w.rf>
   <form>úroky</form>
   <lemma>úrok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w9</LM>
   </w.rf>
   <form>PSSZ</form>
   <lemma>PSSZ-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w10</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w11</LM>
   </w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w13</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w14</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w15</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w16</LM>
   </w.rf>
   <form>napaří</form>
   <lemma>napařit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w17</LM>
   </w.rf>
   <form>penále</form>
   <lemma>penále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s21w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s21w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-078-p1s22">
  <m id="m-lnd94104-078-p1s22w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w1</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-078-p1s22w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w2</LM>
   </w.rf>
   <form>dopisu</form>
   <lemma>dopis</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s22w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w3</LM>
   </w.rf>
   <form>Pavla</form>
   <lemma>Pavel_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s22w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w4</LM>
   </w.rf>
   <form>Mareše</form>
   <lemma>Mareš_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd94104-078-p1s22w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-078-p1s22w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-078-p1s22w6</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
</mdata>
