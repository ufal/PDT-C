<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vesm9211_045.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-vesm9211-045-p1s1">
  <m id="m-vesm9211-045-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w4</LM>
   </w.rf>
   <form>učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w5</LM>
   </w.rf>
   <form>přírodní</form>
   <lemma>přírodní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w6</LM>
   </w.rf>
   <form>vědy</form>
   <lemma>věda</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w7</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w9</LM>
   </w.rf>
   <form>smyslu</form>
   <lemma>smysl</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w10</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP2-P1-------</tag>
  </m>
  <m id="m-vesm9211-045-p1s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p1s1w11</LM>
   </w.rf>
   <form>gymnázií</form>
   <lemma>gymnázium</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p2s1">
  <m id="m-vesm9211-045-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w1</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w4</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w5</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w6</LM>
   </w.rf>
   <form>učíme</form>
   <lemma>učit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w8</LM>
   </w.rf>
   <form>gymnáziích</form>
   <lemma>gymnázium</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w9</LM>
   </w.rf>
   <form>přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w10</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s1w11</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p2s2">
  <m id="m-vesm9211-045-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w2</LM>
   </w.rf>
   <form>humanitních</form>
   <lemma>humanitní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w3</LM>
   </w.rf>
   <form>předmětech</form>
   <lemma>předmět</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w7</LM>
   </w.rf>
   <form>český</form>
   <lemma>český</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w8</LM>
   </w.rf>
   <form>jazyk</form>
   <lemma>jazyk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w10</LM>
   </w.rf>
   <form>dějepis</form>
   <lemma>dějepis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w12</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w13</LM>
   </w.rf>
   <form>nepochybuje</form>
   <lemma>pochybovat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w16</LM>
   </w.rf>
   <form>především</form>
   <lemma>především-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w17</LM>
   </w.rf>
   <form>přispívají</form>
   <lemma>přispívat_^(*4ět)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w18</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w19</LM>
   </w.rf>
   <form>všeobecnému</form>
   <lemma>všeobecný</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w20</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s2w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p2s3">
  <m id="m-vesm9211-045-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w2</LM>
   </w.rf>
   <form>přírodovědných</form>
   <lemma>přírodovědný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w3</LM>
   </w.rf>
   <form>předmětech</form>
   <lemma>předmět</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w5</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w6</LM>
   </w.rf>
   <form>mlčky</form>
   <lemma>mlčky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w7</LM>
   </w.rf>
   <form>uvažuje</form>
   <lemma>uvažovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w9</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w10</LM>
   </w.rf>
   <form>přípravě</form>
   <lemma>příprava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w12</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w13</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w14</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w15</LM>
   </w.rf>
   <form>studenty</form>
   <lemma>student</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s3w16</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p2s4">
  <m id="m-vesm9211-045-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w1</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w2</LM>
   </w.rf>
   <form>význam</form>
   <lemma>význam</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w4</LM>
   </w.rf>
   <form>součásti</form>
   <lemma>součást</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w5</LM>
   </w.rf>
   <form>všeobecného</form>
   <lemma>všeobecný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w6</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w8</LM>
   </w.rf>
   <form>nebere</form>
   <lemma>brát</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w9</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w11</LM>
   </w.rf>
   <form>úvahu</form>
   <lemma>úvaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p2s4w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s1">
  <m id="m-vesm9211-045-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w2</LM>
   </w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w3</LM>
   </w.rf>
   <form>civilizaci</form>
   <lemma>civilizace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w5</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w7</LM>
   </w.rf>
   <form>občan</form>
   <lemma>občan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w8</LM>
   </w.rf>
   <form>setkává</form>
   <lemma>setkávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w10</LM>
   </w.rf>
   <form>tolika</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w11</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w13</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w14</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4XP3----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w15</LM>
   </w.rf>
   <form>moderní</form>
   <lemma>moderní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w16</LM>
   </w.rf>
   <form>přírodní</form>
   <lemma>přírodní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w17</LM>
   </w.rf>
   <form>vědy</form>
   <lemma>věda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w18</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w19</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w20</LM>
   </w.rf>
   <form>říci</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w23</LM>
   </w.rf>
   <form>nedostatek</form>
   <lemma>nedostatek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w24</LM>
   </w.rf>
   <form>přehledu</form>
   <lemma>přehled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w25</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w26</LM>
   </w.rf>
   <form>přírodních</form>
   <lemma>přírodní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w27</LM>
   </w.rf>
   <form>vědách</form>
   <lemma>věda</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w28</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w29</LM>
   </w.rf>
   <form>handicapovat</form>
   <lemma>handicapovat_,s_^(^DD**hendikepovat)</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w30</LM>
   </w.rf>
   <form>kohokoliv</form>
   <lemma>kdokoliv</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w31</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w32</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s1w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s2">
  <m id="m-vesm9211-045-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w1</LM>
   </w.rf>
   <form>Náplň</form>
   <lemma>náplň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w2</LM>
   </w.rf>
   <form>přírodovědných</form>
   <lemma>přírodovědný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w3</LM>
   </w.rf>
   <form>předmětů</form>
   <lemma>předmět</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w4</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w6</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w7</LM>
   </w.rf>
   <form>uzpůsobena</form>
   <lemma>uzpůsobit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w10</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w12</LM>
   </w.rf>
   <form>vybavila</form>
   <lemma>vybavit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w13</LM>
   </w.rf>
   <form>přírodovědnými</form>
   <lemma>přírodovědný</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w14</LM>
   </w.rf>
   <form>poznatky</form>
   <lemma>poznatek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w15</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w16</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w18</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w20</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w21</LM>
   </w.rf>
   <form>přírodními</form>
   <lemma>přírodní</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w22</LM>
   </w.rf>
   <form>vědami</form>
   <lemma>věda</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w23</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w24</LM>
   </w.rf>
   <form>styku</form>
   <lemma>styk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w25</LM>
   </w.rf>
   <form>nepřijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w26</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w27</LM>
   </w.rf>
   <form>budoucího</form>
   <lemma>budoucí</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w28</LM>
   </w.rf>
   <form>ekonoma</form>
   <lemma>ekonom</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w29</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w30</LM>
   </w.rf>
   <form>právníka</form>
   <lemma>právník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w32</LM>
   </w.rf>
   <form>filologa</form>
   <lemma>filolog</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s2w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s3A">
  <m id="m-vesm9211-045-p3s3Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw1</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw2</LM>
   </w.rf>
   <form>totiž</form>
   <lemma>totiž-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw3</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw4</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw5</LM>
   </w.rf>
   <form>minimální</form>
   <lemma>minimální</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw6</LM>
   </w.rf>
   <form>tušení</form>
   <lemma>tušení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw8</LM>
   </w.rf>
   <form>stavbě</form>
   <lemma>stavba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw9</LM>
   </w.rf>
   <form>atmosféry</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw11</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw12</LM>
   </w.rf>
   <form>ultrafialovém</form>
   <lemma>ultrafialový</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw13</LM>
   </w.rf>
   <form>záření</form>
   <lemma>záření_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw16</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw17</LM>
   </w.rf>
   <form>vlivu</form>
   <lemma>vliv</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw19</LM>
   </w.rf>
   <form>organismy</form>
   <lemma>organismus_,s_^(^DD**organizmus)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw21</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw23</LM>
   </w.rf>
   <form>neřekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw24</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw25</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw26</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw27</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw28</LM>
   </w.rf>
   <form>ozónové</form>
   <lemma>ozónový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw29</LM>
   </w.rf>
   <form>díry</form>
   <lemma>díra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw30</LM>
   </w.rf>
   <form>nebojím</form>
   <lemma>bát-1</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw32</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw33</LM>
   </w.rf>
   <form>našem</form>
   <lemma>náš</lemma>
   <tag>PSZS6-P1-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw34</LM>
   </w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw35</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw36</LM>
   </w.rf>
   <form>ovzduší</form>
   <lemma>ovzduší</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw37</LM>
   </w.rf>
   <form>čisté</form>
   <lemma>čistý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Aw39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Aw39</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s3B">
  <m id="m-vesm9211-045-p3s3Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw3</LM>
   </w.rf>
   <form>li</form>
   <lemma>li-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw4</LM>
   </w.rf>
   <form>základní</form>
   <lemma>základní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw5</LM>
   </w.rf>
   <form>vědomosti</form>
   <lemma>vědomost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw7</LM>
   </w.rf>
   <form>rozmanitosti</form>
   <lemma>rozmanitost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw8</LM>
   </w.rf>
   <form>vlastností</form>
   <lemma>vlastnost</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw9</LM>
   </w.rf>
   <form>jedinců</form>
   <lemma>jedinec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw11</LM>
   </w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw12</LM>
   </w.rf>
   <form>téhož</form>
   <lemma>týž</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw13</LM>
   </w.rf>
   <form>druhu</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw16</LM>
   </w.rf>
   <form>rozmanitosti</form>
   <lemma>rozmanitost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw17</LM>
   </w.rf>
   <form>podmíněné</form>
   <lemma>podmíněný_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw18</LM>
   </w.rf>
   <form>dědičností</form>
   <lemma>dědičnost_^(*3ý)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw19</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw20</LM>
   </w.rf>
   <form>různými</form>
   <lemma>různý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw21</LM>
   </w.rf>
   <form>vlivy</form>
   <lemma>vliv</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw22</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw24</LM>
   </w.rf>
   <form>nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw25</LM>
   </w.rf>
   <form>argumentovat</form>
   <lemma>argumentovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw26</LM>
   </w.rf>
   <form>takto</form>
   <lemma>takto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw27</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw28</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw29</LM>
   </w.rf>
   <form>Winston</form>
   <lemma>Winston-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw30</LM>
   </w.rf>
   <form>Churchill</form>
   <lemma>Churchill_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw31</LM>
   </w.rf>
   <form>kouřil</form>
   <lemma>kouřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw32</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw33</LM>
   </w.rf>
   <form>pil</form>
   <lemma>pít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw34</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw35</LM>
   </w.rf>
   <form>dožil</form>
   <lemma>dožít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw36</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw37</LM>
   </w.rf>
   <form>čtyřiadevadesáti</form>
   <lemma>čtyřiadevadesát`94</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw38</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw39</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw40</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw41</LM>
   </w.rf>
   <form>strýc</form>
   <lemma>strýc</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw42</LM>
   </w.rf>
   <form>abstinent</form>
   <lemma>abstinent</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw43</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw44</LM>
   </w.rf>
   <form>nekuřák</form>
   <lemma>nekuřák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw45</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw46</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw47</LM>
   </w.rf>
   <form>infarkt</form>
   <lemma>infarkt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw48</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw49</LM>
   </w.rf>
   <form>osmapadesáti</form>
   <lemma>osmapadesát`58</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s3Bw50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s3Bw50</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s4A">
  <m id="m-vesm9211-045-p3s4Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw2</LM>
   </w.rf>
   <form>přeci</form>
   <lemma>přeci-2_,h_^(^GC**přece-2)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw3</LM>
   </w.rf>
   <form>kouření</form>
   <lemma>kouření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw4</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw5</LM>
   </w.rf>
   <form>škodit</form>
   <lemma>škodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Aw7</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s4B">
  <m id="m-vesm9211-045-p3s4Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw1</LM>
   </w.rf>
   <form>Přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw2</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw4</LM>
   </w.rf>
   <form>stává</form>
   <lemma>stávat-2_^(*5t-2)_(*5t-3)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw5</LM>
   </w.rf>
   <form>zvlášť</form>
   <lemma>zvlášť-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw6</LM>
   </w.rf>
   <form>akutní</form>
   <lemma>akutní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw7</LM>
   </w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw9</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw12</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw13</LM>
   </w.rf>
   <form>valí</form>
   <lemma>valit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw14</LM>
   </w.rf>
   <form>vlna</form>
   <lemma>vlna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw15</LM>
   </w.rf>
   <form>iracionality</form>
   <lemma>iracionalita</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw16</LM>
   </w.rf>
   <form>provázená</form>
   <lemma>provázený_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw17</LM>
   </w.rf>
   <form>nákladnou</form>
   <lemma>nákladný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw18</LM>
   </w.rf>
   <form>reklamou</form>
   <lemma>reklama</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s4Bw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s4Bw19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s5">
  <m id="m-vesm9211-045-p3s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w3</LM>
   </w.rf>
   <form>pamatuje</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w6</LM>
   </w.rf>
   <form>látkové</form>
   <lemma>látkový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w7</LM>
   </w.rf>
   <form>přeměně</form>
   <lemma>přeměna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w9</LM>
   </w.rf>
   <form>organismu</form>
   <lemma>organismus_,s_^(^DD**organizmus)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w11</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w12</LM>
   </w.rf>
   <form>pojme</form>
   <lemma>pojmout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w13</LM>
   </w.rf>
   <form>podezření</form>
   <lemma>podezření</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w14</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w15</LM>
   </w.rf>
   <form>zázračnými</form>
   <lemma>zázračný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w16</LM>
   </w.rf>
   <form>metodami</form>
   <lemma>metoda</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w18</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w19</LM>
   </w.rf>
   <form>slibují</form>
   <lemma>slibovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w20</LM>
   </w.rf>
   <form>rychlé</form>
   <lemma>rychlý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w22</LM>
   </w.rf>
   <form>pohodlné</form>
   <lemma>pohodlný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w23</LM>
   </w.rf>
   <form>zhubnutí</form>
   <lemma>zhubnutí_^(*3out)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s5w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s6">
  <m id="m-vesm9211-045-p3s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w2</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w4</LM>
   </w.rf>
   <form>ví</form>
   <lemma>vědět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w6</LM>
   </w.rf>
   <form>kinetické</form>
   <lemma>kinetický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w7</LM>
   </w.rf>
   <form>teorii</form>
   <lemma>teorie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w8</LM>
   </w.rf>
   <form>tepla</form>
   <lemma>teplo-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w10</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w11</LM>
   </w.rf>
   <form>přinejmenším</form>
   <lemma>přinejmenším</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w12</LM>
   </w.rf>
   <form>znejistí</form>
   <lemma>znejistit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w13</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w14</LM>
   </w.rf>
   <form>tvrzením</form>
   <lemma>tvrzení_^(*4dit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w15</LM>
   </w.rf>
   <form>homeopata</form>
   <lemma>homeopat</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w18</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w19</LM>
   </w.rf>
   <form>roztok</form>
   <lemma>roztok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w21</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w22</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w23</LM>
   </w.rf>
   <form>použitím</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w24</LM>
   </w.rf>
   <form>protřepat</form>
   <lemma>protřepat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w26</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w28</LM>
   </w.rf>
   <form>molekuly</form>
   <lemma>molekula</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w29</LM>
   </w.rf>
   <form>léčiva</form>
   <lemma>léčivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w30</LM>
   </w.rf>
   <form>získaly</form>
   <lemma>získat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w31</LM>
   </w.rf>
   <form>dostatečnou</form>
   <lemma>dostatečný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w32</LM>
   </w.rf>
   <form>energii</form>
   <lemma>energie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w33</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s6w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s6w34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p3s7">
  <m id="m-vesm9211-045-p3s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w1</LM>
   </w.rf>
   <form>Přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w2</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w3</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w5</LM>
   </w.rf>
   <form>snížilo</form>
   <lemma>snížit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w6</LM>
   </w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w7</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w9</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w10</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w11</LM>
   </w.rf>
   <form>vydávají</form>
   <lemma>vydávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w12</LM>
   </w.rf>
   <form>nezanedbatelné</form>
   <lemma>zanedbatelný_^(*4)</lemma>
   <tag>AAFP4----1N----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w13</LM>
   </w.rf>
   <form>sumy</form>
   <lemma>suma</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w14</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w15</LM>
   </w.rf>
   <form>léky</form>
   <lemma>lék</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w16</LM>
   </w.rf>
   <form>zahraničního</form>
   <lemma>zahraniční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w17</LM>
   </w.rf>
   <form>původu</form>
   <lemma>původ</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w19</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w20</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w21</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w22</LM>
   </w.rf>
   <form>mohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w23</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w24</LM>
   </w.rf>
   <form>domácí</form>
   <lemma>domácí-1</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w25</LM>
   </w.rf>
   <form>ekvivalent</form>
   <lemma>ekvivalent</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p3s7w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p3s7w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p4s1">
  <m id="m-vesm9211-045-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w1</LM>
   </w.rf>
   <form>Přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w2</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w4</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w5</LM>
   </w.rf>
   <form>zužitkovat</form>
   <lemma>zužitkovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w6</LM>
   </w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w8</LM>
   </w.rf>
   <form>osobním</form>
   <lemma>osobní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w9</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w13</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w14</LM>
   </w.rf>
   <form>výkonu</form>
   <lemma>výkon</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w15</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w16</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w17</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w18</LM>
   </w.rf>
   <form>právník</form>
   <lemma>právník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w19</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w20</LM>
   </w.rf>
   <form>ekonom</form>
   <lemma>ekonom</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w22</LM>
   </w.rf>
   <form>nemluvě</form>
   <lemma>mluvit</lemma>
   <tag>VeYS------N-I--</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w23</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w24</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w25</LM>
   </w.rf>
   <form>kterémkoliv</form>
   <lemma>kterýkoliv</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w26</LM>
   </w.rf>
   <form>učiteli</form>
   <lemma>učitel</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w28</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w29</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w30</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS6---------1</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w31</LM>
   </w.rf>
   <form>profesi</form>
   <lemma>profese</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w32</LM>
   </w.rf>
   <form>setkávají</form>
   <lemma>setkávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w33</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w34</LM>
   </w.rf>
   <form>podobnými</form>
   <lemma>podobný</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w35</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s1w36</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p4s2">
  <m id="m-vesm9211-045-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w1</LM>
   </w.rf>
   <form>Tomuto</form>
   <lemma>tento</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w2</LM>
   </w.rf>
   <form>cíli</form>
   <lemma>cíl</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w3</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w4</LM>
   </w.rf>
   <form>neposlouží</form>
   <lemma>posloužit</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w5</LM>
   </w.rf>
   <form>přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w6</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w7</LM>
   </w.rf>
   <form>založené</form>
   <lemma>založený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w9</LM>
   </w.rf>
   <form>memorování</form>
   <lemma>memorování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w10</LM>
   </w.rf>
   <form>faktů</form>
   <lemma>fakt-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s2w11</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p4s3">
  <m id="m-vesm9211-045-p4s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w5</LM>
   </w.rf>
   <form>rozumět</form>
   <lemma>rozumět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w6</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w7</LM>
   </w.rf>
   <form>vztahům</form>
   <lemma>vztah</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w9</LM>
   </w.rf>
   <form>příčinným</form>
   <lemma>příčinný</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w10</LM>
   </w.rf>
   <form>souvislostem</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s3w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p4s4">
  <m id="m-vesm9211-045-p4s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w1</LM>
   </w.rf>
   <form>Takto</form>
   <lemma>takto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w2</LM>
   </w.rf>
   <form>podávané</form>
   <lemma>podávaný_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w3</LM>
   </w.rf>
   <form>přírodovědné</form>
   <lemma>přírodovědný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w4</LM>
   </w.rf>
   <form>poznatky</form>
   <lemma>poznatek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w5</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w6</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w7</LM>
   </w.rf>
   <form>lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w8</LM>
   </w.rf>
   <form>přijímány</form>
   <lemma>přijímat</lemma>
   <tag>VsTP----X-API--</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w10</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w11</LM>
   </w.rf>
   <form>studenty</form>
   <lemma>student</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w13</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w14</LM>
   </w.rf>
   <form>počítají</form>
   <lemma>počítat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w16</LM>
   </w.rf>
   <form>povoláním</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w17</LM>
   </w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w18</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w19</LM>
   </w.rf>
   <form>zaměření</form>
   <lemma>zaměření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p4s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p4s4w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p5s1">
  <m id="m-vesm9211-045-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s1w1</LM>
   </w.rf>
   <form>Zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s1w2</LM>
   </w.rf>
   <form>postavení</form>
   <lemma>postavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s1w3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s1w4</LM>
   </w.rf>
   <form>ekologie</form>
   <lemma>ekologie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p5s2">
  <m id="m-vesm9211-045-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w1</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w3</LM>
   </w.rf>
   <form>ekologickou</form>
   <lemma>ekologický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w4</LM>
   </w.rf>
   <form>problematikou</form>
   <lemma>problematika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w6</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w8</LM>
   </w.rf>
   <form>titulu</form>
   <lemma>titul</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w9</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w10</LM>
   </w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w11</LM>
   </w.rf>
   <form>setkat</form>
   <lemma>setkat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w12</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w13</LM>
   </w.rf>
   <form>řídící</form>
   <lemma>řídící_^(*3it)</lemma>
   <tag>AGMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w14</LM>
   </w.rf>
   <form>pracovník</form>
   <lemma>pracovník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w16</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w18</LM>
   </w.rf>
   <form>technik</form>
   <lemma>technik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w20</LM>
   </w.rf>
   <form>ekonom</form>
   <lemma>ekonom</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w21</LM>
   </w.rf>
   <form>či</form>
   <lemma>či-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w22</LM>
   </w.rf>
   <form>právník</form>
   <lemma>právník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s2w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p5s3">
  <m id="m-vesm9211-045-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w1</LM>
   </w.rf>
   <form>Střední</form>
   <lemma>střední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w2</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w4</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w5</LM>
   </w.rf>
   <form>poskytnout</form>
   <lemma>poskytnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w6</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w7</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w8</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w10</LM>
   </w.rf>
   <form>ekologii</form>
   <lemma>ekologie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w12</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w14</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w16</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w18</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w19</LM>
   </w.rf>
   <form>brát</form>
   <lemma>brát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w20</LM>
   </w.rf>
   <form>připomínky</form>
   <lemma>připomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w21</LM>
   </w.rf>
   <form>profesionálních</form>
   <lemma>profesionální</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w22</LM>
   </w.rf>
   <form>ekologů</form>
   <lemma>ekolog</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w23</LM>
   </w.rf>
   <form>vážně</form>
   <lemma>vážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s3w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p5s4">
  <m id="m-vesm9211-045-p5s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w1</LM>
   </w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w2</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w3</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w4</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w6</LM>
   </w.rf>
   <form>zaměřeno</form>
   <lemma>zaměřit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w7</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w9</LM>
   </w.rf>
   <form>fakta</form>
   <lemma>faktum</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w12</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w14</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w15</LM>
   </w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s4w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-045-p5s5">
  <m id="m-vesm9211-045-p5s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w1</LM>
   </w.rf>
   <form>Prof</form>
   <lemma>prof_^(profesor)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w3</LM>
   </w.rf>
   <form>RNDr</form>
   <lemma>RNDr_^(doktor_přír._věd)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w5</LM>
   </w.rf>
   <form>Václav</form>
   <lemma>Václav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w6</LM>
   </w.rf>
   <form>Kubišta</form>
   <lemma>Kubišta_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w8</LM>
   </w.rf>
   <form>CSc</form>
   <lemma>CSc_^(kandidát/ka_věd)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9211-045-p5s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-045-p5s5w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
