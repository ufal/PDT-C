<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94104_101.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94104-101-p1s1A">
  <m id="m-lnd94104-101-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-101-p1s1Aw1</LM>
   </w.rf>
   <form>Ivan</form>
   <lemma>Ivan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-101-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-101-p1s1Aw2</LM>
   </w.rf>
   <form>Hlinka</form>
   <lemma>Hlinka-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94104-101-p1s1B">
  <m id="m-lnd94104-101-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-101-p1s1Bw1</LM>
   </w.rf>
   <form>Foto</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94104-101-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-101-p1s1Bw2</LM>
   </w.rf>
   <form>Robert</form>
   <lemma>Robert_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-101-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-101-p1s1Bw3</LM>
   </w.rf>
   <form>Zlatohlávek</form>
   <lemma>zlatohlávek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
</mdata>
