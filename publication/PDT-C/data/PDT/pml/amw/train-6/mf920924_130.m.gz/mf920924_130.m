<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf920924_130.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf920924-130-p7s1">
  <m id="m-mf920924-130-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-130-p7s1w1</LM>
   </w.rf>
   <form>POLSKO</form>
   <lemma>Polsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
</mdata>
