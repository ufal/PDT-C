<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vesm9301_038.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-vesm9301-038-p1s1">
  <m id="m-vesm9301-038-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w1</LM>
   </w.rf>
   <form>Trpělivě</form>
   <lemma>trpělivě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w2</LM>
   </w.rf>
   <form>čekat</form>
   <lemma>čekat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w4</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w5</LM>
   </w.rf>
   <form>článku</form>
   <lemma>článek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w7</LM>
   </w.rf>
   <form>New</form>
   <lemma>New-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w8</LM>
   </w.rf>
   <form>England</form>
   <lemma>England-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w9</LM>
   </w.rf>
   <form>J</form>
   <lemma>J-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w11</LM>
   </w.rf>
   <form>of</form>
   <lemma>of-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w12</LM>
   </w.rf>
   <form>Med</form>
   <lemma>Med-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w14</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w15</LM>
   </w.rf>
   <form>323</form>
   <lemma>323</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w16</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w17</LM>
   </w.rf>
   <form>604</form>
   <lemma>604</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w19</LM>
   </w.rf>
   <form>1990</form>
   <lemma>1990</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w20</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w22</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w23</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w24</LM>
   </w.rf>
   <form>autor</form>
   <lemma>autor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w25</LM>
   </w.rf>
   <form>článku</form>
   <lemma>článek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w26</LM>
   </w.rf>
   <form>rozebírá</form>
   <lemma>rozebírat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w27</LM>
   </w.rf>
   <form>příčiny</form>
   <lemma>příčina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w28</LM>
   </w.rf>
   <form>dlouhého</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w29</LM>
   </w.rf>
   <form>čekání</form>
   <lemma>čekání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w30</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w31</LM>
   </w.rf>
   <form>čekárnách</form>
   <lemma>čekárna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w32</LM>
   </w.rf>
   <form>zdravotnických</form>
   <lemma>zdravotnický</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w33</LM>
   </w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w34</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w35</LM>
   </w.rf>
   <form>USA</form>
   <lemma>USA_;G_^(United_States_of_America)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p1s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p1s1w36</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p2s3">
  <m id="m-vesm9301-038-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w1</LM>
   </w.rf>
   <form>Během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w2</LM>
   </w.rf>
   <form>několika</form>
   <lemma>několik</lemma>
   <tag>Ca--2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w3</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w5</LM>
   </w.rf>
   <form>opakovaně</form>
   <lemma>opakovaně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w6</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w8</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w9</LM>
   </w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w11</LM>
   </w.rf>
   <form>pacient</form>
   <lemma>pacient</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w13</LM>
   </w.rf>
   <form>ačkoliv</form>
   <lemma>ačkoliv_,s_^(^DD**ačkoli)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w14</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w16</LM>
   </w.rf>
   <form>pracovníkem</form>
   <lemma>pracovník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w17</LM>
   </w.rf>
   <form>zdravotního</form>
   <lemma>zdravotní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w18</LM>
   </w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w19</LM>
   </w.rf>
   <form>spojeného</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w20</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w21</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w23</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w24</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s3w25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p2s4">
  <m id="m-vesm9301-038-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w2</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w3</LM>
   </w.rf>
   <form>zřídka</form>
   <lemma>zřídka</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w4</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w5</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w6</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w7</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w8</LM>
   </w.rf>
   <form>hodinu</form>
   <lemma>hodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w10</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w12</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w14</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w15</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w16</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s4w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p2s5">
  <m id="m-vesm9301-038-p2s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w1</LM>
   </w.rf>
   <form>Autor</form>
   <lemma>autor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w2</LM>
   </w.rf>
   <form>rozebírá</form>
   <lemma>rozebírat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w4</LM>
   </w.rf>
   <form>matematicky</form>
   <lemma>matematicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w5</LM>
   </w.rf>
   <form>analyzuje</form>
   <lemma>analyzovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w6</LM>
   </w.rf>
   <form>faktory</form>
   <lemma>faktor-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w9</LM>
   </w.rf>
   <form>působí</form>
   <lemma>působit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w10</LM>
   </w.rf>
   <form>dlouhé</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w11</LM>
   </w.rf>
   <form>čekání</form>
   <lemma>čekání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w13</LM>
   </w.rf>
   <form>lékařských</form>
   <lemma>lékařský</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w14</LM>
   </w.rf>
   <form>zařízeních</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w16</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w17</LM>
   </w.rf>
   <form>vypracoval</form>
   <lemma>vypracovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w18</LM>
   </w.rf>
   <form>matematický</form>
   <lemma>matematický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w19</LM>
   </w.rf>
   <form>vzorec</form>
   <lemma>vzorec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w21</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w22</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w24</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w25</LM>
   </w.rf>
   <form>čekání</form>
   <lemma>čekání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w26</LM>
   </w.rf>
   <form>determinována</form>
   <lemma>determinovat</lemma>
   <tag>VsQW----X-APB--</tag>
  </m>
  <m id="m-vesm9301-038-p2s5w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s5w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p2s6">
  <m id="m-vesm9301-038-p2s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w1</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w2</LM>
   </w.rf>
   <form>lékaři</form>
   <lemma>lékař</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w4</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w5</LM>
   </w.rf>
   <form>pracují</form>
   <lemma>pracovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w6</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w7</LM>
   </w.rf>
   <form>zastavení</form>
   <lemma>zastavení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w8</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w10</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w11</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w12</LM>
   </w.rf>
   <form>prostojů</form>
   <lemma>prostoj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w13</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w14</LM>
   </w.rf>
   <form>mohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w15</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w16</LM>
   </w.rf>
   <form>příčinou</form>
   <lemma>příčina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w17</LM>
   </w.rf>
   <form>dlouhého</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w18</LM>
   </w.rf>
   <form>čekání</form>
   <lemma>čekání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w19</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP2----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w20</LM>
   </w.rf>
   <form>pacientů</form>
   <lemma>pacient</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w22</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w23</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w24</LM>
   </w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w25</LM>
   </w.rf>
   <form>objednávají</form>
   <lemma>objednávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w26</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w27</LM>
   </w.rf>
   <form>nemocných</form>
   <lemma>nemocný-1_^(pacient)</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w28</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w29</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w30</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w31</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w32</LM>
   </w.rf>
   <form>schopni</form>
   <lemma>schopný</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w33</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w34</LM>
   </w.rf>
   <form>následkem</form>
   <lemma>následek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w35</LM>
   </w.rf>
   <form>nejrůznějších</form>
   <lemma>různý</lemma>
   <tag>AANP2----3A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w36</LM>
   </w.rf>
   <form>zdržení</form>
   <lemma>zdržení_^(*2t)</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w37</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w38</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w39</LM>
   </w.rf>
   <form>daném</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w40</LM>
   </w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w41</LM>
   </w.rf>
   <form>zvládnout</form>
   <lemma>zvládnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-vesm9301-038-p2s6w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p2s6w42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p3s1">
  <m id="m-vesm9301-038-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p3s1w1</LM>
   </w.rf>
   <form>Vratislav</form>
   <lemma>Vratislav-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9301-038-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p3s1w2</LM>
   </w.rf>
   <form>Schreiber</form>
   <lemma>Schreiber_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-vesm9301-038-p4s1">
  <m id="m-vesm9301-038-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p4s1w1</LM>
   </w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9301-038-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p4s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9301-038-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9301-038-p4s1w3</LM>
   </w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
</mdata>
