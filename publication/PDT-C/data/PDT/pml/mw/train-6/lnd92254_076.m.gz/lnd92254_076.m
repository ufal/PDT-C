<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92254_076.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92254-076-p1s1">
  <m id="m-lnd92254-076-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p1s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5365425205.52</form>
   <lemma>5365425205.52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p1s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p1s1w3</LM>
   </w.rf>
   <form>5.55</form>
   <lemma>5.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p1s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p2s1">
  <m id="m-lnd92254-076-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w1</LM>
   </w.rf>
   <form>209921.2019</form>
   <lemma>209921.2019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w3</LM>
   </w.rf>
   <form>8421.28</form>
   <lemma>8421.28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w5</LM>
   </w.rf>
   <form>20.82</form>
   <lemma>20.82</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p3s1">
  <m id="m-lnd92254-076-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p3s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2592612552.67</form>
   <lemma>2592612552.67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p3s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p3s1w3</LM>
   </w.rf>
   <form>2.69</form>
   <lemma>2.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p3s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p4s1">
  <m id="m-lnd92254-076-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w1</LM>
   </w.rf>
   <form>181918.3717</form>
   <lemma>181918.3717</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w3</LM>
   </w.rf>
   <form>8218.74</form>
   <lemma>8218.74</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w5</LM>
   </w.rf>
   <form>18.86</form>
   <lemma>18.86</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p5s1">
  <m id="m-lnd92254-076-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w1</LM>
   </w.rf>
   <form>203920.6019</form>
   <lemma>203920.6019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w3</LM>
   </w.rf>
   <form>9821.04</form>
   <lemma>9821.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w5</LM>
   </w.rf>
   <form>21.12</form>
   <lemma>21.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p6s1">
  <m id="m-lnd92254-076-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w1</LM>
   </w.rf>
   <form>278528.1327</form>
   <lemma>278528.1327</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w3</LM>
   </w.rf>
   <form>2928.69</form>
   <lemma>2928.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w5</LM>
   </w.rf>
   <form>28.52</form>
   <lemma>28.52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-076-p7s1">
  <m id="m-lnd92254-076-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w1</LM>
   </w.rf>
   <form>437744.2142</form>
   <lemma>437744.2142</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w3</LM>
   </w.rf>
   <form>1645.30</form>
   <lemma>1645.30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-076-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w5</LM>
   </w.rf>
   <form>46.09</form>
   <lemma>46.09</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-076-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-076-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
