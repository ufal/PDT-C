<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf930701_115.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf930701-115-p1s1">
  <m id="m-mf930701-115-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w1</LM>
   </w.rf>
   <form>Andre</form>
   <lemma>Andre_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930701-115-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w2</LM>
   </w.rf>
   <form>Agassi</form>
   <lemma>Agassi_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930701-115-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w3</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930701-115-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w4</LM>
   </w.rf>
   <form>bojoval</form>
   <lemma>bojovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-mf930701-115-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930701-115-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930701-115-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930701-115-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w8</LM>
   </w.rf>
   <form>Samprase</form>
   <lemma>Sampras_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-mf930701-115-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w9</LM>
   </w.rf>
   <form>tentokrát</form>
   <lemma>tentokrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-mf930701-115-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930701-115-p1s1w10</LM>
   </w.rf>
   <form>nestačil</form>
   <lemma>stačit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
 </s>
</mdata>
