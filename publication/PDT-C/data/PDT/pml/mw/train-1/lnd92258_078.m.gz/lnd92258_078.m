<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92258_078.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92258-078-p1s1">
  <m id="m-lnd92258-078-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p1s1w1</LM>
   </w.rf>
   <form>PRÁVNÍ</form>
   <lemma>právní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p1s1w2</LM>
   </w.rf>
   <form>RÁMEC</form>
   <lemma>rámec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p1s1w3</LM>
   </w.rf>
   <form>PODNIKÁNÍ</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p2s1">
  <m id="m-lnd92258-078-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w1</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w2</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w3</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w4</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w5</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w6</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w7</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w8</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w9</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w10</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w11</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w12</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w13</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w14</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w15</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w16</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w17</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w18</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w19</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w20</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w21</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w22</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w23</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w24</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w25</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w26</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w27</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w28</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w29</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w30</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w31</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w32</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w33</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w34</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w35</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w36</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w37</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w38</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w39</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w40</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w41</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w42</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w43</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w44</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w45</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w46</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w47</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w48</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w49</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w50</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w51</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w52</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w53</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w54</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w55</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w56</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w57</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w58</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w59</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w60</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w61</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w62</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w63</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p2s1w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p2s1w64</LM>
   </w.rf>
   <form>ˇ</form>
   <lemma>ˇ</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p3s1">
  <m id="m-lnd92258-078-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p3s1w1</LM>
   </w.rf>
   <form>U</form>
   <lemma>U-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p3s1w2</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p4s1">
  <m id="m-lnd92258-078-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p4s1w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p5s1">
  <m id="m-lnd92258-078-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s1w1</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s1w2</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p5s2">
  <m id="m-lnd92258-078-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s2w1</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s2w2</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p5s3">
  <m id="m-lnd92258-078-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s3w1</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s3w2</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p5s4">
  <m id="m-lnd92258-078-p5s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s4w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p5s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s4w2</LM>
   </w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p5s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p5s4w3</LM>
   </w.rf>
   <form>systém</form>
   <lemma>systém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p6s1">
  <m id="m-lnd92258-078-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p6s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p6s1w2</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p6s1w3</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p7s1">
  <m id="m-lnd92258-078-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w2</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w3</LM>
   </w.rf>
   <form>formy</form>
   <lemma>forma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w4</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p7s1w6</LM>
   </w.rf>
   <form>ČSFR</form>
   <lemma>ČSFR_;G_^(Čs._federativní_republika)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p8s1">
  <m id="m-lnd92258-078-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w2</LM>
   </w.rf>
   <form>zahájení</form>
   <lemma>zahájení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w4</LM>
   </w.rf>
   <form>ukončení</form>
   <lemma>ukončení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w5</LM>
   </w.rf>
   <form>podnikatelské</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w6</LM>
   </w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p8s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p8s1w7</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p9s1">
  <m id="m-lnd92258-078-p9s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p9s1w1</LM>
   </w.rf>
   <form>Právní</form>
   <lemma>právní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p9s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p9s1w2</LM>
   </w.rf>
   <form>systém</form>
   <lemma>systém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p10s1">
  <m id="m-lnd92258-078-p10s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w2</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w4</LM>
   </w.rf>
   <form>forem</form>
   <lemma>forma</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w5</LM>
   </w.rf>
   <form>zásahu</form>
   <lemma>zásah</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w6</LM>
   </w.rf>
   <form>státu</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p10s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p10s1w8</LM>
   </w.rf>
   <form>ekonomiky</form>
   <lemma>ekonomika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p11s1">
  <m id="m-lnd92258-078-p11s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p11s1w1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p11s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p11s1w2</LM>
   </w.rf>
   <form>ekonomického</form>
   <lemma>ekonomický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p11s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p11s1w3</LM>
   </w.rf>
   <form>pohledu</form>
   <lemma>pohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p11s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p11s1w4</LM>
   </w.rf>
   <form>fixuje</form>
   <lemma>fixovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p11s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p11s1w5</LM>
   </w.rf>
   <form>očekávání</form>
   <lemma>očekávání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p12s1">
  <m id="m-lnd92258-078-p12s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w2</LM>
   </w.rf>
   <form>právního</form>
   <lemma>právní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w3</LM>
   </w.rf>
   <form>pohledu</form>
   <lemma>pohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w4</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w6</LM>
   </w.rf>
   <form>uznání</form>
   <lemma>uznání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w7</LM>
   </w.rf>
   <form>dosavadních</form>
   <lemma>dosavadní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w8</LM>
   </w.rf>
   <form>forem</form>
   <lemma>forma</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w9</LM>
   </w.rf>
   <form>chování</form>
   <lemma>chování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w11</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>normativních</form>
   <lemma>normativní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p12s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p12s1w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p13s1">
  <m id="m-lnd92258-078-p13s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w1</LM>
   </w.rf>
   <form>Úlohy</form>
   <lemma>úloha</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w2</LM>
   </w.rf>
   <form>právního</form>
   <lemma>právní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w3</LM>
   </w.rf>
   <form>systému</form>
   <lemma>systém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w5</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w6</LM>
   </w.rf>
   <form>vymezení</form>
   <lemma>vymezení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w7</LM>
   </w.rf>
   <form>vlastnických</form>
   <lemma>vlastnický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p13s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p13s1w8</LM>
   </w.rf>
   <form>vztahů</form>
   <lemma>vztah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p14s1">
  <m id="m-lnd92258-078-p14s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p14s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p14s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p14s1w2</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p14s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p14s1w3</LM>
   </w.rf>
   <form>smluv</form>
   <lemma>smlouva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p14s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p14s1w4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p14s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p14s1w5</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p15s1">
  <m id="m-lnd92258-078-p15s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w2</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w3</LM>
   </w.rf>
   <form>vztahů</form>
   <lemma>vztah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w4</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w5</LM>
   </w.rf>
   <form>zaměstnavateli</form>
   <lemma>zaměstnavatel</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p15s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p15s1w7</LM>
   </w.rf>
   <form>zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p16s1">
  <m id="m-lnd92258-078-p16s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p16s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p16s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p16s1w2</LM>
   </w.rf>
   <form>způsob</form>
   <lemma>způsob</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p16s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p16s1w3</LM>
   </w.rf>
   <form>vzájemného</form>
   <lemma>vzájemný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p16s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p16s1w4</LM>
   </w.rf>
   <form>působení</form>
   <lemma>působení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p16s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p16s1w5</LM>
   </w.rf>
   <form>subjektů</form>
   <lemma>subjekt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p17s1">
  <m id="m-lnd92258-078-p17s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p17s1w1</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p17s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p17s1w2</LM>
   </w.rf>
   <form>viz</form>
   <lemma>viz_^(odkaz_na_jiné_místo)</lemma>
   <tag>Vi-S---2--A-P-1</tag>
  </m>
  <m id="m-lnd92258-078-p17s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p17s1w3</LM>
   </w.rf>
   <form>veřejné</form>
   <lemma>veřejný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p17s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p17s1w4</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p17s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p17s1w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p18s1">
  <m id="m-lnd92258-078-p18s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p18s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p18s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p18s1w2</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p18s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p18s1w3</LM>
   </w.rf>
   <form>externalit</form>
   <lemma>externalita</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p19s1">
  <m id="m-lnd92258-078-p19s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p19s1w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-078-p19s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p19s1w2</LM>
   </w.rf>
   <form>Obr</form>
   <lemma>obrázek</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-lnd92258-078-p19s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p19s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p19s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p19s1w4</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p20s1">
  <m id="m-lnd92258-078-p20s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w1</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w2</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w3</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w4</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>OBR</form>
   <lemma>obrázek</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w7</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p20s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p20s1w8</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p21s1">
  <m id="m-lnd92258-078-p21s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p21s1w1</LM>
   </w.rf>
   <form>Úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p21s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p21s1w2</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p22s1">
  <m id="m-lnd92258-078-p22s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p22s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p22s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p22s1w2</LM>
   </w.rf>
   <form>definice</form>
   <lemma>definice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p22s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p22s1w3</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p23s1">
  <m id="m-lnd92258-078-p23s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w1</LM>
   </w.rf>
   <form>Cílem</form>
   <lemma>cíl</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w2</LM>
   </w.rf>
   <form>změn</form>
   <lemma>změna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w3</LM>
   </w.rf>
   <form>nynějšího</form>
   <lemma>nynější</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w4</LM>
   </w.rf>
   <form>právního</form>
   <lemma>právní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w5</LM>
   </w.rf>
   <form>řádu</form>
   <lemma>řád</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p23s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p23s1w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p24s1">
  <m id="m-lnd92258-078-p24s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w2</LM>
   </w.rf>
   <form>změna</form>
   <lemma>změna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w3</LM>
   </w.rf>
   <form>filosofie</form>
   <lemma>filosofie_,s_^(^DD**filozofie)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w4</LM>
   </w.rf>
   <form>práva</form>
   <lemma>právo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w6</LM>
   </w.rf>
   <form>zákonů</form>
   <lemma>zákon</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w9</LM>
   </w.rf>
   <form>upravovaly</form>
   <lemma>upravovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w10</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w12</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w13</LM>
   </w.rf>
   <form>podniky</form>
   <lemma>podnik</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w15</LM>
   </w.rf>
   <form>dané</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w16</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w17</LM>
   </w.rf>
   <form>chovat</form>
   <lemma>chovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w19</LM>
   </w.rf>
   <form>vytyčení</form>
   <lemma>vytyčení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p24s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p24s1w20</LM>
   </w.rf>
   <form>mantinelů</form>
   <lemma>mantinel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p25s1">
  <m id="m-lnd92258-078-p25s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w2</LM>
   </w.rf>
   <form>oddělení</form>
   <lemma>oddělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w3</LM>
   </w.rf>
   <form>veřejného</form>
   <lemma>veřejný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w5</LM>
   </w.rf>
   <form>soukromého</form>
   <lemma>soukromý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w6</LM>
   </w.rf>
   <form>práva</form>
   <lemma>právo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w7</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w8</LM>
   </w.rf>
   <form>stát</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w9</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w10</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w11</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w12</LM>
   </w.rf>
   <form>pozice</form>
   <lemma>pozice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w13</LM>
   </w.rf>
   <form>zasahovat</form>
   <lemma>zasahovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w14</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w15</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w16</LM>
   </w.rf>
   <form>zabezpečení</form>
   <lemma>zabezpečení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w17</LM>
   </w.rf>
   <form>celospolečenských</form>
   <lemma>celospolečenský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w18</LM>
   </w.rf>
   <form>potřeb</form>
   <lemma>potřeba-1</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w20</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w21</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w22</LM>
   </w.rf>
   <form>postavení</form>
   <lemma>postavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w23</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w24</LM>
   </w.rf>
   <form>kterýkoli</form>
   <lemma>kterýkoli</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w25</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w26</LM>
   </w.rf>
   <form>hospodařící</form>
   <lemma>hospodařící_^(*3it)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w27</LM>
   </w.rf>
   <form>subjekt</form>
   <lemma>subjekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p25s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p25s1w29</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p26s1">
  <m id="m-lnd92258-078-p26s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w2</LM>
   </w.rf>
   <form>jednotná</form>
   <lemma>jednotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w3</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w4</LM>
   </w.rf>
   <form>vlastnictví</form>
   <lemma>vlastnictví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w6</LM>
   </w.rf>
   <form>základě</form>
   <lemma>základ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p26s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p26s1w7</LM>
   </w.rf>
   <form>rovnosti</form>
   <lemma>rovnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p27s1">
  <m id="m-lnd92258-078-p27s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w1</LM>
   </w.rf>
   <form>Podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w3</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w5</LM>
   </w.rf>
   <form>práv</form>
   <lemma>právo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w6</LM>
   </w.rf>
   <form>občana</form>
   <lemma>občan</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w8</LM>
   </w.rf>
   <form>jež</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w9</LM>
   </w.rf>
   <form>plyne</form>
   <lemma>plynout</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w10</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w11</LM>
   </w.rf>
   <form>Základní</form>
   <lemma>základní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w12</LM>
   </w.rf>
   <form>listiny</form>
   <lemma>listina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w13</LM>
   </w.rf>
   <form>práv</form>
   <lemma>právo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w15</LM>
   </w.rf>
   <form>svobod</form>
   <lemma>svoboda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p27s2">
  <m id="m-lnd92258-078-p27s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w2</LM>
   </w.rf>
   <form>upraveno</form>
   <lemma>upravit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w3</LM>
   </w.rf>
   <form>Občanským</form>
   <lemma>občanský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w4</LM>
   </w.rf>
   <form>zákoníkem</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w8</LM>
   </w.rf>
   <form>povahu</form>
   <lemma>povaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w9</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w10</LM>
   </w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w11</LM>
   </w.rf>
   <form>normy</form>
   <lemma>norma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w13</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w14</LM>
   </w.rf>
   <form>Obchodním</form>
   <lemma>obchodní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w15</LM>
   </w.rf>
   <form>zákoníkem</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w17</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>jenž</form>
   <lemma>jenž_^(který_[ve_vedl.větě])</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w19</LM>
   </w.rf>
   <form>týká</form>
   <lemma>týkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w20</LM>
   </w.rf>
   <form>specielně</form>
   <lemma>specielně_^(^DD**speciálně)_(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w21</LM>
   </w.rf>
   <form>podnikatelů</form>
   <lemma>podnikatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p27s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p27s2w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p28s1">
  <m id="m-lnd92258-078-p28s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w1</LM>
   </w.rf>
   <form>Normy</form>
   <lemma>norma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p28s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w2</LM>
   </w.rf>
   <form>bezprostředně</form>
   <lemma>bezprostředně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd92258-078-p28s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w3</LM>
   </w.rf>
   <form>dopadající</form>
   <lemma>dopadající_^(*4t)</lemma>
   <tag>AGFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p28s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p28s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w5</LM>
   </w.rf>
   <form>podnikatele</form>
   <lemma>podnikatel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p28s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p28s1w6</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p29s1">
  <m id="m-lnd92258-078-p29s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w1</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w2</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>OBR</form>
   <lemma>obrázek</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w6</LM>
   </w.rf>
   <form>&amp;</form>
   <lemma>&amp;</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p29s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p29s1w7</LM>
   </w.rf>
   <form>;</form>
   <lemma>;</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p30s1">
  <m id="m-lnd92258-078-p30s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p30s1w1</LM>
   </w.rf>
   <form>Občanský</form>
   <lemma>občanský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p30s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p30s1w2</LM>
   </w.rf>
   <form>zákoník</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p30s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p30s1w3</LM>
   </w.rf>
   <form>upravuje</form>
   <lemma>upravovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p30s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p30s1w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p31s1">
  <m id="m-lnd92258-078-p31s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w2</LM>
   </w.rf>
   <form>majetkové</form>
   <lemma>majetkový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w3</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w4</LM>
   </w.rf>
   <form>fyzických</form>
   <lemma>fyzický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w6</LM>
   </w.rf>
   <form>právnických</form>
   <lemma>právnický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w7</LM>
   </w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w9</LM>
   </w.rf>
   <form>majetkové</form>
   <lemma>majetkový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w10</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w11</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w12</LM>
   </w.rf>
   <form>těmito</form>
   <lemma>tento</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w13</LM>
   </w.rf>
   <form>osobami</form>
   <lemma>osoba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w15</LM>
   </w.rf>
   <form>státem</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w17</LM>
   </w.rf>
   <form>jakož</form>
   <lemma>jakož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w18</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w19</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w20</LM>
   </w.rf>
   <form>vyplývající</form>
   <lemma>vyplývající_^(*4t)</lemma>
   <tag>AGIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w21</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w22</LM>
   </w.rf>
   <form>práva</form>
   <lemma>právo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w24</LM>
   </w.rf>
   <form>ochranu</form>
   <lemma>ochrana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w25</LM>
   </w.rf>
   <form>osob</form>
   <lemma>osoba</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p31s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p31s1w29</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p32s1">
  <m id="m-lnd92258-078-p32s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p32s1w1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Konkrétně</form>
   <lemma>konkrétně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd92258-078-p32s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p32s1w2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p32s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p32s1w3</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p32s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p32s1w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p33s1">
  <m id="m-lnd92258-078-p33s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w2</LM>
   </w.rf>
   <form>Definice</form>
   <lemma>definice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w3</LM>
   </w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w5</LM>
   </w.rf>
   <form>právnické</form>
   <lemma>právnický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w6</LM>
   </w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p33s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p33s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p34s1">
  <m id="m-lnd92258-078-p34s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p34s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p34s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p34s1w2</LM>
   </w.rf>
   <form>Vymezení</form>
   <lemma>vymezení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p34s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p34s1w3</LM>
   </w.rf>
   <form>právních</form>
   <lemma>právní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p34s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p34s1w4</LM>
   </w.rf>
   <form>úkonů</form>
   <lemma>úkon</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p35s1">
  <m id="m-lnd92258-078-p35s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p35s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p35s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p35s1w2</LM>
   </w.rf>
   <form>Úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p35s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p35s1w3</LM>
   </w.rf>
   <form>vlastnických</form>
   <lemma>vlastnický</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p35s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p35s1w4</LM>
   </w.rf>
   <form>práv</form>
   <lemma>právo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p36s1">
  <m id="m-lnd92258-078-p36s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w2</LM>
   </w.rf>
   <form>Práva</form>
   <lemma>právo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w4</LM>
   </w.rf>
   <form>cizím</form>
   <lemma>cizí</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w5</LM>
   </w.rf>
   <form>věcem</form>
   <lemma>věc</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w6</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w7</LM>
   </w.rf>
   <form>zástavní</form>
   <lemma>zástavní_^(právo)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w8</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p36s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p36s1w11</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p37s1">
  <m id="m-lnd92258-078-p37s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p37s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p37s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p37s1w2</LM>
   </w.rf>
   <form>Odpovědnost</form>
   <lemma>odpovědnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p37s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p37s1w3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p37s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p37s1w4</LM>
   </w.rf>
   <form>škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p38s1">
  <m id="m-lnd92258-078-p38s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p38s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p38s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p38s1w2</LM>
   </w.rf>
   <form>Dědictví</form>
   <lemma>dědictví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p39s1">
  <m id="m-lnd92258-078-p39s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w2</LM>
   </w.rf>
   <form>Závazkové</form>
   <lemma>závazkový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w3</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w5</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w6</LM>
   </w.rf>
   <form>smluv</form>
   <lemma>smlouva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p39s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p39s1w7</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p40s1">
  <m id="m-lnd92258-078-p40s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w2</LM>
   </w.rf>
   <form>zákoník</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w4</LM>
   </w.rf>
   <form>speciální</form>
   <lemma>speciální</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w5</LM>
   </w.rf>
   <form>právní</form>
   <lemma>právní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w6</LM>
   </w.rf>
   <form>úpravou</form>
   <lemma>úprava</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w7</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w8</LM>
   </w.rf>
   <form>Občanským</form>
   <lemma>občanský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w9</LM>
   </w.rf>
   <form>zákoníkem</form>
   <lemma>zákoník-2_^(předpis)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w11</LM>
   </w.rf>
   <form>upravuje</form>
   <lemma>upravovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w12</LM>
   </w.rf>
   <form>postavení</form>
   <lemma>postavení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w13</LM>
   </w.rf>
   <form>podnikatelů</form>
   <lemma>podnikatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p40s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p40s1w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p41s1">
  <m id="m-lnd92258-078-p41s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p41s1w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p41s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p41s1w2</LM>
   </w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p41s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p41s1w3</LM>
   </w.rf>
   <form>upraveno</form>
   <lemma>upravit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-lnd92258-078-p41s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p41s1w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p42s1">
  <m id="m-lnd92258-078-p42s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p42s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p42s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p42s1w2</LM>
   </w.rf>
   <form>Statut</form>
   <lemma>statut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p42s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p42s1w3</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p43s1">
  <m id="m-lnd92258-078-p43s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p43s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p43s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p43s1w2</LM>
   </w.rf>
   <form>Pravidla</form>
   <lemma>pravidlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p43s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p43s1w3</LM>
   </w.rf>
   <form>hospodářské</form>
   <lemma>hospodářský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p43s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p43s1w4</LM>
   </w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p44s1">
  <m id="m-lnd92258-078-p44s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p44s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p44s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p44s1w2</LM>
   </w.rf>
   <form>Zásady</form>
   <lemma>zásada</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p44s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p44s1w3</LM>
   </w.rf>
   <form>vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p44s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p44s1w4</LM>
   </w.rf>
   <form>účetnictví</form>
   <lemma>účetnictví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p45s1">
  <m id="m-lnd92258-078-p45s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p45s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p45s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p45s1w2</LM>
   </w.rf>
   <form>Podnikový</form>
   <lemma>podnikový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p45s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p45s1w3</LM>
   </w.rf>
   <form>rejstřík</form>
   <lemma>rejstřík</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p46s1">
  <m id="m-lnd92258-078-p46s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w2</LM>
   </w.rf>
   <form>Právní</form>
   <lemma>právní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w3</LM>
   </w.rf>
   <form>úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w4</LM>
   </w.rf>
   <form>obchodních</form>
   <lemma>obchodní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w5</LM>
   </w.rf>
   <form>společností</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p46s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p46s1w7</LM>
   </w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p47s1">
  <m id="m-lnd92258-078-p47s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w2</LM>
   </w.rf>
   <form>Úprava</form>
   <lemma>úprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w3</LM>
   </w.rf>
   <form>obchodních</form>
   <lemma>obchodní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w4</LM>
   </w.rf>
   <form>závazkových</form>
   <lemma>závazkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w5</LM>
   </w.rf>
   <form>vztahů</form>
   <lemma>vztah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w6</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>smluv</form>
   <lemma>smlouva</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p47s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p47s1w8</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p48s1">
  <m id="m-lnd92258-078-p48s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Hierarchie</form>
   <lemma>hierarchie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w2</LM>
   </w.rf>
   <form>platnosti</form>
   <lemma>platnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w4</LM>
   </w.rf>
   <form>Kogentní</form>
   <lemma>kogentní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w5</LM>
   </w.rf>
   <form>ustanovení</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w6</LM>
   </w.rf>
   <form>Obch</form>
   <lemma>obchodní</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p48s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p48s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p49s1">
  <m id="m-lnd92258-078-p49s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w1</LM>
   </w.rf>
   <form>Kogentní</form>
   <lemma>kogentní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p49s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w2</LM>
   </w.rf>
   <form>ustanovení</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p49s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w3</LM>
   </w.rf>
   <form>Obč</form>
   <lemma>občanský</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p49s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p49s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p49s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p49s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p50s1">
  <m id="m-lnd92258-078-p50s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p50s1w1</LM>
   </w.rf>
   <form>Uzavřená</form>
   <lemma>uzavřený_^(*3ít)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p50s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p50s1w2</LM>
   </w.rf>
   <form>smlouva</form>
   <lemma>smlouva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p51s1">
  <m id="m-lnd92258-078-p51s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w1</LM>
   </w.rf>
   <form>Dispozitivní</form>
   <lemma>dispozitivní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p51s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w2</LM>
   </w.rf>
   <form>ustanovení</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p51s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w3</LM>
   </w.rf>
   <form>Obch</form>
   <lemma>obchodní</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p51s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p51s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p51s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p51s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p52s1">
  <m id="m-lnd92258-078-p52s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w1</LM>
   </w.rf>
   <form>Dispozitivní</form>
   <lemma>dispozitivní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p52s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w2</LM>
   </w.rf>
   <form>ustanovení</form>
   <lemma>ustanovení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p52s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w3</LM>
   </w.rf>
   <form>Obč</form>
   <lemma>občanský</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p52s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p52s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p52s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p52s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p53s1">
  <m id="m-lnd92258-078-p53s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p53s1w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p53s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p53s1w2</LM>
   </w.rf>
   <form>zvyklosti</form>
   <lemma>zvyklost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p54s1">
  <m id="m-lnd92258-078-p54s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p54s1w1</LM>
   </w.rf>
   <form>Duch</form>
   <lemma>duch-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p54s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p54s1w2</LM>
   </w.rf>
   <form>zákonů</form>
   <lemma>zákon</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p55s1">
  <m id="m-lnd92258-078-p55s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w2</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w3</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w4</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w6</LM>
   </w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w7</LM>
   </w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w8</LM>
   </w.rf>
   <form>Typy</form>
   <lemma>typ</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p55s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p55s1w9</LM>
   </w.rf>
   <form>živností</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p56s1">
  <m id="m-lnd92258-078-p56s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w1</LM>
   </w.rf>
   <form>Živnostenský</form>
   <lemma>živnostenský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w2</LM>
   </w.rf>
   <form>zákon</form>
   <lemma>zákon</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w4</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w5</LM>
   </w.rf>
   <form>veřejněprávní</form>
   <lemma>veřejněprávní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w6</LM>
   </w.rf>
   <form>charakter</form>
   <lemma>charakter</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p56s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p56s2">
  <m id="m-lnd92258-078-p56s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s2w1</LM>
   </w.rf>
   <form>Definuje</form>
   <lemma>definovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m-lnd92258-078-p56s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p56s2w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p57s1">
  <m id="m-lnd92258-078-p57s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p57s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-lnd92258-078-p57s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p57s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p57s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w5</LM>
   </w.rf>
   <form>živnostenské</form>
   <lemma>živnostenský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p57s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p57s1w6</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p58s1">
  <m id="m-lnd92258-078-p58s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p58s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p58s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p58s1w2</LM>
   </w.rf>
   <form>druhy</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p58s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p58s1w3</LM>
   </w.rf>
   <form>živností</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p59s1">
  <m id="m-lnd92258-078-p59s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p59s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p59s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p59s1w2</LM>
   </w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p59s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p59s1w3</LM>
   </w.rf>
   <form>živn</form>
   <lemma>živnostenský</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p59s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p59s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p59s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p59s1w5</LM>
   </w.rf>
   <form>oprávnění</form>
   <lemma>oprávnění_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p60s1">
  <m id="m-lnd92258-078-p60s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p60s1w1</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p60s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p60s1w2</LM>
   </w.rf>
   <form>vznik</form>
   <lemma>vznik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p60s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p60s1w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p60s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p60s1w4</LM>
   </w.rf>
   <form>zánik</form>
   <lemma>zánik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p60s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p60s1w5</LM>
   </w.rf>
   <form>živnosti</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p61s1">
  <m id="m-lnd92258-078-p61s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p61s1w1</LM>
   </w.rf>
   <form>Možné</form>
   <lemma>možný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p61s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p61s1w2</LM>
   </w.rf>
   <form>formy</form>
   <lemma>forma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p61s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p61s1w3</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p61s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p61s1w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p61s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p61s1w5</LM>
   </w.rf>
   <form>ČSFR</form>
   <lemma>ČSFR_;G_^(Čs._federativní_republika)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p62s1">
  <m id="m-lnd92258-078-p62s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w2</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w3</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w4</LM>
   </w.rf>
   <form>x</form>
   <lemma>x-5_^(náhr._symbolu_krát,_mat._symbol)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w5</LM>
   </w.rf>
   <form>}</form>
   <lemma>}</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w8</LM>
   </w.rf>
   <form>%</form>
   <lemma>%</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w9</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w10</LM>
   </w.rf>
   <form>Formy</form>
   <lemma>forma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w11</LM>
   </w.rf>
   <form>podnikání</form>
   <lemma>podnikání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p62s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p62s1w13</LM>
   </w.rf>
   <form>ČSFR</form>
   <lemma>ČSFR_;G_^(Čs._federativní_republika)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p63s1">
  <m id="m-lnd92258-078-p63s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p63s1w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p63s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p63s1w2</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p63s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p63s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p66s1">
  <m id="m-lnd92258-078-p66s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p66s1w1</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p66s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p66s1w2</LM>
   </w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p67s1">
  <m id="m-lnd92258-078-p67s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w1</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w2</LM>
   </w.rf>
   <form>charakter</form>
   <lemma>charakter</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w3</LM>
   </w.rf>
   <form>ručení</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w4</LM>
   </w.rf>
   <form>kapitál</form>
   <lemma>kapitál_^(peníze)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w6</LM>
   </w.rf>
   <form>účast</form>
   <lemma>účast</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w8</LM>
   </w.rf>
   <form>řízení</form>
   <lemma>řízení_^(*4dit)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w9</LM>
   </w.rf>
   <form>míra</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w10</LM>
   </w.rf>
   <form>veřejné</form>
   <lemma>veřejný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p67s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p67s1w11</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>kontroly</form>
   <lemma>kontrola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p68s1">
  <m id="m-lnd92258-078-p68s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>V-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92258-078-p68s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p68s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w3</LM>
   </w.rf>
   <form>O</form>
   <lemma>obchodní</lemma>
   <tag>AAFXX----1A---a</tag>
  </m>
  <m id="m-lnd92258-078-p68s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p68s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w5</LM>
   </w.rf>
   <form>S</form>
   <lemma>společnost</lemma>
   <tag>NNFXX-----A---a</tag>
  </m>
  <m id="m-lnd92258-078-p68s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p68s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p69s1">
  <m id="m-lnd92258-078-p69s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w1</LM>
   </w.rf>
   <form>K</form>
   <lemma>komanditní</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w3</LM>
   </w.rf>
   <form>S</form>
   <lemma>společnost</lemma>
   <tag>NNFXX-----A---a</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w5</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w6</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w7</LM>
   </w.rf>
   <form>neomezené</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w8</LM>
   </w.rf>
   <form>nízký</form>
   <lemma>nízký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w9</LM>
   </w.rf>
   <form>nutná</form>
   <lemma>nutný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w10</LM>
   </w.rf>
   <form>nízká</form>
   <lemma>nízký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w11</LM>
   </w.rf>
   <form>S</form>
   <lemma>společnost</lemma>
   <tag>NNFXX-----A---a</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w13</LM>
   </w.rf>
   <form>R</form>
   <lemma>ručení</lemma>
   <tag>NNNS7-----A---b</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w15</LM>
   </w.rf>
   <form>O</form>
   <lemma>omezený</lemma>
   <tag>AANS7----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p69s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p69s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p70s1">
  <m id="m-lnd92258-078-p70s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w1</LM>
   </w.rf>
   <form>A</form>
   <lemma>akciový</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w3</LM>
   </w.rf>
   <form>S</form>
   <lemma>společnost</lemma>
   <tag>NNFXX-----A---a</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w5</LM>
   </w.rf>
   <form>kapitálové</form>
   <lemma>kapitálový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w6</LM>
   </w.rf>
   <form>společnosti</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w7</LM>
   </w.rf>
   <form>omezené</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w8</LM>
   </w.rf>
   <form>vysoký</form>
   <lemma>vysoký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w9</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w10</LM>
   </w.rf>
   <form>nutná</form>
   <lemma>nutný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p70s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p70s1w11</LM>
   </w.rf>
   <form>vysoká</form>
   <lemma>vysoký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p71s1">
  <m id="m-lnd92258-078-p71s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p71s1w1</LM>
   </w.rf>
   <form>Veřejná</form>
   <lemma>veřejný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p71s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p71s1w2</LM>
   </w.rf>
   <form>obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p71s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p71s1w3</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p72s1">
  <m id="m-lnd92258-078-p72s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p72s1w1</LM>
   </w.rf>
   <form>Statut</form>
   <lemma>statut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p72s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p72s1w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p73s1">
  <m id="m-lnd92258-078-p73s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w1</LM>
   </w.rf>
   <form>alespoň</form>
   <lemma>alespoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w3</LM>
   </w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w4</LM>
   </w.rf>
   <form>podnikají</form>
   <lemma>podnikat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w5</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w6</LM>
   </w.rf>
   <form>společným</form>
   <lemma>společný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w7</LM>
   </w.rf>
   <form>obchodním</form>
   <lemma>obchodní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p73s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p73s1w8</LM>
   </w.rf>
   <form>jménem</form>
   <lemma>jméno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p74s1">
  <m id="m-lnd92258-078-p74s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p74s1w1</LM>
   </w.rf>
   <form>Ručení</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p74s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p74s1w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p75s1">
  <m id="m-lnd92258-078-p75s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w1</LM>
   </w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w3</LM>
   </w.rf>
   <form>nerozdílné</form>
   <lemma>rozdílný</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w4</LM>
   </w.rf>
   <form>celým</form>
   <lemma>celý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w5</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w6</LM>
   </w.rf>
   <form>majetkem</form>
   <lemma>majetek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w8</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m-lnd92258-078-p75s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p75s1w9</LM>
   </w.rf>
   <form>společníky</form>
   <lemma>společník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p76s1">
  <m id="m-lnd92258-078-p76s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w2</LM>
   </w.rf>
   <form>vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w4</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w6</LM>
   </w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrFP3----------</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w7</LM>
   </w.rf>
   <form>osobám</form>
   <lemma>osoba</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p76s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p76s1w8</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p77s1">
  <m id="m-lnd92258-078-p77s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w1</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w2</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w3</LM>
   </w.rf>
   <form>společníků</form>
   <lemma>společník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w5</LM>
   </w.rf>
   <form>popř</form>
   <lemma>popřípadě</lemma>
   <tag>Db------------b</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w7</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w8</LM>
   </w.rf>
   <form>najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p77s2">
  <m id="m-lnd92258-078-p77s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w1</LM>
   </w.rf>
   <form>Spol</form>
   <lemma>společenský</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w3</LM>
   </w.rf>
   <form>smlouva</form>
   <lemma>smlouva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w4</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w5</LM>
   </w.rf>
   <form>pověřit</form>
   <lemma>pověřit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w6</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w7</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w8</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w9</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w10</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w12</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m-lnd92258-078-p77s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p77s2w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p78s1">
  <m id="m-lnd92258-078-p78s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p78s1w1</LM>
   </w.rf>
   <form>Vznik</form>
   <lemma>vznik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p79s1">
  <m id="m-lnd92258-078-p79s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w1</LM>
   </w.rf>
   <form>společenskou</form>
   <lemma>společenský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w2</LM>
   </w.rf>
   <form>smlouvou</form>
   <lemma>smlouva</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w4</LM>
   </w.rf>
   <form>zápis</form>
   <lemma>zápis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w6</LM>
   </w.rf>
   <form>podnik</form>
   <lemma>podnikový</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p79s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p79s1w8</LM>
   </w.rf>
   <form>rejstříku</form>
   <lemma>rejstřík</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p80s1">
  <m id="m-lnd92258-078-p80s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p80s1w1</LM>
   </w.rf>
   <form>Komanditní</form>
   <lemma>komanditní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p80s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p80s1w2</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p81s1">
  <m id="m-lnd92258-078-p81s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p81s1w1</LM>
   </w.rf>
   <form>Statut</form>
   <lemma>statut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p81s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p81s1w2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p81s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p81s1w3</LM>
   </w.rf>
   <form>ručení</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p82s1">
  <m id="m-lnd92258-078-p82s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w1</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w3</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w4</LM>
   </w.rf>
   <form>společníků</form>
   <lemma>společník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w5</LM>
   </w.rf>
   <form>ručí</form>
   <lemma>ručit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w7</LM>
   </w.rf>
   <form>závazky</form>
   <lemma>závazek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w8</LM>
   </w.rf>
   <form>spol</form>
   <lemma>společnost</lemma>
   <tag>NNFXX-----A---b</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w11</LM>
   </w.rf>
   <form>výše</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w12</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w13</LM>
   </w.rf>
   <form>nesplaceného</form>
   <lemma>splacený_^(*4tit)</lemma>
   <tag>AAIS2----1N----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w14</LM>
   </w.rf>
   <form>vkladu</form>
   <lemma>vklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w15</LM>
   </w.rf>
   <form>zapsaného</form>
   <lemma>zapsaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w17</LM>
   </w.rf>
   <form>obch</form>
   <lemma>obchodní</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w19</LM>
   </w.rf>
   <form>rejstříku</form>
   <lemma>rejstřík</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w20</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w21</LM>
   </w.rf>
   <form>komandista</form>
   <lemma>komandista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w22</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w24</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w25</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w26</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w27</LM>
   </w.rf>
   <form>ručí</form>
   <lemma>ručit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w28</LM>
   </w.rf>
   <form>celým</form>
   <lemma>celý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w29</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w30</LM>
   </w.rf>
   <form>majetkem</form>
   <lemma>majetek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w31</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w32</LM>
   </w.rf>
   <form>komplementář</form>
   <lemma>komplementář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p82s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p82s1w33</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p83s1">
  <m id="m-lnd92258-078-p83s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w3</LM>
   </w.rf>
   <form>li</form>
   <lemma>li-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w5</LM>
   </w.rf>
   <form>názvu</form>
   <lemma>název</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w6</LM>
   </w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w7</LM>
   </w.rf>
   <form>uvedeno</form>
   <lemma>uvést</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w8</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w9</LM>
   </w.rf>
   <form>komandisty</form>
   <lemma>komandista</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w11</LM>
   </w.rf>
   <form>ručí</form>
   <lemma>ručit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w12</LM>
   </w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w13</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w14</LM>
   </w.rf>
   <form>komplementář</form>
   <lemma>komplementář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p83s2">
  <m id="m-lnd92258-078-p83s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w2</LM>
   </w.rf>
   <form>vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w4</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w6</LM>
   </w.rf>
   <form>třetím</form>
   <lemma>třetí</lemma>
   <tag>CrFP3----------</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w7</LM>
   </w.rf>
   <form>osobám</form>
   <lemma>osoba</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p83s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p83s2w8</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p84s1">
  <m id="m-lnd92258-078-p84s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w1</LM>
   </w.rf>
   <form>Statutárním</form>
   <lemma>statutární</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w2</LM>
   </w.rf>
   <form>orgánem</form>
   <lemma>orgán-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w4</LM>
   </w.rf>
   <form>komplementáři</form>
   <lemma>komplementář</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w7</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w8</LM>
   </w.rf>
   <form>jednat</form>
   <lemma>jednat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w9</LM>
   </w.rf>
   <form>samostatně</form>
   <lemma>samostatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w11</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w12</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w14</LM>
   </w.rf>
   <form>spol</form>
   <lemma>společenský</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w16</LM>
   </w.rf>
   <form>smlouvě</form>
   <lemma>smlouva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w17</LM>
   </w.rf>
   <form>uvedeno</form>
   <lemma>uvést</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w18</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s1w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p84s2">
  <m id="m-lnd92258-078-p84s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w1</LM>
   </w.rf>
   <form>Komandista</form>
   <lemma>komandista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w2</LM>
   </w.rf>
   <form>ručí</form>
   <lemma>ručit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w4</LM>
   </w.rf>
   <form>jím</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3-------</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w5</LM>
   </w.rf>
   <form>uzavřené</form>
   <lemma>uzavřený_^(*3ít)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w6</LM>
   </w.rf>
   <form>smlouvy</form>
   <lemma>smlouva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w7</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w8</LM>
   </w.rf>
   <form>zmocnění</form>
   <lemma>zmocnění_^(*2t)_(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w10</LM>
   </w.rf>
   <form>komplementář</form>
   <lemma>komplementář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p84s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p84s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p85s1">
  <m id="m-lnd92258-078-p85s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p85s1w1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p85s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p85s1w2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92258-078-p85s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p85s1w3</LM>
   </w.rf>
   <form>ručením</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p85s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p85s1w4</LM>
   </w.rf>
   <form>omezeným</form>
   <lemma>omezený_^(*3it)</lemma>
   <tag>AANS7----1A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p86s1">
  <m id="m-lnd92258-078-p86s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p86s1w1</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Statut</form>
   <lemma>statut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p87s1">
  <m id="m-lnd92258-078-p87s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w1</LM>
   </w.rf>
   <form>Základní</form>
   <lemma>základní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w2</LM>
   </w.rf>
   <form>jmění</form>
   <lemma>jmění</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w4</LM>
   </w.rf>
   <form>tvořeno</form>
   <lemma>tvořit</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w5</LM>
   </w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w6</LM>
   </w.rf>
   <form>stanoveným</form>
   <lemma>stanovený_^(*3it)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w7</LM>
   </w.rf>
   <form>vkladem</form>
   <lemma>vklad</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p87s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p87s1w8</LM>
   </w.rf>
   <form>společníků</form>
   <lemma>společník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p88s1">
  <m id="m-lnd92258-078-p88s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p88s1w1</LM>
   </w.rf>
   <form>Počet</form>
   <lemma>počet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p88s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p88s1w2</LM>
   </w.rf>
   <form>společníků</form>
   <lemma>společník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p89s1">
  <m id="m-lnd92258-078-p89s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p89s1w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-078-p89s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p89s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p89s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p89s1w3</LM>
   </w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p90s1">
  <m id="m-lnd92258-078-p90s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w1</LM>
   </w.rf>
   <form>Hodnota</form>
   <lemma>hodnota</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p90s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w2</LM>
   </w.rf>
   <form>základního</form>
   <lemma>základní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p90s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w3</LM>
   </w.rf>
   <form>jmění</form>
   <lemma>jmění</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p90s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p90s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w5</LM>
   </w.rf>
   <form>minimální</form>
   <lemma>minimální</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p90s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p90s1w6</LM>
   </w.rf>
   <form>vklad</form>
   <lemma>vklad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p91s1">
  <m id="m-lnd92258-078-p91s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s1w1</LM>
   </w.rf>
   <form>Min</form>
   <lemma>minimálně</lemma>
   <tag>Dg-------1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p91s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p91s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s1w3</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>100000</form>
   <lemma>100000</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p91s2">
  <m id="m-lnd92258-078-p91s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w1</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w3</LM>
   </w.rf>
   <form>min</form>
   <lemma>minimální</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w5</LM>
   </w.rf>
   <form>vklad</form>
   <lemma>vklad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w6</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w7</LM>
   </w.rf>
   <form>společníka</form>
   <lemma>společník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w8</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>20000</form>
   <lemma>20000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-078-p91s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p91s2w9</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p92s1">
  <m id="m-lnd92258-078-p92s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p92s1w1</LM>
   </w.rf>
   <form>Ručení</form>
   <lemma>ručení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p93s1">
  <m id="m-lnd92258-078-p93s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w2</LM>
   </w.rf>
   <form>ručí</form>
   <lemma>ručit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w3</LM>
   </w.rf>
   <form>celým</form>
   <lemma>celý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w4</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w5</LM>
   </w.rf>
   <form>majetkem</form>
   <lemma>majetek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w7</LM>
   </w.rf>
   <form>společník</form>
   <lemma>společník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w9</LM>
   </w.rf>
   <form>výše</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w10</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w11</LM>
   </w.rf>
   <form>vkladu</form>
   <lemma>vklad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p93s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p93s1w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p94s1">
  <m id="m-lnd92258-078-p94s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p94s1w1</LM>
   </w.rf>
   <form>Obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p94s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p94s1w2</LM>
   </w.rf>
   <form>vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p95s1">
  <m id="m-lnd92258-078-p95s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w1</LM>
   </w.rf>
   <form>Nejvyšším</form>
   <lemma>vysoký</lemma>
   <tag>AAIS7----3A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w2</LM>
   </w.rf>
   <form>orgánem</form>
   <lemma>orgán-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w4</LM>
   </w.rf>
   <form>valná</form>
   <lemma>valný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w5</LM>
   </w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w7</LM>
   </w.rf>
   <form>statutárním</form>
   <lemma>statutární</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w8</LM>
   </w.rf>
   <form>orgánem</form>
   <lemma>orgán-1</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w10</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w11</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w12</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w13</LM>
   </w.rf>
   <form>jednatelů</form>
   <lemma>jednatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s1w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p95s2">
  <m id="m-lnd92258-078-p95s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w1</LM>
   </w.rf>
   <form>Stanovy</form>
   <lemma>stanovy</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w2</LM>
   </w.rf>
   <form>mohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w3</LM>
   </w.rf>
   <form>určit</form>
   <lemma>určit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w5</LM>
   </w.rf>
   <form>dozorčí</form>
   <lemma>dozorčí</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w6</LM>
   </w.rf>
   <form>radu</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu;poradní_sbor)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p95s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p95s2w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p96s1">
  <m id="m-lnd92258-078-p96s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p96s1w1</LM>
   </w.rf>
   <form>Akciová</form>
   <lemma>akciový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p96s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p96s1w2</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p97s1">
  <m id="m-lnd92258-078-p97s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p97s1w1</LM>
   </w.rf>
   <form>Statut</form>
   <lemma>statut</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92258-078-p98s1">
  <m id="m-lnd92258-078-p98s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w1</LM>
   </w.rf>
   <form>Společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w3</LM>
   </w.rf>
   <form>jejíž</form>
   <lemma>jehož</lemma>
   <tag>P1ZS1FS3-------</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w4</LM>
   </w.rf>
   <form>základní</form>
   <lemma>základní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w5</LM>
   </w.rf>
   <form>jmění</form>
   <lemma>jmění</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>rozvrženo</form>
   <lemma>rozvrhnout</lemma>
   <tag>VsNS----X-APP-1</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w9</LM>
   </w.rf>
   <form>určitý</form>
   <lemma>určitý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w10</LM>
   </w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w11</LM>
   </w.rf>
   <form>akcií</form>
   <lemma>akcie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w13</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w14</LM>
   </w.rf>
   <form>jmenovité</form>
   <lemma>jmenovitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w15</LM>
   </w.rf>
   <form>hodnotě</form>
   <lemma>hodnota</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92258-078-p98s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-078-p98s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
