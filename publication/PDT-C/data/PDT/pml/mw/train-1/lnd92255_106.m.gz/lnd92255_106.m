<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92255_106.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92255-106-p1s1">
  <m id="m-lnd92255-106-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p1s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5355405195.51</form>
   <lemma>5355405195.51</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p1s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p1s1w3</LM>
   </w.rf>
   <form>5.55</form>
   <lemma>5.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p1s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p2s1">
  <m id="m-lnd92255-106-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w1</LM>
   </w.rf>
   <form>210221.2419</form>
   <lemma>210221.2419</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w3</LM>
   </w.rf>
   <form>8821.32</form>
   <lemma>8821.32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w5</LM>
   </w.rf>
   <form>21.11</form>
   <lemma>21.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p3s1">
  <m id="m-lnd92255-106-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p3s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2582612542.66</form>
   <lemma>2582612542.66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p3s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p3s1w3</LM>
   </w.rf>
   <form>2.69</form>
   <lemma>2.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p3s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p4s1">
  <m id="m-lnd92255-106-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w1</LM>
   </w.rf>
   <form>181418.3217</form>
   <lemma>181418.3217</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w3</LM>
   </w.rf>
   <form>7718.69</form>
   <lemma>7718.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w5</LM>
   </w.rf>
   <form>18.86</form>
   <lemma>18.86</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p5s1">
  <m id="m-lnd92255-106-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w1</LM>
   </w.rf>
   <form>203520.5519</form>
   <lemma>203520.5519</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w3</LM>
   </w.rf>
   <form>9421.00</form>
   <lemma>9421.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w5</LM>
   </w.rf>
   <form>21.17</form>
   <lemma>21.17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p6s1">
  <m id="m-lnd92255-106-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w1</LM>
   </w.rf>
   <form>279328.2127</form>
   <lemma>279328.2127</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w3</LM>
   </w.rf>
   <form>3728.77</form>
   <lemma>3728.77</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w5</LM>
   </w.rf>
   <form>28.54</form>
   <lemma>28.54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92255-106-p7s1">
  <m id="m-lnd92255-106-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w1</LM>
   </w.rf>
   <form>440144.4542</form>
   <lemma>440144.4542</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w3</LM>
   </w.rf>
   <form>4045.54</form>
   <lemma>4045.54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92255-106-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w5</LM>
   </w.rf>
   <form>46.51</form>
   <lemma>46.51</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92255-106-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92255-106-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
