<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92254_094.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92254-094-p1s1">
  <m id="m-lnd92254-094-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p1s1w1</LM>
   </w.rf>
   <form>Tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p2s1">
  <m id="m-lnd92254-094-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s1w1</LM>
   </w.rf>
   <form>San</form>
   <lemma>San-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s1w2</LM>
   </w.rf>
   <form>Juan</form>
   <lemma>Juan-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s1w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p2s2">
  <m id="m-lnd92254-094-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w5</LM>
   </w.rf>
   <form>Coetzerová</form>
   <lemma>Coetzerová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w7</LM>
   </w.rf>
   <form>Kuhlmanová</form>
   <lemma>Kuhlmanová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w10</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w12</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w14</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w16</LM>
   </w.rf>
   <form>Halardová</form>
   <lemma>Halardová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w17</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w18</LM>
   </w.rf>
   <form>Faberová</form>
   <lemma>Faberová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w19</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w20</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w21</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w23</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w24</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w25</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w27</LM>
   </w.rf>
   <form>Rinaldiová</form>
   <lemma>Rinaldiová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w28</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w29</LM>
   </w.rf>
   <form>Kellerová</form>
   <lemma>Kellerová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w30</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w31</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w32</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w33</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w34</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w35</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w36</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w37</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w38</LM>
   </w.rf>
   <form>Allenová</form>
   <lemma>Allenová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w39</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w40</LM>
   </w.rf>
   <form>Kochtová</form>
   <lemma>Kochtová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w41</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w42</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w43</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w44</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w45</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w46</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w47</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p2s2w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p2s2w48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p3s1">
  <m id="m-lnd92254-094-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s1w1</LM>
   </w.rf>
   <form>Stockholm</form>
   <lemma>Stockholm_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p3s2">
  <m id="m-lnd92254-094-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w1</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w5</LM>
   </w.rf>
   <form>Muster</form>
   <lemma>Muster_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w7</LM>
   </w.rf>
   <form>Wahlgren</form>
   <lemma>Wahlgren_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w10</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w12</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w14</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w16</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w17</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w18</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w20</LM>
   </w.rf>
   <form>Bergström</form>
   <lemma>Bergström_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w21</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w22</LM>
   </w.rf>
   <form>Costa</form>
   <lemma>Costa-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w23</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w24</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w25</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w27</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w28</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w29</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w31</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w32</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w33</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w34</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w35</LM>
   </w.rf>
   <form>Mansdorf</form>
   <lemma>Mansdorf-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w36</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w37</LM>
   </w.rf>
   <form>Volkov</form>
   <lemma>Volkov_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w38</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w39</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w40</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w42</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w43</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w44</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w45</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w46</LM>
   </w.rf>
   <form>Edberg</form>
   <lemma>Edberg_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w47</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w48</LM>
   </w.rf>
   <form>Medveděv</form>
   <lemma>Medveděv_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w49</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w50</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w51</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w52</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w53</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w54</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w55</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w56</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w57</LM>
   </w.rf>
   <form>Nováček</form>
   <lemma>Nováček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w58</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w59</LM>
   </w.rf>
   <form>Česnokov</form>
   <lemma>Česnokov_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w60</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w61</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w62</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w63</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w64</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w65">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w65</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w66">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w66</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w67">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w68">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w68</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w69">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w69</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w70">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w70</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w71">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w71</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w72">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w72</LM>
   </w.rf>
   <form>Becker</form>
   <lemma>Becker_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w73">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w73</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w74">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w74</LM>
   </w.rf>
   <form>Svensson</form>
   <lemma>Svensson_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w75">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w75</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w76">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w76</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w77">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w77</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w78">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w78</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w79">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w79</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w80">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w80</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w81">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w81</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w82">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w82</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w83">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w83</LM>
   </w.rf>
   <form>Gustafsson</form>
   <lemma>Gustafsson_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w84">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w84</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w85">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w85</LM>
   </w.rf>
   <form>Clavet</form>
   <lemma>Clavet_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w86">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w86</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w87">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w87</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w88">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w88</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w89">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w89</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w90">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w90</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w91">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w91</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w92">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w92</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p3s2w93">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p3s2w93</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p4s1">
  <m id="m-lnd92254-094-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s1w1</LM>
   </w.rf>
   <form>Guaruja</form>
   <lemma>Guaruja_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p4s2">
  <m id="m-lnd92254-094-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w5</LM>
   </w.rf>
   <form>Arrese</form>
   <lemma>Arrese_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w7</LM>
   </w.rf>
   <form>Herrera</form>
   <lemma>Herrera_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w10</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w12</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w14</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w16</LM>
   </w.rf>
   <form>Oncins</form>
   <lemma>Oncins_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w17</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w18</LM>
   </w.rf>
   <form>Azar</form>
   <lemma>Azar_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w19</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w20</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w21</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w23</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w24</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w25</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w27</LM>
   </w.rf>
   <form>Roese</form>
   <lemma>Roese_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w28</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w29</LM>
   </w.rf>
   <form>Davin</form>
   <lemma>Davin_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w30</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w31</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w32</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w33</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w34</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w35</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w36</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w37</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w38</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w39</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w40</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w42</LM>
   </w.rf>
   <form>Filippini</form>
   <lemma>Filippini_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w43</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w44</LM>
   </w.rf>
   <form>Adams</form>
   <lemma>Adams_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w45</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w46</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w47</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w48</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w49</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w50</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w51</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p4s2w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p4s2w52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p5s1">
  <m id="m-lnd92254-094-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s1w1</LM>
   </w.rf>
   <form>Caracas</form>
   <lemma>Caracas_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p5s2">
  <m id="m-lnd92254-094-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w1</LM>
   </w.rf>
   <form>finále</form>
   <lemma>finále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w3</LM>
   </w.rf>
   <form>Vacek</form>
   <lemma>Vacek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w4</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w5</LM>
   </w.rf>
   <form>Sznajder</form>
   <lemma>Sznajder_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w6</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w10</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w11</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w12</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p5s2w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p6s1">
  <m id="m-lnd92254-094-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s1w1</LM>
   </w.rf>
   <form>Hongkong</form>
   <lemma>Hongkong_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s1w3</LM>
   </w.rf>
   <form>junioři</form>
   <lemma>junior</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s1w5</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p6s2">
  <m id="m-lnd92254-094-p6s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w1</LM>
   </w.rf>
   <form>Kukal</form>
   <lemma>Kukal_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w2</LM>
   </w.rf>
   <form>porazil</form>
   <lemma>porazit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w4</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w6</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w7</LM>
   </w.rf>
   <form>Witze</form>
   <lemma>Witz_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w10</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w12</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w14</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w16</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w17</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s2w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p6s3">
  <m id="m-lnd92254-094-p6s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w1</LM>
   </w.rf>
   <form>Abadu</form>
   <lemma>Abada_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w2</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w4</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w6</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w10</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w11</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s3w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p6s4">
  <m id="m-lnd92254-094-p6s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w1</LM>
   </w.rf>
   <form>Bandurowského</form>
   <lemma>Bandurowský_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w2</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w4</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w6</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w8</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w10</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w11</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w12</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s4w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p6s5">
  <m id="m-lnd92254-094-p6s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w1</LM>
   </w.rf>
   <form>Hronec</form>
   <lemma>Hronec_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w2</LM>
   </w.rf>
   <form>zvítězil</form>
   <lemma>zvítězit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w4</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w6</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w7</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w8</LM>
   </w.rf>
   <form>Iwabušim</form>
   <lemma>Iwabuši_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w9</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w10</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w11</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w13</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w14</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w15</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w17</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w18</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w19</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w21</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w22</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w24</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w25</LM>
   </w.rf>
   <form>Merinem</form>
   <lemma>merino</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w26</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w27</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w28</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w29</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w30</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w31</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w32</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p6s5w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p6s5w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p7s1">
  <m id="m-lnd92254-094-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p7s1w1</LM>
   </w.rf>
   <form>Hokej</form>
   <lemma>hokej</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p8s1">
  <m id="m-lnd92254-094-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w2</LM>
   </w.rf>
   <form>pátém</form>
   <lemma>pátý</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w3</LM>
   </w.rf>
   <form>zápase</form>
   <lemma>zápas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w5</LM>
   </w.rf>
   <form>Kanadě</form>
   <lemma>Kanada_;G_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w6</LM>
   </w.rf>
   <form>Francouzi</form>
   <lemma>Francouz_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w7</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w8</LM>
   </w.rf>
   <form>neuspěli</form>
   <lemma>uspět</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w11</LM>
   </w.rf>
   <form>Campbeltonu</form>
   <lemma>Campbelton_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w12</LM>
   </w.rf>
   <form>prohráli</form>
   <lemma>prohrát</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w13</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w14</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w15</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p8s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p8s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p9s1">
  <m id="m-lnd92254-094-p9s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p9s1w1</LM>
   </w.rf>
   <form>Šerm</form>
   <lemma>šerm</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p10s1">
  <m id="m-lnd92254-094-p10s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w2</LM>
   </w.rf>
   <form>ME</form>
   <lemma>ME_^(mistrovství_Evropy)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w4</LM>
   </w.rf>
   <form>Lisabonu</form>
   <lemma>Lisabon_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w5</LM>
   </w.rf>
   <form>obsadil</form>
   <lemma>obsadit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w7</LM>
   </w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w8</LM>
   </w.rf>
   <form>kordistů</form>
   <lemma>kordista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w9</LM>
   </w.rf>
   <form>Ječmínek</form>
   <lemma>Ječmínek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w10</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w12</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w16</LM>
   </w.rf>
   <form>boji</form>
   <lemma>boj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w18</LM>
   </w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w19</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w20</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w21</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w22</LM>
   </w.rf>
   <form>prohrál</form>
   <lemma>prohrát</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w23</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w24</LM>
   </w.rf>
   <form>pozdějším</form>
   <lemma>pozdější</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w25</LM>
   </w.rf>
   <form>mistrem</form>
   <lemma>mistr</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w26</LM>
   </w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w27</LM>
   </w.rf>
   <form>Fleglerem</form>
   <lemma>Flegler_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w28</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w29</LM>
   </w.rf>
   <form>Něm</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNXX-----A---b</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w31</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s1w32</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p10s2">
  <m id="m-lnd92254-094-p10s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w1</LM>
   </w.rf>
   <form>Douba</form>
   <lemma>Douba_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w2</LM>
   </w.rf>
   <form>obsadil</form>
   <lemma>obsadit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p10s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w3</LM>
   </w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p10s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w5</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p10s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p10s2w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p11s1">
  <m id="m-lnd92254-094-p11s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p11s1w1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p11s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p11s1w2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p11s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p11s1w3</LM>
   </w.rf>
   <form>vyhráli</form>
   <lemma>vyhrát</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p11s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p11s1w4</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s1">
  <m id="m-lnd92254-094-p12s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w2</LM>
   </w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w4</LM>
   </w.rf>
   <form>týdnu</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w5</LM>
   </w.rf>
   <form>Sazky</form>
   <lemma>sazka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w6</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w8</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w10</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w11</LM>
   </w.rf>
   <form>výhra</form>
   <lemma>výhra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w14</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w16</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w17</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w18</LM>
   </w.rf>
   <form>výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w19</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>106662</form>
   <lemma>106662</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w20</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w22</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w23</LM>
   </w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w26</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w27</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w28</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>23701</form>
   <lemma>23701</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w29</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s1w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s2">
  <m id="m-lnd92254-094-p12s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w2</LM>
   </w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w4</LM>
   </w.rf>
   <form>týdnu</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w5</LM>
   </w.rf>
   <form>Skóre</form>
   <lemma>skóre</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w6</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w8</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w11</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w13</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w14</LM>
   </w.rf>
   <form>výhra</form>
   <lemma>výhra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s2w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s3">
  <m id="m-lnd92254-094-p12s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w2</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w4</LM>
   </w.rf>
   <form>tahu</form>
   <lemma>tah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w5</LM>
   </w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w7</LM>
   </w.rf>
   <form>týdne</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w8</LM>
   </w.rf>
   <form>Sportky</form>
   <lemma>Sportka_;m</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w9</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w11</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w14</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w16</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w17</LM>
   </w.rf>
   <form>výhra</form>
   <lemma>výhra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w19</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w20</LM>
   </w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w22</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w23</LM>
   </w.rf>
   <form>112</form>
   <lemma>112</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w24</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w25</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>21734</form>
   <lemma>21734</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w26</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w28</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w29</LM>
   </w.rf>
   <form>IV</form>
   <lemma>IV-3`4</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w31</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w32</LM>
   </w.rf>
   <form>7574</form>
   <lemma>7574</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w33</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w34</LM>
   </w.rf>
   <form>468</form>
   <lemma>468</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w35</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w36</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w37</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w38</LM>
   </w.rf>
   <form>V</form>
   <lemma>V-3`5</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w39</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w40</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w41</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>134314</form>
   <lemma>134314</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w42</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w43</LM>
   </w.rf>
   <form>36</form>
   <lemma>36</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w44</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s3w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s3w45</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s4">
  <m id="m-lnd92254-094-p12s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w2</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w4</LM>
   </w.rf>
   <form>tahu</form>
   <lemma>tah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w7</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w9</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w10</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w11</LM>
   </w.rf>
   <form>výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w12</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>811070</form>
   <lemma>811070</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w13</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w15</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w16</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w19</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w20</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w21</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>216292</form>
   <lemma>216292</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w22</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w24</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w25</LM>
   </w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w27</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w28</LM>
   </w.rf>
   <form>291</form>
   <lemma>291</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w29</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w30</LM>
   </w.rf>
   <form>5616</form>
   <lemma>5616</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w31</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w32</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w33</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w34</LM>
   </w.rf>
   <form>IV</form>
   <lemma>IV-3`4</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w36</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w37</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>14448</form>
   <lemma>14448</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w38</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w39</LM>
   </w.rf>
   <form>190</form>
   <lemma>190</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w40</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w41</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w42</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w43</LM>
   </w.rf>
   <form>V</form>
   <lemma>V-3`5</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w45</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w46</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>196383</form>
   <lemma>196383</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w47</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w48</LM>
   </w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w49</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s4w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s4w50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s5">
  <m id="m-lnd92254-094-p12s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w2</LM>
   </w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w4</LM>
   </w.rf>
   <form>týdnu</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w5</LM>
   </w.rf>
   <form>Matesa</form>
   <lemma>Mates-1_;m</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w8</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w10</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w11</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w12</LM>
   </w.rf>
   <form>výhry</form>
   <lemma>výhra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w13</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>103529</form>
   <lemma>103529</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w14</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w16</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w17</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w20</LM>
   </w.rf>
   <form>240</form>
   <lemma>240</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w21</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w22</LM>
   </w.rf>
   <form>1949</form>
   <lemma>1949</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w23</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w25</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w26</LM>
   </w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w28</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w29</LM>
   </w.rf>
   <form>8152</form>
   <lemma>8152</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w30</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w31</LM>
   </w.rf>
   <form>95</form>
   <lemma>95</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w32</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s5w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s5w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p12s6">
  <m id="m-lnd92254-094-p12s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w2</LM>
   </w.rf>
   <form>43</form>
   <lemma>43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w4</LM>
   </w.rf>
   <form>týdnu</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w5</LM>
   </w.rf>
   <form>Šance</form>
   <lemma>šance</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w6</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w8</LM>
   </w.rf>
   <form>I</form>
   <lemma>I-3`1</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w10</LM>
   </w.rf>
   <form>pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w11</LM>
   </w.rf>
   <form>výhra</form>
   <lemma>výhra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w13</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w14</LM>
   </w.rf>
   <form>II</form>
   <lemma>II-3`2</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w17</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w18</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w19</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>100000</form>
   <lemma>100000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w20</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w22</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w23</LM>
   </w.rf>
   <form>III</form>
   <lemma>III-3`3</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w26</LM>
   </w.rf>
   <form>49</form>
   <lemma>49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w27</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w28</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>10000</form>
   <lemma>10000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w29</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w31</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w32</LM>
   </w.rf>
   <form>IV</form>
   <lemma>IV-3`4</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w34</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w35</LM>
   </w.rf>
   <form>434</form>
   <lemma>434</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w36</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w37</LM>
   </w.rf>
   <form>1000</form>
   <lemma>1000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w38</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w39</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w40</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w41</LM>
   </w.rf>
   <form>V</form>
   <lemma>V-3`5</lemma>
   <tag>C}-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w43</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w44</LM>
   </w.rf>
   <form>4438</form>
   <lemma>4438</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w45</LM>
   </w.rf>
   <form>výher</form>
   <lemma>výhra</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w46</LM>
   </w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w47</LM>
   </w.rf>
   <form>Kčs</form>
   <lemma>Kčs_^(Koruna_čs.)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p12s6w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p12s6w48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p13s1">
  <m id="m-lnd92254-094-p13s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p13s1w1</LM>
   </w.rf>
   <form>Judo</form>
   <lemma>judo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p14s1">
  <m id="m-lnd92254-094-p14s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w1</LM>
   </w.rf>
   <form>Mistry</form>
   <lemma>mistr</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w2</LM>
   </w.rf>
   <form>Evropy</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w4</LM>
   </w.rf>
   <form>soutěži</form>
   <lemma>soutěž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w5</LM>
   </w.rf>
   <form>družstev</form>
   <lemma>družstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w8</LM>
   </w.rf>
   <form>Leondingu</form>
   <lemma>Leonding_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w9</LM>
   </w.rf>
   <form>staly</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w10</LM>
   </w.rf>
   <form>kolektivy</form>
   <lemma>kolektiv</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w11</LM>
   </w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s1w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p14s2">
  <m id="m-lnd92254-094-p14s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w1</LM>
   </w.rf>
   <form>Čs</form>
   <lemma>československý</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w3</LM>
   </w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w4</LM>
   </w.rf>
   <form>skončili</form>
   <lemma>skončit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w5</LM>
   </w.rf>
   <form>sedmí</form>
   <lemma>sedmý</lemma>
   <tag>CrMP1----------</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w7</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w8</LM>
   </w.rf>
   <form>obsadily</form>
   <lemma>obsadit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w9</LM>
   </w.rf>
   <form>pátou</form>
   <lemma>pátý</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w10</LM>
   </w.rf>
   <form>příčku</form>
   <lemma>příčka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p14s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p14s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p15s1">
  <m id="m-lnd92254-094-p15s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p15s1w1</LM>
   </w.rf>
   <form>Fotbal</form>
   <lemma>fotbal</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p16s1">
  <m id="m-lnd92254-094-p16s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w1</LM>
   </w.rf>
   <form>Trenér</form>
   <lemma>trenér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w2</LM>
   </w.rf>
   <form>FC</form>
   <lemma>FC-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w3</LM>
   </w.rf>
   <form>Liverpool</form>
   <lemma>Liverpool_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w4</LM>
   </w.rf>
   <form>G</form>
   <lemma>G-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w6</LM>
   </w.rf>
   <form>Souness</form>
   <lemma>Souness_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w7</LM>
   </w.rf>
   <form>nesmí</form>
   <lemma>smět</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w8</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w9</LM>
   </w.rf>
   <form>výroku</form>
   <lemma>výrok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w10</LM>
   </w.rf>
   <form>disciplinární</form>
   <lemma>disciplinární</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w11</LM>
   </w.rf>
   <form>komise</form>
   <lemma>komise</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w12</LM>
   </w.rf>
   <form>UEFA</form>
   <lemma>UEFA_;m_^(Evr._fotbalová_federace)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w14</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w15</LM>
   </w.rf>
   <form>zápasech</form>
   <lemma>zápas</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w16</LM>
   </w.rf>
   <form>evropských</form>
   <lemma>evropský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w17</LM>
   </w.rf>
   <form>pohárů</form>
   <lemma>pohár</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w19</LM>
   </w.rf>
   <form>lavičku</form>
   <lemma>lavička-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w20</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w21</LM>
   </w.rf>
   <form>útok</form>
   <lemma>útok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w22</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w23</LM>
   </w.rf>
   <form>rozhodčího</form>
   <lemma>rozhodčí-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w25</LM>
   </w.rf>
   <form>zápase</form>
   <lemma>zápas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w26</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w27</LM>
   </w.rf>
   <form>Spartakem</form>
   <lemma>Spartak-2_;m</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w28</LM>
   </w.rf>
   <form>Moskva</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s1w29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p16s2">
  <m id="m-lnd92254-094-p16s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w1</LM>
   </w.rf>
   <form>Liverpoolský</form>
   <lemma>liverpoolský</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w2</LM>
   </w.rf>
   <form>brankař</form>
   <lemma>brankař_,s_^(^DD**brankář)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w3</LM>
   </w.rf>
   <form>Grobbelaar</form>
   <lemma>Grobbelaar_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w6</LM>
   </w.rf>
   <form>vyloučení</form>
   <lemma>vyloučení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w7</LM>
   </w.rf>
   <form>nezahraje</form>
   <lemma>zahrát</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w9</LM>
   </w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS6----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w10</LM>
   </w.rf>
   <form>zápase</form>
   <lemma>zápas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p16s3">
  <m id="m-lnd92254-094-p16s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w1</LM>
   </w.rf>
   <form>Kvalifikace</form>
   <lemma>kvalifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w3</LM>
   </w.rf>
   <form>ME</form>
   <lemma>ME_^(mistrovství_Evropy)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w5</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w8</LM>
   </w.rf>
   <form>Turecko</form>
   <lemma>Turecko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w9</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w10</LM>
   </w.rf>
   <form>San</form>
   <lemma>San-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w11</LM>
   </w.rf>
   <form>Marino</form>
   <lemma>Marino-1_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w12</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w14</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w15</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w16</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w17</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w18</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w19</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w21</LM>
   </w.rf>
   <form>Rakousko</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w22</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w23</LM>
   </w.rf>
   <form>Izrael</form>
   <lemma>Izrael_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w24</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w25</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w26</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w27</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w28</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w29</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w30</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w31</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w32</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w33</LM>
   </w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w34</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w35</LM>
   </w.rf>
   <form>Lucembursko</form>
   <lemma>Lucembursko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w36</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w37</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w38</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w39</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w40</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w41</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w42</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w43</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p16s3w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p16s3w44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p17s1">
  <m id="m-lnd92254-094-p17s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w1</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w4</LM>
   </w.rf>
   <form>anglického</form>
   <lemma>anglický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w5</LM>
   </w.rf>
   <form>ligového</form>
   <lemma>ligový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w6</LM>
   </w.rf>
   <form>poháru</form>
   <lemma>pohár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w8</LM>
   </w.rf>
   <form>Scunthorpe</form>
   <lemma>Scunthorpe_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w9</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w10</LM>
   </w.rf>
   <form>Leeds</form>
   <lemma>Leeds_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w11</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w12</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w13</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w14</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w15</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w16</LM>
   </w.rf>
   <form>utkání</form>
   <lemma>utkání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w17</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w18</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w19</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w21</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>postupuje</form>
   <lemma>postupovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w22</LM>
   </w.rf>
   <form>Leeds</form>
   <lemma>Leeds_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w23</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w24</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w25</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w27</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w28</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w29</LM>
   </w.rf>
   <form>přímý</form>
   <lemma>přímý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w30</LM>
   </w.rf>
   <form>postup</form>
   <lemma>postup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w31</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w32</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w33</LM>
   </w.rf>
   <form>Bury</form>
   <lemma>Bury-2_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w34</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w35</LM>
   </w.rf>
   <form>Q</form>
   <lemma>Q-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w36</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w37</LM>
   </w.rf>
   <form>P</form>
   <lemma>P-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w39</LM>
   </w.rf>
   <form>R</form>
   <lemma>R-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s1w40</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p17s2">
  <m id="m-lnd92254-094-p17s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w1</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w3</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w5</LM>
   </w.rf>
   <form>Notts</form>
   <lemma>Notts-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w6</LM>
   </w.rf>
   <form>County</form>
   <lemma>County-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w7</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w8</LM>
   </w.rf>
   <form>Cambridge</form>
   <lemma>Cambridge_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w9</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w10</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w11</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w13</LM>
   </w.rf>
   <form>Plymouth</form>
   <lemma>Plymouth_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w14</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w15</LM>
   </w.rf>
   <form>Scarborough</form>
   <lemma>Scarborough_;G</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w16</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w17</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w18</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w20</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w22</LM>
   </w.rf>
   <form>opakovat</form>
   <lemma>opakovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w24</LM>
   </w.rf>
   <form>Portsmouth</form>
   <lemma>Portsmouth_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w25</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w26</LM>
   </w.rf>
   <form>Ipswich</form>
   <lemma>Ipswich_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w27</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w28</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w29</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w31</LM>
   </w.rf>
   <form>Sheffield</form>
   <lemma>Sheffield_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w32</LM>
   </w.rf>
   <form>W</form>
   <lemma>W-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w34</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w35</LM>
   </w.rf>
   <form>Leicester</form>
   <lemma>Leicester_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w36</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w37</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w38</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w39</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w40</LM>
   </w.rf>
   <form>Swindon</form>
   <lemma>Swindon_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w41</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w42</LM>
   </w.rf>
   <form>Oldham</form>
   <lemma>Oldham_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w43</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w44</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p17s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p17s2w45</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p18s1">
  <m id="m-lnd92254-094-p18s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p18s1w1</LM>
   </w.rf>
   <form>Basketbal</form>
   <lemma>basketbal</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p19s1">
  <m id="m-lnd92254-094-p19s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s1w1</LM>
   </w.rf>
   <form>USK</form>
   <lemma>USK-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s1w2</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s1w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p19s2">
  <m id="m-lnd92254-094-p19s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w1</LM>
   </w.rf>
   <form>CSKA</form>
   <lemma>CSKA-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w2</LM>
   </w.rf>
   <form>Moskva</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w3</LM>
   </w.rf>
   <form>96</form>
   <lemma>96</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w5</LM>
   </w.rf>
   <form>113</form>
   <lemma>113</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w6</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w7</LM>
   </w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w8</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w9</LM>
   </w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w10</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w12</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w13</LM>
   </w.rf>
   <form>zápas</form>
   <lemma>zápas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w14</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w16</LM>
   </w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w17</LM>
   </w.rf>
   <form>Evropského</form>
   <lemma>evropský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w18</LM>
   </w.rf>
   <form>poháru</form>
   <lemma>pohár</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w19</LM>
   </w.rf>
   <form>klubů</form>
   <lemma>klub</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w20</LM>
   </w.rf>
   <form>mužů</form>
   <lemma>muž</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p19s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p19s2w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p20s1">
  <m id="m-lnd92254-094-p20s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p20s1w1</LM>
   </w.rf>
   <form>Volejbal</form>
   <lemma>volejbal</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p21s1">
  <m id="m-lnd92254-094-p21s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w1</LM>
   </w.rf>
   <form>Český</form>
   <lemma>český</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w2</LM>
   </w.rf>
   <form>pohár</form>
   <lemma>pohár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w3</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w4</LM>
   </w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w5</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w6</LM>
   </w.rf>
   <form>Č</form>
   <lemma>český</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w8</LM>
   </w.rf>
   <form>Budějovice</form>
   <lemma>Budějovice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w9</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w10</LM>
   </w.rf>
   <form>Olymp</form>
   <lemma>Olymp_;G_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w11</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w12</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w14</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w15</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w16</LM>
   </w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w18</LM>
   </w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w20</LM>
   </w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w21</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p21s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p21s1w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p22s1">
  <m id="m-lnd92254-094-p22s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w1</LM>
   </w.rf>
   <form>Čtvrtfinále</form>
   <lemma>čtvrtfinále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w2</LM>
   </w.rf>
   <form>žen</form>
   <lemma>žena</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w4</LM>
   </w.rf>
   <form>NH</form>
   <lemma>NH-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w5</LM>
   </w.rf>
   <form>Ostrava</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w7</LM>
   </w.rf>
   <form>Olomouc</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w8</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w10</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w11</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w12</LM>
   </w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w14</LM>
   </w.rf>
   <form>-8</form>
   <lemma>-8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w16</LM>
   </w.rf>
   <form>-0</form>
   <lemma>-0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w18</LM>
   </w.rf>
   <form>-12</form>
   <lemma>-12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w19</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p22s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s1w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p22s2">
  <m id="m-lnd92254-094-p22s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s2w1</LM>
   </w.rf>
   <form>Vítězky</form>
   <lemma>vítězka_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s2w2</LM>
   </w.rf>
   <form>postupují</form>
   <lemma>postupovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-lnd92254-094-p22s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s2w3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92254-094-p22s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s2w4</LM>
   </w.rf>
   <form>semifinále</form>
   <lemma>semifinále</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p22s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p22s2w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p23s1">
  <m id="m-lnd92254-094-p23s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p23s1w1</LM>
   </w.rf>
   <form>Vodní</form>
   <lemma>vodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92254-094-p23s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p23s1w2</LM>
   </w.rf>
   <form>pólo</form>
   <lemma>pólo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92254-094-p24s1">
  <m id="m-lnd92254-094-p24s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w1</LM>
   </w.rf>
   <form>Turnaj</form>
   <lemma>turnaj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w2</LM>
   </w.rf>
   <form>Košice</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w3</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w4</LM>
   </w.rf>
   <form>92</form>
   <lemma>92</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w5</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w6</LM>
   </w.rf>
   <form>UK</form>
   <lemma>UK-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w7</LM>
   </w.rf>
   <form>Bratislava</form>
   <lemma>Bratislava_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w8</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w9</LM>
   </w.rf>
   <form>Dinamo</form>
   <lemma>Dinamo_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w10</LM>
   </w.rf>
   <form>Ľvov</form>
   <lemma>Ľvov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w11</LM>
   </w.rf>
   <form>8</form>
   <lemma>8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w12</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w13</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w15</LM>
   </w.rf>
   <form>Ferona</form>
   <lemma>Ferona_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w16</LM>
   </w.rf>
   <form>Košice</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w17</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w18</LM>
   </w.rf>
   <form>Vízmü</form>
   <lemma>Vízmü_;m</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w19</LM>
   </w.rf>
   <form>Szentes</form>
   <lemma>Szentes_;G</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w20</LM>
   </w.rf>
   <form>13</form>
   <lemma>13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w21</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w22</LM>
   </w.rf>
   <form>10</form>
   <lemma>10</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92254-094-p24s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92254-094-p24s1w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
