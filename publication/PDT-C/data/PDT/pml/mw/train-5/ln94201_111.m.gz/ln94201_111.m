<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94201_111.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94201-111-p1s1">
  <m id="m-ln94201-111-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w2</LM>
   </w.rf>
   <form>nevyřčená</form>
   <lemma>vyřčený</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-ln94201-111-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w3</LM>
   </w.rf>
   <form>věta</form>
   <lemma>věta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w4</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p1s1w6</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p2s1">
  <m id="m-ln94201-111-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w2</LM>
   </w.rf>
   <form>svém</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w3</LM>
   </w.rf>
   <form>talentu</form>
   <lemma>talent-1</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94201-111-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w5</LM>
   </w.rf>
   <form>nedělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w6</LM>
   </w.rf>
   <form>iluze</form>
   <lemma>iluze</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w8</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w9</LM>
   </w.rf>
   <form>rocker</form>
   <lemma>rocker</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w10</LM>
   </w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w11</LM>
   </w.rf>
   <form>Sahara</form>
   <lemma>sahara</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w12</LM>
   </w.rf>
   <form>Hedl</form>
   <lemma>Hedl_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w13</LM>
   </w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w14</LM>
   </w.rf>
   <form>Seidl</form>
   <lemma>Seidl_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w15</LM>
   </w.rf>
   <form>Kdosi</form>
   <lemma>kdosi</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w16</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w17</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P6--2-------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w18</LM>
   </w.rf>
   <form>prohlásil</form>
   <lemma>prohlásit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p2s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p2s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w21</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p2s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w22</LM>
   </w.rf>
   <form>lordem</form>
   <lemma>lord</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w23</LM>
   </w.rf>
   <form>Byronem</form>
   <lemma>Byron_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w24</LM>
   </w.rf>
   <form>českého</form>
   <lemma>český</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w25</LM>
   </w.rf>
   <form>rocku</form>
   <lemma>rock-1</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s1w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p2s2">
  <m id="m-ln94201-111-p2s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s2w1</LM>
   </w.rf>
   <form>Souhlasíte</form>
   <lemma>souhlasit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p2s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s2w2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p2s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s2w3</LM>
   </w.rf>
   <form>tímto</form>
   <lemma>tento</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p2s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s2w4</LM>
   </w.rf>
   <form>přirovnáním</form>
   <lemma>přirovnání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p2s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p2s2w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p3s1">
  <m id="m-ln94201-111-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w1</LM>
   </w.rf>
   <form>Předně</form>
   <lemma>předně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w4</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w5</LM>
   </w.rf>
   <form>polichocen</form>
   <lemma>polichotit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-ln94201-111-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p3s2">
  <m id="m-ln94201-111-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w1</LM>
   </w.rf>
   <form>Domnívám</form>
   <lemma>domnívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w3</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w6</LM>
   </w.rf>
   <form>určitá</form>
   <lemma>určitý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w7</LM>
   </w.rf>
   <form>podoba</form>
   <lemma>podoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w8</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w9</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w10</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w12</LM>
   </w.rf>
   <form>konkrétních</form>
   <lemma>konkrétní</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w13</LM>
   </w.rf>
   <form>verších</form>
   <lemma>verš</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w15</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w16</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w18</LM>
   </w.rf>
   <form>romantickém</form>
   <lemma>romantický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w19</LM>
   </w.rf>
   <form>přístupu</form>
   <lemma>přístup</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w20</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w21</LM>
   </w.rf>
   <form>psaní</form>
   <lemma>psaní_^(*3át)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w22</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s2w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p3s3">
  <m id="m-ln94201-111-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w1</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w2</LM>
   </w.rf>
   <form>okruh</form>
   <lemma>okruh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w3</LM>
   </w.rf>
   <form>anglických</form>
   <lemma>anglický</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w4</LM>
   </w.rf>
   <form>romantických</form>
   <lemma>romantický</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w5</LM>
   </w.rf>
   <form>básníků</form>
   <lemma>básník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w6</LM>
   </w.rf>
   <form>Byronovy</form>
   <lemma>Byronův_;Y_^(*2)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m-ln94201-111-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w7</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w10</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w11</LM>
   </w.rf>
   <form>blízký</form>
   <lemma>blízký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w13</LM>
   </w.rf>
   <form>zejména</form>
   <lemma>zejména-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w14</LM>
   </w.rf>
   <form>Percy</form>
   <lemma>Percy_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w15</LM>
   </w.rf>
   <form>Shelley</form>
   <lemma>Shelley_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s3w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p3s4">
  <m id="m-ln94201-111-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w1</LM>
   </w.rf>
   <form>Nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ln94201-111-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w3</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w4</LM>
   </w.rf>
   <form>fascinuje</form>
   <lemma>fascinovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m-ln94201-111-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w5</LM>
   </w.rf>
   <form>William</form>
   <lemma>William_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w6</LM>
   </w.rf>
   <form>Blake</form>
   <lemma>Blake_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p3s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w12</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w13</LM>
   </w.rf>
   <form>epocha</form>
   <lemma>epocha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s4w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p3s5">
  <m id="m-ln94201-111-p3s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w1</LM>
   </w.rf>
   <form>Domnívám</form>
   <lemma>domnívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w5</LM>
   </w.rf>
   <form>psal</form>
   <lemma>psát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p3s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w6</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w7</LM>
   </w.rf>
   <form>autenticky</form>
   <lemma>autenticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w8</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w9</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w12</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP6----------</tag>
  </m>
  <m id="m-ln94201-111-p3s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w13</LM>
   </w.rf>
   <form>obrazech</form>
   <lemma>obraz</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w14</LM>
   </w.rf>
   <form>ilustroval</form>
   <lemma>ilustrovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m-ln94201-111-p3s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w15</LM>
   </w.rf>
   <form>středověk</form>
   <lemma>středověk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w16</LM>
   </w.rf>
   <form>Hieronymus</form>
   <lemma>Hieronymus_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w17</LM>
   </w.rf>
   <form>Bosch</form>
   <lemma>Bosch_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p3s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p3s5w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p4s1">
  <m id="m-ln94201-111-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m-ln94201-111-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-ln94201-111-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w3</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w4</LM>
   </w.rf>
   <form>romantismu</form>
   <lemma>romantismus_,s_^(^DD**romantizmus)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w5</LM>
   </w.rf>
   <form>fascinuje</form>
   <lemma>fascinovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m-ln94201-111-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p4s1w6</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p5s1">
  <m id="m-ln94201-111-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w1</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w5</LM>
   </w.rf>
   <form>líbily</form>
   <lemma>líbit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w6</LM>
   </w.rf>
   <form>anglické</form>
   <lemma>anglický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w7</LM>
   </w.rf>
   <form>parky</form>
   <lemma>park</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w9</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w10</LM>
   </w.rf>
   <form>umělé</form>
   <lemma>umělý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w11</LM>
   </w.rf>
   <form>zříceniny</form>
   <lemma>zřícenina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w13</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w14</LM>
   </w.rf>
   <form>transponovaný</form>
   <lemma>transponovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w15</LM>
   </w.rf>
   <form>středověk</form>
   <lemma>středověk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p5s2">
  <m id="m-ln94201-111-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w1</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w2</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w3</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w4</LM>
   </w.rf>
   <form>gotické</form>
   <lemma>gotický</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w5</LM>
   </w.rf>
   <form>romány</form>
   <lemma>román</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w7</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w9</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w10</LM>
   </w.rf>
   <form>psát</form>
   <lemma>psát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w11</LM>
   </w.rf>
   <form>texty</form>
   <lemma>text</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w13</LM>
   </w.rf>
   <form>rytířích</form>
   <lemma>rytíř</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w16</LM>
   </w.rf>
   <form>hradech</form>
   <lemma>hrad</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s2w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p5s3">
  <m id="m-ln94201-111-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w1</LM>
   </w.rf>
   <form>Líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w4</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w5</LM>
   </w.rf>
   <form>mystická</form>
   <lemma>mystický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w6</LM>
   </w.rf>
   <form>symbolika</form>
   <lemma>symbolika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w8</LM>
   </w.rf>
   <form>tajuplná</form>
   <lemma>tajuplný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w9</LM>
   </w.rf>
   <form>atmosféra</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w11</LM>
   </w.rf>
   <form>neprvoplánové</form>
   <lemma>prvoplánový</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w12</LM>
   </w.rf>
   <form>sdělení</form>
   <lemma>sdělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p5s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p5s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p5s3w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p6s1">
  <m id="m-ln94201-111-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w1</LM>
   </w.rf>
   <form>Spojuje</form>
   <lemma>spojovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-ln94201-111-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w4</LM>
   </w.rf>
   <form>romantiky</form>
   <lemma>romantik</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w5</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w6</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m-ln94201-111-p6s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w7</LM>
   </w.rf>
   <form>snaha</form>
   <lemma>snaha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p6s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w8</LM>
   </w.rf>
   <form>vyjadřovat</form>
   <lemma>vyjadřovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p6s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p6s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w10</LM>
   </w.rf>
   <form>metaforou</form>
   <lemma>metafora</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p6s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p6s1w11</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p7s1">
  <m id="m-ln94201-111-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w1</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w5</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w6</LM>
   </w.rf>
   <form>nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w7</LM>
   </w.rf>
   <form>říci</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p7s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w10</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m-ln94201-111-p7s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w11</LM>
   </w.rf>
   <form>prvoplánovitost</form>
   <lemma>prvoplánovitost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w12</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w13</LM>
   </w.rf>
   <form>zatracoval</form>
   <lemma>zatracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w16</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w18</LM>
   </w.rf>
   <form>funkční</form>
   <lemma>funkční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p7s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s1w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p7s2">
  <m id="m-ln94201-111-p7s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w1</LM>
   </w.rf>
   <form>Domnívám</form>
   <lemma>domnívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w5</LM>
   </w.rf>
   <form>posluchač</form>
   <lemma>posluchač</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w6</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w8</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w9</LM>
   </w.rf>
   <form>stát</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w10</LM>
   </w.rf>
   <form>partnerem</form>
   <lemma>partner</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w11</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w12</LM>
   </w.rf>
   <form>textu</form>
   <lemma>text</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w14</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w15</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w16</LM>
   </w.rf>
   <form>jím</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3-------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w17</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w18</LM>
   </w.rf>
   <form>inspirován</form>
   <lemma>inspirovat</lemma>
   <tag>VsYS----X-APB--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w19</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w20</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w21</LM>
   </w.rf>
   <form>představě</form>
   <lemma>představa</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w23</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w24</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w25</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w26</LM>
   </w.rf>
   <form>nemusí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w27</LM>
   </w.rf>
   <form>korespondovat</form>
   <lemma>korespondovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p7s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w28</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p7s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w29</LM>
   </w.rf>
   <form>mou</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p7s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w30</LM>
   </w.rf>
   <form>původní</form>
   <lemma>původní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w31</LM>
   </w.rf>
   <form>vizí</form>
   <lemma>vize</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s2w32</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p7s3">
  <m id="m-ln94201-111-p7s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w1</LM>
   </w.rf>
   <form>Důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p7s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w5</LM>
   </w.rf>
   <form>posluchače</form>
   <lemma>posluchač</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w6</LM>
   </w.rf>
   <form>osloví</form>
   <lemma>oslovit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p7s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w8</LM>
   </w.rf>
   <form>povzbudí</form>
   <lemma>povzbudit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p7s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s3w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p7s4">
  <m id="m-ln94201-111-p7s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w1</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w2</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w4</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w5</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w8</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSIP1-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w9</LM>
   </w.rf>
   <form>texty</form>
   <lemma>text</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w11</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w12</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w14</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w15</LM>
   </w.rf>
   <form>čem</form>
   <lemma>co-1</lemma>
   <tag>PQ--6----------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w17</LM>
   </w.rf>
   <form>posluchač</form>
   <lemma>posluchač</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p7s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w18</LM>
   </w.rf>
   <form>myslí</form>
   <lemma>myslit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p7s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w21</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p7s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p7s4w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p8s1">
  <m id="m-ln94201-111-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P6--2-------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w4</LM>
   </w.rf>
   <form>známo</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w7</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p8s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w8</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w9</LM>
   </w.rf>
   <form>klasickou</form>
   <lemma>klasický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w10</LM>
   </w.rf>
   <form>ruskou</form>
   <lemma>ruský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w11</LM>
   </w.rf>
   <form>literaturu</form>
   <lemma>literatura</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w13</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w15</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w16</LM>
   </w.rf>
   <form>vyznačuje</form>
   <lemma>vyznačovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p8s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w17</LM>
   </w.rf>
   <form>romantikou</form>
   <lemma>romantika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w18</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w19</LM>
   </w.rf>
   <form>odlišnou</form>
   <lemma>odlišný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p8s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p8s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p8s1w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p9s1">
  <m id="m-ln94201-111-p9s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w1</LM>
   </w.rf>
   <form>Ruská</form>
   <lemma>ruský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w2</LM>
   </w.rf>
   <form>romantika</form>
   <lemma>romantika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w5</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w6</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w7</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w8</LM>
   </w.rf>
   <form>anglosaská</form>
   <lemma>anglosaský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w10</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-ln94201-111-p9s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w12</LM>
   </w.rf>
   <form>dané</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w13</LM>
   </w.rf>
   <form>odlišnou</form>
   <lemma>odlišný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w14</LM>
   </w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w15</LM>
   </w.rf>
   <form>mentalitou</form>
   <lemma>mentalita</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w16</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w17</LM>
   </w.rf>
   <form>zkušenostmi</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s1w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p9s2">
  <m id="m-ln94201-111-p9s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w2</LM>
   </w.rf>
   <form>přesto</form>
   <lemma>přesto-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w4</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w5</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w6</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w9</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w10</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p9s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w11</LM>
   </w.rf>
   <form>názoru</form>
   <lemma>názor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w12</LM>
   </w.rf>
   <form>klasická</form>
   <lemma>klasický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w13</LM>
   </w.rf>
   <form>ruská</form>
   <lemma>ruský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w14</LM>
   </w.rf>
   <form>literatura</form>
   <lemma>literatura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w15</LM>
   </w.rf>
   <form>nesmírně</form>
   <lemma>smírně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w16</LM>
   </w.rf>
   <form>romantická</form>
   <lemma>romantický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s2w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p9s3">
  <m id="m-ln94201-111-p9s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w1</LM>
   </w.rf>
   <form>Seznámil</form>
   <lemma>seznámit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p9s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w5</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w6</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w7</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS3---------1</tag>
  </m>
  <m id="m-ln94201-111-p9s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w8</LM>
   </w.rf>
   <form>matce</form>
   <lemma>matka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w10</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w12</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w13</LM>
   </w.rf>
   <form>kulturní</form>
   <lemma>kulturní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w14</LM>
   </w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s3w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p9s4">
  <m id="m-ln94201-111-p9s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w4</LM>
   </w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w6</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w10</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w11</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w12</LM>
   </w.rf>
   <form>narazil</form>
   <lemma>narazit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w14</LM>
   </w.rf>
   <form>učitelku</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w16</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w18</LM>
   </w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w19</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w20</LM>
   </w.rf>
   <form>svému</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS3----------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w21</LM>
   </w.rf>
   <form>stáří</form>
   <lemma>stáří</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w22</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w23</LM>
   </w.rf>
   <form>statečná</form>
   <lemma>statečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s4w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w25</LM>
   </w.rf>
   <form>ignorovala</form>
   <lemma>ignorovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s4w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w26</LM>
   </w.rf>
   <form>předepsané</form>
   <lemma>předepsaný_^(*2t)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w27</LM>
   </w.rf>
   <form>školní</form>
   <lemma>školní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w28</LM>
   </w.rf>
   <form>osnovy</form>
   <lemma>osnova</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s4w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s4w29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p9s5">
  <m id="m-ln94201-111-p9s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w1</LM>
   </w.rf>
   <form>Díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w2</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w6</LM>
   </w.rf>
   <form>ruštinou</form>
   <lemma>ruština</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w7</LM>
   </w.rf>
   <form>neseznamoval</form>
   <lemma>seznamovat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p9s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w8</LM>
   </w.rf>
   <form>prostřednictvím</form>
   <lemma>prostřednictví</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w9</LM>
   </w.rf>
   <form>traktoristů</form>
   <lemma>traktorista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w11</LM>
   </w.rf>
   <form>kombajnérů</form>
   <lemma>kombajnér</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w14</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w15</LM>
   </w.rf>
   <form>Puškina</form>
   <lemma>Puškin_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w17</LM>
   </w.rf>
   <form>Lermontova</form>
   <lemma>Lermontov_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p9s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w19</LM>
   </w.rf>
   <form>Dostojevského</form>
   <lemma>Dostojevský_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p9s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p9s5w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p10s1">
  <m id="m-ln94201-111-p10s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p10s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m-ln94201-111-p10s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w3</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p10s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w4</LM>
   </w.rf>
   <form>blízcí</form>
   <lemma>blízký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p10s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p10s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w6</LM>
   </w.rf>
   <form>někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m-ln94201-111-p10s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w7</LM>
   </w.rf>
   <form>čeští</form>
   <lemma>český</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p10s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w8</LM>
   </w.rf>
   <form>básníci</form>
   <lemma>básník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p10s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p10s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w10</LM>
   </w.rf>
   <form>spisovatelé</form>
   <lemma>spisovatel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p10s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p10s1w11</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p11s1">
  <m id="m-ln94201-111-p11s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p11s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w2</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w3</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w4</LM>
   </w.rf>
   <form>Nezvala</form>
   <lemma>Nezval_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w6</LM>
   </w.rf>
   <form>Seiferta</form>
   <lemma>Seifert_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w8</LM>
   </w.rf>
   <form>Wolkra</form>
   <lemma>Wolker_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w10</LM>
   </w.rf>
   <form>Máchu</form>
   <lemma>Mácha_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w12</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w13</LM>
   </w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w14</LM>
   </w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p11s2">
  <m id="m-ln94201-111-p11s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w1</LM>
   </w.rf>
   <form>Díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p11s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w2</LM>
   </w.rf>
   <form>Nezvalovým</form>
   <lemma>Nezvalův_;Y_^(*2)</lemma>
   <tag>AUIP3M---------</tag>
  </m>
  <m id="m-ln94201-111-p11s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w4</LM>
   </w.rf>
   <form>Seifertovým</form>
   <lemma>Seifertův_;Y_^(*2)</lemma>
   <tag>AUIP3M---------</tag>
  </m>
  <m id="m-ln94201-111-p11s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w5</LM>
   </w.rf>
   <form>překladům</form>
   <lemma>překlad</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p11s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w7</LM>
   </w.rf>
   <form>poznal</form>
   <lemma>poznat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p11s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w8</LM>
   </w.rf>
   <form>francouzské</form>
   <lemma>francouzský</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w9</LM>
   </w.rf>
   <form>prokleté</form>
   <lemma>prokletý_^(*3ít)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w10</LM>
   </w.rf>
   <form>básníky</form>
   <lemma>básník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p11s3">
  <m id="m-ln94201-111-p11s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w1</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m-ln94201-111-p11s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p11s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w4</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m-ln94201-111-p11s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p11s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w6</LM>
   </w.rf>
   <form>krásnou</form>
   <lemma>krásný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w7</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p11s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w9</LM>
   </w.rf>
   <form>jazykem</form>
   <lemma>jazyk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s3w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p11s4">
  <m id="m-ln94201-111-p11s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w1</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w2</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFP1-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p11s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w3</LM>
   </w.rf>
   <form>znalosti</form>
   <lemma>znalost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w4</LM>
   </w.rf>
   <form>angličtiny</form>
   <lemma>angličtina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w5</LM>
   </w.rf>
   <form>dovolí</form>
   <lemma>dovolit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p11s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w7</LM>
   </w.rf>
   <form>mohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-ln94201-111-p11s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w8</LM>
   </w.rf>
   <form>porovnat</form>
   <lemma>porovnat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p11s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w9</LM>
   </w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w10</LM>
   </w.rf>
   <form>originál</form>
   <lemma>originál</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w11</LM>
   </w.rf>
   <form>Poeova</form>
   <lemma>Poeův_;Y_^(*2)</lemma>
   <tag>AUMS4M---------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w12</LM>
   </w.rf>
   <form>Havrana</form>
   <lemma>havran</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w14</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w16</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w17</LM>
   </w.rf>
   <form>jej</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3------2</tag>
  </m>
  <m id="m-ln94201-111-p11s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w18</LM>
   </w.rf>
   <form>přebásnil</form>
   <lemma>přebásnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p11s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w19</LM>
   </w.rf>
   <form>Nezval</form>
   <lemma>Nezval_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w21</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p11s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w22</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w24</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w25</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m-ln94201-111-p11s4w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w26</LM>
   </w.rf>
   <form>překlad</form>
   <lemma>překlad</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w27</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p11s4w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w28</LM>
   </w.rf>
   <form>jazykově</form>
   <lemma>jazykově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p11s4w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w29</LM>
   </w.rf>
   <form>bohatší</form>
   <lemma>bohatý</lemma>
   <tag>AAIS1----2A---1</tag>
  </m>
  <m id="m-ln94201-111-p11s4w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p11s4w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p12s1">
  <m id="m-ln94201-111-p12s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w2</LM>
   </w.rf>
   <form>vaší</form>
   <lemma>váš</lemma>
   <tag>PSFS6-P2-------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w3</LM>
   </w.rf>
   <form>desce</form>
   <lemma>deska</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w6</LM>
   </w.rf>
   <form>většině</form>
   <lemma>většina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w7</LM>
   </w.rf>
   <form>písniček</form>
   <lemma>písnička</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w8</LM>
   </w.rf>
   <form>objevuje</form>
   <lemma>objevovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p12s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w9</LM>
   </w.rf>
   <form>smrt</form>
   <lemma>smrt</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w12</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w14</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m-ln94201-111-p12s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w15</LM>
   </w.rf>
   <form>říci</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p12s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w18</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p12s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w19</LM>
   </w.rf>
   <form>album</form>
   <lemma>album</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w20</LM>
   </w.rf>
   <form>působilo</form>
   <lemma>působit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p12s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w21</LM>
   </w.rf>
   <form>depresivně</form>
   <lemma>depresivně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p12s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s1w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p12s2">
  <m id="m-ln94201-111-p12s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s2w1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m-ln94201-111-p12s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s2w2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-ln94201-111-p12s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s2w3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p12s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s2w4</LM>
   </w.rf>
   <form>láká</form>
   <lemma>lákat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p12s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p12s2w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p13s1">
  <m id="m-ln94201-111-p13s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w1</LM>
   </w.rf>
   <form>Smrt</form>
   <lemma>smrt</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w2</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p13s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p13s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w6</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p13s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p13s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w8</LM>
   </w.rf>
   <form>nejoblíbenějších</form>
   <lemma>oblíbený_^(*3it)</lemma>
   <tag>AAIP2----3A----</tag>
  </m>
  <m id="m-ln94201-111-p13s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w9</LM>
   </w.rf>
   <form>romantických</form>
   <lemma>romantický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w10</LM>
   </w.rf>
   <form>atributů</form>
   <lemma>atribut</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s1w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p13s2">
  <m id="m-ln94201-111-p13s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w1</LM>
   </w.rf>
   <form>Původní</form>
   <lemma>původní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w2</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w3</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p13s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w4</LM>
   </w.rf>
   <form>desky</form>
   <lemma>deska</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w5</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w6</LM>
   </w.rf>
   <form>zněl</form>
   <lemma>znít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p13s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w7</LM>
   </w.rf>
   <form>Písně</form>
   <lemma>píseň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w9</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w11</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w12</LM>
   </w.rf>
   <form>smrt</form>
   <lemma>smrt</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w14</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP6-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w15</LM>
   </w.rf>
   <form>textech</form>
   <lemma>text</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w16</LM>
   </w.rf>
   <form>funguje</form>
   <lemma>fungovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p13s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w18</LM>
   </w.rf>
   <form>memento</form>
   <lemma>memento</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w19</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w20</LM>
   </w.rf>
   <form>neschopností</form>
   <lemma>schopnost_^(*3ý)</lemma>
   <tag>NNFS7-----N----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w21</LM>
   </w.rf>
   <form>či</form>
   <lemma>či-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w22</LM>
   </w.rf>
   <form>neochotou</form>
   <lemma>neochota</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w23</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w24</LM>
   </w.rf>
   <form>vzájemně</form>
   <lemma>vzájemně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w25</LM>
   </w.rf>
   <form>komunikovat</form>
   <lemma>komunikovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m-ln94201-111-p13s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s2w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p13s3">
  <m id="m-ln94201-111-p13s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w1</LM>
   </w.rf>
   <form>Každá</form>
   <lemma>každý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w2</LM>
   </w.rf>
   <form>vyřčená</form>
   <lemma>vyřčený</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w6</LM>
   </w.rf>
   <form>nevyřčená</form>
   <lemma>vyřčený</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-ln94201-111-p13s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w7</LM>
   </w.rf>
   <form>věta</form>
   <lemma>věta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p13s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w8</LM>
   </w.rf>
   <form>totiž</form>
   <lemma>totiž-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p13s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w9</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p13s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w10</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p13s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w11</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m-ln94201-111-p13s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w12</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p13s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p13s3w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p14s1">
  <m id="m-ln94201-111-p14s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p14s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p14s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p14s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w4</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p14s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w5</LM>
   </w.rf>
   <form>rozhodl</form>
   <lemma>rozhodnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m-ln94201-111-p14s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p14s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w7</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p14s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w8</LM>
   </w.rf>
   <form>Tajnej</form>
   <lemma>tajný-1</lemma>
   <tag>AAMS1----1A---6</tag>
  </m>
  <m id="m-ln94201-111-p14s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w9</LM>
   </w.rf>
   <form>svatej</form>
   <lemma>svatý-1</lemma>
   <tag>AAMS1----1A---6</tag>
  </m>
  <m id="m-ln94201-111-p14s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p14s1w10</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p15s1">
  <m id="m-ln94201-111-p15s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p15s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w3</LM>
   </w.rf>
   <form>titul</form>
   <lemma>titul</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w4</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS2----------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w5</LM>
   </w.rf>
   <form>písničky</form>
   <lemma>písnička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w7</LM>
   </w.rf>
   <form>Martinovi</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w9</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w11</LM>
   </w.rf>
   <form>líbil</form>
   <lemma>líbit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p15s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w12</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w13</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p15s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w14</LM>
   </w.rf>
   <form>desku</form>
   <lemma>deska</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p15s2">
  <m id="m-ln94201-111-p15s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w5</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w6</LM>
   </w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p15s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w10</LM>
   </w.rf>
   <form>prožil</form>
   <lemma>prožít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p15s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w11</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w13</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w16</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S6--1-------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w17</LM>
   </w.rf>
   <form>někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w18</LM>
   </w.rf>
   <form>chytráci</form>
   <lemma>chytrák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w19</LM>
   </w.rf>
   <form>šuškali</form>
   <lemma>šuškat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p15s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w21</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w23</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w24</LM>
   </w.rf>
   <form>hudbě</form>
   <lemma>hudba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w25</LM>
   </w.rf>
   <form>pohybuji</form>
   <lemma>pohybovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-ln94201-111-p15s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w26</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w27</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p15s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w28</LM>
   </w.rf>
   <form>tajuplným</form>
   <lemma>tajuplný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w29</LM>
   </w.rf>
   <form>státním</form>
   <lemma>státní</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w30</LM>
   </w.rf>
   <form>posláním</form>
   <lemma>poslání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s2w31</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p15s3">
  <m id="m-ln94201-111-p15s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w1</LM>
   </w.rf>
   <form>Než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w3</LM>
   </w.rf>
   <form>ohánět</form>
   <lemma>ohánět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p15s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w4</LM>
   </w.rf>
   <form>lustračním</form>
   <lemma>lustrační</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w5</LM>
   </w.rf>
   <form>papírem</form>
   <lemma>papír</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w7</LM>
   </w.rf>
   <form>přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p15s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w9</LM>
   </w.rf>
   <form>vhodnější</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w10</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p15s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w11</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w12</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w13</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w15</LM>
   </w.rf>
   <form>obal</form>
   <lemma>obal</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w16</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-ln94201-111-p15s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w17</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-ln94201-111-p15s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w18</LM>
   </w.rf>
   <form>desky</form>
   <lemma>deska</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p15s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p15s3w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p16s1">
  <m id="m-ln94201-111-p16s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p16s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w2</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m-ln94201-111-p16s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w3</LM>
   </w.rf>
   <form>míry</form>
   <lemma>míra_^(měřítko,poměr)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w4</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p16s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p16s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w6</LM>
   </w.rf>
   <form>autobiografické</form>
   <lemma>autobiografický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p16s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w7</LM>
   </w.rf>
   <form>album</form>
   <lemma>album</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s1w8</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p16s2">
  <m id="m-ln94201-111-p16s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p16s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w2</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w3</LM>
   </w.rf>
   <form>onen</form>
   <lemma>onen</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w4</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w5</LM>
   </w.rf>
   <form>posel</form>
   <lemma>posel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w7</LM>
   </w.rf>
   <form>temnejch</form>
   <lemma>temný</lemma>
   <tag>AAFP2----1A---6</tag>
  </m>
  <m id="m-ln94201-111-p16s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w8</LM>
   </w.rf>
   <form>cest</form>
   <lemma>cesta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w10</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4MS4----------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w11</LM>
   </w.rf>
   <form>hvězdy</form>
   <lemma>hvězda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w12</LM>
   </w.rf>
   <form>nechtěj</form>
   <lemma>chtít</lemma>
   <tag>Vi-S---2--N-I--</tag>
  </m>
  <m id="m-ln94201-111-p16s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w13</LM>
   </w.rf>
   <form>vést</form>
   <lemma>vést</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p16s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w15</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w16</LM>
   </w.rf>
   <form>zpíváte</form>
   <lemma>zpívat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p16s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p16s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w18</LM>
   </w.rf>
   <form>písni</form>
   <lemma>píseň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w19</LM>
   </w.rf>
   <form>Annemarie</form>
   <lemma>Annemarie_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p16s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p16s2w20</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p17s1">
  <m id="m-ln94201-111-p17s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p17s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p17s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p17s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w4</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFP1-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p17s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w5</LM>
   </w.rf>
   <form>písně</form>
   <lemma>píseň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p17s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w6</LM>
   </w.rf>
   <form>vycházejí</form>
   <lemma>vycházet</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p17s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p17s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w8</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m-ln94201-111-p17s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w9</LM>
   </w.rf>
   <form>autentického</form>
   <lemma>autentický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p17s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w10</LM>
   </w.rf>
   <form>prožitku</form>
   <lemma>prožitek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p17s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s1w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p17s2">
  <m id="m-ln94201-111-p17s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p17s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w2</LM>
   </w.rf>
   <form>žádném</form>
   <lemma>žádný</lemma>
   <tag>PWZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p17s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w3</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p17s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w4</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p17s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w5</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p17s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w6</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m-ln94201-111-p17s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w7</LM>
   </w.rf>
   <form>ilustrací</form>
   <lemma>ilustrace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p17s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p17s2w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p18s1">
  <m id="m-ln94201-111-p18s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w3</LM>
   </w.rf>
   <form>odlišuje</form>
   <lemma>odlišovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p18s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w4</LM>
   </w.rf>
   <form>úhel</form>
   <lemma>úhel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p18s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w5</LM>
   </w.rf>
   <form>vašeho</form>
   <lemma>váš</lemma>
   <tag>PSZS2-P2-------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w6</LM>
   </w.rf>
   <form>pohledu</form>
   <lemma>pohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p18s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w9</LM>
   </w.rf>
   <form>píšete</form>
   <lemma>psát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p18s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w10</LM>
   </w.rf>
   <form>texty</form>
   <lemma>text</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p18s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w11</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w12</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w15</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p18s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w16</LM>
   </w.rf>
   <form>Báru</form>
   <lemma>Bára_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p18s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w17</LM>
   </w.rf>
   <form>Basikovou</form>
   <lemma>Basiková_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p18s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p18s1w18</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p19s1">
  <m id="m-ln94201-111-p19s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w1</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w4</LM>
   </w.rf>
   <form>Bárou</form>
   <lemma>Bára_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w5</LM>
   </w.rf>
   <form>známe</form>
   <lemma>znát</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w6</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w7</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w9</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w10</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w12</LM>
   </w.rf>
   <form>nečiní</form>
   <lemma>činit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w13</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w14</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w16</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w17</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w18</LM>
   </w.rf>
   <form>vžít</form>
   <lemma>vžít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w20</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w21</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w22</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w23</LM>
   </w.rf>
   <form>kůže</form>
   <lemma>kůže</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w25</LM>
   </w.rf>
   <form>představit</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w26</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w28</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w29</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w30</LM>
   </w.rf>
   <form>reagovala</form>
   <lemma>reagovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w31</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w32</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w33</LM>
   </w.rf>
   <form>situace</form>
   <lemma>situace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w34</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w35</LM>
   </w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w36</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w37</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p19s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w38</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m-ln94201-111-p19s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w39</LM>
   </w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w40</LM>
   </w.rf>
   <form>zaujímala</form>
   <lemma>zaujímat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w41</LM>
   </w.rf>
   <form>názor</form>
   <lemma>názor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s1w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s1w42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p19s2">
  <m id="m-ln94201-111-p19s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w1</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w2</LM>
   </w.rf>
   <form>posluchače</form>
   <lemma>posluchač</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w4</LM>
   </w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w6</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-ln94201-111-p19s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w8</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p19s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w9</LM>
   </w.rf>
   <form>písní</form>
   <lemma>píseň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w10</LM>
   </w.rf>
   <form>podepsaný</form>
   <lemma>podepsaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p19s3">
  <m id="m-ln94201-111-p19s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w1</LM>
   </w.rf>
   <form>Interpret</form>
   <lemma>interpret-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w2</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w3</LM>
   </w.rf>
   <form>především</form>
   <lemma>především-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w4</LM>
   </w.rf>
   <form>působit</form>
   <lemma>působit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p19s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w5</LM>
   </w.rf>
   <form>věrohodně</form>
   <lemma>věrohodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s3w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p19s4">
  <m id="m-ln94201-111-p19s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w1</LM>
   </w.rf>
   <form>Texty</form>
   <lemma>text</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w3</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w4</LM>
   </w.rf>
   <form>píšu</form>
   <lemma>psát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w6</LM>
   </w.rf>
   <form>Báru</form>
   <lemma>Bára_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w8</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w9</LM>
   </w.rf>
   <form>nijak</form>
   <lemma>nijak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w10</LM>
   </w.rf>
   <form>feministické</form>
   <lemma>feministický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w12</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w15</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP6--3-------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w16</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w17</LM>
   </w.rf>
   <form>nestylizuji</form>
   <lemma>stylizovat</lemma>
   <tag>VB-S---1P-NAI-1</tag>
  </m>
  <m id="m-ln94201-111-p19s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w19</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m-ln94201-111-p19s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w20</LM>
   </w.rf>
   <form>ženských</form>
   <lemma>ženský</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w21</LM>
   </w.rf>
   <form>postojů</form>
   <lemma>postoj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s4w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p19s5">
  <m id="m-ln94201-111-p19s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w2</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w4</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w5</LM>
   </w.rf>
   <form>podobné</form>
   <lemma>podobný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p19s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w6</LM>
   </w.rf>
   <form>textům</form>
   <lemma>text</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w8</LM>
   </w.rf>
   <form>písničkám</form>
   <lemma>písnička</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p19s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w10</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w11</LM>
   </w.rf>
   <form>zpívám</form>
   <lemma>zpívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p19s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w12</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-ln94201-111-p19s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p19s5w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p20s1">
  <m id="m-ln94201-111-p20s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w1</LM>
   </w.rf>
   <form>Vaše</form>
   <lemma>váš</lemma>
   <tag>PSIP1-P2-------</tag>
  </m>
  <m id="m-ln94201-111-p20s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w2</LM>
   </w.rf>
   <form>verše</form>
   <lemma>verš</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p20s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p20s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w4</LM>
   </w.rf>
   <form>výrazně</form>
   <lemma>výrazně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p20s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w5</LM>
   </w.rf>
   <form>poznamenány</form>
   <lemma>poznamenat</lemma>
   <tag>VsTP----X-APP--</tag>
  </m>
  <m id="m-ln94201-111-p20s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w6</LM>
   </w.rf>
   <form>životem</form>
   <lemma>život</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p20s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p20s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w8</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p20s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p20s2">
  <m id="m-ln94201-111-p20s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-ln94201-111-p20s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-ln94201-111-p20s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p20s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m-ln94201-111-p20s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w5</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p20s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w6</LM>
   </w.rf>
   <form>přitahuje</form>
   <lemma>přitahovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p20s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p20s2w7</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p21s1">
  <m id="m-ln94201-111-p21s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w2</LM>
   </w.rf>
   <form>Prahou</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w3</LM>
   </w.rf>
   <form>fascinován</form>
   <lemma>fascinovat</lemma>
   <tag>VsYS----X-APB--</tag>
  </m>
  <m id="m-ln94201-111-p21s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w9</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w10</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p21s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w12</LM>
   </w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w13</LM>
   </w.rf>
   <form>česká</form>
   <lemma>český</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w14</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w15</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w16</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w17</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w18</LM>
   </w.rf>
   <form>připadají</form>
   <lemma>připadat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w19</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w20</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w21</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w22</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s1w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p21s2">
  <m id="m-ln94201-111-p21s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w1</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w3</LM>
   </w.rf>
   <form>neskutečným</form>
   <lemma>skutečný</lemma>
   <tag>AAIS7----1N----</tag>
  </m>
  <m id="m-ln94201-111-p21s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w4</LM>
   </w.rf>
   <form>zdrojem</form>
   <lemma>zdroj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w5</LM>
   </w.rf>
   <form>inspirace</form>
   <lemma>inspirace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s2w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p21s3">
  <m id="m-ln94201-111-p21s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w1</LM>
   </w.rf>
   <form>Nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w3</LM>
   </w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w5</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w6</LM>
   </w.rf>
   <form>používat</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p21s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w7</LM>
   </w.rf>
   <form>termín</form>
   <lemma>termín</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w8</LM>
   </w.rf>
   <form>magická</form>
   <lemma>magický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w13</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w14</LM>
   </w.rf>
   <form>zprofanovaný</form>
   <lemma>zprofanovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w15</LM>
   </w.rf>
   <form>pojem</form>
   <lemma>pojem_^(termín,_označení,...)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w17</LM>
   </w.rf>
   <form>avšak</form>
   <lemma>avšak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w18</LM>
   </w.rf>
   <form>nepochybně</form>
   <lemma>nepochybně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w19</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w20</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-ln94201-111-p21s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w21</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w22</LM>
   </w.rf>
   <form>atmosféru</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w24</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w25</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w26</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w27</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p21s3w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w28</LM>
   </w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s3w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w29</LM>
   </w.rf>
   <form>liší</form>
   <lemma>lišit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s3w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s3w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p21s4">
  <m id="m-ln94201-111-p21s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w1</LM>
   </w.rf>
   <form>Navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w5</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w6</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w7</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w8</LM>
   </w.rf>
   <form>chodec</form>
   <lemma>chodec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w10</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w11</LM>
   </w.rf>
   <form>většinu</form>
   <lemma>většina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w12</LM>
   </w.rf>
   <form>volného</form>
   <lemma>volný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w13</LM>
   </w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w14</LM>
   </w.rf>
   <form>tráví</form>
   <lemma>trávit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w15</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w18</LM>
   </w.rf>
   <form>chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w19</LM>
   </w.rf>
   <form>pěšky</form>
   <lemma>pěšky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s4w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p21s5">
  <m id="m-ln94201-111-p21s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w1</LM>
   </w.rf>
   <form>Ulice</form>
   <lemma>ulice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p21s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w3</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSNS1-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p21s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w4</LM>
   </w.rf>
   <form>nejoblíbenější</form>
   <lemma>oblíbený_^(*3it)</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m-ln94201-111-p21s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w5</LM>
   </w.rf>
   <form>pracoviště</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w7</LM>
   </w.rf>
   <form>většina</form>
   <lemma>většina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w8</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w9</LM>
   </w.rf>
   <form>textů</form>
   <lemma>text</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p21s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w10</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w11</LM>
   </w.rf>
   <form>vznikla</form>
   <lemma>vzniknout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m-ln94201-111-p21s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w12</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w14</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m-ln94201-111-p21s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p21s5w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p22s1">
  <m id="m-ln94201-111-p22s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w3</LM>
   </w.rf>
   <form>slučuje</form>
   <lemma>slučovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p22s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w5</LM>
   </w.rf>
   <form>romantická</form>
   <lemma>romantický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w6</LM>
   </w.rf>
   <form>povaha</form>
   <lemma>povaha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w8</LM>
   </w.rf>
   <form>někdejším</form>
   <lemma>někdejší</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w9</LM>
   </w.rf>
   <form>působením</form>
   <lemma>působení_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w11</LM>
   </w.rf>
   <form>undergroundové</form>
   <lemma>undergroundový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w12</LM>
   </w.rf>
   <form>skupině</form>
   <lemma>skupina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w13</LM>
   </w.rf>
   <form>DG</form>
   <lemma>DG-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-ln94201-111-p22s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w14</LM>
   </w.rf>
   <form>307</form>
   <lemma>307</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94201-111-p22s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p22s1w15</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p23s1">
  <m id="m-ln94201-111-p23s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w4</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w5</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w6</LM>
   </w.rf>
   <form>působilo</form>
   <lemma>působit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w7</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w8</LM>
   </w.rf>
   <form>romanticky</form>
   <lemma>romanticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p23s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w12</LM>
   </w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p23s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p23s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w14</LM>
   </w.rf>
   <form>určitým</form>
   <lemma>určitý</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p23s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w15</LM>
   </w.rf>
   <form>dobrodružstvím</form>
   <lemma>dobrodružství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p23s2">
  <m id="m-ln94201-111-p23s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w4</LM>
   </w.rf>
   <form>koncertů</form>
   <lemma>koncert</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w5</LM>
   </w.rf>
   <form>neodjížděli</form>
   <lemma>odjíždět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w6</LM>
   </w.rf>
   <form>limuzínami</form>
   <lemma>limuzína</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w7</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w8</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w11</LM>
   </w.rf>
   <form>prchali</form>
   <lemma>prchat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w13</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w14</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w16</LM>
   </w.rf>
   <form>kličkovali</form>
   <lemma>kličkovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p23s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w17</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w18</LM>
   </w.rf>
   <form>kordony</form>
   <lemma>kordon_,s_^(^DD**kordón)</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w19</LM>
   </w.rf>
   <form>policistů</form>
   <lemma>policista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p23s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p23s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p23s2w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p24s1">
  <m id="m-ln94201-111-p24s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w1</LM>
   </w.rf>
   <form>Život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w2</LM>
   </w.rf>
   <form>rockových</form>
   <lemma>rockový</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p24s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w3</LM>
   </w.rf>
   <form>muzikantů</form>
   <lemma>muzikant</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w5</LM>
   </w.rf>
   <form>obzvláště</form>
   <lemma>obzvláště-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w6</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w8</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w9</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p24s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w11</LM>
   </w.rf>
   <form>undergroundu</form>
   <lemma>underground</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w13</LM>
   </w.rf>
   <form>bývá</form>
   <lemma>bývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p24s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w14</LM>
   </w.rf>
   <form>spojen</form>
   <lemma>spojit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-ln94201-111-p24s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p24s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w16</LM>
   </w.rf>
   <form>hospodou</form>
   <lemma>hospoda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s1w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p24s2">
  <m id="m-ln94201-111-p24s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w1</LM>
   </w.rf>
   <form>Zpěvačka</form>
   <lemma>zpěvačka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w2</LM>
   </w.rf>
   <form>Monika</form>
   <lemma>Monika_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w3</LM>
   </w.rf>
   <form>Načeva</form>
   <lemma>Načeva_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p24s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w5</LM>
   </w.rf>
   <form>nedávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w6</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p24s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w9</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m-ln94201-111-p24s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p24s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w11</LM>
   </w.rf>
   <form>minulosti</form>
   <lemma>minulost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w12</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w13</LM>
   </w.rf>
   <form>pronásledoval</form>
   <lemma>pronásledovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p24s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w14</LM>
   </w.rf>
   <form>démon</form>
   <lemma>démon</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w15</LM>
   </w.rf>
   <form>alkoholu</form>
   <lemma>alkohol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s2w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p24s3">
  <m id="m-ln94201-111-p24s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p24s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p24s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p24s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94201-111-p24s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w5</LM>
   </w.rf>
   <form>vašem</form>
   <lemma>váš</lemma>
   <tag>PSZS6-P2-------</tag>
  </m>
  <m id="m-ln94201-111-p24s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w6</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p24s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p24s3w7</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p25s1">
  <m id="m-ln94201-111-p25s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w1</LM>
   </w.rf>
   <form>Démon</form>
   <lemma>démon</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w2</LM>
   </w.rf>
   <form>alkoholu</form>
   <lemma>alkohol</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w4</LM>
   </w.rf>
   <form>pronásledovat</form>
   <lemma>pronásledovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p25s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w5</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p25s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w9</LM>
   </w.rf>
   <form>neustále</form>
   <lemma>neustále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p25s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w10</LM>
   </w.rf>
   <form>držíme</form>
   <lemma>držet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p25s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w12</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w14</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w15</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w16</LM>
   </w.rf>
   <form>nevzniká</form>
   <lemma>vznikat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p25s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w17</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w18</LM>
   </w.rf>
   <form>žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m-ln94201-111-p25s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w19</LM>
   </w.rf>
   <form>honička</form>
   <lemma>honička_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s1w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p25s2">
  <m id="m-ln94201-111-p25s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w1</LM>
   </w.rf>
   <form>Nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p25s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w2</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w3</LM>
   </w.rf>
   <form>sebemenší</form>
   <lemma>sebemenší</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p25s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w4</LM>
   </w.rf>
   <form>obavu</form>
   <lemma>obava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w7</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p25s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w9</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w10</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p25s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p25s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w12</LM>
   </w.rf>
   <form>lopatky</form>
   <lemma>lopatka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p25s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p25s2w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p26s1">
  <m id="m-ln94201-111-p26s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w1</LM>
   </w.rf>
   <form>Díváte</form>
   <lemma>dívat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p26s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p26s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p26s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>alkohol</form>
   <lemma>alkohol</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p26s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p26s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p26s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w7</LM>
   </w.rf>
   <form>zdroj</form>
   <lemma>zdroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p26s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w8</LM>
   </w.rf>
   <form>inspirace</form>
   <lemma>inspirace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p26s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s1w9</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p26s2">
  <m id="m-ln94201-111-p26s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w1</LM>
   </w.rf>
   <form>Vzpomeňme</form>
   <lemma>vzpomenout</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m-ln94201-111-p26s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w2</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p26s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w3</LM>
   </w.rf>
   <form>zmiňované</form>
   <lemma>zmiňovaný_^(*2t)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p26s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w4</LM>
   </w.rf>
   <form>francouzské</form>
   <lemma>francouzský</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p26s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w5</LM>
   </w.rf>
   <form>prokleté</form>
   <lemma>prokletý_^(*3ít)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p26s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w6</LM>
   </w.rf>
   <form>básníky</form>
   <lemma>básník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p26s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p26s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p26s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p26s2w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p27s1">
  <m id="m-ln94201-111-p27s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p27s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w2</LM>
   </w.rf>
   <form>stoprocentně</form>
   <lemma>stoprocentně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w3</LM>
   </w.rf>
   <form>přesvědčen</form>
   <lemma>přesvědčit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-ln94201-111-p27s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w6</LM>
   </w.rf>
   <form>Rimbaud</form>
   <lemma>Rimbaud_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w7</LM>
   </w.rf>
   <form>či</form>
   <lemma>či-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w8</LM>
   </w.rf>
   <form>Verlaine</form>
   <lemma>Verlaine_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w9</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p27s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w10</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FP4---------1</tag>
  </m>
  <m id="m-ln94201-111-p27s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w11</LM>
   </w.rf>
   <form>básně</form>
   <lemma>báseň</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w12</LM>
   </w.rf>
   <form>napsali</form>
   <lemma>napsat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p27s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w13</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w14</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p27s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w15</LM>
   </w.rf>
   <form>střízlivé</form>
   <lemma>střízlivý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w16</LM>
   </w.rf>
   <form>mysli</form>
   <lemma>mysl</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s1w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p27s2">
  <m id="m-ln94201-111-p27s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w1</LM>
   </w.rf>
   <form>Alkohol</form>
   <lemma>alkohol</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w2</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p27s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w4</LM>
   </w.rf>
   <form>určitém</form>
   <lemma>určitý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w5</LM>
   </w.rf>
   <form>smyslu</form>
   <lemma>smysl</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w6</LM>
   </w.rf>
   <form>uvolnit</form>
   <lemma>uvolnit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p27s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w7</LM>
   </w.rf>
   <form>stavidla</form>
   <lemma>stavidlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w8</LM>
   </w.rf>
   <form>obrazotvornosti</form>
   <lemma>obrazotvornost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w10</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w12</LM>
   </w.rf>
   <form>konkrétním</form>
   <lemma>konkrétní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w13</LM>
   </w.rf>
   <form>okamžiku</form>
   <lemma>okamžik</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w14</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w15</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w16</LM>
   </w.rf>
   <form>napomoci</form>
   <lemma>napomoci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m-ln94201-111-p27s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s2w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p27s3">
  <m id="m-ln94201-111-p27s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w1</LM>
   </w.rf>
   <form>Avšak</form>
   <lemma>avšak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w2</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w4</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w5</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w7</LM>
   </w.rf>
   <form>obdarován</form>
   <lemma>obdarovat</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w8</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w9</LM>
   </w.rf>
   <form>Pánaboha</form>
   <lemma>pánbůh</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w11</LM>
   </w.rf>
   <form>Rimbaud</form>
   <lemma>Rimbaud_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w13</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w14</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w16</LM>
   </w.rf>
   <form>skvělého</form>
   <lemma>skvělý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p27s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w17</LM>
   </w.rf>
   <form>nenapsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w19</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w20</LM>
   </w.rf>
   <form>kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w23</LM>
   </w.rf>
   <form>opil</form>
   <lemma>opít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p27s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w24</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w25</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w26</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w27</LM>
   </w.rf>
   <form>němoty</form>
   <lemma>němota</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p27s3w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p27s3w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p27s3w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p28s1">
  <m id="m-ln94201-111-p28s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w1</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p28s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w6</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w7</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p28s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w8</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w9</LM>
   </w.rf>
   <form>dar</form>
   <lemma>dar</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p28s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p28s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w11</LM>
   </w.rf>
   <form>nebes</form>
   <lemma>nebesa</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p28s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p28s1w12</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p29s1">
  <m id="m-ln94201-111-p29s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w1</LM>
   </w.rf>
   <form>Spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p29s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w3</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p29s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w6</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p29s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w7</LM>
   </w.rf>
   <form>obrovské</form>
   <lemma>obrovský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p29s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w8</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p29s2">
  <m id="m-ln94201-111-p29s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w1</LM>
   </w.rf>
   <form>Nedělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p29s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94201-111-p29s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w3</LM>
   </w.rf>
   <form>iluze</form>
   <lemma>iluze</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p29s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w5</LM>
   </w.rf>
   <form>svém</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p29s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w6</LM>
   </w.rf>
   <form>talentu</form>
   <lemma>talent-1</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94201-111-p29s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s2w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p29s3">
  <m id="m-ln94201-111-p29s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p29s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w5</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w6</LM>
   </w.rf>
   <form>tendence</form>
   <lemma>tendence</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w7</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w8</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w10</LM>
   </w.rf>
   <form>vlastních</form>
   <lemma>vlastní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w11</LM>
   </w.rf>
   <form>očích</form>
   <lemma>oko-2</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w12</LM>
   </w.rf>
   <form>povyšovat</form>
   <lemma>povyšovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p29s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w14</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w15</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFP1-S1------1</tag>
  </m>
  <m id="m-ln94201-111-p29s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w16</LM>
   </w.rf>
   <form>úvahy</form>
   <lemma>úvaha</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w17</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w18</LM>
   </w.rf>
   <form>skončí</form>
   <lemma>skončit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p29s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w19</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w20</LM>
   </w.rf>
   <form>samou</form>
   <lemma>samý</lemma>
   <tag>PLFS7----------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w21</LM>
   </w.rf>
   <form>větou</form>
   <lemma>věta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w22</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p29s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w23</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p29s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w24</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w25</LM>
   </w.rf>
   <form>kliku</form>
   <lemma>klika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p29s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p29s3w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p30s1">
  <m id="m-ln94201-111-p30s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w1</LM>
   </w.rf>
   <form>Neláká</form>
   <lemma>lákat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p30s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w3</LM>
   </w.rf>
   <form>psaní</form>
   <lemma>psaní_^(*3át)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p30s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w5</LM>
   </w.rf>
   <form>něčeho</form>
   <lemma>něco</lemma>
   <tag>PK--2----------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w6</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p30s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w8</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w9</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p30s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w10</LM>
   </w.rf>
   <form>písniček</form>
   <lemma>písnička</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p30s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p30s1w11</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p31s1">
  <m id="m-ln94201-111-p31s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w1</LM>
   </w.rf>
   <form>Vyhovuje</form>
   <lemma>vyhovovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w3</LM>
   </w.rf>
   <form>psát</form>
   <lemma>psát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p31s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w4</LM>
   </w.rf>
   <form>krátké</form>
   <lemma>krátký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p31s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w5</LM>
   </w.rf>
   <form>útvary</form>
   <lemma>útvar</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w7</LM>
   </w.rf>
   <form>mohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-ln94201-111-p31s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w10</LM>
   </w.rf>
   <form>věnovat</form>
   <lemma>věnovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p31s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w11</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w12</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w14</LM>
   </w.rf>
   <form>konce</form>
   <lemma>konec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w15</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w16</LM>
   </w.rf>
   <form>jednomu</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS3----------</tag>
  </m>
  <m id="m-ln94201-111-p31s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w17</LM>
   </w.rf>
   <form>tématu</form>
   <lemma>téma</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s1w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p31s2">
  <m id="m-ln94201-111-p31s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w1</LM>
   </w.rf>
   <form>Obávám</form>
   <lemma>obávat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w3</LM>
   </w.rf>
   <form>totiž</form>
   <lemma>totiž-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w6</LM>
   </w.rf>
   <form>kdybych</form>
   <lemma>kdyby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m-ln94201-111-p31s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w9</LM>
   </w.rf>
   <form>pokoušel</form>
   <lemma>pokoušet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w11</LM>
   </w.rf>
   <form>rozsáhlejší</form>
   <lemma>rozsáhlý</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m-ln94201-111-p31s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w12</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w14</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w15</LM>
   </w.rf>
   <form>smysl</form>
   <lemma>smysl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w16</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p31s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w18</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w19</LM>
   </w.rf>
   <form>rozptýlil</form>
   <lemma>rozptýlit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p31s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s2w20</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p31s3">
  <m id="m-ln94201-111-p31s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w1</LM>
   </w.rf>
   <form>Nedávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-ln94201-111-p31s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w3</LM>
   </w.rf>
   <form>napsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w4</LM>
   </w.rf>
   <form>knížku</form>
   <lemma>knížka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w5</LM>
   </w.rf>
   <form>básniček</form>
   <lemma>básnička</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m-ln94201-111-p31s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w8</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w9</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w10</LM>
   </w.rf>
   <form>vyjít</form>
   <lemma>vyjít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w11</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p31s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w12</LM>
   </w.rf>
   <form>vánoci</form>
   <lemma>vánoce_,i_^(^DS**Vánoce)</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m-ln94201-111-p31s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w14</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w16</LM>
   </w.rf>
   <form>jmenovat</form>
   <lemma>jmenovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m-ln94201-111-p31s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w17</LM>
   </w.rf>
   <form>Královské</form>
   <lemma>královský</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p31s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w18</LM>
   </w.rf>
   <form>Vinohrady</form>
   <lemma>Vinohrady_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s3w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p31s4">
  <m id="m-ln94201-111-p31s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w1</LM>
   </w.rf>
   <form>Jedná</form>
   <lemma>jednat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w5</LM>
   </w.rf>
   <form>záznam</form>
   <lemma>záznam</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w6</LM>
   </w.rf>
   <form>vzpomínek</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w8</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w9</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w10</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w13</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w15</LM>
   </w.rf>
   <form>přelom</form>
   <lemma>přelom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w16</LM>
   </w.rf>
   <form>padesátých</form>
   <lemma>padesátý</lemma>
   <tag>CrNP2----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w18</LM>
   </w.rf>
   <form>šedesátých</form>
   <lemma>šedesátý</lemma>
   <tag>CrNP2----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w19</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w22</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s4w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w24</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w25</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w26</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w27</LM>
   </w.rf>
   <form>komunikace</form>
   <lemma>komunikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w28</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w29</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w30</LM>
   </w.rf>
   <form>samým</form>
   <lemma>samý</lemma>
   <tag>PLZS7----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w32</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w33</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w34</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p31s4w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w35</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m-ln94201-111-p31s4w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w36</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p31s4w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p31s4w37</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p32s1">
  <m id="m-ln94201-111-p32s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w1</LM>
   </w.rf>
   <form>Tajnej</form>
   <lemma>tajný-1</lemma>
   <tag>AAMS1----1A---6</tag>
  </m>
  <m id="m-ln94201-111-p32s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w2</LM>
   </w.rf>
   <form>svatej</form>
   <lemma>svatý-1</lemma>
   <tag>AAMS1----1A---6</tag>
  </m>
  <m id="m-ln94201-111-p32s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w3</LM>
   </w.rf>
   <form>zachycuje</form>
   <lemma>zachycovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p32s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w4</LM>
   </w.rf>
   <form>písničky</form>
   <lemma>písnička</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p32s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w6</LM>
   </w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w7</LM>
   </w.rf>
   <form>patnácti</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m-ln94201-111-p32s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s1w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p32s2">
  <m id="m-ln94201-111-p32s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w1</LM>
   </w.rf>
   <form>Jaký</form>
   <lemma>jaký</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p32s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w3</LM>
   </w.rf>
   <form>vývoj</form>
   <lemma>vývoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w4</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w5</LM>
   </w.rf>
   <form>Saharou</form>
   <lemma>sahara</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w7</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w8</LM>
   </w.rf>
   <form>Duševního</form>
   <lemma>duševní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w9</LM>
   </w.rf>
   <form>hrobu</form>
   <lemma>hrob</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w11</LM>
   </w.rf>
   <form>Saharou</form>
   <lemma>sahara</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p32s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w13</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94201-111-p32s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w14</LM>
   </w.rf>
   <form>1994</form>
   <lemma>1994</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94201-111-p32s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p32s2w15</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p33s1">
  <m id="m-ln94201-111-p33s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p33s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p33s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p33s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w4</LM>
   </w.rf>
   <form>rozhněvaný</form>
   <lemma>rozhněvaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w5</LM>
   </w.rf>
   <form>mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w6</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p33s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w8</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p33s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p33s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94201-111-p33s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w11</LM>
   </w.rf>
   <form>přibývajícím</form>
   <lemma>přibývající_^(*4t)</lemma>
   <tag>AGIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w12</LM>
   </w.rf>
   <form>věkem</form>
   <lemma>věk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w13</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w14</LM>
   </w.rf>
   <form>lyričtější</form>
   <lemma>lyrický</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m-ln94201-111-p33s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s1w15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p33s2">
  <m id="m-ln94201-111-p33s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w1</LM>
   </w.rf>
   <form>Malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w2</LM>
   </w.rf>
   <form>romantik</form>
   <lemma>romantik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p33s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p33s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w4</LM>
   </w.rf>
   <form>postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w5</LM>
   </w.rf>
   <form>stal</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94201-111-p33s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w6</LM>
   </w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p33s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w7</LM>
   </w.rf>
   <form>romantikem</form>
   <lemma>romantik</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p33s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p33s2w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p34s1">
  <m id="m-ln94201-111-p34s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p34s1w1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p34s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p34s1w2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p34s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p34s1w3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p34s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p34s1w4</LM>
   </w.rf>
   <form>cyničtější</form>
   <lemma>cynický</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m-ln94201-111-p34s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p34s1w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p35s1">
  <m id="m-ln94201-111-p35s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w1</LM>
   </w.rf>
   <form>Cyničtější</form>
   <lemma>cynický</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m-ln94201-111-p35s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w2</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w7</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w8</LM>
   </w.rf>
   <form>popíral</form>
   <lemma>popírat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w9</LM>
   </w.rf>
   <form>romantickou</form>
   <lemma>romantický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w10</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w11</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-ln94201-111-p35s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w12</LM>
   </w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s1w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p35s2">
  <m id="m-ln94201-111-p35s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w3</LM>
   </w.rf>
   <form>dojem</form>
   <lemma>dojem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w6</LM>
   </w.rf>
   <form>umění</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w8</LM>
   </w.rf>
   <form>vážná</form>
   <lemma>vážný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w9</LM>
   </w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p35s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w12</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w13</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p35s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w14</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p35s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w15</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94201-111-p35s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w16</LM>
   </w.rf>
   <form>každou</form>
   <lemma>každý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w17</LM>
   </w.rf>
   <form>cenu</form>
   <lemma>cena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w18</LM>
   </w.rf>
   <form>mladým</form>
   <lemma>mladý</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w19</LM>
   </w.rf>
   <form>rozhněvaným</form>
   <lemma>rozhněvaný_^(*2t)</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w20</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m-ln94201-111-p35s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p35s2w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p36s1">
  <m id="m-ln94201-111-p36s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w3</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w4</LM>
   </w.rf>
   <form>díváte</form>
   <lemma>dívat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p36s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w5</LM>
   </w.rf>
   <form>zpětně</form>
   <lemma>zpětně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p36s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w7</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p36s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w9</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m-ln94201-111-p36s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w10</LM>
   </w.rf>
   <form>bližší</form>
   <lemma>blízký</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m-ln94201-111-p36s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s1w11</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p36s2">
  <m id="m-ln94201-111-p36s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p36s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w2</LM>
   </w.rf>
   <form>šestileté</form>
   <lemma>šestiletý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p36s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w3</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p36s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p36s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w5</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p36s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w6</LM>
   </w.rf>
   <form>onen</form>
   <lemma>onen</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-ln94201-111-p36s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w7</LM>
   </w.rf>
   <form>mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p36s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w8</LM>
   </w.rf>
   <form>rozhněvaný</form>
   <lemma>rozhněvaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p36s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w9</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p36s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p36s2w10</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p37s1">
  <m id="m-ln94201-111-p37s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w1</LM>
   </w.rf>
   <form>Mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w2</LM>
   </w.rf>
   <form>rozhněvaný</form>
   <lemma>rozhněvaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w3</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w4</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w5</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w6</LM>
   </w.rf>
   <form>skutečný</form>
   <lemma>skutečný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w8</LM>
   </w.rf>
   <form>zatímco</form>
   <lemma>zatímco</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w9</LM>
   </w.rf>
   <form>romantické</form>
   <lemma>romantický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w10</LM>
   </w.rf>
   <form>šestileté</form>
   <lemma>šestiletý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w11</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w13</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w14</LM>
   </w.rf>
   <form>posílali</form>
   <lemma>posílat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w15</LM>
   </w.rf>
   <form>cvičit</form>
   <lemma>cvičit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94201-111-p37s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w17</LM>
   </w.rf>
   <form>Sokola</form>
   <lemma>Sokol-2_;m_^(organizace)</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94201-111-p37s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w19</LM>
   </w.rf>
   <form>ono</form>
   <lemma>onen</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w21</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-2_^(záměnou_za)</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w22</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w23</LM>
   </w.rf>
   <form>brouzdalo</form>
   <lemma>brouzdat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w24</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w25</LM>
   </w.rf>
   <form>Riegrových</form>
   <lemma>Riegrův_;Y_^(*2)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w26</LM>
   </w.rf>
   <form>sadech</form>
   <lemma>sad</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w28</LM>
   </w.rf>
   <form>skutečné</form>
   <lemma>skutečný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w29</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s1w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94201-111-p37s2">
  <m id="m-ln94201-111-p37s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w6</LM>
   </w.rf>
   <form>hlouběji</form>
   <lemma>hluboce</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w7</LM>
   </w.rf>
   <form>přemýšlím</form>
   <lemma>přemýšlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w10</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w11</LM>
   </w.rf>
   <form>jednoznačně</form>
   <lemma>jednoznačně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w12</LM>
   </w.rf>
   <form>blíž</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w14</LM>
   </w.rf>
   <form>dítěti</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w16</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w17</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w19</LM>
   </w.rf>
   <form>koloběžce</form>
   <lemma>koloběžka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w20</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w21</LM>
   </w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w23</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94201-111-p37s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w24</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w25</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94201-111-p37s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w26</LM>
   </w.rf>
   <form>šišlalo</form>
   <lemma>šišlat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94201-111-p37s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94201-111-p37s2w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
