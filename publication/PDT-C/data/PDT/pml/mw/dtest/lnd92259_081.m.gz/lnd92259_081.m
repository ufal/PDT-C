<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92259_081.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92259-081-p1s1">
  <m id="m-lnd92259-081-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w1</LM>
   </w.rf>
   <form>53065.3605</form>
   <lemma>53065.3605</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w3</LM>
   </w.rf>
   <form>145.46</form>
   <lemma>145.46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w5</LM>
   </w.rf>
   <form>5.52</form>
   <lemma>5.52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p1s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p2s1">
  <m id="m-lnd92259-081-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w1</LM>
   </w.rf>
   <form>2097021.18019</form>
   <lemma>2097021.18019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w3</LM>
   </w.rf>
   <form>8321.27</form>
   <lemma>8321.27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w5</LM>
   </w.rf>
   <form>21.55</form>
   <lemma>21.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p3s1">
  <m id="m-lnd92259-081-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w1</LM>
   </w.rf>
   <form>25542.5802</form>
   <lemma>25542.5802</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w3</LM>
   </w.rf>
   <form>522.64</form>
   <lemma>522.64</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w5</LM>
   </w.rf>
   <form>2.67</form>
   <lemma>2.67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p3s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p4s1">
  <m id="m-lnd92259-081-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w1</LM>
   </w.rf>
   <form>1797118.15117</form>
   <lemma>1797118.15117</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w3</LM>
   </w.rf>
   <form>6018.52</form>
   <lemma>6018.52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w5</LM>
   </w.rf>
   <form>18.75</form>
   <lemma>18.75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p5s1">
  <m id="m-lnd92259-081-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w1</LM>
   </w.rf>
   <form>2014820.35019</form>
   <lemma>2014820.35019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w3</LM>
   </w.rf>
   <form>7420.80</form>
   <lemma>7420.80</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w5</LM>
   </w.rf>
   <form>21.04</form>
   <lemma>21.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p6s1">
  <m id="m-lnd92259-081-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w1</LM>
   </w.rf>
   <form>2826828.55227</form>
   <lemma>2826828.55227</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w3</LM>
   </w.rf>
   <form>7129.11</form>
   <lemma>7129.11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w5</LM>
   </w.rf>
   <form>28.77</form>
   <lemma>28.77</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92259-081-p7s1">
  <m id="m-lnd92259-081-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w1</LM>
   </w.rf>
   <form>4351243.95041</form>
   <lemma>4351243.95041</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w3</LM>
   </w.rf>
   <form>9045.04</form>
   <lemma>9045.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92259-081-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w5</LM>
   </w.rf>
   <form>45.43</form>
   <lemma>45.43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92259-081-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92259-081-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
