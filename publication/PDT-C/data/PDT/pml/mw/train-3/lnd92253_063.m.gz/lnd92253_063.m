<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92253_063.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92253-063-p1s1">
  <m id="m-lnd92253-063-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p1s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5345395185.50</form>
   <lemma>5345395185.50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p1s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p1s1w3</LM>
   </w.rf>
   <form>5.61</form>
   <lemma>5.61</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p1s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p2s1">
  <m id="m-lnd92253-063-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w1</LM>
   </w.rf>
   <form>209721.1919</form>
   <lemma>209721.1919</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w3</LM>
   </w.rf>
   <form>8321.27</form>
   <lemma>8321.27</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w5</LM>
   </w.rf>
   <form>21.41</form>
   <lemma>21.41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p3s1">
  <m id="m-lnd92253-063-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p3s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2592622562.68</form>
   <lemma>2592622562.68</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p3s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p3s1w3</LM>
   </w.rf>
   <form>2.71</form>
   <lemma>2.71</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p3s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p4s1">
  <m id="m-lnd92253-063-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w1</LM>
   </w.rf>
   <form>181018.2817</form>
   <lemma>181018.2817</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w3</LM>
   </w.rf>
   <form>7318.65</form>
   <lemma>7318.65</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w5</LM>
   </w.rf>
   <form>19.04</form>
   <lemma>19.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p5s1">
  <m id="m-lnd92253-063-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w1</LM>
   </w.rf>
   <form>203020.5019</form>
   <lemma>203020.5019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w3</LM>
   </w.rf>
   <form>8920.95</form>
   <lemma>8920.95</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w5</LM>
   </w.rf>
   <form>21.44</form>
   <lemma>21.44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p6s1">
  <m id="m-lnd92253-063-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w1</LM>
   </w.rf>
   <form>279228.2027</form>
   <lemma>279228.2027</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w3</LM>
   </w.rf>
   <form>3627.76</form>
   <lemma>3627.76</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w5</LM>
   </w.rf>
   <form>28.25</form>
   <lemma>28.25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-063-p7s1">
  <m id="m-lnd92253-063-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w1</LM>
   </w.rf>
   <form>442444.6842</form>
   <lemma>442444.6842</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w3</LM>
   </w.rf>
   <form>6345.77</form>
   <lemma>6345.77</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-063-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w5</LM>
   </w.rf>
   <form>46.13</form>
   <lemma>46.13</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-063-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-063-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
