<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94207_103.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94207-103-p1s1">
  <m id="m-ln94207-103-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p1s1w1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p1s1w2</LM>
   </w.rf>
   <form>projektovat</form>
   <lemma>projektovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94207-103-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p1s1w3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p1s1w4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p1s1w5</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p2s1">
  <m id="m-ln94207-103-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s1w1</LM>
   </w.rf>
   <form>Rostislav</form>
   <lemma>Rostislav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s1w2</LM>
   </w.rf>
   <form>Švácha</form>
   <lemma>Švácha_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p2s2A">
  <m id="m-ln94207-103-p2s2Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw1</LM>
   </w.rf>
   <form>Autor</form>
   <lemma>autor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw3</LM>
   </w.rf>
   <form>nar</form>
   <lemma>narozený</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw5</LM>
   </w.rf>
   <form>1952</form>
   <lemma>1952</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw8</LM>
   </w.rf>
   <form>historik</form>
   <lemma>historik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw9</LM>
   </w.rf>
   <form>umění</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw11</LM>
   </w.rf>
   <form>působí</form>
   <lemma>působit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw13</LM>
   </w.rf>
   <form>Ústavu</form>
   <lemma>ústav</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw14</LM>
   </w.rf>
   <form>dějin</form>
   <lemma>dějiny</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw15</LM>
   </w.rf>
   <form>umění</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw16</LM>
   </w.rf>
   <form>Akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Aw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Aw17</LM>
   </w.rf>
   <form>věd</form>
   <lemma>věda</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p2s2B">
  <m id="m-ln94207-103-p2s2Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw1</LM>
   </w.rf>
   <form>Přehlídka</form>
   <lemma>přehlídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw2</LM>
   </w.rf>
   <form>mateřských</form>
   <lemma>mateřský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw3</LM>
   </w.rf>
   <form>školek</form>
   <lemma>školka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw4</LM>
   </w.rf>
   <form>postavených</form>
   <lemma>postavený_^(*3it)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw5</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw6</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw7</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw9</LM>
   </w.rf>
   <form>velikém</form>
   <lemma>veliký</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw10</LM>
   </w.rf>
   <form>německém</form>
   <lemma>německý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw11</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw13</LM>
   </w.rf>
   <form>zdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw14</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw15</LM>
   </w.rf>
   <form>téma</form>
   <lemma>téma</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw16</LM>
   </w.rf>
   <form>přitažlivé</form>
   <lemma>přitažlivý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw17</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw18</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw19</LM>
   </w.rf>
   <form>pedagogy</form>
   <lemma>pedagog</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw21</LM>
   </w.rf>
   <form>sociology</form>
   <lemma>sociolog</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw23</LM>
   </w.rf>
   <form>psychology</form>
   <lemma>psycholog</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw24</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw25</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw26</LM>
   </w.rf>
   <form>milovníky</form>
   <lemma>milovník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw27</LM>
   </w.rf>
   <form>architektury</form>
   <lemma>architektura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s2Bw28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s2Bw28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p2s3">
  <m id="m-ln94207-103-p2s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w2</LM>
   </w.rf>
   <form>výstavě</form>
   <lemma>výstava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w3</LM>
   </w.rf>
   <form>Mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w4</LM>
   </w.rf>
   <form>školky</form>
   <lemma>školka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w5</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w6</LM>
   </w.rf>
   <form>Moderní</form>
   <lemma>moderní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w7</LM>
   </w.rf>
   <form>architektura</form>
   <lemma>architektura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w9</LM>
   </w.rf>
   <form>Frankfurtu</form>
   <lemma>Frankfurt_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w10</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w11</LM>
   </w.rf>
   <form>Mohanem</form>
   <lemma>Mohan_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w13</LM>
   </w.rf>
   <form>Národním</form>
   <lemma>národní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w14</LM>
   </w.rf>
   <form>technickém</form>
   <lemma>technický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w15</LM>
   </w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w17</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w18</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w19</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w20</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w21</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p2s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w22</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w23</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m-ln94207-103-p2s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w24</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m-ln94207-103-p2s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w25</LM>
   </w.rf>
   <form>posledně</form>
   <lemma>posledně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w26</LM>
   </w.rf>
   <form>jmenovaní</form>
   <lemma>jmenovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p2s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s3w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p2s4">
  <m id="m-ln94207-103-p2s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w1</LM>
   </w.rf>
   <form>Přitáhnou</form>
   <lemma>přitáhnout</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p2s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m-ln94207-103-p2s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w3</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w4</LM>
   </w.rf>
   <form>díla</form>
   <lemma>dílo_^(umělecké,_vědecké,...)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w5</LM>
   </w.rf>
   <form>Rakušana</form>
   <lemma>Rakušan_;E</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w6</LM>
   </w.rf>
   <form>Friedensreicha</form>
   <lemma>Friedensreich_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w7</LM>
   </w.rf>
   <form>Hundertwassera</form>
   <lemma>Hundertwasser_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w9</LM>
   </w.rf>
   <form>Japonce</form>
   <lemma>Japonec_;E</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w10</LM>
   </w.rf>
   <form>Toya</form>
   <lemma>Toyo_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w11</LM>
   </w.rf>
   <form>Ita</form>
   <lemma>Ito_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p2s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w13</LM>
   </w.rf>
   <form>Angličana</form>
   <lemma>Angličan_;E</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w14</LM>
   </w.rf>
   <form>Petera</form>
   <lemma>Peter_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w15</LM>
   </w.rf>
   <form>Wilsona</form>
   <lemma>Wilson_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p2s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p2s4w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s1">
  <m id="m-ln94207-103-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94207-103-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w2</LM>
   </w.rf>
   <form>hostitelským</form>
   <lemma>hostitelský</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w3</LM>
   </w.rf>
   <form>muzeem</form>
   <lemma>muzeum</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w5</LM>
   </w.rf>
   <form>německým</form>
   <lemma>německý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w6</LM>
   </w.rf>
   <form>Werkbundem</form>
   <lemma>Werkbund_;m</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w7</LM>
   </w.rf>
   <form>výstavu</form>
   <lemma>výstava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w8</LM>
   </w.rf>
   <form>připravila</form>
   <lemma>připravit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w9</LM>
   </w.rf>
   <form>Projektová</form>
   <lemma>projektový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w10</LM>
   </w.rf>
   <form>skupina</form>
   <lemma>skupina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w11</LM>
   </w.rf>
   <form>mateřských</form>
   <lemma>mateřský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w12</LM>
   </w.rf>
   <form>škol</form>
   <lemma>škola</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w13</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w14</LM>
   </w.rf>
   <form>frankfurtském</form>
   <lemma>frankfurtský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w15</LM>
   </w.rf>
   <form>magistrátu</form>
   <lemma>magistrát</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m-ln94207-103-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s1w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s2">
  <m id="m-ln94207-103-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-ln94207-103-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w3</LM>
   </w.rf>
   <form>1985</form>
   <lemma>1985</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w4</LM>
   </w.rf>
   <form>postavil</form>
   <lemma>postavit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w5</LM>
   </w.rf>
   <form>Frankfurt</form>
   <lemma>Frankfurt_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w7</LM>
   </w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w8</LM>
   </w.rf>
   <form>školek</form>
   <lemma>školka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w10</LM>
   </w.rf>
   <form>jejichž</form>
   <lemma>jehož</lemma>
   <tag>P1XXXXP3-------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w11</LM>
   </w.rf>
   <form>projekty</form>
   <lemma>projekt</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w12</LM>
   </w.rf>
   <form>vypracovali</form>
   <lemma>vypracovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w13</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w14</LM>
   </w.rf>
   <form>směrnic</form>
   <lemma>směrnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w15</LM>
   </w.rf>
   <form>uvedené</form>
   <lemma>uvedený_^(*5ést)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w16</LM>
   </w.rf>
   <form>skupiny</form>
   <lemma>skupina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w17</LM>
   </w.rf>
   <form>výborní</form>
   <lemma>výborný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w18</LM>
   </w.rf>
   <form>architekti</form>
   <lemma>architekt</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w19</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w20</LM>
   </w.rf>
   <form>Německa</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w21</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w22</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m-ln94207-103-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w23</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s2w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s3">
  <m id="m-ln94207-103-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w1</LM>
   </w.rf>
   <form>Daný</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w3</LM>
   </w.rf>
   <form>počet</form>
   <lemma>počet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w4</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w5</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w6</LM>
   </w.rf>
   <form>sto</form>
   <lemma>sto-1`100</lemma>
   <tag>CzNS1----------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w7</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w9</LM>
   </w.rf>
   <form>plošná</form>
   <lemma>plošný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w10</LM>
   </w.rf>
   <form>výměra</form>
   <lemma>výměra_^(např._pozemku_[plocha])</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w11</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w12</LM>
   </w.rf>
   <form>650</form>
   <lemma>650</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w13</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w14</LM>
   </w.rf>
   <form>čtverečních</form>
   <lemma>čtvereční</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w15</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s3w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s4">
  <m id="m-ln94207-103-p3s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w1</LM>
   </w.rf>
   <form>Otázka</form>
   <lemma>otázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w2</LM>
   </w.rf>
   <form>formy</form>
   <lemma>forma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w4</LM>
   </w.rf>
   <form>stylu</form>
   <lemma>styl</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w5</LM>
   </w.rf>
   <form>zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w7</LM>
   </w.rf>
   <form>architektech</form>
   <lemma>architekt</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s4w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s5">
  <m id="m-ln94207-103-p3s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w1</LM>
   </w.rf>
   <form>Zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w5</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w6</LM>
   </w.rf>
   <form>přály</form>
   <lemma>přát</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w7</LM>
   </w.rf>
   <form>lákavé</form>
   <lemma>lákavý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w8</LM>
   </w.rf>
   <form>metafory</form>
   <lemma>metafora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w9</LM>
   </w.rf>
   <form>dětského</form>
   <lemma>dětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w10</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w11</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w12</LM>
   </w.rf>
   <form>cirkus</form>
   <lemma>cirkus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w14</LM>
   </w.rf>
   <form>zámek</form>
   <lemma>zámek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w16</LM>
   </w.rf>
   <form>parník</form>
   <lemma>parník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w17</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w19</LM>
   </w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w20</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w21</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w22</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m-ln94207-103-p3s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w23</LM>
   </w.rf>
   <form>nezasloužily</form>
   <lemma>zasloužit</lemma>
   <tag>VpTP----R-NAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w24</LM>
   </w.rf>
   <form>nejkvalitnější</form>
   <lemma>kvalitní</lemma>
   <tag>AAFS4----3A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w25</LM>
   </w.rf>
   <form>soudobou</form>
   <lemma>soudobý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w26</LM>
   </w.rf>
   <form>architekturu</form>
   <lemma>architektura</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w27</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w28</LM>
   </w.rf>
   <form>ohledu</form>
   <lemma>ohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w29</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w30</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w31</LM>
   </w.rf>
   <form>prvoplánovou</form>
   <lemma>prvoplánový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w32</LM>
   </w.rf>
   <form>přitažlivost</form>
   <lemma>přitažlivost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w33</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w34</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w35</LM>
   </w.rf>
   <form>zda</form>
   <lemma>zda</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w36</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w37</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w38</LM>
   </w.rf>
   <form>architektura</form>
   <lemma>architektura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w39</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w40</LM>
   </w.rf>
   <form>školek</form>
   <lemma>školka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w41</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w42</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w43</LM>
   </w.rf>
   <form>vychovávat</form>
   <lemma>vychovávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w44</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w45</LM>
   </w.rf>
   <form>skromnosti</form>
   <lemma>skromnost_^(*3ý)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w46</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w47</LM>
   </w.rf>
   <form>pravdymilovnosti</form>
   <lemma>pravdymilovnost_^(*3ý)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w48</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w49</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w50</LM>
   </w.rf>
   <form>ekologickému</form>
   <lemma>ekologický</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w51</LM>
   </w.rf>
   <form>myšlení</form>
   <lemma>myšlení_^(*5slit)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w52</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w53</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w54</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w55</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w56</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s5w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w57</LM>
   </w.rf>
   <form>nenašla</form>
   <lemma>najít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m-ln94207-103-p3s5w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w58</LM>
   </w.rf>
   <form>jednoznačná</form>
   <lemma>jednoznačný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w59</LM>
   </w.rf>
   <form>odpověď</form>
   <lemma>odpověď</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s5w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s5w60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p3s6">
  <m id="m-ln94207-103-p3s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w2</LM>
   </w.rf>
   <form>doprovodných</form>
   <lemma>doprovodný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w3</LM>
   </w.rf>
   <form>textech</form>
   <lemma>text</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w6</LM>
   </w.rf>
   <form>speciálním</form>
   <lemma>speciální</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w7</LM>
   </w.rf>
   <form>německo</form>
   <lemma>německo</lemma>
   <tag>S2--------A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w8</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w9</LM>
   </w.rf>
   <form>anglickém</form>
   <lemma>anglický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w10</LM>
   </w.rf>
   <form>čísle</form>
   <lemma>číslo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w11</LM>
   </w.rf>
   <form>revue</form>
   <lemma>revue</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w12</LM>
   </w.rf>
   <form>Archigrad</form>
   <lemma>Archigrad_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w13</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w14</LM>
   </w.rf>
   <form>prodává</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p3s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w17</LM>
   </w.rf>
   <form>sto</form>
   <lemma>sto-1`100</lemma>
   <tag>CzNS4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w18</LM>
   </w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w19</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w21</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w22</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w23</LM>
   </w.rf>
   <form>píše</form>
   <lemma>psát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p3s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w24</LM>
   </w.rf>
   <form>leccos</form>
   <lemma>leccos</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m-ln94207-103-p3s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w25</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p3s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p3s6w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s1">
  <m id="m-ln94207-103-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w1</LM>
   </w.rf>
   <form>Osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w2</LM>
   </w.rf>
   <form>projektů</form>
   <lemma>projekt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w5</LM>
   </w.rf>
   <form>výstavě</form>
   <lemma>výstava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w6</LM>
   </w.rf>
   <form>představuje</form>
   <lemma>představovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w7</LM>
   </w.rf>
   <form>axonometrickými</form>
   <lemma>axonometrický</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w8</LM>
   </w.rf>
   <form>kresbami</form>
   <lemma>kresba</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w10</LM>
   </w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w11</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w12</LM>
   </w.rf>
   <form>podrobnější</form>
   <lemma>podrobný</lemma>
   <tag>AAFS7----2A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w13</LM>
   </w.rf>
   <form>dokumentací</form>
   <lemma>dokumentace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w14</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w15</LM>
   </w.rf>
   <form>fotografií</form>
   <lemma>fotografie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w17</LM>
   </w.rf>
   <form>trojrozměrných</form>
   <lemma>trojrozměrný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w18</LM>
   </w.rf>
   <form>modelů</form>
   <lemma>model-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s1w19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s2">
  <m id="m-ln94207-103-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w1</LM>
   </w.rf>
   <form>Zaujme</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w2</LM>
   </w.rf>
   <form>Hundertwasserova</form>
   <lemma>Hundertwasserův_;Y_^(*2)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w3</LM>
   </w.rf>
   <form>ekologická</form>
   <lemma>ekologický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w4</LM>
   </w.rf>
   <form>variace</form>
   <lemma>variace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w6</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w7</LM>
   </w.rf>
   <form>známý</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w8</LM>
   </w.rf>
   <form>vídeňský</form>
   <lemma>vídeňský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w9</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w10</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w11</LM>
   </w.rf>
   <form>terasovitý</form>
   <lemma>terasovitý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w12</LM>
   </w.rf>
   <form>zámek</form>
   <lemma>zámek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w14</LM>
   </w.rf>
   <form>humornými</form>
   <lemma>humorný</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w15</LM>
   </w.rf>
   <form>věžičkami</form>
   <lemma>věžička</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w17</LM>
   </w.rf>
   <form>sloupy</form>
   <lemma>sloup</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w19</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m-ln94207-103-p4s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w20</LM>
   </w.rf>
   <form>střechami</form>
   <lemma>střecha</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w21</LM>
   </w.rf>
   <form>porostlými</form>
   <lemma>porostlý_^(*5ůst)</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w22</LM>
   </w.rf>
   <form>trávníkem</form>
   <lemma>trávník</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s2w23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s3">
  <m id="m-ln94207-103-p4s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w1</LM>
   </w.rf>
   <form>Obloukový</form>
   <lemma>obloukový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w2</LM>
   </w.rf>
   <form>útvar</form>
   <lemma>útvar</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w3</LM>
   </w.rf>
   <form>školky</form>
   <lemma>školka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w4</LM>
   </w.rf>
   <form>napolo</form>
   <lemma>napolo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w5</LM>
   </w.rf>
   <form>zapustil</form>
   <lemma>zapustit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p4s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w7</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w8</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w9</LM>
   </w.rf>
   <form>Toyo</form>
   <lemma>Toyo_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w10</LM>
   </w.rf>
   <form>Ito</form>
   <lemma>Ito_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s3w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s4">
  <m id="m-ln94207-103-p4s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w1</LM>
   </w.rf>
   <form>Klikaté</form>
   <lemma>klikatý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w2</LM>
   </w.rf>
   <form>pásmo</form>
   <lemma>pásmo_^(geograf.;_na_měření;_filmů)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w3</LM>
   </w.rf>
   <form>stanovitých</form>
   <lemma>stanovitý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w4</LM>
   </w.rf>
   <form>přístřešků</form>
   <lemma>přístřešek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-ln94207-103-p4s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w7</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS2--3-------</tag>
  </m>
  <m id="m-ln94207-103-p4s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w8</LM>
   </w.rf>
   <form>točí</form>
   <lemma>točit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p4s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w9</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w10</LM>
   </w.rf>
   <form>osmiboké</form>
   <lemma>osmiboký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w11</LM>
   </w.rf>
   <form>dřevěné</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w12</LM>
   </w.rf>
   <form>věže</form>
   <lemma>věž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s4w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s5">
  <m id="m-ln94207-103-p4s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w1</LM>
   </w.rf>
   <form>Julia</form>
   <lemma>Julia_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w2</LM>
   </w.rf>
   <form>Bollesová</form>
   <lemma>Bollesová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w4</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w5</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w6</LM>
   </w.rf>
   <form>ceněný</form>
   <lemma>ceněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w7</LM>
   </w.rf>
   <form>Peter</form>
   <lemma>Peter_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w8</LM>
   </w.rf>
   <form>Wilson</form>
   <lemma>Wilson_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w10</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w11</LM>
   </w.rf>
   <form>volně</form>
   <lemma>volně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w12</LM>
   </w.rf>
   <form>tvarované</form>
   <lemma>tvarovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w13</LM>
   </w.rf>
   <form>tělo</form>
   <lemma>tělo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w14</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m-ln94207-103-p4s5w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w15</LM>
   </w.rf>
   <form>školky</form>
   <lemma>školka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w16</LM>
   </w.rf>
   <form>vybrali</form>
   <lemma>vybrat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p4s5w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w17</LM>
   </w.rf>
   <form>pozdní</form>
   <lemma>pozdní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w18</LM>
   </w.rf>
   <form>Le</form>
   <lemma>Le-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w19</LM>
   </w.rf>
   <form>Corbusierův</form>
   <lemma>Corbusierův_;Y_^(*2)</lemma>
   <tag>AUIS4M---------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w20</LM>
   </w.rf>
   <form>styl</form>
   <lemma>styl</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w21</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w22</LM>
   </w.rf>
   <form>údobí</form>
   <lemma>údobí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w23</LM>
   </w.rf>
   <form>kaple</form>
   <lemma>kaple</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s5w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w25</LM>
   </w.rf>
   <form>Ronchamp</form>
   <lemma>Ronchamp_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s5w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s5w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s6">
  <m id="m-ln94207-103-p4s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w2</LM>
   </w.rf>
   <form>detailech</form>
   <lemma>detail</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p4s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w4</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w5</LM>
   </w.rf>
   <form>citáty</form>
   <lemma>citát</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w7</LM>
   </w.rf>
   <form>Le</form>
   <lemma>Le-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w8</LM>
   </w.rf>
   <form>Corbusiera</form>
   <lemma>Corbusier_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w9</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w10</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w11</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w12</LM>
   </w.rf>
   <form>doslovné</form>
   <lemma>doslovný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w16</LM>
   </w.rf>
   <form>celkovém</form>
   <lemma>celkový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w17</LM>
   </w.rf>
   <form>tvaru</form>
   <lemma>tvar</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w18</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w19</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m-ln94207-103-p4s6w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w20</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w21</LM>
   </w.rf>
   <form>kaple</form>
   <lemma>kaple</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w22</LM>
   </w.rf>
   <form>vyšla</form>
   <lemma>vyjít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-ln94207-103-p4s6w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w23</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w24</LM>
   </w.rf>
   <form>rukou</form>
   <lemma>ruka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w25</LM>
   </w.rf>
   <form>ponorka</form>
   <lemma>ponorka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s6w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w26</LM>
   </w.rf>
   <form>U</form>
   <lemma>U-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w27</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s6w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s6w28</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s7">
  <m id="m-ln94207-103-p4s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w2</LM>
   </w.rf>
   <form>týchž</form>
   <lemma>týž</lemma>
   <tag>PDXP6---------1</tag>
  </m>
  <m id="m-ln94207-103-p4s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w3</LM>
   </w.rf>
   <form>padesátých</form>
   <lemma>padesátý</lemma>
   <tag>CrNP6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w4</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w6</LM>
   </w.rf>
   <form>tým</form>
   <lemma>tým</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w7</LM>
   </w.rf>
   <form>Bollesová</form>
   <lemma>Bollesová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w8</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s7w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w9</LM>
   </w.rf>
   <form>Wilson</form>
   <lemma>Wilson_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w10</LM>
   </w.rf>
   <form>hledal</form>
   <lemma>hledat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-ln94207-103-p4s7w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w11</LM>
   </w.rf>
   <form>inspiraci</form>
   <lemma>inspirace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w12</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-ln94207-103-p4s7w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w13</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m-ln94207-103-p4s7w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w14</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w15</LM>
   </w.rf>
   <form>Němec</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w16</LM>
   </w.rf>
   <form>Andreas</form>
   <lemma>Andreas_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w17</LM>
   </w.rf>
   <form>Keller</form>
   <lemma>Keller_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s7w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s7w18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s8">
  <m id="m-ln94207-103-p4s8w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w1</LM>
   </w.rf>
   <form>Příznivcům</form>
   <lemma>příznivec</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w2</LM>
   </w.rf>
   <form>střídmějších</form>
   <lemma>střídmý</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w3</LM>
   </w.rf>
   <form>směrů</form>
   <lemma>směr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s8w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w5</LM>
   </w.rf>
   <form>dnešní</form>
   <lemma>dnešní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w6</LM>
   </w.rf>
   <form>architektuře</form>
   <lemma>architektura</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w7</LM>
   </w.rf>
   <form>doporučuji</form>
   <lemma>doporučovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m-ln94207-103-p4s8w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w8</LM>
   </w.rf>
   <form>dílo</form>
   <lemma>dílo_^(umělecké,_vědecké,...)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w9</LM>
   </w.rf>
   <form>německých</form>
   <lemma>německý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w10</LM>
   </w.rf>
   <form>architektů</form>
   <lemma>architekt</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w11</LM>
   </w.rf>
   <form>Hanse</form>
   <lemma>Hans_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w12</LM>
   </w.rf>
   <form>Kollhoffa</form>
   <lemma>Kollhoff_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s8w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w14</LM>
   </w.rf>
   <form>Helgy</form>
   <lemma>Helga_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w15</LM>
   </w.rf>
   <form>Timmermannové</form>
   <lemma>Timmermannová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s8w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s8w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p4s9">
  <m id="m-ln94207-103-p4s9w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w1</LM>
   </w.rf>
   <form>Jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w2</LM>
   </w.rf>
   <form>neomítnutá</form>
   <lemma>omítnutý_^(*3out)</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w3</LM>
   </w.rf>
   <form>cihlová</form>
   <lemma>cihlový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w4</LM>
   </w.rf>
   <form>školka</form>
   <lemma>školka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w6</LM>
   </w.rf>
   <form>tvaru</form>
   <lemma>tvar</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w7</LM>
   </w.rf>
   <form>schodů</form>
   <lemma>schod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w8</LM>
   </w.rf>
   <form>výborně</form>
   <lemma>výborně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w9</LM>
   </w.rf>
   <form>evokuje</form>
   <lemma>evokovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m-ln94207-103-p4s9w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w13</LM>
   </w.rf>
   <form>ničem</form>
   <lemma>nic</lemma>
   <tag>PY--6----------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w14</LM>
   </w.rf>
   <form>neimituje</form>
   <lemma>imitovat</lemma>
   <tag>VB-S---3P-NAB--</tag>
  </m>
  <m id="m-ln94207-103-p4s9w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w15</LM>
   </w.rf>
   <form>klasickou</form>
   <lemma>klasický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w16</LM>
   </w.rf>
   <form>modernu</form>
   <lemma>moderna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w17</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w18</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m-ln94207-103-p4s9w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w19</LM>
   </w.rf>
   <form>poloviny</form>
   <lemma>polovina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w20</LM>
   </w.rf>
   <form>století</form>
   <lemma>století</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p4s9w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p4s9w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p5s1">
  <m id="m-ln94207-103-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w1</LM>
   </w.rf>
   <form>Mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w2</LM>
   </w.rf>
   <form>školky</form>
   <lemma>školka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w4</LM>
   </w.rf>
   <form>Moderní</form>
   <lemma>moderní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w5</LM>
   </w.rf>
   <form>architektura</form>
   <lemma>architektura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94207-103-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w7</LM>
   </w.rf>
   <form>Frankfurtu</form>
   <lemma>Frankfurt_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w8</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln94207-103-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w9</LM>
   </w.rf>
   <form>Mohanem</form>
   <lemma>Mohan_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s1w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-ln94207-103-p5s2">
  <m id="m-ln94207-103-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w1</LM>
   </w.rf>
   <form>Národní</form>
   <lemma>národní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w2</LM>
   </w.rf>
   <form>technické</form>
   <lemma>technický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w3</LM>
   </w.rf>
   <form>muzeum</form>
   <lemma>muzeum</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w5</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w7</LM>
   </w.rf>
   <form>16</form>
   <lemma>16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w9</LM>
   </w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w10</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w11</LM>
   </w.rf>
   <form>18</form>
   <lemma>18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94207-103-p5s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w13</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-ln94207-103-p5s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94207-103-p5s2w14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
