<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94206_128.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94206-128-p2s11">
  <m id="m-ln94206-128-p2s11w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w1</LM>
   </w.rf>
   <form>Celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-ln94206-128-p2s11w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m-ln94206-128-p2s11w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w3</LM>
   </w.rf>
   <form>vyloučeno</form>
   <lemma>vyloučit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m-ln94206-128-p2s11w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w4</LM>
   </w.rf>
   <form>17</form>
   <lemma>17</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-ln94206-128-p2s11w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w5</LM>
   </w.rf>
   <form>hráčů</form>
   <lemma>hráč</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-ln94206-128-p2s11w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-ln94206-128-p2s11w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w7</LM>
   </w.rf>
   <form>devíti</form>
   <lemma>devět`9</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m-ln94206-128-p2s11w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w8</LM>
   </w.rf>
   <form>mužstev</form>
   <lemma>mužstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m-ln94206-128-p2s11w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94206-128-p2s11w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
