<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94208_39.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94208-39-p1s1A">
  <m id="m-ln94208-39-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94208-39-p1s1Aw1</LM>
   </w.rf>
   <form>Model</form>
   <lemma>model-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-ln94208-39-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94208-39-p1s1Aw2</LM>
   </w.rf>
   <form>tančícího</form>
   <lemma>tančící_^(*3it)</lemma>
   <tag>AGIS2-----A----</tag>
  </m>
  <m id="m-ln94208-39-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94208-39-p1s1Aw3</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
 <s id="m-ln94208-39-p1s1B">
  <m id="m-ln94208-39-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94208-39-p1s1Bw1</LM>
   </w.rf>
   <form>Repro</form>
   <lemma>repro</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94208-39-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94208-39-p1s1Bw2</LM>
   </w.rf>
   <form>LN</form>
   <lemma>LN-1_;m_^(Lidové_noviny)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
 </s>
</mdata>
