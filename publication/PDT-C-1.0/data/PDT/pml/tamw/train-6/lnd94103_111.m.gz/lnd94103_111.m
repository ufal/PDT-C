<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94103_111.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94103-111-p1s1C">
  <m id="m-lnd94103-111-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94103-111-p1s1w1</LM>
   </w.rf>
   <form>František</form>
   <lemma>František_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94103-111-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94103-111-p1s1w2</LM>
   </w.rf>
   <form>Musil</form>
   <lemma>Musil_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd94103-111-p1s1B">
  <m id="m-lnd94103-111-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94103-111-p1s1w3</LM>
   </w.rf>
   <form>Foto</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94103-111-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94103-111-p1s1w4</LM>
   </w.rf>
   <form>archiv</form>
   <lemma>archiv</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
</mdata>
