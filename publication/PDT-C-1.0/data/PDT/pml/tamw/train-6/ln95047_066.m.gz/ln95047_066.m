<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln95047_066.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln95047-066-p1s1">
  <m id="m-ln95047-066-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w1</LM>
   </w.rf>
   <form>Minulost</form>
   <lemma>minulost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-ln95047-066-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w2</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m-ln95047-066-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w3</LM>
   </w.rf>
   <form>těžištěm</form>
   <lemma>těžiště</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m-ln95047-066-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w4</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP2-P1-------</tag>
  </m>
  <m id="m-ln95047-066-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w5</LM>
   </w.rf>
   <form>vztahů</form>
   <lemma>vztah</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-ln95047-066-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-ln95047-066-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln95047-066-p1s1w7</LM>
   </w.rf>
   <form>Německem</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
 </s>
</mdata>
