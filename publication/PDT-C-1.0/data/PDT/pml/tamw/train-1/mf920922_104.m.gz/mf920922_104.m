<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf920922_104.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf920922-104-p1s1">
  <m id="m-mf920922-104-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w1</LM>
   </w.rf>
   <form>Mečiar</form>
   <lemma>Mečiar_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920922-104-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w2</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-mf920922-104-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w3</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-mf920922-104-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920922-104-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w5</LM>
   </w.rf>
   <form>Hradě</form>
   <lemma>hrad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-mf920922-104-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p1s1w6</LM>
   </w.rf>
   <form>Klause</form>
   <lemma>Klaus_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
 </s>
 <s id="m-mf920922-104-p2s1">
  <m id="m-mf920922-104-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p2s1w1</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-104-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p2s1w2</LM>
   </w.rf>
   <form>str</form>
   <lemma>strana</lemma>
   <tag>NNFXX-----A---a</tag>
  </m>
  <m id="m-mf920922-104-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p2s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf920922-104-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p2s1w4</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920922-104-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920922-104-p2s1w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
