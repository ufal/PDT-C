<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf920925_046.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf920925-046-p1s1">
  <m id="m-mf920925-046-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-mf920925-046-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w2</LM>
   </w.rf>
   <form>bugině</form>
   <lemma>bugina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w3</LM>
   </w.rf>
   <form>čtyřnásobný</form>
   <lemma>čtyřnásobný`4</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w4</LM>
   </w.rf>
   <form>autokrosový</form>
   <lemma>autokrosový</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w5</LM>
   </w.rf>
   <form>mistr</form>
   <lemma>mistr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w6</LM>
   </w.rf>
   <form>Československa</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w7</LM>
   </w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf920925-046-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920925-046-p1s1w8</LM>
   </w.rf>
   <form>Bartoš</form>
   <lemma>Bartoš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
</mdata>
