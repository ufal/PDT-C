<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94204_123.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94204-123-p2s9">
  <m id="m-ln94204-123-p2s9w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94204-123-p2s9w1</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-ln94204-123-p2s9w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94204-123-p2s9w2</LM>
   </w.rf>
   <form>šv</form>
   <lemma>šv-99_;Y</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-ln94204-123-p2s9w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94204-123-p2s9w3</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
