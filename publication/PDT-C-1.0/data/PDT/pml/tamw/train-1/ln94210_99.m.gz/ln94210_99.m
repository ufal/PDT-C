<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ln94210_99.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-ln94210-99-p1s1A">
  <m id="m-ln94210-99-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-99-p1s1Aw1</LM>
   </w.rf>
   <form>David</form>
   <lemma>David-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-ln94210-99-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-99-p1s1Aw2</LM>
   </w.rf>
   <form>Gilmour</form>
   <lemma>Gilmour_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
 <s id="m-ln94210-99-p1s1B">
  <m id="m-ln94210-99-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-99-p1s1Bw1</LM>
   </w.rf>
   <form>Foto</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-ln94210-99-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-ln94210-99-p1s1Bw2</LM>
   </w.rf>
   <form>Reuter</form>
   <lemma>Reuter-2_;m_,i_^(^DS**Reuters)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
</mdata>
