<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf930713_039.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf930713-039-p1s1">
  <m id="m-mf930713-039-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w1</LM>
   </w.rf>
   <form>Místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930713-039-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w2</LM>
   </w.rf>
   <form>tragické</form>
   <lemma>tragický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-mf930713-039-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w3</LM>
   </w.rf>
   <form>události</form>
   <lemma>událost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930713-039-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930713-039-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w5</LM>
   </w.rf>
   <form>šipka</form>
   <lemma>šipka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930713-039-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w6</LM>
   </w.rf>
   <form>ukazuje</form>
   <lemma>ukazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-mf930713-039-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w7</LM>
   </w.rf>
   <form>mrtvou</form>
   <lemma>mrtvý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-mf930713-039-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930713-039-p1s1w8</LM>
   </w.rf>
   <form>podnikatelku</form>
   <lemma>podnikatelka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
 </s>
</mdata>
