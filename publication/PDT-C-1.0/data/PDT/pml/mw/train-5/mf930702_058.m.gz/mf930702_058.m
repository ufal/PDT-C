<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf930702_058.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf930702-058-p1s1">
  <m id="m-mf930702-058-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w1</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w2</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w3</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w5</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w8</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w9</LM>
   </w.rf>
   <form>1.1850</form>
   <lemma>1.1850</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w12</LM>
   </w.rf>
   <form>7825</form>
   <lemma>7825</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w14</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w16</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w18</LM>
   </w.rf>
   <form>0555</form>
   <lemma>0555</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w19</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w21</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w23</LM>
   </w.rf>
   <form>0555</form>
   <lemma>0555</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w24</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w26</LM>
   </w.rf>
   <form>BOX</form>
   <lemma>box-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p1s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w27</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w28</LM>
   </w.rf>
   <form>Z</form>
   <lemma>Z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w29</LM>
   </w.rf>
   <form>_</form>
   <lemma>_</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w30</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w32</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w33</LM>
   </w.rf>
   <form>Z</form>
   <lemma>Z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w34</LM>
   </w.rf>
   <form>_</form>
   <lemma>_</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w35</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w36</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w37</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w38</LM>
   </w.rf>
   <form>Z</form>
   <lemma>Z-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w39</LM>
   </w.rf>
   <form>_</form>
   <lemma>_</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w40</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w42</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p1s1w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p1s1w43</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p2s1">
  <m id="m-mf930702-058-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w1</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w3</LM>
   </w.rf>
   <form>Příjmení</form>
   <lemma>příjmení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930702-058-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w5</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p2s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w7</LM>
   </w.rf>
   <form>Příslušnost</form>
   <lemma>příslušnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p2s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p2s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w9</LM>
   </w.rf>
   <form>Druh</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p2s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p2s1w10</LM>
   </w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p3s1">
  <m id="m-mf930702-058-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w1</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w3</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w4</LM>
   </w.rf>
   <form>Huml</form>
   <lemma>Huml_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w5</LM>
   </w.rf>
   <form>Ondřej</form>
   <lemma>Ondřej_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w7</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w9</LM>
   </w.rf>
   <form>Ford</form>
   <lemma>Ford-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w10</LM>
   </w.rf>
   <form>Scorpio</form>
   <lemma>Scorpio_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w11</LM>
   </w.rf>
   <form>Rymeš</form>
   <lemma>Rymeš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w12</LM>
   </w.rf>
   <form>Ladislav</form>
   <lemma>Ladislav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w14</LM>
   </w.rf>
   <form>LB</form>
   <lemma>LB-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w16</LM>
   </w.rf>
   <form>Fiat</form>
   <lemma>Fiat_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w17</LM>
   </w.rf>
   <form>Regata</form>
   <lemma>regata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w18</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w19</LM>
   </w.rf>
   <form>Hruška</form>
   <lemma>Hruška_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w20</LM>
   </w.rf>
   <form>Milan</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w22</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w24</LM>
   </w.rf>
   <form>Audi</form>
   <lemma>Audi_;m_^(vozidlo)</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w25</LM>
   </w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w28</LM>
   </w.rf>
   <form>BMW</form>
   <lemma>BMW_;m_^(vozidlo)</lemma>
   <tag>BNNXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w29</LM>
   </w.rf>
   <form>524</form>
   <lemma>524</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w30</LM>
   </w.rf>
   <form>TD</form>
   <lemma>TD-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w32</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w33</LM>
   </w.rf>
   <form>Audi</form>
   <lemma>Audi_;m_^(vozidlo)</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w34</LM>
   </w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w35</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w36</LM>
   </w.rf>
   <form>Verner</form>
   <lemma>Verner_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w37</LM>
   </w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w38</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w39</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w40</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w41</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w42</LM>
   </w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w43</LM>
   </w.rf>
   <form>Vrzal</form>
   <lemma>Vrzal_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w44</LM>
   </w.rf>
   <form>Ivan</form>
   <lemma>Ivan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w45</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w46</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w47</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w48</LM>
   </w.rf>
   <form>Mitsubishi</form>
   <lemma>Mitsubishi_;m</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w49</LM>
   </w.rf>
   <form>Galant</form>
   <lemma>Galant_;m_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w50</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w51</LM>
   </w.rf>
   <form>Jílek</form>
   <lemma>Jílek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w52</LM>
   </w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w53</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w54</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w55</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w56</LM>
   </w.rf>
   <form>Audi</form>
   <lemma>Audi_;m_^(vozidlo)</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w57</LM>
   </w.rf>
   <form>89</form>
   <lemma>89</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w58</LM>
   </w.rf>
   <form>Kolář</form>
   <lemma>Kolář_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w59</LM>
   </w.rf>
   <form>Robert</form>
   <lemma>Robert_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w60</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w61</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w62</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w63</LM>
   </w.rf>
   <form>Ford</form>
   <lemma>Ford-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w64</LM>
   </w.rf>
   <form>Escort</form>
   <lemma>Escort_;m_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w65">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w65</LM>
   </w.rf>
   <form>Procházka</form>
   <lemma>Procházka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w66">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w66</LM>
   </w.rf>
   <form>Vladimír</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w67">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w68">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w68</LM>
   </w.rf>
   <form>LSU</form>
   <lemma>LSU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w69">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w69</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w70">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w70</LM>
   </w.rf>
   <form>Ford</form>
   <lemma>Ford-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w71">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w71</LM>
   </w.rf>
   <form>Sierra</form>
   <lemma>Sierra_;G_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w72">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w72</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w73">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w73</LM>
   </w.rf>
   <form>Sychra</form>
   <lemma>Sychra_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w74">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w74</LM>
   </w.rf>
   <form>Miroslav</form>
   <lemma>Miroslav-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w75">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w75</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w76">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w76</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w77">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w77</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w78">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w78</LM>
   </w.rf>
   <form>Fiat</form>
   <lemma>Fiat_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w79">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w79</LM>
   </w.rf>
   <form>138</form>
   <lemma>138</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w80">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w80</LM>
   </w.rf>
   <form>R</form>
   <lemma>R-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w81">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w81</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w82">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w82</LM>
   </w.rf>
   <form>Laštůvka</form>
   <lemma>Laštůvka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w83">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w83</LM>
   </w.rf>
   <form>Vladimír</form>
   <lemma>Vladimír_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w84">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w84</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w85">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w85</LM>
   </w.rf>
   <form>OH</form>
   <lemma>OH-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w86">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w86</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w87">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w87</LM>
   </w.rf>
   <form>Ford</form>
   <lemma>Ford-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w88">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w88</LM>
   </w.rf>
   <form>Scorpio</form>
   <lemma>Scorpio_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w89">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w89</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w90">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w90</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w91">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w91</LM>
   </w.rf>
   <form>tiskárna</form>
   <lemma>tiskárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w92">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w92</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w93">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w93</LM>
   </w.rf>
   <form>počítači</form>
   <lemma>počítač</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w94">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w94</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w95">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w95</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w96">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w96</LM>
   </w.rf>
   <form>kopírovací</form>
   <lemma>kopírovací_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w97">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w97</LM>
   </w.rf>
   <form>stroj</form>
   <lemma>stroj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w98">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w98</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w99">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w99</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w100">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w100</LM>
   </w.rf>
   <form>diktafon</form>
   <lemma>diktafon</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w101">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w101</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w102">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w103">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w103</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w104">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w104</LM>
   </w.rf>
   <form>židle</form>
   <lemma>židle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w105">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w105</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w106">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w106</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w107">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w107</LM>
   </w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w108">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w108</LM>
   </w.rf>
   <form>ks</form>
   <lemma>kus</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-mf930702-058-p3s1w109">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w109</LM>
   </w.rf>
   <form>transformátorů</form>
   <lemma>transformátor</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w110">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w110</LM>
   </w.rf>
   <form>Štěrba</form>
   <lemma>Štěrba_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w111">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w111</LM>
   </w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w112">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w113">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w113</LM>
   </w.rf>
   <form>LSU</form>
   <lemma>LSU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w114">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w114</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w115">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w115</LM>
   </w.rf>
   <form>Nádrž</form>
   <lemma>nádrž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w116">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w116</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w117">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w117</LM>
   </w.rf>
   <form>mléko</form>
   <lemma>mléko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w118">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w118</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w119">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w119</LM>
   </w.rf>
   <form>chladící</form>
   <lemma>chladící_^(*3it)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w120">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w120</LM>
   </w.rf>
   <form>aparát</form>
   <lemma>aparát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w121">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w122">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w123">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w123</LM>
   </w.rf>
   <form>cena</form>
   <lemma>cena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w124">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w124</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5500</form>
   <lemma>5500</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w125">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w126">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w126</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w127">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w127</LM>
   </w.rf>
   <form>DM</form>
   <lemma>DM-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s1w128">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w128</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s1w129">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s1w129</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p3s2">
  <m id="m-mf930702-058-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w1</LM>
   </w.rf>
   <form>Mercedes</form>
   <lemma>Mercedes-1_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w2</LM>
   </w.rf>
   <form>Benz</form>
   <lemma>Benz-2_;m</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w3</LM>
   </w.rf>
   <form>190</form>
   <lemma>190</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w4</LM>
   </w.rf>
   <form>D</form>
   <lemma>D-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w5</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2.5</form>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf930702-058-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p3s2w6</LM>
   </w.rf>
   <form>Turbo</form>
   <lemma>Turbo_;G_;m</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p4s1">
  <m id="m-mf930702-058-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w1</LM>
   </w.rf>
   <form>TEXT</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w2</LM>
   </w.rf>
   <form>TABULKY</form>
   <lemma>tabulka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w4</LM>
   </w.rf>
   <form>TEXT</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w5</LM>
   </w.rf>
   <form>TABULKY</form>
   <lemma>tabulka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w7</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w9</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p4s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p4s1w11</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p5s1">
  <m id="m-mf930702-058-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w1</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w3</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w4</LM>
   </w.rf>
   <form>Soldát</form>
   <lemma>Soldát_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w5</LM>
   </w.rf>
   <form>Miloslav</form>
   <lemma>Miloslav_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w7</LM>
   </w.rf>
   <form>ODS</form>
   <lemma>ODS_;m_^(Občanská_demokratická_strana)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w9</LM>
   </w.rf>
   <form>Peugeot</form>
   <lemma>Peugeot-2_;m_^(vozidlo)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w10</LM>
   </w.rf>
   <form>Vlček</form>
   <lemma>Vlček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w11</LM>
   </w.rf>
   <form>Jaroslav</form>
   <lemma>Jaroslav-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w13</LM>
   </w.rf>
   <form>LSU</form>
   <lemma>LSU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w15</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w16</LM>
   </w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w17</LM>
   </w.rf>
   <form>*</form>
   <lemma>*</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w18</LM>
   </w.rf>
   <form>Mráček</form>
   <lemma>Mráček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w19</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w21</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w22</LM>
   </w.rf>
   <form>SPR</form>
   <lemma>SPR-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w23</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w24</LM>
   </w.rf>
   <form>RSČ</form>
   <lemma>RSČ-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w26</LM>
   </w.rf>
   <form>Fiat</form>
   <lemma>Fiat_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w27</LM>
   </w.rf>
   <form>Raška</form>
   <lemma>Raška_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w28</LM>
   </w.rf>
   <form>Miroslav</form>
   <lemma>Miroslav-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w29</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w30</LM>
   </w.rf>
   <form>LSU</form>
   <lemma>LSU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w32</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w33</LM>
   </w.rf>
   <form>automobil</form>
   <lemma>automobil</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w34</LM>
   </w.rf>
   <form>Kraus</form>
   <lemma>Kraus_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w35</LM>
   </w.rf>
   <form>Michal</form>
   <lemma>Michal_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w36</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w37</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w38</LM>
   </w.rf>
   <form>HSDMS</form>
   <lemma>HSDMS_;m_^(Hnutí_za_samosprávnou_demokracii_Moravy_a_Slezska)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w39</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p5s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w40</LM>
   </w.rf>
   <form>Mercedes</form>
   <lemma>Mercedes-1_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p5s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p5s1w41</LM>
   </w.rf>
   <form>Benz</form>
   <lemma>Benz-2_;m</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
 </s>
 <s id="m-mf930702-058-p6s1">
  <m id="m-mf930702-058-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w1</LM>
   </w.rf>
   <form>TEXT</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w2</LM>
   </w.rf>
   <form>TABULKY</form>
   <lemma>tabulka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w4</LM>
   </w.rf>
   <form>TEXT</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w5</LM>
   </w.rf>
   <form>TABULKY</form>
   <lemma>tabulka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w7</LM>
   </w.rf>
   <form>TEXT</form>
   <lemma>text</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w8</LM>
   </w.rf>
   <form>TABULKY</form>
   <lemma>tabulka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-mf930702-058-p6s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w9</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w11</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-mf930702-058-p6s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-058-p6s1w13</LM>
   </w.rf>
   <form>^</form>
   <lemma>^</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
