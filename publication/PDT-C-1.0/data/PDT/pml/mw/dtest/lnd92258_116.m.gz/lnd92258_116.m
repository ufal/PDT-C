<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92258_116.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92258-116-p1s1">
  <m id="m-lnd92258-116-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p1s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5355405185.5</form>
   <lemma>5355405185.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p1s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p1s1w3</LM>
   </w.rf>
   <form>5.51</form>
   <lemma>5.51</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p1s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p2s1">
  <m id="m-lnd92258-116-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w1</LM>
   </w.rf>
   <form>211121.3219</form>
   <lemma>211121.3219</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w3</LM>
   </w.rf>
   <form>9721.41</form>
   <lemma>9721.41</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w5</LM>
   </w.rf>
   <form>21.32</form>
   <lemma>21.32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p3s1">
  <m id="m-lnd92258-116-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p3s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2582602542.66</form>
   <lemma>2582602542.66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p3s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p3s1w3</LM>
   </w.rf>
   <form>2.66</form>
   <lemma>2.66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p3s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p4s1">
  <m id="m-lnd92258-116-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w1</LM>
   </w.rf>
   <form>181418.3217</form>
   <lemma>181418.3217</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w3</LM>
   </w.rf>
   <form>7718.69</form>
   <lemma>7718.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w5</LM>
   </w.rf>
   <form>18.69</form>
   <lemma>18.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p5s1">
  <m id="m-lnd92258-116-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w1</LM>
   </w.rf>
   <form>203420.5419</form>
   <lemma>203420.5419</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w3</LM>
   </w.rf>
   <form>9320.99</form>
   <lemma>9320.99</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w5</LM>
   </w.rf>
   <form>21.00</form>
   <lemma>21.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p6s1">
  <m id="m-lnd92258-116-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w1</LM>
   </w.rf>
   <form>280328.3227</form>
   <lemma>280328.3227</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w3</LM>
   </w.rf>
   <form>4828.88</form>
   <lemma>4828.88</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w5</LM>
   </w.rf>
   <form>28.18</form>
   <lemma>28.18</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92258-116-p7s1">
  <m id="m-lnd92258-116-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w1</LM>
   </w.rf>
   <form>434343.8741</form>
   <lemma>434343.8741</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w3</LM>
   </w.rf>
   <form>8244.96</form>
   <lemma>8244.96</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92258-116-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w5</LM>
   </w.rf>
   <form>45.54</form>
   <lemma>45.54</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92258-116-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92258-116-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
