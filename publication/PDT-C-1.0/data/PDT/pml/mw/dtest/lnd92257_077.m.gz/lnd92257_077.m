<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92257_077.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92257-077-p1s1">
  <m id="m-lnd92257-077-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w1</LM>
   </w.rf>
   <form>53635.4175</form>
   <lemma>53635.4175</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w3</LM>
   </w.rf>
   <form>205.52</form>
   <lemma>205.52</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w5</LM>
   </w.rf>
   <form>5.56</form>
   <lemma>5.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p1s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p2s1">
  <m id="m-lnd92257-077-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w1</LM>
   </w.rf>
   <form>2125621.47020</form>
   <lemma>2125621.47020</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w3</LM>
   </w.rf>
   <form>1121.55</form>
   <lemma>1121.55</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w5</LM>
   </w.rf>
   <form>21.15</form>
   <lemma>21.15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p3s1">
  <m id="m-lnd92257-077-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w1</LM>
   </w.rf>
   <form>25872.6132</form>
   <lemma>25872.6132</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w3</LM>
   </w.rf>
   <form>552.67</form>
   <lemma>552.67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w5</LM>
   </w.rf>
   <form>2.69</form>
   <lemma>2.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p3s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p4s1">
  <m id="m-lnd92257-077-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w1</LM>
   </w.rf>
   <form>1819818.38017</form>
   <lemma>1819818.38017</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w3</LM>
   </w.rf>
   <form>8318.75</form>
   <lemma>8318.75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w5</LM>
   </w.rf>
   <form>18.89</form>
   <lemma>18.89</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p5s1">
  <m id="m-lnd92257-077-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w1</LM>
   </w.rf>
   <form>2038620.59019</form>
   <lemma>2038620.59019</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w3</LM>
   </w.rf>
   <form>9821.04</form>
   <lemma>9821.04</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w5</LM>
   </w.rf>
   <form>21.22</form>
   <lemma>21.22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p6s1">
  <m id="m-lnd92257-077-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w1</LM>
   </w.rf>
   <form>2793028.21027</form>
   <lemma>2793028.21027</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w3</LM>
   </w.rf>
   <form>3728.77</form>
   <lemma>3728.77</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w5</LM>
   </w.rf>
   <form>28.49</form>
   <lemma>28.49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92257-077-p7s1">
  <m id="m-lnd92257-077-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w1</LM>
   </w.rf>
   <form>4389744.33942</form>
   <lemma>4389744.33942</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w3</LM>
   </w.rf>
   <form>2945.43</form>
   <lemma>2945.43</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92257-077-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w5</LM>
   </w.rf>
   <form>46.46</form>
   <lemma>46.46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92257-077-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-077-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
