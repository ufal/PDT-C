<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92252_063.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92252-063-p1s1">
  <m id="m-lnd92252-063-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p1s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>5405465245.56</form>
   <lemma>5405465245.56</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p1s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p1s1w3</LM>
   </w.rf>
   <form>5.64</form>
   <lemma>5.64</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p1s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p2s1">
  <m id="m-lnd92252-063-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w1</LM>
   </w.rf>
   <form>208621.0719</form>
   <lemma>208621.0719</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w3</LM>
   </w.rf>
   <form>7121.15</form>
   <lemma>7121.15</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p2s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w5</LM>
   </w.rf>
   <form>21.44</form>
   <lemma>21.44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p2s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p2s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p3s1">
  <m id="m-lnd92252-063-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p3s1w1</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2612632572.69</form>
   <lemma>2612632572.69</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p3s1w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p3s1w3</LM>
   </w.rf>
   <form>2.73</form>
   <lemma>2.73</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p3s1w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p4s1">
  <m id="m-lnd92252-063-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w1</LM>
   </w.rf>
   <form>183418.5317</form>
   <lemma>183418.5317</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w3</LM>
   </w.rf>
   <form>9718.89</form>
   <lemma>9718.89</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w5</LM>
   </w.rf>
   <form>19.16</form>
   <lemma>19.16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p4s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p5s1">
  <m id="m-lnd92252-063-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w1</LM>
   </w.rf>
   <form>205620.7720</form>
   <lemma>205620.7720</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w3</LM>
   </w.rf>
   <form>1621.22</form>
   <lemma>1621.22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w5</LM>
   </w.rf>
   <form>21.50</form>
   <lemma>21.50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p5s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p6s1">
  <m id="m-lnd92252-063-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w1</LM>
   </w.rf>
   <form>276527.9327</form>
   <lemma>276527.9327</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w3</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>928.49</form>
   <lemma>928.49</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w5</LM>
   </w.rf>
   <form>28.00</form>
   <lemma>28.00</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p6s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p7s1">
  <m id="m-lnd92252-063-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w1</LM>
   </w.rf>
   <form>449345.3843</form>
   <lemma>449345.3843</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w3</LM>
   </w.rf>
   <form>3246.46</form>
   <lemma>3246.46</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w4</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w5</LM>
   </w.rf>
   <form>47.32</form>
   <lemma>47.32</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92252-063-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p7s1w6</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92252-063-p8s1">
  <m id="m-lnd92252-063-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w1</LM>
   </w.rf>
   <form>Erupční</form>
   <lemma>erupční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w2</LM>
   </w.rf>
   <form>aktivita</form>
   <lemma>aktivita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w3</LM>
   </w.rf>
   <form>Slunce</form>
   <lemma>slunce</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w5</LM>
   </w.rf>
   <form>slabá</form>
   <lemma>slabý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w7</LM>
   </w.rf>
   <form>geomagnetické</form>
   <lemma>geomagnetický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w8</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w9</LM>
   </w.rf>
   <form>Země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w11</LM>
   </w.rf>
   <form>porušené</form>
   <lemma>porušený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-lnd92252-063-p8s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92252-063-p8s1w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
