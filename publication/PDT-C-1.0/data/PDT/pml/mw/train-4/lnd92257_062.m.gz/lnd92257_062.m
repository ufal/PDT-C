<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92257_062.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92257-062-p1s1A">
  <m id="m-lnd92257-062-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-062-p1s1Aw1</LM>
   </w.rf>
   <form>Kresba</form>
   <lemma>kresba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92257-062-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-062-p1s1Aw2</LM>
   </w.rf>
   <form>Miroslav</form>
   <lemma>Miroslav-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92257-062-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92257-062-p1s1Aw3</LM>
   </w.rf>
   <form>Kemel</form>
   <lemma>Kemel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
 </s>
</mdata>
