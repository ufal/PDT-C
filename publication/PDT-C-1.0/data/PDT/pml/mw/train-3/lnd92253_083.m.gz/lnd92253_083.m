<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd92253_083.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd92253-083-p1s1">
  <m id="m-lnd92253-083-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p1s1w1</LM>
   </w.rf>
   <form>Tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p2s1">
  <m id="m-lnd92253-083-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p2s1w1</LM>
   </w.rf>
   <form>Fotbal</form>
   <lemma>fotbal</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p3s1">
  <m id="m-lnd92253-083-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s1w1</LM>
   </w.rf>
   <form>Svazijsko</form>
   <lemma>Svazijsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p3s2">
  <m id="m-lnd92253-083-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w1</LM>
   </w.rf>
   <form>Zair</form>
   <lemma>Zair_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w2</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w4</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w5</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w6</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w7</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w8</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w9</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w11</LM>
   </w.rf>
   <form>kvalifikace</form>
   <lemma>kvalifikace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w13</LM>
   </w.rf>
   <form>MS</form>
   <lemma>MS-1_^(mistrovství_světa)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w14</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w15</LM>
   </w.rf>
   <form>94</form>
   <lemma>94</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p3s2w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p4s1">
  <m id="m-lnd92253-083-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p4s1w1</LM>
   </w.rf>
   <form>Krasobruslení</form>
   <lemma>krasobruslení</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s1">
  <m id="m-lnd92253-083-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s1w1</LM>
   </w.rf>
   <form>Výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s1w2</LM>
   </w.rf>
   <form>VC</form>
   <lemma>VC-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s1w3</LM>
   </w.rf>
   <form>Košic</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s1w4</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s2">
  <m id="m-lnd92253-083-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s2w1</LM>
   </w.rf>
   <form>muži</form>
   <lemma>muž</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s2w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s2w3</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s2w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s3">
  <m id="m-lnd92253-083-p5s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w1</LM>
   </w.rf>
   <form>Vidrai</form>
   <lemma>Vidrai_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w3</LM>
   </w.rf>
   <form>Maď</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNXX-----A---b</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2.5</form>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w8</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s3w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s4">
  <m id="m-lnd92253-083-p5s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s4w1</LM>
   </w.rf>
   <form>Vincze</form>
   <lemma>Vincze_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s4w2</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2.5</form>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s4w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s4w4</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s4w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s5">
  <m id="m-lnd92253-083-p5s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w1</LM>
   </w.rf>
   <form>Miskolcz</form>
   <lemma>Miskolcz_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w3</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w4</LM>
   </w.rf>
   <form>Košice</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>4.0</form>
   <lemma>4.0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w7</LM>
   </w.rf>
   <form>b</form>
   <lemma>bod</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-lnd92253-083-p5s5w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s5w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s6">
  <m id="m-lnd92253-083-p5s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s6w1</LM>
   </w.rf>
   <form>Ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s6w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s6w3</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s6w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s6w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s7">
  <m id="m-lnd92253-083-p5s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w1</LM>
   </w.rf>
   <form>Nagyová</form>
   <lemma>Nagyová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w3</LM>
   </w.rf>
   <form>Maď</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNXX-----A---b</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>2.0</form>
   <lemma>2.0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w7</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w8</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s7w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s7w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s8">
  <m id="m-lnd92253-083-p5s8w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w1</LM>
   </w.rf>
   <form>Štefaníková</form>
   <lemma>Štefaníková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w3</LM>
   </w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w4</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w5</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>3.5</form>
   <lemma>3.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w7</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s8w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s8w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p5s9">
  <m id="m-lnd92253-083-p5s9w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w1</LM>
   </w.rf>
   <form>Gegöová</form>
   <lemma>Gegöová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p5s9w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w2</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s9w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w3</LM>
   </w.rf>
   <form>Maď</form>
   <lemma>Maďarsko_;G</lemma>
   <tag>NNNXX-----A---b</tag>
  </m>
  <m id="m-lnd92253-083-p5s9w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s9w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w5</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p5s9w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p5s9w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p6s1">
  <m id="m-lnd92253-083-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p6s1w1</LM>
   </w.rf>
   <form>Tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p7s1">
  <m id="m-lnd92253-083-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s1w1</LM>
   </w.rf>
   <form>Stockholm</form>
   <lemma>Stockholm_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s1w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p7s2">
  <m id="m-lnd92253-083-p7s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w1</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w5</LM>
   </w.rf>
   <form>Bergström</form>
   <lemma>Bergström_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w7</LM>
   </w.rf>
   <form>Haarhuis</form>
   <lemma>Haarhuis_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w8</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w10</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w12</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w14</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w16</LM>
   </w.rf>
   <form>Tarango</form>
   <lemma>Tarango_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w17</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w18</LM>
   </w.rf>
   <form>Pescosolido</form>
   <lemma>Pescosolido_;Y</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w19</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w20</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w21</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w23</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w24</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w25</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w27</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w28</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w29</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w31</LM>
   </w.rf>
   <form>Woodbridge</form>
   <lemma>Woodbridge-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w32</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w33</LM>
   </w.rf>
   <form>Hogstedt</form>
   <lemma>Hogstedt_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w34</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w35</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w36</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w37</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w38</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w39</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w40</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w41</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w42</LM>
   </w.rf>
   <form>Medveděv</form>
   <lemma>Medveděv_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w43</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w44</LM>
   </w.rf>
   <form>Delaitre</form>
   <lemma>Delaitre_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w45</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w46</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w47</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w48</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w49</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w50</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w51</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w52</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w53</LM>
   </w.rf>
   <form>Gustafsson</form>
   <lemma>Gustafsson_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w54</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w55</LM>
   </w.rf>
   <form>Steeb</form>
   <lemma>Steeb_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w56</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w57</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w58</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w59</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w60</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w61</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w62</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w63</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w64</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w65">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w65</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w66">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w66</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w67">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w68">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w68</LM>
   </w.rf>
   <form>Mansdorf</form>
   <lemma>Mansdorf-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w69">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w69</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w70">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w70</LM>
   </w.rf>
   <form>Björkman</form>
   <lemma>Björkman_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w71">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w71</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w72">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w72</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w73">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w73</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w74">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w74</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w75">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w75</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w76">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w76</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w77">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w77</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w78">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w78</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w79">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w79</LM>
   </w.rf>
   <form>Wahlgren</form>
   <lemma>Wahlgren_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w80">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w80</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w81">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w81</LM>
   </w.rf>
   <form>Kulti</form>
   <lemma>Kulti_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w82">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w82</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w83">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w83</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w84">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w84</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w85">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w85</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w86">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w86</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w87">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w87</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w88">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w88</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w89">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w89</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w90">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w90</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w91">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w91</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w92">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w92</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w93">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w93</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w94">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w94</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w95">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w95</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w96">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w96</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w97">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w97</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w98">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w98</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w99">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w99</LM>
   </w.rf>
   <form>Masur</form>
   <lemma>Masur_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w100">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w100</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w101">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w101</LM>
   </w.rf>
   <form>Čerkasov</form>
   <lemma>Čerkasov_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w102">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w102</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w103">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w103</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w104">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w104</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w105">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w105</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w106">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w106</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w107">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w107</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w108">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w108</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w109">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w109</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w110">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w110</LM>
   </w.rf>
   <form>Česnokov</form>
   <lemma>Česnokov_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w111">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w111</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w112">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w112</LM>
   </w.rf>
   <form>Stenlund</form>
   <lemma>Stenlund_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w113">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w113</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w114">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w114</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w115">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w115</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w116">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w116</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w117">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w117</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w118">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w118</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w119">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w119</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p7s2w120">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p7s2w120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s1">
  <m id="m-lnd92253-083-p8s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s1w1</LM>
   </w.rf>
   <form>Žebříček</form>
   <lemma>žebříček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s1w2</LM>
   </w.rf>
   <form>ATP</form>
   <lemma>ATP-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s1w4</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s2">
  <m id="m-lnd92253-083-p8s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s2w1</LM>
   </w.rf>
   <form>Courier</form>
   <lemma>Courier_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s2w2</LM>
   </w.rf>
   <form>3439</form>
   <lemma>3439</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s2w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s2w4</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s2w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s3">
  <m id="m-lnd92253-083-p8s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s3w1</LM>
   </w.rf>
   <form>Sampras</form>
   <lemma>Sampras_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s3w2</LM>
   </w.rf>
   <form>3402</form>
   <lemma>3402</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s3w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s3w4</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s3w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s4">
  <m id="m-lnd92253-083-p8s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w1</LM>
   </w.rf>
   <form>Edberg</form>
   <lemma>Edberg_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w2</LM>
   </w.rf>
   <form>3093</form>
   <lemma>3093</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>0.5</form>
   <lemma>0.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s4w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s5">
  <m id="m-lnd92253-083-p8s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s5w1</LM>
   </w.rf>
   <form>Korda</form>
   <lemma>Korda_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s5w2</LM>
   </w.rf>
   <form>2161</form>
   <lemma>2161</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s5w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s5w4</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s5w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p8s6">
  <m id="m-lnd92253-083-p8s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s6w1</LM>
   </w.rf>
   <form>Lendl</form>
   <lemma>Lendl_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p8s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s6w2</LM>
   </w.rf>
   <form>2118</form>
   <lemma>2118</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p8s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p8s6w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s1">
  <m id="m-lnd92253-083-p9s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s1w1</LM>
   </w.rf>
   <form>Žebříček</form>
   <lemma>žebříček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s1w2</LM>
   </w.rf>
   <form>WTA</form>
   <lemma>WTA-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s1w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s1w4</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s2">
  <m id="m-lnd92253-083-p9s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w1</LM>
   </w.rf>
   <form>Selešová</form>
   <lemma>Selešová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w2</LM>
   </w.rf>
   <form>5355</form>
   <lemma>5355</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w3</LM>
   </w.rf>
   <form>bodů</form>
   <lemma>bod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w5</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s2w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s3">
  <m id="m-lnd92253-083-p9s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s3w1</LM>
   </w.rf>
   <form>Grafová</form>
   <lemma>Grafová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s3w2</LM>
   </w.rf>
   <form>4080</form>
   <lemma>4080</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s3w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s3w4</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s3w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s4">
  <m id="m-lnd92253-083-p9s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w1</LM>
   </w.rf>
   <form>Sabatiniová</form>
   <lemma>Sabatiniová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w2</LM>
   </w.rf>
   <form>3970</form>
   <lemma>3970</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>0.9</form>
   <lemma>0.9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s4w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s5">
  <m id="m-lnd92253-083-p9s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w1</LM>
   </w.rf>
   <form>Novotná</form>
   <lemma>Novotná_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w2</LM>
   </w.rf>
   <form>1403</form>
   <lemma>1403</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>0.16</form>
   <lemma>0.16</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s5w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s5w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s6">
  <m id="m-lnd92253-083-p9s6w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s6w1</LM>
   </w.rf>
   <form>Suková</form>
   <lemma>Suková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s6w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s6w2</LM>
   </w.rf>
   <form>1109</form>
   <lemma>1109</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s6w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s6w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s7">
  <m id="m-lnd92253-083-p9s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w1</LM>
   </w.rf>
   <form>Pořadí</form>
   <lemma>pořadí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w2</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd92253-083-p9s7w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w3</LM>
   </w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s7w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w4</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s7w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w5</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s7w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s7w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s8">
  <m id="m-lnd92253-083-p9s8w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w1</LM>
   </w.rf>
   <form>Selešová</form>
   <lemma>Selešová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s8w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w2</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>1802352</form>
   <lemma>1802352</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s8w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w3</LM>
   </w.rf>
   <form>dolarů</form>
   <lemma>dolar</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s8w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s8w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w5</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s8w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s8w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s9">
  <m id="m-lnd92253-083-p9s9w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s9w1</LM>
   </w.rf>
   <form>Grafová</form>
   <lemma>Grafová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s9w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s9w2</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>1257139</form>
   <lemma>1257139</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s9w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s9w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s9w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s9w4</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s9w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s9w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s10">
  <m id="m-lnd92253-083-p9s10w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w1</LM>
   </w.rf>
   <form>Sanchezová</form>
   <lemma>Sanchezová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w3</LM>
   </w.rf>
   <form>Vicariová</form>
   <lemma>Vicariová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w4</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>1119405</form>
   <lemma>1119405</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w8</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>0.8</form>
   <lemma>0.8</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s10w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s10w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s11">
  <m id="m-lnd92253-083-p9s11w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w1</LM>
   </w.rf>
   <form>Novotná</form>
   <lemma>Novotná_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w2</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>437184</form>
   <lemma>437184</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w6</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>0.12</form>
   <lemma>0.12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s11w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s11w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p9s12">
  <m id="m-lnd92253-083-p9s12w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s12w1</LM>
   </w.rf>
   <form>Suková</form>
   <lemma>Suková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p9s12w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s12w2</LM>
   </w.rf>
   <form_change>num_normalization</form_change>
   <form>359112</form>
   <lemma>359112</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p9s12w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p9s12w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p10s1">
  <m id="m-lnd92253-083-p10s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p10s1w1</LM>
   </w.rf>
   <form>Hokej</form>
   <lemma>hokej</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p11s1">
  <m id="m-lnd92253-083-p11s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w1</LM>
   </w.rf>
   <form>Výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w2</LM>
   </w.rf>
   <form>12</form>
   <lemma>12</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w4</LM>
   </w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w5</LM>
   </w.rf>
   <form>ČNL</form>
   <lemma>ČNL-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w6</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w7</LM>
   </w.rf>
   <form>Ml</form>
   <lemma>mladý</lemma>
   <tag>AAXXX----2A---b</tag>
  </m>
  <m id="m-lnd92253-083-p11s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s1w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd92253-083-p11s2">
  <m id="m-lnd92253-083-p11s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w1</LM>
   </w.rf>
   <form>Boleslav</form>
   <lemma>Boleslav-2_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w3</LM>
   </w.rf>
   <form>Opava</form>
   <lemma>Opava-2_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w4</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w5</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w6</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w7</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w8</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w9</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w10</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w12</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w13</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w14</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w15</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w16</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w17</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w18</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w19</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w20</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w21</LM>
   </w.rf>
   <form>Vsetín</form>
   <lemma>Vsetín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w22</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w23</LM>
   </w.rf>
   <form>Karviná</form>
   <lemma>Karviná_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w24</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w25</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w26</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w27</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w28</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w29</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w30</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w31</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w32</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w33</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w34</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w35</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w36</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w37</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w38</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w39</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w40</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w41</LM>
   </w.rf>
   <form>Jindřichův</form>
   <lemma>Jindřichův_;Y_^(*2)</lemma>
   <tag>AUIS1M---------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w42</LM>
   </w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w43</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w44</LM>
   </w.rf>
   <form>Zetor</form>
   <lemma>Zetor_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w45</LM>
   </w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w46</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w47</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w48">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w48</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w49">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w49</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w50">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w50</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w51">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w51</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w52">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w52</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w53">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w53</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w54">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w54</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w55">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w55</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w56">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w56</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w57">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w57</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w58">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w58</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w59">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w59</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w60">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w60</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w61">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w61</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w62">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w62</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w63">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w63</LM>
   </w.rf>
   <form>HC</form>
   <lemma>HC-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w64">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w64</LM>
   </w.rf>
   <form>Brno</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w65">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w65</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w66">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w66</LM>
   </w.rf>
   <form>VTJ</form>
   <lemma>VTJ-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w67">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w67</LM>
   </w.rf>
   <form>Tábor</form>
   <lemma>Tábor_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w68">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w68</LM>
   </w.rf>
   <form>5</form>
   <lemma>5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w69">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w69</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w70">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w70</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w71">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w71</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w72">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w72</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w73">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w73</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w74">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w74</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w75">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w75</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w76">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w76</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w77">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w77</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w78">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w78</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w79">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w79</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w80">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w80</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w81">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w81</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w82">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w82</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w83">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w83</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w84">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w84</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w85">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w85</LM>
   </w.rf>
   <form>Slavia</form>
   <lemma>Slavie_;m_,s_^(^DD**Slávie)</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w86">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w86</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w87">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w87</LM>
   </w.rf>
   <form>Třinec</form>
   <lemma>Třinec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w88">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w88</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w89">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w89</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w90">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w90</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w91">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w91</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w92">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w92</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w93">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w93</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w94">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w94</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w95">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w95</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w96">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w96</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w97">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w97</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w98">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w98</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w99">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w99</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w100">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w100</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w101">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w101</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w102">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w102</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w103">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w103</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w104">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w105">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w105</LM>
   </w.rf>
   <form>Sokolov</form>
   <lemma>Sokolov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w106">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w106</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w107">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w107</LM>
   </w.rf>
   <form>Havířov</form>
   <lemma>Havířov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w108">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w108</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w109">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w109</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w110">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w110</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w111">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w111</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w112">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w112</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w113">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w113</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w114">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w114</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w115">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w116">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w116</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w117">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w117</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w118">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w118</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w119">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w119</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w120">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w120</LM>
   </w.rf>
   <form>0</form>
   <lemma>0</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w121">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w121</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w122">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w122</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w123">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w123</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w124">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w124</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w125">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w125</LM>
   </w.rf>
   <form>Hodonín</form>
   <lemma>Hodonín_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w126">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w126</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w127">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w127</LM>
   </w.rf>
   <form>Hradec</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w128">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w128</LM>
   </w.rf>
   <form>Králové</form>
   <lemma>Králové_;G_^(Dvůr_Králové)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w129">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w129</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w130">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w130</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w131">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w131</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w132">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w132</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w133">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w133</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w134">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w134</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w135">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w135</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w136">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w137">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w137</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w138">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w138</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w139">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w139</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w140">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w140</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w141">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w141</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w142">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w142</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w143">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w143</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w144">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w144</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd92253-083-p11s2w145">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd92253-083-p11s2w145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
