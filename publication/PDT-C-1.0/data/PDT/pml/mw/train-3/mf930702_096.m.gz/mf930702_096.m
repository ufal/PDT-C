<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf930702_096.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf930702-096-p1s1">
  <m id="m-mf930702-096-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-096-p1s1w1</LM>
   </w.rf>
   <form>SPORTOVEC</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-mf930702-096-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf930702-096-p1s1w2</LM>
   </w.rf>
   <form>MĚSÍCE</form>
   <lemma>měsíc</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
 </s>
</mdata>
