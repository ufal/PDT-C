<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94104_079.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94104-079-p1s1A">
  <m id="m-lnd94104-079-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw1</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw6</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw7</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw8</LM>
   </w.rf>
   <form>LN</form>
   <lemma>LN-1_;m_^(Lidové_noviny)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw9</LM>
   </w.rf>
   <form>23</form>
   <lemma>23</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw11</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw13</LM>
   </w.rf>
   <form>1994</form>
   <lemma>1994</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Aw14</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-079-p1s1B">
  <m id="m-lnd94104-079-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw2</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw4</LM>
   </w.rf>
   <form>pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw5</LM>
   </w.rf>
   <form>Just</form>
   <lemma>Just_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw6</LM>
   </w.rf>
   <form>napsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-079-p1s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s1Bw7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-079-p1s4">
  <m id="m-lnd94104-079-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w1</LM>
   </w.rf>
   <form>Začátkem</form>
   <lemma>začátek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w3</LM>
   </w.rf>
   <form>1993</form>
   <lemma>1993</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w5</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w6</LM>
   </w.rf>
   <form>znovu</form>
   <lemma>znovu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w8</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w10</LM>
   </w.rf>
   <form>živnost</form>
   <lemma>živnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w11</LM>
   </w.rf>
   <form>provozoval</form>
   <lemma>provozovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w12</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w13</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w14</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w15</LM>
   </w.rf>
   <form>volném</form>
   <lemma>volný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w16</LM>
   </w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w18</LM>
   </w.rf>
   <form>doplňkový</form>
   <lemma>doplňkový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w19</LM>
   </w.rf>
   <form>zdroj</form>
   <lemma>zdroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w20</LM>
   </w.rf>
   <form>příjmů</form>
   <lemma>příjem</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-lnd94104-079-p1s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-079-p1s4w21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
