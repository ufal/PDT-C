<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf920924_129.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf920924-129-p1s1">
  <m id="m-mf920924-129-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p1s1w1</LM>
   </w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920924-129-p2s1">
  <m id="m-mf920924-129-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p2s1w1</LM>
   </w.rf>
   <form>F</form>
   <lemma>F-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-mf920924-129-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p2s1w2</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-mf920924-129-p13s1">
  <m id="m-mf920924-129-p13s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p13s1w1</LM>
   </w.rf>
   <form>Přestávka</form>
   <lemma>přestávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920924-129-p13s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p13s1w2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920924-129-p13s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p13s1w3</LM>
   </w.rf>
   <form>11.50</form>
   <lemma>11.50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920924-129-p13s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p13s1w4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920924-129-p13s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p13s1w5</LM>
   </w.rf>
   <form>15.20</form>
   <lemma>15.20</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
 <s id="m-mf920924-129-p38s1">
  <m id="m-mf920924-129-p38s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p38s1w1</LM>
   </w.rf>
   <form>Přestávka</form>
   <lemma>přestávka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-mf920924-129-p38s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p38s1w2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920924-129-p38s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p38s1w3</LM>
   </w.rf>
   <form>11.25</form>
   <lemma>11.25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-mf920924-129-p38s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p38s1w4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-mf920924-129-p38s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920924-129-p38s1w5</LM>
   </w.rf>
   <form>15.20</form>
   <lemma>15.20</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
</mdata>
