<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94105_050.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94105-050-p1s1">
  <m id="m-lnd94105-050-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-050-p1s1w1</LM>
   </w.rf>
   <form>Pobaltští</form>
   <lemma>pobaltský</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m-lnd94105-050-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-050-p1s1w2</LM>
   </w.rf>
   <form>prezidenti</form>
   <lemma>prezident</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-lnd94105-050-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-050-p1s1w3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-lnd94105-050-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-050-p1s1w4</LM>
   </w.rf>
   <form>odsunu</form>
   <lemma>odsun</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-lnd94105-050-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-050-p1s1w5</LM>
   </w.rf>
   <form>vojáků</form>
   <lemma>voják</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
 </s>
</mdata>
