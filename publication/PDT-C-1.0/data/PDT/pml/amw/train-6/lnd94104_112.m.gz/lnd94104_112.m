<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94104_112.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94104-112-p1s2">
  <m id="m-lnd94104-112-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s2w1</LM>
   </w.rf>
   <form>Temesvariová</form>
   <lemma>Temesvariová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94104-112-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s2w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-112-p1s4">
  <m id="m-lnd94104-112-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s4w1</LM>
   </w.rf>
   <form>Druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m-lnd94104-112-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s4w2</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-lnd94104-112-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s4w3</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94104-112-p1s5">
  <m id="m-lnd94104-112-p1s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s5w1</LM>
   </w.rf>
   <form>Navrátilová</form>
   <lemma>Navrátilová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94104-112-p1s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94104-112-p1s5w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
