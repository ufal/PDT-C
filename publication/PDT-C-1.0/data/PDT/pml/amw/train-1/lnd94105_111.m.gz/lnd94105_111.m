<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94105_111.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94105-111-p1s1">
  <m id="m-lnd94105-111-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-111-p1s1w1</LM>
   </w.rf>
   <form>Sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94105-111-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-111-p1s1w2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
 </s>
 <s id="m-lnd94105-111-p1s7">
  <m id="m-lnd94105-111-p1s7w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-111-p1s7w1</LM>
   </w.rf>
   <form>Liberec</form>
   <lemma>Liberec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-lnd94105-111-p1s7w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-111-p1s7w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
