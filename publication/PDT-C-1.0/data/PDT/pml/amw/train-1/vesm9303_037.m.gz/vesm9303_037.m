<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vesm9303_037.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-vesm9303-037-p1s1">
  <m id="m-vesm9303-037-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w1</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w5</LM>
   </w.rf>
   <form>časem</form>
   <lemma>čas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w9</LM>
   </w.rf>
   <form>našem</form>
   <lemma>náš</lemma>
   <tag>PSZS6-P1-------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w10</LM>
   </w.rf>
   <form>denním</form>
   <lemma>denní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w11</LM>
   </w.rf>
   <form>tisku</form>
   <lemma>tisk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w14</LM>
   </w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w15</LM>
   </w.rf>
   <form>časopise</form>
   <lemma>časopis</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w16</LM>
   </w.rf>
   <form>dočetla</form>
   <lemma>dočíst</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w18</LM>
   </w.rf>
   <form>indickém</form>
   <lemma>indický</lemma>
   <tag>AAMS6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w19</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>vědci</form>
   <lemma>vědec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w20</LM>
   </w.rf>
   <form>Chabrabártym</form>
   <lemma>Chabrabárty_;Y</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w22</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w23</LM>
   </w.rf>
   <form>objevil</form>
   <lemma>objevit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w24</LM>
   </w.rf>
   <form>baktérie</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w25</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w26</LM>
   </w.rf>
   <form>požírající</form>
   <lemma>požírající_^(*4t)</lemma>
   <tag>AGIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w27</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w28</LM>
   </w.rf>
   <form>odpad</form>
   <lemma>odpad</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w29</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w30</LM>
   </w.rf>
   <form>např</form>
   <lemma>například</lemma>
   <tag>TT------------b</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w31</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w32</LM>
   </w.rf>
   <form>rýžovou</form>
   <lemma>rýžový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w33</LM>
   </w.rf>
   <form>slámu</form>
   <lemma>sláma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w34</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w35</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w36</LM>
   </w.rf>
   <form>vyrábějící</form>
   <lemma>vyrábějící_^(*4t)</lemma>
   <tag>AGFP4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w37</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w38</LM>
   </w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w39</LM>
   </w.rf>
   <form>odpadů</form>
   <lemma>odpad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w40</LM>
   </w.rf>
   <form>metan</form>
   <lemma>metan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s1w41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p1s2">
  <m id="m-vesm9303-037-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w2</LM>
   </w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w4</LM>
   </w.rf>
   <form>světový</form>
   <lemma>světový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w5</LM>
   </w.rf>
   <form>objev</form>
   <lemma>objev</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w6</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w7</LM>
   </w.rf>
   <form>avšak</form>
   <lemma>avšak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w9</LM>
   </w.rf>
   <form>mnoha</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w10</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w11</LM>
   </w.rf>
   <form>bádání</form>
   <lemma>bádání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w12</LM>
   </w.rf>
   <form>vědec</form>
   <lemma>vědec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w13</LM>
   </w.rf>
   <form>zjistil</form>
   <lemma>zjistit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w16</LM>
   </w.rf>
   <form>baktérie</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w18</LM>
   </w.rf>
   <form>dostanou</form>
   <lemma>dostat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w19</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w20</LM>
   </w.rf>
   <form>li</form>
   <lemma>li-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w22</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w23</LM>
   </w.rf>
   <form>lidského</form>
   <lemma>lidský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w24</LM>
   </w.rf>
   <form>organismu</form>
   <lemma>organismus_,s_^(^DD**organizmus)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w26</LM>
   </w.rf>
   <form>mohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w27</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w28</LM>
   </w.rf>
   <form>zabíjet</form>
   <lemma>zabíjet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w29</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w30</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w32</LM>
   </w.rf>
   <form>neohrozil</form>
   <lemma>ohrozit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w33</LM>
   </w.rf>
   <form>lidský</form>
   <lemma>lidský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w34</LM>
   </w.rf>
   <form>rod</form>
   <lemma>rod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w35</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w36</LM>
   </w.rf>
   <form>raději</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w37</LM>
   </w.rf>
   <form>výsledky</form>
   <lemma>výsledek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w38</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS2----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w39</LM>
   </w.rf>
   <form>dvacetiletého</form>
   <lemma>dvacetiletý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w40</LM>
   </w.rf>
   <form>bádání</form>
   <lemma>bádání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w41</LM>
   </w.rf>
   <form>zcela</form>
   <lemma>zcela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w42</LM>
   </w.rf>
   <form>zničil</form>
   <lemma>zničit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s2w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s2w43</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p1s3">
  <m id="m-vesm9303-037-p1s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w1</LM>
   </w.rf>
   <form>Velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w2</LM>
   </w.rf>
   <form>mne</form>
   <lemma>já</lemma>
   <tag>PP-S4--1-------</tag>
  </m>
  <m id="m-vesm9303-037-p1s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w3</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w4</LM>
   </w.rf>
   <form>sdělení</form>
   <lemma>sdělení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w5</LM>
   </w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s3w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p1s4">
  <m id="m-vesm9303-037-p1s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w1</LM>
   </w.rf>
   <form>Ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w4</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w6</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w7</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w8</LM>
   </w.rf>
   <form>dozvěděla</form>
   <lemma>dozvědět</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w9</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w12</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w13</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w14</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w15</LM>
   </w.rf>
   <form>samotném</form>
   <lemma>samotný</lemma>
   <tag>AAMS6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w16</LM>
   </w.rf>
   <form>vědci</form>
   <lemma>vědec</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w18</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w19</LM>
   </w.rf>
   <form>prokázal</form>
   <lemma>prokázat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w21</LM>
   </w.rf>
   <form>vysoký</form>
   <lemma>vysoký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w22</LM>
   </w.rf>
   <form>stupeň</form>
   <lemma>stupeň</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w23</LM>
   </w.rf>
   <form>odpovědnosti</form>
   <lemma>odpovědnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p1s4w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p1s4w26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p2s1">
  <m id="m-vesm9303-037-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p2s1w1</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karla_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p2s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p2s1w2</LM>
   </w.rf>
   <form>Erbová</form>
   <lemma>Erbová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p2s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p2s1w3</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p2s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p2s1w4</LM>
   </w.rf>
   <form>Praha</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p3s1">
  <m id="m-vesm9303-037-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w1</LM>
   </w.rf>
   <form>Odpověď</form>
   <lemma>odpověď</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w3</LM>
   </w.rf>
   <form>Metan</form>
   <lemma>metan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w5</LM>
   </w.rf>
   <form>původně</form>
   <lemma>původně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w6</LM>
   </w.rf>
   <form>známý</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w7</LM>
   </w.rf>
   <form>spíše</form>
   <lemma>spíš</lemma>
   <tag>TT------------1</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w9</LM>
   </w.rf>
   <form>bahenní</form>
   <lemma>bahenní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w10</LM>
   </w.rf>
   <form>plyn</form>
   <lemma>plyn</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s1w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p3s2">
  <m id="m-vesm9303-037-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w1</LM>
   </w.rf>
   <form>Mikrobiologický</form>
   <lemma>mikrobiologický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w2</LM>
   </w.rf>
   <form>vznik</form>
   <lemma>vznik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w3</LM>
   </w.rf>
   <form>metanu</form>
   <lemma>metan</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w4</LM>
   </w.rf>
   <form>vysvětlil</form>
   <lemma>vysvětlit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w5</LM>
   </w.rf>
   <form>Omeljanski</form>
   <lemma>Omeljanski_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w7</LM>
   </w.rf>
   <form>Söhngen</form>
   <lemma>Söhngen_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s2w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p3s3">
  <m id="m-vesm9303-037-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w1</LM>
   </w.rf>
   <form>Izolaci</form>
   <lemma>izolace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w2</LM>
   </w.rf>
   <form>mikroorganismů</form>
   <lemma>mikroorganismus_,s_^(^DD**mikroorganizmus)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w4</LM>
   </w.rf>
   <form>ověření</form>
   <lemma>ověření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w5</LM>
   </w.rf>
   <form>reakcí</form>
   <lemma>reakce</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w6</LM>
   </w.rf>
   <form>metanového</form>
   <lemma>metanový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w7</LM>
   </w.rf>
   <form>kvašení</form>
   <lemma>kvašení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w8</LM>
   </w.rf>
   <form>provedl</form>
   <lemma>provést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w9</LM>
   </w.rf>
   <form>Barker</form>
   <lemma>Barker_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w10</LM>
   </w.rf>
   <form>r</form>
   <lemma>rok</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w12</LM>
   </w.rf>
   <form>1936</form>
   <lemma>1936</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p3s3w13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p4s1">
  <m id="m-vesm9303-037-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w1</LM>
   </w.rf>
   <form>Metanové</form>
   <lemma>metanový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w2</LM>
   </w.rf>
   <form>baktérie</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w4</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w5</LM>
   </w.rf>
   <form>skupinou</form>
   <lemma>skupina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w6</LM>
   </w.rf>
   <form>anaerobních</form>
   <lemma>anaerobní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w7</LM>
   </w.rf>
   <form>mikroorganismů</form>
   <lemma>mikroorganismus_,s_^(^DD**mikroorganizmus)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s1w8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p4s2">
  <m id="m-vesm9303-037-p4s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w1</LM>
   </w.rf>
   <form>Vyznačují</form>
   <lemma>vyznačovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w3</LM>
   </w.rf>
   <form>specifickou</form>
   <lemma>specifický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w4</LM>
   </w.rf>
   <form>látkovou</form>
   <lemma>látkový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w5</LM>
   </w.rf>
   <form>přeměnou</form>
   <lemma>přeměna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w7</LM>
   </w.rf>
   <form>získávání</form>
   <lemma>získávání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w8</LM>
   </w.rf>
   <form>energie</form>
   <lemma>energie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w9</LM>
   </w.rf>
   <form>potřebné</form>
   <lemma>potřebný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w10</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w11</LM>
   </w.rf>
   <form>růst</form>
   <lemma>růst-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s2w12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p4s3">
  <m id="m-vesm9303-037-p4s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w1</LM>
   </w.rf>
   <form>Tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w2</LM>
   </w.rf>
   <form>energii</form>
   <lemma>energie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w3</LM>
   </w.rf>
   <form>získávají</form>
   <lemma>získávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w4</LM>
   </w.rf>
   <form>oxidací</form>
   <lemma>oxidace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w5</LM>
   </w.rf>
   <form>anorganických</form>
   <lemma>anorganický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w6</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w7</LM>
   </w.rf>
   <form>vodík</form>
   <lemma>vodík</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w8</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w9</LM>
   </w.rf>
   <form>CO</form>
   <lemma>CO_;U_^(kysličník_uhelnatý)</lemma>
   <tag>BNIXX-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w10</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w11</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w12</LM>
   </w.rf>
   <form>jednoduchých</form>
   <lemma>jednoduchý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w13</LM>
   </w.rf>
   <form>organických</form>
   <lemma>organický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w14</LM>
   </w.rf>
   <form>sloučenin</form>
   <lemma>sloučenina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w15</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w16</LM>
   </w.rf>
   <form>kyselina</form>
   <lemma>kyselina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w17</LM>
   </w.rf>
   <form>mravenčí</form>
   <lemma>mravenčí</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w18</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w19</LM>
   </w.rf>
   <form>vyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w20</LM>
   </w.rf>
   <form>mastné</form>
   <lemma>mastný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w21</LM>
   </w.rf>
   <form>kyseliny</form>
   <lemma>kyselina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w23</LM>
   </w.rf>
   <form>alkoholy</form>
   <lemma>alkohol</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w24</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w25</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w26</LM>
   </w.rf>
   <form>metan</form>
   <lemma>metan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s3w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s3w27</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p4s4">
  <m id="m-vesm9303-037-p4s4w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w1</LM>
   </w.rf>
   <form>Většina</form>
   <lemma>většina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w2</LM>
   </w.rf>
   <form>druhů</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w3</LM>
   </w.rf>
   <form>metanových</form>
   <lemma>metanový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w4</LM>
   </w.rf>
   <form>baktérií</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w5</LM>
   </w.rf>
   <form>vykazuje</form>
   <lemma>vykazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w6</LM>
   </w.rf>
   <form>substrátovou</form>
   <lemma>substrátový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w7</LM>
   </w.rf>
   <form>specifitu</form>
   <lemma>specifita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w8</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w9</LM>
   </w.rf>
   <form>určitý</form>
   <lemma>určitý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w10</LM>
   </w.rf>
   <form>druh</form>
   <lemma>druh-1_^(typ)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w11</LM>
   </w.rf>
   <form>využívá</form>
   <lemma>využívat_^(*3t)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w12</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w13</LM>
   </w.rf>
   <form>určitý</form>
   <lemma>určitý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w14</LM>
   </w.rf>
   <form>substrát</form>
   <lemma>substrát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w15</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p4s4w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p4s4w16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p5s1">
  <m id="m-vesm9303-037-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w1</LM>
   </w.rf>
   <form>Metanové</form>
   <lemma>metanový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w2</LM>
   </w.rf>
   <form>baktérie</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w3</LM>
   </w.rf>
   <form>žijí</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w4</LM>
   </w.rf>
   <form>např</form>
   <lemma>například</lemma>
   <tag>TT------------b</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w7</LM>
   </w.rf>
   <form>spodních</form>
   <lemma>spodní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w8</LM>
   </w.rf>
   <form>vrstvách</form>
   <lemma>vrstva</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w9</LM>
   </w.rf>
   <form>bažin</form>
   <lemma>bažina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w11</LM>
   </w.rf>
   <form>močálů</form>
   <lemma>močál</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w12</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w14</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w16</LM>
   </w.rf>
   <form>zažívacím</form>
   <lemma>zažívací_^(*2t)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w17</LM>
   </w.rf>
   <form>traktu</form>
   <lemma>trakt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w18</LM>
   </w.rf>
   <form>přežvýkavců</form>
   <lemma>přežvýkavec</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w19</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w20</LM>
   </w.rf>
   <form>krávy</form>
   <lemma>kráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w22</LM>
   </w.rf>
   <form>ovce</form>
   <lemma>ovce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w24</LM>
   </w.rf>
   <form>kozy</form>
   <lemma>koza</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w25</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w26</LM>
   </w.rf>
   <form>velblouda</form>
   <lemma>velbloud</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w28</LM>
   </w.rf>
   <form>žirafy</form>
   <lemma>žirafa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w29</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w30</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w31</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w32</LM>
   </w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w33</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w34</LM>
   </w.rf>
   <form>viz</form>
   <lemma>viz_^(odkaz_na_jiné_místo)</lemma>
   <tag>Vi-S---2--A-P-1</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w35</LM>
   </w.rf>
   <form>Vesmír</form>
   <lemma>vesmír</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w36</LM>
   </w.rf>
   <form>67</form>
   <lemma>67</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w37</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w38</LM>
   </w.rf>
   <form>108</form>
   <lemma>108</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w39</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w40</LM>
   </w.rf>
   <form>1988</form>
   <lemma>1988</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w41</LM>
   </w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w42</LM>
   </w.rf>
   <form>2</form>
   <lemma>2</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w43</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s1w44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s1w44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p5s2">
  <m id="m-vesm9303-037-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w2</LM>
   </w.rf>
   <form>krávy</form>
   <lemma>kráva</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w3</LM>
   </w.rf>
   <form>vytvářejí</form>
   <lemma>vytvářet</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w4</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w5</LM>
   </w.rf>
   <form>100</form>
   <lemma>100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w6</LM>
   </w.rf>
   <form>litrů</form>
   <lemma>litr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w7</LM>
   </w.rf>
   <form>metanu</form>
   <lemma>metan</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w8</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9303-037-p5s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p5s2w9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p6s1">
  <m id="m-vesm9303-037-p6s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w1</LM>
   </w.rf>
   <form>Praktické</form>
   <lemma>praktický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w2</LM>
   </w.rf>
   <form>využití</form>
   <lemma>využití_^(*3ít)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w3</LM>
   </w.rf>
   <form>metanového</form>
   <lemma>metanový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w4</LM>
   </w.rf>
   <form>kvašení</form>
   <lemma>kvašení_^(*4sit)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w5</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w6</LM>
   </w.rf>
   <form>odpadní</form>
   <lemma>odpadní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w7</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w9</LM>
   </w.rf>
   <form>zkvašovány</form>
   <lemma>zkvašovat</lemma>
   <tag>VsTP----X-API--</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w11</LM>
   </w.rf>
   <form>vznikající</form>
   <lemma>vznikající_^(*4t)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w12</LM>
   </w.rf>
   <form>zápalný</form>
   <lemma>zápalný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w13</LM>
   </w.rf>
   <form>plyn</form>
   <lemma>plyn</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w14</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w15</LM>
   </w.rf>
   <form>obsahující</form>
   <lemma>obsahující_^(*5ovat)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w16</LM>
   </w.rf>
   <form>převážně</form>
   <lemma>převážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w17</LM>
   </w.rf>
   <form>metan</form>
   <lemma>metan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w18</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w20</LM>
   </w.rf>
   <form>zachycován</form>
   <lemma>zachycovat</lemma>
   <tag>VsYS----X-API--</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w22</LM>
   </w.rf>
   <form>použit</form>
   <lemma>použít</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w23</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w24</LM>
   </w.rf>
   <form>svítiplyn</form>
   <lemma>svítiplyn</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w25</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w26</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w27</LM>
   </w.rf>
   <form>substrát</form>
   <lemma>substrát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w28</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w29</LM>
   </w.rf>
   <form>růst</form>
   <lemma>růst-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w30</LM>
   </w.rf>
   <form>dalších</form>
   <lemma>další</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w31</LM>
   </w.rf>
   <form>mikroorganismů</form>
   <lemma>mikroorganismus_,s_^(^DD**mikroorganizmus)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w32</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w33</LM>
   </w.rf>
   <form>tzv</form>
   <lemma>takzvaný</lemma>
   <tag>AAXXX----1A---b</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w34</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w35</LM>
   </w.rf>
   <form>metanotrofních</form>
   <lemma>metanotrofní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w36</LM>
   </w.rf>
   <form>baktérií</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s1w37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s1w37</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p6s2">
  <m id="m-vesm9303-037-p6s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w1</LM>
   </w.rf>
   <form>Průmyslově</form>
   <lemma>průmyslově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w2</LM>
   </w.rf>
   <form>připravené</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w3</LM>
   </w.rf>
   <form>metanotrofní</form>
   <lemma>metanotrofní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w4</LM>
   </w.rf>
   <form>baktérie</form>
   <lemma>baktérie_,s_^(^DD**bakterie)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w6</LM>
   </w.rf>
   <form>uplatňují</form>
   <lemma>uplatňovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w7</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w8</LM>
   </w.rf>
   <form>zdroje</form>
   <lemma>zdroj</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w9</LM>
   </w.rf>
   <form>krmných</form>
   <lemma>krmný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w10</LM>
   </w.rf>
   <form>bílkovin</form>
   <lemma>bílkovina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p6s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p6s2w11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9303-037-p7s1">
  <m id="m-vesm9303-037-p7s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w1</LM>
   </w.rf>
   <form>RNDr</form>
   <lemma>RNDr_^(doktor_přír._věd)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w3</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w4</LM>
   </w.rf>
   <form>Řeháček</form>
   <lemma>Řeháček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w6</LM>
   </w.rf>
   <form>DrSc</form>
   <lemma>DrSc_^(doktor_věd)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9303-037-p7s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9303-037-p7s1w7</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
