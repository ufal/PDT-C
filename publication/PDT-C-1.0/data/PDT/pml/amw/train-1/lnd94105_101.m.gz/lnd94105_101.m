<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lnd94105_101.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-lnd94105-101-p1s1">
  <m id="m-lnd94105-101-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-101-p1s1w1</LM>
   </w.rf>
   <form>Uhodli</form>
   <lemma>uhodnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m-lnd94105-101-p1s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-101-p1s1w2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m-lnd94105-101-p1s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-101-p1s1w3</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-lnd94105-101-p1s5">
  <m id="m-lnd94105-101-p1s5w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-101-p1s5w1</LM>
   </w.rf>
   <form>Olomouc</form>
   <lemma>Olomouc_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-lnd94105-101-p1s5w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-lnd94105-101-p1s5w2</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
