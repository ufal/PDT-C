<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="mf920901_090.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-mf920901-090-p1s1">
  <m id="m-mf920901-090-p1s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920901-090-p1s1w1</LM>
   </w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920901-090-p2s1">
  <m id="m-mf920901-090-p2s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920901-090-p2s1w1</LM>
   </w.rf>
   <form>RAKOUSKO</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
 </s>
 <s id="m-mf920901-090-p3s1">
  <m id="m-mf920901-090-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920901-090-p3s1w1</LM>
   </w.rf>
   <form>FS</form>
   <lemma>FS-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-mf920901-090-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-mf920901-090-p3s1w2</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
 </s>
</mdata>
