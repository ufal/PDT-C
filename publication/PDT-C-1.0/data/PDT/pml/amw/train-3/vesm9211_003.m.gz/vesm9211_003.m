<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="vesm9211_003.w.gz" />
  </references>
 </head>
 <meta>
  <lang>cs</lang>
  <annotation_info id="manual">
   <desc>Manual annotation</desc>
  </annotation_info>
 </meta>
 <s id="m-vesm9211-003-p1s1A">
  <m id="m-vesm9211-003-p1s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw1</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw4</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw5</LM>
   </w.rf>
   <form>četbě</form>
   <lemma>četba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw6</LM>
   </w.rf>
   <form>článku</form>
   <lemma>článek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw7</LM>
   </w.rf>
   <form>J</form>
   <lemma>J-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw9</LM>
   </w.rf>
   <form>Bednářové</form>
   <lemma>Bednářová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw10</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw11</LM>
   </w.rf>
   <form>Pouštní</form>
   <lemma>pouštní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw13</LM>
   </w.rf>
   <form>skalní</form>
   <lemma>skalní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw14</LM>
   </w.rf>
   <form>laky</form>
   <lemma>lak</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw15</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw16</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw17</LM>
   </w.rf>
   <form>Vesmír</form>
   <lemma>vesmír</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw18</LM>
   </w.rf>
   <form>71</form>
   <lemma>71</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw19</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw20</LM>
   </w.rf>
   <form>398</form>
   <lemma>398</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw21</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw22</LM>
   </w.rf>
   <form>1992</form>
   <lemma>1992</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw23</LM>
   </w.rf>
   <form>/</form>
   <lemma>/</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw24</LM>
   </w.rf>
   <form>7</form>
   <lemma>7</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw25</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw26</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw27</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw28</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw29</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw30</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw31</LM>
   </w.rf>
   <form>nepěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw32</LM>
   </w.rf>
   <form>překvapila</form>
   <lemma>překvapit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw33</LM>
   </w.rf>
   <form>věta</form>
   <lemma>věta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw34</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw35</LM>
   </w.rf>
   <form>Nejčastěji</form>
   <lemma>často</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw36</LM>
   </w.rf>
   <form>dochází</form>
   <lemma>docházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw37</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw38</LM>
   </w.rf>
   <form>zátekům</form>
   <lemma>zátek</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw39</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw40</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw41</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw42</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw43</LM>
   </w.rf>
   <form>drobných</form>
   <lemma>drobný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw44">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw45">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw45</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw46">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw46</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Aw47">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Aw47</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p1s1B">
  <m id="m-vesm9211-003-p1s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw3</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw5</LM>
   </w.rf>
   <form>nejhroznějších</form>
   <lemma>hrozný</lemma>
   <tag>AAIP2----3A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw6</LM>
   </w.rf>
   <form>příkladů</form>
   <lemma>příklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw7</LM>
   </w.rf>
   <form>použití</form>
   <lemma>použití_^(*3ít)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw8</LM>
   </w.rf>
   <form>vazby</form>
   <lemma>vazba_^(všechny_významy)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw10</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw11</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw12</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw14</LM>
   </w.rf>
   <form>něčemu</form>
   <lemma>něco</lemma>
   <tag>PK--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw15</LM>
   </w.rf>
   <form>dochází</form>
   <lemma>docházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p1s1Bw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s1Bw16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p1s2">
  <m id="m-vesm9211-003-p1s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s2w1</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s2w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p1s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p1s2w3</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p2s1A">
  <m id="m-vesm9211-003-p2s1Aw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw1</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw2</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw4</LM>
   </w.rf>
   <form>akademika</form>
   <lemma>akademik</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw5</LM>
   </w.rf>
   <form>Kurze</form>
   <lemma>Kurz-1_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw6</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw7</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw9</LM>
   </w.rf>
   <form>publikacích</form>
   <lemma>publikace</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw10</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP6----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw11</LM>
   </w.rf>
   <form>žáků</form>
   <lemma>žák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw12</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw13</LM>
   </w.rf>
   <form>ohavnou</form>
   <lemma>ohavný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw14</LM>
   </w.rf>
   <form>vazbu</form>
   <lemma>vazba_^(všechny_významy)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw15</LM>
   </w.rf>
   <form>nekompromisně</form>
   <lemma>kompromisně_^(*1í)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw16</LM>
   </w.rf>
   <form>stíhal</form>
   <lemma>stíhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw18</LM>
   </w.rf>
   <form>říkával</form>
   <lemma>říkávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw19</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw20</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw21</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw22</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw23</LM>
   </w.rf>
   <form>říkat</form>
   <lemma>říkat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw24</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw25</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw27</LM>
   </w.rf>
   <form>Jeníček</form>
   <lemma>Jeníček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw28</LM>
   </w.rf>
   <form>počůral</form>
   <lemma>počůrat_,h</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw29</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw30</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw31">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw31</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw32">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw32</LM>
   </w.rf>
   <form>lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw33">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw33</LM>
   </w.rf>
   <form>znít</form>
   <lemma>znít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw34">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw34</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw35">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw35</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw36">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw36</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw37">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw37</LM>
   </w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw38">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw38</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw39">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw39</LM>
   </w.rf>
   <form>počůrání</form>
   <lemma>počůrání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw40">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw40</LM>
   </w.rf>
   <form>Jeníčka</form>
   <lemma>Jeníček_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw41">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw41</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw42">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Aw43">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Aw43</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p2s1B">
  <m id="m-vesm9211-003-p2s1Bw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw1</LM>
   </w.rf>
   <form>Této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw2</LM>
   </w.rf>
   <form>nepěkné</form>
   <lemma>pěkný</lemma>
   <tag>AAFS2----1N----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw3</LM>
   </w.rf>
   <form>vazby</form>
   <lemma>vazba_^(všechny_významy)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw4</LM>
   </w.rf>
   <form>nacházíme</form>
   <lemma>nacházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw6</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP6-P1-------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw7</LM>
   </w.rf>
   <form>vědeckých</form>
   <lemma>vědecký</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw8</LM>
   </w.rf>
   <form>publikacích</form>
   <lemma>publikace</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw9</LM>
   </w.rf>
   <form>spousty</form>
   <lemma>spousta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Bw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Bw10</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p2s1C">
  <m id="m-vesm9211-003-p2s1Cw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw3</LM>
   </w.rf>
   <form>insulinu</form>
   <lemma>insulin_,s_^(^DD**inzulín)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw4</LM>
   </w.rf>
   <form>dochází</form>
   <lemma>docházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw6</LM>
   </w.rf>
   <form>poklesu</form>
   <lemma>pokles</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw7</LM>
   </w.rf>
   <form>glykemie</form>
   <lemma>glykemie_,s_^(^DD**glykémie)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Cw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Cw9</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p2s1D">
  <m id="m-vesm9211-003-p2s1Dw1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw1</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw2</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw3</LM>
   </w.rf>
   <form>infekčních</form>
   <lemma>infekční</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw4</LM>
   </w.rf>
   <form>onemocněních</form>
   <lemma>onemocnění_^(*2t)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw5</LM>
   </w.rf>
   <form>dochází</form>
   <lemma>docházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw7</LM>
   </w.rf>
   <form>vzestupu</form>
   <lemma>vzestup</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw8</LM>
   </w.rf>
   <form>sedimentace</form>
   <lemma>sedimentace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw9</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p2s1Dw10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p2s1Dw10</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p3s1">
  <m id="m-vesm9211-003-p3s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w1</LM>
   </w.rf>
   <form>Snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m-vesm9211-003-p3s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w3</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w4</LM>
   </w.rf>
   <form>připomínku</form>
   <lemma>připomínka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w5</LM>
   </w.rf>
   <form>nezazlíte</form>
   <lemma>zazlít</lemma>
   <tag>VB-P---2P-NAP--</tag>
  </m>
  <m id="m-vesm9211-003-p3s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s1w6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p3s2">
  <m id="m-vesm9211-003-p3s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w2</LM>
   </w.rf>
   <form>Vesmír</form>
   <lemma>vesmír</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w3</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w4</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w6</LM>
   </w.rf>
   <form>čtu</form>
   <lemma>číst</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w8</LM>
   </w.rf>
   <form>něm</form>
   <lemma>on-1</lemma>
   <tag>PEZS6--3-------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w9</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w10</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w11">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w14</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w15</LM>
   </w.rf>
   <form>mne</form>
   <lemma>já</lemma>
   <tag>PP-S4--1-------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w16</LM>
   </w.rf>
   <form>jakási</form>
   <lemma>jakýsi</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w17</LM>
   </w.rf>
   <form>obdoba</form>
   <lemma>obdoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w18</LM>
   </w.rf>
   <form>Scientific</form>
   <lemma>Scientific-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w19</LM>
   </w.rf>
   <form>American</form>
   <lemma>American-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w21</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w22</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w23">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w24">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w24</LM>
   </w.rf>
   <form>celkové</form>
   <lemma>celkový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w25">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w25</LM>
   </w.rf>
   <form>úrovni</form>
   <lemma>úroveň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w26">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w26</LM>
   </w.rf>
   <form>časopisu</form>
   <lemma>časopis</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w27">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w27</LM>
   </w.rf>
   <form>dává</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w28">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w28</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w29">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w29</LM>
   </w.rf>
   <form>záležet</form>
   <lemma>záležet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-003-p3s2w30">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s2w30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p3s3">
  <m id="m-vesm9211-003-p3s3w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w4</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w5</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w6</LM>
   </w.rf>
   <form>Vesmír</form>
   <lemma>vesmír</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w7</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w8</LM>
   </w.rf>
   <form>starost</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w9</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w10</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w12">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w12</LM>
   </w.rf>
   <form>nejen</form>
   <lemma>nejen</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w13">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w13</LM>
   </w.rf>
   <form>vědecky</form>
   <lemma>vědecky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w14">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w14</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w15">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w15</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w16">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w16</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w17">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w17</LM>
   </w.rf>
   <form>jazykově</form>
   <lemma>jazykově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w18">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w18</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w19">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w19</LM>
   </w.rf>
   <form>plně</form>
   <lemma>plně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w20">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w21">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w21</LM>
   </w.rf>
   <form>výši</form>
   <lemma>výše_^(velikost_apod.;_též_tlaková_výše)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p3s3w22">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p3s3w22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p4s1">
  <m id="m-vesm9211-003-p4s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p4s1w1</LM>
   </w.rf>
   <form>Prof</form>
   <lemma>prof_^(profesor)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p4s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p4s1w2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p4s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p4s1w3</LM>
   </w.rf>
   <form>J</form>
   <lemma>J-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m-vesm9211-003-p4s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p4s1w4</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m-vesm9211-003-p4s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p4s1w5</LM>
   </w.rf>
   <form>Hořejší</form>
   <lemma>Hořejší_;Y</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p5s1">
  <m id="m-vesm9211-003-p5s1w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w2">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w2</LM>
   </w.rf>
   <form>téma</form>
   <lemma>téma</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w3">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w4">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w4</LM>
   </w.rf>
   <form>probírá</form>
   <lemma>probírat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w5">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w6">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w6</LM>
   </w.rf>
   <form>jazykovém</form>
   <lemma>jazykový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w7">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w7</LM>
   </w.rf>
   <form>koutku</form>
   <lemma>koutek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w8">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w8</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w9">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w9</LM>
   </w.rf>
   <form>čísla</form>
   <lemma>číslo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m-vesm9211-003-p5s1w10">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s1w10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m-vesm9211-003-p5s2">
  <m id="m-vesm9211-003-p5s2w1">
   <src.rf>manual</src.rf>
   <w.rf>
    <LM>w#w-vesm9211-003-p5s2w1</LM>
   </w.rf>
   <form>Redakce</form>
   <lemma>redakce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
 </s>
</mdata>
