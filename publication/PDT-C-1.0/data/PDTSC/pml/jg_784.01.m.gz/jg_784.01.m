<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_784.01.w.gz" />
  </references>
 </head>
 <s id="m784-27638_04-d1e381-x2">
  <m id="m784-d1t384-1">
   <w.rf>
    <LM>w#w-d1t384-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e381-x2-3563">
   <w.rf>
    <LM>w#w-d1e381-x2-3563</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t395-1">
   <w.rf>
    <LM>w#w-d1t395-1</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e381-x2-3781">
   <w.rf>
    <LM>w#w-d1e381-x2-3781</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t395-2">
   <w.rf>
    <LM>w#w-d1t395-2</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t395-3">
   <w.rf>
    <LM>w#w-d1t395-3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m784-d1t395-4">
   <w.rf>
    <LM>w#w-d1t395-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m784-d1t395-5">
   <w.rf>
    <LM>w#w-d1t395-5</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP6----------</tag>
  </m>
  <m id="m784-d1t395-6">
   <w.rf>
    <LM>w#w-d1t395-6</LM>
   </w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t395-7">
   <w.rf>
    <LM>w#w-d1t395-7</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m784-d1t401-1">
   <w.rf>
    <LM>w#w-d1t401-1</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t401-2">
   <w.rf>
    <LM>w#w-d1t401-2</LM>
   </w.rf>
   <form>nastoupit</form>
   <lemma>nastoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t401-3">
   <w.rf>
    <LM>w#w-d1t401-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t401-4">
   <w.rf>
    <LM>w#w-d1t401-4</LM>
   </w.rf>
   <form>třídu</form>
   <lemma>třída</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t401-5">
   <w.rf>
    <LM>w#w-d1t401-5</LM>
   </w.rf>
   <form>D</form>
   <lemma>D-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m784-d1t401-6">
   <w.rf>
    <LM>w#w-d1t401-6</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d-id67278">
   <w.rf>
    <LM>w#w-d-id67278</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t403-1">
   <w.rf>
    <LM>w#w-d1t403-1</LM>
   </w.rf>
   <form>nevyučený</form>
   <lemma>vyučený_^(*3it)</lemma>
   <tag>AAMS1----1N----</tag>
  </m>
  <m id="m784-d1e381-x2-1075">
   <w.rf>
    <LM>w#w-d1e381-x2-1075</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1076">
  <m id="m784-d1t405-3">
   <w.rf>
    <LM>w#w-d1t405-3</LM>
   </w.rf>
   <form>Šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t405-2">
   <w.rf>
    <LM>w#w-d1t405-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m784-d1t405-4">
   <w.rf>
    <LM>w#w-d1t405-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t405-5">
   <w.rf>
    <LM>w#w-d1t405-5</LM>
   </w.rf>
   <form>platem</form>
   <lemma>plat_^(mzda)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m784-d1t405-6">
   <w.rf>
    <LM>w#w-d1t405-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t405-7">
   <w.rf>
    <LM>w#w-d1t405-7</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m784-d1t405-8">
   <w.rf>
    <LM>w#w-d1t405-8</LM>
   </w.rf>
   <form>stovek</form>
   <lemma>stovka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-d1t405-9">
   <w.rf>
    <LM>w#w-d1t405-9</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t405-10">
   <w.rf>
    <LM>w#w-d1t405-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t405-11">
   <w.rf>
    <LM>w#w-d1t405-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t405-12">
   <w.rf>
    <LM>w#w-d1t405-12</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t405-13">
   <w.rf>
    <LM>w#w-d1t405-13</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t405-14">
   <w.rf>
    <LM>w#w-d1t405-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t405-15">
   <w.rf>
    <LM>w#w-d1t405-15</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m784-d1t405-17">
   <w.rf>
    <LM>w#w-d1t405-17</LM>
   </w.rf>
   <form>nehodilo</form>
   <lemma>hodit-2_^(bude_se_hodit)</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m784-d-id67577">
   <w.rf>
    <LM>w#w-d-id67577</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e406-x2">
  <m id="m784-d1t409-2">
   <w.rf>
    <LM>w#w-d1t409-2</LM>
   </w.rf>
   <form>Neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t409-3">
   <w.rf>
    <LM>w#w-d1t409-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t411-1">
   <w.rf>
    <LM>w#w-d1t411-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t411-2">
   <w.rf>
    <LM>w#w-d1t411-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t411-3">
   <w.rf>
    <LM>w#w-d1t411-3</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m784-d1t411-4">
   <w.rf>
    <LM>w#w-d1t411-4</LM>
   </w.rf>
   <form>jinou</form>
   <lemma>jiný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d1t411-5">
   <w.rf>
    <LM>w#w-d1t411-5</LM>
   </w.rf>
   <form>funkci</form>
   <lemma>funkce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t411-6">
   <w.rf>
    <LM>w#w-d1t411-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t411-7">
   <w.rf>
    <LM>w#w-d1t411-7</LM>
   </w.rf>
   <form>dělnickou</form>
   <lemma>dělnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d-id67759">
   <w.rf>
    <LM>w#w-d-id67759</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e412-x2">
  <m id="m784-d1t415-6">
   <w.rf>
    <LM>w#w-d1t415-6</LM>
   </w.rf>
   <form>Absolvoval</form>
   <lemma>absolvovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m784-d1t415-5">
   <w.rf>
    <LM>w#w-d1t415-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t417-2">
   <w.rf>
    <LM>w#w-d1t417-2</LM>
   </w.rf>
   <form>mistrovskou</form>
   <lemma>mistrovský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d1t417-3">
   <w.rf>
    <LM>w#w-d1t417-3</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e412-x2-4050">
   <w.rf>
    <LM>w#w-d1e412-x2-4050</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t417-5">
   <w.rf>
    <LM>w#w-d1t417-5</LM>
   </w.rf>
   <form>třech</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m784-d1t417-6">
   <w.rf>
    <LM>w#w-d1t417-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m784-d1e412-x2-1082">
   <w.rf>
    <LM>w#w-d1e412-x2-1082</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1083">
  <m id="m784-d1t419-6">
   <w.rf>
    <LM>w#w-d1t419-6</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t419-7">
   <w.rf>
    <LM>w#w-d1t419-7</LM>
   </w.rf>
   <form>Přelouči</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t419-5">
   <w.rf>
    <LM>w#w-d1t419-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t419-8">
   <w.rf>
    <LM>w#w-d1t419-8</LM>
   </w.rf>
   <form>působil</form>
   <lemma>působit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t419-9">
   <w.rf>
    <LM>w#w-d1t419-9</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t419-10">
   <w.rf>
    <LM>w#w-d1t419-10</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t419-11">
   <w.rf>
    <LM>w#w-d1t419-11</LM>
   </w.rf>
   <form>1959</form>
   <lemma>1959</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e412-x2-4056">
   <w.rf>
    <LM>w#w-d1e412-x2-4056</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-1083-1084">
   <w.rf>
    <LM>w#w-1083-1084</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m784-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>1959</form>
   <lemma>1959</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t426-5">
   <w.rf>
    <LM>w#w-d1t426-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t426-6">
   <w.rf>
    <LM>w#w-d1t426-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e412-x2-4059">
   <w.rf>
    <LM>w#w-d1e412-x2-4059</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t426-8">
   <w.rf>
    <LM>w#w-d1t426-8</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t426-9">
   <w.rf>
    <LM>w#w-d1t426-9</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m784-d-id68438">
   <w.rf>
    <LM>w#w-d-id68438</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t426-14">
   <w.rf>
    <LM>w#w-d1t426-14</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t426-12">
   <w.rf>
    <LM>w#w-d1t426-12</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m784-d1t426-13">
   <w.rf>
    <LM>w#w-d1t426-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t426-15">
   <w.rf>
    <LM>w#w-d1t426-15</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t426-16">
   <w.rf>
    <LM>w#w-d1t426-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t426-17">
   <w.rf>
    <LM>w#w-d1t426-17</LM>
   </w.rf>
   <form>dokladů</form>
   <lemma>doklad</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1e412-x2-1080">
   <w.rf>
    <LM>w#w-d1e412-x2-1080</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1081">
  <m id="m784-d1t419-3">
   <w.rf>
    <LM>w#w-d1t419-3</LM>
   </w.rf>
   <form>Mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t430-3">
   <w.rf>
    <LM>w#w-d1t430-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t430-6">
   <w.rf>
    <LM>w#w-d1t430-6</LM>
   </w.rf>
   <form>nastoupil</form>
   <lemma>nastoupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t430-12">
   <w.rf>
    <LM>w#w-d1t430-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t430-14">
   <w.rf>
    <LM>w#w-d1t430-14</LM>
   </w.rf>
   <form>vzorkovny</form>
   <lemma>vzorkovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t430-15">
   <w.rf>
    <LM>w#w-d1t430-15</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t430-16">
   <w.rf>
    <LM>w#w-d1t430-16</LM>
   </w.rf>
   <form>soustružník</form>
   <lemma>soustružník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e412-x2-4060">
   <w.rf>
    <LM>w#w-d1e412-x2-4060</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4061">
  <m id="m784-d1t432-1">
   <w.rf>
    <LM>w#w-d1t432-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t432-2">
   <w.rf>
    <LM>w#w-d1t432-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t432-3">
   <w.rf>
    <LM>w#w-d1t432-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t432-4">
   <w.rf>
    <LM>w#w-d1t432-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t432-5">
   <w.rf>
    <LM>w#w-d1t432-5</LM>
   </w.rf>
   <form>montáž</form>
   <lemma>montáž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t432-6">
   <w.rf>
    <LM>w#w-d1t432-6</LM>
   </w.rf>
   <form>rozhlasových</form>
   <lemma>rozhlasový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m784-d1t432-7">
   <w.rf>
    <LM>w#w-d1t432-7</LM>
   </w.rf>
   <form>přijímačů</form>
   <lemma>přijímač</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-4061-4077">
   <w.rf>
    <LM>w#w-4061-4077</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t434-1">
   <w.rf>
    <LM>w#w-d1t434-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t434-2">
   <w.rf>
    <LM>w#w-d1t434-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t434-3">
   <w.rf>
    <LM>w#w-d1t434-3</LM>
   </w.rf>
   <form>přešel</form>
   <lemma>přejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t434-4">
   <w.rf>
    <LM>w#w-d1t434-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t434-5">
   <w.rf>
    <LM>w#w-d1t434-5</LM>
   </w.rf>
   <form>technologie</form>
   <lemma>technologie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t436-1">
   <w.rf>
    <LM>w#w-d1t436-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t436-2">
   <w.rf>
    <LM>w#w-d1t436-2</LM>
   </w.rf>
   <form>technolog</form>
   <lemma>technolog</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-4061-4079">
   <w.rf>
    <LM>w#w-4061-4079</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t439-1">
   <w.rf>
    <LM>w#w-d1t439-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t439-2">
   <w.rf>
    <LM>w#w-d1t439-2</LM>
   </w.rf>
   <form>určitou</form>
   <lemma>určitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d1t439-3">
   <w.rf>
    <LM>w#w-d1t439-3</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t439-4">
   <w.rf>
    <LM>w#w-d1t439-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m784-d1t439-5">
   <w.rf>
    <LM>w#w-d1t439-5</LM>
   </w.rf>
   <form>přemístili</form>
   <lemma>přemístit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t439-6">
   <w.rf>
    <LM>w#w-d1t439-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t439-7">
   <w.rf>
    <LM>w#w-d1t439-7</LM>
   </w.rf>
   <form>odborného</form>
   <lemma>odborný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m784-d1t439-8">
   <w.rf>
    <LM>w#w-d1t439-8</LM>
   </w.rf>
   <form>učiliště</form>
   <lemma>učiliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t439-9">
   <w.rf>
    <LM>w#w-d1t439-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t439-10">
   <w.rf>
    <LM>w#w-d1t439-10</LM>
   </w.rf>
   <form>mistra</form>
   <lemma>mistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1t439-11">
   <w.rf>
    <LM>w#w-d1t439-11</LM>
   </w.rf>
   <form>výrobního</form>
   <lemma>výrobní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m784-d1t439-12">
   <w.rf>
    <LM>w#w-d1t439-12</LM>
   </w.rf>
   <form>výcviku</form>
   <lemma>výcvik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t439-13">
   <w.rf>
    <LM>w#w-d1t439-13</LM>
   </w.rf>
   <form>oboru</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t439-14">
   <w.rf>
    <LM>w#w-d1t439-14</LM>
   </w.rf>
   <form>frézař</form>
   <lemma>frézař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-4061-4080">
   <w.rf>
    <LM>w#w-4061-4080</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4081">
  <m id="m784-d1t445-3">
   <w.rf>
    <LM>w#w-d1t445-3</LM>
   </w.rf>
   <form>Pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t445-4">
   <w.rf>
    <LM>w#w-d1t445-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t445-5">
   <w.rf>
    <LM>w#w-d1t445-5</LM>
   </w.rf>
   <form>Tesle</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t445-6">
   <w.rf>
    <LM>w#w-d1t445-6</LM>
   </w.rf>
   <form>Přelouči</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t445-2">
   <w.rf>
    <LM>w#w-d1t445-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t445-1">
   <w.rf>
    <LM>w#w-d1t445-1</LM>
   </w.rf>
   <form>zakončil</form>
   <lemma>zakončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t445-7">
   <w.rf>
    <LM>w#w-d1t445-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t445-8">
   <w.rf>
    <LM>w#w-d1t445-8</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t445-9">
   <w.rf>
    <LM>w#w-d1t445-9</LM>
   </w.rf>
   <form>1967</form>
   <lemma>1967</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d-id69496">
   <w.rf>
    <LM>w#w-d-id69496</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t447-1">
   <w.rf>
    <LM>w#w-d1t447-1</LM>
   </w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-4081-4161">
   <w.rf>
    <LM>w#w-4081-4161</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t447-2">
   <w.rf>
    <LM>w#w-d1t447-2</LM>
   </w.rf>
   <form>července</form>
   <lemma>červenec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-4081-4163">
   <w.rf>
    <LM>w#w-4081-4163</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t447-4">
   <w.rf>
    <LM>w#w-d1t447-4</LM>
   </w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-4081-4165">
   <w.rf>
    <LM>w#w-4081-4165</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t447-5">
   <w.rf>
    <LM>w#w-d1t447-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t447-6">
   <w.rf>
    <LM>w#w-d1t447-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t447-7">
   <w.rf>
    <LM>w#w-d1t447-7</LM>
   </w.rf>
   <form>ženil</form>
   <lemma>ženit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-4081-4168">
   <w.rf>
    <LM>w#w-4081-4168</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t449-2">
   <w.rf>
    <LM>w#w-d1t449-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t452-1">
   <w.rf>
    <LM>w#w-d1t452-1</LM>
   </w.rf>
   <form>končil</form>
   <lemma>končit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t452-2">
   <w.rf>
    <LM>w#w-d1t452-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t452-5">
   <w.rf>
    <LM>w#w-d1t452-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t452-6">
   <w.rf>
    <LM>w#w-d1t452-6</LM>
   </w.rf>
   <form>technik</form>
   <lemma>technik</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t456-1">
   <w.rf>
    <LM>w#w-d1t456-1</LM>
   </w.rf>
   <form>technologického</form>
   <lemma>technologický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m784-d1t456-2">
   <w.rf>
    <LM>w#w-d1t456-2</LM>
   </w.rf>
   <form>vývoje</form>
   <lemma>vývoj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d-id69822">
   <w.rf>
    <LM>w#w-d-id69822</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e412-x3">
  <m id="m784-d1t462-3">
   <w.rf>
    <LM>w#w-d1t462-3</LM>
   </w.rf>
   <form>Odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t462-4">
   <w.rf>
    <LM>w#w-d1t462-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t462-6">
   <w.rf>
    <LM>w#w-d1t462-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t462-7">
   <w.rf>
    <LM>w#w-d1t462-7</LM>
   </w.rf>
   <form>Třemošnice</form>
   <lemma>Třemošnice_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t462-8">
   <w.rf>
    <LM>w#w-d1t462-8</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t462-9">
   <w.rf>
    <LM>w#w-d1t462-9</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t465-1">
   <w.rf>
    <LM>w#w-d1t465-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t465-2">
   <w.rf>
    <LM>w#w-d1t465-2</LM>
   </w.rf>
   <form>dělník</form>
   <lemma>dělník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1e412-x3-4229">
   <w.rf>
    <LM>w#w-d1e412-x3-4229</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t465-3">
   <w.rf>
    <LM>w#w-d1t465-3</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t465-7">
   <w.rf>
    <LM>w#w-d1t465-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t465-5">
   <w.rf>
    <LM>w#w-d1t465-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t465-6">
   <w.rf>
    <LM>w#w-d1t465-6</LM>
   </w.rf>
   <form>stavěl</form>
   <lemma>stavět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t465-8">
   <w.rf>
    <LM>w#w-d1t465-8</LM>
   </w.rf>
   <form>družstevně</form>
   <lemma>družstevně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t465-9">
   <w.rf>
    <LM>w#w-d1t465-9</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1e412-x3-4231">
   <w.rf>
    <LM>w#w-d1e412-x3-4231</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t467-1">
   <w.rf>
    <LM>w#w-d1t467-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m784-d1t467-2">
   <w.rf>
    <LM>w#w-d1t467-2</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m784-d1t467-4">
   <w.rf>
    <LM>w#w-d1t467-4</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t467-5">
   <w.rf>
    <LM>w#w-d1t467-5</LM>
   </w.rf>
   <form>bydlím</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d-id69830">
   <w.rf>
    <LM>w#w-d-id69830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e472-x2">
  <m id="m784-d1t475-1">
   <w.rf>
    <LM>w#w-d1t475-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t475-2">
   <w.rf>
    <LM>w#w-d1t475-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t475-3">
   <w.rf>
    <LM>w#w-d1t475-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t475-4">
   <w.rf>
    <LM>w#w-d1t475-4</LM>
   </w.rf>
   <form>dověděl</form>
   <lemma>dovědět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t477-1">
   <w.rf>
    <LM>w#w-d1t477-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t477-2">
   <w.rf>
    <LM>w#w-d1t477-2</LM>
   </w.rf>
   <form>Přelouči</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t477-3">
   <w.rf>
    <LM>w#w-d1t477-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t477-4">
   <w.rf>
    <LM>w#w-d1t477-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m784-d-id70454">
   <w.rf>
    <LM>w#w-d-id70454</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t477-6">
   <w.rf>
    <LM>w#w-d1t477-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t477-7">
   <w.rf>
    <LM>w#w-d1t477-7</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t477-9">
   <w.rf>
    <LM>w#w-d1t477-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t477-10">
   <w.rf>
    <LM>w#w-d1t477-10</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t477-11">
   <w.rf>
    <LM>w#w-d1t477-11</LM>
   </w.rf>
   <form>získat</form>
   <lemma>získat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t477-12">
   <w.rf>
    <LM>w#w-d1t477-12</LM>
   </w.rf>
   <form>bydlení</form>
   <lemma>bydlení_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e472-x2-4268">
   <w.rf>
    <LM>w#w-d1e472-x2-4268</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e478-x2">
  <m id="m784-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m784-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m784-d1t481-5">
   <w.rf>
    <LM>w#w-d1t481-5</LM>
   </w.rf>
   <form>náhoda</form>
   <lemma>náhoda_^(př._s_takovou_n._jsem_počítal,_n._tomu_chtěla)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1e478-x2-4429">
   <w.rf>
    <LM>w#w-d1e478-x2-4429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4430">
  <m id="m784-d1t481-8">
   <w.rf>
    <LM>w#w-d1t481-8</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t481-12">
   <w.rf>
    <LM>w#w-d1t481-12</LM>
   </w.rf>
   <form>zaměstnanec</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t481-13">
   <w.rf>
    <LM>w#w-d1t481-13</LM>
   </w.rf>
   <form>Tesly</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t483-1">
   <w.rf>
    <LM>w#w-d1t483-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t483-2">
   <w.rf>
    <LM>w#w-d1t483-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t483-3">
   <w.rf>
    <LM>w#w-d1t483-3</LM>
   </w.rf>
   <form>zajímal</form>
   <lemma>zajímat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t483-4">
   <w.rf>
    <LM>w#w-d1t483-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t483-5">
   <w.rf>
    <LM>w#w-d1t483-5</LM>
   </w.rf>
   <form>elektrotechniku</form>
   <lemma>elektrotechnika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e478-x2-4411">
   <w.rf>
    <LM>w#w-d1e478-x2-4411</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t483-6">
   <w.rf>
    <LM>w#w-d1t483-6</LM>
   </w.rf>
   <form>radioamatérské</form>
   <lemma>radioamatérský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t483-7">
   <w.rf>
    <LM>w#w-d1t483-7</LM>
   </w.rf>
   <form>vysílání</form>
   <lemma>vysílání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-4430-1096">
   <w.rf>
    <LM>w#w-4430-1096</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1097">
  <m id="m784-d1t485-2">
   <w.rf>
    <LM>w#w-d1t485-2</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m784-d1t485-3">
   <w.rf>
    <LM>w#w-d1t485-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t485-4">
   <w.rf>
    <LM>w#w-d1t485-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m784-d-id71000">
   <w.rf>
    <LM>w#w-d-id71000</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t485-6">
   <w.rf>
    <LM>w#w-d1t485-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t485-7">
   <w.rf>
    <LM>w#w-d1t485-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t485-8">
   <w.rf>
    <LM>w#w-d1t485-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t485-9">
   <w.rf>
    <LM>w#w-d1t485-9</LM>
   </w.rf>
   <form>kamarádem</form>
   <lemma>kamarád</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m784-d1t485-10">
   <w.rf>
    <LM>w#w-d1t485-10</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t485-11">
   <w.rf>
    <LM>w#w-d1t485-11</LM>
   </w.rf>
   <form>hledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t487-3">
   <w.rf>
    <LM>w#w-d1t487-3</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1e478-x2-4414">
   <w.rf>
    <LM>w#w-d1e478-x2-4414</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t487-4">
   <w.rf>
    <LM>w#w-d1t487-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t487-5">
   <w.rf>
    <LM>w#w-d1t487-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t487-6">
   <w.rf>
    <LM>w#w-d1t487-6</LM>
   </w.rf>
   <form>usídlit</form>
   <lemma>usídlit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t489-1">
   <w.rf>
    <LM>w#w-d1t489-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t489-2">
   <w.rf>
    <LM>w#w-d1t489-2</LM>
   </w.rf>
   <form>odtud</form>
   <lemma>odtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t489-3">
   <w.rf>
    <LM>w#w-d1t489-3</LM>
   </w.rf>
   <form>vysílat</form>
   <lemma>vysílat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t489-4">
   <w.rf>
    <LM>w#w-d1t489-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t489-5">
   <w.rf>
    <LM>w#w-d1t489-5</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m784-d1t489-6">
   <w.rf>
    <LM>w#w-d1t489-6</LM>
   </w.rf>
   <form>kopce</form>
   <lemma>kopec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e478-x2-4419">
   <w.rf>
    <LM>w#w-d1e478-x2-4419</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t489-7">
   <w.rf>
    <LM>w#w-d1t489-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t489-8">
   <w.rf>
    <LM>w#w-d1t489-8</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m784-d1t489-9">
   <w.rf>
    <LM>w#w-d1t489-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t489-10">
   <w.rf>
    <LM>w#w-d1t489-10</LM>
   </w.rf>
   <form>elektrika</form>
   <lemma>elektrika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t489-11">
   <w.rf>
    <LM>w#w-d1t489-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t489-12">
   <w.rf>
    <LM>w#w-d1t489-12</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1e478-x2-4422">
   <w.rf>
    <LM>w#w-d1e478-x2-4422</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t492-1">
   <w.rf>
    <LM>w#w-d1t492-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t492-2">
   <w.rf>
    <LM>w#w-d1t492-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t492-4">
   <w.rf>
    <LM>w#w-d1t492-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t492-5">
   <w.rf>
    <LM>w#w-d1t492-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t492-6">
   <w.rf>
    <LM>w#w-d1t492-6</LM>
   </w.rf>
   <form>kótu</form>
   <lemma>kóta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1t492-7">
   <w.rf>
    <LM>w#w-d1t492-7</LM>
   </w.rf>
   <form>Zbyslavec</form>
   <lemma>Zbyslavec_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d1t494-1">
   <w.rf>
    <LM>w#w-d1t494-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t494-2">
   <w.rf>
    <LM>w#w-d1t494-2</LM>
   </w.rf>
   <form>Míčova</form>
   <lemma>Míčov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-1097-1098">
   <w.rf>
    <LM>w#w-1097-1098</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1099">
  <m id="m784-d1t494-13">
   <w.rf>
    <LM>w#w-d1t494-13</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t494-12">
   <w.rf>
    <LM>w#w-d1t494-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t494-3">
   <w.rf>
    <LM>w#w-d1t494-3</LM>
   </w.rf>
   <form>568</form>
   <lemma>568</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t494-9">
   <w.rf>
    <LM>w#w-d1t494-9</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m784-d1t494-10">
   <w.rf>
    <LM>w#w-d1t494-10</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t494-11">
   <w.rf>
    <LM>w#w-d1t494-11</LM>
   </w.rf>
   <form>mořem</form>
   <lemma>moře</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m784-d-id71722">
   <w.rf>
    <LM>w#w-d-id71722</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e478-x3">
  <m id="m784-d1t502-2">
   <w.rf>
    <LM>w#w-d1t502-2</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t502-1">
   <w.rf>
    <LM>w#w-d1t502-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d-id71865">
   <w.rf>
    <LM>w#w-d-id71865</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t502-4">
   <w.rf>
    <LM>w#w-d1t502-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t502-5">
   <w.rf>
    <LM>w#w-d1t502-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t502-6">
   <w.rf>
    <LM>w#w-d1t502-6</LM>
   </w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m784-d1t502-8">
   <w.rf>
    <LM>w#w-d1t502-8</LM>
   </w.rf>
   <form>přechodně</form>
   <lemma>přechodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t502-7">
   <w.rf>
    <LM>w#w-d1t502-7</LM>
   </w.rf>
   <form>bydlet</form>
   <lemma>bydlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1e478-x3-4623">
   <w.rf>
    <LM>w#w-d1e478-x3-4623</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t502-9">
   <w.rf>
    <LM>w#w-d1t502-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t502-10">
   <w.rf>
    <LM>w#w-d1t502-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t502-11">
   <w.rf>
    <LM>w#w-d1t502-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t502-12">
   <w.rf>
    <LM>w#w-d1t502-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t502-13">
   <w.rf>
    <LM>w#w-d1t502-13</LM>
   </w.rf>
   <form>nastěhoval</form>
   <lemma>nastěhovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1e478-x3-1107">
   <w.rf>
    <LM>w#w-d1e478-x3-1107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1108">
  <m id="m784-d1t502-15">
   <w.rf>
    <LM>w#w-d1t502-15</LM>
   </w.rf>
   <form>Dojížděl</form>
   <lemma>dojíždět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t502-16">
   <w.rf>
    <LM>w#w-d1t502-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t502-17">
   <w.rf>
    <LM>w#w-d1t502-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t502-18">
   <w.rf>
    <LM>w#w-d1t502-18</LM>
   </w.rf>
   <form>Přelouče</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t507-1">
   <w.rf>
    <LM>w#w-d1t507-1</LM>
   </w.rf>
   <form>odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id72105">
   <w.rf>
    <LM>w#w-d-id72105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e478-x4">
  <m id="m784-d1t511-5">
   <w.rf>
    <LM>w#w-d1t511-5</LM>
   </w.rf>
   <form>Seznámil</form>
   <lemma>seznámit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t511-6">
   <w.rf>
    <LM>w#w-d1t511-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t511-7">
   <w.rf>
    <LM>w#w-d1t511-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t511-8">
   <w.rf>
    <LM>w#w-d1t511-8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m784-d1t511-9">
   <w.rf>
    <LM>w#w-d1t511-9</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t511-10">
   <w.rf>
    <LM>w#w-d1t511-10</LM>
   </w.rf>
   <form>jménem</form>
   <lemma>jméno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m784-d1t511-11">
   <w.rf>
    <LM>w#w-d1t511-11</LM>
   </w.rf>
   <form>Jetonice</form>
   <lemma>Jetonice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1t511-12">
   <w.rf>
    <LM>w#w-d1t511-12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t511-13">
   <w.rf>
    <LM>w#w-d1t511-13</LM>
   </w.rf>
   <form>mou</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1------1</tag>
  </m>
  <m id="m784-d1t511-14">
   <w.rf>
    <LM>w#w-d1t511-14</LM>
   </w.rf>
   <form>nynější</form>
   <lemma>nynější</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m784-d1t511-15">
   <w.rf>
    <LM>w#w-d1t511-15</LM>
   </w.rf>
   <form>manželkou</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m784-d1e478-x4-4960">
   <w.rf>
    <LM>w#w-d1e478-x4-4960</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t515-1">
   <w.rf>
    <LM>w#w-d1t515-1</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m784-d1t515-2">
   <w.rf>
    <LM>w#w-d1t515-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t515-3">
   <w.rf>
    <LM>w#w-d1t515-3</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m784-d1e478-x4-4961">
   <w.rf>
    <LM>w#w-d1e478-x4-4961</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t515-4">
   <w.rf>
    <LM>w#w-d1t515-4</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1e478-x4-9179">
   <w.rf>
    <LM>w#w-d1e478-x4-9179</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t515-5">
   <w.rf>
    <LM>w#w-d1t515-5</LM>
   </w.rf>
   <form>zdá</form>
   <lemma>zdát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t515-6">
   <w.rf>
    <LM>w#w-d1t515-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1e478-x4-4963">
   <w.rf>
    <LM>w#w-d1e478-x4-4963</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-4964">
  <m id="m784-d1t522-1">
   <w.rf>
    <LM>w#w-d1t522-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t522-2">
   <w.rf>
    <LM>w#w-d1t522-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t522-3">
   <w.rf>
    <LM>w#w-d1t522-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t522-4">
   <w.rf>
    <LM>w#w-d1t522-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t522-5">
   <w.rf>
    <LM>w#w-d1t522-5</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m784-d1t522-6">
   <w.rf>
    <LM>w#w-d1t522-6</LM>
   </w.rf>
   <form>seznámil</form>
   <lemma>seznámit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-4964-4975">
   <w.rf>
    <LM>w#w-4964-4975</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t522-11">
   <w.rf>
    <LM>w#w-d1t522-11</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t522-8">
   <w.rf>
    <LM>w#w-d1t522-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t522-9">
   <w.rf>
    <LM>w#w-d1t522-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t522-10">
   <w.rf>
    <LM>w#w-d1t522-10</LM>
   </w.rf>
   <form>motorce</form>
   <lemma>motorka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t522-12">
   <w.rf>
    <LM>w#w-d1t522-12</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t522-13">
   <w.rf>
    <LM>w#w-d1t522-13</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t522-14">
   <w.rf>
    <LM>w#w-d1t522-14</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-4964-5212">
   <w.rf>
    <LM>w#w-4964-5212</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t524-1">
   <w.rf>
    <LM>w#w-d1t524-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t524-2">
   <w.rf>
    <LM>w#w-d1t524-2</LM>
   </w.rf>
   <form>kina</form>
   <lemma>kino</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-4964-1113">
   <w.rf>
    <LM>w#w-4964-1113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1114">
  <m id="m784-d1t524-5">
   <w.rf>
    <LM>w#w-d1t524-5</LM>
   </w.rf>
   <form>Viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t524-6">
   <w.rf>
    <LM>w#w-d1t524-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-4964-5216">
   <w.rf>
    <LM>w#w-4964-5216</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t524-7">
   <w.rf>
    <LM>w#w-d1t524-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t524-8">
   <w.rf>
    <LM>w#w-d1t524-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t524-9">
   <w.rf>
    <LM>w#w-d1t524-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t524-10">
   <w.rf>
    <LM>w#w-d1t524-10</LM>
   </w.rf>
   <form>podnik</form>
   <lemma>podnik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d-id72942">
   <w.rf>
    <LM>w#w-d-id72942</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t526-1">
   <w.rf>
    <LM>w#w-d1t526-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t526-2">
   <w.rf>
    <LM>w#w-d1t526-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t526-3">
   <w.rf>
    <LM>w#w-d1t526-3</LM>
   </w.rf>
   <form>staví</form>
   <lemma>stavět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-4964-5218">
   <w.rf>
    <LM>w#w-4964-5218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-5177">
  <m id="m784-d1t528-4">
   <w.rf>
    <LM>w#w-d1t528-4</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t528-2">
   <w.rf>
    <LM>w#w-d1t528-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-5177-5224">
   <w.rf>
    <LM>w#w-5177-5224</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d-id73086">
   <w.rf>
    <LM>w#w-d-id73086</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t528-7">
   <w.rf>
    <LM>w#w-d1t528-7</LM>
   </w.rf>
   <form>Půjdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m784-5177-5229">
   <w.rf>
    <LM>w#w-5177-5229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-5177-5227">
   <w.rf>
    <LM>w#w-5177-5227</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-5230">
  <m id="m784-d1t533-1">
   <w.rf>
    <LM>w#w-d1t533-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t533-2">
   <w.rf>
    <LM>w#w-d1t533-2</LM>
   </w.rf>
   <form>Přelouči</form>
   <lemma>Přelouč_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t533-3">
   <w.rf>
    <LM>w#w-d1t533-3</LM>
   </w.rf>
   <form>naděje</form>
   <lemma>naděje</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t533-4">
   <w.rf>
    <LM>w#w-d1t533-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t533-5">
   <w.rf>
    <LM>w#w-d1t533-5</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t533-6">
   <w.rf>
    <LM>w#w-d1t533-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m784-5177-5228">
   <w.rf>
    <LM>w#w-5177-5228</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t535-1">
   <w.rf>
    <LM>w#w-d1t535-1</LM>
   </w.rf>
   <form>kdežto</form>
   <lemma>kdežto</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t535-2">
   <w.rf>
    <LM>w#w-d1t535-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t535-3">
   <w.rf>
    <LM>w#w-d1t535-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t535-4">
   <w.rf>
    <LM>w#w-d1t535-4</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t535-5">
   <w.rf>
    <LM>w#w-d1t535-5</LM>
   </w.rf>
   <form>bydlet</form>
   <lemma>bydlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t535-6">
   <w.rf>
    <LM>w#w-d1t535-6</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-5230-1119">
   <w.rf>
    <LM>w#w-5230-1119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1120">
  <m id="m784-d1t535-10">
   <w.rf>
    <LM>w#w-d1t535-10</LM>
   </w.rf>
   <form>Ženil</form>
   <lemma>ženit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t535-8">
   <w.rf>
    <LM>w#w-d1t535-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t535-9">
   <w.rf>
    <LM>w#w-d1t535-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t535-11">
   <w.rf>
    <LM>w#w-d1t535-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-5230-5246">
   <w.rf>
    <LM>w#w-5230-5246</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t535-12">
   <w.rf>
    <LM>w#w-d1t535-12</LM>
   </w.rf>
   <form>1967</form>
   <lemma>1967</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-5230-5248">
   <w.rf>
    <LM>w#w-5230-5248</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t537-1">
   <w.rf>
    <LM>w#w-d1t537-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-5230-5249">
   <w.rf>
    <LM>w#w-5230-5249</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-5230-5250">
   <w.rf>
    <LM>w#w-5230-5250</LM>
   </w.rf>
   <form>1967</form>
   <lemma>1967</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t537-4">
   <w.rf>
    <LM>w#w-d1t537-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t537-5">
   <w.rf>
    <LM>w#w-d1t537-5</LM>
   </w.rf>
   <form>podzim</form>
   <lemma>podzim</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t537-7">
   <w.rf>
    <LM>w#w-d1t537-7</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m784-d1t537-8">
   <w.rf>
    <LM>w#w-d1t537-8</LM>
   </w.rf>
   <form>výstavba</form>
   <lemma>výstavba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-1120-1121">
   <w.rf>
    <LM>w#w-1120-1121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1122">
  <m id="m784-d1t539-2">
   <w.rf>
    <LM>w#w-d1t539-2</LM>
   </w.rf>
   <form>Šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m784-d1t539-3">
   <w.rf>
    <LM>w#w-d1t539-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t539-4">
   <w.rf>
    <LM>w#w-d1t539-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t539-5">
   <w.rf>
    <LM>w#w-d1t539-5</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t539-6">
   <w.rf>
    <LM>w#w-d1t539-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t539-8">
   <w.rf>
    <LM>w#w-d1t539-8</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t539-9">
   <w.rf>
    <LM>w#w-d1t539-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t539-10">
   <w.rf>
    <LM>w#w-d1t539-10</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m784-d1t539-11">
   <w.rf>
    <LM>w#w-d1t539-11</LM>
   </w.rf>
   <form>svém</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m784-d1t539-12">
   <w.rf>
    <LM>w#w-d1t539-12</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d-id73860">
   <w.rf>
    <LM>w#w-d-id73860</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e540-x2">
  <m id="m784-d1t543-3">
   <w.rf>
    <LM>w#w-d1t543-3</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t543-4">
   <w.rf>
    <LM>w#w-d1t543-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m784-d1t543-5">
   <w.rf>
    <LM>w#w-d1t543-5</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t543-6">
   <w.rf>
    <LM>w#w-d1t543-6</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t543-7">
   <w.rf>
    <LM>w#w-d1t543-7</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1e540-x2-1123">
   <w.rf>
    <LM>w#w-d1e540-x2-1123</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1e540-x2-5273">
   <w.rf>
    <LM>w#w-d1e540-x2-5273</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e544-x2">
  <m id="m784-d1t547-1">
   <w.rf>
    <LM>w#w-d1t547-1</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1e544-x2-1124">
   <w.rf>
    <LM>w#w-d1e544-x2-1124</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t547-2">
   <w.rf>
    <LM>w#w-d1t547-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t547-5">
   <w.rf>
    <LM>w#w-d1t547-5</LM>
   </w.rf>
   <form>manželčiných</form>
   <lemma>manželčin_^(*3ka)</lemma>
   <tag>AUFP2F---------</tag>
  </m>
  <m id="m784-d1t547-6">
   <w.rf>
    <LM>w#w-d1t547-6</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m784-d1t555-1">
   <w.rf>
    <LM>w#w-d1t555-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t555-2">
   <w.rf>
    <LM>w#w-d1t555-2</LM>
   </w.rf>
   <form>Jetonicích</form>
   <lemma>Jetonice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m784-d-id74041">
   <w.rf>
    <LM>w#w-d-id74041</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e548-x2">
  <m id="m784-d1t553-1">
   <w.rf>
    <LM>w#w-d1t553-1</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m784-d-id74187">
   <w.rf>
    <LM>w#w-d-id74187</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e556-x2">
  <m id="m784-d1t559-2">
   <w.rf>
    <LM>w#w-d1t559-2</LM>
   </w.rf>
   <form>Sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t559-3">
   <w.rf>
    <LM>w#w-d1t559-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t559-4">
   <w.rf>
    <LM>w#w-d1t559-4</LM>
   </w.rf>
   <form>dojížděli</form>
   <lemma>dojíždět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1e556-x2-5436">
   <w.rf>
    <LM>w#w-d1e556-x2-5436</LM>
   </w.rf>
   <form>jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1e556-x2-5437">
   <w.rf>
    <LM>w#w-d1e556-x2-5437</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1e556-x2-5438">
   <w.rf>
    <LM>w#w-d1e556-x2-5438</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t574-1">
   <w.rf>
    <LM>w#w-d1t574-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t574-2">
   <w.rf>
    <LM>w#w-d1t574-2</LM>
   </w.rf>
   <form>jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t574-3">
   <w.rf>
    <LM>w#w-d1t574-3</LM>
   </w.rf>
   <form>stavět</form>
   <lemma>stavět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t574-4">
   <w.rf>
    <LM>w#w-d1t574-4</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1e556-x2-5453">
   <w.rf>
    <LM>w#w-d1e556-x2-5453</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e562-x2">
  <m id="m784-d1t567-1">
   <w.rf>
    <LM>w#w-d1t567-1</LM>
   </w.rf>
   <form>Sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t567-2">
   <w.rf>
    <LM>w#w-d1t567-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t567-3">
   <w.rf>
    <LM>w#w-d1t567-3</LM>
   </w.rf>
   <form>dojížděl</form>
   <lemma>dojíždět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t567-4">
   <w.rf>
    <LM>w#w-d1t567-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t567-5">
   <w.rf>
    <LM>w#w-d1t567-5</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1e562-x2-5573">
   <w.rf>
    <LM>w#w-d1e562-x2-5573</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t578-4">
   <w.rf>
    <LM>w#w-d1t578-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t578-5">
   <w.rf>
    <LM>w#w-d1t578-5</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t578-7">
   <w.rf>
    <LM>w#w-d1t578-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t578-9">
   <w.rf>
    <LM>w#w-d1t578-9</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1e562-x2-1133">
   <w.rf>
    <LM>w#w-d1e562-x2-1133</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1e562-x2-1134">
   <w.rf>
    <LM>w#w-d1e562-x2-1134</LM>
   </w.rf>
   <form>pracoviště</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t578-2">
   <w.rf>
    <LM>w#w-d1t578-2</LM>
   </w.rf>
   <form>stavět</form>
   <lemma>stavět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t578-3">
   <w.rf>
    <LM>w#w-d1t578-3</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id74678">
   <w.rf>
    <LM>w#w-d-id74678</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e579-x2">
  <m id="m784-d1e579-x2-1129">
   <w.rf>
    <LM>w#w-d1e579-x2-1129</LM>
   </w.rf>
   <form>Abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m784-d1e579-x2-5579">
   <w.rf>
    <LM>w#w-d1e579-x2-5579</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t586-1">
   <w.rf>
    <LM>w#w-d1t586-1</LM>
   </w.rf>
   <form>manželstvím</form>
   <lemma>manželství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m784-d1t586-2">
   <w.rf>
    <LM>w#w-d1t586-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t586-3">
   <w.rf>
    <LM>w#w-d1t586-3</LM>
   </w.rf>
   <form>udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t586-6">
   <w.rf>
    <LM>w#w-d1t586-6</LM>
   </w.rf>
   <form>tečku</form>
   <lemma>tečka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e579-x2-5582">
   <w.rf>
    <LM>w#w-d1e579-x2-5582</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t593-1">
   <w.rf>
    <LM>w#w-d1t593-1</LM>
   </w.rf>
   <form>vzešlo</form>
   <lemma>vzejít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m784-d1t586-7">
   <w.rf>
    <LM>w#w-d1t586-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t586-8">
   <w.rf>
    <LM>w#w-d1t586-8</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m784-d1t586-9">
   <w.rf>
    <LM>w#w-d1t586-9</LM>
   </w.rf>
   <form>potomstvo</form>
   <lemma>potomstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d1e579-x2-5650">
   <w.rf>
    <LM>w#w-d1e579-x2-5650</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e579-x5">
  <m id="m784-d1t599-2">
   <w.rf>
    <LM>w#w-d1t599-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t601-1">
   <w.rf>
    <LM>w#w-d1t601-1</LM>
   </w.rf>
   <form>vzešlo</form>
   <lemma>vzejít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m784-d1t601-2">
   <w.rf>
    <LM>w#w-d1t601-2</LM>
   </w.rf>
   <form>potomstvo</form>
   <lemma>potomstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m784-d1e579-x5-124">
   <w.rf>
    <LM>w#w-d1e579-x5-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-125">
  <m id="m784-d1t601-3">
   <w.rf>
    <LM>w#w-d1t601-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t601-4">
   <w.rf>
    <LM>w#w-d1t601-4</LM>
   </w.rf>
   <form>jedinou</form>
   <lemma>jediný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m784-d1t601-5">
   <w.rf>
    <LM>w#w-d1t601-5</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-125-171">
   <w.rf>
    <LM>w#w-125-171</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m784-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>Jolana</form>
   <lemma>Jolana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t607-7">
   <w.rf>
    <LM>w#w-d1t607-7</LM>
   </w.rf>
   <form>Vamberská</form>
   <lemma>vamberský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m784-125-173">
   <w.rf>
    <LM>w#w-125-173</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t607-8">
   <w.rf>
    <LM>w#w-d1t607-8</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t607-9">
   <w.rf>
    <LM>w#w-d1t607-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t607-10">
   <w.rf>
    <LM>w#w-d1t607-10</LM>
   </w.rf>
   <form>Heřmanově</form>
   <lemma>Heřmanův_;Y_^(*2)</lemma>
   <tag>AUIS6M---------</tag>
  </m>
  <m id="m784-d1t607-11">
   <w.rf>
    <LM>w#w-d1t607-11</LM>
   </w.rf>
   <form>Městci</form>
   <lemma>Městec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-125-1136">
   <w.rf>
    <LM>w#w-125-1136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1137">
  <m id="m784-d1t609-2">
   <w.rf>
    <LM>w#w-d1t609-2</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t609-7">
   <w.rf>
    <LM>w#w-d1t609-7</LM>
   </w.rf>
   <form>vnuka</form>
   <lemma>vnuk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1t617-1">
   <w.rf>
    <LM>w#w-d1t617-1</LM>
   </w.rf>
   <form>Honzu</form>
   <lemma>Honza_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d-id75530">
   <w.rf>
    <LM>w#w-d-id75530</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e610-x2">
  <m id="m784-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>Dobrá</form>
   <lemma>dobrá-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e610-x2-490">
   <w.rf>
    <LM>w#w-d1e610-x2-490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t621-2">
   <w.rf>
    <LM>w#w-d1t621-2</LM>
   </w.rf>
   <form>vrátíme</form>
   <lemma>vrátit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m784-d1t625-1">
   <w.rf>
    <LM>w#w-d1t625-1</LM>
   </w.rf>
   <form>úmyslně</form>
   <lemma>úmyslně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t627-1">
   <w.rf>
    <LM>w#w-d1t627-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t627-2">
   <w.rf>
    <LM>w#w-d1t627-2</LM>
   </w.rf>
   <form>opět</form>
   <lemma>opět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t627-3">
   <w.rf>
    <LM>w#w-d1t627-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m784-d1t627-4">
   <w.rf>
    <LM>w#w-d1t627-4</LM>
   </w.rf>
   <form>vašemu</form>
   <lemma>váš</lemma>
   <tag>PSZS3-P2-------</tag>
  </m>
  <m id="m784-d1t629-1">
   <w.rf>
    <LM>w#w-d1t629-1</LM>
   </w.rf>
   <form>rodnému</form>
   <lemma>rodný</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m784-d1t629-2">
   <w.rf>
    <LM>w#w-d1t629-2</LM>
   </w.rf>
   <form>otci</form>
   <lemma>otec</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m784-d1e610-x2-493">
   <w.rf>
    <LM>w#w-d1e610-x2-493</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-494">
  <m id="m784-d1t632-1">
   <w.rf>
    <LM>w#w-d1t632-1</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m784-d1t632-2">
   <w.rf>
    <LM>w#w-d1t632-2</LM>
   </w.rf>
   <form>otázka</form>
   <lemma>otázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-494-1142">
   <w.rf>
    <LM>w#w-494-1142</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t632-7">
   <w.rf>
    <LM>w#w-d1t632-7</LM>
   </w.rf>
   <form>Nezazlíval</form>
   <lemma>zazlívat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m784-d1t632-5">
   <w.rf>
    <LM>w#w-d1t632-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t632-6">
   <w.rf>
    <LM>w#w-d1t632-6</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m784-494-519">
   <w.rf>
    <LM>w#w-494-519</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t632-11">
   <w.rf>
    <LM>w#w-d1t632-11</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t632-8">
   <w.rf>
    <LM>w#w-d1t632-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t632-9">
   <w.rf>
    <LM>w#w-d1t632-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t632-10">
   <w.rf>
    <LM>w#w-d1t632-10</LM>
   </w.rf>
   <form>dospělý</form>
   <lemma>dospělý-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d-id75988">
   <w.rf>
    <LM>w#w-d-id75988</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t632-13">
   <w.rf>
    <LM>w#w-d1t632-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t632-14">
   <w.rf>
    <LM>w#w-d1t632-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t632-15">
   <w.rf>
    <LM>w#w-d1t632-15</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m784-d1t632-16">
   <w.rf>
    <LM>w#w-d1t632-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t632-17">
   <w.rf>
    <LM>w#w-d1t632-17</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t632-18">
   <w.rf>
    <LM>w#w-d1t632-18</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-5_^(př._co_nejméně,_co_nevidět_atd.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t632-19">
   <w.rf>
    <LM>w#w-d1t632-19</LM>
   </w.rf>
   <form>škvrně</form>
   <lemma>škvrně</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m784-d1t632-20">
   <w.rf>
    <LM>w#w-d1t632-20</LM>
   </w.rf>
   <form>jedenapůlleté</form>
   <lemma>jedenapůlletý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m784-d1t632-24">
   <w.rf>
    <LM>w#w-d1t632-24</LM>
   </w.rf>
   <form>nenechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-494-511">
   <w.rf>
    <LM>w#w-494-511</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-512">
  <m id="m784-d1t632-25">
   <w.rf>
    <LM>w#w-d1t632-25</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m784-d1t632-26">
   <w.rf>
    <LM>w#w-d1t632-26</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t632-27">
   <w.rf>
    <LM>w#w-d1t632-27</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m784-d1t632-28">
   <w.rf>
    <LM>w#w-d1t632-28</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t632-29">
   <w.rf>
    <LM>w#w-d1t632-29</LM>
   </w.rf>
   <form>ušetřil</form>
   <lemma>ušetřit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t632-30">
   <w.rf>
    <LM>w#w-d1t632-30</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP2----------</tag>
  </m>
  <m id="m784-d1t632-31">
   <w.rf>
    <LM>w#w-d1t632-31</LM>
   </w.rf>
   <form>trampot</form>
   <lemma>trampoty</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m784-d-id76184">
   <w.rf>
    <LM>w#w-d-id76184</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t632-36">
   <w.rf>
    <LM>w#w-d1t632-36</LM>
   </w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t632-37">
   <w.rf>
    <LM>w#w-d1t632-37</LM>
   </w.rf>
   <form>tří</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m784-d1t632-38">
   <w.rf>
    <LM>w#w-d1t632-38</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m784-d1t632-39">
   <w.rf>
    <LM>w#w-d1t632-39</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t632-40">
   <w.rf>
    <LM>w#w-d1t632-40</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t634-1">
   <w.rf>
    <LM>w#w-d1t634-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t636-2">
   <w.rf>
    <LM>w#w-d1t636-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m784-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m784-d1t636-5">
   <w.rf>
    <LM>w#w-d1t636-5</LM>
   </w.rf>
   <form>ochránil</form>
   <lemma>ochránit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t636-6">
   <w.rf>
    <LM>w#w-d1t636-6</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>deportací</form>
   <lemma>deportace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m784-d-id76409">
   <w.rf>
    <LM>w#w-d-id76409</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e643-x2">
  <m id="m784-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t646-2">
   <w.rf>
    <LM>w#w-d1t646-2</LM>
   </w.rf>
   <form>dospělý</form>
   <lemma>dospělý_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t646-4">
   <w.rf>
    <LM>w#w-d1t646-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t646-5">
   <w.rf>
    <LM>w#w-d1t646-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m784-d1t646-6">
   <w.rf>
    <LM>w#w-d1t646-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t646-9">
   <w.rf>
    <LM>w#w-d1t646-9</LM>
   </w.rf>
   <form>nevyčetl</form>
   <lemma>vyčíst</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1t646-13">
   <w.rf>
    <LM>w#w-d1t646-13</LM>
   </w.rf>
   <form>hlasem</form>
   <lemma>hlas</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m784-d1e643-x2-9514">
   <w.rf>
    <LM>w#w-d1e643-x2-9514</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-9515">
  <m id="m784-d1t646-22">
   <w.rf>
    <LM>w#w-d1t646-22</LM>
   </w.rf>
   <form>Neřekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1t646-20">
   <w.rf>
    <LM>w#w-d1t646-20</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t646-21">
   <w.rf>
    <LM>w#w-d1t646-21</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t646-16">
   <w.rf>
    <LM>w#w-d1t646-16</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m784-d1t646-17">
   <w.rf>
    <LM>w#w-d1t646-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t646-18">
   <w.rf>
    <LM>w#w-d1t646-18</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m784-d1e643-x2-803">
   <w.rf>
    <LM>w#w-d1e643-x2-803</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e643-x2-804">
   <w.rf>
    <LM>w#w-d1e643-x2-804</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t650-1">
   <w.rf>
    <LM>w#w-d1t650-1</LM>
   </w.rf>
   <form>Mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t650-2">
   <w.rf>
    <LM>w#w-d1t650-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m784-d1t650-3">
   <w.rf>
    <LM>w#w-d1t650-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m784-d1t650-4">
   <w.rf>
    <LM>w#w-d1t650-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t650-5">
   <w.rf>
    <LM>w#w-d1t650-5</LM>
   </w.rf>
   <form>nechat</form>
   <lemma>nechat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-9515-1154">
   <w.rf>
    <LM>w#w-9515-1154</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1e643-x2-807">
   <w.rf>
    <LM>w#w-d1e643-x2-807</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e651-x2">
  <m id="m784-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e651-x2-996">
   <w.rf>
    <LM>w#w-d1e651-x2-996</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>neřekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1e651-x2-998">
   <w.rf>
    <LM>w#w-d1e651-x2-998</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-999">
  <m id="m784-d1t654-5">
   <w.rf>
    <LM>w#w-d1t654-5</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t654-6">
   <w.rf>
    <LM>w#w-d1t654-6</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-999-1009">
   <w.rf>
    <LM>w#w-999-1009</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e651-x3">
  <m id="m784-d1t656-1">
   <w.rf>
    <LM>w#w-d1t656-1</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t656-2">
   <w.rf>
    <LM>w#w-d1t656-2</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m784-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t660-2">
   <w.rf>
    <LM>w#w-d1t660-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t660-3">
   <w.rf>
    <LM>w#w-d1t660-3</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t660-4">
   <w.rf>
    <LM>w#w-d1t660-4</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t660-5">
   <w.rf>
    <LM>w#w-d1t660-5</LM>
   </w.rf>
   <form>vlivem</form>
   <lemma>vliv</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m784-d1t660-6">
   <w.rf>
    <LM>w#w-d1t660-6</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS2---------1</tag>
  </m>
  <m id="m784-d1t660-7">
   <w.rf>
    <LM>w#w-d1t660-7</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1e651-x3-1091">
   <w.rf>
    <LM>w#w-d1e651-x3-1091</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t667-1">
   <w.rf>
    <LM>w#w-d1t667-1</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m784-d1t667-2">
   <w.rf>
    <LM>w#w-d1t667-2</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d-id77405">
   <w.rf>
    <LM>w#w-d-id77405</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t667-4">
   <w.rf>
    <LM>w#w-d1t667-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t667-5">
   <w.rf>
    <LM>w#w-d1t667-5</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m784-d1t667-6">
   <w.rf>
    <LM>w#w-d1t667-6</LM>
   </w.rf>
   <form>vhodné</form>
   <lemma>vhodný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m784-d1e651-x3-1203">
   <w.rf>
    <LM>w#w-d1e651-x3-1203</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1204">
  <m id="m784-d1t669-2">
   <w.rf>
    <LM>w#w-d1t669-2</LM>
   </w.rf>
   <form>Podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t669-5">
   <w.rf>
    <LM>w#w-d1t669-5</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m784-d1t669-7">
   <w.rf>
    <LM>w#w-d1t669-7</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t669-9">
   <w.rf>
    <LM>w#w-d1t669-9</LM>
   </w.rf>
   <form>názor</form>
   <lemma>názor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d-id77609">
   <w.rf>
    <LM>w#w-d-id77609</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t669-11">
   <w.rf>
    <LM>w#w-d1t669-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t669-12">
   <w.rf>
    <LM>w#w-d1t669-12</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m784-d1t669-13">
   <w.rf>
    <LM>w#w-d1t669-13</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m784-d1t669-14">
   <w.rf>
    <LM>w#w-d1t669-14</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m784-d1t669-15">
   <w.rf>
    <LM>w#w-d1t669-15</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t669-16">
   <w.rf>
    <LM>w#w-d1t669-16</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m784-d1t669-17">
   <w.rf>
    <LM>w#w-d1t669-17</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-d1t669-18">
   <w.rf>
    <LM>w#w-d1t669-18</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m784-1204-1214">
   <w.rf>
    <LM>w#w-1204-1214</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t673-4">
   <w.rf>
    <LM>w#w-d1t673-4</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m784-d1t673-5">
   <w.rf>
    <LM>w#w-d1t673-5</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m784-d1t673-6">
   <w.rf>
    <LM>w#w-d1t673-6</LM>
   </w.rf>
   <form>neovlivňovala</form>
   <lemma>ovlivňovat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m784-d1t673-7">
   <w.rf>
    <LM>w#w-d1t673-7</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m784-d1t673-8">
   <w.rf>
    <LM>w#w-d1t673-8</LM>
   </w.rf>
   <form>rodinou</form>
   <lemma>rodina</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m784-d-id77900">
   <w.rf>
    <LM>w#w-d-id77900</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e674-x2">
  <m id="m784-d1e674-x2-1270">
   <w.rf>
    <LM>w#w-d1e674-x2-1270</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m784-d1t679-2">
   <w.rf>
    <LM>w#w-d1t679-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t679-3">
   <w.rf>
    <LM>w#w-d1t679-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t679-4">
   <w.rf>
    <LM>w#w-d1t679-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t679-5">
   <w.rf>
    <LM>w#w-d1t679-5</LM>
   </w.rf>
   <form>mysli</form>
   <lemma>mysl</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d1t681-1">
   <w.rf>
    <LM>w#w-d1t681-1</LM>
   </w.rf>
   <form>vašeho</form>
   <lemma>váš</lemma>
   <tag>PSMS4-P2-------</tag>
  </m>
  <m id="m784-d1t681-2">
   <w.rf>
    <LM>w#w-d1t681-2</LM>
   </w.rf>
   <form>otce</form>
   <lemma>otec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1t681-3">
   <w.rf>
    <LM>w#w-d1t681-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t681-4">
   <w.rf>
    <LM>w#w-d1t681-4</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m784-d1t681-5">
   <w.rf>
    <LM>w#w-d1t681-5</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m784-d1e674-x2-9592">
   <w.rf>
    <LM>w#w-d1e674-x2-9592</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t690-1">
   <w.rf>
    <LM>w#w-d1t690-1</LM>
   </w.rf>
   <form>nikoliv</form>
   <lemma>nikoliv_,s_^(^DD**nikoli)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t690-2">
   <w.rf>
    <LM>w#w-d1t690-2</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m784-d1t690-3">
   <w.rf>
    <LM>w#w-d1t690-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1e674-x2-1288">
   <w.rf>
    <LM>w#w-d1e674-x2-1288</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8MS4----------</tag>
  </m>
  <m id="m784-d1e674-x2-1289">
   <w.rf>
    <LM>w#w-d1e674-x2-1289</LM>
   </w.rf>
   <form>otce</form>
   <lemma>otec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1e674-x2-1294">
   <w.rf>
    <LM>w#w-d1e674-x2-1294</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e674-x5">
  <m id="m784-d1t694-1">
   <w.rf>
    <LM>w#w-d1t694-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e674-x5-1359">
   <w.rf>
    <LM>w#w-d1e674-x5-1359</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t694-2">
   <w.rf>
    <LM>w#w-d1t694-2</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1e674-x5-1360">
   <w.rf>
    <LM>w#w-d1e674-x5-1360</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t694-6">
   <w.rf>
    <LM>w#w-d1t694-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t694-7">
   <w.rf>
    <LM>w#w-d1t694-7</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m784-d1e674-x5-1361">
   <w.rf>
    <LM>w#w-d1e674-x5-1361</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t696-1">
   <w.rf>
    <LM>w#w-d1t696-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t696-2">
   <w.rf>
    <LM>w#w-d1t696-2</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------1</tag>
  </m>
  <m id="m784-d1t696-3">
   <w.rf>
    <LM>w#w-d1t696-3</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e674-x5-1397">
   <w.rf>
    <LM>w#w-d1e674-x5-1397</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t701-2">
   <w.rf>
    <LM>w#w-d1t701-2</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8MS4----------</tag>
  </m>
  <m id="m784-d1t701-3">
   <w.rf>
    <LM>w#w-d1t701-3</LM>
   </w.rf>
   <form>otce</form>
   <lemma>otec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m784-d1t701-4">
   <w.rf>
    <LM>w#w-d1t701-4</LM>
   </w.rf>
   <form>taktéž</form>
   <lemma>taktéž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-1366-1375">
   <w.rf>
    <LM>w#w-1366-1375</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t701-11">
   <w.rf>
    <LM>w#w-d1t701-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m784-d1t701-7">
   <w.rf>
    <LM>w#w-d1t701-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m784-d1t701-8">
   <w.rf>
    <LM>w#w-d1t701-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t701-9">
   <w.rf>
    <LM>w#w-d1t701-9</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m784-d1t701-10">
   <w.rf>
    <LM>w#w-d1t701-10</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t701-12">
   <w.rf>
    <LM>w#w-d1t701-12</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m784-d-id78623">
   <w.rf>
    <LM>w#w-d-id78623</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e702-x2">
  <m id="m784-d1t707-9">
   <w.rf>
    <LM>w#w-d1t707-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t707-10">
   <w.rf>
    <LM>w#w-d1t707-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t707-11">
   <w.rf>
    <LM>w#w-d1t707-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t707-12">
   <w.rf>
    <LM>w#w-d1t707-12</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t707-13">
   <w.rf>
    <LM>w#w-d1t707-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t709-1">
   <w.rf>
    <LM>w#w-d1t709-1</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1e702-x2-1488">
   <w.rf>
    <LM>w#w-d1e702-x2-1488</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t711-1">
   <w.rf>
    <LM>w#w-d1t711-1</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t711-2">
   <w.rf>
    <LM>w#w-d1t711-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m784-d1t711-3">
   <w.rf>
    <LM>w#w-d1t711-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m784-d1t711-4">
   <w.rf>
    <LM>w#w-d1t711-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1e702-x2-1491">
   <w.rf>
    <LM>w#w-d1e702-x2-1491</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t711-5">
   <w.rf>
    <LM>w#w-d1t711-5</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1e702-x2-1492">
   <w.rf>
    <LM>w#w-d1e702-x2-1492</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t713-2">
   <w.rf>
    <LM>w#w-d1t713-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t711-10">
   <w.rf>
    <LM>w#w-d1t711-10</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m784-d1t713-1">
   <w.rf>
    <LM>w#w-d1t713-1</LM>
   </w.rf>
   <form>několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m784-d1t711-11">
   <w.rf>
    <LM>w#w-d1t711-11</LM>
   </w.rf>
   <form>navštívil</form>
   <lemma>navštívit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1e702-x2-1182">
   <w.rf>
    <LM>w#w-d1e702-x2-1182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-1183">
  <m id="m784-1183-1184">
   <w.rf>
    <LM>w#w-1183-1184</LM>
   </w.rf>
   <form>Několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m784-1183-1185">
   <w.rf>
    <LM>w#w-1183-1185</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t713-3">
   <w.rf>
    <LM>w#w-d1t713-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m784-d1t713-4">
   <w.rf>
    <LM>w#w-d1t713-4</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m784-d1t713-5">
   <w.rf>
    <LM>w#w-d1t713-5</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t716-1">
   <w.rf>
    <LM>w#w-d1t716-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t716-3">
   <w.rf>
    <LM>w#w-d1t716-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m784-d1t716-5">
   <w.rf>
    <LM>w#w-d1t716-5</LM>
   </w.rf>
   <form>1949</form>
   <lemma>1949</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t718-1">
   <w.rf>
    <LM>w#w-d1t718-1</LM>
   </w.rf>
   <form>dopadl</form>
   <lemma>dopadnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m784-d1t718-2">
   <w.rf>
    <LM>w#w-d1t718-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t718-3">
   <w.rf>
    <LM>w#w-d1t718-3</LM>
   </w.rf>
   <form>hůř</form>
   <lemma>hůře</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m784-d1t718-4">
   <w.rf>
    <LM>w#w-d1t718-4</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t718-5">
   <w.rf>
    <LM>w#w-d1t718-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m784-d-id79365">
   <w.rf>
    <LM>w#w-d-id79365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e702-x3">
  <m id="m784-d1t722-2">
   <w.rf>
    <LM>w#w-d1t722-2</LM>
   </w.rf>
   <form>Systém</form>
   <lemma>systém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m784-d-id79429">
   <w.rf>
    <LM>w#w-d-id79429</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t722-4">
   <w.rf>
    <LM>w#w-d1t722-4</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m784-d1t722-5">
   <w.rf>
    <LM>w#w-d1t722-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t722-6">
   <w.rf>
    <LM>w#w-d1t722-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t722-7">
   <w.rf>
    <LM>w#w-d1t722-7</LM>
   </w.rf>
   <form>našem</form>
   <lemma>náš</lemma>
   <tag>PSZS6-P1-------</tag>
  </m>
  <m id="m784-d1t722-10">
   <w.rf>
    <LM>w#w-d1t722-10</LM>
   </w.rf>
   <form>Československu</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m784-d1e702-x3-1895">
   <w.rf>
    <LM>w#w-d1e702-x3-1895</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t724-1">
   <w.rf>
    <LM>w#w-d1t724-1</LM>
   </w.rf>
   <form>způsobil</form>
   <lemma>způsobit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t724-2">
   <w.rf>
    <LM>w#w-d1t724-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d-id79579">
   <w.rf>
    <LM>w#w-d-id79579</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t724-4">
   <w.rf>
    <LM>w#w-d1t724-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t724-5">
   <w.rf>
    <LM>w#w-d1t724-5</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t724-6">
   <w.rf>
    <LM>w#w-d1t724-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t724-7">
   <w.rf>
    <LM>w#w-d1t724-7</LM>
   </w.rf>
   <form>radioamatér</form>
   <lemma>radioamatér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t724-8">
   <w.rf>
    <LM>w#w-d1t724-8</LM>
   </w.rf>
   <form>OK</form>
   <lemma>OK-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m784-d1t724-10">
   <w.rf>
    <LM>w#w-d1t724-10</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t724-11">
   <w.rf>
    <LM>w#w-d1t724-11</LM>
   </w.rf>
   <form>Svatopluk</form>
   <lemma>Svatopluk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t724-12">
   <w.rf>
    <LM>w#w-d1t724-12</LM>
   </w.rf>
   <form>Viliam</form>
   <lemma>Viliam_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t726-1">
   <w.rf>
    <LM>w#w-d1t726-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m784-d1t726-2">
   <w.rf>
    <LM>w#w-d1t726-2</LM>
   </w.rf>
   <form>obviněn</form>
   <lemma>obvinit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m784-d1t726-3">
   <w.rf>
    <LM>w#w-d1t726-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m784-d1t726-4">
   <w.rf>
    <LM>w#w-d1t726-4</LM>
   </w.rf>
   <form>protistátní</form>
   <lemma>protistátní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m784-d1t726-5">
   <w.rf>
    <LM>w#w-d1t726-5</LM>
   </w.rf>
   <form>činnosti</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m784-d1t729-1">
   <w.rf>
    <LM>w#w-d1t729-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m784-d1t729-2">
   <w.rf>
    <LM>w#w-d1t729-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t729-3">
   <w.rf>
    <LM>w#w-d1t729-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m784-d-id79864">
   <w.rf>
    <LM>w#w-d-id79864</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t731-1">
   <w.rf>
    <LM>w#w-d1t731-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t731-2">
   <w.rf>
    <LM>w#w-d1t731-2</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m784-d1t731-3">
   <w.rf>
    <LM>w#w-d1t731-3</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t731-4">
   <w.rf>
    <LM>w#w-d1t731-4</LM>
   </w.rf>
   <form>padl</form>
   <lemma>padnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m784-d1t731-9">
   <w.rf>
    <LM>w#w-d1t731-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m784-d1t731-10">
   <w.rf>
    <LM>w#w-d1t731-10</LM>
   </w.rf>
   <form>český</form>
   <lemma>český</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m784-d1t731-11">
   <w.rf>
    <LM>w#w-d1t731-11</LM>
   </w.rf>
   <form>letec</form>
   <lemma>letec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t731-12">
   <w.rf>
    <LM>w#w-d1t731-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t731-13">
   <w.rf>
    <LM>w#w-d1t731-13</LM>
   </w.rf>
   <form>Anglii</form>
   <lemma>Anglie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m784-d-id80076">
   <w.rf>
    <LM>w#w-d-id80076</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e702-x4">
  <m id="m784-d1t735-2">
   <w.rf>
    <LM>w#w-d1t735-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m784-d1t735-3">
   <w.rf>
    <LM>w#w-d1t735-3</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m784-d1t735-1">
   <w.rf>
    <LM>w#w-d1t735-1</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t735-4">
   <w.rf>
    <LM>w#w-d1t735-4</LM>
   </w.rf>
   <form>25</form>
   <lemma>25</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m784-d1t735-5">
   <w.rf>
    <LM>w#w-d1t735-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m784-d1t735-6">
   <w.rf>
    <LM>w#w-d1t735-6</LM>
   </w.rf>
   <form>pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m784-d1t735-7">
   <w.rf>
    <LM>w#w-d1t735-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t735-8">
   <w.rf>
    <LM>w#w-d1t735-8</LM>
   </w.rf>
   <form>Jáchymově</form>
   <lemma>Jáchymov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1e702-x4-9758">
   <w.rf>
    <LM>w#w-d1e702-x4-9758</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t737-2">
   <w.rf>
    <LM>w#w-d1t737-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t737-3">
   <w.rf>
    <LM>w#w-d1t737-3</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m784-d1t737-4">
   <w.rf>
    <LM>w#w-d1t737-4</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m784-d1t737-5">
   <w.rf>
    <LM>w#w-d1t737-5</LM>
   </w.rf>
   <form>budování</form>
   <lemma>budování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t737-6">
   <w.rf>
    <LM>w#w-d1t737-6</LM>
   </w.rf>
   <form>státu</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t737-7">
   <w.rf>
    <LM>w#w-d1t737-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t739-3">
   <w.rf>
    <LM>w#w-d1t739-3</LM>
   </w.rf>
   <form>dolování</form>
   <lemma>dolování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m784-d1t739-4">
   <w.rf>
    <LM>w#w-d1t739-4</LM>
   </w.rf>
   <form>uranu</form>
   <lemma>uran</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m784-d1t742-1">
   <w.rf>
    <LM>w#w-d1t742-1</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1t742-2">
   <w.rf>
    <LM>w#w-d1t742-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m784-d1t755-1">
   <w.rf>
    <LM>w#w-d1t755-1</LM>
   </w.rf>
   <form>nemoc</form>
   <lemma>nemoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d-id80085">
   <w.rf>
    <LM>w#w-d-id80085</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e744-x2">
  <m id="m784-d1t749-1">
   <w.rf>
    <LM>w#w-d1t749-1</LM>
   </w.rf>
   <form>Zahynul</form>
   <lemma>zahynout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m784-d1e744-x2-2080">
   <w.rf>
    <LM>w#w-d1e744-x2-2080</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1e744-x2-2078">
   <w.rf>
    <LM>w#w-d1e744-x2-2078</LM>
   </w.rf>
   <form>komunistickém</form>
   <lemma>komunistický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m784-d1e744-x2-2079">
   <w.rf>
    <LM>w#w-d1e744-x2-2079</LM>
   </w.rf>
   <form>lágru</form>
   <lemma>lágr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d-id80499">
   <w.rf>
    <LM>w#w-d-id80499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e756-x2">
  <m id="m784-d1t769-3">
   <w.rf>
    <LM>w#w-d1t769-3</LM>
   </w.rf>
   <form>Tentokrát</form>
   <lemma>tentokrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t773-2">
   <w.rf>
    <LM>w#w-d1t773-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m784-d1t773-3">
   <w.rf>
    <LM>w#w-d1t773-3</LM>
   </w.rf>
   <form>dovolili</form>
   <lemma>dovolit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m784-d1t769-8">
   <w.rf>
    <LM>w#w-d1t769-8</LM>
   </w.rf>
   <form>dovézt</form>
   <lemma>dovézt</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1e756-x2-2469">
   <w.rf>
    <LM>w#w-d1e756-x2-2469</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m784-d1e756-x2-2470">
   <w.rf>
    <LM>w#w-d1e756-x2-2470</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t769-6">
   <w.rf>
    <LM>w#w-d1t769-6</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t769-7">
   <w.rf>
    <LM>w#w-d1t769-7</LM>
   </w.rf>
   <form>mrtvolu</form>
   <lemma>mrtvola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m784-d1e756-x2-2471">
   <w.rf>
    <LM>w#w-d1e756-x2-2471</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t769-9">
   <w.rf>
    <LM>w#w-d1t769-9</LM>
   </w.rf>
   <form>umřít</form>
   <lemma>umřít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1t769-10">
   <w.rf>
    <LM>w#w-d1t769-10</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d-id80950">
   <w.rf>
    <LM>w#w-d-id80950</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m784-27638_04-d1e770-x2">
  <m id="m784-d1t777-1">
   <w.rf>
    <LM>w#w-d1t777-1</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t777-2">
   <w.rf>
    <LM>w#w-d1t777-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m784-d1t777-3">
   <w.rf>
    <LM>w#w-d1t777-3</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m784-d1t777-4">
   <w.rf>
    <LM>w#w-d1t777-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m784-d1t777-5">
   <w.rf>
    <LM>w#w-d1t777-5</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m784-d1t777-6">
   <w.rf>
    <LM>w#w-d1t777-6</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t777-7">
   <w.rf>
    <LM>w#w-d1t777-7</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS3---------1</tag>
  </m>
  <m id="m784-d1t777-8">
   <w.rf>
    <LM>w#w-d1t777-8</LM>
   </w.rf>
   <form>babičce</form>
   <lemma>babička</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m784-d1e770-x2-2475">
   <w.rf>
    <LM>w#w-d1e770-x2-2475</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t779-1">
   <w.rf>
    <LM>w#w-d1t779-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m784-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP3----------</tag>
  </m>
  <m id="m784-d1t779-3">
   <w.rf>
    <LM>w#w-d1t779-3</LM>
   </w.rf>
   <form>příbuzným</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m784-d1t779-4">
   <w.rf>
    <LM>w#w-d1t779-4</LM>
   </w.rf>
   <form>jediným</form>
   <lemma>jediný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m784-d1t779-5">
   <w.rf>
    <LM>w#w-d1t779-5</LM>
   </w.rf>
   <form>slovem</form>
   <lemma>slovo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m784-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>neřekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m784-d1e770-x2-2478">
   <w.rf>
    <LM>w#w-d1e770-x2-2478</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d-id81305">
   <w.rf>
    <LM>w#w-d-id81305</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m784-d1t781-4">
   <w.rf>
    <LM>w#w-d1t781-4</LM>
   </w.rf>
   <form>Mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m784-d1t781-2">
   <w.rf>
    <LM>w#w-d1t781-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m784-d1t781-3">
   <w.rf>
    <LM>w#w-d1t781-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m784-d1t781-7">
   <w.rf>
    <LM>w#w-d1t781-7</LM>
   </w.rf>
   <form>vyreklamovat</form>
   <lemma>vyreklamovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m784-d1e770-x2-1199">
   <w.rf>
    <LM>w#w-d1e770-x2-1199</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
