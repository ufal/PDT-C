<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_023.01.w.gz" />
  </references>
 </head>
 <s id="m023-d1e683-x2">
  <m id="m023-d1t686-1">
   <w.rf>
    <LM>w#w-d1t686-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m023-d1t686-2">
   <w.rf>
    <LM>w#w-d1t686-2</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d-id65377-punct">
   <w.rf>
    <LM>w#w-d-id65377-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t686-4">
   <w.rf>
    <LM>w#w-d1t686-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m023-d1t686-5">
   <w.rf>
    <LM>w#w-d1t686-5</LM>
   </w.rf>
   <form>tancuju</form>
   <lemma>tancovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t686-6">
   <w.rf>
    <LM>w#w-d1t686-6</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-d1e683-x2-572">
   <w.rf>
    <LM>w#w-d1e683-x2-572</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-573">
  <m id="m023-d1t686-7">
   <w.rf>
    <LM>w#w-d1t686-7</LM>
   </w.rf>
   <form>Sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t696-1">
   <w.rf>
    <LM>w#w-d1t696-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t696-2">
   <w.rf>
    <LM>w#w-d1t696-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m023-d1t696-3">
   <w.rf>
    <LM>w#w-d1t696-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m023-d1t696-4">
   <w.rf>
    <LM>w#w-d1t696-4</LM>
   </w.rf>
   <form>65</form>
   <lemma>65</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m023-d-id65580-punct">
   <w.rf>
    <LM>w#w-d-id65580-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t696-6">
   <w.rf>
    <LM>w#w-d1t696-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t696-7">
   <w.rf>
    <LM>w#w-d1t696-7</LM>
   </w.rf>
   <form>tancuju</form>
   <lemma>tancovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t696-8">
   <w.rf>
    <LM>w#w-d1t696-8</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-d-m-d1e687-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e687-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-574">
  <m id="m023-d1t700-1">
   <w.rf>
    <LM>w#w-d1t700-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t700-2">
   <w.rf>
    <LM>w#w-d1t700-2</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-d1t700-3">
   <w.rf>
    <LM>w#w-d1t700-3</LM>
   </w.rf>
   <form>hudbu</form>
   <lemma>hudba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-574-575">
   <w.rf>
    <LM>w#w-574-575</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t700-4">
   <w.rf>
    <LM>w#w-d1t700-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t702-1">
   <w.rf>
    <LM>w#w-d1t702-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t702-3">
   <w.rf>
    <LM>w#w-d1t702-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t702-4">
   <w.rf>
    <LM>w#w-d1t702-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m023-d1t702-5">
   <w.rf>
    <LM>w#w-d1t702-5</LM>
   </w.rf>
   <form>přítelkyní</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m023-d1t702-7">
   <w.rf>
    <LM>w#w-d1t702-7</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t702-6">
   <w.rf>
    <LM>w#w-d1t702-6</LM>
   </w.rf>
   <form>chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m023-d-m-d1e697-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e697-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e716-x2">
  <m id="m023-d1t719-1">
   <w.rf>
    <LM>w#w-d1t719-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t719-2">
   <w.rf>
    <LM>w#w-d1t719-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t719-3">
   <w.rf>
    <LM>w#w-d1t719-3</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t719-4">
   <w.rf>
    <LM>w#w-d1t719-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m023-d1t719-5">
   <w.rf>
    <LM>w#w-d1t719-5</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m023-d1t719-6">
   <w.rf>
    <LM>w#w-d1t719-6</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d-id66104-punct">
   <w.rf>
    <LM>w#w-d-id66104-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e720-x2">
  <m id="m023-d1t723-5">
   <w.rf>
    <LM>w#w-d1t723-5</LM>
   </w.rf>
   <form>Jmenoval</form>
   <lemma>jmenovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m023-d1t723-4">
   <w.rf>
    <LM>w#w-d1t723-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t723-7">
   <w.rf>
    <LM>w#w-d1t723-7</LM>
   </w.rf>
   <form>Bohumil</form>
   <lemma>Bohumil_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d1t723-8">
   <w.rf>
    <LM>w#w-d1t723-8</LM>
   </w.rf>
   <form>Herejt</form>
   <lemma>Herejt_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d1t723-12">
   <w.rf>
    <LM>w#w-d1t723-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t723-14">
   <w.rf>
    <LM>w#w-d1t723-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t723-15">
   <w.rf>
    <LM>w#w-d1t723-15</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1e720-x2-602">
   <w.rf>
    <LM>w#w-d1e720-x2-602</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-603">
  <m id="m023-d1t727-2">
   <w.rf>
    <LM>w#w-d1t727-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t727-1">
   <w.rf>
    <LM>w#w-d1t727-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t727-3">
   <w.rf>
    <LM>w#w-d1t727-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m023-d1t727-4">
   <w.rf>
    <LM>w#w-d1t727-4</LM>
   </w.rf>
   <form>řádka</form>
   <lemma>řádka_^(textu)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m023-d1t727-5">
   <w.rf>
    <LM>w#w-d1t727-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m023-d-id66498-punct">
   <w.rf>
    <LM>w#w-d-id66498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t727-7">
   <w.rf>
    <LM>w#w-d1t727-7</LM>
   </w.rf>
   <form>umřel</form>
   <lemma>umřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1t727-8">
   <w.rf>
    <LM>w#w-d1t727-8</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-603-604">
   <w.rf>
    <LM>w#w-603-604</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-605">
  <m id="m023-d1t727-11">
   <w.rf>
    <LM>w#w-d1t727-11</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1t727-12">
   <w.rf>
    <LM>w#w-d1t727-12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t727-13">
   <w.rf>
    <LM>w#w-d1t727-13</LM>
   </w.rf>
   <form>nohu</form>
   <lemma>noha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d-m-d1e720-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e720-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e732-x2">
  <m id="m023-d1t735-1">
   <w.rf>
    <LM>w#w-d1t735-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m023-d1t735-2">
   <w.rf>
    <LM>w#w-d1t735-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t735-3">
   <w.rf>
    <LM>w#w-d1t735-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m023-d1t735-4">
   <w.rf>
    <LM>w#w-d1t735-4</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m023-d-id66796-punct">
   <w.rf>
    <LM>w#w-d-id66796-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e736-x2">
  <m id="m023-d1t741-1">
   <w.rf>
    <LM>w#w-d1t741-1</LM>
   </w.rf>
   <form>Dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1t741-3">
   <w.rf>
    <LM>w#w-d1t741-3</LM>
   </w.rf>
   <form>sněť</form>
   <lemma>sněť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t741-4">
   <w.rf>
    <LM>w#w-d1t741-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t741-5">
   <w.rf>
    <LM>w#w-d1t741-5</LM>
   </w.rf>
   <form>nohy</form>
   <lemma>noha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m023-d1e736-x2-1779">
   <w.rf>
    <LM>w#w-d1e736-x2-1779</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-1780">
  <m id="m023-d1t741-8">
   <w.rf>
    <LM>w#w-d1t741-8</LM>
   </w.rf>
   <form>Nejprve</form>
   <lemma>nejprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t741-9">
   <w.rf>
    <LM>w#w-d1t741-9</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m023-d1t741-10">
   <w.rf>
    <LM>w#w-d1t741-10</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m023-d1t743-2">
   <w.rf>
    <LM>w#w-d1t743-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t743-3">
   <w.rf>
    <LM>w#w-d1t743-3</LM>
   </w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t743-1">
   <w.rf>
    <LM>w#w-d1t743-1</LM>
   </w.rf>
   <form>palec</form>
   <lemma>palec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1t743-4">
   <w.rf>
    <LM>w#w-d1t743-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t743-5">
   <w.rf>
    <LM>w#w-d1t743-5</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t743-6">
   <w.rf>
    <LM>w#w-d1t743-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t743-7">
   <w.rf>
    <LM>w#w-d1t743-7</LM>
   </w.rf>
   <form>nohu</form>
   <lemma>noha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t743-8">
   <w.rf>
    <LM>w#w-d1t743-8</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t743-9">
   <w.rf>
    <LM>w#w-d1t743-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t743-10">
   <w.rf>
    <LM>w#w-d1t743-10</LM>
   </w.rf>
   <form>dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m023-d1e736-x2-629">
   <w.rf>
    <LM>w#w-d1e736-x2-629</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-630">
  <m id="m023-d1t745-1">
   <w.rf>
    <LM>w#w-d1t745-1</LM>
   </w.rf>
   <form>Skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1t745-2">
   <w.rf>
    <LM>w#w-d1t745-2</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-630-631">
   <w.rf>
    <LM>w#w-630-631</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-632">
  <m id="m023-d1t745-5">
   <w.rf>
    <LM>w#w-d1t745-5</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-d1t745-6">
   <w.rf>
    <LM>w#w-d1t745-6</LM>
   </w.rf>
   <form>kouřil</form>
   <lemma>kouřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t745-7">
   <w.rf>
    <LM>w#w-d1t745-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t747-2">
   <w.rf>
    <LM>w#w-d1t747-2</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t747-1">
   <w.rf>
    <LM>w#w-d1t747-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m023-d-id67432-punct">
   <w.rf>
    <LM>w#w-d-id67432-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t747-4">
   <w.rf>
    <LM>w#w-d1t747-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t747-5">
   <w.rf>
    <LM>w#w-d1t747-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t747-6">
   <w.rf>
    <LM>w#w-d1t747-6</LM>
   </w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d1t747-7">
   <w.rf>
    <LM>w#w-d1t747-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t747-8">
   <w.rf>
    <LM>w#w-d1t747-8</LM>
   </w.rf>
   <form>vliv</form>
   <lemma>vliv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1t750-1">
   <w.rf>
    <LM>w#w-d1t750-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t750-2">
   <w.rf>
    <LM>w#w-d1t750-2</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m023-d1t750-3">
   <w.rf>
    <LM>w#w-d1t750-3</LM>
   </w.rf>
   <form>cévy</form>
   <lemma>céva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m023-632-633">
   <w.rf>
    <LM>w#w-632-633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-634">
  <m id="m023-d1t750-7">
   <w.rf>
    <LM>w#w-d1t750-7</LM>
   </w.rf>
   <form>Nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m023-d1t750-5">
   <w.rf>
    <LM>w#w-d1t750-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m023-d1t750-8">
   <w.rf>
    <LM>w#w-d1t750-8</LM>
   </w.rf>
   <form>odpustit</form>
   <lemma>odpustit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m023-d1t750-9">
   <w.rf>
    <LM>w#w-d1t750-9</LM>
   </w.rf>
   <form>kouření</form>
   <lemma>kouření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m023-634-635">
   <w.rf>
    <LM>w#w-634-635</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-636">
  <m id="m023-d1t752-1">
   <w.rf>
    <LM>w#w-d1t752-1</LM>
   </w.rf>
   <form>Kouřil</form>
   <lemma>kouřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m023-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>cigaretu</form>
   <lemma>cigareta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m023-d1t752-5">
   <w.rf>
    <LM>w#w-d1t752-5</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m023-d1t752-6">
   <w.rf>
    <LM>w#w-d1t752-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t752-9">
   <w.rf>
    <LM>w#w-d1t752-9</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m023-d-id67821-punct">
   <w.rf>
    <LM>w#w-d-id67821-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t754-1">
   <w.rf>
    <LM>w#w-d1t754-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t754-2">
   <w.rf>
    <LM>w#w-d1t754-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t754-3">
   <w.rf>
    <LM>w#w-d1t754-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d1t754-4">
   <w.rf>
    <LM>w#w-d1t754-4</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-d1t754-5">
   <w.rf>
    <LM>w#w-d1t754-5</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t754-6">
   <w.rf>
    <LM>w#w-d1t754-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m023-d-m-d1e736-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e736-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e755-x2">
  <m id="m023-d1t758-1">
   <w.rf>
    <LM>w#w-d1t758-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d-m-d1e755-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e755-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e765-x2">
  <m id="m023-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m023-d1t768-2">
   <w.rf>
    <LM>w#w-d1t768-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d-id68232-punct">
   <w.rf>
    <LM>w#w-d-id68232-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e769-x2">
  <m id="m023-d1t772-3">
   <w.rf>
    <LM>w#w-d1t772-3</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t772-4">
   <w.rf>
    <LM>w#w-d1t772-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m023-d1e769-x2-671">
   <w.rf>
    <LM>w#w-d1e769-x2-671</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t772-5">
   <w.rf>
    <LM>w#w-d1t772-5</LM>
   </w.rf>
   <form>čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m023-d1t772-6">
   <w.rf>
    <LM>w#w-d1t772-6</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d1t772-7">
   <w.rf>
    <LM>w#w-d1t772-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1e769-x2-672">
   <w.rf>
    <LM>w#w-d1e769-x2-672</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-673">
  <m id="m023-d1t774-2">
   <w.rf>
    <LM>w#w-d1t774-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t774-3">
   <w.rf>
    <LM>w#w-d1t774-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t774-5">
   <w.rf>
    <LM>w#w-d1t774-5</LM>
   </w.rf>
   <form>zemědělcem</form>
   <lemma>zemědělec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m023-673-674">
   <w.rf>
    <LM>w#w-673-674</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-675">
  <m id="m023-d1t774-7">
   <w.rf>
    <LM>w#w-d1t774-7</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d-id68499-punct">
   <w.rf>
    <LM>w#w-d-id68499-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t776-1">
   <w.rf>
    <LM>w#w-d1t776-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t776-2">
   <w.rf>
    <LM>w#w-d1t776-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t776-4">
   <w.rf>
    <LM>w#w-d1t776-4</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m023-d1t776-5">
   <w.rf>
    <LM>w#w-d1t776-5</LM>
   </w.rf>
   <form>sourozenci</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m023-675-676">
   <w.rf>
    <LM>w#w-675-676</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-677">
  <m id="m023-d1t778-1">
   <w.rf>
    <LM>w#w-d1t778-1</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m023-d1t776-8">
   <w.rf>
    <LM>w#w-d1t776-8</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m023-d1t778-2">
   <w.rf>
    <LM>w#w-d1t778-2</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d1t778-3">
   <w.rf>
    <LM>w#w-d1t778-3</LM>
   </w.rf>
   <form>bydlel</form>
   <lemma>bydlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t778-4">
   <w.rf>
    <LM>w#w-d1t778-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t778-6">
   <w.rf>
    <LM>w#w-d1t778-6</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t778-8">
   <w.rf>
    <LM>w#w-d1t778-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t778-10">
   <w.rf>
    <LM>w#w-d1t778-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t778-12">
   <w.rf>
    <LM>w#w-d1t778-12</LM>
   </w.rf>
   <form>malou</form>
   <lemma>malý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-d1t780-1">
   <w.rf>
    <LM>w#w-d1t780-1</LM>
   </w.rf>
   <form>fabričku</form>
   <lemma>fabrička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t780-2">
   <w.rf>
    <LM>w#w-d1t780-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t780-3">
   <w.rf>
    <LM>w#w-d1t780-3</LM>
   </w.rf>
   <form>baterie</form>
   <lemma>baterie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m023-677-185">
   <w.rf>
    <LM>w#w-677-185</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-186">
  <m id="m023-d1t780-6">
   <w.rf>
    <LM>w#w-d1t780-6</LM>
   </w.rf>
   <form>Otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m023-d1t780-7">
   <w.rf>
    <LM>w#w-d1t780-7</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m023-d1t780-8">
   <w.rf>
    <LM>w#w-d1t780-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t780-9">
   <w.rf>
    <LM>w#w-d1t780-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t780-10">
   <w.rf>
    <LM>w#w-d1t780-10</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t780-11">
   <w.rf>
    <LM>w#w-d1t780-11</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t783-1">
   <w.rf>
    <LM>w#w-d1t783-1</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t783-2">
   <w.rf>
    <LM>w#w-d1t783-2</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m023-677-679">
   <w.rf>
    <LM>w#w-677-679</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-680">
  <m id="m023-d1t783-3">
   <w.rf>
    <LM>w#w-d1t783-3</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t783-4">
   <w.rf>
    <LM>w#w-d1t783-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t783-6">
   <w.rf>
    <LM>w#w-d1t783-6</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m023-d1t783-7">
   <w.rf>
    <LM>w#w-d1t783-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t783-8">
   <w.rf>
    <LM>w#w-d1t783-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t783-9">
   <w.rf>
    <LM>w#w-d1t783-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t783-10">
   <w.rf>
    <LM>w#w-d1t783-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t783-19">
   <w.rf>
    <LM>w#w-d1t783-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t783-21">
   <w.rf>
    <LM>w#w-d1t783-21</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t785-1">
   <w.rf>
    <LM>w#w-d1t785-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m023-d1t785-2">
   <w.rf>
    <LM>w#w-d1t785-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m023-d1t783-11">
   <w.rf>
    <LM>w#w-d1t783-11</LM>
   </w.rf>
   <form>vyfocený</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m023-680-681">
   <w.rf>
    <LM>w#w-680-681</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-682">
  <m id="m023-d1t783-12">
   <w.rf>
    <LM>w#w-d1t783-12</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m023-d-id69117-punct">
   <w.rf>
    <LM>w#w-d-id69117-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t783-14">
   <w.rf>
    <LM>w#w-d1t783-14</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t783-15">
   <w.rf>
    <LM>w#w-d1t783-15</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m023-d1t783-16">
   <w.rf>
    <LM>w#w-d1t783-16</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t783-17">
   <w.rf>
    <LM>w#w-d1t783-17</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m023-d1t783-18">
   <w.rf>
    <LM>w#w-d1t783-18</LM>
   </w.rf>
   <form>vybranou</form>
   <lemma>vybraný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-682-683">
   <w.rf>
    <LM>w#w-682-683</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e769-x3">
  <m id="m023-d1t785-5">
   <w.rf>
    <LM>w#w-d1t785-5</LM>
   </w.rf>
   <form>Přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t785-6">
   <w.rf>
    <LM>w#w-d1t785-6</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t785-7">
   <w.rf>
    <LM>w#w-d1t785-7</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t785-8">
   <w.rf>
    <LM>w#w-d1t785-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t785-10">
   <w.rf>
    <LM>w#w-d1t785-10</LM>
   </w.rf>
   <form>strejdy</form>
   <lemma>strejda</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m023-d1e769-x3-692">
   <w.rf>
    <LM>w#w-d1e769-x3-692</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t785-11">
   <w.rf>
    <LM>w#w-d1t785-11</LM>
   </w.rf>
   <form>opravovali</form>
   <lemma>opravovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t785-12">
   <w.rf>
    <LM>w#w-d1t785-12</LM>
   </w.rf>
   <form>baterie</form>
   <lemma>baterie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m023-d1t785-13">
   <w.rf>
    <LM>w#w-d1t785-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t785-14">
   <w.rf>
    <LM>w#w-d1t785-14</LM>
   </w.rf>
   <form>aut</form>
   <lemma>auto</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m023-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m023-d1t787-5">
   <w.rf>
    <LM>w#w-d1t787-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t787-6">
   <w.rf>
    <LM>w#w-d1t787-6</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d1t787-7">
   <w.rf>
    <LM>w#w-d1t787-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t787-8">
   <w.rf>
    <LM>w#w-d1t787-8</LM>
   </w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m023-d-m-d1e769-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e769-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e802-x2">
  <m id="m023-d1t805-1">
   <w.rf>
    <LM>w#w-d1t805-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t805-2">
   <w.rf>
    <LM>w#w-d1t805-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m023-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m023-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m023-d-id69799-punct">
   <w.rf>
    <LM>w#w-d-id69799-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e806-x2">
  <m id="m023-d1t809-3">
   <w.rf>
    <LM>w#w-d1t809-3</LM>
   </w.rf>
   <form>Máti</form>
   <lemma>máti</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m023-d1t809-4">
   <w.rf>
    <LM>w#w-d1t809-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m023-d1t809-5">
   <w.rf>
    <LM>w#w-d1t809-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t809-6">
   <w.rf>
    <LM>w#w-d1t809-6</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m023-d1e806-x2-723">
   <w.rf>
    <LM>w#w-d1e806-x2-723</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1e806-x2-724">
   <w.rf>
    <LM>w#w-d1e806-x2-724</LM>
   </w.rf>
   <form>drobná</form>
   <lemma>drobný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m023-d1t813-1">
   <w.rf>
    <LM>w#w-d1t813-1</LM>
   </w.rf>
   <form>zemědělkyně</form>
   <lemma>zemědělkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m023-d1t813-2">
   <w.rf>
    <LM>w#w-d1t813-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t813-3">
   <w.rf>
    <LM>w#w-d1t813-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t813-4">
   <w.rf>
    <LM>w#w-d1t813-4</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m023-d1t813-5">
   <w.rf>
    <LM>w#w-d1t813-5</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m023-d1t813-6">
   <w.rf>
    <LM>w#w-d1t813-6</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1t813-7">
   <w.rf>
    <LM>w#w-d1t813-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t813-8">
   <w.rf>
    <LM>w#w-d1t813-8</LM>
   </w.rf>
   <form>JZD</form>
   <lemma>JZD_^(Jednotné_zemědělské_družstvo)</lemma>
   <tag>BNNXX-----A----</tag>
  </m>
  <m id="m023-d1t815-1">
   <w.rf>
    <LM>w#w-d1t815-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t815-3">
   <w.rf>
    <LM>w#w-d1t815-3</LM>
   </w.rf>
   <form>Litohlavech</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m023-d1e806-x2-725">
   <w.rf>
    <LM>w#w-d1e806-x2-725</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-726">
  <m id="m023-d1t815-5">
   <w.rf>
    <LM>w#w-d1t815-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t815-6">
   <w.rf>
    <LM>w#w-d1t815-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d1t815-7">
   <w.rf>
    <LM>w#w-d1t815-7</LM>
   </w.rf>
   <form>JZD</form>
   <lemma>JZD_^(Jednotné_zemědělské_družstvo)</lemma>
   <tag>BNNXX-----A----</tag>
  </m>
  <m id="m023-726-727">
   <w.rf>
    <LM>w#w-726-727</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-726-728">
   <w.rf>
    <LM>w#w-726-728</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m023-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t820-3">
   <w.rf>
    <LM>w#w-d1t820-3</LM>
   </w.rf>
   <form>spadlo</form>
   <lemma>spadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m023-d1t820-4">
   <w.rf>
    <LM>w#w-d1t820-4</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t820-6">
   <w.rf>
    <LM>w#w-d1t820-6</LM>
   </w.rf>
   <form>Osek</form>
   <lemma>Osek_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-726-729">
   <w.rf>
    <LM>w#w-726-729</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-730">
  <m id="m023-d1t820-11">
   <w.rf>
    <LM>w#w-d1t820-11</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m023-d1t820-12">
   <w.rf>
    <LM>w#w-d1t820-12</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1t824-2">
   <w.rf>
    <LM>w#w-d1t824-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1t824-3">
   <w.rf>
    <LM>w#w-d1t824-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t824-4">
   <w.rf>
    <LM>w#w-d1t824-4</LM>
   </w.rf>
   <form>pozdního</form>
   <lemma>pozdní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m023-d1t824-5">
   <w.rf>
    <LM>w#w-d1t824-5</LM>
   </w.rf>
   <form>stáří</form>
   <lemma>stáří</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m023-d1t820-13">
   <w.rf>
    <LM>w#w-d1t820-13</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m023-d1t822-1">
   <w.rf>
    <LM>w#w-d1t822-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t822-2">
   <w.rf>
    <LM>w#w-d1t822-2</LM>
   </w.rf>
   <form>JZD</form>
   <lemma>JZD_^(Jednotné_zemědělské_družstvo)</lemma>
   <tag>BNNXX-----A----</tag>
  </m>
  <m id="m023-730-367">
   <w.rf>
    <LM>w#w-730-367</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-368">
  <m id="m023-d1t824-8">
   <w.rf>
    <LM>w#w-d1t824-8</LM>
   </w.rf>
   <form>Zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m023-730-732">
   <w.rf>
    <LM>w#w-730-732</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t826-1">
   <w.rf>
    <LM>w#w-d1t826-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t826-3">
   <w.rf>
    <LM>w#w-d1t826-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m023-d1t826-2">
   <w.rf>
    <LM>w#w-d1t826-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-730-731">
   <w.rf>
    <LM>w#w-730-731</LM>
   </w.rf>
   <form>83</form>
   <lemma>83</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m023-d1t826-6">
   <w.rf>
    <LM>w#w-d1t826-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m023-730-733">
   <w.rf>
    <LM>w#w-730-733</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e806-x3">
  <m id="m023-d1t833-5">
   <w.rf>
    <LM>w#w-d1t833-5</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-d1t833-4">
   <w.rf>
    <LM>w#w-d1t833-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m023-d1t833-3">
   <w.rf>
    <LM>w#w-d1t833-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t833-6">
   <w.rf>
    <LM>w#w-d1t833-6</LM>
   </w.rf>
   <form>bavilo</form>
   <lemma>bavit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d-m-d1e806-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e806-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e837-x2">
  <m id="m023-d1t840-1">
   <w.rf>
    <LM>w#w-d1t840-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t840-2">
   <w.rf>
    <LM>w#w-d1t840-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m023-d1t840-3">
   <w.rf>
    <LM>w#w-d1t840-3</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m023-d1t840-4">
   <w.rf>
    <LM>w#w-d1t840-4</LM>
   </w.rf>
   <form>věk</form>
   <lemma>věk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m023-d-m-d1e837-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e837-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e841-x2">
  <m id="m023-d1t846-4">
   <w.rf>
    <LM>w#w-d1t846-4</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1e841-x2-740">
   <w.rf>
    <LM>w#w-d1e841-x2-740</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t846-2">
   <w.rf>
    <LM>w#w-d1t846-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m023-d1t846-3">
   <w.rf>
    <LM>w#w-d1t846-3</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m023-d-m-d1e841-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e841-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e847-x2">
  <m id="m023-d1t850-1">
   <w.rf>
    <LM>w#w-d1t850-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t850-2">
   <w.rf>
    <LM>w#w-d1t850-2</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m023-d1t850-3">
   <w.rf>
    <LM>w#w-d1t850-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t850-4">
   <w.rf>
    <LM>w#w-d1t850-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d-id71295-punct">
   <w.rf>
    <LM>w#w-d-id71295-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e851-x2">
  <m id="m023-d1t854-2">
   <w.rf>
    <LM>w#w-d1t854-2</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m023-d-id71381-punct">
   <w.rf>
    <LM>w#w-d-id71381-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t854-4">
   <w.rf>
    <LM>w#w-d1t854-4</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t854-5">
   <w.rf>
    <LM>w#w-d1t854-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m023-d1t856-1">
   <w.rf>
    <LM>w#w-d1t856-1</LM>
   </w.rf>
   <form>nefotila</form>
   <lemma>fotit</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m023-d1e851-x2-748">
   <w.rf>
    <LM>w#w-d1e851-x2-748</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-749">
  <m id="m023-d1t858-1">
   <w.rf>
    <LM>w#w-d1t858-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m023-749-750">
   <w.rf>
    <LM>w#w-749-750</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t858-2">
   <w.rf>
    <LM>w#w-d1t858-2</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t858-4">
   <w.rf>
    <LM>w#w-d1t858-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m023-d1t858-5">
   <w.rf>
    <LM>w#w-d1t858-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t858-7">
   <w.rf>
    <LM>w#w-d1t858-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d-m-d1e851-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e851-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e859-x2">
  <m id="m023-d1t864-1">
   <w.rf>
    <LM>w#w-d1t864-1</LM>
   </w.rf>
   <form>Nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m023-d1e859-x2-757">
   <w.rf>
    <LM>w#w-d1e859-x2-757</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-758">
  <m id="m023-d1t864-3">
   <w.rf>
    <LM>w#w-d1t864-3</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m023-d1t864-4">
   <w.rf>
    <LM>w#w-d1t864-4</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-d1t864-5">
   <w.rf>
    <LM>w#w-d1t864-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t864-6">
   <w.rf>
    <LM>w#w-d1t864-6</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m023-d-id71707-punct">
   <w.rf>
    <LM>w#w-d-id71707-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e865-x2">
  <m id="m023-d1t872-1">
   <w.rf>
    <LM>w#w-d1t872-1</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1e865-x2-775">
   <w.rf>
    <LM>w#w-d1e865-x2-775</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-776">
  <m id="m023-d1t872-4">
   <w.rf>
    <LM>w#w-d1t872-4</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d-id71841-punct">
   <w.rf>
    <LM>w#w-d-id71841-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t872-6">
   <w.rf>
    <LM>w#w-d1t872-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t872-7">
   <w.rf>
    <LM>w#w-d1t872-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t872-8">
   <w.rf>
    <LM>w#w-d1t872-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t872-9">
   <w.rf>
    <LM>w#w-d1t872-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t872-11">
   <w.rf>
    <LM>w#w-d1t872-11</LM>
   </w.rf>
   <form>drobet</form>
   <lemma>drobet-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t872-10">
   <w.rf>
    <LM>w#w-d1t872-10</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m023-d-id71930-punct">
   <w.rf>
    <LM>w#w-d-id71930-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t874-2">
   <w.rf>
    <LM>w#w-d1t874-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t874-3">
   <w.rf>
    <LM>w#w-d1t874-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m023-d1t876-1">
   <w.rf>
    <LM>w#w-d1t876-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m023-d1t876-2">
   <w.rf>
    <LM>w#w-d1t876-2</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t874-4">
   <w.rf>
    <LM>w#w-d1t874-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m023-d1t874-5">
   <w.rf>
    <LM>w#w-d1t874-5</LM>
   </w.rf>
   <form>kluky</form>
   <lemma>kluk</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m023-776-386">
   <w.rf>
    <LM>w#w-776-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-387">
  <m id="m023-d1t876-6">
   <w.rf>
    <LM>w#w-d1t876-6</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-d1t876-7">
   <w.rf>
    <LM>w#w-d1t876-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m023-d1t876-8">
   <w.rf>
    <LM>w#w-d1t876-8</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t876-9">
   <w.rf>
    <LM>w#w-d1t876-9</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-776-778">
   <w.rf>
    <LM>w#w-776-778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-779">
  <m id="m023-d1t881-1">
   <w.rf>
    <LM>w#w-d1t881-1</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m023-d1t881-2">
   <w.rf>
    <LM>w#w-d1t881-2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m023-d1t879-1">
   <w.rf>
    <LM>w#w-d1t879-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m023-d1t879-2">
   <w.rf>
    <LM>w#w-d1t879-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t881-3">
   <w.rf>
    <LM>w#w-d1t881-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t881-4">
   <w.rf>
    <LM>w#w-d1t881-4</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t881-5">
   <w.rf>
    <LM>w#w-d1t881-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t881-6">
   <w.rf>
    <LM>w#w-d1t881-6</LM>
   </w.rf>
   <form>ledě</form>
   <lemma>led</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m023-d1t881-8">
   <w.rf>
    <LM>w#w-d1t881-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t881-9">
   <w.rf>
    <LM>w#w-d1t881-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t881-10">
   <w.rf>
    <LM>w#w-d1t881-10</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-779-780">
   <w.rf>
    <LM>w#w-779-780</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-781">
  <m id="m023-d1t881-11">
   <w.rf>
    <LM>w#w-d1t881-11</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t881-12">
   <w.rf>
    <LM>w#w-d1t881-12</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m023-d1t881-13">
   <w.rf>
    <LM>w#w-d1t881-13</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m023-d1t881-15">
   <w.rf>
    <LM>w#w-d1t881-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t881-14">
   <w.rf>
    <LM>w#w-d1t881-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t881-16">
   <w.rf>
    <LM>w#w-d1t881-16</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t883-1">
   <w.rf>
    <LM>w#w-d1t883-1</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-d1t883-2">
   <w.rf>
    <LM>w#w-d1t883-2</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t883-3">
   <w.rf>
    <LM>w#w-d1t883-3</LM>
   </w.rf>
   <form>sníh</form>
   <lemma>sníh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m023-d-id72471-punct">
   <w.rf>
    <LM>w#w-d-id72471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t883-5">
   <w.rf>
    <LM>w#w-d1t883-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t883-6">
   <w.rf>
    <LM>w#w-d1t883-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m023-d1t885-1">
   <w.rf>
    <LM>w#w-d1t885-1</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m023-d1t885-3">
   <w.rf>
    <LM>w#w-d1t885-3</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t885-4">
   <w.rf>
    <LM>w#w-d1t885-4</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t885-5">
   <w.rf>
    <LM>w#w-d1t885-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t885-6">
   <w.rf>
    <LM>w#w-d1t885-6</LM>
   </w.rf>
   <form>saních</form>
   <lemma>saně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-781-782">
   <w.rf>
    <LM>w#w-781-782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t885-8">
   <w.rf>
    <LM>w#w-d1t885-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t885-9">
   <w.rf>
    <LM>w#w-d1t885-9</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-781-783">
   <w.rf>
    <LM>w#w-781-783</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t885-10">
   <w.rf>
    <LM>w#w-d1t885-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t885-11">
   <w.rf>
    <LM>w#w-d1t885-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t885-14">
   <w.rf>
    <LM>w#w-d1t885-14</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-d1t885-15">
   <w.rf>
    <LM>w#w-d1t885-15</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t885-12">
   <w.rf>
    <LM>w#w-d1t885-12</LM>
   </w.rf>
   <form>bruslilo</form>
   <lemma>bruslit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-781-801">
   <w.rf>
    <LM>w#w-781-801</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e865-x3">
  <m id="m023-d1t887-1">
   <w.rf>
    <LM>w#w-d1t887-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t885-18">
   <w.rf>
    <LM>w#w-d1t885-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t885-17">
   <w.rf>
    <LM>w#w-d1t885-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m023-d1t887-3">
   <w.rf>
    <LM>w#w-d1t887-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m023-d1e865-x3-394">
   <w.rf>
    <LM>w#w-d1e865-x3-394</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-395">
  <m id="m023-d1t887-6">
   <w.rf>
    <LM>w#w-d1t887-6</LM>
   </w.rf>
   <form>Dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m023-d-id72891-punct">
   <w.rf>
    <LM>w#w-d-id72891-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t887-8">
   <w.rf>
    <LM>w#w-d1t887-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m023-d1t887-9">
   <w.rf>
    <LM>w#w-d1t887-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t887-10">
   <w.rf>
    <LM>w#w-d1t887-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m023-d1t887-12">
   <w.rf>
    <LM>w#w-d1t887-12</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m023-d1e865-x3-809">
   <w.rf>
    <LM>w#w-d1e865-x3-809</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t887-13">
   <w.rf>
    <LM>w#w-d1t887-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m023-d1t887-14">
   <w.rf>
    <LM>w#w-d1t887-14</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d-id72995-punct">
   <w.rf>
    <LM>w#w-d-id72995-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t889-4">
   <w.rf>
    <LM>w#w-d1t889-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d1t889-2">
   <w.rf>
    <LM>w#w-d1t889-2</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-d1t889-3">
   <w.rf>
    <LM>w#w-d1t889-3</LM>
   </w.rf>
   <form>zimu</form>
   <lemma>zima-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d1t889-5">
   <w.rf>
    <LM>w#w-d1t889-5</LM>
   </w.rf>
   <form>strávil</form>
   <lemma>strávit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m023-d1t892-1">
   <w.rf>
    <LM>w#w-d1t892-1</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t892-2">
   <w.rf>
    <LM>w#w-d1t892-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-d1e865-x3-810">
   <w.rf>
    <LM>w#w-d1e865-x3-810</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t892-5">
   <w.rf>
    <LM>w#w-d1t892-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t892-6">
   <w.rf>
    <LM>w#w-d1t892-6</LM>
   </w.rf>
   <form>bruslích</form>
   <lemma>brusle</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-d1e865-x3-811">
   <w.rf>
    <LM>w#w-d1e865-x3-811</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t892-7">
   <w.rf>
    <LM>w#w-d1t892-7</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t892-8">
   <w.rf>
    <LM>w#w-d1t892-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t892-9">
   <w.rf>
    <LM>w#w-d1t892-9</LM>
   </w.rf>
   <form>saních</form>
   <lemma>saně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m023-d1e865-x3-812">
   <w.rf>
    <LM>w#w-d1e865-x3-812</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-813">
  <m id="m023-813-814">
   <w.rf>
    <LM>w#w-813-814</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m023-813-815">
   <w.rf>
    <LM>w#w-813-815</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m023-813-816">
   <w.rf>
    <LM>w#w-813-816</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m023-d1t894-2">
   <w.rf>
    <LM>w#w-d1t894-2</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m023-d-m-d1e865-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e865-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e895-x2">
  <m id="m023-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t898-2">
   <w.rf>
    <LM>w#w-d1t898-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m023-d1t898-3">
   <w.rf>
    <LM>w#w-d1t898-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t898-4">
   <w.rf>
    <LM>w#w-d1t898-4</LM>
   </w.rf>
   <form>dobrou</form>
   <lemma>dobrý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m023-d1t898-5">
   <w.rf>
    <LM>w#w-d1t898-5</LM>
   </w.rf>
   <form>partu</form>
   <lemma>parta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m023-d-id73469-punct">
   <w.rf>
    <LM>w#w-d-id73469-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e899-x2">
  <m id="m023-d1t902-1">
   <w.rf>
    <LM>w#w-d1t902-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m023-d1e899-x2-819">
   <w.rf>
    <LM>w#w-d1e899-x2-819</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t902-2">
   <w.rf>
    <LM>w#w-d1t902-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d-m-d1e899-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e899-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e905-x3">
  <m id="m023-d1t912-1">
   <w.rf>
    <LM>w#w-d1t912-1</LM>
   </w.rf>
   <form>Vyprávějte</form>
   <lemma>vyprávět</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m023-d1t912-2">
   <w.rf>
    <LM>w#w-d1t912-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m023-d1t912-3">
   <w.rf>
    <LM>w#w-d1t912-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m023-d-m-d1e905-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e905-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-d1e913-x2">
  <m id="m023-d1t920-1">
   <w.rf>
    <LM>w#w-d1t920-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t920-2">
   <w.rf>
    <LM>w#w-d1t920-2</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m023-d1t920-3">
   <w.rf>
    <LM>w#w-d1t920-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m023-d1t920-4">
   <w.rf>
    <LM>w#w-d1t920-4</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m023-d1t920-5">
   <w.rf>
    <LM>w#w-d1t920-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m023-d1t920-7">
   <w.rf>
    <LM>w#w-d1t920-7</LM>
   </w.rf>
   <form>Litohlavech</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m023-d1e913-x2-830">
   <w.rf>
    <LM>w#w-d1e913-x2-830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m023-831">
  <m id="m023-d1t920-10">
   <w.rf>
    <LM>w#w-d1t920-10</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m023-d1t920-9">
   <w.rf>
    <LM>w#w-d1t920-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t922-1">
   <w.rf>
    <LM>w#w-d1t922-1</LM>
   </w.rf>
   <form>pětitřídka</form>
   <lemma>pětitřídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m023-831-832">
   <w.rf>
    <LM>w#w-831-832</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t922-2">
   <w.rf>
    <LM>w#w-d1t922-2</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t922-3">
   <w.rf>
    <LM>w#w-d1t922-3</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m023-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t922-5">
   <w.rf>
    <LM>w#w-d1t922-5</LM>
   </w.rf>
   <form>páté</form>
   <lemma>pátý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m023-d1t922-6">
   <w.rf>
    <LM>w#w-d1t922-6</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m023-831-407">
   <w.rf>
    <LM>w#w-831-407</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m023-d1t922-7">
   <w.rf>
    <LM>w#w-d1t922-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m023-d1t922-8">
   <w.rf>
    <LM>w#w-d1t922-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m023-d1t922-9">
   <w.rf>
    <LM>w#w-d1t922-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m023-d1t922-10">
   <w.rf>
    <LM>w#w-d1t922-10</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m023-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m023-d1t924-3">
   <w.rf>
    <LM>w#w-d1t924-3</LM>
   </w.rf>
   <form>Rokycan</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m023-831-833">
   <w.rf>
    <LM>w#w-831-833</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
