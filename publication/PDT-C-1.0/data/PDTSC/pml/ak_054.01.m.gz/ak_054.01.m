<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_054.01.w.gz" />
  </references>
 </head>
 <s id="m054-d1e279-x3">
  <m id="m054-d1t286-1">
   <w.rf>
    <LM>w#w-d1t286-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t286-2">
   <w.rf>
    <LM>w#w-d1t286-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t286-3">
   <w.rf>
    <LM>w#w-d1t286-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t286-4">
   <w.rf>
    <LM>w#w-d1t286-4</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t286-5">
   <w.rf>
    <LM>w#w-d1t286-5</LM>
   </w.rf>
   <form>vypadalo</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d-id64735-punct">
   <w.rf>
    <LM>w#w-d-id64735-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e287-x2">
  <m id="m054-d1t290-9">
   <w.rf>
    <LM>w#w-d1t290-9</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t290-10">
   <w.rf>
    <LM>w#w-d1t290-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t290-11">
   <w.rf>
    <LM>w#w-d1t290-11</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t290-12">
   <w.rf>
    <LM>w#w-d1t290-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t290-14">
   <w.rf>
    <LM>w#w-d1t290-14</LM>
   </w.rf>
   <form>obrázku</form>
   <lemma>obrázek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d1e287-x2-263">
   <w.rf>
    <LM>w#w-d1e287-x2-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-264">
  <m id="m054-d1t292-6">
   <w.rf>
    <LM>w#w-d1t292-6</LM>
   </w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t292-8">
   <w.rf>
    <LM>w#w-d1t292-8</LM>
   </w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t292-2">
   <w.rf>
    <LM>w#w-d1t292-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t292-3">
   <w.rf>
    <LM>w#w-d1t292-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t292-1">
   <w.rf>
    <LM>w#w-d1t292-1</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t292-4">
   <w.rf>
    <LM>w#w-d1t292-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m054-d1t292-5">
   <w.rf>
    <LM>w#w-d1t292-5</LM>
   </w.rf>
   <form>nezměnilo</form>
   <lemma>změnit</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m054-264-265">
   <w.rf>
    <LM>w#w-264-265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-266">
  <m id="m054-d1t294-3">
   <w.rf>
    <LM>w#w-d1t294-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t294-4">
   <w.rf>
    <LM>w#w-d1t294-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t294-5">
   <w.rf>
    <LM>w#w-d1t294-5</LM>
   </w.rf>
   <form>stoleček</form>
   <lemma>stoleček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t294-6">
   <w.rf>
    <LM>w#w-d1t294-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t294-7">
   <w.rf>
    <LM>w#w-d1t294-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t294-8">
   <w.rf>
    <LM>w#w-d1t294-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t294-9">
   <w.rf>
    <LM>w#w-d1t294-9</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t298-1">
   <w.rf>
    <LM>w#w-d1t298-1</LM>
   </w.rf>
   <form>lavičky</form>
   <lemma>lavička-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-266-267">
   <w.rf>
    <LM>w#w-266-267</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-268">
  <m id="m054-d1t298-5">
   <w.rf>
    <LM>w#w-d1t298-5</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t298-6">
   <w.rf>
    <LM>w#w-d1t298-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t298-3">
   <w.rf>
    <LM>w#w-d1t298-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t298-7">
   <w.rf>
    <LM>w#w-d1t298-7</LM>
   </w.rf>
   <form>vypadalo</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t298-9">
   <w.rf>
    <LM>w#w-d1t298-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-268-269">
   <w.rf>
    <LM>w#w-268-269</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t298-13">
   <w.rf>
    <LM>w#w-d1t298-13</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t298-14">
   <w.rf>
    <LM>w#w-d1t298-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t298-15">
   <w.rf>
    <LM>w#w-d1t298-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t298-16">
   <w.rf>
    <LM>w#w-d1t298-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-268-270">
   <w.rf>
    <LM>w#w-268-270</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m054-d1t298-18">
   <w.rf>
    <LM>w#w-d1t298-18</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-268-271">
   <w.rf>
    <LM>w#w-268-271</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-272">
  <m id="m054-d1t298-19">
   <w.rf>
    <LM>w#w-d1t298-19</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t298-20">
   <w.rf>
    <LM>w#w-d1t298-20</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t298-21">
   <w.rf>
    <LM>w#w-d1t298-21</LM>
   </w.rf>
   <form>travička</form>
   <lemma>travička_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-272-273">
   <w.rf>
    <LM>w#w-272-273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-274">
  <m id="m054-d1t298-23">
   <w.rf>
    <LM>w#w-d1t298-23</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t298-24">
   <w.rf>
    <LM>w#w-d1t298-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t298-25">
   <w.rf>
    <LM>w#w-d1t298-25</LM>
   </w.rf>
   <form>kamínky</form>
   <lemma>kamínek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m054-274-275">
   <w.rf>
    <LM>w#w-274-275</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-276">
  <m id="m054-d1t301-4">
   <w.rf>
    <LM>w#w-d1t301-4</LM>
   </w.rf>
   <form>Travičky</form>
   <lemma>travička_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t301-5">
   <w.rf>
    <LM>w#w-d1t301-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t301-6">
   <w.rf>
    <LM>w#w-d1t301-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t301-7">
   <w.rf>
    <LM>w#w-d1t301-7</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m054-276-277">
   <w.rf>
    <LM>w#w-276-277</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-278">
  <m id="m054-d1t301-9">
   <w.rf>
    <LM>w#w-d1t301-9</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t301-10">
   <w.rf>
    <LM>w#w-d1t301-10</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1t301-13">
   <w.rf>
    <LM>w#w-d1t301-13</LM>
   </w.rf>
   <form>kořeny</form>
   <lemma>kořen-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m054-d1t301-15">
   <w.rf>
    <LM>w#w-d1t301-15</LM>
   </w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m054-d-m-d1e287-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e287-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e312-x2">
  <m id="m054-d1t315-1">
   <w.rf>
    <LM>w#w-d1t315-1</LM>
   </w.rf>
   <form>Kolem</form>
   <lemma>kolem-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t315-2">
   <w.rf>
    <LM>w#w-d1t315-2</LM>
   </w.rf>
   <form>dokola</form>
   <lemma>dokola</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t315-5">
   <w.rf>
    <LM>w#w-d1t315-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t315-6">
   <w.rf>
    <LM>w#w-d1t315-6</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t315-7">
   <w.rf>
    <LM>w#w-d1t315-7</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1e312-x2-297">
   <w.rf>
    <LM>w#w-d1e312-x2-297</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t315-10">
   <w.rf>
    <LM>w#w-d1t315-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t315-11">
   <w.rf>
    <LM>w#w-d1t315-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t315-12">
   <w.rf>
    <LM>w#w-d1t315-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t315-13">
   <w.rf>
    <LM>w#w-d1t315-13</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e312-x2-295">
   <w.rf>
    <LM>w#w-d1e312-x2-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-296">
  <m id="m054-d1t317-2">
   <w.rf>
    <LM>w#w-d1t317-2</LM>
   </w.rf>
   <form>Pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t317-1">
   <w.rf>
    <LM>w#w-d1t317-1</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t317-3">
   <w.rf>
    <LM>w#w-d1t317-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d-id66283-punct">
   <w.rf>
    <LM>w#w-d-id66283-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t317-5">
   <w.rf>
    <LM>w#w-d1t317-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t317-6">
   <w.rf>
    <LM>w#w-d1t317-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t317-7">
   <w.rf>
    <LM>w#w-d1t317-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m054-d1t317-8">
   <w.rf>
    <LM>w#w-d1t317-8</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t317-9">
   <w.rf>
    <LM>w#w-d1t317-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t317-10">
   <w.rf>
    <LM>w#w-d1t317-10</LM>
   </w.rf>
   <form>nestálo</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m054-d1t317-11">
   <w.rf>
    <LM>w#w-d1t317-11</LM>
   </w.rf>
   <form>sídliště</form>
   <lemma>sídliště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-296-298">
   <w.rf>
    <LM>w#w-296-298</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-299">
  <m id="m054-d1t317-16">
   <w.rf>
    <LM>w#w-d1t317-16</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t317-19">
   <w.rf>
    <LM>w#w-d1t317-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t317-18">
   <w.rf>
    <LM>w#w-d1t317-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t317-17">
   <w.rf>
    <LM>w#w-d1t317-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t317-21">
   <w.rf>
    <LM>w#w-d1t317-21</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t317-20">
   <w.rf>
    <LM>w#w-d1t317-20</LM>
   </w.rf>
   <form>změněné</form>
   <lemma>změněný_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-299-300">
   <w.rf>
    <LM>w#w-299-300</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-301">
  <m id="m054-d1t317-24">
   <w.rf>
    <LM>w#w-d1t317-24</LM>
   </w.rf>
   <form>Rybník</form>
   <lemma>rybník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t317-25">
   <w.rf>
    <LM>w#w-d1t317-25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t317-23">
   <w.rf>
    <LM>w#w-d1t317-23</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t317-26">
   <w.rf>
    <LM>w#w-d1t317-26</LM>
   </w.rf>
   <form>stejný</form>
   <lemma>stejný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-303-304">
   <w.rf>
    <LM>w#w-303-304</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t317-28">
   <w.rf>
    <LM>w#w-d1t317-28</LM>
   </w.rf>
   <form>přístup</form>
   <lemma>přístup</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t317-29">
   <w.rf>
    <LM>w#w-d1t317-29</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t317-31">
   <w.rf>
    <LM>w#w-d1t317-31</LM>
   </w.rf>
   <form>stejný</form>
   <lemma>stejný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t317-32">
   <w.rf>
    <LM>w#w-d1t317-32</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t317-33">
   <w.rf>
    <LM>w#w-d1t317-33</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t317-34">
   <w.rf>
    <LM>w#w-d1t317-34</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t317-35">
   <w.rf>
    <LM>w#w-d1t317-35</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t317-36">
   <w.rf>
    <LM>w#w-d1t317-36</LM>
   </w.rf>
   <form>stejná</form>
   <lemma>stejný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d-m-d1e312-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e312-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e324-x2">
  <m id="m054-d1t329-2">
   <w.rf>
    <LM>w#w-d1t329-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t329-3">
   <w.rf>
    <LM>w#w-d1t329-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t329-4">
   <w.rf>
    <LM>w#w-d1t329-4</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t329-5">
   <w.rf>
    <LM>w#w-d1t329-5</LM>
   </w.rf>
   <form>vzpomínka</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d-m-d1e324-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e324-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e324-x3">
  <m id="m054-d1t331-1">
   <w.rf>
    <LM>w#w-d1t331-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t331-2">
   <w.rf>
    <LM>w#w-d1t331-2</LM>
   </w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t331-3">
   <w.rf>
    <LM>w#w-d1t331-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1t331-4">
   <w.rf>
    <LM>w#w-d1t331-4</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m054-d1t331-5">
   <w.rf>
    <LM>w#w-d1t331-5</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d1e324-x3-306">
   <w.rf>
    <LM>w#w-d1e324-x3-306</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e332-x2">
  <m id="m054-d1t335-3">
   <w.rf>
    <LM>w#w-d1t335-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1e332-x2-316">
   <w.rf>
    <LM>w#w-d1e332-x2-316</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-317">
  <m id="m054-d1t335-6">
   <w.rf>
    <LM>w#w-d1t335-6</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t335-5">
   <w.rf>
    <LM>w#w-d1t335-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t335-7">
   <w.rf>
    <LM>w#w-d1t335-7</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m054-d1t335-8">
   <w.rf>
    <LM>w#w-d1t335-8</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-317-322">
   <w.rf>
    <LM>w#w-317-322</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t337-1">
   <w.rf>
    <LM>w#w-d1t337-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t337-2">
   <w.rf>
    <LM>w#w-d1t337-2</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m054-d1t337-3">
   <w.rf>
    <LM>w#w-d1t337-3</LM>
   </w.rf>
   <form>manželstvím</form>
   <lemma>manželství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m054-d1t337-4">
   <w.rf>
    <LM>w#w-d1t337-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t337-5">
   <w.rf>
    <LM>w#w-d1t337-5</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m054-d-id67216-punct">
   <w.rf>
    <LM>w#w-d-id67216-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t337-7">
   <w.rf>
    <LM>w#w-d1t337-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t337-8">
   <w.rf>
    <LM>w#w-d1t337-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t337-9">
   <w.rf>
    <LM>w#w-d1t337-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m054-d1t337-10">
   <w.rf>
    <LM>w#w-d1t337-10</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m054-319-320">
   <w.rf>
    <LM>w#w-319-320</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-321">
  <m id="m054-d1t337-13">
   <w.rf>
    <LM>w#w-d1t337-13</LM>
   </w.rf>
   <form>Opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t337-15">
   <w.rf>
    <LM>w#w-d1t337-15</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-321-323">
   <w.rf>
    <LM>w#w-321-323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-324">
  <m id="m054-d1t337-20">
   <w.rf>
    <LM>w#w-d1t337-20</LM>
   </w.rf>
   <form>Výborně</form>
   <lemma>výborně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t337-17">
   <w.rf>
    <LM>w#w-d1t337-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t337-18">
   <w.rf>
    <LM>w#w-d1t337-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t337-19">
   <w.rf>
    <LM>w#w-d1t337-19</LM>
   </w.rf>
   <form>shodli</form>
   <lemma>shodnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m054-324-325">
   <w.rf>
    <LM>w#w-324-325</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-326">
  <m id="m054-d1t341-3">
   <w.rf>
    <LM>w#w-d1t341-3</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t341-2">
   <w.rf>
    <LM>w#w-d1t341-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m054-326-327">
   <w.rf>
    <LM>w#w-326-327</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t341-5">
   <w.rf>
    <LM>w#w-d1t341-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-326-328">
   <w.rf>
    <LM>w#w-326-328</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t339-6">
   <w.rf>
    <LM>w#w-d1t339-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t339-7">
   <w.rf>
    <LM>w#w-d1t339-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t339-8">
   <w.rf>
    <LM>w#w-d1t339-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t339-9">
   <w.rf>
    <LM>w#w-d1t339-9</LM>
   </w.rf>
   <form>svobodná</form>
   <lemma>svobodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d-id67585-punct">
   <w.rf>
    <LM>w#w-d-id67585-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-326-329">
   <w.rf>
    <LM>w#w-326-329</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t341-8">
   <w.rf>
    <LM>w#w-d1t341-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t341-6">
   <w.rf>
    <LM>w#w-d1t341-6</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m054-d1t341-7">
   <w.rf>
    <LM>w#w-d1t341-7</LM>
   </w.rf>
   <form>plavky</form>
   <lemma>plavky</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t341-9">
   <w.rf>
    <LM>w#w-d1t341-9</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-326-330">
   <w.rf>
    <LM>w#w-326-330</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-331">
  <m id="m054-d1t346-1">
   <w.rf>
    <LM>w#w-d1t346-1</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t346-3">
   <w.rf>
    <LM>w#w-d1t346-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t346-4">
   <w.rf>
    <LM>w#w-d1t346-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t346-5">
   <w.rf>
    <LM>w#w-d1t346-5</LM>
   </w.rf>
   <form>módě</form>
   <lemma>móda_^(co_je_módní)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t346-2">
   <w.rf>
    <LM>w#w-d1t346-2</LM>
   </w.rf>
   <form>plavky</form>
   <lemma>plavky</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-331-332">
   <w.rf>
    <LM>w#w-331-332</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t346-9">
   <w.rf>
    <LM>w#w-d1t346-9</LM>
   </w.rf>
   <form>sukýnka</form>
   <lemma>sukýnka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t346-10">
   <w.rf>
    <LM>w#w-d1t346-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t346-11">
   <w.rf>
    <LM>w#w-d1t346-11</LM>
   </w.rf>
   <form>kalhotky</form>
   <lemma>kalhotky</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-331-333">
   <w.rf>
    <LM>w#w-331-333</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-334">
  <m id="m054-d1t346-16">
   <w.rf>
    <LM>w#w-d1t346-16</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t346-17">
   <w.rf>
    <LM>w#w-d1t346-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t346-18">
   <w.rf>
    <LM>w#w-d1t346-18</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d-m-d1e332-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e332-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e347-x2">
  <m id="m054-d1t350-1">
   <w.rf>
    <LM>w#w-d1t350-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t350-2">
   <w.rf>
    <LM>w#w-d1t350-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t350-3">
   <w.rf>
    <LM>w#w-d1t350-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d-m-d1e347-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e347-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e351-x2">
  <m id="m054-d1t354-1">
   <w.rf>
    <LM>w#w-d1t354-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1e351-x2-336">
   <w.rf>
    <LM>w#w-d1e351-x2-336</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e355-x2">
  <m id="m054-d1t358-1">
   <w.rf>
    <LM>w#w-d1t358-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t358-2">
   <w.rf>
    <LM>w#w-d1t358-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t358-3">
   <w.rf>
    <LM>w#w-d1t358-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d-m-d1e355-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e355-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e359-x2">
  <m id="m054-d1t364-6">
   <w.rf>
    <LM>w#w-d1t364-6</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t364-7">
   <w.rf>
    <LM>w#w-d1t364-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t364-8">
   <w.rf>
    <LM>w#w-d1t364-8</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t364-9">
   <w.rf>
    <LM>w#w-d1t364-9</LM>
   </w.rf>
   <form>móda</form>
   <lemma>móda_^(co_je_módní)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1e359-x2-346">
   <w.rf>
    <LM>w#w-d1e359-x2-346</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-347">
  <m id="m054-d1t364-15">
   <w.rf>
    <LM>w#w-d1t364-15</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m054-d1t364-16">
   <w.rf>
    <LM>w#w-d1t364-16</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t364-17">
   <w.rf>
    <LM>w#w-d1t364-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t364-18">
   <w.rf>
    <LM>w#w-d1t364-18</LM>
   </w.rf>
   <form>nekoupala</form>
   <lemma>koupat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d-id68655-punct">
   <w.rf>
    <LM>w#w-d-id68655-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t364-21">
   <w.rf>
    <LM>w#w-d1t364-21</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d1t364-22">
   <w.rf>
    <LM>w#w-d1t364-22</LM>
   </w.rf>
   <form>milovnice</form>
   <lemma>milovnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-349-350">
   <w.rf>
    <LM>w#w-349-350</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-347-357">
   <w.rf>
    <LM>w#w-347-357</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-358">
  <m id="m054-d1t366-2">
   <w.rf>
    <LM>w#w-d1t366-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t366-3">
   <w.rf>
    <LM>w#w-d1t366-3</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t366-4">
   <w.rf>
    <LM>w#w-d1t366-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t366-1">
   <w.rf>
    <LM>w#w-d1t366-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t366-5">
   <w.rf>
    <LM>w#w-d1t366-5</LM>
   </w.rf>
   <form>plavec</form>
   <lemma>plavec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-358-359">
   <w.rf>
    <LM>w#w-358-359</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t366-8">
   <w.rf>
    <LM>w#w-d1t366-8</LM>
   </w.rf>
   <form>přeplaval</form>
   <lemma>přeplavat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t366-10">
   <w.rf>
    <LM>w#w-d1t366-10</LM>
   </w.rf>
   <form>Bolevecký</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m054-d1t366-12">
   <w.rf>
    <LM>w#w-d1t366-12</LM>
   </w.rf>
   <form>rybník</form>
   <lemma>rybník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-349-351">
   <w.rf>
    <LM>w#w-349-351</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-352">
  <m id="m054-d1t368-2">
   <w.rf>
    <LM>w#w-d1t368-2</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t368-3">
   <w.rf>
    <LM>w#w-d1t368-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m054-d1t368-4">
   <w.rf>
    <LM>w#w-d1t368-4</LM>
   </w.rf>
   <form>přeplaval</form>
   <lemma>přeplavat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t370-1">
   <w.rf>
    <LM>w#w-d1t370-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t370-3">
   <w.rf>
    <LM>w#w-d1t370-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t370-2">
   <w.rf>
    <LM>w#w-d1t370-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m054-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t370-5">
   <w.rf>
    <LM>w#w-d1t370-5</LM>
   </w.rf>
   <form>zádech</form>
   <lemma>záda</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m054-352-363">
   <w.rf>
    <LM>w#w-352-363</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-364">
  <m id="m054-d1t370-8">
   <w.rf>
    <LM>w#w-d1t370-8</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t380-1">
   <w.rf>
    <LM>w#w-d1t380-1</LM>
   </w.rf>
   <form>ohromný</form>
   <lemma>ohromný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-d1t380-2">
   <w.rf>
    <LM>w#w-d1t380-2</LM>
   </w.rf>
   <form>plavec</form>
   <lemma>plavec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-364-367">
   <w.rf>
    <LM>w#w-364-367</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e381-x3">
  <m id="m054-d1t388-1">
   <w.rf>
    <LM>w#w-d1t388-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t388-2">
   <w.rf>
    <LM>w#w-d1t388-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t388-3">
   <w.rf>
    <LM>w#w-d1t388-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t388-4">
   <w.rf>
    <LM>w#w-d1t388-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t388-5">
   <w.rf>
    <LM>w#w-d1t388-5</LM>
   </w.rf>
   <form>naposledy</form>
   <lemma>naposledy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d-id69436-punct">
   <w.rf>
    <LM>w#w-d-id69436-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e389-x2">
  <m id="m054-d1t392-1">
   <w.rf>
    <LM>w#w-d1t392-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t392-4">
   <w.rf>
    <LM>w#w-d1t392-4</LM>
   </w.rf>
   <form>Boleveckém</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m054-d1t392-6">
   <w.rf>
    <LM>w#w-d1t392-6</LM>
   </w.rf>
   <form>rybníku</form>
   <lemma>rybník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d-id69577-punct">
   <w.rf>
    <LM>w#w-d-id69577-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-387"></s>
 <s id="m054-d1e399-x2">
  <m id="m054-d1t404-8">
   <w.rf>
    <LM>w#w-d1t404-8</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-7">
   <w.rf>
    <LM>w#w-d1t404-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t404-6">
   <w.rf>
    <LM>w#w-d1t404-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-9">
   <w.rf>
    <LM>w#w-d1t404-9</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t404-10">
   <w.rf>
    <LM>w#w-d1t404-10</LM>
   </w.rf>
   <form>bruslit</form>
   <lemma>bruslit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1e399-x2-389">
   <w.rf>
    <LM>w#w-d1e399-x2-389</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-390">
  <m id="m054-d1t404-14">
   <w.rf>
    <LM>w#w-d1t404-14</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m054-d1t404-15">
   <w.rf>
    <LM>w#w-d1t404-15</LM>
   </w.rf>
   <form>dobou</form>
   <lemma>doba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m054-d1t404-16">
   <w.rf>
    <LM>w#w-d1t404-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t404-17">
   <w.rf>
    <LM>w#w-d1t404-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-18">
   <w.rf>
    <LM>w#w-d1t404-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-20">
   <w.rf>
    <LM>w#w-d1t404-20</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-390-391">
   <w.rf>
    <LM>w#w-390-391</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-392">
  <m id="m054-d1t404-26">
   <w.rf>
    <LM>w#w-d1t404-26</LM>
   </w.rf>
   <form>Teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-23">
   <w.rf>
    <LM>w#w-d1t404-23</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-24">
   <w.rf>
    <LM>w#w-d1t404-24</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t404-25">
   <w.rf>
    <LM>w#w-d1t404-25</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t404-27">
   <w.rf>
    <LM>w#w-d1t404-27</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m054-d-id70088-punct">
   <w.rf>
    <LM>w#w-d-id70088-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t406-1">
   <w.rf>
    <LM>w#w-d1t406-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t406-2">
   <w.rf>
    <LM>w#w-d1t406-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m054-d1t406-3">
   <w.rf>
    <LM>w#w-d1t406-3</LM>
   </w.rf>
   <form>lhala</form>
   <lemma>lhát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-392-393">
   <w.rf>
    <LM>w#w-392-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-394">
  <m id="m054-d1t406-6">
   <w.rf>
    <LM>w#w-d1t406-6</LM>
   </w.rf>
   <form>Bruslit</form>
   <lemma>bruslit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1t406-7">
   <w.rf>
    <LM>w#w-d1t406-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t406-8">
   <w.rf>
    <LM>w#w-d1t406-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t406-5">
   <w.rf>
    <LM>w#w-d1t406-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t406-9">
   <w.rf>
    <LM>w#w-d1t406-9</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-394-395">
   <w.rf>
    <LM>w#w-394-395</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-396">
  <m id="m054-d1t408-3">
   <w.rf>
    <LM>w#w-d1t408-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t408-4">
   <w.rf>
    <LM>w#w-d1t408-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t408-5">
   <w.rf>
    <LM>w#w-d1t408-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t408-7">
   <w.rf>
    <LM>w#w-d1t408-7</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m054-d1t408-6">
   <w.rf>
    <LM>w#w-d1t408-6</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d-id70342-punct">
   <w.rf>
    <LM>w#w-d-id70342-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t410-1">
   <w.rf>
    <LM>w#w-d1t410-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t413-1">
   <w.rf>
    <LM>w#w-d1t413-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t413-2">
   <w.rf>
    <LM>w#w-d1t413-2</LM>
   </w.rf>
   <form>chodily</form>
   <lemma>chodit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t413-3">
   <w.rf>
    <LM>w#w-d1t413-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t413-4">
   <w.rf>
    <LM>w#w-d1t413-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t413-7">
   <w.rf>
    <LM>w#w-d1t413-7</LM>
   </w.rf>
   <form>Bolevecký</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m054-d1t413-9">
   <w.rf>
    <LM>w#w-d1t413-9</LM>
   </w.rf>
   <form>rybník</form>
   <lemma>rybník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-396-397">
   <w.rf>
    <LM>w#w-396-397</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-398">
  <m id="m054-d1t415-1">
   <w.rf>
    <LM>w#w-d1t415-1</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t415-2">
   <w.rf>
    <LM>w#w-d1t415-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t415-4">
   <w.rf>
    <LM>w#w-d1t415-4</LM>
   </w.rf>
   <form>přešly</form>
   <lemma>přejít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m054-d1t415-6">
   <w.rf>
    <LM>w#w-d1t415-6</LM>
   </w.rf>
   <form>lávku</form>
   <lemma>lávka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d-id70612-punct">
   <w.rf>
    <LM>w#w-d-id70612-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t415-8">
   <w.rf>
    <LM>w#w-d1t415-8</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m054-d1t415-9">
   <w.rf>
    <LM>w#w-d1t415-9</LM>
   </w.rf>
   <form>vedla</form>
   <lemma>vést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t415-11">
   <w.rf>
    <LM>w#w-d1t415-11</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-398-399">
   <w.rf>
    <LM>w#w-398-399</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-400">
  <m id="m054-d1t415-14">
   <w.rf>
    <LM>w#w-d1t415-14</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t415-13">
   <w.rf>
    <LM>w#w-d1t415-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t415-17">
   <w.rf>
    <LM>w#w-d1t415-17</LM>
   </w.rf>
   <form>vepředu</form>
   <lemma>vepředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e399-x3-406">
   <w.rf>
    <LM>w#w-d1e399-x3-406</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t417-1">
   <w.rf>
    <LM>w#w-d1t417-1</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m054-d1t417-2">
   <w.rf>
    <LM>w#w-d1t417-2</LM>
   </w.rf>
   <form>nemusely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m054-d1t417-3">
   <w.rf>
    <LM>w#w-d1t417-3</LM>
   </w.rf>
   <form>platit</form>
   <lemma>platit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1e399-x3-407">
   <w.rf>
    <LM>w#w-d1e399-x3-407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-408">
  <m id="m054-d1t417-4">
   <w.rf>
    <LM>w#w-d1t417-4</LM>
   </w.rf>
   <form>Vepředu</form>
   <lemma>vepředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t417-7">
   <w.rf>
    <LM>w#w-d1t417-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t417-9">
   <w.rf>
    <LM>w#w-d1t417-9</LM>
   </w.rf>
   <form>Boleveckém</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m054-d1t417-11">
   <w.rf>
    <LM>w#w-d1t417-11</LM>
   </w.rf>
   <form>rybníku</form>
   <lemma>rybník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d1t417-5">
   <w.rf>
    <LM>w#w-d1t417-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t417-6">
   <w.rf>
    <LM>w#w-d1t417-6</LM>
   </w.rf>
   <form>neplatilo</form>
   <lemma>platit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m054-d-id70936-punct">
   <w.rf>
    <LM>w#w-d-id70936-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t419-1">
   <w.rf>
    <LM>w#w-d1t419-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>přešel</form>
   <lemma>přejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t426-4">
   <w.rf>
    <LM>w#w-d1t426-4</LM>
   </w.rf>
   <form>lávku</form>
   <lemma>lávka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d-id71088-punct">
   <w.rf>
    <LM>w#w-d-id71088-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t426-6">
   <w.rf>
    <LM>w#w-d1t426-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t434-1">
   <w.rf>
    <LM>w#w-d1t434-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t434-2">
   <w.rf>
    <LM>w#w-d1t434-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t434-3">
   <w.rf>
    <LM>w#w-d1t434-3</LM>
   </w.rf>
   <form>výběrčí</form>
   <lemma>výběrčí-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-408-224">
   <w.rf>
    <LM>w#w-408-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-225">
  <m id="m054-d1t434-7">
   <w.rf>
    <LM>w#w-d1t434-7</LM>
   </w.rf>
   <form>Platilo</form>
   <lemma>platit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t434-6">
   <w.rf>
    <LM>w#w-d1t434-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t434-5">
   <w.rf>
    <LM>w#w-d1t434-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t434-10">
   <w.rf>
    <LM>w#w-d1t434-10</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t434-8">
   <w.rf>
    <LM>w#w-d1t434-8</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m054-d1t434-9">
   <w.rf>
    <LM>w#w-d1t434-9</LM>
   </w.rf>
   <form>haléřů</form>
   <lemma>haléř</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m054-d-m-d1e431-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e431-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e435-x2">
  <m id="m054-d1t440-2">
   <w.rf>
    <LM>w#w-d1t440-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t440-3">
   <w.rf>
    <LM>w#w-d1t440-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t440-4">
   <w.rf>
    <LM>w#w-d1t440-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t440-5">
   <w.rf>
    <LM>w#w-d1t440-5</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t440-6">
   <w.rf>
    <LM>w#w-d1t440-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m054-d1t440-7">
   <w.rf>
    <LM>w#w-d1t440-7</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m054-d1t450-1">
   <w.rf>
    <LM>w#w-d1t450-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t450-4">
   <w.rf>
    <LM>w#w-d1t450-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t450-6">
   <w.rf>
    <LM>w#w-d1t450-6</LM>
   </w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m054-d1t450-7">
   <w.rf>
    <LM>w#w-d1t450-7</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d1e445-x2-432">
   <w.rf>
    <LM>w#w-d1e445-x2-432</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-433">
  <m id="m054-d1t450-10">
   <w.rf>
    <LM>w#w-d1t450-10</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t450-11">
   <w.rf>
    <LM>w#w-d1t450-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t450-12">
   <w.rf>
    <LM>w#w-d1t450-12</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t450-13">
   <w.rf>
    <LM>w#w-d1t450-13</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m054-d1t450-14">
   <w.rf>
    <LM>w#w-d1t450-14</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m054-d1t450-15">
   <w.rf>
    <LM>w#w-d1t450-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t450-16">
   <w.rf>
    <LM>w#w-d1t450-16</LM>
   </w.rf>
   <form>manželé</form>
   <lemma>manžel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-433-441">
   <w.rf>
    <LM>w#w-433-441</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t450-22">
   <w.rf>
    <LM>w#w-d1t450-22</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t450-23">
   <w.rf>
    <LM>w#w-d1t450-23</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t450-24">
   <w.rf>
    <LM>w#w-d1t450-24</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t450-25">
   <w.rf>
    <LM>w#w-d1t450-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t450-26">
   <w.rf>
    <LM>w#w-d1t450-26</LM>
   </w.rf>
   <form>těsně</form>
   <lemma>těsně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t450-27">
   <w.rf>
    <LM>w#w-d1t450-27</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t450-28">
   <w.rf>
    <LM>w#w-d1t450-28</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d-id72072-punct">
   <w.rf>
    <LM>w#w-d-id72072-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t452-1">
   <w.rf>
    <LM>w#w-d1t452-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t452-2">
   <w.rf>
    <LM>w#w-d1t452-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t452-4">
   <w.rf>
    <LM>w#w-d1t452-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t452-3">
   <w.rf>
    <LM>w#w-d1t452-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t452-5">
   <w.rf>
    <LM>w#w-d1t452-5</LM>
   </w.rf>
   <form>bruslit</form>
   <lemma>bruslit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-433-442">
   <w.rf>
    <LM>w#w-433-442</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-443">
  <m id="m054-d1t452-10">
   <w.rf>
    <LM>w#w-d1t452-10</LM>
   </w.rf>
   <form>Sedělo</form>
   <lemma>sedět</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t452-8">
   <w.rf>
    <LM>w#w-d1t452-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-443-444">
   <w.rf>
    <LM>w#w-443-444</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t452-9">
   <w.rf>
    <LM>w#w-d1t452-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t452-11">
   <w.rf>
    <LM>w#w-d1t452-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t452-13">
   <w.rf>
    <LM>w#w-d1t452-13</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-443-446">
   <w.rf>
    <LM>w#w-443-446</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-447">
  <m id="m054-d1t452-15">
   <w.rf>
    <LM>w#w-d1t452-15</LM>
   </w.rf>
   <form>Hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t452-17">
   <w.rf>
    <LM>w#w-d1t452-17</LM>
   </w.rf>
   <form>hudba</form>
   <lemma>hudba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-447-448">
   <w.rf>
    <LM>w#w-447-448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-449">
  <m id="m054-d1t452-19">
   <w.rf>
    <LM>w#w-d1t452-19</LM>
   </w.rf>
   <form>Netančilo</form>
   <lemma>tančit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m054-d1t452-20">
   <w.rf>
    <LM>w#w-d1t452-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-449-450">
   <w.rf>
    <LM>w#w-449-450</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-451">
  <m id="m054-d1t454-1">
   <w.rf>
    <LM>w#w-d1t454-1</LM>
   </w.rf>
   <form>Hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t454-3">
   <w.rf>
    <LM>w#w-d1t454-3</LM>
   </w.rf>
   <form>hudba</form>
   <lemma>hudba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-451-452">
   <w.rf>
    <LM>w#w-451-452</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t454-6">
   <w.rf>
    <LM>w#w-d1t454-6</LM>
   </w.rf>
   <form>posezení</form>
   <lemma>posezení_^(*4dět)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-451-454">
   <w.rf>
    <LM>w#w-451-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-455">
  <m id="m054-455-456">
   <w.rf>
    <LM>w#w-455-456</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t454-12">
   <w.rf>
    <LM>w#w-d1t454-12</LM>
   </w.rf>
   <form>ledu</form>
   <lemma>led</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m054-d1t454-9">
   <w.rf>
    <LM>w#w-d1t454-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t454-10">
   <w.rf>
    <LM>w#w-d1t454-10</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t454-8">
   <w.rf>
    <LM>w#w-d1t454-8</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t454-13">
   <w.rf>
    <LM>w#w-d1t454-13</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-455-457">
   <w.rf>
    <LM>w#w-455-457</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-458">
  <m id="m054-d1t456-3">
   <w.rf>
    <LM>w#w-d1t456-3</LM>
   </w.rf>
   <form>Můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t456-4">
   <w.rf>
    <LM>w#w-d1t456-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m054-d-id72656-punct">
   <w.rf>
    <LM>w#w-d-id72656-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t456-6">
   <w.rf>
    <LM>w#w-d1t456-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t456-7">
   <w.rf>
    <LM>w#w-d1t456-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t456-8">
   <w.rf>
    <LM>w#w-d1t456-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t456-9">
   <w.rf>
    <LM>w#w-d1t456-9</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e445-x3-462">
   <w.rf>
    <LM>w#w-d1e445-x3-462</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t456-11">
   <w.rf>
    <LM>w#w-d1t456-11</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m054-d1t456-12">
   <w.rf>
    <LM>w#w-d1t456-12</LM>
   </w.rf>
   <form>ledu</form>
   <lemma>led</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m054-d1t456-10">
   <w.rf>
    <LM>w#w-d1t456-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t456-13">
   <w.rf>
    <LM>w#w-d1t456-13</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d-m-d1e445-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e445-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
