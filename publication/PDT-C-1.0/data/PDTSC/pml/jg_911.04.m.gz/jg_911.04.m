<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_911.04.w.gz" />
  </references>
 </head>
 <s id="m911-12941_01-3497">
  <m id="m911-3497-3504">
   <w.rf>
    <LM>w#w-3497-3504</LM>
   </w.rf>
   <form>Přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m911-d1t1409-15">
   <w.rf>
    <LM>w#w-d1t1409-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m911-d1t1409-16">
   <w.rf>
    <LM>w#w-d1t1409-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m911-d1t1409-17">
   <w.rf>
    <LM>w#w-d1t1409-17</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m911-3497-3505">
   <w.rf>
    <LM>w#w-3497-3505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m911-d1t1411-3">
   <w.rf>
    <LM>w#w-d1t1411-3</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m911-d1t1411-4">
   <w.rf>
    <LM>w#w-d1t1411-4</LM>
   </w.rf>
   <form>mínus</form>
   <lemma>mínus-2_,h_^(mat._operace;_9_mínus_3,_též_mínus_dva_stupně)_(^GC**minus-2)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m911-d1t1411-5">
   <w.rf>
    <LM>w#w-d1t1411-5</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m911-3497-3506">
   <w.rf>
    <LM>w#w-3497-3506</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m911-d1t1411-6">
   <w.rf>
    <LM>w#w-d1t1411-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>11000000</form>
   <lemma>11000000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m911-d1t1411-8">
   <w.rf>
    <LM>w#w-d1t1411-8</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m911-d-id107643">
   <w.rf>
    <LM>w#w-d-id107643</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
