<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_013.08.w.gz" />
  </references>
 </head>
 <s id="m013-d1e3059-x2">
  <m id="m013-d1t3064-1">
   <w.rf>
    <LM>w#w-d1t3064-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m013-d1t3064-2">
   <w.rf>
    <LM>w#w-d1t3064-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3064-3">
   <w.rf>
    <LM>w#w-d1t3064-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3064-4">
   <w.rf>
    <LM>w#w-d1t3064-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d-id135934-punct">
   <w.rf>
    <LM>w#w-d-id135934-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3065-x2">
  <m id="m013-d1t3068-4">
   <w.rf>
    <LM>w#w-d1t3068-4</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3068-5">
   <w.rf>
    <LM>w#w-d1t3068-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3068-2">
   <w.rf>
    <LM>w#w-d1t3068-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3068-3">
   <w.rf>
    <LM>w#w-d1t3068-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m013-d-m-d1e3065-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3065-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3076-x2">
  <m id="m013-d1t3079-1">
   <w.rf>
    <LM>w#w-d1t3079-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3079-2">
   <w.rf>
    <LM>w#w-d1t3079-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3079-3">
   <w.rf>
    <LM>w#w-d1t3079-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m013-d-m-d1e3076-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3076-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3086-x2">
  <m id="m013-d1t3089-1">
   <w.rf>
    <LM>w#w-d1t3089-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m013-d1t3089-2">
   <w.rf>
    <LM>w#w-d1t3089-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3089-4">
   <w.rf>
    <LM>w#w-d1t3089-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m013-d1t3089-5">
   <w.rf>
    <LM>w#w-d1t3089-5</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m013-d1t3089-3">
   <w.rf>
    <LM>w#w-d1t3089-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m013-d-id136379-punct">
   <w.rf>
    <LM>w#w-d-id136379-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3090-x2">
  <m id="m013-d1t3095-1">
   <w.rf>
    <LM>w#w-d1t3095-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3095-3">
   <w.rf>
    <LM>w#w-d1t3095-3</LM>
   </w.rf>
   <form>Ermitáži</form>
   <lemma>Ermitáž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3095-5">
   <w.rf>
    <LM>w#w-d1t3095-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3095-6">
   <w.rf>
    <LM>w#w-d1t3095-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m013-d1t3095-7">
   <w.rf>
    <LM>w#w-d1t3095-7</LM>
   </w.rf>
   <form>teta</form>
   <lemma>teta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3095-9">
   <w.rf>
    <LM>w#w-d1t3095-9</LM>
   </w.rf>
   <form>Luba</form>
   <lemma>Luba_;G_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3090-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3090-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3109-x2">
  <m id="m013-d1t3112-1">
   <w.rf>
    <LM>w#w-d1t3112-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m013-d1t3112-3">
   <w.rf>
    <LM>w#w-d1t3112-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3112-4">
   <w.rf>
    <LM>w#w-d1t3112-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3112-5">
   <w.rf>
    <LM>w#w-d1t3112-5</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m013-d1t3112-6">
   <w.rf>
    <LM>w#w-d1t3112-6</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3112-7">
   <w.rf>
    <LM>w#w-d1t3112-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3112-8">
   <w.rf>
    <LM>w#w-d1t3112-8</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m013-d-id136810-punct">
   <w.rf>
    <LM>w#w-d-id136810-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3113-x2">
  <m id="m013-d1t3118-1">
   <w.rf>
    <LM>w#w-d1t3118-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3118-2">
   <w.rf>
    <LM>w#w-d1t3118-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3120-1">
   <w.rf>
    <LM>w#w-d1t3120-1</LM>
   </w.rf>
   <form>carova</form>
   <lemma>carův_^(*2)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m013-d1t3120-2">
   <w.rf>
    <LM>w#w-d1t3120-2</LM>
   </w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3120-3">
   <w.rf>
    <LM>w#w-d1t3120-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3120-4">
   <w.rf>
    <LM>w#w-d1t3120-4</LM>
   </w.rf>
   <form>koních</form>
   <lemma>kůň</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3113-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3113-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3121-x2">
  <m id="m013-d1t3126-1">
   <w.rf>
    <LM>w#w-d1t3126-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m013-d1t3126-2">
   <w.rf>
    <LM>w#w-d1t3126-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m013-d1t3126-3">
   <w.rf>
    <LM>w#w-d1t3126-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3126-4">
   <w.rf>
    <LM>w#w-d1t3126-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3126-6">
   <w.rf>
    <LM>w#w-d1t3126-6</LM>
   </w.rf>
   <form>Ermitáži</form>
   <lemma>Ermitáž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3126-8">
   <w.rf>
    <LM>w#w-d1t3126-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3126-9">
   <w.rf>
    <LM>w#w-d1t3126-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m013-d1t3126-10">
   <w.rf>
    <LM>w#w-d1t3126-10</LM>
   </w.rf>
   <form>vidění</form>
   <lemma>vidění_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m013-d-id137178-punct">
   <w.rf>
    <LM>w#w-d-id137178-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3127-x2">
  <m id="m013-d1t3132-2">
   <w.rf>
    <LM>w#w-d1t3132-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3132-4">
   <w.rf>
    <LM>w#w-d1t3132-4</LM>
   </w.rf>
   <form>Ermitáži</form>
   <lemma>Ermitáž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3132-6">
   <w.rf>
    <LM>w#w-d1t3132-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3134-2">
   <w.rf>
    <LM>w#w-d1t3134-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m013-d1t3134-3">
   <w.rf>
    <LM>w#w-d1t3134-3</LM>
   </w.rf>
   <form>vidění</form>
   <lemma>vidění_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m013-d1t3136-1">
   <w.rf>
    <LM>w#w-d1t3136-1</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3136-2">
   <w.rf>
    <LM>w#w-d1t3136-2</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3127-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3127-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3149-x2">
  <m id="m013-d1t3152-2">
   <w.rf>
    <LM>w#w-d1t3152-2</LM>
   </w.rf>
   <form>Zaujaly</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m013-d1t3152-1">
   <w.rf>
    <LM>w#w-d1t3152-1</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m013-d1t3138-1">
   <w.rf>
    <LM>w#w-d1t3138-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3152-3">
   <w.rf>
    <LM>w#w-d1t3152-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3152-4">
   <w.rf>
    <LM>w#w-d1t3152-4</LM>
   </w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m013-d1t3152-5">
   <w.rf>
    <LM>w#w-d1t3152-5</LM>
   </w.rf>
   <form>obrazy</form>
   <lemma>obraz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m013-d-id137669-punct">
   <w.rf>
    <LM>w#w-d-id137669-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3152-7">
   <w.rf>
    <LM>w#w-d1t3152-7</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m013-d1t3152-9">
   <w.rf>
    <LM>w#w-d1t3152-9</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3152-8">
   <w.rf>
    <LM>w#w-d1t3152-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3152-10">
   <w.rf>
    <LM>w#w-d1t3152-10</LM>
   </w.rf>
   <form>nafocené</form>
   <lemma>nafocený_^(*4tit)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m013-d1e3149-x2-612">
   <w.rf>
    <LM>w#w-d1e3149-x2-612</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3152-11">
   <w.rf>
    <LM>w#w-d1t3152-11</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3152-13">
   <w.rf>
    <LM>w#w-d1t3152-13</LM>
   </w.rf>
   <form>momentálně</form>
   <lemma>momentálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3152-15">
   <w.rf>
    <LM>w#w-d1t3152-15</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3152-16">
   <w.rf>
    <LM>w#w-d1t3152-16</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d-id137806-punct">
   <w.rf>
    <LM>w#w-d-id137806-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3152-18">
   <w.rf>
    <LM>w#w-d1t3152-18</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3152-19">
   <w.rf>
    <LM>w#w-d1t3152-19</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3152-20">
   <w.rf>
    <LM>w#w-d1t3152-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m013-d1t3152-22">
   <w.rf>
    <LM>w#w-d1t3152-22</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3152-21">
   <w.rf>
    <LM>w#w-d1t3152-21</LM>
   </w.rf>
   <form>nafocené</form>
   <lemma>nafocený_^(*4tit)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m013-d1e3149-x2-614">
   <w.rf>
    <LM>w#w-d1e3149-x2-614</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3156-2">
   <w.rf>
    <LM>w#w-d1t3156-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3156-3">
   <w.rf>
    <LM>w#w-d1t3156-3</LM>
   </w.rf>
   <form>zlatý</form>
   <lemma>zlatý-1_^(atribut;_z._řetízek,_poklad,...)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m013-d1t3156-4">
   <w.rf>
    <LM>w#w-d1t3156-4</LM>
   </w.rf>
   <form>kočár</form>
   <lemma>kočár</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m013-d1t3156-5">
   <w.rf>
    <LM>w#w-d1t3156-5</LM>
   </w.rf>
   <form>cara</form>
   <lemma>car</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m013-d1t3156-7">
   <w.rf>
    <LM>w#w-d1t3156-7</LM>
   </w.rf>
   <form>Petra</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m013-d1t3156-9">
   <w.rf>
    <LM>w#w-d1t3156-9</LM>
   </w.rf>
   <form>Prvního</form>
   <lemma>první-1</lemma>
   <tag>CrMS2----------</tag>
  </m>
  <m id="m013-d-id138042-punct">
   <w.rf>
    <LM>w#w-d-id138042-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3160-1">
   <w.rf>
    <LM>w#w-d1t3160-1</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m013-d1t3163-1">
   <w.rf>
    <LM>w#w-d1t3163-1</LM>
   </w.rf>
   <form>památky</form>
   <lemma>památka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m013-d1t3163-2">
   <w.rf>
    <LM>w#w-d1t3163-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3163-3">
   <w.rf>
    <LM>w#w-d1t3163-3</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP6--3-------</tag>
  </m>
  <m id="m013-d-m-d1e3149-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3149-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3170-x2">
  <m id="m013-d1t3173-1">
   <w.rf>
    <LM>w#w-d1t3173-1</LM>
   </w.rf>
   <form>Porcelán</form>
   <lemma>porcelán</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m013-d1t3175-1">
   <w.rf>
    <LM>w#w-d1t3175-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3175-3">
   <w.rf>
    <LM>w#w-d1t3175-3</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m013-d1t3175-4">
   <w.rf>
    <LM>w#w-d1t3175-4</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m013-d-id138340-punct">
   <w.rf>
    <LM>w#w-d-id138340-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3175-6">
   <w.rf>
    <LM>w#w-d1t3175-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m013-d1t3175-7">
   <w.rf>
    <LM>w#w-d1t3175-7</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m013-d1t3175-8">
   <w.rf>
    <LM>w#w-d1t3175-8</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3175-9">
   <w.rf>
    <LM>w#w-d1t3175-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3175-10">
   <w.rf>
    <LM>w#w-d1t3175-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m013-d1t3175-11">
   <w.rf>
    <LM>w#w-d1t3175-11</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m013-d1t3175-13">
   <w.rf>
    <LM>w#w-d1t3175-13</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d-m-d1e3170-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3170-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3176-x2">
  <m id="m013-d1t3179-1">
   <w.rf>
    <LM>w#w-d1t3179-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1e3176-x2-624">
   <w.rf>
    <LM>w#w-d1e3176-x2-624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-622_2">
  <m id="m013-d1t3179-3">
   <w.rf>
    <LM>w#w-d1t3179-3</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m013-d1t3179-4">
   <w.rf>
    <LM>w#w-d1t3179-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3179-5">
   <w.rf>
    <LM>w#w-d1t3179-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3179-6">
   <w.rf>
    <LM>w#w-d1t3179-6</LM>
   </w.rf>
   <form>projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m013-d1t3179-7">
   <w.rf>
    <LM>w#w-d1t3179-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3179-8">
   <w.rf>
    <LM>w#w-d1t3179-8</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m013-d1t3179-9">
   <w.rf>
    <LM>w#w-d1t3179-9</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m013-d-id138652-punct">
   <w.rf>
    <LM>w#w-d-id138652-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3180-x2">
  <m id="m013-d1t3183-1">
   <w.rf>
    <LM>w#w-d1t3183-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d-id138729-punct">
   <w.rf>
    <LM>w#w-d-id138729-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3183-3">
   <w.rf>
    <LM>w#w-d1t3183-3</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m013-d1t3183-4">
   <w.rf>
    <LM>w#w-d1t3183-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3183-5">
   <w.rf>
    <LM>w#w-d1t3183-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3183-6">
   <w.rf>
    <LM>w#w-d1t3183-6</LM>
   </w.rf>
   <form>projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m013-d1t3183-7">
   <w.rf>
    <LM>w#w-d1t3183-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3183-8">
   <w.rf>
    <LM>w#w-d1t3183-8</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m013-d1t3183-9">
   <w.rf>
    <LM>w#w-d1t3183-9</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3180-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3180-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3184-x2">
  <m id="m013-d1t3187-1">
   <w.rf>
    <LM>w#w-d1t3187-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m013-d1t3187-2">
   <w.rf>
    <LM>w#w-d1t3187-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m013-d1t3187-3">
   <w.rf>
    <LM>w#w-d1t3187-3</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m013-d1t3187-4">
   <w.rf>
    <LM>w#w-d1t3187-4</LM>
   </w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m013-d-id138948-punct">
   <w.rf>
    <LM>w#w-d-id138948-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3189-x2">
  <m id="m013-d1t3196-1">
   <w.rf>
    <LM>w#w-d1t3196-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3196-3">
   <w.rf>
    <LM>w#w-d1t3196-3</LM>
   </w.rf>
   <form>Ermitáži</form>
   <lemma>Ermitáž_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3189-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3189-x2-punct-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-642_2">
  <m id="m013-642_2-644">
   <w.rf>
    <LM>w#w-642_2-644</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-642_2-646">
   <w.rf>
    <LM>w#w-642_2-646</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3207-x2">
  <m id="m013-d1t3210-1">
   <w.rf>
    <LM>w#w-d1t3210-1</LM>
   </w.rf>
   <form>Obrazy</form>
   <lemma>obraz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m013-d1e3207-x2-660">
   <w.rf>
    <LM>w#w-d1e3207-x2-660</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-662">
  <m id="m013-d1t3210-3">
   <w.rf>
    <LM>w#w-d1t3210-3</LM>
   </w.rf>
   <form>Jednoznačně</form>
   <lemma>jednoznačně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3210-4">
   <w.rf>
    <LM>w#w-d1t3210-4</LM>
   </w.rf>
   <form>obrazy</form>
   <lemma>obraz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3207-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3207-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3217-x2">
  <m id="m013-d1t3220-1">
   <w.rf>
    <LM>w#w-d1t3220-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d1t3220-2">
   <w.rf>
    <LM>w#w-d1t3220-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m013-d1t3220-3">
   <w.rf>
    <LM>w#w-d1t3220-3</LM>
   </w.rf>
   <form>umění</form>
   <lemma>umění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m013-d-id139363-punct">
   <w.rf>
    <LM>w#w-d-id139363-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3221-x2">
  <m id="m013-d1t3224-3">
   <w.rf>
    <LM>w#w-d1t3224-3</LM>
   </w.rf>
   <form>Podívám</form>
   <lemma>podívat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m013-d1t3224-4">
   <w.rf>
    <LM>w#w-d1t3224-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3224-5">
   <w.rf>
    <LM>w#w-d1t3224-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m013-d1t3230-1">
   <w.rf>
    <LM>w#w-d1t3230-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3230-2">
   <w.rf>
    <LM>w#w-d1t3230-2</LM>
   </w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m013-d1t3230-3">
   <w.rf>
    <LM>w#w-d1t3230-3</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3221-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3221-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3235-x2">
  <m id="m013-d1t3238-1">
   <w.rf>
    <LM>w#w-d1t3238-1</LM>
   </w.rf>
   <form>Podívám</form>
   <lemma>podívat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m013-d1t3238-2">
   <w.rf>
    <LM>w#w-d1t3238-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3238-3">
   <w.rf>
    <LM>w#w-d1t3238-3</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m013-d-m-d1e3235-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3235-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3245-x2">
  <m id="m013-d1t3248-1">
   <w.rf>
    <LM>w#w-d1t3248-1</LM>
   </w.rf>
   <form>Doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3248-3">
   <w.rf>
    <LM>w#w-d1t3248-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3248-4">
   <w.rf>
    <LM>w#w-d1t3248-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m013-d1t3248-2">
   <w.rf>
    <LM>w#w-d1t3248-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d-id139830-punct">
   <w.rf>
    <LM>w#w-d-id139830-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3249-x2">
  <m id="m013-d1t3254-1">
   <w.rf>
    <LM>w#w-d1t3254-1</LM>
   </w.rf>
   <form>Starého</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m013-d-id139916-punct">
   <w.rf>
    <LM>w#w-d-id139916-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-1108"></s>
 <s id="m013-d1e3261-x2">
  <m id="m013-d1t3266-2">
   <w.rf>
    <LM>w#w-d1t3266-2</LM>
   </w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3266-3">
   <w.rf>
    <LM>w#w-d1t3266-3</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3266-4">
   <w.rf>
    <LM>w#w-d1t3266-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3266-5">
   <w.rf>
    <LM>w#w-d1t3266-5</LM>
   </w.rf>
   <form>drobnosti</form>
   <lemma>drobnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m013-d-id140126-punct">
   <w.rf>
    <LM>w#w-d-id140126-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3268-2">
   <w.rf>
    <LM>w#w-d1t3268-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3268-3">
   <w.rf>
    <LM>w#w-d1t3268-3</LM>
   </w.rf>
   <form>staršího</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS2----2A----</tag>
  </m>
  <m id="m013-d1t3268-4">
   <w.rf>
    <LM>w#w-d1t3268-4</LM>
   </w.rf>
   <form>data</form>
   <lemma>datum-1_^(kalendářní)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3261-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3261-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3269-x2">
  <m id="m013-d1t3274-1">
   <w.rf>
    <LM>w#w-d1t3274-1</LM>
   </w.rf>
   <form>Líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3274-2">
   <w.rf>
    <LM>w#w-d1t3274-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3274-3">
   <w.rf>
    <LM>w#w-d1t3274-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m013-d1t3274-5">
   <w.rf>
    <LM>w#w-d1t3274-5</LM>
   </w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m013-d-id140370-punct">
   <w.rf>
    <LM>w#w-d-id140370-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3275-x2">
  <m id="m013-d1t3280-2">
   <w.rf>
    <LM>w#w-d1t3280-2</LM>
   </w.rf>
   <form>Rusko</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m013-d1t3280-4">
   <w.rf>
    <LM>w#w-d1t3280-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3280-5">
   <w.rf>
    <LM>w#w-d1t3280-5</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m013-d1t3280-6">
   <w.rf>
    <LM>w#w-d1t3280-6</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d-m-d1e3275-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3275-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3287-x2">
  <m id="m013-d1t3292-4">
   <w.rf>
    <LM>w#w-d1t3292-4</LM>
   </w.rf>
   <form>Nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m013-d1t3292-5">
   <w.rf>
    <LM>w#w-d1t3292-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3292-6">
   <w.rf>
    <LM>w#w-d1t3292-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3292-7">
   <w.rf>
    <LM>w#w-d1t3292-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3292-9">
   <w.rf>
    <LM>w#w-d1t3292-9</LM>
   </w.rf>
   <form>Petrohradě</form>
   <lemma>Petrohrad_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m013-d1e3287-x2-720">
   <w.rf>
    <LM>w#w-d1e3287-x2-720</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3292-11">
   <w.rf>
    <LM>w#w-d1t3292-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3292-12">
   <w.rf>
    <LM>w#w-d1t3292-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3292-13">
   <w.rf>
    <LM>w#w-d1t3292-13</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d1t3292-14">
   <w.rf>
    <LM>w#w-d1t3292-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3292-16">
   <w.rf>
    <LM>w#w-d1t3292-16</LM>
   </w.rf>
   <form>Moskvě</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3292-18">
   <w.rf>
    <LM>w#w-d1t3292-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3292-19">
   <w.rf>
    <LM>w#w-d1t3292-19</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3292-20">
   <w.rf>
    <LM>w#w-d1t3292-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3292-21">
   <w.rf>
    <LM>w#w-d1t3292-21</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d1t3292-22">
   <w.rf>
    <LM>w#w-d1t3292-22</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3292-23">
   <w.rf>
    <LM>w#w-d1t3292-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3292-24">
   <w.rf>
    <LM>w#w-d1t3292-24</LM>
   </w.rf>
   <form>jihu</form>
   <lemma>jih</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m013-d-id141017-punct">
   <w.rf>
    <LM>w#w-d-id141017-punct</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3294-2">
   <w.rf>
    <LM>w#w-d1t3294-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3294-3">
   <w.rf>
    <LM>w#w-d1t3294-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3294-4">
   <w.rf>
    <LM>w#w-d1t3294-4</LM>
   </w.rf>
   <form>obrovská</form>
   <lemma>obrovský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m013-d1t3294-5">
   <w.rf>
    <LM>w#w-d1t3294-5</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3296-2">
   <w.rf>
    <LM>w#w-d1t3296-2</LM>
   </w.rf>
   <form>velikých</form>
   <lemma>veliký</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m013-d1t3296-3">
   <w.rf>
    <LM>w#w-d1t3296-3</LM>
   </w.rf>
   <form>kontrastů</form>
   <lemma>kontrast</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3287-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3287-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3307-x2">
  <m id="m013-d1t3310-1">
   <w.rf>
    <LM>w#w-d1t3310-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m013-d1t3310-2">
   <w.rf>
    <LM>w#w-d1t3310-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3310-3">
   <w.rf>
    <LM>w#w-d1t3310-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3310-4">
   <w.rf>
    <LM>w#w-d1t3310-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3310-5">
   <w.rf>
    <LM>w#w-d1t3310-5</LM>
   </w.rf>
   <form>naposled</form>
   <lemma>naposled</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3310-6">
   <w.rf>
    <LM>w#w-d1t3310-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3310-9">
   <w.rf>
    <LM>w#w-d1t3310-9</LM>
   </w.rf>
   <form>Petrohradě</form>
   <lemma>Petrohrad_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m013-d-id141451-punct">
   <w.rf>
    <LM>w#w-d-id141451-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3310-12">
   <w.rf>
    <LM>w#w-d1t3310-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d1t3310-13">
   <w.rf>
    <LM>w#w-d1t3310-13</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m013-d1t3310-15">
   <w.rf>
    <LM>w#w-d1t3310-15</LM>
   </w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m013-d-id141553-punct">
   <w.rf>
    <LM>w#w-d-id141553-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3310-19">
   <w.rf>
    <LM>w#w-d1t3310-19</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m013-d1t3310-20">
   <w.rf>
    <LM>w#w-d1t3310-20</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3310-17">
   <w.rf>
    <LM>w#w-d1t3310-17</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m013-d1t3310-21">
   <w.rf>
    <LM>w#w-d1t3310-21</LM>
   </w.rf>
   <form>veliké</form>
   <lemma>veliký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m013-d1t3310-22">
   <w.rf>
    <LM>w#w-d1t3310-22</LM>
   </w.rf>
   <form>obchody</form>
   <lemma>obchod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m013-d-id141624-punct">
   <w.rf>
    <LM>w#w-d-id141624-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3310-24">
   <w.rf>
    <LM>w#w-d1t3310-24</LM>
   </w.rf>
   <form>supermarkety</form>
   <lemma>supermarket</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m013-d-id141648-punct">
   <w.rf>
    <LM>w#w-d-id141648-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3310-27">
   <w.rf>
    <LM>w#w-d1t3310-27</LM>
   </w.rf>
   <form>plné</form>
   <lemma>plný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m013-d1t3310-26">
   <w.rf>
    <LM>w#w-d1t3310-26</LM>
   </w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m013-d1e3307-x2-734">
   <w.rf>
    <LM>w#w-d1e3307-x2-734</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3312-2">
   <w.rf>
    <LM>w#w-d1t3312-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3312-5">
   <w.rf>
    <LM>w#w-d1t3312-5</LM>
   </w.rf>
   <form>nebývalo</form>
   <lemma>bývat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m013-d1t3312-7">
   <w.rf>
    <LM>w#w-d1t3312-7</LM>
   </w.rf>
   <form>normální</form>
   <lemma>normální</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m013-d-m-d1e3307-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3307-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3313-x3">
  <m id="m013-d1t3322-3">
   <w.rf>
    <LM>w#w-d1t3322-3</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3322-2">
   <w.rf>
    <LM>w#w-d1t3322-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3322-4">
   <w.rf>
    <LM>w#w-d1t3322-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m013-d1t3322-5">
   <w.rf>
    <LM>w#w-d1t3322-5</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d1t3322-6">
   <w.rf>
    <LM>w#w-d1t3322-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1e3313-x3-438">
   <w.rf>
    <LM>w#w-d1e3313-x3-438</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3322-7">
   <w.rf>
    <LM>w#w-d1t3322-7</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m013-d1t3322-8">
   <w.rf>
    <LM>w#w-d1t3322-8</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m013-d-m-d1e3313-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3313-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3324-x2">
  <m id="m013-d1t3327-1">
   <w.rf>
    <LM>w#w-d1t3327-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1e3324-x2-742">
   <w.rf>
    <LM>w#w-d1e3324-x2-742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-740">
  <m id="m013-d1t3327-3">
   <w.rf>
    <LM>w#w-d1t3327-3</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m013-d1t3327-4">
   <w.rf>
    <LM>w#w-d1t3327-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3327-5">
   <w.rf>
    <LM>w#w-d1t3327-5</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d1t3327-6">
   <w.rf>
    <LM>w#w-d1t3327-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3327-7">
   <w.rf>
    <LM>w#w-d1t3327-7</LM>
   </w.rf>
   <form>příbuzné</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m013-d-id142173-punct">
   <w.rf>
    <LM>w#w-d-id142173-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3328-x2">
  <m id="m013-d1t3333-1">
   <w.rf>
    <LM>w#w-d1t3333-1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3333-2">
   <w.rf>
    <LM>w#w-d1t3333-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3335-1">
   <w.rf>
    <LM>w#w-d1t3335-1</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m013-d1t3335-3">
   <w.rf>
    <LM>w#w-d1t3335-3</LM>
   </w.rf>
   <form>maminčiny</form>
   <lemma>maminčin_^(*3ka)</lemma>
   <tag>AUFP1F---------</tag>
  </m>
  <m id="m013-d1t3335-2">
   <w.rf>
    <LM>w#w-d1t3335-2</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m013-d-id142330-punct">
   <w.rf>
    <LM>w#w-d-id142330-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3335-6">
   <w.rf>
    <LM>w#w-d1t3335-6</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m013-d1t3335-9">
   <w.rf>
    <LM>w#w-d1t3335-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3335-10">
   <w.rf>
    <LM>w#w-d1t3335-10</LM>
   </w.rf>
   <form>nežije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m013-d1e3328-x2-1144">
   <w.rf>
    <LM>w#w-d1e3328-x2-1144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-1145">
  <m id="m013-d1t3337-1">
   <w.rf>
    <LM>w#w-d1t3337-1</LM>
   </w.rf>
   <form>Babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3337-2">
   <w.rf>
    <LM>w#w-d1t3337-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3337-3">
   <w.rf>
    <LM>w#w-d1t3337-3</LM>
   </w.rf>
   <form>nežije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m013-d-id142489-punct">
   <w.rf>
    <LM>w#w-d-id142489-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3337-5">
   <w.rf>
    <LM>w#w-d1t3337-5</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m013-d1t3337-6">
   <w.rf>
    <LM>w#w-d1t3337-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3337-7">
   <w.rf>
    <LM>w#w-d1t3337-7</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-1145-1146">
   <w.rf>
    <LM>w#w-1145-1146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-1147">
  <m id="m013-d1t3339-1">
   <w.rf>
    <LM>w#w-d1t3339-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3339-2">
   <w.rf>
    <LM>w#w-d1t3339-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3339-3">
   <w.rf>
    <LM>w#w-d1t3339-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3339-4">
   <w.rf>
    <LM>w#w-d1t3339-4</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m013-d1t3339-5">
   <w.rf>
    <LM>w#w-d1t3339-5</LM>
   </w.rf>
   <form>bratrance</form>
   <lemma>bratranec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m013-d1t3339-6">
   <w.rf>
    <LM>w#w-d1t3339-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3339-7">
   <w.rf>
    <LM>w#w-d1t3339-7</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m013-d1t3339-8">
   <w.rf>
    <LM>w#w-d1t3339-8</LM>
   </w.rf>
   <form>sestřenici</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3328-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3328-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3340-x2">
  <m id="m013-d1t3343-1">
   <w.rf>
    <LM>w#w-d1t3343-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3343-2">
   <w.rf>
    <LM>w#w-d1t3343-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1e3340-x2-754">
   <w.rf>
    <LM>w#w-d1e3340-x2-754</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m013-d1e3340-x2-756">
   <w.rf>
    <LM>w#w-d1e3340-x2-756</LM>
   </w.rf>
   <form>vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d-m-d1e3340-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3340-x2-punct-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3346-x2">
  <m id="m013-d1t3349-7">
   <w.rf>
    <LM>w#w-d1t3349-7</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3349-5">
   <w.rf>
    <LM>w#w-d1t3349-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3349-6">
   <w.rf>
    <LM>w#w-d1t3349-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1t3349-4">
   <w.rf>
    <LM>w#w-d1t3349-4</LM>
   </w.rf>
   <form>vídávali</form>
   <lemma>vídávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3351-1">
   <w.rf>
    <LM>w#w-d1t3351-1</LM>
   </w.rf>
   <form>častěji</form>
   <lemma>často</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m013-d-id142948-punct">
   <w.rf>
    <LM>w#w-d-id142948-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3351-3">
   <w.rf>
    <LM>w#w-d1t3351-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m013-d1t3351-4">
   <w.rf>
    <LM>w#w-d1t3351-4</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3351-5">
   <w.rf>
    <LM>w#w-d1t3351-5</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3353-1">
   <w.rf>
    <LM>w#w-d1t3353-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3353-2">
   <w.rf>
    <LM>w#w-d1t3353-2</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3353-3">
   <w.rf>
    <LM>w#w-d1t3353-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3353-4">
   <w.rf>
    <LM>w#w-d1t3353-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m013-d1e3346-x2-1154">
   <w.rf>
    <LM>w#w-d1e3346-x2-1154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-1155">
  <m id="m013-d1t3355-2">
   <w.rf>
    <LM>w#w-d1t3355-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3355-3">
   <w.rf>
    <LM>w#w-d1t3355-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3355-4">
   <w.rf>
    <LM>w#w-d1t3355-4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3355-5">
   <w.rf>
    <LM>w#w-d1t3355-5</LM>
   </w.rf>
   <form>dlouhá</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m013-d1t3355-6">
   <w.rf>
    <LM>w#w-d1t3355-6</LM>
   </w.rf>
   <form>pauza</form>
   <lemma>pauza</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3357-1">
   <w.rf>
    <LM>w#w-d1t3357-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3357-2">
   <w.rf>
    <LM>w#w-d1t3357-2</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m013-d1t3357-3">
   <w.rf>
    <LM>w#w-d1t3357-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3357-4">
   <w.rf>
    <LM>w#w-d1t3357-4</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3357-6">
   <w.rf>
    <LM>w#w-d1t3357-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m013-d1t3357-8">
   <w.rf>
    <LM>w#w-d1t3357-8</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m013-d1t3357-7">
   <w.rf>
    <LM>w#w-d1t3357-7</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m013-d1e3346-x2-784">
   <w.rf>
    <LM>w#w-d1e3346-x2-784</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3363-1">
   <w.rf>
    <LM>w#w-d1t3363-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3363-2">
   <w.rf>
    <LM>w#w-d1t3363-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3363-3">
   <w.rf>
    <LM>w#w-d1t3363-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m013-d1t3363-5">
   <w.rf>
    <LM>w#w-d1t3363-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3371-2">
   <w.rf>
    <LM>w#w-d1t3371-2</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m013-d1t3373-1">
   <w.rf>
    <LM>w#w-d1t3373-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m013-d1t3373-4">
   <w.rf>
    <LM>w#w-d1t3373-4</LM>
   </w.rf>
   <form>Petrohradu</form>
   <lemma>Petrohrad_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m013-d1t3363-4">
   <w.rf>
    <LM>w#w-d1t3363-4</LM>
   </w.rf>
   <form>doprovodila</form>
   <lemma>doprovodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m013-d-m-d1e3346-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3346-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3374-x2">
  <m id="m013-d1t3379-1">
   <w.rf>
    <LM>w#w-d1t3379-1</LM>
   </w.rf>
   <form>Letěly</form>
   <lemma>letět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m013-d1t3379-2">
   <w.rf>
    <LM>w#w-d1t3379-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3379-3">
   <w.rf>
    <LM>w#w-d1t3379-3</LM>
   </w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3374-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3374-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3374-x3">
  <m id="m013-d1t3381-1">
   <w.rf>
    <LM>w#w-d1t3381-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d-m-d1e3374-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3374-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3382-x2">
  <m id="m013-d1t3385-1">
   <w.rf>
    <LM>w#w-d1t3385-1</LM>
   </w.rf>
   <form>Jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3385-2">
   <w.rf>
    <LM>w#w-d1t3385-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3385-3">
   <w.rf>
    <LM>w#w-d1t3385-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m013-d1t3385-4">
   <w.rf>
    <LM>w#w-d1t3385-4</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m013-d-id143866-punct">
   <w.rf>
    <LM>w#w-d-id143866-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3386-x2">
  <m id="m013-d1t3393-1">
   <w.rf>
    <LM>w#w-d1t3393-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m013-d-id143960-punct">
   <w.rf>
    <LM>w#w-d-id143960-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3393-3">
   <w.rf>
    <LM>w#w-d1t3393-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3393-4">
   <w.rf>
    <LM>w#w-d1t3393-4</LM>
   </w.rf>
   <form>momentálně</form>
   <lemma>momentálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3393-5">
   <w.rf>
    <LM>w#w-d1t3393-5</LM>
   </w.rf>
   <form>nejezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m013-d-id144016-punct">
   <w.rf>
    <LM>w#w-d-id144016-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3393-7">
   <w.rf>
    <LM>w#w-d1t3393-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m013-d1t3393-9">
   <w.rf>
    <LM>w#w-d1t3393-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3393-10">
   <w.rf>
    <LM>w#w-d1t3393-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m013-d1t3393-8">
   <w.rf>
    <LM>w#w-d1t3393-8</LM>
   </w.rf>
   <form>údajně</form>
   <lemma>údajně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3393-11">
   <w.rf>
    <LM>w#w-d1t3393-11</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m013-d1t3393-12">
   <w.rf>
    <LM>w#w-d1t3393-12</LM>
   </w.rf>
   <form>finanční</form>
   <lemma>finanční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m013-d1t3393-13">
   <w.rf>
    <LM>w#w-d1t3393-13</LM>
   </w.rf>
   <form>prostředky</form>
   <lemma>prostředek_^(střed,způsob,_nástroj)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3386-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3386-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3400-x2">
  <m id="m013-d1t3403-1">
   <w.rf>
    <LM>w#w-d1t3403-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3403-2">
   <w.rf>
    <LM>w#w-d1t3403-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3403-3">
   <w.rf>
    <LM>w#w-d1t3403-3</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d-id144232-punct">
   <w.rf>
    <LM>w#w-d-id144232-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3404-x2">
  <m id="m013-d1t3411-2">
   <w.rf>
    <LM>w#w-d1t3411-2</LM>
   </w.rf>
   <form>Lítáme</form>
   <lemma>lítat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3411-3">
   <w.rf>
    <LM>w#w-d1t3411-3</LM>
   </w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3404-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3404-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3412-x2">
  <m id="m013-d1t3417-1">
   <w.rf>
    <LM>w#w-d1t3417-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3417-2">
   <w.rf>
    <LM>w#w-d1t3417-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3417-3">
   <w.rf>
    <LM>w#w-d1t3417-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3417-4">
   <w.rf>
    <LM>w#w-d1t3417-4</LM>
   </w.rf>
   <form>trvá</form>
   <lemma>trvat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d-id144482-punct">
   <w.rf>
    <LM>w#w-d-id144482-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3418-x2">
  <m id="m013-d1t3423-1">
   <w.rf>
    <LM>w#w-d1t3423-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m013-d1t3423-4">
   <w.rf>
    <LM>w#w-d1t3423-4</LM>
   </w.rf>
   <form>Petrohradu</form>
   <lemma>Petrohrad_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m013-d1t3423-6">
   <w.rf>
    <LM>w#w-d1t3423-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m013-d1t3423-12">
   <w.rf>
    <LM>w#w-d1t3423-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m013-d1t3423-14">
   <w.rf>
    <LM>w#w-d1t3423-14</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m013-d1t3423-7">
   <w.rf>
    <LM>w#w-d1t3423-7</LM>
   </w.rf>
   <form>trvá</form>
   <lemma>trvat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m013-d1t3423-8">
   <w.rf>
    <LM>w#w-d1t3423-8</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m013-d1t3423-9">
   <w.rf>
    <LM>w#w-d1t3423-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3423-10">
   <w.rf>
    <LM>w#w-d1t3423-10</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m013-d1t3423-11">
   <w.rf>
    <LM>w#w-d1t3423-11</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3418-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3418-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3424-x2">
  <m id="m013-d1t3427-1">
   <w.rf>
    <LM>w#w-d1t3427-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m013-d1t3427-2">
   <w.rf>
    <LM>w#w-d1t3427-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m013-d1t3427-3">
   <w.rf>
    <LM>w#w-d1t3427-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3427-4">
   <w.rf>
    <LM>w#w-d1t3427-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3427-5">
   <w.rf>
    <LM>w#w-d1t3427-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m013-d1t3427-6">
   <w.rf>
    <LM>w#w-d1t3427-6</LM>
   </w.rf>
   <form>vícekrát</form>
   <lemma>vícekrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m013-d-id144884-punct">
   <w.rf>
    <LM>w#w-d-id144884-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m013-d1t3427-8">
   <w.rf>
    <LM>w#w-d1t3427-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m013-d-id144908-punct">
   <w.rf>
    <LM>w#w-d-id144908-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3428-x2">
  <m id="m013-d1t3433-1">
   <w.rf>
    <LM>w#w-d1t3433-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m013-d1t3433-2">
   <w.rf>
    <LM>w#w-d1t3433-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m013-d1t3433-3">
   <w.rf>
    <LM>w#w-d1t3433-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3433-5">
   <w.rf>
    <LM>w#w-d1t3433-5</LM>
   </w.rf>
   <form>Petrohradě</form>
   <lemma>Petrohrad_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m013-d1t3433-7">
   <w.rf>
    <LM>w#w-d1t3433-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m013-d1t3433-8">
   <w.rf>
    <LM>w#w-d1t3433-8</LM>
   </w.rf>
   <form>prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1t3433-9">
   <w.rf>
    <LM>w#w-d1t3433-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3433-10">
   <w.rf>
    <LM>w#w-d1t3433-10</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3428-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3428-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3434-x2">
  <m id="m013-d1t3439-1">
   <w.rf>
    <LM>w#w-d1t3439-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m013-d1t3439-2">
   <w.rf>
    <LM>w#w-d1t3439-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m013-d1t3439-4">
   <w.rf>
    <LM>w#w-d1t3439-4</LM>
   </w.rf>
   <form>Rusku</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m013-d-id145246-punct">
   <w.rf>
    <LM>w#w-d-id145246-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
