<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_035.13.w.gz" />
  </references>
 </head>
 <s id="m035-543">
  <m id="m035-d1t3824-4">
   <w.rf>
    <LM>w#w-d1t3824-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3824-1">
   <w.rf>
    <LM>w#w-d1t3824-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3824-5">
   <w.rf>
    <LM>w#w-d1t3824-5</LM>
   </w.rf>
   <form>jede</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3824-6">
   <w.rf>
    <LM>w#w-d1t3824-6</LM>
   </w.rf>
   <form>rychlejší</form>
   <lemma>rychlý</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m035-543-544">
   <w.rf>
    <LM>w#w-543-544</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3826-1">
   <w.rf>
    <LM>w#w-d1t3826-1</LM>
   </w.rf>
   <form>řekne</form>
   <lemma>říci</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m035-543-545">
   <w.rf>
    <LM>w#w-543-545</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-543-546">
   <w.rf>
    <LM>w#w-543-546</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3826-2">
   <w.rf>
    <LM>w#w-d1t3826-2</LM>
   </w.rf>
   <form>Stopa</form>
   <lemma>stopa_^(míra;_otisk_s.;_s._po_něčem_[malé_množství])</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m035-543-556">
   <w.rf>
    <LM>w#w-543-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-543-547">
   <w.rf>
    <LM>w#w-543-547</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-558">
  <m id="m035-543-548">
   <w.rf>
    <LM>w#w-543-548</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m035-d1t3826-4">
   <w.rf>
    <LM>w#w-d1t3826-4</LM>
   </w.rf>
   <form>uvolním</form>
   <lemma>uvolnit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m035-543-551">
   <w.rf>
    <LM>w#w-543-551</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-543-552">
   <w.rf>
    <LM>w#w-543-552</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m035-543-549">
   <w.rf>
    <LM>w#w-543-549</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-543-550">
   <w.rf>
    <LM>w#w-543-550</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3826-5">
   <w.rf>
    <LM>w#w-d1t3826-5</LM>
   </w.rf>
   <form>Díky</form>
   <lemma>dík-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-d-id194055-punct">
   <w.rf>
    <LM>w#w-d-id194055-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3826-7">
   <w.rf>
    <LM>w#w-d1t3826-7</LM>
   </w.rf>
   <form>ahoj</form>
   <lemma>ahoj</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m035-543-553">
   <w.rf>
    <LM>w#w-543-553</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-543-554">
   <w.rf>
    <LM>w#w-543-554</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-555">
  <m id="m035-d1t3826-12">
   <w.rf>
    <LM>w#w-d1t3826-12</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3826-13">
   <w.rf>
    <LM>w#w-d1t3826-13</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS3-P1-------</tag>
  </m>
  <m id="m035-d1t3826-14">
   <w.rf>
    <LM>w#w-d1t3826-14</LM>
   </w.rf>
   <form>holce</form>
   <lemma>holka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m035-555-559">
   <w.rf>
    <LM>w#w-555-559</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-555-561">
   <w.rf>
    <LM>w#w-555-561</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-555-562">
   <w.rf>
    <LM>w#w-555-562</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-555-397">
   <w.rf>
    <LM>w#w-555-397</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-d1t3826-19">
   <w.rf>
    <LM>w#w-d1t3826-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3826-20">
   <w.rf>
    <LM>w#w-d1t3826-20</LM>
   </w.rf>
   <form>běžkách</form>
   <lemma>běžka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m035-d1t3826-18">
   <w.rf>
    <LM>w#w-d1t3826-18</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3826-17">
   <w.rf>
    <LM>w#w-d1t3826-17</LM>
   </w.rf>
   <form>inteligentní</form>
   <lemma>inteligentní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-555-724">
   <w.rf>
    <LM>w#w-555-724</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-725">
  <m id="m035-d1t3828-1">
   <w.rf>
    <LM>w#w-d1t3828-1</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m035-555-564">
   <w.rf>
    <LM>w#w-555-564</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-555-565">
   <w.rf>
    <LM>w#w-555-565</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3828-2">
   <w.rf>
    <LM>w#w-d1t3828-2</LM>
   </w.rf>
   <form>Vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-555-566">
   <w.rf>
    <LM>w#w-555-566</LM>
   </w.rf>
   <form>ses</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4--------s-</tag>
  </m>
  <m id="m035-d1t3828-6">
   <w.rf>
    <LM>w#w-d1t3828-6</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m035-d1t3828-5">
   <w.rf>
    <LM>w#w-d1t3828-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3828-7">
   <w.rf>
    <LM>w#w-d1t3828-7</LM>
   </w.rf>
   <form>smál</form>
   <lemma>smát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-555-567">
   <w.rf>
    <LM>w#w-555-567</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-555-569">
   <w.rf>
    <LM>w#w-555-569</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-568">
  <m id="m035-d1t3828-10">
   <w.rf>
    <LM>w#w-d1t3828-10</LM>
   </w.rf>
   <form>Povídal</form>
   <lemma>povídat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-568-570">
   <w.rf>
    <LM>w#w-568-570</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-568-571">
   <w.rf>
    <LM>w#w-568-571</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-568-572">
   <w.rf>
    <LM>w#w-568-572</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3828-14">
   <w.rf>
    <LM>w#w-d1t3828-14</LM>
   </w.rf>
   <form>Smál</form>
   <lemma>smát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3828-12">
   <w.rf>
    <LM>w#w-d1t3828-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3828-13">
   <w.rf>
    <LM>w#w-d1t3828-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-568-573">
   <w.rf>
    <LM>w#w-568-573</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3828-15">
   <w.rf>
    <LM>w#w-d1t3828-15</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3828-16">
   <w.rf>
    <LM>w#w-d1t3828-16</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m035-d1t3828-17">
   <w.rf>
    <LM>w#w-d1t3828-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3828-18">
   <w.rf>
    <LM>w#w-d1t3828-18</LM>
   </w.rf>
   <form>smějete</form>
   <lemma>smát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t3828-19">
   <w.rf>
    <LM>w#w-d1t3828-19</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3828-20">
   <w.rf>
    <LM>w#w-d1t3828-20</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m035-d-m-d1e3797-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3797-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-583">
  <m id="m035-d1t3836-3">
   <w.rf>
    <LM>w#w-d1t3836-3</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3836-4">
   <w.rf>
    <LM>w#w-d1t3836-4</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m035-d1t3836-5">
   <w.rf>
    <LM>w#w-d1t3836-5</LM>
   </w.rf>
   <form>staří</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d-id194646-punct">
   <w.rf>
    <LM>w#w-d-id194646-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3836-8">
   <w.rf>
    <LM>w#w-d1t3836-8</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m035-d1t3836-9">
   <w.rf>
    <LM>w#w-d1t3836-9</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3836-10">
   <w.rf>
    <LM>w#w-d1t3836-10</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1t3836-11">
   <w.rf>
    <LM>w#w-d1t3836-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3836-12">
   <w.rf>
    <LM>w#w-d1t3836-12</LM>
   </w.rf>
   <form>běžkách</form>
   <lemma>běžka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3831-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3831-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-583-584">
   <w.rf>
    <LM>w#w-583-584</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3843-x2">
  <m id="m035-d1t3846-3">
   <w.rf>
    <LM>w#w-d1t3846-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3846-1">
   <w.rf>
    <LM>w#w-d1t3846-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3846-2">
   <w.rf>
    <LM>w#w-d1t3846-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3846-4">
   <w.rf>
    <LM>w#w-d1t3846-4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3846-5">
   <w.rf>
    <LM>w#w-d1t3846-5</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m035-d-id194898-punct">
   <w.rf>
    <LM>w#w-d-id194898-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3848-1">
   <w.rf>
    <LM>w#w-d1t3848-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3848-2">
   <w.rf>
    <LM>w#w-d1t3848-2</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1t3848-3">
   <w.rf>
    <LM>w#w-d1t3848-3</LM>
   </w.rf>
   <form>vidí</form>
   <lemma>vidět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3848-6">
   <w.rf>
    <LM>w#w-d1t3848-6</LM>
   </w.rf>
   <form>krajinu</form>
   <lemma>krajina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3843-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3843-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3850-x2">
  <m id="m035-d1t3853-1">
   <w.rf>
    <LM>w#w-d1t3853-1</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3853-2">
   <w.rf>
    <LM>w#w-d1t3853-2</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3853-3">
   <w.rf>
    <LM>w#w-d1t3853-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3853-4">
   <w.rf>
    <LM>w#w-d1t3853-4</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t3853-5">
   <w.rf>
    <LM>w#w-d1t3853-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3853-6">
   <w.rf>
    <LM>w#w-d1t3853-6</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m035-d-id195166-punct">
   <w.rf>
    <LM>w#w-d-id195166-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3854-x2">
  <m id="m035-d1t3857-1">
   <w.rf>
    <LM>w#w-d1t3857-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1e3854-x2-588">
   <w.rf>
    <LM>w#w-d1e3854-x2-588</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3857-2">
   <w.rf>
    <LM>w#w-d1t3857-2</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-m-d1e3854-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3854-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3858-x3">
  <m id="m035-d1t3867-1">
   <w.rf>
    <LM>w#w-d1t3867-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m035-d1t3867-2">
   <w.rf>
    <LM>w#w-d1t3867-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m035-d1t3867-3">
   <w.rf>
    <LM>w#w-d1t3867-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3867-4">
   <w.rf>
    <LM>w#w-d1t3867-4</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3867-5">
   <w.rf>
    <LM>w#w-d1t3867-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-d-id195461-punct">
   <w.rf>
    <LM>w#w-d-id195461-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3868-x2">
  <m id="m035-d1e3868-x2-590">
   <w.rf>
    <LM>w#w-d1e3868-x2-590</LM>
   </w.rf>
   <form>75</form>
   <lemma>75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d-m-d1e3868-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3868-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3872-x2">
  <m id="m035-d1t3875-2">
   <w.rf>
    <LM>w#w-d1t3875-2</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t3875-3">
   <w.rf>
    <LM>w#w-d1t3875-3</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d-m-d1e3872-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3872-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3876-x2">
  <m id="m035-d1t3885-1">
   <w.rf>
    <LM>w#w-d1t3885-1</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m035-d1e3876-x2-594">
   <w.rf>
    <LM>w#w-d1e3876-x2-594</LM>
   </w.rf>
   <form>prozatím</form>
   <lemma>prozatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3885-3">
   <w.rf>
    <LM>w#w-d1t3885-3</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m035-d1t3885-4">
   <w.rf>
    <LM>w#w-d1t3885-4</LM>
   </w.rf>
   <form>nebolí</form>
   <lemma>bolet</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m035-d-id195858-punct">
   <w.rf>
    <LM>w#w-d-id195858-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3885-8">
   <w.rf>
    <LM>w#w-d1t3885-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3885-10">
   <w.rf>
    <LM>w#w-d1t3885-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3885-9">
   <w.rf>
    <LM>w#w-d1t3885-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3885-12">
   <w.rf>
    <LM>w#w-d1t3885-12</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1e3876-x2-595">
   <w.rf>
    <LM>w#w-d1e3876-x2-595</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-597">
  <m id="m035-d1t3885-16">
   <w.rf>
    <LM>w#w-d1t3885-16</LM>
   </w.rf>
   <form>Obden</form>
   <lemma>obden</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3885-17">
   <w.rf>
    <LM>w#w-d1t3885-17</LM>
   </w.rf>
   <form>cvičím</form>
   <lemma>cvičit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3887-3">
   <w.rf>
    <LM>w#w-d1t3887-3</LM>
   </w.rf>
   <form>hodinu</form>
   <lemma>hodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d1t3887-4">
   <w.rf>
    <LM>w#w-d1t3887-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3887-5">
   <w.rf>
    <LM>w#w-d1t3887-5</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m035-d1t3887-1">
   <w.rf>
    <LM>w#w-d1t3887-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3887-2">
   <w.rf>
    <LM>w#w-d1t3887-2</LM>
   </w.rf>
   <form>posilovně</form>
   <lemma>posilovna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t3887-7">
   <w.rf>
    <LM>w#w-d1t3887-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3887-8">
   <w.rf>
    <LM>w#w-d1t3887-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3887-9">
   <w.rf>
    <LM>w#w-d1t3887-9</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-d1t3887-10">
   <w.rf>
    <LM>w#w-d1t3887-10</LM>
   </w.rf>
   <form>najedu</form>
   <lemma>najet</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m035-d1t3887-12">
   <w.rf>
    <LM>w#w-d1t3887-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3887-13">
   <w.rf>
    <LM>w#w-d1t3887-13</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t3890-6">
   <w.rf>
    <LM>w#w-d1t3890-6</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-597-598">
   <w.rf>
    <LM>w#w-597-598</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>3000</form>
   <lemma>3000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t3890-10">
   <w.rf>
    <LM>w#w-d1t3890-10</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m035-597-599">
   <w.rf>
    <LM>w#w-597-599</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-600">
  <m id="m035-d1t3896-2">
   <w.rf>
    <LM>w#w-d1t3896-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3896-3">
   <w.rf>
    <LM>w#w-d1t3896-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3896-1">
   <w.rf>
    <LM>w#w-d1t3896-1</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3896-4">
   <w.rf>
    <LM>w#w-d1t3896-4</LM>
   </w.rf>
   <form>věnuju</form>
   <lemma>věnovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3896-5">
   <w.rf>
    <LM>w#w-d1t3896-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3896-6">
   <w.rf>
    <LM>w#w-d1t3896-6</LM>
   </w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3876-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3876-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3897-x3">
  <m id="m035-d1t3912-7">
   <w.rf>
    <LM>w#w-d1t3912-7</LM>
   </w.rf>
   <form>Nezačínal</form>
   <lemma>začínat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m035-d1t3912-6">
   <w.rf>
    <LM>w#w-d1t3912-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3906-1">
   <w.rf>
    <LM>w#w-d1t3906-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1e3897-x3-613">
   <w.rf>
    <LM>w#w-d1e3897-x3-613</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3912-8">
   <w.rf>
    <LM>w#w-d1t3912-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3912-9">
   <w.rf>
    <LM>w#w-d1t3912-9</LM>
   </w.rf>
   <form>penzi</form>
   <lemma>penze</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1e3897-x3-614">
   <w.rf>
    <LM>w#w-d1e3897-x3-614</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-615">
  <m id="m035-d1t3916-14">
   <w.rf>
    <LM>w#w-d1t3916-14</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3916-16">
   <w.rf>
    <LM>w#w-d1t3916-16</LM>
   </w.rf>
   <form>Orlíku</form>
   <lemma>Orlík_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m035-d1t3918-1">
   <w.rf>
    <LM>w#w-d1t3918-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3918-2">
   <w.rf>
    <LM>w#w-d1t3918-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3918-4">
   <w.rf>
    <LM>w#w-d1t3918-4</LM>
   </w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d1t3918-5">
   <w.rf>
    <LM>w#w-d1t3918-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3918-6">
   <w.rf>
    <LM>w#w-d1t3918-6</LM>
   </w.rf>
   <form>dílny</form>
   <lemma>dílna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d-id197140-punct">
   <w.rf>
    <LM>w#w-d-id197140-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3925-1">
   <w.rf>
    <LM>w#w-d1t3925-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3925-3">
   <w.rf>
    <LM>w#w-d1t3925-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3925-4">
   <w.rf>
    <LM>w#w-d1t3925-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3925-5">
   <w.rf>
    <LM>w#w-d1t3925-5</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3925-6">
   <w.rf>
    <LM>w#w-d1t3925-6</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3925-7">
   <w.rf>
    <LM>w#w-d1t3925-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3925-8">
   <w.rf>
    <LM>w#w-d1t3925-8</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-615-616">
   <w.rf>
    <LM>w#w-615-616</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3925-10">
   <w.rf>
    <LM>w#w-d1t3925-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3925-11">
   <w.rf>
    <LM>w#w-d1t3925-11</LM>
   </w.rf>
   <form>běhal</form>
   <lemma>běhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-615-617">
   <w.rf>
    <LM>w#w-615-617</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-620">
  <m id="m035-d1t3925-15">
   <w.rf>
    <LM>w#w-d1t3925-15</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3925-14">
   <w.rf>
    <LM>w#w-d1t3925-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3925-13">
   <w.rf>
    <LM>w#w-d1t3925-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3927-1">
   <w.rf>
    <LM>w#w-d1t3927-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m035-d1t3927-2">
   <w.rf>
    <LM>w#w-d1t3927-2</LM>
   </w.rf>
   <form>skříni</form>
   <lemma>skříň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t3925-16">
   <w.rf>
    <LM>w#w-d1t3925-16</LM>
   </w.rf>
   <form>šaty</form>
   <lemma>šat</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-620-621">
   <w.rf>
    <LM>w#w-620-621</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-622">
  <m id="m035-d1t3927-4">
   <w.rf>
    <LM>w#w-d1t3927-4</LM>
   </w.rf>
   <form>Přiběhl</form>
   <lemma>přiběhnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m035-d1t3927-5">
   <w.rf>
    <LM>w#w-d1t3927-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3927-6">
   <w.rf>
    <LM>w#w-d1t3927-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-id197486-punct">
   <w.rf>
    <LM>w#w-d-id197486-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3927-8">
   <w.rf>
    <LM>w#w-d1t3927-8</LM>
   </w.rf>
   <form>vykoupal</form>
   <lemma>vykoupat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-622-623">
   <w.rf>
    <LM>w#w-622-623</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d-id197510-punct">
   <w.rf>
    <LM>w#w-d-id197510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3929-1">
   <w.rf>
    <LM>w#w-d1t3929-1</LM>
   </w.rf>
   <form>převlékl</form>
   <lemma>převléknout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m035-d1t3929-2">
   <w.rf>
    <LM>w#w-d1t3929-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3929-3">
   <w.rf>
    <LM>w#w-d1t3929-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3929-5">
   <w.rf>
    <LM>w#w-d1t3929-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3929-6">
   <w.rf>
    <LM>w#w-d1t3929-6</LM>
   </w.rf>
   <form>běžel</form>
   <lemma>běžet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3929-4">
   <w.rf>
    <LM>w#w-d1t3929-4</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-622-638">
   <w.rf>
    <LM>w#w-622-638</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3909-x3">
  <m id="m035-d1t3931-3">
   <w.rf>
    <LM>w#w-d1t3931-3</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3931-2">
   <w.rf>
    <LM>w#w-d1t3931-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3931-4">
   <w.rf>
    <LM>w#w-d1t3931-4</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m035-d1t3933-1">
   <w.rf>
    <LM>w#w-d1t3933-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3933-2">
   <w.rf>
    <LM>w#w-d1t3933-2</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m035-d1t3933-3">
   <w.rf>
    <LM>w#w-d1t3933-3</LM>
   </w.rf>
   <form>líný</form>
   <lemma>líný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1e3909-x3-639">
   <w.rf>
    <LM>w#w-d1e3909-x3-639</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-640">
  <m id="m035-d1t3933-7">
   <w.rf>
    <LM>w#w-d1t3933-7</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3933-8">
   <w.rf>
    <LM>w#w-d1t3933-8</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m035-d1t3933-6">
   <w.rf>
    <LM>w#w-d1t3933-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3933-9">
   <w.rf>
    <LM>w#w-d1t3933-9</LM>
   </w.rf>
   <form>hrál</form>
   <lemma>hrát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3933-10">
   <w.rf>
    <LM>w#w-d1t3933-10</LM>
   </w.rf>
   <form>fotbal</form>
   <lemma>fotbal</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t3933-11">
   <w.rf>
    <LM>w#w-d1t3933-11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3933-12">
   <w.rf>
    <LM>w#w-d1t3933-12</LM>
   </w.rf>
   <form>hokej</form>
   <lemma>hokej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t3933-16">
   <w.rf>
    <LM>w#w-d1t3933-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3933-17">
   <w.rf>
    <LM>w#w-d1t3933-17</LM>
   </w.rf>
   <form>běhal</form>
   <lemma>běhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3933-18">
   <w.rf>
    <LM>w#w-d1t3933-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3933-19">
   <w.rf>
    <LM>w#w-d1t3933-19</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3909-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3909-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3937-x2">
  <m id="m035-d1t3942-5">
   <w.rf>
    <LM>w#w-d1t3942-5</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t3942-2">
   <w.rf>
    <LM>w#w-d1t3942-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3942-3">
   <w.rf>
    <LM>w#w-d1t3942-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t3942-4">
   <w.rf>
    <LM>w#w-d1t3942-4</LM>
   </w.rf>
   <form>věnoval</form>
   <lemma>věnovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t3942-6">
   <w.rf>
    <LM>w#w-d1t3942-6</LM>
   </w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3937-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3937-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3937-x3">
  <m id="m035-d1e3937-x3-760">
   <w.rf>
    <LM>w#w-d1e3937-x3-760</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3944-2">
   <w.rf>
    <LM>w#w-d1t3944-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t3944-3">
   <w.rf>
    <LM>w#w-d1t3944-3</LM>
   </w.rf>
   <form>sportovec</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3937-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3937-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3945-x2">
  <m id="m035-d1e3945-x2-660">
   <w.rf>
    <LM>w#w-d1e3945-x2-660</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1e3945-x2-661">
   <w.rf>
    <LM>w#w-d1e3945-x2-661</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3950-1">
   <w.rf>
    <LM>w#w-d1t3950-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3950-2">
   <w.rf>
    <LM>w#w-d1t3950-2</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m035-d1t3950-4">
   <w.rf>
    <LM>w#w-d1t3950-4</LM>
   </w.rf>
   <form>normální</form>
   <lemma>normální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-d1t3952-2">
   <w.rf>
    <LM>w#w-d1t3952-2</LM>
   </w.rf>
   <form>sportovec</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1e3945-x2-662">
   <w.rf>
    <LM>w#w-d1e3945-x2-662</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-663">
  <m id="m035-d1t3952-3">
   <w.rf>
    <LM>w#w-d1t3952-3</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3952-4">
   <w.rf>
    <LM>w#w-d1t3952-4</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m035-d1t3952-5">
   <w.rf>
    <LM>w#w-d1t3952-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3952-8">
   <w.rf>
    <LM>w#w-d1t3952-8</LM>
   </w.rf>
   <form>nechtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m035-d1t3952-9">
   <w.rf>
    <LM>w#w-d1t3952-9</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1t3952-7">
   <w.rf>
    <LM>w#w-d1t3952-7</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d-id198501-punct">
   <w.rf>
    <LM>w#w-d-id198501-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-663-668">
   <w.rf>
    <LM>w#w-663-668</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3954-5">
   <w.rf>
    <LM>w#w-d1t3954-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-663-669">
   <w.rf>
    <LM>w#w-663-669</LM>
   </w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-663-670">
   <w.rf>
    <LM>w#w-663-670</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m035-d1t3954-7">
   <w.rf>
    <LM>w#w-d1t3954-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-663-400">
   <w.rf>
    <LM>w#w-663-400</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-663-401">
   <w.rf>
    <LM>w#w-663-401</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m035-d1t3954-9">
   <w.rf>
    <LM>w#w-d1t3954-9</LM>
   </w.rf>
   <form>invalidé</form>
   <lemma>invalida</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m035-663-671">
   <w.rf>
    <LM>w#w-663-671</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-672">
  <m id="m035-d1t3954-13">
   <w.rf>
    <LM>w#w-d1t3954-13</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3954-16">
   <w.rf>
    <LM>w#w-d1t3954-16</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m035-d1t3954-14">
   <w.rf>
    <LM>w#w-d1t3954-14</LM>
   </w.rf>
   <form>oddělané</form>
   <lemma>oddělaný_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m035-d1t3954-15">
   <w.rf>
    <LM>w#w-d1t3954-15</LM>
   </w.rf>
   <form>klouby</form>
   <lemma>kloub</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-d-id198740-punct">
   <w.rf>
    <LM>w#w-d-id198740-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3954-20">
   <w.rf>
    <LM>w#w-d1t3954-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3954-19">
   <w.rf>
    <LM>w#w-d1t3954-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3954-21">
   <w.rf>
    <LM>w#w-d1t3954-21</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m035-d1t3954-22">
   <w.rf>
    <LM>w#w-d1t3954-22</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-672-673">
   <w.rf>
    <LM>w#w-672-673</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-674">
  <m id="m035-d1t3954-31">
   <w.rf>
    <LM>w#w-d1t3954-31</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m035-d1t3954-32">
   <w.rf>
    <LM>w#w-d1t3954-32</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3954-33">
   <w.rf>
    <LM>w#w-d1t3954-33</LM>
   </w.rf>
   <form>sportovali</form>
   <lemma>sportovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t3954-34">
   <w.rf>
    <LM>w#w-d1t3954-34</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3954-35">
   <w.rf>
    <LM>w#w-d1t3954-35</LM>
   </w.rf>
   <form>buřta</form>
   <lemma>buřt-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m035-674-693">
   <w.rf>
    <LM>w#w-674-693</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3962-1">
   <w.rf>
    <LM>w#w-d1t3962-1</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m035-d1t3962-2">
   <w.rf>
    <LM>w#w-d1t3962-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t3962-3">
   <w.rf>
    <LM>w#w-d1t3962-3</LM>
   </w.rf>
   <form>miliony</form>
   <lemma>milion`1000000_,s_^(^DD**milión)</lemma>
   <tag>CzIP4----------</tag>
  </m>
  <m id="m035-d-id199141-punct">
   <w.rf>
    <LM>w#w-d-id199141-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3962-10">
   <w.rf>
    <LM>w#w-d1t3962-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t3962-11">
   <w.rf>
    <LM>w#w-d1t3962-11</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3962-12">
   <w.rf>
    <LM>w#w-d1t3962-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t3962-14">
   <w.rf>
    <LM>w#w-d1t3962-14</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t3962-15">
   <w.rf>
    <LM>w#w-d1t3962-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t3962-16">
   <w.rf>
    <LM>w#w-d1t3962-16</LM>
   </w.rf>
   <form>tolika</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m035-d1t3962-17">
   <w.rf>
    <LM>w#w-d1t3962-17</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m035-d1t3962-13">
   <w.rf>
    <LM>w#w-d1t3962-13</LM>
   </w.rf>
   <form>zdraví</form>
   <lemma>zdravý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m035-d-m-d1e3957-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3957-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-692">
  <m id="m035-d1t3971-4">
   <w.rf>
    <LM>w#w-d1t3971-4</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3975-1">
   <w.rf>
    <LM>w#w-d1t3975-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-692-15">
   <w.rf>
    <LM>w#w-692-15</LM>
   </w.rf>
   <form>kdejaký</form>
   <lemma>kdejaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m035-d1t3973-2">
   <w.rf>
    <LM>w#w-d1t3973-2</LM>
   </w.rf>
   <form>sportovec</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-692-16">
   <w.rf>
    <LM>w#w-692-16</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3973-3">
   <w.rf>
    <LM>w#w-d1t3973-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3973-5">
   <w.rf>
    <LM>w#w-d1t3973-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3973-4">
   <w.rf>
    <LM>w#w-d1t3973-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m035-692-17">
   <w.rf>
    <LM>w#w-692-17</LM>
   </w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t3973-7">
   <w.rf>
    <LM>w#w-d1t3973-7</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m035-d-id199501-punct">
   <w.rf>
    <LM>w#w-d-id199501-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-692-18">
   <w.rf>
    <LM>w#w-692-18</LM>
   </w.rf>
   <form>zničené</form>
   <lemma>zničený_^(*3it)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m035-d1t3975-2">
   <w.rf>
    <LM>w#w-d1t3975-2</LM>
   </w.rf>
   <form>klouby</form>
   <lemma>kloub</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-692-19">
   <w.rf>
    <LM>w#w-692-19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-20">
  <m id="m035-d1t3977-6">
   <w.rf>
    <LM>w#w-d1t3977-6</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3977-7">
   <w.rf>
    <LM>w#w-d1t3977-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3977-8">
   <w.rf>
    <LM>w#w-d1t3977-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3977-9">
   <w.rf>
    <LM>w#w-d1t3977-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t3977-11">
   <w.rf>
    <LM>w#w-d1t3977-11</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1t3977-12">
   <w.rf>
    <LM>w#w-d1t3977-12</LM>
   </w.rf>
   <form>styl</form>
   <lemma>styl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-d1t3977-10">
   <w.rf>
    <LM>w#w-d1t3977-10</LM>
   </w.rf>
   <form>sportu</form>
   <lemma>sport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-d-m-d1e3968-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3968-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3980-x3">
  <m id="m035-d1t3987-1">
   <w.rf>
    <LM>w#w-d1t3987-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m035-d1t3987-2">
   <w.rf>
    <LM>w#w-d1t3987-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1e3980-x3-27">
   <w.rf>
    <LM>w#w-d1e3980-x3-27</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3987-4">
   <w.rf>
    <LM>w#w-d1t3987-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3987-5">
   <w.rf>
    <LM>w#w-d1t3987-5</LM>
   </w.rf>
   <form>buřta</form>
   <lemma>buřt-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m035-d-id200012-punct">
   <w.rf>
    <LM>w#w-d-id200012-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3988-x2">
  <m id="m035-d1t3991-1">
   <w.rf>
    <LM>w#w-d1t3991-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e3988-x2-28">
   <w.rf>
    <LM>w#w-d1e3988-x2-28</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3992-x2">
  <m id="m035-d1t3995-1">
   <w.rf>
    <LM>w#w-d1t3995-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m035-d1t3995-2">
   <w.rf>
    <LM>w#w-d1t3995-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1e3992-x2-30">
   <w.rf>
    <LM>w#w-d1e3992-x2-30</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1e3992-x2-828">
   <w.rf>
    <LM>w#w-d1e3992-x2-828</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3995-4">
   <w.rf>
    <LM>w#w-d1t3995-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t3995-5">
   <w.rf>
    <LM>w#w-d1t3995-5</LM>
   </w.rf>
   <form>buřta</form>
   <lemma>buřt-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m035-d1e3992-x2-829">
   <w.rf>
    <LM>w#w-d1e3992-x2-829</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d-id200212-punct">
   <w.rf>
    <LM>w#w-d-id200212-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3996-x2">
  <m id="m035-d1e3996-x2-41">
   <w.rf>
    <LM>w#w-d1e3996-x2-41</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1e3996-x2-42">
   <w.rf>
    <LM>w#w-d1e3996-x2-42</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e3996-x2-44">
   <w.rf>
    <LM>w#w-d1e3996-x2-44</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3999-3">
   <w.rf>
    <LM>w#w-d1t3999-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3999-4">
   <w.rf>
    <LM>w#w-d1t3999-4</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t3999-7">
   <w.rf>
    <LM>w#w-d1t3999-7</LM>
   </w.rf>
   <form>oddělané</form>
   <lemma>oddělaný_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m035-d1t3999-8">
   <w.rf>
    <LM>w#w-d1t3999-8</LM>
   </w.rf>
   <form>klouby</form>
   <lemma>kloub</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m035-d-id200385-punct">
   <w.rf>
    <LM>w#w-d-id200385-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t3999-10">
   <w.rf>
    <LM>w#w-d1t3999-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t3999-15">
   <w.rf>
    <LM>w#w-d1t3999-15</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m035-d1t4001-1">
   <w.rf>
    <LM>w#w-d1t4001-1</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t3999-16">
   <w.rf>
    <LM>w#w-d1t3999-16</LM>
   </w.rf>
   <form>namáhavé</form>
   <lemma>namáhavý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m035-d1t4001-4">
   <w.rf>
    <LM>w#w-d1t4001-4</LM>
   </w.rf>
   <form>tréninky</form>
   <lemma>trénink</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m035-d1e3996-x2-45">
   <w.rf>
    <LM>w#w-d1e3996-x2-45</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-46">
  <m id="m035-46-47">
   <w.rf>
    <LM>w#w-46-47</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m035-d1t4005-2">
   <w.rf>
    <LM>w#w-d1t4005-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4005-3">
   <w.rf>
    <LM>w#w-d1t4005-3</LM>
   </w.rf>
   <form>trénovali</form>
   <lemma>trénovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-46-48">
   <w.rf>
    <LM>w#w-46-48</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4005-4">
   <w.rf>
    <LM>w#w-d1t4005-4</LM>
   </w.rf>
   <form>úterý</form>
   <lemma>úterý</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m035-46-50">
   <w.rf>
    <LM>w#w-46-50</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-46-51">
   <w.rf>
    <LM>w#w-46-51</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m035-d1t4005-6">
   <w.rf>
    <LM>w#w-d1t4005-6</LM>
   </w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-46-52">
   <w.rf>
    <LM>w#w-46-52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-54">
  <m id="m035-d1t4007-2">
   <w.rf>
    <LM>w#w-d1t4007-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4007-3">
   <w.rf>
    <LM>w#w-d1t4007-3</LM>
   </w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d1t4007-4">
   <w.rf>
    <LM>w#w-d1t4007-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t4007-5">
   <w.rf>
    <LM>w#w-d1t4007-5</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-d1t4007-6">
   <w.rf>
    <LM>w#w-d1t4007-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4007-7">
   <w.rf>
    <LM>w#w-d1t4007-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4007-8">
   <w.rf>
    <LM>w#w-d1t4007-8</LM>
   </w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m035-d1t4007-9">
   <w.rf>
    <LM>w#w-d1t4007-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t4007-10">
   <w.rf>
    <LM>w#w-d1t4007-10</LM>
   </w.rf>
   <form>hrálo</form>
   <lemma>hrát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-54-55">
   <w.rf>
    <LM>w#w-54-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-60">
  <m id="m035-60-403">
   <w.rf>
    <LM>w#w-60-403</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4010-7">
   <w.rf>
    <LM>w#w-d1t4010-7</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m035-60-404">
   <w.rf>
    <LM>w#w-60-404</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4010-8">
   <w.rf>
    <LM>w#w-d1t4010-8</LM>
   </w.rf>
   <form>škváry</form>
   <lemma>škvár</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m035-60-61">
   <w.rf>
    <LM>w#w-60-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-64">
  <m id="m035-d1t4012-1">
   <w.rf>
    <LM>w#w-d1t4012-1</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m035-d1t4012-3">
   <w.rf>
    <LM>w#w-d1t4012-3</LM>
   </w.rf>
   <form>travnaté</form>
   <lemma>travnatý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m035-d1t4012-2">
   <w.rf>
    <LM>w#w-d1t4012-2</LM>
   </w.rf>
   <form>hřiště</form>
   <lemma>hřiště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-d1t4012-4">
   <w.rf>
    <LM>w#w-d1t4012-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4012-5">
   <w.rf>
    <LM>w#w-d1t4012-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4012-7">
   <w.rf>
    <LM>w#w-d1t4012-7</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-64-66">
   <w.rf>
    <LM>w#w-64-66</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4012-23">
   <w.rf>
    <LM>w#w-d1t4012-23</LM>
   </w.rf>
   <form>Štruncovy</form>
   <lemma>Štruncův_;Y_^(*2)</lemma>
   <tag>AUIP1M---------</tag>
  </m>
  <m id="m035-d1t4012-24">
   <w.rf>
    <LM>w#w-d1t4012-24</LM>
   </w.rf>
   <form>sady</form>
   <lemma>sad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m035-64-67">
   <w.rf>
    <LM>w#w-64-67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4012-20">
   <w.rf>
    <LM>w#w-d1t4012-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t4012-21">
   <w.rf>
    <LM>w#w-d1t4012-21</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-64-68">
   <w.rf>
    <LM>w#w-64-68</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4012-19">
   <w.rf>
    <LM>w#w-d1t4012-19</LM>
   </w.rf>
   <form>teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-64-69">
   <w.rf>
    <LM>w#w-64-69</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t4012-10">
   <w.rf>
    <LM>w#w-d1t4012-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4012-14">
   <w.rf>
    <LM>w#w-d1t4012-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4012-15">
   <w.rf>
    <LM>w#w-d1t4012-15</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m035-64-70">
   <w.rf>
    <LM>w#w-64-70</LM>
   </w.rf>
   <form>1955</form>
   <lemma>1955</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t4012-11">
   <w.rf>
    <LM>w#w-d1t4012-11</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1t4012-12">
   <w.rf>
    <LM>w#w-d1t4012-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t4012-13">
   <w.rf>
    <LM>w#w-d1t4012-13</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m035-64-71">
   <w.rf>
    <LM>w#w-64-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e3996-x3">
  <m id="m035-d1t4016-3">
   <w.rf>
    <LM>w#w-d1t4016-3</LM>
   </w.rf>
   <form>Prvně</form>
   <lemma>prvně</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t4016-2">
   <w.rf>
    <LM>w#w-d1t4016-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e3996-x3-101">
   <w.rf>
    <LM>w#w-d1e3996-x3-101</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1e3996-x3-102">
   <w.rf>
    <LM>w#w-d1e3996-x3-102</LM>
   </w.rf>
   <form>trénink</form>
   <lemma>trénink</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1e3996-x3-103">
   <w.rf>
    <LM>w#w-d1e3996-x3-103</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4018-1">
   <w.rf>
    <LM>w#w-d1t4018-1</LM>
   </w.rf>
   <form>trávě</form>
   <lemma>tráva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t4018-2">
   <w.rf>
    <LM>w#w-d1t4018-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1e3996-x3-105">
   <w.rf>
    <LM>w#w-d1e3996-x3-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-106">
  <m id="m035-d1t4020-2">
   <w.rf>
    <LM>w#w-d1t4020-2</LM>
   </w.rf>
   <form>Hokej</form>
   <lemma>hokej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t4020-4">
   <w.rf>
    <LM>w#w-d1t4020-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4020-5">
   <w.rf>
    <LM>w#w-d1t4020-5</LM>
   </w.rf>
   <form>nehráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m035-106-107">
   <w.rf>
    <LM>w#w-106-107</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4020-8">
   <w.rf>
    <LM>w#w-d1t4020-8</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFS6----------</tag>
  </m>
  <m id="m035-d1t4020-9">
   <w.rf>
    <LM>w#w-d1t4020-9</LM>
   </w.rf>
   <form>zastřešené</form>
   <lemma>zastřešený_^(*3it)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m035-106-108">
   <w.rf>
    <LM>w#w-106-108</LM>
   </w.rf>
   <form>hale</form>
   <lemma>hala</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-106-109">
   <w.rf>
    <LM>w#w-106-109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-110">
  <m id="m035-d1t4020-15">
   <w.rf>
    <LM>w#w-d1t4020-15</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4020-13">
   <w.rf>
    <LM>w#w-d1t4020-13</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-110-112">
   <w.rf>
    <LM>w#w-110-112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-110-111">
   <w.rf>
    <LM>w#w-110-111</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t4023-1">
   <w.rf>
    <LM>w#w-d1t4023-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4023-2">
   <w.rf>
    <LM>w#w-d1t4023-2</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t4023-8">
   <w.rf>
    <LM>w#w-d1t4023-8</LM>
   </w.rf>
   <form>hokej</form>
   <lemma>hokej</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t4023-3">
   <w.rf>
    <LM>w#w-d1t4023-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4023-5">
   <w.rf>
    <LM>w#w-d1t4023-5</LM>
   </w.rf>
   <form>Banské</form>
   <lemma>banský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m035-d1t4023-6">
   <w.rf>
    <LM>w#w-d1t4023-6</LM>
   </w.rf>
   <form>Bystrici</form>
   <lemma>Bystrica_;G</lemma>
   <tag>NNFS6-----A---1</tag>
  </m>
  <m id="m035-d1t4023-10">
   <w.rf>
    <LM>w#w-d1t4023-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-110-113">
   <w.rf>
    <LM>w#w-110-113</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m035-110-114">
   <w.rf>
    <LM>w#w-110-114</LM>
   </w.rf>
   <form>28</form>
   <lemma>28</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m035-d1t4023-12">
   <w.rf>
    <LM>w#w-d1t4023-12</LM>
   </w.rf>
   <form>stupňů</form>
   <lemma>stupeň</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m035-d1t4023-13">
   <w.rf>
    <LM>w#w-d1t4023-13</LM>
   </w.rf>
   <form>mrazu</form>
   <lemma>mráz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m035-110-115">
   <w.rf>
    <LM>w#w-110-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-119">
  <m id="m035-d1t4023-17">
   <w.rf>
    <LM>w#w-d1t4023-17</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m035-d1t4023-18">
   <w.rf>
    <LM>w#w-d1t4023-18</LM>
   </w.rf>
   <form>lavici</form>
   <lemma>lavice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m035-d1t4023-16">
   <w.rf>
    <LM>w#w-d1t4023-16</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m035-d1t4023-19">
   <w.rf>
    <LM>w#w-d1t4023-19</LM>
   </w.rf>
   <form>položené</form>
   <lemma>položený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m035-d1t4023-21">
   <w.rf>
    <LM>w#w-d1t4023-21</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4023-20">
   <w.rf>
    <LM>w#w-d1t4023-20</LM>
   </w.rf>
   <form>deky</form>
   <lemma>deka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m035-119-120">
   <w.rf>
    <LM>w#w-119-120</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-121">
  <m id="m035-d1t4023-25">
   <w.rf>
    <LM>w#w-d1t4023-25</LM>
   </w.rf>
   <form>Nehrálo</form>
   <lemma>hrát</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m035-d1t4023-26">
   <w.rf>
    <LM>w#w-d1t4023-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t4023-27">
   <w.rf>
    <LM>w#w-d1t4023-27</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4023-28">
   <w.rf>
    <LM>w#w-d1t4023-28</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m035-d1t4023-29">
   <w.rf>
    <LM>w#w-d1t4023-29</LM>
   </w.rf>
   <form>pětky</form>
   <lemma>pětka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d-id202038-punct">
   <w.rf>
    <LM>w#w-d-id202038-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-121-123">
   <w.rf>
    <LM>w#w-121-123</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4025-1">
   <w.rf>
    <LM>w#w-d1t4025-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4025-2">
   <w.rf>
    <LM>w#w-d1t4025-2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m035-d1t4025-3">
   <w.rf>
    <LM>w#w-d1t4025-3</LM>
   </w.rf>
   <form>pětky</form>
   <lemma>pětka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-121-124">
   <w.rf>
    <LM>w#w-121-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-128">
  <m id="m035-d1t4025-7">
   <w.rf>
    <LM>w#w-d1t4025-7</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t4025-6">
   <w.rf>
    <LM>w#w-d1t4025-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t4025-8">
   <w.rf>
    <LM>w#w-d1t4025-8</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m035-d1t4025-9">
   <w.rf>
    <LM>w#w-d1t4025-9</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1t4025-10">
   <w.rf>
    <LM>w#w-d1t4025-10</LM>
   </w.rf>
   <form>styl</form>
   <lemma>styl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-d1t4025-12">
   <w.rf>
    <LM>w#w-d1t4025-12</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t4025-13">
   <w.rf>
    <LM>w#w-d1t4025-13</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-128-129">
   <w.rf>
    <LM>w#w-128-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-130">
  <m id="m035-d1t4027-5">
   <w.rf>
    <LM>w#w-d1t4027-5</LM>
   </w.rf>
   <form>Člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m035-d1t4027-4">
   <w.rf>
    <LM>w#w-d1t4027-4</LM>
   </w.rf>
   <form>přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m035-d1t4027-6">
   <w.rf>
    <LM>w#w-d1t4027-6</LM>
   </w.rf>
   <form>zpocený</form>
   <lemma>zpocený_^(*4tit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m035-130-142">
   <w.rf>
    <LM>w#w-130-142</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4027-9">
   <w.rf>
    <LM>w#w-d1t4027-9</LM>
   </w.rf>
   <form>sedl</form>
   <lemma>sednout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m035-d1t4027-8">
   <w.rf>
    <LM>w#w-d1t4027-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m035-d1t4027-7">
   <w.rf>
    <LM>w#w-d1t4027-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4027-10">
   <w.rf>
    <LM>w#w-d1t4027-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4027-11">
   <w.rf>
    <LM>w#w-d1t4027-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4027-12">
   <w.rf>
    <LM>w#w-d1t4027-12</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m035-d1t4027-13">
   <w.rf>
    <LM>w#w-d1t4027-13</LM>
   </w.rf>
   <form>minuty</form>
   <lemma>minuta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m035-d1t4027-15">
   <w.rf>
    <LM>w#w-d1t4027-15</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m035-d1t4027-16">
   <w.rf>
    <LM>w#w-d1t4027-16</LM>
   </w.rf>
   <form>znova</form>
   <lemma>znova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-130-143">
   <w.rf>
    <LM>w#w-130-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-144">
  <m id="m035-d1t4029-5">
   <w.rf>
    <LM>w#w-d1t4029-5</LM>
   </w.rf>
   <form>Marod</form>
   <lemma>marod-2_,h</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m035-d1t4029-4">
   <w.rf>
    <LM>w#w-d1t4029-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4029-2">
   <w.rf>
    <LM>w#w-d1t4029-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4029-3">
   <w.rf>
    <LM>w#w-d1t4029-3</LM>
   </w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m035-d-m-d1e3996-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3996-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e4030-x3">
  <m id="m035-d1t4039-1">
   <w.rf>
    <LM>w#w-d1t4039-1</LM>
   </w.rf>
   <form>Myslela</form>
   <lemma>myslit</lemma>
   <tag>VpQW----R-AAI-1</tag>
  </m>
  <m id="m035-d1t4039-2">
   <w.rf>
    <LM>w#w-d1t4039-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m035-d1e4030-x3-157">
   <w.rf>
    <LM>w#w-d1e4030-x3-157</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4039-3">
   <w.rf>
    <LM>w#w-d1t4039-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m035-d1t4039-5">
   <w.rf>
    <LM>w#w-d1t4039-5</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1e4030-x3-825">
   <w.rf>
    <LM>w#w-d1e4030-x3-825</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4039-6">
   <w.rf>
    <LM>w#w-d1t4039-6</LM>
   </w.rf>
   <form>hrát</form>
   <lemma>hrát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1t4039-7">
   <w.rf>
    <LM>w#w-d1t4039-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m035-d1t4039-8">
   <w.rf>
    <LM>w#w-d1t4039-8</LM>
   </w.rf>
   <form>buřta</form>
   <lemma>buřt-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m035-d1e4030-x3-826">
   <w.rf>
    <LM>w#w-d1e4030-x3-826</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d-id202791-punct">
   <w.rf>
    <LM>w#w-d-id202791-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e4040-x2">
  <m id="m035-d1t4043-13">
   <w.rf>
    <LM>w#w-d1t4043-13</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t4043-11">
   <w.rf>
    <LM>w#w-d1t4043-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4043-12">
   <w.rf>
    <LM>w#w-d1t4043-12</LM>
   </w.rf>
   <form>špekáček</form>
   <lemma>špekáček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1e4040-x2-161">
   <w.rf>
    <LM>w#w-d1e4040-x2-161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4043-14">
   <w.rf>
    <LM>w#w-d1t4043-14</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4043-15">
   <w.rf>
    <LM>w#w-d1t4043-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m035-d-id203045-punct">
   <w.rf>
    <LM>w#w-d-id203045-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4043-18">
   <w.rf>
    <LM>w#w-d1t4043-18</LM>
   </w.rf>
   <form>zadarmo</form>
   <lemma>zadarmo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d-m-d1e4040-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4040-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e4044-x2">
  <m id="m035-d1t4049-5">
   <w.rf>
    <LM>w#w-d1t4049-5</LM>
   </w.rf>
   <form>Přeháněli</form>
   <lemma>přehánět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t4049-4">
   <w.rf>
    <LM>w#w-d1t4049-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1e4044-x2-165">
   <w.rf>
    <LM>w#w-d1e4044-x2-165</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e4044-x2-166">
   <w.rf>
    <LM>w#w-d1e4044-x2-166</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4062-3">
   <w.rf>
    <LM>w#w-d1t4062-3</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m035-d1t4062-4">
   <w.rf>
    <LM>w#w-d1t4062-4</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m035-d1t4062-5">
   <w.rf>
    <LM>w#w-d1t4062-5</LM>
   </w.rf>
   <form>prachů</form>
   <lemma>prachy</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m035-d1e4044-x2-167">
   <w.rf>
    <LM>w#w-d1e4044-x2-167</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4062-7">
   <w.rf>
    <LM>w#w-d1t4062-7</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m035-d1t4062-8">
   <w.rf>
    <LM>w#w-d1t4062-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m035-d1t4062-9">
   <w.rf>
    <LM>w#w-d1t4062-9</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m035-d1t4062-10">
   <w.rf>
    <LM>w#w-d1t4062-10</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4064-2">
   <w.rf>
    <LM>w#w-d1t4064-2</LM>
   </w.rf>
   <form>špekáček</form>
   <lemma>špekáček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m035-d1t4066-1">
   <w.rf>
    <LM>w#w-d1t4066-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m035-d1t4066-2">
   <w.rf>
    <LM>w#w-d1t4066-2</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m035-d1t4066-3">
   <w.rf>
    <LM>w#w-d1t4066-3</LM>
   </w.rf>
   <form>koruny</form>
   <lemma>koruna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m035-d-m-d1e4059-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4059-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1e4044-x2-169">
   <w.rf>
    <LM>w#w-d1e4044-x2-169</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-d1e4075-x2">
  <m id="m035-d1t4082-9">
   <w.rf>
    <LM>w#w-d1t4082-9</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1t4082-10">
   <w.rf>
    <LM>w#w-d1t4082-10</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m035-d1t4082-11">
   <w.rf>
    <LM>w#w-d1t4082-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-d1t4082-12">
   <w.rf>
    <LM>w#w-d1t4082-12</LM>
   </w.rf>
   <form>dobrý</form>
   <lemma>dobrý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m035-d1e4075-x2-191">
   <w.rf>
    <LM>w#w-d1e4075-x2-191</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4080-1">
   <w.rf>
    <LM>w#w-d1t4080-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m035-d1t4082-4">
   <w.rf>
    <LM>w#w-d1t4082-4</LM>
   </w.rf>
   <form>nesmí</form>
   <lemma>smět</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m035-d1t4082-5">
   <w.rf>
    <LM>w#w-d1t4082-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m035-d1t4082-6">
   <w.rf>
    <LM>w#w-d1t4082-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m035-d1t4082-7">
   <w.rf>
    <LM>w#w-d1t4082-7</LM>
   </w.rf>
   <form>přehánět</form>
   <lemma>přehánět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m035-d1e4075-x2-192">
   <w.rf>
    <LM>w#w-d1e4075-x2-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m035-196">
  <m id="m035-d1t4084-3">
   <w.rf>
    <LM>w#w-d1t4084-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m035-d1t4084-4">
   <w.rf>
    <LM>w#w-d1t4084-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4084-5">
   <w.rf>
    <LM>w#w-d1t4084-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-196-197">
   <w.rf>
    <LM>w#w-196-197</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m035-d1t4084-6">
   <w.rf>
    <LM>w#w-d1t4084-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-196-198">
   <w.rf>
    <LM>w#w-196-198</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m035-d1t4084-8">
   <w.rf>
    <LM>w#w-d1t4084-8</LM>
   </w.rf>
   <form>eso</form>
   <lemma>eso</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m035-196-199">
   <w.rf>
    <LM>w#w-196-199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m035-d1t4084-10">
   <w.rf>
    <LM>w#w-d1t4084-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m035-d1t4084-13">
   <w.rf>
    <LM>w#w-d1t4084-13</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m035-196-200">
   <w.rf>
    <LM>w#w-196-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
