<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_050.02.w.gz" />
  </references>
 </head>
 <s id="m050-d1e546-x2">
  <m id="m050-d1t551-1">
   <w.rf>
    <LM>w#w-d1t551-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t551-2">
   <w.rf>
    <LM>w#w-d1t551-2</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m050-d1t551-3">
   <w.rf>
    <LM>w#w-d1t551-3</LM>
   </w.rf>
   <form>bratry</form>
   <lemma>bratr</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m050-d-id71770-punct">
   <w.rf>
    <LM>w#w-d-id71770-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t551-5">
   <w.rf>
    <LM>w#w-d1t551-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t551-6">
   <w.rf>
    <LM>w#w-d1t551-6</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t551-7">
   <w.rf>
    <LM>w#w-d1t551-7</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m050-d1t551-9">
   <w.rf>
    <LM>w#w-d1t551-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t551-11">
   <w.rf>
    <LM>w#w-d1t551-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t551-12">
   <w.rf>
    <LM>w#w-d1t551-12</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1t551-10">
   <w.rf>
    <LM>w#w-d1t551-10</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m050-d-m-d1e546-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e546-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e552-x2">
  <m id="m050-d1t557-1">
   <w.rf>
    <LM>w#w-d1t557-1</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t557-2">
   <w.rf>
    <LM>w#w-d1t557-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t557-3">
   <w.rf>
    <LM>w#w-d1t557-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t557-4">
   <w.rf>
    <LM>w#w-d1t557-4</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m050-d-id72007-punct">
   <w.rf>
    <LM>w#w-d-id72007-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t559-2">
   <w.rf>
    <LM>w#w-d1t559-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t559-3">
   <w.rf>
    <LM>w#w-d1t559-3</LM>
   </w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m050-d1t559-4">
   <w.rf>
    <LM>w#w-d1t559-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m050-d1t561-1">
   <w.rf>
    <LM>w#w-d1t561-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t561-2">
   <w.rf>
    <LM>w#w-d1t561-2</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m050-d1t561-3">
   <w.rf>
    <LM>w#w-d1t561-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m050-d-m-d1e552-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e552-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e569-x2">
  <m id="m050-d1t572-1">
   <w.rf>
    <LM>w#w-d1t572-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t572-2">
   <w.rf>
    <LM>w#w-d1t572-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t572-3">
   <w.rf>
    <LM>w#w-d1t572-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m050-d1t572-4">
   <w.rf>
    <LM>w#w-d1t572-4</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t572-5">
   <w.rf>
    <LM>w#w-d1t572-5</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m050-d-id72286-punct">
   <w.rf>
    <LM>w#w-d-id72286-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e573-x2">
  <m id="m050-d1t576-1">
   <w.rf>
    <LM>w#w-d1t576-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m050-d1t576-2">
   <w.rf>
    <LM>w#w-d1t576-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m050-d1e573-x2-99">
   <w.rf>
    <LM>w#w-d1e573-x2-99</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1e573-x2-98">
   <w.rf>
    <LM>w#w-d1e573-x2-98</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t576-5">
   <w.rf>
    <LM>w#w-d1t576-5</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1e573-x2-100">
   <w.rf>
    <LM>w#w-d1e573-x2-100</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1e573-x2-71">
   <w.rf>
    <LM>w#w-d1e573-x2-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-73">
  <m id="m050-d1t576-7">
   <w.rf>
    <LM>w#w-d1t576-7</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t576-8">
   <w.rf>
    <LM>w#w-d1t576-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d1t576-9">
   <w.rf>
    <LM>w#w-d1t576-9</LM>
   </w.rf>
   <form>hrál</form>
   <lemma>hrát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t576-10">
   <w.rf>
    <LM>w#w-d1t576-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t576-11">
   <w.rf>
    <LM>w#w-d1t576-11</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m050-d1t576-12">
   <w.rf>
    <LM>w#w-d1t576-12</LM>
   </w.rf>
   <form>jiným</form>
   <lemma>jiný</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m050-d1t576-13">
   <w.rf>
    <LM>w#w-d1t576-13</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t576-15">
   <w.rf>
    <LM>w#w-d1t576-15</LM>
   </w.rf>
   <form>běhal</form>
   <lemma>běhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t576-16">
   <w.rf>
    <LM>w#w-d1t576-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m050-d1t576-18">
   <w.rf>
    <LM>w#w-d1t576-18</LM>
   </w.rf>
   <form>staršími</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP7----2A----</tag>
  </m>
  <m id="m050-d1t576-17">
   <w.rf>
    <LM>w#w-d1t576-17</LM>
   </w.rf>
   <form>kluky</form>
   <lemma>kluk</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m050-73-74">
   <w.rf>
    <LM>w#w-73-74</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-75">
  <m id="m050-d1t580-4">
   <w.rf>
    <LM>w#w-d1t580-4</LM>
   </w.rf>
   <form>Fotili</form>
   <lemma>fotit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t580-2">
   <w.rf>
    <LM>w#w-d1t580-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t580-3">
   <w.rf>
    <LM>w#w-d1t580-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t580-5">
   <w.rf>
    <LM>w#w-d1t580-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t580-6">
   <w.rf>
    <LM>w#w-d1t580-6</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t580-7">
   <w.rf>
    <LM>w#w-d1t580-7</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e573-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e573-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e583-x2">
  <m id="m050-d1t590-1">
   <w.rf>
    <LM>w#w-d1t590-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t590-2">
   <w.rf>
    <LM>w#w-d1t590-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t590-3">
   <w.rf>
    <LM>w#w-d1t590-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m050-d1t590-5">
   <w.rf>
    <LM>w#w-d1t590-5</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m050-d1t590-6">
   <w.rf>
    <LM>w#w-d1t590-6</LM>
   </w.rf>
   <form>sestřenice</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1e583-x2-77">
   <w.rf>
    <LM>w#w-d1e583-x2-77</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e591-x2">
  <m id="m050-d1t596-1">
   <w.rf>
    <LM>w#w-d1t596-1</LM>
   </w.rf>
   <form>Sestřenice</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t596-2">
   <w.rf>
    <LM>w#w-d1t596-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t596-4">
   <w.rf>
    <LM>w#w-d1t596-4</LM>
   </w.rf>
   <form>Alenka</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t600-1">
   <w.rf>
    <LM>w#w-d1t600-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t600-2">
   <w.rf>
    <LM>w#w-d1t600-2</LM>
   </w.rf>
   <form>bráška</form>
   <lemma>bráška</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t600-3">
   <w.rf>
    <LM>w#w-d1t600-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t600-5">
   <w.rf>
    <LM>w#w-d1t600-5</LM>
   </w.rf>
   <form>Milan</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d-m-d1e591-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e591-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e603-x2">
  <m id="m050-d1t610-1">
   <w.rf>
    <LM>w#w-d1t610-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t610-4">
   <w.rf>
    <LM>w#w-d1t610-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t610-3">
   <w.rf>
    <LM>w#w-d1t610-3</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t610-7">
   <w.rf>
    <LM>w#w-d1t610-7</LM>
   </w.rf>
   <form>Tymákov</form>
   <lemma>Tymákov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d-id73317-punct">
   <w.rf>
    <LM>w#w-d-id73317-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e611-x2">
  <m id="m050-d1t618-2">
   <w.rf>
    <LM>w#w-d1t618-2</LM>
   </w.rf>
   <form>Tymákov</form>
   <lemma>Tymákov_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d1t618-4">
   <w.rf>
    <LM>w#w-d1t618-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t618-5">
   <w.rf>
    <LM>w#w-d1t618-5</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d-id73461-punct">
   <w.rf>
    <LM>w#w-d-id73461-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t618-7">
   <w.rf>
    <LM>w#w-d1t618-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t618-8">
   <w.rf>
    <LM>w#w-d1t618-8</LM>
   </w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m050-d1t618-9">
   <w.rf>
    <LM>w#w-d1t618-9</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m050-d1t618-10">
   <w.rf>
    <LM>w#w-d1t618-10</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t618-12">
   <w.rf>
    <LM>w#w-d1t618-12</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-d1e611-x2-101">
   <w.rf>
    <LM>w#w-d1e611-x2-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-102">
  <m id="m050-d1t618-15">
   <w.rf>
    <LM>w#w-d1t618-15</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m050-d1t618-16">
   <w.rf>
    <LM>w#w-d1t618-16</LM>
   </w.rf>
   <form>teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t618-17">
   <w.rf>
    <LM>w#w-d1t618-17</LM>
   </w.rf>
   <form>bydlíme</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t618-18">
   <w.rf>
    <LM>w#w-d1t618-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t618-20">
   <w.rf>
    <LM>w#w-d1t618-20</LM>
   </w.rf>
   <form>Božkově</form>
   <lemma>Božkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d-id73655-punct">
   <w.rf>
    <LM>w#w-d-id73655-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t618-23">
   <w.rf>
    <LM>w#w-d1t618-23</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t622-2">
   <w.rf>
    <LM>w#w-d1t622-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t622-1">
   <w.rf>
    <LM>w#w-d1t622-1</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m050-d1t622-3">
   <w.rf>
    <LM>w#w-d1t622-3</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-102-103">
   <w.rf>
    <LM>w#w-102-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-104">
  <m id="m050-d1t627-3">
   <w.rf>
    <LM>w#w-d1t627-3</LM>
   </w.rf>
   <form>Vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t627-2">
   <w.rf>
    <LM>w#w-d1t627-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t627-4">
   <w.rf>
    <LM>w#w-d1t627-4</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t627-5">
   <w.rf>
    <LM>w#w-d1t627-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t627-7">
   <w.rf>
    <LM>w#w-d1t627-7</LM>
   </w.rf>
   <form>Božkově</form>
   <lemma>Božkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d1t627-9">
   <w.rf>
    <LM>w#w-d1t627-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t627-10">
   <w.rf>
    <LM>w#w-d1t627-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m050-d1t627-11">
   <w.rf>
    <LM>w#w-d1t627-11</LM>
   </w.rf>
   <form>babičce</form>
   <lemma>babička</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m050-d1t627-12">
   <w.rf>
    <LM>w#w-d1t627-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t627-13">
   <w.rf>
    <LM>w#w-d1t627-13</LM>
   </w.rf>
   <form>dojížděli</form>
   <lemma>dojíždět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-104-105">
   <w.rf>
    <LM>w#w-104-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-106">
  <m id="m050-d1t629-1">
   <w.rf>
    <LM>w#w-d1t629-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m050-d1t629-2">
   <w.rf>
    <LM>w#w-d1t629-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t629-3">
   <w.rf>
    <LM>w#w-d1t629-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t629-4">
   <w.rf>
    <LM>w#w-d1t629-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t629-5">
   <w.rf>
    <LM>w#w-d1t629-5</LM>
   </w.rf>
   <form>nejblíž</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m050-106-110">
   <w.rf>
    <LM>w#w-106-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-111">
  <m id="m050-d1t631-2">
   <w.rf>
    <LM>w#w-d1t631-2</LM>
   </w.rf>
   <form>Sestřenice</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t631-4">
   <w.rf>
    <LM>w#w-d1t631-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t631-5">
   <w.rf>
    <LM>w#w-d1t631-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t631-6">
   <w.rf>
    <LM>w#w-d1t631-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t631-8">
   <w.rf>
    <LM>w#w-d1t631-8</LM>
   </w.rf>
   <form>Kraslic</form>
   <lemma>Kraslice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m050-d-id74143-punct">
   <w.rf>
    <LM>w#w-d-id74143-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t633-2">
   <w.rf>
    <LM>w#w-d1t633-2</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m050-d1t633-3">
   <w.rf>
    <LM>w#w-d1t633-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t633-4">
   <w.rf>
    <LM>w#w-d1t633-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t633-5">
   <w.rf>
    <LM>w#w-d1t633-5</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m050-111-299">
   <w.rf>
    <LM>w#w-111-299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-300">
  <m id="m050-d1t635-1">
   <w.rf>
    <LM>w#w-d1t635-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m050-d1t635-2">
   <w.rf>
    <LM>w#w-d1t635-2</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t635-3">
   <w.rf>
    <LM>w#w-d1t635-3</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t635-4">
   <w.rf>
    <LM>w#w-d1t635-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t635-5">
   <w.rf>
    <LM>w#w-d1t635-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t635-7">
   <w.rf>
    <LM>w#w-d1t635-7</LM>
   </w.rf>
   <form>prázdniny</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d-id74342-punct">
   <w.rf>
    <LM>w#w-d-id74342-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t635-9">
   <w.rf>
    <LM>w#w-d1t635-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t635-11">
   <w.rf>
    <LM>w#w-d1t635-11</LM>
   </w.rf>
   <form>posvícení</form>
   <lemma>posvícení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m050-d-id74390-punct">
   <w.rf>
    <LM>w#w-d-id74390-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t635-13">
   <w.rf>
    <LM>w#w-d1t635-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t635-15">
   <w.rf>
    <LM>w#w-d1t635-15</LM>
   </w.rf>
   <form>pouť</form>
   <lemma>pouť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-111-74">
   <w.rf>
    <LM>w#w-111-74</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e611-x3">
  <m id="m050-d1t635-17">
   <w.rf>
    <LM>w#w-d1t635-17</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m050-d1t635-18">
   <w.rf>
    <LM>w#w-d1t635-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t635-19">
   <w.rf>
    <LM>w#w-d1t635-19</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t635-20">
   <w.rf>
    <LM>w#w-d1t635-20</LM>
   </w.rf>
   <form>babičkou</form>
   <lemma>babička</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m050-d1t635-21">
   <w.rf>
    <LM>w#w-d1t635-21</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t638-1">
   <w.rf>
    <LM>w#w-d1t638-1</LM>
   </w.rf>
   <form>téměř</form>
   <lemma>téměř</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t638-2">
   <w.rf>
    <LM>w#w-d1t638-2</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m050-d1t638-3">
   <w.rf>
    <LM>w#w-d1t638-3</LM>
   </w.rf>
   <form>víkend</form>
   <lemma>víkend</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d-m-d1e611-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e611-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e641-x2">
  <m id="m050-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t646-2">
   <w.rf>
    <LM>w#w-d1t646-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t646-4">
   <w.rf>
    <LM>w#w-d1t646-4</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t646-5">
   <w.rf>
    <LM>w#w-d1t646-5</LM>
   </w.rf>
   <form>vypadalo</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d-id74728-punct">
   <w.rf>
    <LM>w#w-d-id74728-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e647-x2">
  <m id="m050-d1t652-3">
   <w.rf>
    <LM>w#w-d1t652-3</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t652-4">
   <w.rf>
    <LM>w#w-d1t652-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t652-5">
   <w.rf>
    <LM>w#w-d1t652-5</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1e647-x2-134">
   <w.rf>
    <LM>w#w-d1e647-x2-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-135">
  <m id="m050-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t654-4">
   <w.rf>
    <LM>w#w-d1t654-4</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t654-3">
   <w.rf>
    <LM>w#w-d1t654-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d1t656-1">
   <w.rf>
    <LM>w#w-d1t656-1</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m050-d1t656-2">
   <w.rf>
    <LM>w#w-d1t656-2</LM>
   </w.rf>
   <form>stavení</form>
   <lemma>stavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m050-d-id74993-punct">
   <w.rf>
    <LM>w#w-d-id74993-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t658-1">
   <w.rf>
    <LM>w#w-d1t658-1</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m050-d1t658-2">
   <w.rf>
    <LM>w#w-d1t658-2</LM>
   </w.rf>
   <form>zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t658-4">
   <w.rf>
    <LM>w#w-d1t658-4</LM>
   </w.rf>
   <form>ovocnými</form>
   <lemma>ovocný</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m050-d1t658-5">
   <w.rf>
    <LM>w#w-d1t658-5</LM>
   </w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m050-d1t661-1">
   <w.rf>
    <LM>w#w-d1t661-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t661-2">
   <w.rf>
    <LM>w#w-d1t661-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t661-3">
   <w.rf>
    <LM>w#w-d1t661-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t661-4">
   <w.rf>
    <LM>w#w-d1t661-4</LM>
   </w.rf>
   <form>nějakými</form>
   <lemma>nějaký</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m050-d1t661-5">
   <w.rf>
    <LM>w#w-d1t661-5</LM>
   </w.rf>
   <form>záhonky</form>
   <lemma>záhonek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m050-135-136">
   <w.rf>
    <LM>w#w-135-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-137">
  <m id="m050-d1t661-7">
   <w.rf>
    <LM>w#w-d1t661-7</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t661-9">
   <w.rf>
    <LM>w#w-d1t661-9</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-137-138">
   <w.rf>
    <LM>w#w-137-138</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t661-10">
   <w.rf>
    <LM>w#w-d1t661-10</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t661-11">
   <w.rf>
    <LM>w#w-d1t661-11</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t661-12">
   <w.rf>
    <LM>w#w-d1t661-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t661-15">
   <w.rf>
    <LM>w#w-d1t661-15</LM>
   </w.rf>
   <form>domácí</form>
   <lemma>domácí-1</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m050-d1t661-14">
   <w.rf>
    <LM>w#w-d1t661-14</LM>
   </w.rf>
   <form>zvířata</form>
   <lemma>zvíře</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m050-137-139">
   <w.rf>
    <LM>w#w-137-139</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-140">
  <m id="m050-d1t663-3">
   <w.rf>
    <LM>w#w-d1t663-3</LM>
   </w.rf>
   <form>Se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m050-d1t663-5">
   <w.rf>
    <LM>w#w-d1t663-5</LM>
   </w.rf>
   <form>sestřenicí</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m050-d1t661-18">
   <w.rf>
    <LM>w#w-d1t661-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t663-1">
   <w.rf>
    <LM>w#w-d1t663-1</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-id75429-punct">
   <w.rf>
    <LM>w#w-d-id75429-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t663-7">
   <w.rf>
    <LM>w#w-d1t663-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t663-8">
   <w.rf>
    <LM>w#w-d1t663-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t663-9">
   <w.rf>
    <LM>w#w-d1t663-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t663-10">
   <w.rf>
    <LM>w#w-d1t663-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m050-d1t663-11">
   <w.rf>
    <LM>w#w-d1t663-11</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m050-d-id75516-punct">
   <w.rf>
    <LM>w#w-d-id75516-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t663-16">
   <w.rf>
    <LM>w#w-d1t663-16</LM>
   </w.rf>
   <form>honily</form>
   <lemma>honit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m050-d1t663-17">
   <w.rf>
    <LM>w#w-d1t663-17</LM>
   </w.rf>
   <form>husy</form>
   <lemma>husa</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d1t663-20">
   <w.rf>
    <LM>w#w-d1t663-20</LM>
   </w.rf>
   <form>vykoupat</form>
   <lemma>vykoupat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m050-d1t663-18">
   <w.rf>
    <LM>w#w-d1t663-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t663-19">
   <w.rf>
    <LM>w#w-d1t663-19</LM>
   </w.rf>
   <form>rybníka</form>
   <lemma>rybník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m050-140-141">
   <w.rf>
    <LM>w#w-140-141</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-142">
  <m id="m050-d1t671-1">
   <w.rf>
    <LM>w#w-d1t671-1</LM>
   </w.rf>
   <form>Líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t671-2">
   <w.rf>
    <LM>w#w-d1t671-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t671-3">
   <w.rf>
    <LM>w#w-d1t671-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m050-d1t671-4">
   <w.rf>
    <LM>w#w-d1t671-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e647-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e647-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e675-x2">
  <m id="m050-d1t680-1">
   <w.rf>
    <LM>w#w-d1t680-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t680-2">
   <w.rf>
    <LM>w#w-d1t680-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t680-3">
   <w.rf>
    <LM>w#w-d1t680-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t680-4">
   <w.rf>
    <LM>w#w-d1t680-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t680-5">
   <w.rf>
    <LM>w#w-d1t680-5</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m050-d-id75903-punct">
   <w.rf>
    <LM>w#w-d-id75903-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e682-x2">
  <m id="m050-d1t691-1">
   <w.rf>
    <LM>w#w-d1t691-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m050-d1t691-8">
   <w.rf>
    <LM>w#w-d1t691-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t691-10">
   <w.rf>
    <LM>w#w-d1t691-10</LM>
   </w.rf>
   <form>příbuzenstva</form>
   <lemma>příbuzenstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m050-d1t691-2">
   <w.rf>
    <LM>w#w-d1t691-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t691-3">
   <w.rf>
    <LM>w#w-d1t691-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d1t691-4">
   <w.rf>
    <LM>w#w-d1t691-4</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t691-5">
   <w.rf>
    <LM>w#w-d1t691-5</LM>
   </w.rf>
   <form>vystačili</form>
   <lemma>vystačit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m050-d1t691-6">
   <w.rf>
    <LM>w#w-d1t691-6</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m050-d1e682-x2-149">
   <w.rf>
    <LM>w#w-d1e682-x2-149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-150">
  <m id="m050-d1t693-4">
   <w.rf>
    <LM>w#w-d1t693-4</LM>
   </w.rf>
   <form>Kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t693-5">
   <w.rf>
    <LM>w#w-d1t693-5</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m050-d1t693-6">
   <w.rf>
    <LM>w#w-d1t693-6</LM>
   </w.rf>
   <form>sestřenic</form>
   <lemma>sestřenice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m050-150-323">
   <w.rf>
    <LM>w#w-150-323</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t693-16">
   <w.rf>
    <LM>w#w-d1t693-16</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t693-18">
   <w.rf>
    <LM>w#w-d1t693-18</LM>
   </w.rf>
   <form>druhých</form>
   <lemma>druhý`2</lemma>
   <tag>CrFP2----------</tag>
  </m>
  <m id="m050-d1t693-19">
   <w.rf>
    <LM>w#w-d1t693-19</LM>
   </w.rf>
   <form>sestřenic</form>
   <lemma>sestřenice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m050-d-id76452-punct">
   <w.rf>
    <LM>w#w-d-id76452-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t696-1">
   <w.rf>
    <LM>w#w-d1t696-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t696-2">
   <w.rf>
    <LM>w#w-d1t696-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t693-21">
   <w.rf>
    <LM>w#w-d1t693-21</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t693-22">
   <w.rf>
    <LM>w#w-d1t693-22</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t696-4">
   <w.rf>
    <LM>w#w-d1t696-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d1t696-5">
   <w.rf>
    <LM>w#w-d1t696-5</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t696-6">
   <w.rf>
    <LM>w#w-d1t696-6</LM>
   </w.rf>
   <form>neznala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m050-d-m-d1e682-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e682-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e699-x2">
  <m id="m050-d1t704-1">
   <w.rf>
    <LM>w#w-d1t704-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1e699-x2-152">
   <w.rf>
    <LM>w#w-d1e699-x2-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-153">
  <m id="m050-d1t706-3">
   <w.rf>
    <LM>w#w-d1t706-3</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t706-4">
   <w.rf>
    <LM>w#w-d1t706-4</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d1t706-2">
   <w.rf>
    <LM>w#w-d1t706-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m050-d1t706-1">
   <w.rf>
    <LM>w#w-d1t706-1</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t706-5">
   <w.rf>
    <LM>w#w-d1t706-5</LM>
   </w.rf>
   <form>patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d-id76773-punct">
   <w.rf>
    <LM>w#w-d-id76773-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e707-x2">
  <m id="m050-d1t714-1">
   <w.rf>
    <LM>w#w-d1t714-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1e707-x2-158">
   <w.rf>
    <LM>w#w-d1e707-x2-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-159">
  <m id="m050-d1t716-1">
   <w.rf>
    <LM>w#w-d1t716-1</LM>
   </w.rf>
   <form>Patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m050-159-160">
   <w.rf>
    <LM>w#w-159-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-161">
  <m id="m050-d1t718-4">
   <w.rf>
    <LM>w#w-d1t718-4</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t718-6">
   <w.rf>
    <LM>w#w-d1t718-6</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t718-5">
   <w.rf>
    <LM>w#w-d1t718-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t718-7">
   <w.rf>
    <LM>w#w-d1t718-7</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t718-8">
   <w.rf>
    <LM>w#w-d1t718-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t718-10">
   <w.rf>
    <LM>w#w-d1t718-10</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-161-130">
   <w.rf>
    <LM>w#w-161-130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-163">
  <m id="m050-d1t721-3">
   <w.rf>
    <LM>w#w-d1t721-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t721-4">
   <w.rf>
    <LM>w#w-d1t721-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m050-d1t721-5">
   <w.rf>
    <LM>w#w-d1t721-5</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d1t721-1">
   <w.rf>
    <LM>w#w-d1t721-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t721-2">
   <w.rf>
    <LM>w#w-d1t721-2</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t721-6">
   <w.rf>
    <LM>w#w-d1t721-6</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m050-d1t721-7">
   <w.rf>
    <LM>w#w-d1t721-7</LM>
   </w.rf>
   <form>nebydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m050-163-131">
   <w.rf>
    <LM>w#w-163-131</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-161-162">
   <w.rf>
    <LM>w#w-161-162</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t721-12">
   <w.rf>
    <LM>w#w-d1t721-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t721-15">
   <w.rf>
    <LM>w#w-d1t721-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t721-16">
   <w.rf>
    <LM>w#w-d1t721-16</LM>
   </w.rf>
   <form>dnešní</form>
   <lemma>dnešní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m050-d1t721-17">
   <w.rf>
    <LM>w#w-d1t721-17</LM>
   </w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d1t721-11">
   <w.rf>
    <LM>w#w-d1t721-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t721-13">
   <w.rf>
    <LM>w#w-d1t721-13</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t721-18">
   <w.rf>
    <LM>w#w-d1t721-18</LM>
   </w.rf>
   <form>starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m050-163-164">
   <w.rf>
    <LM>w#w-163-164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-165">
  <m id="m050-d1t723-1">
   <w.rf>
    <LM>w#w-d1t723-1</LM>
   </w.rf>
   <form>Buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t723-2">
   <w.rf>
    <LM>w#w-d1t723-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t723-4">
   <w.rf>
    <LM>w#w-d1t723-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t723-5">
   <w.rf>
    <LM>w#w-d1t723-5</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m050-d1t723-6">
   <w.rf>
    <LM>w#w-d1t723-6</LM>
   </w.rf>
   <form>prodávat</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-165-166">
   <w.rf>
    <LM>w#w-165-166</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t723-7">
   <w.rf>
    <LM>w#w-d1t723-7</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t723-8">
   <w.rf>
    <LM>w#w-d1t723-8</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m050-165-169">
   <w.rf>
    <LM>w#w-165-169</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t723-10">
   <w.rf>
    <LM>w#w-d1t723-10</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t727-2">
   <w.rf>
    <LM>w#w-d1t727-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t727-3">
   <w.rf>
    <LM>w#w-d1t727-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m050-d1t729-1">
   <w.rf>
    <LM>w#w-d1t729-1</LM>
   </w.rf>
   <form>naložíme</form>
   <lemma>naložit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m050-165-167">
   <w.rf>
    <LM>w#w-165-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e732-x2">
  <m id="m050-d1t739-3">
   <w.rf>
    <LM>w#w-d1t739-3</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d-id77745-punct">
   <w.rf>
    <LM>w#w-d-id77745-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t743-1">
   <w.rf>
    <LM>w#w-d1t743-1</LM>
   </w.rf>
   <form>dokud</form>
   <lemma>dokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t743-2">
   <w.rf>
    <LM>w#w-d1t743-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m050-d1t743-3">
   <w.rf>
    <LM>w#w-d1t743-3</LM>
   </w.rf>
   <form>bereme</form>
   <lemma>brát</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t743-4">
   <w.rf>
    <LM>w#w-d1t743-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t743-5">
   <w.rf>
    <LM>w#w-d1t743-5</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d-id77898-punct">
   <w.rf>
    <LM>w#w-d-id77898-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t743-8">
   <w.rf>
    <LM>w#w-d1t743-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t743-9">
   <w.rf>
    <LM>w#w-d1t743-9</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t743-10">
   <w.rf>
    <LM>w#w-d1t743-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t743-11">
   <w.rf>
    <LM>w#w-d1t743-11</LM>
   </w.rf>
   <form>držet</form>
   <lemma>držet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d-m-d1e732-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e732-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e753-x2">
  <m id="m050-d1t756-1">
   <w.rf>
    <LM>w#w-d1t756-1</LM>
   </w.rf>
   <form>Změnilo</form>
   <lemma>změnit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m050-d1t756-2">
   <w.rf>
    <LM>w#w-d1t756-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t756-3">
   <w.rf>
    <LM>w#w-d1t756-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t756-4">
   <w.rf>
    <LM>w#w-d1t756-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t756-5">
   <w.rf>
    <LM>w#w-d1t756-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d-id78143-punct">
   <w.rf>
    <LM>w#w-d-id78143-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e757-x2">
  <m id="m050-d1t760-2">
   <w.rf>
    <LM>w#w-d1t760-2</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t760-3">
   <w.rf>
    <LM>w#w-d1t760-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t760-4">
   <w.rf>
    <LM>w#w-d1t760-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1e757-x2-175">
   <w.rf>
    <LM>w#w-d1e757-x2-175</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-178">
  <m id="m050-d1t764-2">
   <w.rf>
    <LM>w#w-d1t764-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t764-3">
   <w.rf>
    <LM>w#w-d1t764-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t764-1">
   <w.rf>
    <LM>w#w-d1t764-1</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t764-4">
   <w.rf>
    <LM>w#w-d1t764-4</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t766-1">
   <w.rf>
    <LM>w#w-d1t766-1</LM>
   </w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d-m-d1e757-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e757-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e769-x2">
  <m id="m050-d1t772-1">
   <w.rf>
    <LM>w#w-d1t772-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1e769-x2-181">
   <w.rf>
    <LM>w#w-d1e769-x2-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-182">
  <m id="m050-d1t772-5">
   <w.rf>
    <LM>w#w-d1t772-5</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m050-d1t772-4">
   <w.rf>
    <LM>w#w-d1t772-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t772-6">
   <w.rf>
    <LM>w#w-d1t772-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t772-7">
   <w.rf>
    <LM>w#w-d1t772-7</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m050-d1t772-8">
   <w.rf>
    <LM>w#w-d1t772-8</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-182-183">
   <w.rf>
    <LM>w#w-182-183</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-184">
  <m id="m050-d1t774-1">
   <w.rf>
    <LM>w#w-d1t774-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m050-d1t774-2">
   <w.rf>
    <LM>w#w-d1t774-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t774-3">
   <w.rf>
    <LM>w#w-d1t774-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t774-4">
   <w.rf>
    <LM>w#w-d1t774-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-id78681-punct">
   <w.rf>
    <LM>w#w-d-id78681-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e775-x2">
  <m id="m050-d1t780-1">
   <w.rf>
    <LM>w#w-d1t780-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t780-2">
   <w.rf>
    <LM>w#w-d1t780-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t780-3">
   <w.rf>
    <LM>w#w-d1t780-3</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d1t780-4">
   <w.rf>
    <LM>w#w-d1t780-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t780-5">
   <w.rf>
    <LM>w#w-d1t780-5</LM>
   </w.rf>
   <form>kolech</form>
   <lemma>kolo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m050-d-m-d1e775-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e775-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e783-x2">
  <m id="m050-d1t788-1">
   <w.rf>
    <LM>w#w-d1t788-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t788-2">
   <w.rf>
    <LM>w#w-d1t788-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t788-4">
   <w.rf>
    <LM>w#w-d1t788-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m050-d1t788-5">
   <w.rf>
    <LM>w#w-d1t788-5</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-d-id78972-punct">
   <w.rf>
    <LM>w#w-d-id78972-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t788-7">
   <w.rf>
    <LM>w#w-d1t788-7</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t788-8">
   <w.rf>
    <LM>w#w-d1t788-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t788-9">
   <w.rf>
    <LM>w#w-d1t788-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t788-10">
   <w.rf>
    <LM>w#w-d1t788-10</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t788-11">
   <w.rf>
    <LM>w#w-d1t788-11</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m050-d1e783-x2-187">
   <w.rf>
    <LM>w#w-d1e783-x2-187</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-188">
  <m id="m050-d1t788-13">
   <w.rf>
    <LM>w#w-d1t788-13</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t788-14">
   <w.rf>
    <LM>w#w-d1t788-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t788-15">
   <w.rf>
    <LM>w#w-d1t788-15</LM>
   </w.rf>
   <form>bráškova</form>
   <lemma>bráškův_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m050-d1t788-16">
   <w.rf>
    <LM>w#w-d1t788-16</LM>
   </w.rf>
   <form>třída</form>
   <lemma>třída</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-188-189">
   <w.rf>
    <LM>w#w-188-189</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-190">
  <m id="m050-d1t790-2">
   <w.rf>
    <LM>w#w-d1t790-2</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m050-d1t790-3">
   <w.rf>
    <LM>w#w-d1t790-3</LM>
   </w.rf>
   <form>brali</form>
   <lemma>brát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-190-191">
   <w.rf>
    <LM>w#w-190-191</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t790-4">
   <w.rf>
    <LM>w#w-d1t790-4</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m050-d-id79180-punct">
   <w.rf>
    <LM>w#w-d-id79180-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t790-6">
   <w.rf>
    <LM>w#w-d1t790-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t792-2">
   <w.rf>
    <LM>w#w-d1t792-2</LM>
   </w.rf>
   <form>tenhleten</form>
   <lemma>tenhleten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m050-d1t792-4">
   <w.rf>
    <LM>w#w-d1t792-4</LM>
   </w.rf>
   <form>cyklistický</form>
   <lemma>cyklistický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m050-d1t792-5">
   <w.rf>
    <LM>w#w-d1t792-5</LM>
   </w.rf>
   <form>kroužek</form>
   <lemma>kroužek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d1t792-1">
   <w.rf>
    <LM>w#w-d1t792-1</LM>
   </w.rf>
   <form>vedl</form>
   <lemma>vést</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t790-7">
   <w.rf>
    <LM>w#w-d1t790-7</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-190-192">
   <w.rf>
    <LM>w#w-190-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-193">
  <m id="m050-d1t794-1">
   <w.rf>
    <LM>w#w-d1t794-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t794-2">
   <w.rf>
    <LM>w#w-d1t794-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t797-1">
   <w.rf>
    <LM>w#w-d1t797-1</LM>
   </w.rf>
   <form>vybavení</form>
   <lemma>vybavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m050-d1t792-7">
   <w.rf>
    <LM>w#w-d1t792-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t792-8">
   <w.rf>
    <LM>w#w-d1t792-8</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m050-d1t792-9">
   <w.rf>
    <LM>w#w-d1t792-9</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-193-344">
   <w.rf>
    <LM>w#w-193-344</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-193-345">
   <w.rf>
    <LM>w#w-193-345</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d-m-d1e783-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e783-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e802-x2">
  <m id="m050-d1t805-1">
   <w.rf>
    <LM>w#w-d1t805-1</LM>
   </w.rf>
   <form>Pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>klukům</form>
   <lemma>kluk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m050-d-id79565-punct">
   <w.rf>
    <LM>w#w-d-id79565-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t805-5">
   <w.rf>
    <LM>w#w-d1t805-5</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m050-d1t805-6">
   <w.rf>
    <LM>w#w-d1t805-6</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t805-7">
   <w.rf>
    <LM>w#w-d1t805-7</LM>
   </w.rf>
   <form>nadšení</form>
   <lemma>nadšení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m050-d1t805-8">
   <w.rf>
    <LM>w#w-d1t805-8</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d1t805-9">
   <w.rf>
    <LM>w#w-d1t805-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t805-12">
   <w.rf>
    <LM>w#w-d1t805-12</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d1t805-13">
   <w.rf>
    <LM>w#w-d1t805-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t805-14">
   <w.rf>
    <LM>w#w-d1t805-14</LM>
   </w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-d1e802-x2-201">
   <w.rf>
    <LM>w#w-d1e802-x2-201</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-202">
  <m id="m050-d1t809-3">
   <w.rf>
    <LM>w#w-d1t809-3</LM>
   </w.rf>
   <form>Sestrojil</form>
   <lemma>sestrojit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m050-d1t809-2">
   <w.rf>
    <LM>w#w-d1t809-2</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m050-d1t809-4">
   <w.rf>
    <LM>w#w-d1t809-4</LM>
   </w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m050-202-203">
   <w.rf>
    <LM>w#w-202-203</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-205">
  <m id="m050-d1t809-6">
   <w.rf>
    <LM>w#w-d1t809-6</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t809-7">
   <w.rf>
    <LM>w#w-d1t809-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t809-8">
   <w.rf>
    <LM>w#w-d1t809-8</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m050-d1t809-9">
   <w.rf>
    <LM>w#w-d1t809-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t809-10">
   <w.rf>
    <LM>w#w-d1t809-10</LM>
   </w.rf>
   <form>teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-id79875-punct">
   <w.rf>
    <LM>w#w-d-id79875-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t809-12">
   <w.rf>
    <LM>w#w-d1t809-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t809-13">
   <w.rf>
    <LM>w#w-d1t809-13</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m050-d1t809-14">
   <w.rf>
    <LM>w#w-d1t809-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t809-15">
   <w.rf>
    <LM>w#w-d1t809-15</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t809-16">
   <w.rf>
    <LM>w#w-d1t809-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t809-17">
   <w.rf>
    <LM>w#w-d1t809-17</LM>
   </w.rf>
   <form>obchodu</form>
   <lemma>obchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m050-d1t809-18">
   <w.rf>
    <LM>w#w-d1t809-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t809-19">
   <w.rf>
    <LM>w#w-d1t809-19</LM>
   </w.rf>
   <form>koupilo</form>
   <lemma>koupit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m050-d1t809-20">
   <w.rf>
    <LM>w#w-d1t809-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t809-21">
   <w.rf>
    <LM>w#w-d1t809-21</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d1t809-22">
   <w.rf>
    <LM>w#w-d1t809-22</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m050-205-206">
   <w.rf>
    <LM>w#w-205-206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t811-1">
   <w.rf>
    <LM>w#w-d1t811-1</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t811-2">
   <w.rf>
    <LM>w#w-d1t811-2</LM>
   </w.rf>
   <form>horské</form>
   <lemma>horský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-205-207">
   <w.rf>
    <LM>w#w-205-207</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t818-1">
   <w.rf>
    <LM>w#w-d1t818-1</LM>
   </w.rf>
   <form>trekové</form>
   <lemma>trekový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d1t818-2">
   <w.rf>
    <LM>w#w-d1t818-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t818-3">
   <w.rf>
    <LM>w#w-d1t818-3</LM>
   </w.rf>
   <form>silniční</form>
   <lemma>silniční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-205-208">
   <w.rf>
    <LM>w#w-205-208</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-209">
  <m id="m050-d1t818-6">
   <w.rf>
    <LM>w#w-d1t818-6</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t820-1">
   <w.rf>
    <LM>w#w-d1t820-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t818-9">
   <w.rf>
    <LM>w#w-d1t818-9</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t820-2">
   <w.rf>
    <LM>w#w-d1t820-2</LM>
   </w.rf>
   <form>nedostatek</form>
   <lemma>nedostatek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-209-212">
   <w.rf>
    <LM>w#w-209-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-213">
  <m id="m050-d1t824-1">
   <w.rf>
    <LM>w#w-d1t824-1</LM>
   </w.rf>
   <form>Pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m050-d1t820-6">
   <w.rf>
    <LM>w#w-d1t820-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t824-2">
   <w.rf>
    <LM>w#w-d1t824-2</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m050-d1t824-3">
   <w.rf>
    <LM>w#w-d1t824-3</LM>
   </w.rf>
   <form>klukům</form>
   <lemma>kluk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m050-d1t824-4">
   <w.rf>
    <LM>w#w-d1t824-4</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m050-d1t824-5">
   <w.rf>
    <LM>w#w-d1t824-5</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t822-1">
   <w.rf>
    <LM>w#w-d1t822-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t822-2">
   <w.rf>
    <LM>w#w-d1t822-2</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m050-d1t822-3">
   <w.rf>
    <LM>w#w-d1t822-3</LM>
   </w.rf>
   <form>součástek</form>
   <lemma>součástka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m050-209-210">
   <w.rf>
    <LM>w#w-209-210</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-211">
  <m id="m050-d1t824-7">
   <w.rf>
    <LM>w#w-d1t824-7</LM>
   </w.rf>
   <form>Nadšeně</form>
   <lemma>nadšeně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t824-8">
   <w.rf>
    <LM>w#w-d1t824-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t824-10">
   <w.rf>
    <LM>w#w-d1t824-10</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t824-11">
   <w.rf>
    <LM>w#w-d1t824-11</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t824-12">
   <w.rf>
    <LM>w#w-d1t824-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t824-13">
   <w.rf>
    <LM>w#w-d1t824-13</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m050-d1t824-15">
   <w.rf>
    <LM>w#w-d1t824-15</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-211-218">
   <w.rf>
    <LM>w#w-211-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
