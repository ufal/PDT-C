<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_005.08.w.gz" />
  </references>
 </head>
 <s id="m005-d1e2724-x2">
  <m id="m005-d1t2727-3">
   <w.rf>
    <LM>w#w-d1t2727-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2727-5">
   <w.rf>
    <LM>w#w-d1t2727-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2727-4">
   <w.rf>
    <LM>w#w-d1t2727-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m005-d1t2727-7">
   <w.rf>
    <LM>w#w-d1t2727-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m005-d1t2727-6">
   <w.rf>
    <LM>w#w-d1t2727-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2727-8">
   <w.rf>
    <LM>w#w-d1t2727-8</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m005-d1e2724-x2-152">
   <w.rf>
    <LM>w#w-d1e2724-x2-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-153">
  <m id="m005-d1t2731-2">
   <w.rf>
    <LM>w#w-d1t2731-2</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m005-d1e2724-x2-6505">
   <w.rf>
    <LM>w#w-d1e2724-x2-6505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2731-3">
   <w.rf>
    <LM>w#w-d1t2731-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m005-d1t2731-4">
   <w.rf>
    <LM>w#w-d1t2731-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2731-5">
   <w.rf>
    <LM>w#w-d1t2731-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2731-6">
   <w.rf>
    <LM>w#w-d1t2731-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m005-d1e2724-x2-6506">
   <w.rf>
    <LM>w#w-d1e2724-x2-6506</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-6509">
  <m id="m005-d1t2733-2">
   <w.rf>
    <LM>w#w-d1t2733-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2733-3">
   <w.rf>
    <LM>w#w-d1t2733-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m005-d1t2733-4">
   <w.rf>
    <LM>w#w-d1t2733-4</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m005-d1t2733-5">
   <w.rf>
    <LM>w#w-d1t2733-5</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m005-d1t2733-6">
   <w.rf>
    <LM>w#w-d1t2733-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2733-7">
   <w.rf>
    <LM>w#w-d1t2733-7</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2733-8">
   <w.rf>
    <LM>w#w-d1t2733-8</LM>
   </w.rf>
   <form>les</form>
   <lemma>les</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-6509-6519">
   <w.rf>
    <LM>w#w-6509-6519</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-6520">
  <m id="m005-d1t2735-7">
   <w.rf>
    <LM>w#w-d1t2735-7</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2735-8">
   <w.rf>
    <LM>w#w-d1t2735-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2735-10">
   <w.rf>
    <LM>w#w-d1t2735-10</LM>
   </w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d-id135891">
   <w.rf>
    <LM>w#w-d-id135891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2740-1">
   <w.rf>
    <LM>w#w-d1t2740-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2740-2">
   <w.rf>
    <LM>w#w-d1t2740-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2742-1">
   <w.rf>
    <LM>w#w-d1t2742-1</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m005-d1t2742-2">
   <w.rf>
    <LM>w#w-d1t2742-2</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-6520-178">
   <w.rf>
    <LM>w#w-6520-178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-6520-179">
   <w.rf>
    <LM>w#w-6520-179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-6520-180">
   <w.rf>
    <LM>w#w-6520-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-181">
  <m id="m005-d1t2746-1">
   <w.rf>
    <LM>w#w-d1t2746-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2746-2">
   <w.rf>
    <LM>w#w-d1t2746-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2746-3">
   <w.rf>
    <LM>w#w-d1t2746-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m005-d1t2746-4">
   <w.rf>
    <LM>w#w-d1t2746-4</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-181-182">
   <w.rf>
    <LM>w#w-181-182</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-183">
  <m id="m005-d1t2746-7">
   <w.rf>
    <LM>w#w-d1t2746-7</LM>
   </w.rf>
   <form>Vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m005-d1t2746-9">
   <w.rf>
    <LM>w#w-d1t2746-9</LM>
   </w.rf>
   <form>státu</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m005-d1t2748-2">
   <w.rf>
    <LM>w#w-d1t2748-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2748-3">
   <w.rf>
    <LM>w#w-d1t2748-3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2748-5">
   <w.rf>
    <LM>w#w-d1t2748-5</LM>
   </w.rf>
   <form>shromáždění</form>
   <lemma>shromáždění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m005-183-186">
   <w.rf>
    <LM>w#w-183-186</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-187">
  <m id="m005-d1t2748-8">
   <w.rf>
    <LM>w#w-d1t2748-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2748-9">
   <w.rf>
    <LM>w#w-d1t2748-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2748-10">
   <w.rf>
    <LM>w#w-d1t2748-10</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m005-6520-6532">
   <w.rf>
    <LM>w#w-6520-6532</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2724-x3">
  <m id="m005-d1t2751-4">
   <w.rf>
    <LM>w#w-d1t2751-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2751-5">
   <w.rf>
    <LM>w#w-d1t2751-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2751-6">
   <w.rf>
    <LM>w#w-d1t2751-6</LM>
   </w.rf>
   <form>nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d1e2724-x3-196">
   <w.rf>
    <LM>w#w-d1e2724-x3-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-197">
  <m id="m005-d1t2755-1">
   <w.rf>
    <LM>w#w-d1t2755-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2755-2">
   <w.rf>
    <LM>w#w-d1t2755-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2755-3">
   <w.rf>
    <LM>w#w-d1t2755-3</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m005-d1t2755-4">
   <w.rf>
    <LM>w#w-d1t2755-4</LM>
   </w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m005-d1t2755-6">
   <w.rf>
    <LM>w#w-d1t2755-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2755-7">
   <w.rf>
    <LM>w#w-d1t2755-7</LM>
   </w.rf>
   <form>kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m005-d1t2755-5">
   <w.rf>
    <LM>w#w-d1t2755-5</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m005-d1t2755-13">
   <w.rf>
    <LM>w#w-d1t2755-13</LM>
   </w.rf>
   <form>vysoké</form>
   <lemma>vysoký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m005-d1t2755-14">
   <w.rf>
    <LM>w#w-d1t2755-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2757-2">
   <w.rf>
    <LM>w#w-d1t2757-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2757-1">
   <w.rf>
    <LM>w#w-d1t2757-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2757-3">
   <w.rf>
    <LM>w#w-d1t2757-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m005-d1t2757-4">
   <w.rf>
    <LM>w#w-d1t2757-4</LM>
   </w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m005-d-id136738">
   <w.rf>
    <LM>w#w-d-id136738</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2759-3">
   <w.rf>
    <LM>w#w-d1t2759-3</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m005-d1t2759-4">
   <w.rf>
    <LM>w#w-d1t2759-4</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m005-d1t2759-5">
   <w.rf>
    <LM>w#w-d1t2759-5</LM>
   </w.rf>
   <form>liány</form>
   <lemma>liána</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m005-d1t2761-1">
   <w.rf>
    <LM>w#w-d1t2761-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2761-2">
   <w.rf>
    <LM>w#w-d1t2761-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m005-d1t2761-3">
   <w.rf>
    <LM>w#w-d1t2761-3</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m005-d1t2761-4">
   <w.rf>
    <LM>w#w-d1t2761-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m005-d1e2724-x3-6693">
   <w.rf>
    <LM>w#w-d1e2724-x3-6693</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-6696">
  <m id="m005-d1t2761-13">
   <w.rf>
    <LM>w#w-d1t2761-13</LM>
   </w.rf>
   <form>Zasedací</form>
   <lemma>zasedací_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m005-d1t2761-15">
   <w.rf>
    <LM>w#w-d1t2761-15</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d1t2764-3">
   <w.rf>
    <LM>w#w-d1t2764-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2764-4">
   <w.rf>
    <LM>w#w-d1t2764-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m005-d1t2764-5">
   <w.rf>
    <LM>w#w-d1t2764-5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m005-d1t2764-6">
   <w.rf>
    <LM>w#w-d1t2764-6</LM>
   </w.rf>
   <form>700</form>
   <lemma>700</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m005-d1t2773-1">
   <w.rf>
    <LM>w#w-d1t2773-1</LM>
   </w.rf>
   <form>ministrů</form>
   <lemma>ministr</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m005-d-id136369">
   <w.rf>
    <LM>w#w-d-id136369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2768-x3">
  <m id="m005-d1t2779-1">
   <w.rf>
    <LM>w#w-d1t2779-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2779-2">
   <w.rf>
    <LM>w#w-d1t2779-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2779-3">
   <w.rf>
    <LM>w#w-d1t2779-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d-id137378">
   <w.rf>
    <LM>w#w-d-id137378</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2780-x2">
  <m id="m005-d1t2783-2">
   <w.rf>
    <LM>w#w-d1t2783-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2783-3">
   <w.rf>
    <LM>w#w-d1t2783-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2783-4">
   <w.rf>
    <LM>w#w-d1t2783-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m005-d1t2783-6">
   <w.rf>
    <LM>w#w-d1t2783-6</LM>
   </w.rf>
   <form>Francii</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m005-d-id137537">
   <w.rf>
    <LM>w#w-d-id137537</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2787-5">
   <w.rf>
    <LM>w#w-d1t2787-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2787-4">
   <w.rf>
    <LM>w#w-d1t2787-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2787-7">
   <w.rf>
    <LM>w#w-d1t2787-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2787-6">
   <w.rf>
    <LM>w#w-d1t2787-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2787-8">
   <w.rf>
    <LM>w#w-d1t2787-8</LM>
   </w.rf>
   <form>řiká</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1e2780-x2-225">
   <w.rf>
    <LM>w#w-d1e2780-x2-225</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2789-1">
   <w.rf>
    <LM>w#w-d1t2789-1</LM>
   </w.rf>
   <form>heršo</form>
   <lemma>heršo-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m005-d1e2780-x2-226">
   <w.rf>
    <LM>w#w-d1e2780-x2-226</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d-id137425">
   <w.rf>
    <LM>w#w-d-id137425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2790-x2">
  <m id="m005-d1t2793-1">
   <w.rf>
    <LM>w#w-d1t2793-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m005-d1t2793-2">
   <w.rf>
    <LM>w#w-d1t2793-2</LM>
   </w.rf>
   <form>jakém</form>
   <lemma>jaký</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m005-d1t2793-3">
   <w.rf>
    <LM>w#w-d1t2793-3</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m005-d-id137836">
   <w.rf>
    <LM>w#w-d-id137836</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2794-x2">
  <m id="m005-d1t2799-2">
   <w.rf>
    <LM>w#w-d1t2799-2</LM>
   </w.rf>
   <form>Patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2799-3">
   <w.rf>
    <LM>w#w-d1t2799-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1e2794-x2-7044">
   <w.rf>
    <LM>w#w-d1e2794-x2-7044</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2799-4">
   <w.rf>
    <LM>w#w-d1t2799-4</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m005-d1e2794-x2-7045">
   <w.rf>
    <LM>w#w-d1e2794-x2-7045</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2799-5">
   <w.rf>
    <LM>w#w-d1t2799-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2799-6">
   <w.rf>
    <LM>w#w-d1t2799-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m005-d1t2799-8">
   <w.rf>
    <LM>w#w-d1t2799-8</LM>
   </w.rf>
   <form>Paříži</form>
   <lemma>Paříž_;G</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m005-d-id138133">
   <w.rf>
    <LM>w#w-d-id138133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2823-x2">
  <m id="m005-d1t2826-1">
   <w.rf>
    <LM>w#w-d1t2826-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2826-2">
   <w.rf>
    <LM>w#w-d1t2826-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2826-3">
   <w.rf>
    <LM>w#w-d1t2826-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2826-4">
   <w.rf>
    <LM>w#w-d1t2826-4</LM>
   </w.rf>
   <form>evropský</form>
   <lemma>evropský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m005-d1t2826-5">
   <w.rf>
    <LM>w#w-d1t2826-5</LM>
   </w.rf>
   <form>parlament</form>
   <lemma>parlament</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-d-id138453">
   <w.rf>
    <LM>w#w-d-id138453</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2827-x2">
  <m id="m005-d1t2830-7">
   <w.rf>
    <LM>w#w-d1t2830-7</LM>
   </w.rf>
   <form>Celoevropský</form>
   <lemma>celoevropský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m005-d1e2827-x2-254">
   <w.rf>
    <LM>w#w-d1e2827-x2-254</LM>
   </w.rf>
   <form>parlament</form>
   <lemma>parlament</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-d-id138625">
   <w.rf>
    <LM>w#w-d-id138625</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2832-2">
   <w.rf>
    <LM>w#w-d1t2832-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2832-1">
   <w.rf>
    <LM>w#w-d1t2832-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2832-3">
   <w.rf>
    <LM>w#w-d1t2832-3</LM>
   </w.rf>
   <form>obrovské</form>
   <lemma>obrovský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m005-d-id138499">
   <w.rf>
    <LM>w#w-d-id138499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2839-x2">
  <m id="m005-d1t2844-1">
   <w.rf>
    <LM>w#w-d1t2844-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2844-2">
   <w.rf>
    <LM>w#w-d1t2844-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2844-3">
   <w.rf>
    <LM>w#w-d1t2844-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m005-d1t2844-4">
   <w.rf>
    <LM>w#w-d1t2844-4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d1t2844-5">
   <w.rf>
    <LM>w#w-d1t2844-5</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m005-d1e2839-x2-258">
   <w.rf>
    <LM>w#w-d1e2839-x2-258</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-259">
  <m id="m005-d1t2846-1">
   <w.rf>
    <LM>w#w-d1t2846-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2846-5">
   <w.rf>
    <LM>w#w-d1t2846-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m005-d1t2846-6">
   <w.rf>
    <LM>w#w-d1t2846-6</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m005-d1t2846-7">
   <w.rf>
    <LM>w#w-d1t2846-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m005-d-id138991">
   <w.rf>
    <LM>w#w-d-id138991</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2848-1">
   <w.rf>
    <LM>w#w-d1t2848-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2848-2">
   <w.rf>
    <LM>w#w-d1t2848-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m005-d1t2848-4">
   <w.rf>
    <LM>w#w-d1t2848-4</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2848-3">
   <w.rf>
    <LM>w#w-d1t2848-3</LM>
   </w.rf>
   <form>vlajky</form>
   <lemma>vlajka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m005-d-id138782">
   <w.rf>
    <LM>w#w-d-id138782</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2851-x2">
  <m id="m005-d1t2856-1">
   <w.rf>
    <LM>w#w-d1t2856-1</LM>
   </w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m005-d1t2856-2">
   <w.rf>
    <LM>w#w-d1t2856-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m005-d1t2856-3">
   <w.rf>
    <LM>w#w-d1t2856-3</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m005-d1t2856-4">
   <w.rf>
    <LM>w#w-d1t2856-4</LM>
   </w.rf>
   <form>států</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m005-d-id139192">
   <w.rf>
    <LM>w#w-d-id139192</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2856-6">
   <w.rf>
    <LM>w#w-d1t2856-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m005-d1e2851-x2-7386">
   <w.rf>
    <LM>w#w-d1e2851-x2-7386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1e2851-x2-7387">
   <w.rf>
    <LM>w#w-d1e2851-x2-7387</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d-id139121">
   <w.rf>
    <LM>w#w-d-id139121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2851-x3">
  <m id="m005-d1t2858-1">
   <w.rf>
    <LM>w#w-d1t2858-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2858-2">
   <w.rf>
    <LM>w#w-d1t2858-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2858-3">
   <w.rf>
    <LM>w#w-d1t2858-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m005-d1t2858-5">
   <w.rf>
    <LM>w#w-d1t2858-5</LM>
   </w.rf>
   <form>Štrasburk</form>
   <lemma>Štrasburk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-d-id139225">
   <w.rf>
    <LM>w#w-d-id139225</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2860-x2">
  <m id="m005-d1t2863-7">
   <w.rf>
    <LM>w#w-d1t2863-7</LM>
   </w.rf>
   <form>Štrasburk</form>
   <lemma>Štrasburk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m005-d1e2860-x2-7391">
   <w.rf>
    <LM>w#w-d1e2860-x2-7391</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2863-9">
   <w.rf>
    <LM>w#w-d1t2863-9</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m005-d-id139335">
   <w.rf>
    <LM>w#w-d-id139335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2866-x2">
  <m id="m005-d1t2871-3">
   <w.rf>
    <LM>w#w-d1t2871-3</LM>
   </w.rf>
   <form>Nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m005-d1e2866-x2-276">
   <w.rf>
    <LM>w#w-d1e2866-x2-276</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m005-d1t2871-2">
   <w.rf>
    <LM>w#w-d1t2871-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m005-d1t2871-4">
   <w.rf>
    <LM>w#w-d1t2871-4</LM>
   </w.rf>
   <form>vzpomenout</form>
   <lemma>vzpomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m005-d-id139493">
   <w.rf>
    <LM>w#w-d-id139493</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2878-x2">
  <m id="m005-d1t2883-10">
   <w.rf>
    <LM>w#w-d1t2883-10</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m005-d1t2883-11">
   <w.rf>
    <LM>w#w-d1t2883-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2883-12">
   <w.rf>
    <LM>w#w-d1t2883-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t2883-13">
   <w.rf>
    <LM>w#w-d1t2883-13</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d1t2883-14">
   <w.rf>
    <LM>w#w-d1t2883-14</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d-id139858">
   <w.rf>
    <LM>w#w-d-id139858</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2883-16">
   <w.rf>
    <LM>w#w-d1t2883-16</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1e2878-x2-285">
   <w.rf>
    <LM>w#w-d1e2878-x2-285</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m005-d1e2878-x2-287">
   <w.rf>
    <LM>w#w-d1e2878-x2-287</LM>
   </w.rf>
   <form>státy</form>
   <lemma>stát-1_^(státní_útvar)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m005-d1t2883-17">
   <w.rf>
    <LM>w#w-d1t2883-17</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m005-d1t2883-18">
   <w.rf>
    <LM>w#w-d1t2883-18</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m005-d1t2883-19">
   <w.rf>
    <LM>w#w-d1t2883-19</LM>
   </w.rf>
   <form>paměť</form>
   <lemma>paměť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m005-d1e2878-x2-7538">
   <w.rf>
    <LM>w#w-d1e2878-x2-7538</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2893-1">
   <w.rf>
    <LM>w#w-d1t2893-1</LM>
   </w.rf>
   <form>jakou</form>
   <lemma>jaký</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m005-d1t2893-2">
   <w.rf>
    <LM>w#w-d1t2893-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m005-d1t2893-3">
   <w.rf>
    <LM>w#w-d1t2893-3</LM>
   </w.rf>
   <form>potřeboval</form>
   <lemma>potřebovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m005-d-id139643">
   <w.rf>
    <LM>w#w-d-id139643</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2904-x2">
  <m id="m005-d1t2907-1">
   <w.rf>
    <LM>w#w-d1t2907-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m005-d1t2907-2">
   <w.rf>
    <LM>w#w-d1t2907-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2907-3">
   <w.rf>
    <LM>w#w-d1t2907-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m005-d1t2907-4">
   <w.rf>
    <LM>w#w-d1t2907-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m005-d1t2907-5">
   <w.rf>
    <LM>w#w-d1t2907-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m005-d-id140317">
   <w.rf>
    <LM>w#w-d-id140317</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2908-x2">
  <m id="m005-d1t2911-2">
   <w.rf>
    <LM>w#w-d1t2911-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2911-3">
   <w.rf>
    <LM>w#w-d1t2911-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2911-4">
   <w.rf>
    <LM>w#w-d1t2911-4</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m005-d1t2911-9">
   <w.rf>
    <LM>w#w-d1t2911-9</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m005-d1t2911-10">
   <w.rf>
    <LM>w#w-d1t2911-10</LM>
   </w.rf>
   <form>přítelkyně</form>
   <lemma>přítelkyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d-id140506">
   <w.rf>
    <LM>w#w-d-id140506</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2911-12">
   <w.rf>
    <LM>w#w-d1t2911-12</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m005-d1t2911-13">
   <w.rf>
    <LM>w#w-d1t2911-13</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2911-14">
   <w.rf>
    <LM>w#w-d1t2911-14</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m005-d1t2911-16">
   <w.rf>
    <LM>w#w-d1t2911-16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m005-d1t2911-17">
   <w.rf>
    <LM>w#w-d1t2911-17</LM>
   </w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m005-d1t2911-15">
   <w.rf>
    <LM>w#w-d1t2911-15</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m005-d-id140363">
   <w.rf>
    <LM>w#w-d-id140363</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2914-x3">
  <m id="m005-d1t2925-1">
   <w.rf>
    <LM>w#w-d1t2925-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2925-2">
   <w.rf>
    <LM>w#w-d1t2925-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2925-3">
   <w.rf>
    <LM>w#w-d1t2925-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m005-d-id140774">
   <w.rf>
    <LM>w#w-d-id140774</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2926-x2">
  <m id="m005-d1t2929-2">
   <w.rf>
    <LM>w#w-d1t2929-2</LM>
   </w.rf>
   <form>Libuše</form>
   <lemma>Libuše_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d1t2929-3">
   <w.rf>
    <LM>w#w-d1t2929-3</LM>
   </w.rf>
   <form>Ecksteinová</form>
   <lemma>Ecksteinová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d-id140820">
   <w.rf>
    <LM>w#w-d-id140820</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2936-x2">
  <m id="m005-d1t2939-2">
   <w.rf>
    <LM>w#w-d1t2939-2</LM>
   </w.rf>
   <form>Tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m005-d1t2939-3">
   <w.rf>
    <LM>w#w-d1t2939-3</LM>
   </w.rf>
   <form>znáte</form>
   <lemma>znát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d1e2936-x2-7882">
   <w.rf>
    <LM>w#w-d1e2936-x2-7882</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2945-x2">
  <m id="m005-d1t2948-1">
   <w.rf>
    <LM>w#w-d1t2948-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m005-d1t2948-2">
   <w.rf>
    <LM>w#w-d1t2948-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m005-d1t2948-3">
   <w.rf>
    <LM>w#w-d1t2948-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t2948-4">
   <w.rf>
    <LM>w#w-d1t2948-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m005-d-id141171">
   <w.rf>
    <LM>w#w-d-id141171</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2949-x2">
  <m id="m005-d1t2952-2">
   <w.rf>
    <LM>w#w-d1t2952-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2952-3">
   <w.rf>
    <LM>w#w-d1t2952-3</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d1e2949-x2-7912">
   <w.rf>
    <LM>w#w-d1e2949-x2-7912</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2952-4">
   <w.rf>
    <LM>w#w-d1t2952-4</LM>
   </w.rf>
   <form>74</form>
   <lemma>74</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m005-d-id141218">
   <w.rf>
    <LM>w#w-d-id141218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2955-x2">
  <m id="m005-d1t2958-1">
   <w.rf>
    <LM>w#w-d1t2958-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2958-2">
   <w.rf>
    <LM>w#w-d1t2958-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2958-3">
   <w.rf>
    <LM>w#w-d1t2958-3</LM>
   </w.rf>
   <form>znáte</form>
   <lemma>znát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d-id141412">
   <w.rf>
    <LM>w#w-d-id141412</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2959-x2">
  <m id="m005-d1t2964-5">
   <w.rf>
    <LM>w#w-d1t2964-5</LM>
   </w.rf>
   <form>Poznali</form>
   <lemma>poznat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m005-d1t2964-3">
   <w.rf>
    <LM>w#w-d1t2964-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t2964-4">
   <w.rf>
    <LM>w#w-d1t2964-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2964-6">
   <w.rf>
    <LM>w#w-d1t2964-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m005-d1t2964-8">
   <w.rf>
    <LM>w#w-d1t2964-8</LM>
   </w.rf>
   <form>Kadani</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m005-d-id141459">
   <w.rf>
    <LM>w#w-d-id141459</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e2975-x2">
  <m id="m005-d1t2970-3">
   <w.rf>
    <LM>w#w-d1t2970-3</LM>
   </w.rf>
   <form>Jel</form>
   <lemma>jet-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m005-d1e2975-x2-307">
   <w.rf>
    <LM>w#w-d1e2975-x2-307</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m005-d1t2970-2">
   <w.rf>
    <LM>w#w-d1t2970-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2980-1">
   <w.rf>
    <LM>w#w-d1t2980-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m005-d1t2980-2">
   <w.rf>
    <LM>w#w-d1t2980-2</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m005-d-id141879">
   <w.rf>
    <LM>w#w-d-id141879</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t2982-2">
   <w.rf>
    <LM>w#w-d1t2982-2</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m005-d1t2982-3">
   <w.rf>
    <LM>w#w-d1t2982-3</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m005-d1t2982-4">
   <w.rf>
    <LM>w#w-d1t2982-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2984-2">
   <w.rf>
    <LM>w#w-d1t2984-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t2984-3">
   <w.rf>
    <LM>w#w-d1t2984-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t2992-1">
   <w.rf>
    <LM>w#w-d1t2992-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t2992-2">
   <w.rf>
    <LM>w#w-d1t2992-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t2992-3">
   <w.rf>
    <LM>w#w-d1t2992-3</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m005-d-id141776">
   <w.rf>
    <LM>w#w-d-id141776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3003-x2">
  <m id="m005-d1t3006-1">
   <w.rf>
    <LM>w#w-d1t3006-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3006-2">
   <w.rf>
    <LM>w#w-d1t3006-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d1t3006-3">
   <w.rf>
    <LM>w#w-d1t3006-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t3006-4">
   <w.rf>
    <LM>w#w-d1t3006-4</LM>
   </w.rf>
   <form>znáte</form>
   <lemma>znát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d-id142370">
   <w.rf>
    <LM>w#w-d-id142370</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3007-x2">
  <m id="m005-d1t3010-1">
   <w.rf>
    <LM>w#w-d1t3010-1</LM>
   </w.rf>
   <form>Šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m005-d1t3010-2">
   <w.rf>
    <LM>w#w-d1t3010-2</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m005-d-id142416">
   <w.rf>
    <LM>w#w-d-id142416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3011-x2">
  <m id="m005-d1t3018-1">
   <w.rf>
    <LM>w#w-d1t3018-1</LM>
   </w.rf>
   <form>Před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m005-d1t3018-2">
   <w.rf>
    <LM>w#w-d1t3018-2</LM>
   </w.rf>
   <form>šesti</form>
   <lemma>šest`6</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m005-d1t3018-3">
   <w.rf>
    <LM>w#w-d1t3018-3</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m005-d1t3018-4">
   <w.rf>
    <LM>w#w-d1t3018-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3018-5">
   <w.rf>
    <LM>w#w-d1t3018-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3018-7">
   <w.rf>
    <LM>w#w-d1t3018-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m005-d-id142503">
   <w.rf>
    <LM>w#w-d-id142503</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3011-x3">
  <m id="m005-d1t3029-3">
   <w.rf>
    <LM>w#w-d1t3029-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m005-d1t3029-4">
   <w.rf>
    <LM>w#w-d1t3029-4</LM>
   </w.rf>
   <form>vdova</form>
   <lemma>vdova</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d-id142648">
   <w.rf>
    <LM>w#w-d-id142648</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3011-x4">
  <m id="m005-d1t3033-1">
   <w.rf>
    <LM>w#w-d1t3033-1</LM>
   </w.rf>
   <form>Žijete</form>
   <lemma>žít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d1t3033-2">
   <w.rf>
    <LM>w#w-d1t3033-2</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d-id142776">
   <w.rf>
    <LM>w#w-d-id142776</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3035-x2">
  <m id="m005-d1t3038-1">
   <w.rf>
    <LM>w#w-d1t3038-1</LM>
   </w.rf>
   <form>Žijeme</form>
   <lemma>žít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3038-2">
   <w.rf>
    <LM>w#w-d1t3038-2</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d-id142823">
   <w.rf>
    <LM>w#w-d-id142823</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3041-x2">
  <m id="m005-d1t3046-3">
   <w.rf>
    <LM>w#w-d1t3046-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m005-d1t3046-2">
   <w.rf>
    <LM>w#w-d1t3046-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3046-4">
   <w.rf>
    <LM>w#w-d1t3046-4</LM>
   </w.rf>
   <form>vdovec</form>
   <lemma>vdovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m005-d-id142919">
   <w.rf>
    <LM>w#w-d-id142919</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3053-x2">
  <m id="m005-d1t3056-2">
   <w.rf>
    <LM>w#w-d1t3056-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m005-d1t3056-4">
   <w.rf>
    <LM>w#w-d1t3056-4</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m005-d1t3056-3">
   <w.rf>
    <LM>w#w-d1t3056-3</LM>
   </w.rf>
   <form>1990</form>
   <lemma>1990</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m005-d1t3056-1">
   <w.rf>
    <LM>w#w-d1t3056-1</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m005-d1t3056-5">
   <w.rf>
    <LM>w#w-d1t3056-5</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m005-d1t3056-6">
   <w.rf>
    <LM>w#w-d1t3056-6</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d1e3053-x2-8443">
   <w.rf>
    <LM>w#w-d1e3053-x2-8443</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t3058-2">
   <w.rf>
    <LM>w#w-d1t3058-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t3058-3">
   <w.rf>
    <LM>w#w-d1t3058-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3058-4">
   <w.rf>
    <LM>w#w-d1t3058-4</LM>
   </w.rf>
   <form>napřed</form>
   <lemma>napřed</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3058-5">
   <w.rf>
    <LM>w#w-d1t3058-5</LM>
   </w.rf>
   <form>živořil</form>
   <lemma>živořit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m005-d1e3053-x2-8444">
   <w.rf>
    <LM>w#w-d1e3053-x2-8444</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t3058-6">
   <w.rf>
    <LM>w#w-d1t3058-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3058-7">
   <w.rf>
    <LM>w#w-d1t3058-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t3058-8">
   <w.rf>
    <LM>w#w-d1t3058-8</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m005-d1e3053-x2-316">
   <w.rf>
    <LM>w#w-d1e3053-x2-316</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-317">
  <m id="m005-d1t3070-3">
   <w.rf>
    <LM>w#w-d1t3070-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3070-7">
   <w.rf>
    <LM>w#w-d1t3070-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3070-8">
   <w.rf>
    <LM>w#w-d1t3070-8</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1e3067-x2-8517">
   <w.rf>
    <LM>w#w-d1e3067-x2-8517</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m005-d1t3070-14">
   <w.rf>
    <LM>w#w-d1t3070-14</LM>
   </w.rf>
   <form>daří</form>
   <lemma>dařit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t3070-12">
   <w.rf>
    <LM>w#w-d1t3070-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t3070-13">
   <w.rf>
    <LM>w#w-d1t3070-13</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m005-d1t3070-15">
   <w.rf>
    <LM>w#w-d1t3070-15</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d1t3070-16">
   <w.rf>
    <LM>w#w-d1t3070-16</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m005-d-id143397">
   <w.rf>
    <LM>w#w-d-id143397</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3071-x2">
  <m id="m005-d1t3076-3">
   <w.rf>
    <LM>w#w-d1t3076-3</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d1t3076-1">
   <w.rf>
    <LM>w#w-d1t3076-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t3076-2">
   <w.rf>
    <LM>w#w-d1t3076-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3------1</tag>
  </m>
  <m id="m005-d1t3076-4">
   <w.rf>
    <LM>w#w-d1t3076-4</LM>
   </w.rf>
   <form>zeptat</form>
   <lemma>zeptat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m005-d-id143758">
   <w.rf>
    <LM>w#w-d-id143758</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t3076-6">
   <w.rf>
    <LM>w#w-d1t3076-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m005-d1t3076-8">
   <w.rf>
    <LM>w#w-d1t3076-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3076-7">
   <w.rf>
    <LM>w#w-d1t3076-7</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3076-9">
   <w.rf>
    <LM>w#w-d1t3076-9</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m005-d1t3076-10">
   <w.rf>
    <LM>w#w-d1t3076-10</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m005-d1t3076-11">
   <w.rf>
    <LM>w#w-d1t3076-11</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m005-d-id143687">
   <w.rf>
    <LM>w#w-d-id143687</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3081-x2">
  <m id="m005-d1t3084-1">
   <w.rf>
    <LM>w#w-d1t3084-1</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3084-2">
   <w.rf>
    <LM>w#w-d1t3084-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m005-d1t3084-3">
   <w.rf>
    <LM>w#w-d1t3084-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m005-d1t3084-4">
   <w.rf>
    <LM>w#w-d1t3084-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m005-d1t3084-5">
   <w.rf>
    <LM>w#w-d1t3084-5</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m005-d1t3084-6">
   <w.rf>
    <LM>w#w-d1t3084-6</LM>
   </w.rf>
   <form>povídat</form>
   <lemma>povídat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m005-d-id143990">
   <w.rf>
    <LM>w#w-d-id143990</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-335"></s>
 <s id="m005-d1e3095-x2">
  <m id="m005-d1t3102-3">
   <w.rf>
    <LM>w#w-d1t3102-3</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3102-2">
   <w.rf>
    <LM>w#w-d1t3102-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m005-d1t3102-4">
   <w.rf>
    <LM>w#w-d1t3102-4</LM>
   </w.rf>
   <form>vybrala</form>
   <lemma>vybrat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m005-d1t3102-5">
   <w.rf>
    <LM>w#w-d1t3102-5</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m005-d1t3102-7">
   <w.rf>
    <LM>w#w-d1t3102-7</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m005-d-id144116">
   <w.rf>
    <LM>w#w-d-id144116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3107-x3">
  <m id="m005-d1t3116-2">
   <w.rf>
    <LM>w#w-d1t3116-2</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3116-3">
   <w.rf>
    <LM>w#w-d1t3116-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m005-d1t3116-4">
   <w.rf>
    <LM>w#w-d1t3116-4</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m005-d1t3116-5">
   <w.rf>
    <LM>w#w-d1t3116-5</LM>
   </w.rf>
   <form>dovolená</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m005-d-id144495">
   <w.rf>
    <LM>w#w-d-id144495</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3117-x2">
  <m id="m005-d1t3120-2">
   <w.rf>
    <LM>w#w-d1t3120-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m005-d1t3120-3">
   <w.rf>
    <LM>w#w-d1t3120-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m005-d1t3120-5">
   <w.rf>
    <LM>w#w-d1t3120-5</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m005-d1t3120-6">
   <w.rf>
    <LM>w#w-d1t3120-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m005-d-id144644">
   <w.rf>
    <LM>w#w-d-id144644</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m005-d1t3122-2">
   <w.rf>
    <LM>w#w-d1t3122-2</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m005-d1t3122-1">
   <w.rf>
    <LM>w#w-d1t3122-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m005-d1t3122-3">
   <w.rf>
    <LM>w#w-d1t3122-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m005-d1t3122-6">
   <w.rf>
    <LM>w#w-d1t3122-6</LM>
   </w.rf>
   <form>Kadaně</form>
   <lemma>Kadaň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m005-d-id144541">
   <w.rf>
    <LM>w#w-d-id144541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3124-x2">
  <m id="m005-d1t3127-1">
   <w.rf>
    <LM>w#w-d1t3127-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3127-2">
   <w.rf>
    <LM>w#w-d1t3127-2</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d1t3127-3">
   <w.rf>
    <LM>w#w-d1t3127-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m005-d1t3127-4">
   <w.rf>
    <LM>w#w-d1t3127-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m005-d1t3127-5">
   <w.rf>
    <LM>w#w-d1t3127-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m005-d1t3127-6">
   <w.rf>
    <LM>w#w-d1t3127-6</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m005-d-id144899">
   <w.rf>
    <LM>w#w-d-id144899</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m005-d1e3128-x2">
  <m id="m005-d1t3131-1">
   <w.rf>
    <LM>w#w-d1t3131-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m005-d-id144976">
   <w.rf>
    <LM>w#w-d-id144976</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
