<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_032.09.w.gz" />
  </references>
 </head>
 <s id="m032-d1e2980-x2">
  <m id="m032-d1t2983-1">
   <w.rf>
    <LM>w#w-d1t2983-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t2983-2">
   <w.rf>
    <LM>w#w-d1t2983-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t2983-3">
   <w.rf>
    <LM>w#w-d1t2983-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m032-d1t2983-4">
   <w.rf>
    <LM>w#w-d1t2983-4</LM>
   </w.rf>
   <form>působili</form>
   <lemma>působit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1t2983-6">
   <w.rf>
    <LM>w#w-d1t2983-6</LM>
   </w.rf>
   <form>Tunisané</form>
   <lemma>Tunisan_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m032-d-id161162-punct">
   <w.rf>
    <LM>w#w-d-id161162-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e2984-x2">
  <m id="m032-d1t2991-4">
   <w.rf>
    <LM>w#w-d1t2991-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1t2991-2">
   <w.rf>
    <LM>w#w-d1t2991-2</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t2991-3">
   <w.rf>
    <LM>w#w-d1t2991-3</LM>
   </w.rf>
   <form>ochotní</form>
   <lemma>ochotný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m032-d-id161303-punct">
   <w.rf>
    <LM>w#w-d-id161303-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t2991-6">
   <w.rf>
    <LM>w#w-d1t2991-6</LM>
   </w.rf>
   <form>nabízeli</form>
   <lemma>nabízet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1e2984-x2-1582">
   <w.rf>
    <LM>w#w-d1e2984-x2-1582</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-1584">
  <m id="m032-d1t2991-8">
   <w.rf>
    <LM>w#w-d1t2991-8</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m032-d1t2991-10">
   <w.rf>
    <LM>w#w-d1t2991-10</LM>
   </w.rf>
   <form>neumím</form>
   <lemma>umět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m032-d1t2991-9">
   <w.rf>
    <LM>w#w-d1t2991-9</LM>
   </w.rf>
   <form>smlouvat</form>
   <lemma>smlouvat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t2991-12">
   <w.rf>
    <LM>w#w-d1t2991-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t2991-13">
   <w.rf>
    <LM>w#w-d1t2991-13</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m032-d1t2991-15">
   <w.rf>
    <LM>w#w-d1t2991-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t2991-16">
   <w.rf>
    <LM>w#w-d1t2991-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m032-d1t2991-17">
   <w.rf>
    <LM>w#w-d1t2991-17</LM>
   </w.rf>
   <form>smlouvání</form>
   <lemma>smlouvání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m032-d1t2991-14">
   <w.rf>
    <LM>w#w-d1t2991-14</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d-m-d1e2984-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2984-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3004-x2">
  <m id="m032-d1t3007-1">
   <w.rf>
    <LM>w#w-d1t3007-1</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3007-2">
   <w.rf>
    <LM>w#w-d1t3007-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m032-d1t3007-3">
   <w.rf>
    <LM>w#w-d1t3007-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3007-4">
   <w.rf>
    <LM>w#w-d1t3007-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3007-5">
   <w.rf>
    <LM>w#w-d1t3007-5</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3007-7">
   <w.rf>
    <LM>w#w-d1t3007-7</LM>
   </w.rf>
   <form>šaty</form>
   <lemma>šaty</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m032-d-id161764-punct">
   <w.rf>
    <LM>w#w-d-id161764-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3007-10">
   <w.rf>
    <LM>w#w-d1t3007-10</LM>
   </w.rf>
   <form>vpředu</form>
   <lemma>vpředu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3007-9">
   <w.rf>
    <LM>w#w-d1t3007-9</LM>
   </w.rf>
   <form>vyšívané</form>
   <lemma>vyšívaný_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m032-d-id161804-punct">
   <w.rf>
    <LM>w#w-d-id161804-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3007-12">
   <w.rf>
    <LM>w#w-d1t3007-12</LM>
   </w.rf>
   <form>modré</form>
   <lemma>modrý_;o</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m032-d1e3004-x2-1600">
   <w.rf>
    <LM>w#w-d1e3004-x2-1600</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-1602">
  <m id="m032-d1t3007-15">
   <w.rf>
    <LM>w#w-d1t3007-15</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3007-16">
   <w.rf>
    <LM>w#w-d1t3007-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3007-17">
   <w.rf>
    <LM>w#w-d1t3007-17</LM>
   </w.rf>
   <form>lehké</form>
   <lemma>lehký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m032-1602-1604">
   <w.rf>
    <LM>w#w-1602-1604</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3009-1">
   <w.rf>
    <LM>w#w-d1t3009-1</LM>
   </w.rf>
   <form>bavlna</form>
   <lemma>bavlna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-1602-1606">
   <w.rf>
    <LM>w#w-1602-1606</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3009-2">
   <w.rf>
    <LM>w#w-d1t3009-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-1602-1608">
   <w.rf>
    <LM>w#w-1602-1608</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-1602-1610">
   <w.rf>
    <LM>w#w-1602-1610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3011-2">
   <w.rf>
    <LM>w#w-d1t3011-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3011-3">
   <w.rf>
    <LM>w#w-d1t3011-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3011-4">
   <w.rf>
    <LM>w#w-d1t3011-4</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d-id162082-punct">
   <w.rf>
    <LM>w#w-d-id162082-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3009-6">
   <w.rf>
    <LM>w#w-d1t3009-6</LM>
   </w.rf>
   <form>batikované</form>
   <lemma>batikovaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m032-d1t3013-1">
   <w.rf>
    <LM>w#w-d1t3013-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3013-2">
   <w.rf>
    <LM>w#w-d1t3013-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-1602-1612">
   <w.rf>
    <LM>w#w-1602-1612</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m032-d1t3013-3">
   <w.rf>
    <LM>w#w-d1t3013-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3013-4">
   <w.rf>
    <LM>w#w-d1t3013-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3013-5">
   <w.rf>
    <LM>w#w-d1t3013-5</LM>
   </w.rf>
   <form>vyšívané</form>
   <lemma>vyšívaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m032-d-m-d1e3004-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3004-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3020-x2">
  <m id="m032-d1t3023-1">
   <w.rf>
    <LM>w#w-d1t3023-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3023-2">
   <w.rf>
    <LM>w#w-d1t3023-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3023-4">
   <w.rf>
    <LM>w#w-d1t3023-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3023-5">
   <w.rf>
    <LM>w#w-d1t3023-5</LM>
   </w.rf>
   <form>večírek</form>
   <lemma>večírek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m032-d-id162363-punct">
   <w.rf>
    <LM>w#w-d-id162363-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3025-1">
   <w.rf>
    <LM>w#w-d1t3025-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3025-2">
   <w.rf>
    <LM>w#w-d1t3025-2</LM>
   </w.rf>
   <form>vystupovali</form>
   <lemma>vystupovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3025-5">
   <w.rf>
    <LM>w#w-d1t3025-5</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m032-d1t3025-4">
   <w.rf>
    <LM>w#w-d1t3025-4</LM>
   </w.rf>
   <form>umělci</form>
   <lemma>umělec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m032-d1e3020-x2-66">
   <w.rf>
    <LM>w#w-d1e3020-x2-66</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-68">
  <m id="m032-d1t3027-1">
   <w.rf>
    <LM>w#w-d1t3027-1</LM>
   </w.rf>
   <form>Ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m032-d1t3027-2">
   <w.rf>
    <LM>w#w-d1t3027-2</LM>
   </w.rf>
   <form>tančily</form>
   <lemma>tančit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-68-70">
   <w.rf>
    <LM>w#w-68-70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-72_2">
  <m id="m032-d1t3027-5">
   <w.rf>
    <LM>w#w-d1t3027-5</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3027-6">
   <w.rf>
    <LM>w#w-d1t3027-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3027-7">
   <w.rf>
    <LM>w#w-d1t3027-7</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m032-d1t3027-8">
   <w.rf>
    <LM>w#w-d1t3027-8</LM>
   </w.rf>
   <form>pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m032-d-id162593-punct">
   <w.rf>
    <LM>w#w-d-id162593-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3027-10">
   <w.rf>
    <LM>w#w-d1t3027-10</LM>
   </w.rf>
   <form>kterému</form>
   <lemma>který</lemma>
   <tag>P4ZS3----------</tag>
  </m>
  <m id="m032-d1t3029-1">
   <w.rf>
    <LM>w#w-d1t3029-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3029-2">
   <w.rf>
    <LM>w#w-d1t3029-2</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m032-d1t3029-4">
   <w.rf>
    <LM>w#w-d1t3029-4</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3029-6">
   <w.rf>
    <LM>w#w-d1t3029-6</LM>
   </w.rf>
   <form>pyramidu</form>
   <lemma>pyramida</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m032-d1t3029-7">
   <w.rf>
    <LM>w#w-d1t3029-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3029-8">
   <w.rf>
    <LM>w#w-d1t3029-8</LM>
   </w.rf>
   <form>lahví</form>
   <lemma>lahev_,s_^(^DD**láhev)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m032-d-id162751-punct">
   <w.rf>
    <LM>w#w-d-id162751-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3029-11">
   <w.rf>
    <LM>w#w-d1t3029-11</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3029-13">
   <w.rf>
    <LM>w#w-d1t3029-13</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m032-d1t3029-12">
   <w.rf>
    <LM>w#w-d1t3029-12</LM>
   </w.rf>
   <form>prkénko</form>
   <lemma>prkénko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m032-d1t3029-14">
   <w.rf>
    <LM>w#w-d1t3029-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3029-15">
   <w.rf>
    <LM>w#w-d1t3029-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3029-16">
   <w.rf>
    <LM>w#w-d1t3029-16</LM>
   </w.rf>
   <form>lahve</form>
   <lemma>lahev_,s_^(^DD**láhev)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m032-72_2-74">
   <w.rf>
    <LM>w#w-72_2-74</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-76_2">
  <m id="m032-d1t3029-21">
   <w.rf>
    <LM>w#w-d1t3029-21</LM>
   </w.rf>
   <form>Všelijak</form>
   <lemma>všelijak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3029-22">
   <w.rf>
    <LM>w#w-d1t3029-22</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3029-24">
   <w.rf>
    <LM>w#w-d1t3029-24</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3029-25">
   <w.rf>
    <LM>w#w-d1t3029-25</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m032-d1t3029-26">
   <w.rf>
    <LM>w#w-d1t3029-26</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m032-d-m-d1e3020-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3020-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3032-x2">
  <m id="m032-d1t3037-2">
   <w.rf>
    <LM>w#w-d1t3037-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3037-3">
   <w.rf>
    <LM>w#w-d1t3037-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m032-d1t3037-4">
   <w.rf>
    <LM>w#w-d1t3037-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3037-5">
   <w.rf>
    <LM>w#w-d1t3037-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3037-7">
   <w.rf>
    <LM>w#w-d1t3037-7</LM>
   </w.rf>
   <form>vyfocená</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m032-d-m-d1e3032-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3032-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3032-x3">
  <m id="m032-d1t3050-1">
   <w.rf>
    <LM>w#w-d1t3050-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3050-2">
   <w.rf>
    <LM>w#w-d1t3050-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3050-3">
   <w.rf>
    <LM>w#w-d1t3050-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m032-d-m-d1e3032-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3032-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-82">
  <m id="m032-d1t3048-11">
   <w.rf>
    <LM>w#w-d1t3048-11</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3048-10">
   <w.rf>
    <LM>w#w-d1t3048-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3048-7">
   <w.rf>
    <LM>w#w-d1t3048-7</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3048-8">
   <w.rf>
    <LM>w#w-d1t3048-8</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m032-d1t3048-9">
   <w.rf>
    <LM>w#w-d1t3048-9</LM>
   </w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3032-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3032-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3052-x2">
  <m id="m032-d1t3055-1">
   <w.rf>
    <LM>w#w-d1t3055-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3055-2">
   <w.rf>
    <LM>w#w-d1t3055-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m032-d1t3055-3">
   <w.rf>
    <LM>w#w-d1t3055-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m032-d1t3055-4">
   <w.rf>
    <LM>w#w-d1t3055-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3055-5">
   <w.rf>
    <LM>w#w-d1t3055-5</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3055-6">
   <w.rf>
    <LM>w#w-d1t3055-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d-id163550-punct">
   <w.rf>
    <LM>w#w-d-id163550-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3056-x2">
  <m id="m032-d1t3061-5">
   <w.rf>
    <LM>w#w-d1t3061-5</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3061-4">
   <w.rf>
    <LM>w#w-d1t3061-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1e3056-x2-122">
   <w.rf>
    <LM>w#w-d1e3056-x2-122</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3061-1">
   <w.rf>
    <LM>w#w-d1t3061-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3061-2">
   <w.rf>
    <LM>w#w-d1t3061-2</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m032-d1t3061-3">
   <w.rf>
    <LM>w#w-d1t3061-3</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m032-d-m-d1e3056-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3056-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3064-x2">
  <m id="m032-d1t3069-2">
   <w.rf>
    <LM>w#w-d1t3069-2</LM>
   </w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3069-4">
   <w.rf>
    <LM>w#w-d1t3069-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3069-5">
   <w.rf>
    <LM>w#w-d1t3069-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3069-3">
   <w.rf>
    <LM>w#w-d1t3069-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3069-6">
   <w.rf>
    <LM>w#w-d1t3069-6</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3069-7">
   <w.rf>
    <LM>w#w-d1t3069-7</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t3069-8">
   <w.rf>
    <LM>w#w-d1t3069-8</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m032-d-m-d1e3064-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3064-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3064-x3">
  <m id="m032-d1t3080-1">
   <w.rf>
    <LM>w#w-d1t3080-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m032-d1t3080-2">
   <w.rf>
    <LM>w#w-d1t3080-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3080-3">
   <w.rf>
    <LM>w#w-d1t3080-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m032-d1t3080-4">
   <w.rf>
    <LM>w#w-d1t3080-4</LM>
   </w.rf>
   <form>netroufnu</form>
   <lemma>troufnout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m032-d-m-d1e3064-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3064-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3064-x4">
  <m id="m032-d1t3082-1">
   <w.rf>
    <LM>w#w-d1t3082-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m032-d-m-d1e3064-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3064-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3083-x2">
  <m id="m032-d1t3088-2">
   <w.rf>
    <LM>w#w-d1t3088-2</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m032-d1t3088-3">
   <w.rf>
    <LM>w#w-d1t3088-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3088-4">
   <w.rf>
    <LM>w#w-d1t3088-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m032-d1t3088-5">
   <w.rf>
    <LM>w#w-d1t3088-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m032-d-id164144-punct">
   <w.rf>
    <LM>w#w-d-id164144-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3083-x4">
  <m id="m032-d1t3090-1">
   <w.rf>
    <LM>w#w-d1t3090-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1e3083-x4-130">
   <w.rf>
    <LM>w#w-d1e3083-x4-130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-132">
  <m id="m032-d1t3094-1">
   <w.rf>
    <LM>w#w-d1t3094-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m032-d1t3094-2">
   <w.rf>
    <LM>w#w-d1t3094-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3094-3">
   <w.rf>
    <LM>w#w-d1t3094-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3094-4">
   <w.rf>
    <LM>w#w-d1t3094-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m032-d1t3094-5">
   <w.rf>
    <LM>w#w-d1t3094-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m032-d-id164269-punct">
   <w.rf>
    <LM>w#w-d-id164269-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3100-x2">
  <m id="m032-d1t3103-1">
   <w.rf>
    <LM>w#w-d1t3103-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3103-2">
   <w.rf>
    <LM>w#w-d1t3103-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3103-3">
   <w.rf>
    <LM>w#w-d1t3103-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3103-4">
   <w.rf>
    <LM>w#w-d1t3103-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3103-5">
   <w.rf>
    <LM>w#w-d1t3103-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m032-d1e3100-x2-154">
   <w.rf>
    <LM>w#w-d1e3100-x2-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-156">
  <m id="m032-d1t3103-8">
   <w.rf>
    <LM>w#w-d1t3103-8</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3103-9">
   <w.rf>
    <LM>w#w-d1t3103-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3103-10">
   <w.rf>
    <LM>w#w-d1t3103-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3103-11">
   <w.rf>
    <LM>w#w-d1t3103-11</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m032-d1t3103-12">
   <w.rf>
    <LM>w#w-d1t3103-12</LM>
   </w.rf>
   <form>1999</form>
   <lemma>1999</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m032-156-158">
   <w.rf>
    <LM>w#w-156-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-160">
  <m id="m032-d1t3105-9">
   <w.rf>
    <LM>w#w-d1t3105-9</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3105-10">
   <w.rf>
    <LM>w#w-d1t3105-10</LM>
   </w.rf>
   <form>červnu</form>
   <lemma>červen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m032-d1t3105-2">
   <w.rf>
    <LM>w#w-d1t3105-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3105-3">
   <w.rf>
    <LM>w#w-d1t3105-3</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3105-4">
   <w.rf>
    <LM>w#w-d1t3105-4</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t3105-11">
   <w.rf>
    <LM>w#w-d1t3105-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3105-12">
   <w.rf>
    <LM>w#w-d1t3105-12</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m032-d1t3105-5">
   <w.rf>
    <LM>w#w-d1t3105-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3105-7">
   <w.rf>
    <LM>w#w-d1t3105-7</LM>
   </w.rf>
   <form>Gradace</form>
   <lemma>Gradac_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3100-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3100-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3112-x2">
  <m id="m032-d1t3115-2">
   <w.rf>
    <LM>w#w-d1t3115-2</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3115-3">
   <w.rf>
    <LM>w#w-d1t3115-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-d1t3115-4">
   <w.rf>
    <LM>w#w-d1t3115-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3115-6">
   <w.rf>
    <LM>w#w-d1t3115-6</LM>
   </w.rf>
   <form>Dubrovníku</form>
   <lemma>Dubrovník_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m032-d1e3112-x2-188">
   <w.rf>
    <LM>w#w-d1e3112-x2-188</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-190">
  <m id="m032-d1t3115-13">
   <w.rf>
    <LM>w#w-d1t3115-13</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m032-d1t3115-14">
   <w.rf>
    <LM>w#w-d1t3115-14</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m032-d1t3115-11">
   <w.rf>
    <LM>w#w-d1t3115-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3115-12">
   <w.rf>
    <LM>w#w-d1t3115-12</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3115-15">
   <w.rf>
    <LM>w#w-d1t3115-15</LM>
   </w.rf>
   <form>lázně</form>
   <lemma>lázně</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m032-190-196">
   <w.rf>
    <LM>w#w-190-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-198">
  <m id="m032-d1t3115-18">
   <w.rf>
    <LM>w#w-d1t3115-18</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3115-19">
   <w.rf>
    <LM>w#w-d1t3115-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3115-21">
   <w.rf>
    <LM>w#w-d1t3115-21</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m032-d-id165185-punct">
   <w.rf>
    <LM>w#w-d-id165185-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3115-24">
   <w.rf>
    <LM>w#w-d1t3115-24</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3115-25">
   <w.rf>
    <LM>w#w-d1t3115-25</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3115-26">
   <w.rf>
    <LM>w#w-d1t3115-26</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3115-27">
   <w.rf>
    <LM>w#w-d1t3115-27</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t3115-28">
   <w.rf>
    <LM>w#w-d1t3115-28</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3115-29">
   <w.rf>
    <LM>w#w-d1t3115-29</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m032-d1t3115-30">
   <w.rf>
    <LM>w#w-d1t3115-30</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m032-190-192">
   <w.rf>
    <LM>w#w-190-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-194">
  <m id="m032-d1t3117-4">
   <w.rf>
    <LM>w#w-d1t3117-4</LM>
   </w.rf>
   <form>Domluvila</form>
   <lemma>domluvit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3117-3">
   <w.rf>
    <LM>w#w-d1t3117-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3117-5">
   <w.rf>
    <LM>w#w-d1t3117-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3121-1">
   <w.rf>
    <LM>w#w-d1t3121-1</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m032-d-id165438-punct">
   <w.rf>
    <LM>w#w-d-id165438-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3121-3">
   <w.rf>
    <LM>w#w-d1t3121-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m032-d1t3121-5">
   <w.rf>
    <LM>w#w-d1t3121-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3121-6">
   <w.rf>
    <LM>w#w-d1t3121-6</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3-------</tag>
  </m>
  <m id="m032-d1t3121-4">
   <w.rf>
    <LM>w#w-d1t3121-4</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d-id165502-punct">
   <w.rf>
    <LM>w#w-d-id165502-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3121-8">
   <w.rf>
    <LM>w#w-d1t3121-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3121-9">
   <w.rf>
    <LM>w#w-d1t3121-9</LM>
   </w.rf>
   <form>jely</form>
   <lemma>jet-1</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-d1t3121-10">
   <w.rf>
    <LM>w#w-d1t3121-10</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-194-200">
   <w.rf>
    <LM>w#w-194-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-202">
  <m id="m032-d1t3121-12">
   <w.rf>
    <LM>w#w-d1t3121-12</LM>
   </w.rf>
   <form>Zavřely</form>
   <lemma>zavřít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m032-d1t3121-13">
   <w.rf>
    <LM>w#w-d1t3121-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3123-2">
   <w.rf>
    <LM>w#w-d1t3123-2</LM>
   </w.rf>
   <form>napsaly</form>
   <lemma>napsat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m032-202-204">
   <w.rf>
    <LM>w#w-202-204</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3123-3">
   <w.rf>
    <LM>w#w-d1t3123-3</LM>
   </w.rf>
   <form>Dovolená</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-202-208">
   <w.rf>
    <LM>w#w-202-208</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-202-206">
   <w.rf>
    <LM>w#w-202-206</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-210">
  <m id="m032-d1t3126-1">
   <w.rf>
    <LM>w#w-d1t3126-1</LM>
   </w.rf>
   <form>Každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m032-210-212">
   <w.rf>
    <LM>w#w-210-212</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3126-2">
   <w.rf>
    <LM>w#w-d1t3126-2</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m032-d1t3126-3">
   <w.rf>
    <LM>w#w-d1t3126-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m032-d1t3126-5">
   <w.rf>
    <LM>w#w-d1t3126-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3126-6">
   <w.rf>
    <LM>w#w-d1t3126-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3126-7">
   <w.rf>
    <LM>w#w-d1t3126-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m032-d1t3126-8">
   <w.rf>
    <LM>w#w-d1t3126-8</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m032-d1t3126-9">
   <w.rf>
    <LM>w#w-d1t3126-9</LM>
   </w.rf>
   <form>vyzvednout</form>
   <lemma>vyzvednout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m032-d1t3126-11">
   <w.rf>
    <LM>w#w-d1t3126-11</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m032-d-id165849-punct">
   <w.rf>
    <LM>w#w-d-id165849-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3128-3">
   <w.rf>
    <LM>w#w-d1t3128-3</LM>
   </w.rf>
   <form>obeslaly</form>
   <lemma>obeslat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m032-d-id165906-punct">
   <w.rf>
    <LM>w#w-d-id165906-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3128-5">
   <w.rf>
    <LM>w#w-d1t3128-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3128-6">
   <w.rf>
    <LM>w#w-d1t3128-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m032-d1t3128-7">
   <w.rf>
    <LM>w#w-d1t3128-7</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m032-d1t3128-8">
   <w.rf>
    <LM>w#w-d1t3128-8</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m032-d-id165977-punct">
   <w.rf>
    <LM>w#w-d-id165977-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3130-2">
   <w.rf>
    <LM>w#w-d1t3130-2</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3130-3">
   <w.rf>
    <LM>w#w-d1t3130-3</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3130-4">
   <w.rf>
    <LM>w#w-d1t3130-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3130-5">
   <w.rf>
    <LM>w#w-d1t3130-5</LM>
   </w.rf>
   <form>vrátí</form>
   <lemma>vrátit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m032-d-m-d1e3112-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3112-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3143-x2">
  <m id="m032-d1t3146-14">
   <w.rf>
    <LM>w#w-d1t3146-14</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3146-13">
   <w.rf>
    <LM>w#w-d1t3146-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m032-d1t3146-15">
   <w.rf>
    <LM>w#w-d1t3146-15</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3146-16">
   <w.rf>
    <LM>w#w-d1t3146-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3146-17">
   <w.rf>
    <LM>w#w-d1t3146-17</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m032-d1t3146-18">
   <w.rf>
    <LM>w#w-d1t3146-18</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m032-d-m-d1e3143-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3143-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-370_2">
  <m id="m032-d1t3138-2">
   <w.rf>
    <LM>w#w-d1t3138-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m032-d1t3138-3">
   <w.rf>
    <LM>w#w-d1t3138-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3138-4">
   <w.rf>
    <LM>w#w-d1t3138-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3146-5">
   <w.rf>
    <LM>w#w-d1t3146-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3146-6">
   <w.rf>
    <LM>w#w-d1t3146-6</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m032-d1t3146-1">
   <w.rf>
    <LM>w#w-d1t3146-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3146-3">
   <w.rf>
    <LM>w#w-d1t3146-3</LM>
   </w.rf>
   <form>Bechyni</form>
   <lemma>Bechyně-2_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m032-d1e3143-x2-316">
   <w.rf>
    <LM>w#w-d1e3143-x2-316</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3159-x2">
  <m id="m032-d1t3154-1">
   <w.rf>
    <LM>w#w-d1t3154-1</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m032-d1t3154-2">
   <w.rf>
    <LM>w#w-d1t3154-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3154-3">
   <w.rf>
    <LM>w#w-d1t3154-3</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3154-4">
   <w.rf>
    <LM>w#w-d1t3154-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3162-1">
   <w.rf>
    <LM>w#w-d1t3162-1</LM>
   </w.rf>
   <form>přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3162-4">
   <w.rf>
    <LM>w#w-d1t3162-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3162-2">
   <w.rf>
    <LM>w#w-d1t3162-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3162-3">
   <w.rf>
    <LM>w#w-d1t3162-3</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m032-d1e3159-x2-392">
   <w.rf>
    <LM>w#w-d1e3159-x2-392</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-394_2">
  <m id="m032-d1t3164-4">
   <w.rf>
    <LM>w#w-d1t3164-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3164-2">
   <w.rf>
    <LM>w#w-d1t3164-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3164-3">
   <w.rf>
    <LM>w#w-d1t3164-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3164-5">
   <w.rf>
    <LM>w#w-d1t3164-5</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m032-d1t3164-6">
   <w.rf>
    <LM>w#w-d1t3164-6</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m032-394_2-396">
   <w.rf>
    <LM>w#w-394_2-396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-398">
  <m id="m032-d1t3164-14">
   <w.rf>
    <LM>w#w-d1t3164-14</LM>
   </w.rf>
   <form>Přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3164-15">
   <w.rf>
    <LM>w#w-d1t3164-15</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3164-16">
   <w.rf>
    <LM>w#w-d1t3164-16</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3164-18">
   <w.rf>
    <LM>w#w-d1t3164-18</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m032-d1t3164-19">
   <w.rf>
    <LM>w#w-d1t3164-19</LM>
   </w.rf>
   <form>dcerou</form>
   <lemma>dcera</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m032-d1t3166-1">
   <w.rf>
    <LM>w#w-d1t3166-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3166-2">
   <w.rf>
    <LM>w#w-d1t3166-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3166-3">
   <w.rf>
    <LM>w#w-d1t3166-3</LM>
   </w.rf>
   <form>vnučkou</form>
   <lemma>vnučka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m032-398-400">
   <w.rf>
    <LM>w#w-398-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-402_2">
  <m id="m032-d1t3168-2">
   <w.rf>
    <LM>w#w-d1t3168-2</LM>
   </w.rf>
   <form>Říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m032-402_2-404_2">
   <w.rf>
    <LM>w#w-402_2-404_2</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-402_2-406">
   <w.rf>
    <LM>w#w-402_2-406</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3170-1">
   <w.rf>
    <LM>w#w-d1t3170-1</LM>
   </w.rf>
   <form>Neboj</form>
   <lemma>bát-1</lemma>
   <tag>Vi-S---2--N-I--</tag>
  </m>
  <m id="m032-d1t3170-2">
   <w.rf>
    <LM>w#w-d1t3170-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-402_2-408">
   <w.rf>
    <LM>w#w-402_2-408</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3170-3">
   <w.rf>
    <LM>w#w-d1t3170-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3170-5">
   <w.rf>
    <LM>w#w-d1t3170-5</LM>
   </w.rf>
   <form>Chorvatsko</form>
   <lemma>Chorvatsko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m032-d1t3170-7">
   <w.rf>
    <LM>w#w-d1t3170-7</LM>
   </w.rf>
   <form>nepřijdeš</form>
   <lemma>přijít</lemma>
   <tag>VB-S---2P-NAP--</tag>
  </m>
  <m id="m032-402_2-1712">
   <w.rf>
    <LM>w#w-402_2-1712</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-1713">
  <m id="m032-d1t3173-1">
   <w.rf>
    <LM>w#w-d1t3173-1</LM>
   </w.rf>
   <form>Seznámila</form>
   <lemma>seznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3173-2">
   <w.rf>
    <LM>w#w-d1t3173-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3173-3">
   <w.rf>
    <LM>w#w-d1t3173-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3173-4">
   <w.rf>
    <LM>w#w-d1t3173-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3173-5">
   <w.rf>
    <LM>w#w-d1t3173-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3173-6">
   <w.rf>
    <LM>w#w-d1t3173-6</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m032-d1t3173-7">
   <w.rf>
    <LM>w#w-d1t3173-7</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m032-d-id167408-punct">
   <w.rf>
    <LM>w#w-d-id167408-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3173-9">
   <w.rf>
    <LM>w#w-d1t3173-9</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m032-d1t3173-10">
   <w.rf>
    <LM>w#w-d1t3173-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m032-d1t3173-12">
   <w.rf>
    <LM>w#w-d1t3173-12</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m032-d1t3173-11">
   <w.rf>
    <LM>w#w-d1t3173-11</LM>
   </w.rf>
   <form>pozval</form>
   <lemma>pozvat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m032-d1t3173-13">
   <w.rf>
    <LM>w#w-d1t3173-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3173-14">
   <w.rf>
    <LM>w#w-d1t3173-14</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m032-d1t3173-15">
   <w.rf>
    <LM>w#w-d1t3173-15</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m032-d1t3173-16">
   <w.rf>
    <LM>w#w-d1t3173-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3173-17">
   <w.rf>
    <LM>w#w-d1t3173-17</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3159-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3159-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-402_2-410">
   <w.rf>
    <LM>w#w-402_2-410</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3175-x2">
  <m id="m032-d1e3175-x2-452">
   <w.rf>
    <LM>w#w-d1e3175-x2-452</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d-id167669-punct">
   <w.rf>
    <LM>w#w-d-id167669-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3180-6">
   <w.rf>
    <LM>w#w-d1t3180-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3180-7">
   <w.rf>
    <LM>w#w-d1t3180-7</LM>
   </w.rf>
   <form>můžem</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI-6</tag>
  </m>
  <m id="m032-d1t3180-8">
   <w.rf>
    <LM>w#w-d1t3180-8</LM>
   </w.rf>
   <form>přijet</form>
   <lemma>přijet</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m032-d1t3180-1">
   <w.rf>
    <LM>w#w-d1t3180-1</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m032-d1t3180-2">
   <w.rf>
    <LM>w#w-d1t3180-2</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m032-d1t3180-3">
   <w.rf>
    <LM>w#w-d1t3180-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3180-4">
   <w.rf>
    <LM>w#w-d1t3180-4</LM>
   </w.rf>
   <form>srpnu</form>
   <lemma>srpen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m032-d1e3175-x2-454">
   <w.rf>
    <LM>w#w-d1e3175-x2-454</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3190-2">
   <w.rf>
    <LM>w#w-d1t3190-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3190-3">
   <w.rf>
    <LM>w#w-d1t3190-3</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m032-d1t3190-6">
   <w.rf>
    <LM>w#w-d1t3190-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3190-7">
   <w.rf>
    <LM>w#w-d1t3190-7</LM>
   </w.rf>
   <form>můžem</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI-6</tag>
  </m>
  <m id="m032-d1t3190-8">
   <w.rf>
    <LM>w#w-d1t3190-8</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t3190-9">
   <w.rf>
    <LM>w#w-d1t3190-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3190-10">
   <w.rf>
    <LM>w#w-d1t3190-10</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m032-d1t3190-11">
   <w.rf>
    <LM>w#w-d1t3190-11</LM>
   </w.rf>
   <form>chcem</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-AAI-6</tag>
  </m>
  <m id="m032-d-m-d1e3175-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3175-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3187-x2">
  <m id="m032-d1t3192-5">
   <w.rf>
    <LM>w#w-d1t3192-5</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m032-d1e3187-x2-456">
   <w.rf>
    <LM>w#w-d1e3187-x2-456</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3192-4">
   <w.rf>
    <LM>w#w-d1t3192-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3194-1">
   <w.rf>
    <LM>w#w-d1t3194-1</LM>
   </w.rf>
   <form>necelé</form>
   <lemma>celý</lemma>
   <tag>AAIP4----1N----</tag>
  </m>
  <m id="m032-d1t3194-2">
   <w.rf>
    <LM>w#w-d1t3194-2</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m032-d1t3194-3">
   <w.rf>
    <LM>w#w-d1t3194-3</LM>
   </w.rf>
   <form>neděle</form>
   <lemma>neděle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m032-d1e3187-x2-458">
   <w.rf>
    <LM>w#w-d1e3187-x2-458</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-460">
  <m id="m032-d1t3194-12">
   <w.rf>
    <LM>w#w-d1t3194-12</LM>
   </w.rf>
   <form>Navštívily</form>
   <lemma>navštívit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m032-d1t3194-13">
   <w.rf>
    <LM>w#w-d1t3194-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3194-15">
   <w.rf>
    <LM>w#w-d1t3194-15</LM>
   </w.rf>
   <form>Dubrovník</form>
   <lemma>Dubrovník_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m032-460-512">
   <w.rf>
    <LM>w#w-460-512</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3202-1">
   <w.rf>
    <LM>w#w-d1t3202-1</LM>
   </w.rf>
   <form>navštívily</form>
   <lemma>navštívit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m032-d1t3202-2">
   <w.rf>
    <LM>w#w-d1t3202-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3202-4">
   <w.rf>
    <LM>w#w-d1t3202-4</LM>
   </w.rf>
   <form>Split</form>
   <lemma>Split_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m032-d1t3202-7">
   <w.rf>
    <LM>w#w-d1t3202-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3210-1">
   <w.rf>
    <LM>w#w-d1t3210-1</LM>
   </w.rf>
   <form>městečka</form>
   <lemma>městečko</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m032-d1t3212-2">
   <w.rf>
    <LM>w#w-d1t3212-2</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3212-3">
   <w.rf>
    <LM>w#w-d1t3212-3</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3187-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3187-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3207-x2">
  <m id="m032-d1t3212-7">
   <w.rf>
    <LM>w#w-d1t3212-7</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m032-d1t3212-8">
   <w.rf>
    <LM>w#w-d1t3212-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3212-9">
   <w.rf>
    <LM>w#w-d1t3212-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3212-10">
   <w.rf>
    <LM>w#w-d1t3212-10</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3212-21">
   <w.rf>
    <LM>w#w-d1t3212-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3212-22">
   <w.rf>
    <LM>w#w-d1t3212-22</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m032-d1t3212-23">
   <w.rf>
    <LM>w#w-d1t3212-23</LM>
   </w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m032-d-id168746-punct">
   <w.rf>
    <LM>w#w-d-id168746-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3212-12">
   <w.rf>
    <LM>w#w-d1t3212-12</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3212-13">
   <w.rf>
    <LM>w#w-d1t3212-13</LM>
   </w.rf>
   <form>zavřela</form>
   <lemma>zavřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3212-15">
   <w.rf>
    <LM>w#w-d1t3212-15</LM>
   </w.rf>
   <form>dílnu</form>
   <lemma>dílna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m032-d-id168817-punct">
   <w.rf>
    <LM>w#w-d-id168817-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3212-26">
   <w.rf>
    <LM>w#w-d1t3212-26</LM>
   </w.rf>
   <form>stěhovala</form>
   <lemma>stěhovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1e3207-x2-514">
   <w.rf>
    <LM>w#w-d1e3207-x2-514</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-516_2">
  <m id="m032-d1t3214-2">
   <w.rf>
    <LM>w#w-d1t3214-2</LM>
   </w.rf>
   <form>Žila</form>
   <lemma>žít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3214-3">
   <w.rf>
    <LM>w#w-d1t3214-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3214-4">
   <w.rf>
    <LM>w#w-d1t3214-4</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3216-1">
   <w.rf>
    <LM>w#w-d1t3216-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3216-2">
   <w.rf>
    <LM>w#w-d1t3216-2</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m032-d1t3216-3">
   <w.rf>
    <LM>w#w-d1t3216-3</LM>
   </w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m032-d-m-d1e3207-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3207-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3219-x2">
  <m id="m032-d1t3224-4">
   <w.rf>
    <LM>w#w-d1t3224-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3224-2">
   <w.rf>
    <LM>w#w-d1t3224-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3224-5">
   <w.rf>
    <LM>w#w-d1t3224-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3224-6">
   <w.rf>
    <LM>w#w-d1t3224-6</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m032-d1t3224-7">
   <w.rf>
    <LM>w#w-d1t3224-7</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3224-8">
   <w.rf>
    <LM>w#w-d1t3224-8</LM>
   </w.rf>
   <form>pětkrát</form>
   <lemma>pětkrát`5</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m032-d1e3219-x2-548">
   <w.rf>
    <LM>w#w-d1e3219-x2-548</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3234-2">
   <w.rf>
    <LM>w#w-d1t3234-2</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3234-3">
   <w.rf>
    <LM>w#w-d1t3234-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3234-4">
   <w.rf>
    <LM>w#w-d1t3234-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3234-5">
   <w.rf>
    <LM>w#w-d1t3234-5</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m032-d-id169510-punct">
   <w.rf>
    <LM>w#w-d-id169510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3234-7">
   <w.rf>
    <LM>w#w-d1t3234-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3234-8">
   <w.rf>
    <LM>w#w-d1t3234-8</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m032-d1t3234-9">
   <w.rf>
    <LM>w#w-d1t3234-9</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3219-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3219-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3231-x2">
  <m id="m032-d1t3234-11">
   <w.rf>
    <LM>w#w-d1t3234-11</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3234-12">
   <w.rf>
    <LM>w#w-d1t3234-12</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3234-13">
   <w.rf>
    <LM>w#w-d1t3234-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3234-14">
   <w.rf>
    <LM>w#w-d1t3234-14</LM>
   </w.rf>
   <form>nejela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m032-d1t3234-15">
   <w.rf>
    <LM>w#w-d1t3234-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3234-16">
   <w.rf>
    <LM>w#w-d1t3234-16</LM>
   </w.rf>
   <form>červenci</form>
   <lemma>červenec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m032-d1t3234-17">
   <w.rf>
    <LM>w#w-d1t3234-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3234-18">
   <w.rf>
    <LM>w#w-d1t3234-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3234-19">
   <w.rf>
    <LM>w#w-d1t3234-19</LM>
   </w.rf>
   <form>srpnu</form>
   <lemma>srpen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m032-d-id169700-punct">
   <w.rf>
    <LM>w#w-d-id169700-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3234-21">
   <w.rf>
    <LM>w#w-d1t3234-21</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m032-d1t3234-22">
   <w.rf>
    <LM>w#w-d1t3234-22</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3234-24">
   <w.rf>
    <LM>w#w-d1t3234-24</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3234-25">
   <w.rf>
    <LM>w#w-d1t3234-25</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m032-d1t3234-26">
   <w.rf>
    <LM>w#w-d1t3234-26</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m032-d-m-d1e3231-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3231-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-d1e3247-x2">
  <m id="m032-d1t3250-1">
   <w.rf>
    <LM>w#w-d1t3250-1</LM>
   </w.rf>
   <form>Jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3250-2">
   <w.rf>
    <LM>w#w-d1t3250-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3250-3">
   <w.rf>
    <LM>w#w-d1t3250-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3250-4">
   <w.rf>
    <LM>w#w-d1t3250-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3250-6">
   <w.rf>
    <LM>w#w-d1t3250-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3250-8">
   <w.rf>
    <LM>w#w-d1t3250-8</LM>
   </w.rf>
   <form>Velikonoc</form>
   <lemma>Velikonoce_;m</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m032-d1t3250-10">
   <w.rf>
    <LM>w#w-d1t3250-10</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3250-11">
   <w.rf>
    <LM>w#w-d1t3250-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3250-12">
   <w.rf>
    <LM>w#w-d1t3250-12</LM>
   </w.rf>
   <form>polovičky</form>
   <lemma>polovička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m032-d1t3250-14">
   <w.rf>
    <LM>w#w-d1t3250-14</LM>
   </w.rf>
   <form>července</form>
   <lemma>červenec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m032-d-id170137-punct">
   <w.rf>
    <LM>w#w-d-id170137-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3252-1">
   <w.rf>
    <LM>w#w-d1t3252-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3252-5">
   <w.rf>
    <LM>w#w-d1t3252-5</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3252-6">
   <w.rf>
    <LM>w#w-d1t3252-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m032-d1t3252-7">
   <w.rf>
    <LM>w#w-d1t3252-7</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m032-d1t3252-8">
   <w.rf>
    <LM>w#w-d1t3252-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3252-9">
   <w.rf>
    <LM>w#w-d1t3252-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m032-d1t3252-11">
   <w.rf>
    <LM>w#w-d1t3252-11</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m032-d1e3247-x2-574">
   <w.rf>
    <LM>w#w-d1e3247-x2-574</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-576">
  <m id="m032-d1t3254-6">
   <w.rf>
    <LM>w#w-d1t3254-6</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3254-7">
   <w.rf>
    <LM>w#w-d1t3254-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3256-2">
   <w.rf>
    <LM>w#w-d1t3256-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m032-d1t3256-3">
   <w.rf>
    <LM>w#w-d1t3256-3</LM>
   </w.rf>
   <form>studená</form>
   <lemma>studený</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m032-d1t3256-4">
   <w.rf>
    <LM>w#w-d1t3256-4</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3256-1">
   <w.rf>
    <LM>w#w-d1t3256-1</LM>
   </w.rf>
   <form>nevadila</form>
   <lemma>vadit</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m032-576-584">
   <w.rf>
    <LM>w#w-576-584</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3254-4">
   <w.rf>
    <LM>w#w-d1t3254-4</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m032-d1t3254-2">
   <w.rf>
    <LM>w#w-d1t3254-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3254-3">
   <w.rf>
    <LM>w#w-d1t3254-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m032-d1t3254-1">
   <w.rf>
    <LM>w#w-d1t3254-1</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3258-2">
   <w.rf>
    <LM>w#w-d1t3258-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m032-d1t3258-3">
   <w.rf>
    <LM>w#w-d1t3258-3</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m032-d1t3258-4">
   <w.rf>
    <LM>w#w-d1t3258-4</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m032-d1t3258-5">
   <w.rf>
    <LM>w#w-d1t3258-5</LM>
   </w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m032-576-580">
   <w.rf>
    <LM>w#w-576-580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-582">
  <m id="m032-d1t3258-14">
   <w.rf>
    <LM>w#w-d1t3258-14</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3258-16">
   <w.rf>
    <LM>w#w-d1t3258-16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3258-17">
   <w.rf>
    <LM>w#w-d1t3258-17</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m032-d1t3258-15">
   <w.rf>
    <LM>w#w-d1t3258-15</LM>
   </w.rf>
   <form>přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m032-d1t3258-18">
   <w.rf>
    <LM>w#w-d1t3258-18</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m032-d1t3258-19">
   <w.rf>
    <LM>w#w-d1t3258-19</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1t3258-21">
   <w.rf>
    <LM>w#w-d1t3258-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m032-d1t3258-25">
   <w.rf>
    <LM>w#w-d1t3258-25</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m032-d1t3258-23">
   <w.rf>
    <LM>w#w-d1t3258-23</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-582-586">
   <w.rf>
    <LM>w#w-582-586</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-588">
  <m id="m032-d1t3258-33">
   <w.rf>
    <LM>w#w-d1t3258-33</LM>
   </w.rf>
   <form>Zuzaně</form>
   <lemma>Zuzana_;Y</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m032-d1t3258-28">
   <w.rf>
    <LM>w#w-d1t3258-28</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m032-d1t3258-29">
   <w.rf>
    <LM>w#w-d1t3258-29</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m032-d1t3258-30">
   <w.rf>
    <LM>w#w-d1t3258-30</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m032-588-622">
   <w.rf>
    <LM>w#w-588-622</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-1777">
  <m id="m032-d1t3261-4">
   <w.rf>
    <LM>w#w-d1t3261-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3261-3">
   <w.rf>
    <LM>w#w-d1t3261-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3261-5">
   <w.rf>
    <LM>w#w-d1t3261-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m032-d1t3261-6">
   <w.rf>
    <LM>w#w-d1t3261-6</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m032-d1t3261-7">
   <w.rf>
    <LM>w#w-d1t3261-7</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m032-d1t3261-8">
   <w.rf>
    <LM>w#w-d1t3261-8</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m032-d-id171190-punct">
   <w.rf>
    <LM>w#w-d-id171190-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m032-d1t3261-10">
   <w.rf>
    <LM>w#w-d1t3261-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m032-d1t3261-11">
   <w.rf>
    <LM>w#w-d1t3261-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3261-12">
   <w.rf>
    <LM>w#w-d1t3261-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3261-13">
   <w.rf>
    <LM>w#w-d1t3261-13</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m032-d1t3261-15">
   <w.rf>
    <LM>w#w-d1t3261-15</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m032-d1e3247-x3-624">
   <w.rf>
    <LM>w#w-d1e3247-x3-624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-626_2">
  <m id="m032-d1t3265-2">
   <w.rf>
    <LM>w#w-d1t3265-2</LM>
   </w.rf>
   <form>Zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3265-3">
   <w.rf>
    <LM>w#w-d1t3265-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m032-d1t3265-5">
   <w.rf>
    <LM>w#w-d1t3265-5</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m032-d1t3263-3">
   <w.rf>
    <LM>w#w-d1t3263-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3263-7">
   <w.rf>
    <LM>w#w-d1t3263-7</LM>
   </w.rf>
   <form>odjížděla</form>
   <lemma>odjíždět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3263-4">
   <w.rf>
    <LM>w#w-d1t3263-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m032-d1t3263-5">
   <w.rf>
    <LM>w#w-d1t3263-5</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m032-d1t3263-8">
   <w.rf>
    <LM>w#w-d1t3263-8</LM>
   </w.rf>
   <form>autem</form>
   <lemma>auto</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m032-626_2-628_2">
   <w.rf>
    <LM>w#w-626_2-628_2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m032-630">
  <m id="m032-d1t3267-6">
   <w.rf>
    <LM>w#w-d1t3267-6</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3267-2">
   <w.rf>
    <LM>w#w-d1t3267-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m032-d1t3267-3">
   <w.rf>
    <LM>w#w-d1t3267-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m032-d1t3267-4">
   <w.rf>
    <LM>w#w-d1t3267-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m032-d1t3267-5">
   <w.rf>
    <LM>w#w-d1t3267-5</LM>
   </w.rf>
   <form>nejdéle</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m032-630-632">
   <w.rf>
    <LM>w#w-630-632</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
