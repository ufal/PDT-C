<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_913.04.w.gz" />
  </references>
 </head>
 <s id="m913-12941_03-4719">
  <m id="m913-d1t1271-2">
   <w.rf>
    <LM>w#w-d1t1271-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m913-d1t1271-4">
   <w.rf>
    <LM>w#w-d1t1271-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m913-d1t1271-5">
   <w.rf>
    <LM>w#w-d1t1271-5</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m913-4719-4729">
   <w.rf>
    <LM>w#w-4719-4729</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m913-d1t1271-6">
   <w.rf>
    <LM>w#w-d1t1271-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m913-d1t1271-7">
   <w.rf>
    <LM>w#w-d1t1271-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m913-d1t1271-8">
   <w.rf>
    <LM>w#w-d1t1271-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m913-d1t1271-9">
   <w.rf>
    <LM>w#w-d1t1271-9</LM>
   </w.rf>
   <form>roztomilé</form>
   <lemma>roztomilý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m913-4719-897">
   <w.rf>
    <LM>w#w-4719-897</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m913-12941_03-898">
  <m id="m913-d1t1271-11">
   <w.rf>
    <LM>w#w-d1t1271-11</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m913-d1t1271-13">
   <w.rf>
    <LM>w#w-d1t1271-13</LM>
   </w.rf>
   <form>jich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3------1</tag>
  </m>
  <m id="m913-d1t1271-12">
   <w.rf>
    <LM>w#w-d1t1271-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m913-d1t1271-14">
   <w.rf>
    <LM>w#w-d1t1271-14</LM>
   </w.rf>
   <form>tisíc</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIS1----------</tag>
  </m>
  <m id="m913-d-id101959">
   <w.rf>
    <LM>w#w-d-id101959</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m913-d1t1271-16">
   <w.rf>
    <LM>w#w-d1t1271-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m913-d1t1271-17">
   <w.rf>
    <LM>w#w-d1t1271-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m913-d1t1271-18">
   <w.rf>
    <LM>w#w-d1t1271-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m913-d1t1271-19">
   <w.rf>
    <LM>w#w-d1t1271-19</LM>
   </w.rf>
   <form>nepříjemné</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m913-d-id102023">
   <w.rf>
    <LM>w#w-d-id102023</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m913-12941_03-d1e1264-x3">
  <m id="m913-d1t1275-1">
   <w.rf>
    <LM>w#w-d1t1275-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m913-d1t1275-2">
   <w.rf>
    <LM>w#w-d1t1275-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m913-d1t1275-3">
   <w.rf>
    <LM>w#w-d1t1275-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m913-d1t1275-4">
   <w.rf>
    <LM>w#w-d1t1275-4</LM>
   </w.rf>
   <form>postele</form>
   <lemma>postel</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m913-d1t1275-5">
   <w.rf>
    <LM>w#w-d1t1275-5</LM>
   </w.rf>
   <form>nastěhovaly</form>
   <lemma>nastěhovat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m913-d1t1280-1">
   <w.rf>
    <LM>w#w-d1t1280-1</LM>
   </w.rf>
   <form>dovnitř</form>
   <lemma>dovnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m913-d1t1280-2">
   <w.rf>
    <LM>w#w-d1t1280-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m913-d1t1280-3">
   <w.rf>
    <LM>w#w-d1t1280-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m913-d1t1280-4">
   <w.rf>
    <LM>w#w-d1t1280-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m913-d1t1280-5">
   <w.rf>
    <LM>w#w-d1t1280-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m913-d1t1280-6">
   <w.rf>
    <LM>w#w-d1t1280-6</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m913-d1t1280-7">
   <w.rf>
    <LM>w#w-d1t1280-7</LM>
   </w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m913-d-id102260">
   <w.rf>
    <LM>w#w-d-id102260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
