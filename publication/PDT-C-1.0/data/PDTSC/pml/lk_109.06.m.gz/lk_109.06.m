<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_109.06.w.gz" />
  </references>
 </head>
 <s id="m109-d1e983-x2">
  <m id="m109-d1t986-1">
   <w.rf>
    <LM>w#w-d1t986-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m109-d1e983-x2-693">
   <w.rf>
    <LM>w#w-d1e983-x2-693</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-694">
  <m id="m109-d1t988-1">
   <w.rf>
    <LM>w#w-d1t988-1</LM>
   </w.rf>
   <form>Koho</form>
   <lemma>kdo</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t988-2">
   <w.rf>
    <LM>w#w-d1t988-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t988-3">
   <w.rf>
    <LM>w#w-d1t988-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t988-4">
   <w.rf>
    <LM>w#w-d1t988-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m109-d1t988-5">
   <w.rf>
    <LM>w#w-d1t988-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d-id117486-punct">
   <w.rf>
    <LM>w#w-d-id117486-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e989-x2">
  <m id="m109-d1t994-2">
   <w.rf>
    <LM>w#w-d1t994-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t994-3">
   <w.rf>
    <LM>w#w-d1t994-3</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m109-d1t994-4">
   <w.rf>
    <LM>w#w-d1t994-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t994-5">
   <w.rf>
    <LM>w#w-d1t994-5</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t994-6">
   <w.rf>
    <LM>w#w-d1t994-6</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d1t994-7">
   <w.rf>
    <LM>w#w-d1t994-7</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS2-P1-------</tag>
  </m>
  <m id="m109-d1t994-8">
   <w.rf>
    <LM>w#w-d1t994-8</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d1e989-x2-705">
   <w.rf>
    <LM>w#w-d1e989-x2-705</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-706">
  <m id="m109-d1t996-1">
   <w.rf>
    <LM>w#w-d1t996-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t996-2">
   <w.rf>
    <LM>w#w-d1t996-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t996-3">
   <w.rf>
    <LM>w#w-d1t996-3</LM>
   </w.rf>
   <form>promoce</form>
   <lemma>promoce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id117743-punct">
   <w.rf>
    <LM>w#w-d-id117743-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t996-5">
   <w.rf>
    <LM>w#w-d1t996-5</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t996-6">
   <w.rf>
    <LM>w#w-d1t996-6</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d1t996-7">
   <w.rf>
    <LM>w#w-d1t996-7</LM>
   </w.rf>
   <form>dostudoval</form>
   <lemma>dostudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t996-8">
   <w.rf>
    <LM>w#w-d1t996-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t996-9">
   <w.rf>
    <LM>w#w-d1t996-9</LM>
   </w.rf>
   <form>filozofické</form>
   <lemma>filozofický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m109-d1t996-10">
   <w.rf>
    <LM>w#w-d1t996-10</LM>
   </w.rf>
   <form>fakultě</form>
   <lemma>fakulta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t996-11">
   <w.rf>
    <LM>w#w-d1t996-11</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t996-12">
   <w.rf>
    <LM>w#w-d1t996-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t996-14">
   <w.rf>
    <LM>w#w-d1t996-14</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t996-16">
   <w.rf>
    <LM>w#w-d1t996-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t996-17">
   <w.rf>
    <LM>w#w-d1t996-17</LM>
   </w.rf>
   <form>získal</form>
   <lemma>získat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t996-18">
   <w.rf>
    <LM>w#w-d1t996-18</LM>
   </w.rf>
   <form>magistra</form>
   <lemma>magistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m109-706-707">
   <w.rf>
    <LM>w#w-706-707</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-708">
  <m id="m109-d1t998-3">
   <w.rf>
    <LM>w#w-d1t998-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t998-2">
   <w.rf>
    <LM>w#w-d1t998-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t998-4">
   <w.rf>
    <LM>w#w-d1t998-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t998-5">
   <w.rf>
    <LM>w#w-d1t998-5</LM>
   </w.rf>
   <form>promoce</form>
   <lemma>promoce</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d1t998-6">
   <w.rf>
    <LM>w#w-d1t998-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t998-8">
   <w.rf>
    <LM>w#w-d1t998-8</LM>
   </w.rf>
   <form>Karolinu</form>
   <lemma>Karolinum_;G_;m</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m109-708-709">
   <w.rf>
    <LM>w#w-708-709</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-710">
  <m id="m109-d1t1000-2">
   <w.rf>
    <LM>w#w-d1t1000-2</LM>
   </w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id118142-punct">
   <w.rf>
    <LM>w#w-d-id118142-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1000-4">
   <w.rf>
    <LM>w#w-d1t1000-4</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m109-d1t1000-5">
   <w.rf>
    <LM>w#w-d1t1000-5</LM>
   </w.rf>
   <form>objímá</form>
   <lemma>objímat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d-id118182-punct">
   <w.rf>
    <LM>w#w-d-id118182-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1000-8">
   <w.rf>
    <LM>w#w-d1t1000-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-9">
   <w.rf>
    <LM>w#w-d1t1000-9</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m109-d1t1000-10">
   <w.rf>
    <LM>w#w-d1t1000-10</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-710-711">
   <w.rf>
    <LM>w#w-710-711</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-713">
  <m id="m109-d1t1000-15">
   <w.rf>
    <LM>w#w-d1t1000-15</LM>
   </w.rf>
   <form>Napravo</form>
   <lemma>napravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-16">
   <w.rf>
    <LM>w#w-d1t1000-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-17">
   <w.rf>
    <LM>w#w-d1t1000-17</LM>
   </w.rf>
   <form>přítel</form>
   <lemma>přítel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d1t1000-18">
   <w.rf>
    <LM>w#w-d1t1000-18</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m109-d1t1000-19">
   <w.rf>
    <LM>w#w-d1t1000-19</LM>
   </w.rf>
   <form>matky</form>
   <lemma>matka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-713-714">
   <w.rf>
    <LM>w#w-713-714</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-715">
  <m id="m109-d1t1000-21">
   <w.rf>
    <LM>w#w-d1t1000-21</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1000-22">
   <w.rf>
    <LM>w#w-d1t1000-22</LM>
   </w.rf>
   <form>vnuka</form>
   <lemma>vnuk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m109-d1t1000-23">
   <w.rf>
    <LM>w#w-d1t1000-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-24">
   <w.rf>
    <LM>w#w-d1t1000-24</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m109-d1t1000-25">
   <w.rf>
    <LM>w#w-d1t1000-25</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-715-716">
   <w.rf>
    <LM>w#w-715-716</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1000-26">
   <w.rf>
    <LM>w#w-d1t1000-26</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m109-d1t1000-27">
   <w.rf>
    <LM>w#w-d1t1000-27</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1000-28">
   <w.rf>
    <LM>w#w-d1t1000-28</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1000-29">
   <w.rf>
    <LM>w#w-d1t1000-29</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-30">
   <w.rf>
    <LM>w#w-d1t1000-30</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-31">
   <w.rf>
    <LM>w#w-d1t1000-31</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1000-32">
   <w.rf>
    <LM>w#w-d1t1000-32</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m109-d1t1000-33">
   <w.rf>
    <LM>w#w-d1t1000-33</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t1000-34">
   <w.rf>
    <LM>w#w-d1t1000-34</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-35">
   <w.rf>
    <LM>w#w-d1t1000-35</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m109-d1t1000-36">
   <w.rf>
    <LM>w#w-d1t1000-36</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m109-d-id118643-punct">
   <w.rf>
    <LM>w#w-d-id118643-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1000-40">
   <w.rf>
    <LM>w#w-d1t1000-40</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m109-d1t1000-41">
   <w.rf>
    <LM>w#w-d1t1000-41</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-42">
   <w.rf>
    <LM>w#w-d1t1000-42</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-43">
   <w.rf>
    <LM>w#w-d1t1000-43</LM>
   </w.rf>
   <form>filozofickou</form>
   <lemma>filozofický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m109-d1t1000-44">
   <w.rf>
    <LM>w#w-d1t1000-44</LM>
   </w.rf>
   <form>fakultu</form>
   <lemma>fakulta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-715-729">
   <w.rf>
    <LM>w#w-715-729</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-730">
  <m id="m109-d1t1000-46">
   <w.rf>
    <LM>w#w-d1t1000-46</LM>
   </w.rf>
   <form>Žijou</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1000-47">
   <w.rf>
    <LM>w#w-d1t1000-47</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-48">
   <w.rf>
    <LM>w#w-d1t1000-48</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1000-49">
   <w.rf>
    <LM>w#w-d1t1000-49</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1000-51">
   <w.rf>
    <LM>w#w-d1t1000-51</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d-m-d1e989-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e989-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1001-x2">
  <m id="m109-d1t1004-1">
   <w.rf>
    <LM>w#w-d1t1004-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t1004-2">
   <w.rf>
    <LM>w#w-d1t1004-2</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m109-d1t1004-3">
   <w.rf>
    <LM>w#w-d1t1004-3</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d1t1004-4">
   <w.rf>
    <LM>w#w-d1t1004-4</LM>
   </w.rf>
   <form>vystudoval</form>
   <lemma>vystudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d-id118986-punct">
   <w.rf>
    <LM>w#w-d-id118986-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1005-x2">
  <m id="m109-d1t1008-1">
   <w.rf>
    <LM>w#w-d1t1008-1</LM>
   </w.rf>
   <form>Vystudoval</form>
   <lemma>vystudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t1008-2">
   <w.rf>
    <LM>w#w-d1t1008-2</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m109-d1e1005-x2-744">
   <w.rf>
    <LM>w#w-d1e1005-x2-744</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1e1005-x2-745">
   <w.rf>
    <LM>w#w-d1e1005-x2-745</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1e1005-x2-746">
   <w.rf>
    <LM>w#w-d1e1005-x2-746</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-747">
  <m id="m109-d1t1010-2">
   <w.rf>
    <LM>w#w-d1t1010-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1010-1">
   <w.rf>
    <LM>w#w-d1t1010-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m109-d1t1010-3">
   <w.rf>
    <LM>w#w-d1t1010-3</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m109-d-id119134-punct">
   <w.rf>
    <LM>w#w-d-id119134-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1010-5">
   <w.rf>
    <LM>w#w-d1t1010-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1010-6">
   <w.rf>
    <LM>w#w-d1t1010-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1010-8">
   <w.rf>
    <LM>w#w-d1t1010-8</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m109-d1e1005-x2-738">
   <w.rf>
    <LM>w#w-d1e1005-x2-738</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-739">
  <m id="m109-d1t1014-1">
   <w.rf>
    <LM>w#w-d1t1014-1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1014-2">
   <w.rf>
    <LM>w#w-d1t1014-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1014-5">
   <w.rf>
    <LM>w#w-d1t1014-5</LM>
   </w.rf>
   <form>moderní</form>
   <lemma>moderní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m109-d1t1014-4">
   <w.rf>
    <LM>w#w-d1t1014-4</LM>
   </w.rf>
   <form>multimedia</form>
   <lemma>multimedium_,s_^(^DD**multimédium)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m109-739-740">
   <w.rf>
    <LM>w#w-739-740</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1014-7">
   <w.rf>
    <LM>w#w-d1t1014-7</LM>
   </w.rf>
   <form>televize</form>
   <lemma>televize</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m109-d-id119330-punct">
   <w.rf>
    <LM>w#w-d-id119330-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1014-9">
   <w.rf>
    <LM>w#w-d1t1014-9</LM>
   </w.rf>
   <form>film</form>
   <lemma>film</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m109-739-741">
   <w.rf>
    <LM>w#w-739-741</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AANP1----1A---6</tag>
  </m>
  <m id="m109-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m109-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>informatikou</form>
   <lemma>informatika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m109-739-742">
   <w.rf>
    <LM>w#w-739-742</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-743">
  <m id="m109-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>Základem</form>
   <lemma>základ</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m109-d1t1021-3">
   <w.rf>
    <LM>w#w-d1t1021-3</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m109-d1t1021-4">
   <w.rf>
    <LM>w#w-d1t1021-4</LM>
   </w.rf>
   <form>studia</form>
   <lemma>studio</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m109-d1t1021-5">
   <w.rf>
    <LM>w#w-d1t1021-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1021-6">
   <w.rf>
    <LM>w#w-d1t1021-6</LM>
   </w.rf>
   <form>knihovnictví</form>
   <lemma>knihovnictví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m109-743-752">
   <w.rf>
    <LM>w#w-743-752</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-753">
  <m id="m109-d1t1025-2">
   <w.rf>
    <LM>w#w-d1t1025-2</LM>
   </w.rf>
   <form>Dosáhl</form>
   <lemma>dosáhnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t1025-1">
   <w.rf>
    <LM>w#w-d1t1025-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1025-4">
   <w.rf>
    <LM>w#w-d1t1025-4</LM>
   </w.rf>
   <form>bakaláře</form>
   <lemma>bakalář</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m109-d1t1025-5">
   <w.rf>
    <LM>w#w-d1t1025-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1025-7">
   <w.rf>
    <LM>w#w-d1t1025-7</LM>
   </w.rf>
   <form>pokračoval</form>
   <lemma>pokračovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1025-8">
   <w.rf>
    <LM>w#w-d1t1025-8</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1025-10">
   <w.rf>
    <LM>w#w-d1t1025-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1025-11">
   <w.rf>
    <LM>w#w-d1t1025-11</LM>
   </w.rf>
   <form>magistra</form>
   <lemma>magistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m109-753-739">
   <w.rf>
    <LM>w#w-753-739</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-740">
  <m id="m109-d1t1025-15">
   <w.rf>
    <LM>w#w-d1t1025-15</LM>
   </w.rf>
   <form>Zvolil</form>
   <lemma>zvolit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t1025-14">
   <w.rf>
    <LM>w#w-d1t1025-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m109-d1t1027-1">
   <w.rf>
    <LM>w#w-d1t1027-1</LM>
   </w.rf>
   <form>tenhleten</form>
   <lemma>tenhleten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m109-753-754">
   <w.rf>
    <LM>w#w-753-754</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1029-2">
   <w.rf>
    <LM>w#w-d1t1029-2</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t1029-1">
   <w.rf>
    <LM>w#w-d1t1029-1</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m109-753-755">
   <w.rf>
    <LM>w#w-753-755</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1029-3">
   <w.rf>
    <LM>w#w-d1t1029-3</LM>
   </w.rf>
   <form>supermoderní</form>
   <lemma>supermoderní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m109-d1t1029-4">
   <w.rf>
    <LM>w#w-d1t1029-4</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m109-d-id119904-punct">
   <w.rf>
    <LM>w#w-d-id119904-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1029-6">
   <w.rf>
    <LM>w#w-d1t1029-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m109-d1t1029-7">
   <w.rf>
    <LM>w#w-d1t1029-7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1029-8">
   <w.rf>
    <LM>w#w-d1t1029-8</LM>
   </w.rf>
   <form>uplatnění</form>
   <lemma>uplatnění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m109-d1t1029-9">
   <w.rf>
    <LM>w#w-d1t1029-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m109-d1t1029-10">
   <w.rf>
    <LM>w#w-d1t1029-10</LM>
   </w.rf>
   <form>všech</form>
   <lemma>všechen</lemma>
   <tag>PLXP6----------</tag>
  </m>
  <m id="m109-d1t1029-13">
   <w.rf>
    <LM>w#w-d1t1029-13</LM>
   </w.rf>
   <form>současných</form>
   <lemma>současný</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m109-d1t1029-12">
   <w.rf>
    <LM>w#w-d1t1029-12</LM>
   </w.rf>
   <form>médiích</form>
   <lemma>médium</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m109-d-m-d1e1005-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1005-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1036-x2">
  <m id="m109-d1t1039-1">
   <w.rf>
    <LM>w#w-d1t1039-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t1039-2">
   <w.rf>
    <LM>w#w-d1t1039-2</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1039-3">
   <w.rf>
    <LM>w#w-d1t1039-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d-id120137-punct">
   <w.rf>
    <LM>w#w-d-id120137-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1040-x2">
  <m id="m109-d1t1043-1">
   <w.rf>
    <LM>w#w-d1t1043-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>pracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1043-3">
   <w.rf>
    <LM>w#w-d1t1043-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1045-1">
   <w.rf>
    <LM>w#w-d1t1045-1</LM>
   </w.rf>
   <form>novinář</form>
   <lemma>novinář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d1t1045-2">
   <w.rf>
    <LM>w#w-d1t1045-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1045-3">
   <w.rf>
    <LM>w#w-d1t1045-3</LM>
   </w.rf>
   <form>ČTK</form>
   <lemma>ČTK_;m_^(Čs./Česká_tisková_kancelář)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m109-d1e1040-x2-760">
   <w.rf>
    <LM>w#w-d1e1040-x2-760</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1047-8">
   <w.rf>
    <LM>w#w-d1t1047-8</LM>
   </w.rf>
   <form>České</form>
   <lemma>český</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m109-d1t1047-9">
   <w.rf>
    <LM>w#w-d1t1047-9</LM>
   </w.rf>
   <form>tiskové</form>
   <lemma>tiskový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m109-d1t1047-10">
   <w.rf>
    <LM>w#w-d1t1047-10</LM>
   </w.rf>
   <form>kanceláři</form>
   <lemma>kancelář</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1e1040-x2-761">
   <w.rf>
    <LM>w#w-d1e1040-x2-761</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d-m-d1e1040-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1040-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1048-x2">
  <m id="m109-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m109-d1t1051-4">
   <w.rf>
    <LM>w#w-d1t1051-4</LM>
   </w.rf>
   <form>studoval</form>
   <lemma>studovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1051-5">
   <w.rf>
    <LM>w#w-d1t1051-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1051-6">
   <w.rf>
    <LM>w#w-d1t1051-6</LM>
   </w.rf>
   <form>mlada</form>
   <lemma>mlada</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m109-d1t1051-7">
   <w.rf>
    <LM>w#w-d1t1051-7</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m109-d-id120614-punct">
   <w.rf>
    <LM>w#w-d-id120614-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1052-x2">
  <m id="m109-d1t1055-3">
   <w.rf>
    <LM>w#w-d1t1055-3</LM>
   </w.rf>
   <form>Vystudoval</form>
   <lemma>vystudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m109-d1t1055-2">
   <w.rf>
    <LM>w#w-d1t1055-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1055-4">
   <w.rf>
    <LM>w#w-d1t1055-4</LM>
   </w.rf>
   <form>spojovací</form>
   <lemma>spojovací_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m109-d1t1055-5">
   <w.rf>
    <LM>w#w-d1t1055-5</LM>
   </w.rf>
   <form>obor</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m109-d-m-d1e1052-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1052-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1062-x2">
  <m id="m109-d1t1065-2">
   <w.rf>
    <LM>w#w-d1t1065-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t1065-3">
   <w.rf>
    <LM>w#w-d1t1065-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m109-d1t1065-4">
   <w.rf>
    <LM>w#w-d1t1065-4</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1065-5">
   <w.rf>
    <LM>w#w-d1t1065-5</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d-id120884-punct">
   <w.rf>
    <LM>w#w-d-id120884-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1066-x2">
  <m id="m109-d1t1071-1">
   <w.rf>
    <LM>w#w-d1t1071-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1071-2">
   <w.rf>
    <LM>w#w-d1t1071-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1071-3">
   <w.rf>
    <LM>w#w-d1t1071-3</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1071-7">
   <w.rf>
    <LM>w#w-d1t1071-7</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m109-d1t1071-8">
   <w.rf>
    <LM>w#w-d1t1071-8</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m109-d1t1071-4">
   <w.rf>
    <LM>w#w-d1t1071-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1071-5">
   <w.rf>
    <LM>w#w-d1t1071-5</LM>
   </w.rf>
   <form>armádě</form>
   <lemma>armáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d-m-d1e1066-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1066-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1072-x2">
  <m id="m109-d1t1075-1">
   <w.rf>
    <LM>w#w-d1t1075-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m109-d1e1072-x2-768">
   <w.rf>
    <LM>w#w-d1e1072-x2-768</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-769">
  <m id="m109-d1t1077-2">
   <w.rf>
    <LM>w#w-d1t1077-2</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1077-3">
   <w.rf>
    <LM>w#w-d1t1077-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1077-4">
   <w.rf>
    <LM>w#w-d1t1077-4</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m109-d1t1077-5">
   <w.rf>
    <LM>w#w-d1t1077-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id121233-punct">
   <w.rf>
    <LM>w#w-d-id121233-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1078-x2">
  <m id="m109-d1t1081-3">
   <w.rf>
    <LM>w#w-d1t1081-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1081-2">
   <w.rf>
    <LM>w#w-d1t1081-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1081-4">
   <w.rf>
    <LM>w#w-d1t1081-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1081-5">
   <w.rf>
    <LM>w#w-d1t1081-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1081-6">
   <w.rf>
    <LM>w#w-d1t1081-6</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS2-P1-------</tag>
  </m>
  <m id="m109-d1t1081-7">
   <w.rf>
    <LM>w#w-d1t1081-7</LM>
   </w.rf>
   <form>chalupy</form>
   <lemma>chalupa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d1e1078-x2-776">
   <w.rf>
    <LM>w#w-d1e1078-x2-776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-777">
  <m id="m109-d1t1083-1">
   <w.rf>
    <LM>w#w-d1t1083-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1083-2">
   <w.rf>
    <LM>w#w-d1t1083-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1083-3">
   <w.rf>
    <LM>w#w-d1t1083-3</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1083-4">
   <w.rf>
    <LM>w#w-d1t1083-4</LM>
   </w.rf>
   <form>pozemku</form>
   <lemma>pozemek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m109-d-id121480-punct">
   <w.rf>
    <LM>w#w-d-id121480-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1083-6">
   <w.rf>
    <LM>w#w-d1t1083-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1083-7">
   <w.rf>
    <LM>w#w-d1t1083-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1083-8">
   <w.rf>
    <LM>w#w-d1t1083-8</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m109-d1t1083-9">
   <w.rf>
    <LM>w#w-d1t1083-9</LM>
   </w.rf>
   <form>chalupa</form>
   <lemma>chalupa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1083-10">
   <w.rf>
    <LM>w#w-d1t1083-10</LM>
   </w.rf>
   <form>nachází</form>
   <lemma>nacházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-777-778">
   <w.rf>
    <LM>w#w-777-778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-779">
  <m id="m109-d1t1087-1">
   <w.rf>
    <LM>w#w-d1t1087-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1087-2">
   <w.rf>
    <LM>w#w-d1t1087-2</LM>
   </w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m109-d1t1087-3">
   <w.rf>
    <LM>w#w-d1t1087-3</LM>
   </w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t1087-4">
   <w.rf>
    <LM>w#w-d1t1087-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m109-d1t1087-5">
   <w.rf>
    <LM>w#w-d1t1087-5</LM>
   </w.rf>
   <form>stromem</form>
   <lemma>strom</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m109-d1t1087-6">
   <w.rf>
    <LM>w#w-d1t1087-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1087-7">
   <w.rf>
    <LM>w#w-d1t1087-7</LM>
   </w.rf>
   <form>schody</form>
   <lemma>schod</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m109-d-id121699-punct">
   <w.rf>
    <LM>w#w-d-id121699-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1087-9">
   <w.rf>
    <LM>w#w-d1t1087-9</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m109-d1t1087-10">
   <w.rf>
    <LM>w#w-d1t1087-10</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1087-11">
   <w.rf>
    <LM>w#w-d1t1087-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1087-12">
   <w.rf>
    <LM>w#w-d1t1087-12</LM>
   </w.rf>
   <form>horní</form>
   <lemma>horní-1_^(vrchní)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m109-d1t1087-13">
   <w.rf>
    <LM>w#w-d1t1087-13</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d1t1087-14">
   <w.rf>
    <LM>w#w-d1t1087-14</LM>
   </w.rf>
   <form>zahrady</form>
   <lemma>zahrada</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d-id121801-punct">
   <w.rf>
    <LM>w#w-d-id121801-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1087-16">
   <w.rf>
    <LM>w#w-d1t1087-16</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1087-17">
   <w.rf>
    <LM>w#w-d1t1087-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1089-1">
   <w.rf>
    <LM>w#w-d1t1089-1</LM>
   </w.rf>
   <form>většina</form>
   <lemma>většina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1089-2">
   <w.rf>
    <LM>w#w-d1t1089-2</LM>
   </w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m109-779-780">
   <w.rf>
    <LM>w#w-779-780</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-781">
  <m id="m109-d1t1092-1">
   <w.rf>
    <LM>w#w-d1t1092-1</LM>
   </w.rf>
   <form>Celkově</form>
   <lemma>celkově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m109-d1t1092-2">
   <w.rf>
    <LM>w#w-d1t1092-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1092-3">
   <w.rf>
    <LM>w#w-d1t1092-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1092-5">
   <w.rf>
    <LM>w#w-d1t1092-5</LM>
   </w.rf>
   <form>pozemku</form>
   <lemma>pozemek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m109-d1t1092-6">
   <w.rf>
    <LM>w#w-d1t1092-6</LM>
   </w.rf>
   <form>chalupy</form>
   <lemma>chalupa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d1t1092-7">
   <w.rf>
    <LM>w#w-d1t1092-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m109-d1t1092-8">
   <w.rf>
    <LM>w#w-d1t1092-8</LM>
   </w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m109-d1t1092-9">
   <w.rf>
    <LM>w#w-d1t1092-9</LM>
   </w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m109-781-782">
   <w.rf>
    <LM>w#w-781-782</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-783">
  <m id="m109-d1t1092-11">
   <w.rf>
    <LM>w#w-d1t1092-11</LM>
   </w.rf>
   <form>Převážná</form>
   <lemma>převážný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-d1t1092-12">
   <w.rf>
    <LM>w#w-d1t1092-12</LM>
   </w.rf>
   <form>většina</form>
   <lemma>většina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1092-13">
   <w.rf>
    <LM>w#w-d1t1092-13</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1092-14">
   <w.rf>
    <LM>w#w-d1t1092-14</LM>
   </w.rf>
   <form>jabloně</form>
   <lemma>jabloň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m109-783-785">
   <w.rf>
    <LM>w#w-783-785</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-786">
  <m id="m109-d1t1094-1">
   <w.rf>
    <LM>w#w-d1t1094-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1094-2">
   <w.rf>
    <LM>w#w-d1t1094-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1094-3">
   <w.rf>
    <LM>w#w-d1t1094-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1094-4">
   <w.rf>
    <LM>w#w-d1t1094-4</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m109-d1t1094-5">
   <w.rf>
    <LM>w#w-d1t1094-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1094-6">
   <w.rf>
    <LM>w#w-d1t1094-6</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m109-d1t1094-7">
   <w.rf>
    <LM>w#w-d1t1094-7</LM>
   </w.rf>
   <form>stromů</form>
   <lemma>strom</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m109-d1t1094-8">
   <w.rf>
    <LM>w#w-d1t1094-8</LM>
   </w.rf>
   <form>sliv</form>
   <lemma>slíva</lemma>
   <tag>NNFP2-----A---1</tag>
  </m>
  <m id="m109-786-787">
   <w.rf>
    <LM>w#w-786-787</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-788">
  <m id="m109-d1t1094-10">
   <w.rf>
    <LM>w#w-d1t1094-10</LM>
   </w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m109-d1t1094-11">
   <w.rf>
    <LM>w#w-d1t1094-11</LM>
   </w.rf>
   <form>slíva</form>
   <lemma>slíva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1094-12">
   <w.rf>
    <LM>w#w-d1t1094-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1094-14">
   <w.rf>
    <LM>w#w-d1t1094-14</LM>
   </w.rf>
   <form>vyfocená</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-d1t1094-15">
   <w.rf>
    <LM>w#w-d1t1094-15</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m109-d1t1094-16">
   <w.rf>
    <LM>w#w-d1t1094-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1094-17">
   <w.rf>
    <LM>w#w-d1t1094-17</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m109-d1t1094-18">
   <w.rf>
    <LM>w#w-d1t1094-18</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-788-789">
   <w.rf>
    <LM>w#w-788-789</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-790">
  <m id="m109-d1t1096-3">
   <w.rf>
    <LM>w#w-d1t1096-3</LM>
   </w.rf>
   <form>Trávník</form>
   <lemma>trávník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m109-d-id122456-punct">
   <w.rf>
    <LM>w#w-d-id122456-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1096-5">
   <w.rf>
    <LM>w#w-d1t1096-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1096-6">
   <w.rf>
    <LM>w#w-d1t1096-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1096-8">
   <w.rf>
    <LM>w#w-d1t1096-8</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m109-d1t1096-9">
   <w.rf>
    <LM>w#w-d1t1096-9</LM>
   </w.rf>
   <form>slíva</form>
   <lemma>slíva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1096-10">
   <w.rf>
    <LM>w#w-d1t1096-10</LM>
   </w.rf>
   <form>používáme</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1096-11">
   <w.rf>
    <LM>w#w-d1t1096-11</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1096-12">
   <w.rf>
    <LM>w#w-d1t1096-12</LM>
   </w.rf>
   <form>okrasný</form>
   <lemma>okrasný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m109-d-id122588-punct">
   <w.rf>
    <LM>w#w-d-id122588-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1096-14">
   <w.rf>
    <LM>w#w-d1t1096-14</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1096-15">
   <w.rf>
    <LM>w#w-d1t1096-15</LM>
   </w.rf>
   <form>ozdobný</form>
   <lemma>ozdobný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m109-790-802">
   <w.rf>
    <LM>w#w-790-802</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-803">
  <m id="m109-d1t1098-1">
   <w.rf>
    <LM>w#w-d1t1098-1</LM>
   </w.rf>
   <form>Kolem</form>
   <lemma>kolem-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1100-1">
   <w.rf>
    <LM>w#w-d1t1100-1</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1100-3">
   <w.rf>
    <LM>w#w-d1t1100-3</LM>
   </w.rf>
   <form>barevné</form>
   <lemma>barevný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m109-d1t1100-4">
   <w.rf>
    <LM>w#w-d1t1100-4</LM>
   </w.rf>
   <form>polštáře</form>
   <lemma>polštář</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m109-d1t1100-6">
   <w.rf>
    <LM>w#w-d1t1100-6</LM>
   </w.rf>
   <form>krásných</form>
   <lemma>krásný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m109-d1t1100-7">
   <w.rf>
    <LM>w#w-d1t1100-7</LM>
   </w.rf>
   <form>kytek</form>
   <lemma>kytka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m109-d-id122777-punct">
   <w.rf>
    <LM>w#w-d-id122777-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1100-9">
   <w.rf>
    <LM>w#w-d1t1100-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m109-d1t1100-10">
   <w.rf>
    <LM>w#w-d1t1100-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m109-d1t1100-11">
   <w.rf>
    <LM>w#w-d1t1100-11</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m109-d1t1100-12">
   <w.rf>
    <LM>w#w-d1t1100-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1100-13">
   <w.rf>
    <LM>w#w-d1t1100-13</LM>
   </w.rf>
   <form>skalce</form>
   <lemma>skalka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-803-804">
   <w.rf>
    <LM>w#w-803-804</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-805">
  <m id="m109-d1t1100-15">
   <w.rf>
    <LM>w#w-d1t1100-15</LM>
   </w.rf>
   <form>Vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1100-16">
   <w.rf>
    <LM>w#w-d1t1100-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1100-17">
   <w.rf>
    <LM>w#w-d1t1100-17</LM>
   </w.rf>
   <form>hezký</form>
   <lemma>hezký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m109-d1t1100-18">
   <w.rf>
    <LM>w#w-d1t1100-18</LM>
   </w.rf>
   <form>bílý</form>
   <lemma>bílý_;o</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m109-d1t1100-19">
   <w.rf>
    <LM>w#w-d1t1100-19</LM>
   </w.rf>
   <form>rododendron</form>
   <lemma>rododendron</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m109-805-806">
   <w.rf>
    <LM>w#w-805-806</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-807">
  <m id="m109-d1t1105-2">
   <w.rf>
    <LM>w#w-d1t1105-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1105-3">
   <w.rf>
    <LM>w#w-d1t1105-3</LM>
   </w.rf>
   <form>pozadí</form>
   <lemma>pozadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m109-d1t1105-4">
   <w.rf>
    <LM>w#w-d1t1105-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1107-1">
   <w.rf>
    <LM>w#w-d1t1107-1</LM>
   </w.rf>
   <form>přístavba</form>
   <lemma>přístavba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id123059-punct">
   <w.rf>
    <LM>w#w-d-id123059-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1107-3">
   <w.rf>
    <LM>w#w-d1t1107-3</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m109-d1t1107-4">
   <w.rf>
    <LM>w#w-d1t1107-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m109-d1t1107-6">
   <w.rf>
    <LM>w#w-d1t1107-6</LM>
   </w.rf>
   <form>součástí</form>
   <lemma>součást</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m109-d1t1107-7">
   <w.rf>
    <LM>w#w-d1t1107-7</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m109-807-778">
   <w.rf>
    <LM>w#w-807-778</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-780">
  <m id="m109-d1t1109-4">
   <w.rf>
    <LM>w#w-d1t1109-4</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1109-5">
   <w.rf>
    <LM>w#w-d1t1109-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1109-9">
   <w.rf>
    <LM>w#w-d1t1109-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1109-10">
   <w.rf>
    <LM>w#w-d1t1109-10</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t1109-6">
   <w.rf>
    <LM>w#w-d1t1109-6</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m109-d1t1109-8">
   <w.rf>
    <LM>w#w-d1t1109-8</LM>
   </w.rf>
   <form>stavby</form>
   <lemma>stavba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m109-d-id123318-punct">
   <w.rf>
    <LM>w#w-d-id123318-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1109-12">
   <w.rf>
    <LM>w#w-d1t1109-12</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m109-d1t1109-13">
   <w.rf>
    <LM>w#w-d1t1109-13</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1109-14">
   <w.rf>
    <LM>w#w-d1t1109-14</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m109-d1t1109-15">
   <w.rf>
    <LM>w#w-d1t1109-15</LM>
   </w.rf>
   <form>patro</form>
   <lemma>patro</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m109-807-808">
   <w.rf>
    <LM>w#w-807-808</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-809">
  <m id="m109-d1t1111-1">
   <w.rf>
    <LM>w#w-d1t1111-1</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d-id123420-punct">
   <w.rf>
    <LM>w#w-d-id123420-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1111-3">
   <w.rf>
    <LM>w#w-d1t1111-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m109-d1t1111-4">
   <w.rf>
    <LM>w#w-d1t1111-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1111-6">
   <w.rf>
    <LM>w#w-d1t1111-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m109-d1t1111-7">
   <w.rf>
    <LM>w#w-d1t1111-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1111-8">
   <w.rf>
    <LM>w#w-d1t1111-8</LM>
   </w.rf>
   <form>obrázku</form>
   <lemma>obrázek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m109-d-id123521-punct">
   <w.rf>
    <LM>w#w-d-id123521-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1111-10">
   <w.rf>
    <LM>w#w-d1t1111-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1111-17">
   <w.rf>
    <LM>w#w-d1t1111-17</LM>
   </w.rf>
   <form>zámečnická</form>
   <lemma>zámečnický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-d1t1111-18">
   <w.rf>
    <LM>w#w-d1t1111-18</LM>
   </w.rf>
   <form>dílna</form>
   <lemma>dílna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-809-831">
   <w.rf>
    <LM>w#w-809-831</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-830">
  <m id="m109-d1t1115-2">
   <w.rf>
    <LM>w#w-d1t1115-2</LM>
   </w.rf>
   <form>Nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1115-3">
   <w.rf>
    <LM>w#w-d1t1115-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1115-4">
   <w.rf>
    <LM>w#w-d1t1115-4</LM>
   </w.rf>
   <form>nadstavbě</form>
   <lemma>nadstavba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m109-d1t1115-5">
   <w.rf>
    <LM>w#w-d1t1115-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-830-842">
   <w.rf>
    <LM>w#w-830-842</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-6">
   <w.rf>
    <LM>w#w-d1t1115-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1115-7">
   <w.rf>
    <LM>w#w-d1t1115-7</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m109-d1t1115-8">
   <w.rf>
    <LM>w#w-d1t1115-8</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m109-830-843">
   <w.rf>
    <LM>w#w-830-843</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-9">
   <w.rf>
    <LM>w#w-d1t1115-9</LM>
   </w.rf>
   <form>luxusní</form>
   <lemma>luxusní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m109-d1t1115-10">
   <w.rf>
    <LM>w#w-d1t1115-10</LM>
   </w.rf>
   <form>chlívky</form>
   <lemma>chlívek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m109-d-id123842-punct">
   <w.rf>
    <LM>w#w-d-id123842-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-12">
   <w.rf>
    <LM>w#w-d1t1115-12</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m109-d1t1115-13">
   <w.rf>
    <LM>w#w-d1t1115-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1115-14">
   <w.rf>
    <LM>w#w-d1t1115-14</LM>
   </w.rf>
   <form>dají</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m109-d1t1115-15">
   <w.rf>
    <LM>w#w-d1t1115-15</LM>
   </w.rf>
   <form>používat</form>
   <lemma>používat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m109-d1t1115-16">
   <w.rf>
    <LM>w#w-d1t1115-16</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1115-17">
   <w.rf>
    <LM>w#w-d1t1115-17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1115-18">
   <w.rf>
    <LM>w#w-d1t1115-18</LM>
   </w.rf>
   <form>obytné</form>
   <lemma>obytný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m109-d1t1115-19">
   <w.rf>
    <LM>w#w-d1t1115-19</LM>
   </w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m109-830-791">
   <w.rf>
    <LM>w#w-830-791</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-792">
  <m id="m109-d1t1115-22">
   <w.rf>
    <LM>w#w-d1t1115-22</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m109-d1t1115-24">
   <w.rf>
    <LM>w#w-d1t1115-24</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m109-d1t1115-28">
   <w.rf>
    <LM>w#w-d1t1115-28</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1115-25">
   <w.rf>
    <LM>w#w-d1t1115-25</LM>
   </w.rf>
   <form>bývalý</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m109-d1t1115-26">
   <w.rf>
    <LM>w#w-d1t1115-26</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d1t1115-27">
   <w.rf>
    <LM>w#w-d1t1115-27</LM>
   </w.rf>
   <form>manželky</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-d-id124108-punct">
   <w.rf>
    <LM>w#w-d-id124108-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-30">
   <w.rf>
    <LM>w#w-d1t1115-30</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1115-32">
   <w.rf>
    <LM>w#w-d1t1115-32</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1115-34">
   <w.rf>
    <LM>w#w-d1t1115-34</LM>
   </w.rf>
   <form>švec</form>
   <lemma>švec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m109-d-id124194-punct">
   <w.rf>
    <LM>w#w-d-id124194-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-39">
   <w.rf>
    <LM>w#w-d1t1115-39</LM>
   </w.rf>
   <form>dílnu</form>
   <lemma>dílna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d-id124265-punct">
   <w.rf>
    <LM>w#w-d-id124265-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1115-41">
   <w.rf>
    <LM>w#w-d1t1115-41</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1115-44">
   <w.rf>
    <LM>w#w-d1t1115-44</LM>
   </w.rf>
   <form>vyráběl</form>
   <lemma>vyrábět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-830-844">
   <w.rf>
    <LM>w#w-830-844</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1115-47">
   <w.rf>
    <LM>w#w-d1t1115-47</LM>
   </w.rf>
   <form>opravoval</form>
   <lemma>opravovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m109-d1t1115-48">
   <w.rf>
    <LM>w#w-d1t1115-48</LM>
   </w.rf>
   <form>boty</form>
   <lemma>bota</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m109-830-845">
   <w.rf>
    <LM>w#w-830-845</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-846">
  <m id="m109-d1t1118-5">
   <w.rf>
    <LM>w#w-d1t1118-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1118-6">
   <w.rf>
    <LM>w#w-d1t1118-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1118-7">
   <w.rf>
    <LM>w#w-d1t1118-7</LM>
   </w.rf>
   <form>prostorné</form>
   <lemma>prostorný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m109-846-847">
   <w.rf>
    <LM>w#w-846-847</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-848">
  <m id="m109-d1t1120-2">
   <w.rf>
    <LM>w#w-d1t1120-2</LM>
   </w.rf>
   <form>Ostatním</form>
   <lemma>ostatní</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m109-d1t1120-4">
   <w.rf>
    <LM>w#w-d1t1120-4</LM>
   </w.rf>
   <form>částem</form>
   <lemma>část</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m109-d1t1120-7">
   <w.rf>
    <LM>w#w-d1t1120-7</LM>
   </w.rf>
   <form>říkáme</form>
   <lemma>říkat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1120-8">
   <w.rf>
    <LM>w#w-d1t1120-8</LM>
   </w.rf>
   <form>pila</form>
   <lemma>pila</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-848-849">
   <w.rf>
    <LM>w#w-848-849</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-850">
  <m id="m109-d1t1120-11">
   <w.rf>
    <LM>w#w-d1t1120-11</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1120-10">
   <w.rf>
    <LM>w#w-d1t1120-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1120-12">
   <w.rf>
    <LM>w#w-d1t1120-12</LM>
   </w.rf>
   <form>obrovská</form>
   <lemma>obrovský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-d1t1120-13">
   <w.rf>
    <LM>w#w-d1t1120-13</LM>
   </w.rf>
   <form>pila</form>
   <lemma>pila</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1120-14">
   <w.rf>
    <LM>w#w-d1t1120-14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m109-d1t1120-16">
   <w.rf>
    <LM>w#w-d1t1120-16</LM>
   </w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m109-850-867">
   <w.rf>
    <LM>w#w-850-867</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1120-18">
   <w.rf>
    <LM>w#w-d1t1120-18</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1120-19">
   <w.rf>
    <LM>w#w-d1t1120-19</LM>
   </w.rf>
   <form>lodním</form>
   <lemma>lodní</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m109-d1t1120-17">
   <w.rf>
    <LM>w#w-d1t1120-17</LM>
   </w.rf>
   <form>motorem</form>
   <lemma>motor</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m109-850-868">
   <w.rf>
    <LM>w#w-850-868</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-869">
  <m id="m109-d1t1120-21">
   <w.rf>
    <LM>w#w-d1t1120-21</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1120-22">
   <w.rf>
    <LM>w#w-d1t1120-22</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1120-23">
   <w.rf>
    <LM>w#w-d1t1120-23</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1120-24">
   <w.rf>
    <LM>w#w-d1t1120-24</LM>
   </w.rf>
   <form>truhlárna</form>
   <lemma>truhlárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1120-25">
   <w.rf>
    <LM>w#w-d1t1120-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1120-26">
   <w.rf>
    <LM>w#w-d1t1120-26</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m109-d1t1120-27">
   <w.rf>
    <LM>w#w-d1t1120-27</LM>
   </w.rf>
   <form>truhlárnou</form>
   <lemma>truhlárna</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m109-d1t1120-28">
   <w.rf>
    <LM>w#w-d1t1120-28</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1122-1">
   <w.rf>
    <LM>w#w-d1t1122-1</LM>
   </w.rf>
   <form>dřevěná</form>
   <lemma>dřevěný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-d1t1122-2">
   <w.rf>
    <LM>w#w-d1t1122-2</LM>
   </w.rf>
   <form>kůlna</form>
   <lemma>kůlna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id124970-punct">
   <w.rf>
    <LM>w#w-d-id124970-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1122-4">
   <w.rf>
    <LM>w#w-d1t1122-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1122-17">
   <w.rf>
    <LM>w#w-d1t1122-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1122-19">
   <w.rf>
    <LM>w#w-d1t1122-19</LM>
   </w.rf>
   <form>skladují</form>
   <lemma>skladovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1122-20">
   <w.rf>
    <LM>w#w-d1t1122-20</LM>
   </w.rf>
   <form>laťky</form>
   <lemma>laťka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m109-d-id125222-punct">
   <w.rf>
    <LM>w#w-d-id125222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1122-22">
   <w.rf>
    <LM>w#w-d1t1122-22</LM>
   </w.rf>
   <form>prkna</form>
   <lemma>prkno</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m109-d1t1122-23">
   <w.rf>
    <LM>w#w-d1t1122-23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m109-d1t1122-24">
   <w.rf>
    <LM>w#w-d1t1122-24</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m109-d-id125009-punct">
   <w.rf>
    <LM>w#w-d-id125009-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1122-7">
   <w.rf>
    <LM>w#w-d1t1122-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1122-8">
   <w.rf>
    <LM>w#w-d1t1122-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1122-9">
   <w.rf>
    <LM>w#w-d1t1122-9</LM>
   </w.rf>
   <form>suchá</form>
   <lemma>suchý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m109-869-870">
   <w.rf>
    <LM>w#w-869-870</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-871">
  <m id="m109-d1t1122-11">
   <w.rf>
    <LM>w#w-d1t1122-11</LM>
   </w.rf>
   <form>Dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m109-d1t1122-12">
   <w.rf>
    <LM>w#w-d1t1122-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1122-13">
   <w.rf>
    <LM>w#w-d1t1122-13</LM>
   </w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m109-d1t1122-14">
   <w.rf>
    <LM>w#w-d1t1122-14</LM>
   </w.rf>
   <form>střechu</form>
   <lemma>střecha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-871-872">
   <w.rf>
    <LM>w#w-871-872</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-873">
  <m id="m109-d1t1124-2">
   <w.rf>
    <LM>w#w-d1t1124-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1124-3">
   <w.rf>
    <LM>w#w-d1t1124-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1124-4">
   <w.rf>
    <LM>w#w-d1t1124-4</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m109-d1t1124-5">
   <w.rf>
    <LM>w#w-d1t1124-5</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d-id125370-punct">
   <w.rf>
    <LM>w#w-d-id125370-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1124-7">
   <w.rf>
    <LM>w#w-d1t1124-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1124-8">
   <w.rf>
    <LM>w#w-d1t1124-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1124-9">
   <w.rf>
    <LM>w#w-d1t1124-9</LM>
   </w.rf>
   <form>přijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m109-d1t1124-10">
   <w.rf>
    <LM>w#w-d1t1124-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m109-d1t1124-11">
   <w.rf>
    <LM>w#w-d1t1124-11</LM>
   </w.rf>
   <form>domu</form>
   <lemma>dům</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m109-d-m-d1e1078-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1078-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1125-x2">
  <m id="m109-d1t1128-1">
   <w.rf>
    <LM>w#w-d1t1128-1</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m109-d1t1128-2">
   <w.rf>
    <LM>w#w-d1t1128-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1128-3">
   <w.rf>
    <LM>w#w-d1t1128-3</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d1t1128-4">
   <w.rf>
    <LM>w#w-d1t1128-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m109-d-id125571-punct">
   <w.rf>
    <LM>w#w-d-id125571-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-d1e1129-x2">
  <m id="m109-d1t1132-1">
   <w.rf>
    <LM>w#w-d1t1132-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1132-2">
   <w.rf>
    <LM>w#w-d1t1132-2</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d1t1132-3">
   <w.rf>
    <LM>w#w-d1t1132-3</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-4">
   <w.rf>
    <LM>w#w-d1t1132-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m109-d1e1129-x2-886">
   <w.rf>
    <LM>w#w-d1e1129-x2-886</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-887">
  <m id="m109-d1t1132-6">
   <w.rf>
    <LM>w#w-d1t1132-6</LM>
   </w.rf>
   <form>Jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-7">
   <w.rf>
    <LM>w#w-d1t1132-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1132-9">
   <w.rf>
    <LM>w#w-d1t1132-9</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1132-10">
   <w.rf>
    <LM>w#w-d1t1132-10</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m109-d1t1132-11">
   <w.rf>
    <LM>w#w-d1t1132-11</LM>
   </w.rf>
   <form>jara</form>
   <lemma>jaro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m109-d1t1132-12">
   <w.rf>
    <LM>w#w-d1t1132-12</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m109-d1t1132-13">
   <w.rf>
    <LM>w#w-d1t1132-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1132-15">
   <w.rf>
    <LM>w#w-d1t1132-15</LM>
   </w.rf>
   <form>října</form>
   <lemma>říjen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m109-d-id125858-punct">
   <w.rf>
    <LM>w#w-d-id125858-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1132-17">
   <w.rf>
    <LM>w#w-d1t1132-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m109-d1t1132-18">
   <w.rf>
    <LM>w#w-d1t1132-18</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-19">
   <w.rf>
    <LM>w#w-d1t1132-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m109-d1t1132-21">
   <w.rf>
    <LM>w#w-d1t1132-21</LM>
   </w.rf>
   <form>pozdního</form>
   <lemma>pozdní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m109-d1t1132-22">
   <w.rf>
    <LM>w#w-d1t1132-22</LM>
   </w.rf>
   <form>podzimu</form>
   <lemma>podzim</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m109-d-id125960-punct">
   <w.rf>
    <LM>w#w-d-id125960-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1132-24">
   <w.rf>
    <LM>w#w-d1t1132-24</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m109-d1t1132-25">
   <w.rf>
    <LM>w#w-d1t1132-25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-26">
   <w.rf>
    <LM>w#w-d1t1132-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1132-27">
   <w.rf>
    <LM>w#w-d1t1132-27</LM>
   </w.rf>
   <form>plno</form>
   <lemma>plno</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m109-d1t1132-28">
   <w.rf>
    <LM>w#w-d1t1132-28</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m109-887-888">
   <w.rf>
    <LM>w#w-887-888</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-889">
  <m id="m109-d1t1132-30">
   <w.rf>
    <LM>w#w-d1t1132-30</LM>
   </w.rf>
   <form>Staráme</form>
   <lemma>starat_^(se)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-31">
   <w.rf>
    <LM>w#w-d1t1132-31</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1132-32">
   <w.rf>
    <LM>w#w-d1t1132-32</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1132-33">
   <w.rf>
    <LM>w#w-d1t1132-33</LM>
   </w.rf>
   <form>kytky</form>
   <lemma>kytka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m109-889-890">
   <w.rf>
    <LM>w#w-889-890</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m109-891">
  <m id="m109-d1t1132-35">
   <w.rf>
    <LM>w#w-d1t1132-35</LM>
   </w.rf>
   <form>Žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m109-d1t1132-36">
   <w.rf>
    <LM>w#w-d1t1132-36</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m109-d1t1132-37">
   <w.rf>
    <LM>w#w-d1t1132-37</LM>
   </w.rf>
   <form>vysazuje</form>
   <lemma>vysazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-39">
   <w.rf>
    <LM>w#w-d1t1132-39</LM>
   </w.rf>
   <form>zeleninovou</form>
   <lemma>zeleninový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m109-d1t1132-40">
   <w.rf>
    <LM>w#w-d1t1132-40</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m109-d-id126218-punct">
   <w.rf>
    <LM>w#w-d-id126218-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1132-42">
   <w.rf>
    <LM>w#w-d1t1132-42</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-43">
   <w.rf>
    <LM>w#w-d1t1132-43</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1132-44">
   <w.rf>
    <LM>w#w-d1t1132-44</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m109-d1t1132-45">
   <w.rf>
    <LM>w#w-d1t1132-45</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m109-d1t1132-46">
   <w.rf>
    <LM>w#w-d1t1132-46</LM>
   </w.rf>
   <form>starat</form>
   <lemma>starat_^(se)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m109-d-id126304-punct">
   <w.rf>
    <LM>w#w-d-id126304-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m109-d1t1132-48">
   <w.rf>
    <LM>w#w-d1t1132-48</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m109-d1t1132-49">
   <w.rf>
    <LM>w#w-d1t1132-49</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m109-d1t1132-50">
   <w.rf>
    <LM>w#w-d1t1132-50</LM>
   </w.rf>
   <form>zalévat</form>
   <lemma>zalévat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m109-891-893">
   <w.rf>
    <LM>w#w-891-893</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
