<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_009.11.w.gz" />
  </references>
 </head>
 <s id="m009-579">
  <m id="m009-d1t2981-9">
   <w.rf>
    <LM>w#w-d1t2981-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t2981-10">
   <w.rf>
    <LM>w#w-d1t2981-10</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t2981-11">
   <w.rf>
    <LM>w#w-d1t2981-11</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t2981-12">
   <w.rf>
    <LM>w#w-d1t2981-12</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m009-d1t2992-1">
   <w.rf>
    <LM>w#w-d1t2992-1</LM>
   </w.rf>
   <form>1937</form>
   <lemma>1937</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m009-d-id167963">
   <w.rf>
    <LM>w#w-d-id167963</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e2999-x2">
  <m id="m009-d1t3002-1">
   <w.rf>
    <LM>w#w-d1t3002-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3002-2">
   <w.rf>
    <LM>w#w-d1t3002-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3002-3">
   <w.rf>
    <LM>w#w-d1t3002-3</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d-id168266">
   <w.rf>
    <LM>w#w-d-id168266</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3003-x2">
  <m id="m009-d1t3006-1">
   <w.rf>
    <LM>w#w-d1t3006-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3006-2">
   <w.rf>
    <LM>w#w-d1t3006-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3006-3">
   <w.rf>
    <LM>w#w-d1t3006-3</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d-id168413">
   <w.rf>
    <LM>w#w-d-id168413</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3006-5">
   <w.rf>
    <LM>w#w-d1t3006-5</LM>
   </w.rf>
   <form>vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3006-6">
   <w.rf>
    <LM>w#w-d1t3006-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m009-d1t3006-7">
   <w.rf>
    <LM>w#w-d1t3006-7</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d-id168358">
   <w.rf>
    <LM>w#w-d-id168358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3007-x2">
  <m id="m009-d1t3012-1">
   <w.rf>
    <LM>w#w-d1t3012-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3012-2">
   <w.rf>
    <LM>w#w-d1t3012-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3012-4">
   <w.rf>
    <LM>w#w-d1t3012-4</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t3012-5">
   <w.rf>
    <LM>w#w-d1t3012-5</LM>
   </w.rf>
   <form>šedesát</form>
   <lemma>šedesát`60</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m009-d1e3007-x2-676">
   <w.rf>
    <LM>w#w-d1e3007-x2-676</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m009-d-id168503">
   <w.rf>
    <LM>w#w-d-id168503</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3007-x3">
  <m id="m009-d1t3014-1">
   <w.rf>
    <LM>w#w-d1t3014-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t3014-2">
   <w.rf>
    <LM>w#w-d1t3014-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m009-d1t3014-3">
   <w.rf>
    <LM>w#w-d1t3014-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m009-d1t3014-4">
   <w.rf>
    <LM>w#w-d1t3014-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m009-d1t3014-5">
   <w.rf>
    <LM>w#w-d1t3014-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3014-6">
   <w.rf>
    <LM>w#w-d1t3014-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m009-d1t3014-7">
   <w.rf>
    <LM>w#w-d1t3014-7</LM>
   </w.rf>
   <form>dodat</form>
   <lemma>dodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m009-d-id168680">
   <w.rf>
    <LM>w#w-d-id168680</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3015-x2">
  <m id="m009-d1t3018-3">
   <w.rf>
    <LM>w#w-d1t3018-3</LM>
   </w.rf>
   <form>Že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3018-7">
   <w.rf>
    <LM>w#w-d1t3018-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m009-d1e3015-x2-66">
   <w.rf>
    <LM>w#w-d1e3015-x2-66</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m009-d1t3018-6">
   <w.rf>
    <LM>w#w-d1t3018-6</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d1t3018-8">
   <w.rf>
    <LM>w#w-d1t3018-8</LM>
   </w.rf>
   <form>nutí</form>
   <lemma>nutit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3018-9">
   <w.rf>
    <LM>w#w-d1t3018-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m009-d1t3018-10">
   <w.rf>
    <LM>w#w-d1t3018-10</LM>
   </w.rf>
   <form>zamyšlení</form>
   <lemma>zamyšlení_^(*5slit)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m009-d1e3015-x2-764">
   <w.rf>
    <LM>w#w-d1e3015-x2-764</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3018-11">
   <w.rf>
    <LM>w#w-d1t3018-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3020-1">
   <w.rf>
    <LM>w#w-d1t3020-1</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m009-d1t3020-2">
   <w.rf>
    <LM>w#w-d1t3020-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t3020-3">
   <w.rf>
    <LM>w#w-d1t3020-3</LM>
   </w.rf>
   <form>druhém</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m009-d1t3020-4">
   <w.rf>
    <LM>w#w-d1t3020-4</LM>
   </w.rf>
   <form>odcházíme</form>
   <lemma>odcházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3022-1">
   <w.rf>
    <LM>w#w-d1t3022-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t3022-7">
   <w.rf>
    <LM>w#w-d1t3022-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t3022-8">
   <w.rf>
    <LM>w#w-d1t3022-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m009-d1t3022-9">
   <w.rf>
    <LM>w#w-d1t3022-9</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m009-d1t3022-2">
   <w.rf>
    <LM>w#w-d1t3022-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3022-3">
   <w.rf>
    <LM>w#w-d1t3022-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3022-4">
   <w.rf>
    <LM>w#w-d1t3022-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3022-5">
   <w.rf>
    <LM>w#w-d1t3022-5</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3022-6">
   <w.rf>
    <LM>w#w-d1t3022-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3022-12">
   <w.rf>
    <LM>w#w-d1t3022-12</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1e3015-x2-68">
   <w.rf>
    <LM>w#w-d1e3015-x2-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-69">
  <m id="m009-d1t3022-14">
   <w.rf>
    <LM>w#w-d1t3022-14</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3022-15">
   <w.rf>
    <LM>w#w-d1t3022-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3022-16">
   <w.rf>
    <LM>w#w-d1t3022-16</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3022-17">
   <w.rf>
    <LM>w#w-d1t3022-17</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m009-d-id169184">
   <w.rf>
    <LM>w#w-d-id169184</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3022-19">
   <w.rf>
    <LM>w#w-d1t3022-19</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m009-d1t3022-20">
   <w.rf>
    <LM>w#w-d1t3022-20</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m009-d1t3022-21">
   <w.rf>
    <LM>w#w-d1t3022-21</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3022-22">
   <w.rf>
    <LM>w#w-d1t3022-22</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t3022-23">
   <w.rf>
    <LM>w#w-d1t3022-23</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m009-d-id168726">
   <w.rf>
    <LM>w#w-d-id168726</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3029-x2">
  <m id="m009-d1t3032-2">
   <w.rf>
    <LM>w#w-d1t3032-2</LM>
   </w.rf>
   <form>Zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m009-d1t3032-3">
   <w.rf>
    <LM>w#w-d1t3032-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3032-4">
   <w.rf>
    <LM>w#w-d1t3032-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3032-5">
   <w.rf>
    <LM>w#w-d1t3032-5</LM>
   </w.rf>
   <form>slouží</form>
   <lemma>sloužit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d-id169402">
   <w.rf>
    <LM>w#w-d-id169402</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3033-x2">
  <m id="m009-d1t3036-1">
   <w.rf>
    <LM>w#w-d1t3036-1</LM>
   </w.rf>
   <form>Zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m009-d1t3036-5">
   <w.rf>
    <LM>w#w-d1t3036-5</LM>
   </w.rf>
   <form>jakž</form>
   <lemma>jakž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3036-6">
   <w.rf>
    <LM>w#w-d1t3036-6</LM>
   </w.rf>
   <form>takž</form>
   <lemma>takž</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1e3033-x2-160">
   <w.rf>
    <LM>w#w-d1e3033-x2-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-153">
  <m id="m009-d1t3036-13">
   <w.rf>
    <LM>w#w-d1t3036-13</LM>
   </w.rf>
   <form>Nebolí</form>
   <lemma>bolet</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m009-d1t3036-14">
   <w.rf>
    <LM>w#w-d1t3036-14</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m009-d1t3036-15">
   <w.rf>
    <LM>w#w-d1t3036-15</LM>
   </w.rf>
   <form>nohy</form>
   <lemma>noha</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m009-d-id169669">
   <w.rf>
    <LM>w#w-d-id169669</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3038-1">
   <w.rf>
    <LM>w#w-d1t3038-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t3038-2">
   <w.rf>
    <LM>w#w-d1t3038-2</LM>
   </w.rf>
   <form>nechtějí</form>
   <lemma>chtít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m009-d1t3038-3">
   <w.rf>
    <LM>w#w-d1t3038-3</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d-id169448">
   <w.rf>
    <LM>w#w-d-id169448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3039-x2">
  <m id="m009-d1t3044-1">
   <w.rf>
    <LM>w#w-d1t3044-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t3052-1">
   <w.rf>
    <LM>w#w-d1t3052-1</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3052-2">
   <w.rf>
    <LM>w#w-d1t3052-2</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m009-d1t3052-3">
   <w.rf>
    <LM>w#w-d1t3052-3</LM>
   </w.rf>
   <form>problém</form>
   <lemma>problém</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d1e3039-x2-339">
   <w.rf>
    <LM>w#w-d1e3039-x2-339</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3052-4">
   <w.rf>
    <LM>w#w-d1t3052-4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t3052-5">
   <w.rf>
    <LM>w#w-d1t3052-5</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t3052-6">
   <w.rf>
    <LM>w#w-d1t3052-6</LM>
   </w.rf>
   <form>šmakuje</form>
   <lemma>šmakovat_,h</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3052-7">
   <w.rf>
    <LM>w#w-d1t3052-7</LM>
   </w.rf>
   <form>jíst</form>
   <lemma>jíst</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d1e3039-x2-378">
   <w.rf>
    <LM>w#w-d1e3039-x2-378</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-314">
  <m id="m009-d1t3052-12">
   <w.rf>
    <LM>w#w-d1t3052-12</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t3052-13">
   <w.rf>
    <LM>w#w-d1t3052-13</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m009-d1t3052-14">
   <w.rf>
    <LM>w#w-d1t3052-14</LM>
   </w.rf>
   <form>jedl</form>
   <lemma>jíst</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m009-d1t3054-2">
   <w.rf>
    <LM>w#w-d1t3054-2</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-314-449">
   <w.rf>
    <LM>w#w-314-449</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3054-3">
   <w.rf>
    <LM>w#w-d1t3054-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t3054-4">
   <w.rf>
    <LM>w#w-d1t3054-4</LM>
   </w.rf>
   <form>rána</form>
   <lemma>ráno-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m009-d1t3054-5">
   <w.rf>
    <LM>w#w-d1t3054-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t3054-6">
   <w.rf>
    <LM>w#w-d1t3054-6</LM>
   </w.rf>
   <form>večera</form>
   <lemma>večer-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m009-d-id170162">
   <w.rf>
    <LM>w#w-d-id170162</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3054-8">
   <w.rf>
    <LM>w#w-d1t3054-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t3056-3">
   <w.rf>
    <LM>w#w-d1t3056-3</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m009-d1t3056-4">
   <w.rf>
    <LM>w#w-d1t3056-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3056-5">
   <w.rf>
    <LM>w#w-d1t3056-5</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3056-6">
   <w.rf>
    <LM>w#w-d1t3056-6</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDNP4----------</tag>
  </m>
  <m id="m009-d1t3056-7">
   <w.rf>
    <LM>w#w-d1t3056-7</LM>
   </w.rf>
   <form>kila</form>
   <lemma>kilo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m009-d1t3056-8">
   <w.rf>
    <LM>w#w-d1t3056-8</LM>
   </w.rf>
   <form>nosit</form>
   <lemma>nosit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d-id170285">
   <w.rf>
    <LM>w#w-d-id170285</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3056-10">
   <w.rf>
    <LM>w#w-d1t3056-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3056-11">
   <w.rf>
    <LM>w#w-d1t3056-11</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t3056-12">
   <w.rf>
    <LM>w#w-d1t3056-12</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3056-13">
   <w.rf>
    <LM>w#w-d1t3056-13</LM>
   </w.rf>
   <form>tlustý</form>
   <lemma>tlustý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m009-314-454">
   <w.rf>
    <LM>w#w-314-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-455">
  <m id="m009-d1t3056-15">
   <w.rf>
    <LM>w#w-d1t3056-15</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3056-16">
   <w.rf>
    <LM>w#w-d1t3056-16</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3058-1">
   <w.rf>
    <LM>w#w-d1t3058-1</LM>
   </w.rf>
   <form>95</form>
   <lemma>95</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m009-455-468">
   <w.rf>
    <LM>w#w-455-468</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3058-5">
   <w.rf>
    <LM>w#w-d1t3058-5</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3058-6">
   <w.rf>
    <LM>w#w-d1t3058-6</LM>
   </w.rf>
   <form>97</form>
   <lemma>97</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m009-455-478">
   <w.rf>
    <LM>w#w-455-478</LM>
   </w.rf>
   <form>kilo</form>
   <lemma>kilo</lemma>
   <tag>NNNP2-----A---1</tag>
  </m>
  <m id="m009-455-479">
   <w.rf>
    <LM>w#w-455-479</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-471">
  <m id="m009-d1t3060-1">
   <w.rf>
    <LM>w#w-d1t3060-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3060-2">
   <w.rf>
    <LM>w#w-d1t3060-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3060-7">
   <w.rf>
    <LM>w#w-d1t3060-7</LM>
   </w.rf>
   <form>strašné</form>
   <lemma>strašný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m009-471-523">
   <w.rf>
    <LM>w#w-471-523</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3060-9">
   <w.rf>
    <LM>w#w-d1t3060-9</LM>
   </w.rf>
   <form>šmakuje</form>
   <lemma>šmakovat_,h</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3060-10">
   <w.rf>
    <LM>w#w-d1t3060-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t3060-11">
   <w.rf>
    <LM>w#w-d1t3060-11</LM>
   </w.rf>
   <form>jíst</form>
   <lemma>jíst</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-d1t3063-1">
   <w.rf>
    <LM>w#w-d1t3063-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-d1t3063-2">
   <w.rf>
    <LM>w#w-d1t3063-2</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-471-404">
   <w.rf>
    <LM>w#w-471-404</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t3063-4">
   <w.rf>
    <LM>w#w-d1t3063-4</LM>
   </w.rf>
   <form>omezovat</form>
   <lemma>omezovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m009-471-526">
   <w.rf>
    <LM>w#w-471-526</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-527_2">
  <m id="m009-d1t3063-7">
   <w.rf>
    <LM>w#w-d1t3063-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3063-8">
   <w.rf>
    <LM>w#w-d1t3063-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3063-9">
   <w.rf>
    <LM>w#w-d1t3063-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3063-10">
   <w.rf>
    <LM>w#w-d1t3063-10</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m009-d-id169853">
   <w.rf>
    <LM>w#w-d-id169853</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3064-x2">
  <m id="m009-d1t3067-1">
   <w.rf>
    <LM>w#w-d1t3067-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1e3064-x2-561">
   <w.rf>
    <LM>w#w-d1e3064-x2-561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-554">
  <m id="m009-d1t3067-4">
   <w.rf>
    <LM>w#w-d1t3067-4</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3067-5">
   <w.rf>
    <LM>w#w-d1t3067-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m009-d1t3067-6">
   <w.rf>
    <LM>w#w-d1t3067-6</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m009-d1t3067-7">
   <w.rf>
    <LM>w#w-d1t3067-7</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m009-d-id170813">
   <w.rf>
    <LM>w#w-d-id170813</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3068-x2">
  <m id="m009-d1t3071-1">
   <w.rf>
    <LM>w#w-d1t3071-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1e3068-x2-573">
   <w.rf>
    <LM>w#w-d1e3068-x2-573</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3071-2">
   <w.rf>
    <LM>w#w-d1t3071-2</LM>
   </w.rf>
   <form>děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id170968">
   <w.rf>
    <LM>w#w-d-id170968</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3072-x2">
  <m id="m009-d1t3075-1">
   <w.rf>
    <LM>w#w-d1t3075-1</LM>
   </w.rf>
   <form>Děkujeme</form>
   <lemma>děkovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3075-2">
   <w.rf>
    <LM>w#w-d1t3075-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3075-3">
   <w.rf>
    <LM>w#w-d1t3075-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t3075-4">
   <w.rf>
    <LM>w#w-d1t3075-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSIS4-P2-------</tag>
  </m>
  <m id="m009-d1t3075-5">
   <w.rf>
    <LM>w#w-d1t3075-5</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d-id171052">
   <w.rf>
    <LM>w#w-d-id171052</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3076-x2">
  <m id="m009-d1t3079-1">
   <w.rf>
    <LM>w#w-d1t3079-1</LM>
   </w.rf>
   <form>Rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m009-d1t3079-2">
   <w.rf>
    <LM>w#w-d1t3079-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3079-3">
   <w.rf>
    <LM>w#w-d1t3079-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3079-4">
   <w.rf>
    <LM>w#w-d1t3079-4</LM>
   </w.rf>
   <form>vyhověl</form>
   <lemma>vyhovět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m009-d1e3076-x2-649">
   <w.rf>
    <LM>w#w-d1e3076-x2-649</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-650">
  <m id="m009-d1t3079-6">
   <w.rf>
    <LM>w#w-d1t3079-6</LM>
   </w.rf>
   <form>Nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m009-d1t3079-7">
   <w.rf>
    <LM>w#w-d1t3079-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3079-8">
   <w.rf>
    <LM>w#w-d1t3079-8</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1t3079-9">
   <w.rf>
    <LM>w#w-d1t3079-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m009-d1t3079-10">
   <w.rf>
    <LM>w#w-d1t3079-10</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m009-d1t3079-11">
   <w.rf>
    <LM>w#w-d1t3079-11</LM>
   </w.rf>
   <form>problém</form>
   <lemma>problém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m009-d-id171183">
   <w.rf>
    <LM>w#w-d-id171183</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3080-x2">
  <m id="m009-d1t3083-1">
   <w.rf>
    <LM>w#w-d1t3083-1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3083-2">
   <w.rf>
    <LM>w#w-d1t3083-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t3083-3">
   <w.rf>
    <LM>w#w-d1t3083-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t3083-4">
   <w.rf>
    <LM>w#w-d1t3083-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m009-d1t3083-5">
   <w.rf>
    <LM>w#w-d1t3083-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t3083-6">
   <w.rf>
    <LM>w#w-d1t3083-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m009-d1t3083-7">
   <w.rf>
    <LM>w#w-d1t3083-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m009-d-id171393">
   <w.rf>
    <LM>w#w-d-id171393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3084-x2">
  <m id="m009-d1t3087-1">
   <w.rf>
    <LM>w#w-d1t3087-1</LM>
   </w.rf>
   <form>Povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m009-d1t3087-2">
   <w.rf>
    <LM>w#w-d1t3087-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t3087-3">
   <w.rf>
    <LM>w#w-d1t3087-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3087-4">
   <w.rf>
    <LM>w#w-d1t3087-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m009-d1t3087-5">
   <w.rf>
    <LM>w#w-d1t3087-5</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m009-d1t3087-6">
   <w.rf>
    <LM>w#w-d1t3087-6</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d-id171649">
   <w.rf>
    <LM>w#w-d-id171649</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3095-x2">
  <m id="m009-d1t3098-3">
   <w.rf>
    <LM>w#w-d1t3098-3</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3098-4">
   <w.rf>
    <LM>w#w-d1t3098-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3098-5">
   <w.rf>
    <LM>w#w-d1t3098-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3098-6">
   <w.rf>
    <LM>w#w-d1t3098-6</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m009-d1e3095-x2-713">
   <w.rf>
    <LM>w#w-d1e3095-x2-713</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3098-8">
   <w.rf>
    <LM>w#w-d1t3098-8</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m009-d1t3098-9">
   <w.rf>
    <LM>w#w-d1t3098-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m009-d1t3098-10">
   <w.rf>
    <LM>w#w-d1t3098-10</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m009-d1t3098-11">
   <w.rf>
    <LM>w#w-d1t3098-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d-id171757">
   <w.rf>
    <LM>w#w-d-id171757</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3099-x2">
  <m id="m009-d1t3102-1">
   <w.rf>
    <LM>w#w-d1t3102-1</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3102-2">
   <w.rf>
    <LM>w#w-d1t3102-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3102-3">
   <w.rf>
    <LM>w#w-d1t3102-3</LM>
   </w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m009-d1t3102-4">
   <w.rf>
    <LM>w#w-d1t3102-4</LM>
   </w.rf>
   <form>slouží</form>
   <lemma>sloužit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d-id171960">
   <w.rf>
    <LM>w#w-d-id171960</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3103-x2">
  <m id="m009-d1t3106-2">
   <w.rf>
    <LM>w#w-d1t3106-2</LM>
   </w.rf>
   <form>Vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3106-3">
   <w.rf>
    <LM>w#w-d1t3106-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1e3103-x2-818">
   <w.rf>
    <LM>w#w-d1e3103-x2-818</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-819">
  <m id="m009-d1t3106-5">
   <w.rf>
    <LM>w#w-d1t3106-5</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3106-11">
   <w.rf>
    <LM>w#w-d1t3106-11</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3106-7">
   <w.rf>
    <LM>w#w-d1t3106-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m009-d1t3106-8">
   <w.rf>
    <LM>w#w-d1t3106-8</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m009-d1t3106-12">
   <w.rf>
    <LM>w#w-d1t3106-12</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m009-d1t3106-13">
   <w.rf>
    <LM>w#w-d1t3106-13</LM>
   </w.rf>
   <form>vychází</form>
   <lemma>vycházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d-id172259">
   <w.rf>
    <LM>w#w-d-id172259</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3108-1">
   <w.rf>
    <LM>w#w-d1t3108-1</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3108-2">
   <w.rf>
    <LM>w#w-d1t3108-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t3108-3">
   <w.rf>
    <LM>w#w-d1t3108-3</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d1t3108-4">
   <w.rf>
    <LM>w#w-d1t3108-4</LM>
   </w.rf>
   <form>zdráva</form>
   <lemma>zdravý</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m009-d1t3108-5">
   <w.rf>
    <LM>w#w-d1t3108-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m009-819-829">
   <w.rf>
    <LM>w#w-819-829</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t3108-8">
   <w.rf>
    <LM>w#w-d1t3108-8</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m009-d1t3108-6">
   <w.rf>
    <LM>w#w-d1t3108-6</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m009-d1t3108-7">
   <w.rf>
    <LM>w#w-d1t3108-7</LM>
   </w.rf>
   <form>problémů</form>
   <lemma>problém</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m009-d-id172069">
   <w.rf>
    <LM>w#w-d-id172069</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3109-x2">
  <m id="m009-d1t3114-1">
   <w.rf>
    <LM>w#w-d1t3114-1</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m009-d1t3114-2">
   <w.rf>
    <LM>w#w-d1t3114-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m009-d1t3114-3">
   <w.rf>
    <LM>w#w-d1t3114-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d1t3114-4">
   <w.rf>
    <LM>w#w-d1t3114-4</LM>
   </w.rf>
   <form>vede</form>
   <lemma>vést</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m009-d1t3114-5">
   <w.rf>
    <LM>w#w-d1t3114-5</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m009-d-id172442">
   <w.rf>
    <LM>w#w-d-id172442</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3119-x2">
  <m id="m009-d1t3122-1">
   <w.rf>
    <LM>w#w-d1t3122-1</LM>
   </w.rf>
   <form>Děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id172577">
   <w.rf>
    <LM>w#w-d-id172577</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3123-x2">
  <m id="m009-d1t3126-1">
   <w.rf>
    <LM>w#w-d1t3126-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m009-d1t3126-2">
   <w.rf>
    <LM>w#w-d1t3126-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m009-d1t3126-4">
   <w.rf>
    <LM>w#w-d1t3126-4</LM>
   </w.rf>
   <form>mockrát</form>
   <lemma>mockrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m009-d1t3126-3">
   <w.rf>
    <LM>w#w-d1t3126-3</LM>
   </w.rf>
   <form>děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d-id172646">
   <w.rf>
    <LM>w#w-d-id172646</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3127-x2">
  <m id="m009-d1t3130-1">
   <w.rf>
    <LM>w#w-d1t3130-1</LM>
   </w.rf>
   <form>Počkejte</form>
   <lemma>počkat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m009-d1t3130-2">
   <w.rf>
    <LM>w#w-d1t3130-2</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d-id172808">
   <w.rf>
    <LM>w#w-d-id172808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3130-4">
   <w.rf>
    <LM>w#w-d1t3130-4</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m009-d1t3130-5">
   <w.rf>
    <LM>w#w-d1t3130-5</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m009-d1t3130-6">
   <w.rf>
    <LM>w#w-d1t3130-6</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m009-d1t3130-7">
   <w.rf>
    <LM>w#w-d1t3130-7</LM>
   </w.rf>
   <form>vysvobodit</form>
   <lemma>vysvobodit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m009-d-id172761">
   <w.rf>
    <LM>w#w-d-id172761</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3131-x2">
  <m id="m009-d1t3134-1">
   <w.rf>
    <LM>w#w-d1t3134-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m009-d1t3134-2">
   <w.rf>
    <LM>w#w-d1t3134-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3134-3">
   <w.rf>
    <LM>w#w-d1t3134-3</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m009-d-id172916">
   <w.rf>
    <LM>w#w-d-id172916</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3135-x2">
  <m id="m009-d1t3140-1">
   <w.rf>
    <LM>w#w-d1t3140-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m009-d1e3135-x2-897">
   <w.rf>
    <LM>w#w-d1e3135-x2-897</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m009-d-id173019">
   <w.rf>
    <LM>w#w-d-id173019</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3135-x3">
  <m id="m009-d1t3142-2">
   <w.rf>
    <LM>w#w-d1t3142-2</LM>
   </w.rf>
   <form>Děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m009-d1t3142-3">
   <w.rf>
    <LM>w#w-d1t3142-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m009-d-id173059">
   <w.rf>
    <LM>w#w-d-id173059</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m009-d1e3143-x2">
  <m id="m009-d1t3146-1">
   <w.rf>
    <LM>w#w-d1t3146-1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m009-d1t3146-2">
   <w.rf>
    <LM>w#w-d1t3146-2</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m009-d-id173190">
   <w.rf>
    <LM>w#w-d-id173190</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m009-d1t3146-4">
   <w.rf>
    <LM>w#w-d1t3146-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m009-d1t3146-5">
   <w.rf>
    <LM>w#w-d1t3146-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m009-d1t3146-6">
   <w.rf>
    <LM>w#w-d1t3146-6</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m009-d-id173143">
   <w.rf>
    <LM>w#w-d-id173143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
