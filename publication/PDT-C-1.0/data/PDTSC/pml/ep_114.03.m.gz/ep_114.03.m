<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ep_114.03.w.gz" />
  </references>
 </head>
 <s id="m114-178">
  <m id="m114-d1t824-1">
   <w.rf>
    <LM>w#w-d1t824-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t824-2">
   <w.rf>
    <LM>w#w-d1t824-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t824-3">
   <w.rf>
    <LM>w#w-d1t824-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1t824-5">
   <w.rf>
    <LM>w#w-d1t824-5</LM>
   </w.rf>
   <form>jeřábek</form>
   <lemma>jeřábek-2</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m114-d1t824-6">
   <w.rf>
    <LM>w#w-d1t824-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t824-7">
   <w.rf>
    <LM>w#w-d1t824-7</LM>
   </w.rf>
   <form>tvaru</form>
   <lemma>tvar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-178-450">
   <w.rf>
    <LM>w#w-178-450</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t824-8">
   <w.rf>
    <LM>w#w-d1t824-8</LM>
   </w.rf>
   <form>A</form>
   <lemma>A-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m114-178-451">
   <w.rf>
    <LM>w#w-178-451</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t824-9">
   <w.rf>
    <LM>w#w-d1t824-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t824-10">
   <w.rf>
    <LM>w#w-d1t824-10</LM>
   </w.rf>
   <form>klikou</form>
   <lemma>klika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m114-178-452">
   <w.rf>
    <LM>w#w-178-452</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-453">
  <m id="m114-d1t824-12">
   <w.rf>
    <LM>w#w-d1t824-12</LM>
   </w.rf>
   <form>Pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t824-13">
   <w.rf>
    <LM>w#w-d1t824-13</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m114-d1t824-14">
   <w.rf>
    <LM>w#w-d1t824-14</LM>
   </w.rf>
   <form>jeřábku</form>
   <lemma>jeřábek-2</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t824-15">
   <w.rf>
    <LM>w#w-d1t824-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t824-16">
   <w.rf>
    <LM>w#w-d1t824-16</LM>
   </w.rf>
   <form>hradla</form>
   <lemma>hradlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m114-d-id91693-punct">
   <w.rf>
    <LM>w#w-d-id91693-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t828-1">
   <w.rf>
    <LM>w#w-d1t828-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t828-2">
   <w.rf>
    <LM>w#w-d1t828-2</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t828-3">
   <w.rf>
    <LM>w#w-d1t828-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m114-d1t828-4">
   <w.rf>
    <LM>w#w-d1t828-4</LM>
   </w.rf>
   <form>dřevěné</form>
   <lemma>dřevěný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m114-d1t828-5">
   <w.rf>
    <LM>w#w-d1t828-5</LM>
   </w.rf>
   <form>trámce</form>
   <lemma>trámec</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m114-d1t828-6">
   <w.rf>
    <LM>w#w-d1t828-6</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t828-7">
   <w.rf>
    <LM>w#w-d1t828-7</LM>
   </w.rf>
   <form>vodě</form>
   <lemma>voda</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m114-178-52">
   <w.rf>
    <LM>w#w-178-52</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t828-10">
   <w.rf>
    <LM>w#w-d1t828-10</LM>
   </w.rf>
   <form>hákem</form>
   <lemma>hák</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m114-d1t828-12">
   <w.rf>
    <LM>w#w-d1t828-12</LM>
   </w.rf>
   <form>vyndávala</form>
   <lemma>vyndávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t828-13">
   <w.rf>
    <LM>w#w-d1t828-13</LM>
   </w.rf>
   <form>ven</form>
   <lemma>ven</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-178-179">
   <w.rf>
    <LM>w#w-178-179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-181">
  <m id="m114-d1t835-2">
   <w.rf>
    <LM>w#w-d1t835-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t835-3">
   <w.rf>
    <LM>w#w-d1t835-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t835-4">
   <w.rf>
    <LM>w#w-d1t835-4</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t835-5">
   <w.rf>
    <LM>w#w-d1t835-5</LM>
   </w.rf>
   <form>pracovníka</form>
   <lemma>pracovník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m114-d-id92025-punct">
   <w.rf>
    <LM>w#w-d-id92025-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t835-7">
   <w.rf>
    <LM>w#w-d1t835-7</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m114-d1t835-8">
   <w.rf>
    <LM>w#w-d1t835-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t835-9">
   <w.rf>
    <LM>w#w-d1t835-9</LM>
   </w.rf>
   <form>podílel</form>
   <lemma>podílet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t835-10">
   <w.rf>
    <LM>w#w-d1t835-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t835-11">
   <w.rf>
    <LM>w#w-d1t835-11</LM>
   </w.rf>
   <form>vyhražování</form>
   <lemma>vyhražování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m114-d1t835-12">
   <w.rf>
    <LM>w#w-d1t835-12</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m114-d1t835-13">
   <w.rf>
    <LM>w#w-d1t835-13</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-181-198">
   <w.rf>
    <LM>w#w-181-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e808-x3">
  <m id="m114-d1t839-1">
   <w.rf>
    <LM>w#w-d1t839-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t839-2">
   <w.rf>
    <LM>w#w-d1t839-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t839-3">
   <w.rf>
    <LM>w#w-d1t839-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1e808-x3-206">
   <w.rf>
    <LM>w#w-d1e808-x3-206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t839-8">
   <w.rf>
    <LM>w#w-d1t839-8</LM>
   </w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t839-6">
   <w.rf>
    <LM>w#w-d1t839-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t839-5">
   <w.rf>
    <LM>w#w-d1t839-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t839-9">
   <w.rf>
    <LM>w#w-d1t839-9</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t839-10">
   <w.rf>
    <LM>w#w-d1t839-10</LM>
   </w.rf>
   <form>omrzlá</form>
   <lemma>omrzlý_^(*2nout)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d-id92317-punct">
   <w.rf>
    <LM>w#w-d-id92317-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t841-1">
   <w.rf>
    <LM>w#w-d1t841-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t843-1">
   <w.rf>
    <LM>w#w-d1t843-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t843-2">
   <w.rf>
    <LM>w#w-d1t843-2</LM>
   </w.rf>
   <form>nejvyšší</form>
   <lemma>vysoký</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m114-d1t843-3">
   <w.rf>
    <LM>w#w-d1t843-3</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d-id92406-punct">
   <w.rf>
    <LM>w#w-d-id92406-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t843-5">
   <w.rf>
    <LM>w#w-d1t843-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t843-6">
   <w.rf>
    <LM>w#w-d1t843-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t843-8">
   <w.rf>
    <LM>w#w-d1t843-8</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1t843-10">
   <w.rf>
    <LM>w#w-d1t843-10</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t843-11">
   <w.rf>
    <LM>w#w-d1t843-11</LM>
   </w.rf>
   <form>vyhradil</form>
   <lemma>vyhradit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1t843-12">
   <w.rf>
    <LM>w#w-d1t843-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t843-13">
   <w.rf>
    <LM>w#w-d1t843-13</LM>
   </w.rf>
   <form>sklopil</form>
   <lemma>sklopit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1e808-x3-207">
   <w.rf>
    <LM>w#w-d1e808-x3-207</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-208">
  <m id="m114-d1t848-1">
   <w.rf>
    <LM>w#w-d1t848-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t848-2">
   <w.rf>
    <LM>w#w-d1t848-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t848-3">
   <w.rf>
    <LM>w#w-d1t848-3</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d-id92625-punct">
   <w.rf>
    <LM>w#w-d-id92625-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t848-5">
   <w.rf>
    <LM>w#w-d1t848-5</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m114-d1t848-6">
   <w.rf>
    <LM>w#w-d1t848-6</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t848-7">
   <w.rf>
    <LM>w#w-d1t848-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m114-d1t848-8">
   <w.rf>
    <LM>w#w-d1t848-8</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m114-208-213">
   <w.rf>
    <LM>w#w-208-213</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t852-2">
   <w.rf>
    <LM>w#w-d1t852-2</LM>
   </w.rf>
   <form>účastnilo</form>
   <lemma>účastnit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t852-3">
   <w.rf>
    <LM>w#w-d1t852-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t852-4">
   <w.rf>
    <LM>w#w-d1t852-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m114-d1t852-5">
   <w.rf>
    <LM>w#w-d1t852-5</LM>
   </w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t852-6">
   <w.rf>
    <LM>w#w-d1t852-6</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m114-d1t852-7">
   <w.rf>
    <LM>w#w-d1t852-7</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m114-208-212">
   <w.rf>
    <LM>w#w-208-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-214">
  <m id="m114-d1t854-2">
   <w.rf>
    <LM>w#w-d1t854-2</LM>
   </w.rf>
   <form>Muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t854-3">
   <w.rf>
    <LM>w#w-d1t854-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t854-4">
   <w.rf>
    <LM>w#w-d1t854-4</LM>
   </w.rf>
   <form>rozebrat</form>
   <lemma>rozebrat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t854-5">
   <w.rf>
    <LM>w#w-d1t854-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t861-1">
   <w.rf>
    <LM>w#w-d1t861-1</LM>
   </w.rf>
   <form>pomocné</form>
   <lemma>pomocný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t861-2">
   <w.rf>
    <LM>w#w-d1t861-2</LM>
   </w.rf>
   <form>zábradlí</form>
   <lemma>zábradlí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m114-d1t863-1">
   <w.rf>
    <LM>w#w-d1t863-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t863-2">
   <w.rf>
    <LM>w#w-d1t863-2</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m114-d1t863-4">
   <w.rf>
    <LM>w#w-d1t863-4</LM>
   </w.rf>
   <form>konstrukci</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t863-5">
   <w.rf>
    <LM>w#w-d1t863-5</LM>
   </w.rf>
   <form>pomaličku</form>
   <lemma>pomaličku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t863-6">
   <w.rf>
    <LM>w#w-d1t863-6</LM>
   </w.rf>
   <form>spustit</form>
   <lemma>spustit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t863-7">
   <w.rf>
    <LM>w#w-d1t863-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t863-8">
   <w.rf>
    <LM>w#w-d1t863-8</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d-m-d1e808-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e808-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e864-x2">
  <m id="m114-d1t867-1">
   <w.rf>
    <LM>w#w-d1t867-1</LM>
   </w.rf>
   <form>Mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t867-2">
   <w.rf>
    <LM>w#w-d1t867-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t867-3">
   <w.rf>
    <LM>w#w-d1t867-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t867-4">
   <w.rf>
    <LM>w#w-d1t867-4</LM>
   </w.rf>
   <form>mostě</form>
   <lemma>most</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d1t867-5">
   <w.rf>
    <LM>w#w-d1t867-5</LM>
   </w.rf>
   <form>přecházet</form>
   <lemma>přecházet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d-id93285-punct">
   <w.rf>
    <LM>w#w-d-id93285-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e868-x2">
  <m id="m114-d1t875-1">
   <w.rf>
    <LM>w#w-d1t875-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d-id93380-punct">
   <w.rf>
    <LM>w#w-d-id93380-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t875-3">
   <w.rf>
    <LM>w#w-d1t875-3</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m114-d1t875-4">
   <w.rf>
    <LM>w#w-d1t875-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t875-6">
   <w.rf>
    <LM>w#w-d1t875-6</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t875-7">
   <w.rf>
    <LM>w#w-d1t875-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m114-d1t875-5">
   <w.rf>
    <LM>w#w-d1t875-5</LM>
   </w.rf>
   <form>přecházet</form>
   <lemma>přecházet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1e868-x2-469">
   <w.rf>
    <LM>w#w-d1e868-x2-469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-470">
  <m id="m114-d1t875-9">
   <w.rf>
    <LM>w#w-d1t875-9</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t875-10">
   <w.rf>
    <LM>w#w-d1t875-10</LM>
   </w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m114-d1t875-11">
   <w.rf>
    <LM>w#w-d1t875-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t875-12">
   <w.rf>
    <LM>w#w-d1t875-12</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m114-d-id93536-punct">
   <w.rf>
    <LM>w#w-d-id93536-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t875-14">
   <w.rf>
    <LM>w#w-d1t875-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t875-15">
   <w.rf>
    <LM>w#w-d1t875-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t875-16">
   <w.rf>
    <LM>w#w-d1t875-16</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t875-17">
   <w.rf>
    <LM>w#w-d1t875-17</LM>
   </w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1t875-18">
   <w.rf>
    <LM>w#w-d1t875-18</LM>
   </w.rf>
   <form>prostor</form>
   <lemma>prostor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d-id93622-punct">
   <w.rf>
    <LM>w#w-d-id93622-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t875-20">
   <w.rf>
    <LM>w#w-d1t875-20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t875-21">
   <w.rf>
    <LM>w#w-d1t875-21</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t875-22">
   <w.rf>
    <LM>w#w-d1t875-22</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m114-d1t875-23">
   <w.rf>
    <LM>w#w-d1t875-23</LM>
   </w.rf>
   <form>určeno</form>
   <lemma>určit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m114-d1t875-24">
   <w.rf>
    <LM>w#w-d1t875-24</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t875-25">
   <w.rf>
    <LM>w#w-d1t875-25</LM>
   </w.rf>
   <form>osoby</form>
   <lemma>osoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m114-d1t875-27">
   <w.rf>
    <LM>w#w-d1t875-27</LM>
   </w.rf>
   <form>cizí</form>
   <lemma>cizí</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m114-d-id93755-punct">
   <w.rf>
    <LM>w#w-d-id93755-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t875-29">
   <w.rf>
    <LM>w#w-d1t875-29</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m114-d1t875-30">
   <w.rf>
    <LM>w#w-d1t875-30</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t875-31">
   <w.rf>
    <LM>w#w-d1t875-31</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d1t875-32">
   <w.rf>
    <LM>w#w-d1t875-32</LM>
   </w.rf>
   <form>nepracovaly</form>
   <lemma>pracovat</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m114-470-471">
   <w.rf>
    <LM>w#w-470-471</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-472">
  <m id="m114-d1t877-2">
   <w.rf>
    <LM>w#w-d1t877-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t877-1">
   <w.rf>
    <LM>w#w-d1t877-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t875-35">
   <w.rf>
    <LM>w#w-d1t875-35</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t875-36">
   <w.rf>
    <LM>w#w-d1t875-36</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t877-3">
   <w.rf>
    <LM>w#w-d1t877-3</LM>
   </w.rf>
   <form>nebezpečné</form>
   <lemma>bezpečný</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m114-d1e868-x2-228">
   <w.rf>
    <LM>w#w-d1e868-x2-228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-229">
  <m id="m114-d1t882-1">
   <w.rf>
    <LM>w#w-d1t882-1</LM>
   </w.rf>
   <form>Musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t882-2">
   <w.rf>
    <LM>w#w-d1t882-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t882-3">
   <w.rf>
    <LM>w#w-d1t882-3</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1t882-4">
   <w.rf>
    <LM>w#w-d1t882-4</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m114-d-id94023-punct">
   <w.rf>
    <LM>w#w-d-id94023-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t882-6">
   <w.rf>
    <LM>w#w-d1t882-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m114-d1t882-7">
   <w.rf>
    <LM>w#w-d1t882-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t882-8">
   <w.rf>
    <LM>w#w-d1t882-8</LM>
   </w.rf>
   <form>znalý</form>
   <lemma>znalý_^(*3át)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m114-229-484">
   <w.rf>
    <LM>w#w-229-484</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t884-1">
   <w.rf>
    <LM>w#w-d1t884-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t884-2">
   <w.rf>
    <LM>w#w-d1t884-2</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m114-d1t884-3">
   <w.rf>
    <LM>w#w-d1t884-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t884-4">
   <w.rf>
    <LM>w#w-d1t884-4</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-229-485">
   <w.rf>
    <LM>w#w-229-485</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-229-486">
   <w.rf>
    <LM>w#w-229-486</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-229-487">
   <w.rf>
    <LM>w#w-229-487</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-316">
  <m id="m114-d1t884-8">
   <w.rf>
    <LM>w#w-d1t884-8</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d-id94198-punct">
   <w.rf>
    <LM>w#w-d-id94198-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t884-10">
   <w.rf>
    <LM>w#w-d1t884-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-316-488">
   <w.rf>
    <LM>w#w-316-488</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-316-489">
   <w.rf>
    <LM>w#w-316-489</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m114-d1t884-11">
   <w.rf>
    <LM>w#w-d1t884-11</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m114-d-id94238-punct">
   <w.rf>
    <LM>w#w-d-id94238-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t884-13">
   <w.rf>
    <LM>w#w-d1t884-13</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t884-14">
   <w.rf>
    <LM>w#w-d1t884-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t884-15">
   <w.rf>
    <LM>w#w-d1t884-15</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m114-d1t884-16">
   <w.rf>
    <LM>w#w-d1t884-16</LM>
   </w.rf>
   <form>nijak</form>
   <lemma>nijak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t884-17">
   <w.rf>
    <LM>w#w-d1t884-17</LM>
   </w.rf>
   <form>zavřené</form>
   <lemma>zavřený_^(*3ít)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-316-496">
   <w.rf>
    <LM>w#w-316-496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-498">
  <m id="m114-d1t886-1">
   <w.rf>
    <LM>w#w-d1t886-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t886-2">
   <w.rf>
    <LM>w#w-d1t886-2</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m114-d1t886-3">
   <w.rf>
    <LM>w#w-d1t886-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t886-4">
   <w.rf>
    <LM>w#w-d1t886-4</LM>
   </w.rf>
   <form>veřejně</form>
   <lemma>veřejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t886-5">
   <w.rf>
    <LM>w#w-d1t886-5</LM>
   </w.rf>
   <form>přístupné</form>
   <lemma>přístupný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d-m-d1e868-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e868-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e887-x2">
  <m id="m114-d1t890-1">
   <w.rf>
    <LM>w#w-d1t890-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t890-2">
   <w.rf>
    <LM>w#w-d1t890-2</LM>
   </w.rf>
   <form>hluboká</form>
   <lemma>hluboký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t890-3">
   <w.rf>
    <LM>w#w-d1t890-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t890-4">
   <w.rf>
    <LM>w#w-d1t890-4</LM>
   </w.rf>
   <form>řeka</form>
   <lemma>řeka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t890-5">
   <w.rf>
    <LM>w#w-d1t890-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t890-6">
   <w.rf>
    <LM>w#w-d1t890-6</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m114-d1t890-7">
   <w.rf>
    <LM>w#w-d1t890-7</LM>
   </w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m114-d-id94580-punct">
   <w.rf>
    <LM>w#w-d-id94580-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e891-x2">
  <m id="m114-d1t900-1">
   <w.rf>
    <LM>w#w-d1t900-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t900-2">
   <w.rf>
    <LM>w#w-d1t900-2</LM>
   </w.rf>
   <form>tomhle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m114-d1t900-3">
   <w.rf>
    <LM>w#w-d1t900-3</LM>
   </w.rf>
   <form>prostoru</form>
   <lemma>prostor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d-id94730-punct">
   <w.rf>
    <LM>w#w-d-id94730-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t900-5">
   <w.rf>
    <LM>w#w-d1t900-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t900-6">
   <w.rf>
    <LM>w#w-d1t900-6</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t900-7">
   <w.rf>
    <LM>w#w-d1t900-7</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m114-d1t900-8">
   <w.rf>
    <LM>w#w-d1t900-8</LM>
   </w.rf>
   <form>človíček</form>
   <lemma>človíček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m114-d-id94801-punct">
   <w.rf>
    <LM>w#w-d-id94801-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t900-11">
   <w.rf>
    <LM>w#w-d1t900-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t900-12">
   <w.rf>
    <LM>w#w-d1t900-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t905-1">
   <w.rf>
    <LM>w#w-d1t905-1</LM>
   </w.rf>
   <form>takzvané</form>
   <lemma>takzvaný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t905-2">
   <w.rf>
    <LM>w#w-d1t905-2</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m114-d1t905-3">
   <w.rf>
    <LM>w#w-d1t905-3</LM>
   </w.rf>
   <form>jezové</form>
   <lemma>jezový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t905-4">
   <w.rf>
    <LM>w#w-d1t905-4</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m114-d1e891-x2-15">
   <w.rf>
    <LM>w#w-d1e891-x2-15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-16">
  <m id="m114-d1t905-8">
   <w.rf>
    <LM>w#w-d1t905-8</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1t905-7">
   <w.rf>
    <LM>w#w-d1t905-7</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t905-9">
   <w.rf>
    <LM>w#w-d1t905-9</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t905-14">
   <w.rf>
    <LM>w#w-d1t905-14</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t905-15">
   <w.rf>
    <LM>w#w-d1t905-15</LM>
   </w.rf>
   <form>pravého</form>
   <lemma>pravý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m114-d1t905-16">
   <w.rf>
    <LM>w#w-d1t905-16</LM>
   </w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t905-17">
   <w.rf>
    <LM>w#w-d1t905-17</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t905-18">
   <w.rf>
    <LM>w#w-d1t905-18</LM>
   </w.rf>
   <form>levému</form>
   <lemma>levý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m114-d1t905-10">
   <w.rf>
    <LM>w#w-d1t905-10</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m114-d1t905-11">
   <w.rf>
    <LM>w#w-d1t905-11</LM>
   </w.rf>
   <form>jezová</form>
   <lemma>jezový</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m114-d1t905-12">
   <w.rf>
    <LM>w#w-d1t905-12</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m114-16-17">
   <w.rf>
    <LM>w#w-16-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-18">
  <m id="m114-d1t909-7">
   <w.rf>
    <LM>w#w-d1t909-7</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m114-d1t909-8">
   <w.rf>
    <LM>w#w-d1t909-8</LM>
   </w.rf>
   <form>jezové</form>
   <lemma>jezový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t909-9">
   <w.rf>
    <LM>w#w-d1t909-9</LM>
   </w.rf>
   <form>pravé</form>
   <lemma>pravý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t909-10">
   <w.rf>
    <LM>w#w-d1t909-10</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m114-d1t909-2">
   <w.rf>
    <LM>w#w-d1t909-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t909-3">
   <w.rf>
    <LM>w#w-d1t909-3</LM>
   </w.rf>
   <form>pravého</form>
   <lemma>pravý</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m114-d1t909-4">
   <w.rf>
    <LM>w#w-d1t909-4</LM>
   </w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t909-11">
   <w.rf>
    <LM>w#w-d1t909-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t909-12">
   <w.rf>
    <LM>w#w-d1t909-12</LM>
   </w.rf>
   <form>nejhlubší</form>
   <lemma>hluboký</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m114-18-23">
   <w.rf>
    <LM>w#w-18-23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-24">
  <m id="m114-d1t913-1">
   <w.rf>
    <LM>w#w-d1t913-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t913-2">
   <w.rf>
    <LM>w#w-d1t913-2</LM>
   </w.rf>
   <form>určeno</form>
   <lemma>určit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m114-d1t913-3">
   <w.rf>
    <LM>w#w-d1t913-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-24-506">
   <w.rf>
    <LM>w#w-24-506</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m114-d-id95415-punct">
   <w.rf>
    <LM>w#w-d-id95415-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t913-5">
   <w.rf>
    <LM>w#w-d1t913-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t913-6">
   <w.rf>
    <LM>w#w-d1t913-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t913-7">
   <w.rf>
    <LM>w#w-d1t913-7</LM>
   </w.rf>
   <form>jezová</form>
   <lemma>jezový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t913-8">
   <w.rf>
    <LM>w#w-d1t913-8</LM>
   </w.rf>
   <form>konstrukce</form>
   <lemma>konstrukce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t913-9">
   <w.rf>
    <LM>w#w-d1t913-9</LM>
   </w.rf>
   <form>sklopená</form>
   <lemma>sklopený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t913-10">
   <w.rf>
    <LM>w#w-d1t913-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t913-11">
   <w.rf>
    <LM>w#w-d1t913-11</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t913-12">
   <w.rf>
    <LM>w#w-d1t913-12</LM>
   </w.rf>
   <form>nepřesahovala</form>
   <lemma>přesahovat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m114-d1t913-13">
   <w.rf>
    <LM>w#w-d1t913-13</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t913-14">
   <w.rf>
    <LM>w#w-d1t913-14</LM>
   </w.rf>
   <form>jezové</form>
   <lemma>jezový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m114-d1t913-15">
   <w.rf>
    <LM>w#w-d1t913-15</LM>
   </w.rf>
   <form>pilíře</form>
   <lemma>pilíř</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m114-d-id95595-punct">
   <w.rf>
    <LM>w#w-d-id95595-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-24-326">
   <w.rf>
    <LM>w#w-24-326</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t918-2">
   <w.rf>
    <LM>w#w-d1t918-2</LM>
   </w.rf>
   <form>touto</form>
   <lemma>tento</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m114-d1t918-3">
   <w.rf>
    <LM>w#w-d1t918-3</LM>
   </w.rf>
   <form>částí</form>
   <lemma>část</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m114-d1t918-1">
   <w.rf>
    <LM>w#w-d1t918-1</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t918-4">
   <w.rf>
    <LM>w#w-d1t918-4</LM>
   </w.rf>
   <form>proplouvat</form>
   <lemma>proplouvat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1t918-5">
   <w.rf>
    <LM>w#w-d1t918-5</LM>
   </w.rf>
   <form>remorkér</form>
   <lemma>remorkér</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t918-6">
   <w.rf>
    <LM>w#w-d1t918-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t918-7">
   <w.rf>
    <LM>w#w-d1t918-7</LM>
   </w.rf>
   <form>jakákoliv</form>
   <lemma>jakýkoliv</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m114-d1t918-8">
   <w.rf>
    <LM>w#w-d1t918-8</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t918-9">
   <w.rf>
    <LM>w#w-d1t918-9</LM>
   </w.rf>
   <form>loď</form>
   <lemma>loď</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-24-38">
   <w.rf>
    <LM>w#w-24-38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e891-x3">
  <m id="m114-d1t922-5">
   <w.rf>
    <LM>w#w-d1t922-5</LM>
   </w.rf>
   <form>Nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t922-7">
   <w.rf>
    <LM>w#w-d1t922-7</LM>
   </w.rf>
   <form>jezem</form>
   <lemma>jez</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m114-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t924-7">
   <w.rf>
    <LM>w#w-d1t924-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t924-8">
   <w.rf>
    <LM>w#w-d1t924-8</LM>
   </w.rf>
   <form>některých</form>
   <lemma>některý</lemma>
   <tag>PZXP6----------</tag>
  </m>
  <m id="m114-d1t924-9">
   <w.rf>
    <LM>w#w-d1t924-9</LM>
   </w.rf>
   <form>místech</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m114-d1t922-2">
   <w.rf>
    <LM>w#w-d1t922-2</LM>
   </w.rf>
   <form>hloubka</form>
   <lemma>hloubka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m114-d1t924-2">
   <w.rf>
    <LM>w#w-d1t924-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t924-3">
   <w.rf>
    <LM>w#w-d1t924-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>4.5</form>
   <lemma>4.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1t924-6">
   <w.rf>
    <LM>w#w-d1t924-6</LM>
   </w.rf>
   <form>m</form>
   <lemma>metr</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m114-d-m-d1e891-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e891-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e925-x2">
  <m id="m114-d1t928-1">
   <w.rf>
    <LM>w#w-d1t928-1</LM>
   </w.rf>
   <form>Stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m114-d1t928-2">
   <w.rf>
    <LM>w#w-d1t928-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t928-3">
   <w.rf>
    <LM>w#w-d1t928-3</LM>
   </w.rf>
   <form>zde</form>
   <lemma>zde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t928-4">
   <w.rf>
    <LM>w#w-d1t928-4</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t928-5">
   <w.rf>
    <LM>w#w-d1t928-5</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m114-d1t928-6">
   <w.rf>
    <LM>w#w-d1t928-6</LM>
   </w.rf>
   <form>neštěstí</form>
   <lemma>neštěstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m114-d-id96198-punct">
   <w.rf>
    <LM>w#w-d-id96198-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e929-x2">
  <m id="m114-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t936-2">
   <w.rf>
    <LM>w#w-d1t936-2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m114-d1t936-3">
   <w.rf>
    <LM>w#w-d1t936-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t936-4">
   <w.rf>
    <LM>w#w-d1t936-4</LM>
   </w.rf>
   <form>dostaneme</form>
   <lemma>dostat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m114-d1t936-5">
   <w.rf>
    <LM>w#w-d1t936-5</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1e929-x2-49">
   <w.rf>
    <LM>w#w-d1e929-x2-49</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-50">
  <m id="m114-d1t938-1">
   <w.rf>
    <LM>w#w-d1t938-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t940-1">
   <w.rf>
    <LM>w#w-d1t940-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t940-2">
   <w.rf>
    <LM>w#w-d1t940-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t940-3">
   <w.rf>
    <LM>w#w-d1t940-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m114-d1t943-2">
   <w.rf>
    <LM>w#w-d1t943-2</LM>
   </w.rf>
   <form>1974</form>
   <lemma>1974</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1t943-8">
   <w.rf>
    <LM>w#w-d1t943-8</LM>
   </w.rf>
   <form>rozhodnuto</form>
   <lemma>rozhodnout</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m114-d-id96641-punct">
   <w.rf>
    <LM>w#w-d-id96641-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t943-10">
   <w.rf>
    <LM>w#w-d1t943-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m114-d1t945-4">
   <w.rf>
    <LM>w#w-d1t945-4</LM>
   </w.rf>
   <form>jezovém</form>
   <lemma>jezový</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m114-d1t945-5">
   <w.rf>
    <LM>w#w-d1t945-5</LM>
   </w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m114-d1t947-1">
   <w.rf>
    <LM>w#w-d1t947-1</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m114-d1t947-2">
   <w.rf>
    <LM>w#w-d1t947-2</LM>
   </w.rf>
   <form>vytvořena</form>
   <lemma>vytvořit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m114-d1t951-2">
   <w.rf>
    <LM>w#w-d1t951-2</LM>
   </w.rf>
   <form>podpíraná</form>
   <lemma>podpíraný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t951-1">
   <w.rf>
    <LM>w#w-d1t951-1</LM>
   </w.rf>
   <form>jezová</form>
   <lemma>jezový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t951-3">
   <w.rf>
    <LM>w#w-d1t951-3</LM>
   </w.rf>
   <form>klapka</form>
   <lemma>klapka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d-id96856-punct">
   <w.rf>
    <LM>w#w-d-id96856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t951-5">
   <w.rf>
    <LM>w#w-d1t951-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t951-6">
   <w.rf>
    <LM>w#w-d1t951-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t951-7">
   <w.rf>
    <LM>w#w-d1t951-7</LM>
   </w.rf>
   <form>ulehčila</form>
   <lemma>ulehčit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m114-d1t951-8">
   <w.rf>
    <LM>w#w-d1t951-8</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t951-9">
   <w.rf>
    <LM>w#w-d1t951-9</LM>
   </w.rf>
   <form>lidem</form>
   <lemma>lidé</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m114-d1t951-10">
   <w.rf>
    <LM>w#w-d1t951-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t951-11">
   <w.rf>
    <LM>w#w-d1t951-11</LM>
   </w.rf>
   <form>hradlovém</form>
   <lemma>hradlový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m114-d1t951-12">
   <w.rf>
    <LM>w#w-d1t951-12</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-50-51">
   <w.rf>
    <LM>w#w-50-51</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t958-1">
   <w.rf>
    <LM>w#w-d1t958-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t958-2">
   <w.rf>
    <LM>w#w-d1t958-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t958-3">
   <w.rf>
    <LM>w#w-d1t958-3</LM>
   </w.rf>
   <form>zahradilo</form>
   <lemma>zahradit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m114-d-id97068-punct">
   <w.rf>
    <LM>w#w-d-id97068-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t958-5">
   <w.rf>
    <LM>w#w-d1t958-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t958-6">
   <w.rf>
    <LM>w#w-d1t958-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t958-7">
   <w.rf>
    <LM>w#w-d1t958-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m114-d1t958-8">
   <w.rf>
    <LM>w#w-d1t958-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t958-9">
   <w.rf>
    <LM>w#w-d1t958-9</LM>
   </w.rf>
   <form>zmínili</form>
   <lemma>zmínit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m114-d-id97155-punct">
   <w.rf>
    <LM>w#w-d-id97155-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t960-1">
   <w.rf>
    <LM>w#w-d1t960-1</LM>
   </w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t960-2">
   <w.rf>
    <LM>w#w-d1t960-2</LM>
   </w.rf>
   <form>železných</form>
   <lemma>železný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m114-d1t960-3">
   <w.rf>
    <LM>w#w-d1t960-3</LM>
   </w.rf>
   <form>štětovnic</form>
   <lemma>štětovnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m114-d1t960-4">
   <w.rf>
    <LM>w#w-d1t960-4</LM>
   </w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t960-5">
   <w.rf>
    <LM>w#w-d1t960-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t960-6">
   <w.rf>
    <LM>w#w-d1t960-6</LM>
   </w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m114-d1t960-7">
   <w.rf>
    <LM>w#w-d1t960-7</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m114-50-66">
   <w.rf>
    <LM>w#w-50-66</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e929-x3">
  <m id="m114-d1t964-2">
   <w.rf>
    <LM>w#w-d1t964-2</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t964-5">
   <w.rf>
    <LM>w#w-d1t964-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t966-1">
   <w.rf>
    <LM>w#w-d1t966-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t964-3">
   <w.rf>
    <LM>w#w-d1t964-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m114-d1t964-4">
   <w.rf>
    <LM>w#w-d1t964-4</LM>
   </w.rf>
   <form>stavba</form>
   <lemma>stavba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t966-2">
   <w.rf>
    <LM>w#w-d1t966-2</LM>
   </w.rf>
   <form>odložena</form>
   <lemma>odložit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m114-d1t969-1">
   <w.rf>
    <LM>w#w-d1t969-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>nápor</form>
   <lemma>nápor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t969-3">
   <w.rf>
    <LM>w#w-d1t969-3</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d-id97466-punct">
   <w.rf>
    <LM>w#w-d-id97466-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t969-5">
   <w.rf>
    <LM>w#w-d1t969-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m114-d1t969-6">
   <w.rf>
    <LM>w#w-d1t969-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t969-7">
   <w.rf>
    <LM>w#w-d1t969-7</LM>
   </w.rf>
   <form>soustředěn</form>
   <lemma>soustředit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m114-d1t969-8">
   <w.rf>
    <LM>w#w-d1t969-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t969-9">
   <w.rf>
    <LM>w#w-d1t969-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t969-10">
   <w.rf>
    <LM>w#w-d1t969-10</LM>
   </w.rf>
   <form>levému</form>
   <lemma>levý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m114-d1t969-11">
   <w.rf>
    <LM>w#w-d1t969-11</LM>
   </w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m114-d-id97583-punct">
   <w.rf>
    <LM>w#w-d-id97583-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t973-1">
   <w.rf>
    <LM>w#w-d1t973-1</LM>
   </w.rf>
   <form>dovedl</form>
   <lemma>dovést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1t973-2">
   <w.rf>
    <LM>w#w-d1t973-2</LM>
   </w.rf>
   <form>podhlodat</form>
   <lemma>podhlodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t973-3">
   <w.rf>
    <LM>w#w-d1t973-3</LM>
   </w.rf>
   <form>spodní</form>
   <lemma>spodní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m114-d1t973-4">
   <w.rf>
    <LM>w#w-d1t973-4</LM>
   </w.rf>
   <form>stavbu</form>
   <lemma>stavba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t973-5">
   <w.rf>
    <LM>w#w-d1t973-5</LM>
   </w.rf>
   <form>jezového</form>
   <lemma>jezový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m114-d1t973-6">
   <w.rf>
    <LM>w#w-d1t973-6</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m114-d1t973-9">
   <w.rf>
    <LM>w#w-d1t973-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t973-10">
   <w.rf>
    <LM>w#w-d1t973-10</LM>
   </w.rf>
   <form>levé</form>
   <lemma>levý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m114-d1t973-11">
   <w.rf>
    <LM>w#w-d1t973-11</LM>
   </w.rf>
   <form>části</form>
   <lemma>část</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d1t975-1">
   <w.rf>
    <LM>w#w-d1t975-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t975-2">
   <w.rf>
    <LM>w#w-d1t975-2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m114-d1t975-3">
   <w.rf>
    <LM>w#w-d1t975-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t975-4">
   <w.rf>
    <LM>w#w-d1t975-4</LM>
   </w.rf>
   <form>zřítila</form>
   <lemma>zřítit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m114-d1e929-x3-67">
   <w.rf>
    <LM>w#w-d1e929-x3-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-68">
  <m id="m114-d1t977-1">
   <w.rf>
    <LM>w#w-d1t977-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t975-6">
   <w.rf>
    <LM>w#w-d1t975-6</LM>
   </w.rf>
   <form>následujícím</form>
   <lemma>následující_^(*5ovat)</lemma>
   <tag>AGIS6-----A----</tag>
  </m>
  <m id="m114-d1t975-7">
   <w.rf>
    <LM>w#w-d1t975-7</LM>
   </w.rf>
   <form>obrázku</form>
   <lemma>obrázek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d1t975-8">
   <w.rf>
    <LM>w#w-d1t975-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t977-3">
   <w.rf>
    <LM>w#w-d1t977-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m114-d1t977-4">
   <w.rf>
    <LM>w#w-d1t977-4</LM>
   </w.rf>
   <form>patrně</form>
   <lemma>patrně-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t977-5">
   <w.rf>
    <LM>w#w-d1t977-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t977-6">
   <w.rf>
    <LM>w#w-d1t977-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-68-69">
   <w.rf>
    <LM>w#w-68-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-70">
  <m id="m114-d1t982-2">
   <w.rf>
    <LM>w#w-d1t982-2</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t982-3">
   <w.rf>
    <LM>w#w-d1t982-3</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t982-4">
   <w.rf>
    <LM>w#w-d1t982-4</LM>
   </w.rf>
   <form>stavbě</form>
   <lemma>stavba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d1t982-5">
   <w.rf>
    <LM>w#w-d1t982-5</LM>
   </w.rf>
   <form>nového</form>
   <lemma>nový</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m114-d1t982-6">
   <w.rf>
    <LM>w#w-d1t982-6</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t982-7">
   <w.rf>
    <LM>w#w-d1t982-7</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t982-8">
   <w.rf>
    <LM>w#w-d1t982-8</LM>
   </w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m114-d1t982-9">
   <w.rf>
    <LM>w#w-d1t982-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t982-10">
   <w.rf>
    <LM>w#w-d1t982-10</LM>
   </w.rf>
   <form>jednomu</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS3----------</tag>
  </m>
  <m id="m114-d1t982-11">
   <w.rf>
    <LM>w#w-d1t982-11</LM>
   </w.rf>
   <form>smrtelnému</form>
   <lemma>smrtelný</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m114-d1t982-12">
   <w.rf>
    <LM>w#w-d1t982-12</LM>
   </w.rf>
   <form>úrazu</form>
   <lemma>úraz</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m114-70-71">
   <w.rf>
    <LM>w#w-70-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-72">
  <m id="m114-d1t984-1">
   <w.rf>
    <LM>w#w-d1t984-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t984-2">
   <w.rf>
    <LM>w#w-d1t984-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m114-d1t984-3">
   <w.rf>
    <LM>w#w-d1t984-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t984-4">
   <w.rf>
    <LM>w#w-d1t984-4</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m114-d1t984-5">
   <w.rf>
    <LM>w#w-d1t984-5</LM>
   </w.rf>
   <form>původním</form>
   <lemma>původní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m114-d1t982-16">
   <w.rf>
    <LM>w#w-d1t982-16</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-72-88">
   <w.rf>
    <LM>w#w-72-88</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t986-1">
   <w.rf>
    <LM>w#w-d1t986-1</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d-id98401-punct">
   <w.rf>
    <LM>w#w-d-id98401-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t986-3">
   <w.rf>
    <LM>w#w-d1t986-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t986-4">
   <w.rf>
    <LM>w#w-d1t986-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m114-d1t986-5">
   <w.rf>
    <LM>w#w-d1t986-5</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m114-d1t986-6">
   <w.rf>
    <LM>w#w-d1t986-6</LM>
   </w.rf>
   <form>nespadli</form>
   <lemma>spadnout</lemma>
   <tag>VpMP----R-NAP-1</tag>
  </m>
  <m id="m114-d1t986-7">
   <w.rf>
    <LM>w#w-d1t986-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t986-8">
   <w.rf>
    <LM>w#w-d1t986-8</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-72-543">
   <w.rf>
    <LM>w#w-72-543</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-544">
  <m id="m114-d1t986-10">
   <w.rf>
    <LM>w#w-d1t986-10</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t986-11">
   <w.rf>
    <LM>w#w-d1t986-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m114-d1t986-12">
   <w.rf>
    <LM>w#w-d1t986-12</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m114-d1t986-13">
   <w.rf>
    <LM>w#w-d1t986-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t986-14">
   <w.rf>
    <LM>w#w-d1t986-14</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m114-d-id98589-punct">
   <w.rf>
    <LM>w#w-d-id98589-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t986-16">
   <w.rf>
    <LM>w#w-d1t986-16</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t986-17">
   <w.rf>
    <LM>w#w-d1t986-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m114-d1t986-18">
   <w.rf>
    <LM>w#w-d1t986-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m114-d1t986-19">
   <w.rf>
    <LM>w#w-d1t986-19</LM>
   </w.rf>
   <form>přežili</form>
   <lemma>přežít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m114-d-m-d1e929-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e929-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e987-x2">
  <m id="m114-d1t990-1">
   <w.rf>
    <LM>w#w-d1t990-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m114-d-m-d1e987-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e987-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e992-x2">
  <m id="m114-d1t995-1">
   <w.rf>
    <LM>w#w-d1t995-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m114-d-m-d1e992-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e992-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e996-x2">
  <m id="m114-d1t999-1">
   <w.rf>
    <LM>w#w-d1t999-1</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m114-d1t999-2">
   <w.rf>
    <LM>w#w-d1t999-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m114-d1t999-3">
   <w.rf>
    <LM>w#w-d1t999-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m114-d1t999-4">
   <w.rf>
    <LM>w#w-d1t999-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m114-d1e996-x2-549">
   <w.rf>
    <LM>w#w-d1e996-x2-549</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-550">
  <m id="m114-d1t999-6">
   <w.rf>
    <LM>w#w-d1t999-6</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m114-d1t999-7">
   <w.rf>
    <LM>w#w-d1t999-7</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m114-d1t999-8">
   <w.rf>
    <LM>w#w-d1t999-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t999-9">
   <w.rf>
    <LM>w#w-d1t999-9</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m114-d1t999-10">
   <w.rf>
    <LM>w#w-d1t999-10</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d-id98998-punct">
   <w.rf>
    <LM>w#w-d-id98998-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1000-x2">
  <m id="m114-d1t1003-1">
   <w.rf>
    <LM>w#w-d1t1003-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m114-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m114-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>pracovníka</form>
   <lemma>pracovník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m114-d-id99137-punct">
   <w.rf>
    <LM>w#w-d-id99137-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1003-7">
   <w.rf>
    <LM>w#w-d1t1003-7</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m114-d1t1003-8">
   <w.rf>
    <LM>w#w-d1t1003-8</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1003-9">
   <w.rf>
    <LM>w#w-d1t1003-9</LM>
   </w.rf>
   <form>denně</form>
   <lemma>denně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1003-10">
   <w.rf>
    <LM>w#w-d1t1003-10</LM>
   </w.rf>
   <form>několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m114-d1t1003-11">
   <w.rf>
    <LM>w#w-d1t1003-11</LM>
   </w.rf>
   <form>projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t1003-12">
   <w.rf>
    <LM>w#w-d1t1003-12</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m114-d1t1003-13">
   <w.rf>
    <LM>w#w-d1t1003-13</LM>
   </w.rf>
   <form>jezové</form>
   <lemma>jezový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m114-d1t1003-14">
   <w.rf>
    <LM>w#w-d1t1003-14</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m114-d1t1003-15">
   <w.rf>
    <LM>w#w-d1t1003-15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1003-16">
   <w.rf>
    <LM>w#w-d1t1003-16</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1003-17">
   <w.rf>
    <LM>w#w-d1t1003-17</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m114-d1t1003-18">
   <w.rf>
    <LM>w#w-d1t1003-18</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m114-d1t1005-1">
   <w.rf>
    <LM>w#w-d1t1005-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1005-2">
   <w.rf>
    <LM>w#w-d1t1005-2</LM>
   </w.rf>
   <form>pomocí</form>
   <lemma>pomocí</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m114-d1t1005-3">
   <w.rf>
    <LM>w#w-d1t1005-3</LM>
   </w.rf>
   <form>háčku</form>
   <lemma>háček</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t1005-4">
   <w.rf>
    <LM>w#w-d1t1005-4</LM>
   </w.rf>
   <form>pročistit</form>
   <lemma>pročistit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t1005-5">
   <w.rf>
    <LM>w#w-d1t1005-5</LM>
   </w.rf>
   <form>mezery</form>
   <lemma>mezera</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m114-d1t1005-6">
   <w.rf>
    <LM>w#w-d1t1005-6</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t1005-7">
   <w.rf>
    <LM>w#w-d1t1005-7</LM>
   </w.rf>
   <form>jednotlivými</form>
   <lemma>jednotlivý</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m114-d1t1005-8">
   <w.rf>
    <LM>w#w-d1t1005-8</LM>
   </w.rf>
   <form>hradly</form>
   <lemma>hradlo</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m114-d-id99467-punct">
   <w.rf>
    <LM>w#w-d-id99467-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1007-1">
   <w.rf>
    <LM>w#w-d1t1007-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1007-2">
   <w.rf>
    <LM>w#w-d1t1007-2</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1007-3">
   <w.rf>
    <LM>w#w-d1t1007-3</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1007-4">
   <w.rf>
    <LM>w#w-d1t1007-4</LM>
   </w.rf>
   <form>protékat</form>
   <lemma>protékat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1e1000-x2-560">
   <w.rf>
    <LM>w#w-d1e1000-x2-560</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-561">
  <m id="m114-d1t1007-7">
   <w.rf>
    <LM>w#w-d1t1007-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t1007-8">
   <w.rf>
    <LM>w#w-d1t1007-8</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m114-d1t1007-9">
   <w.rf>
    <LM>w#w-d1t1007-9</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d-id99617-punct">
   <w.rf>
    <LM>w#w-d-id99617-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1007-11">
   <w.rf>
    <LM>w#w-d1t1007-11</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m114-d1t1007-12">
   <w.rf>
    <LM>w#w-d1t1007-12</LM>
   </w.rf>
   <form>převádí</form>
   <lemma>převádět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t1007-13">
   <w.rf>
    <LM>w#w-d1t1007-13</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t1007-14">
   <w.rf>
    <LM>w#w-d1t1007-14</LM>
   </w.rf>
   <form>vrchem</form>
   <lemma>vrchem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d-id99688-punct">
   <w.rf>
    <LM>w#w-d-id99688-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1009-1">
   <w.rf>
    <LM>w#w-d1t1009-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1009-2">
   <w.rf>
    <LM>w#w-d1t1009-2</LM>
   </w.rf>
   <form>propouští</form>
   <lemma>propouštět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1t1009-3">
   <w.rf>
    <LM>w#w-d1t1009-3</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t1009-4">
   <w.rf>
    <LM>w#w-d1t1009-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1009-5">
   <w.rf>
    <LM>w#w-d1t1009-5</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d1t1009-6">
   <w.rf>
    <LM>w#w-d1t1009-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1009-7">
   <w.rf>
    <LM>w#w-d1t1009-7</LM>
   </w.rf>
   <form>cedníkem</form>
   <lemma>cedník</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m114-d1e1000-x2-100">
   <w.rf>
    <LM>w#w-d1e1000-x2-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-101">
  <m id="m114-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>řeka</form>
   <lemma>řeka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m114-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>čistá</form>
   <lemma>čistý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t1016-6">
   <w.rf>
    <LM>w#w-d1t1016-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1016-7">
   <w.rf>
    <LM>w#w-d1t1016-7</LM>
   </w.rf>
   <form>nosí</form>
   <lemma>nosit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m114-d1e1000-x2-99">
   <w.rf>
    <LM>w#w-d1e1000-x2-99</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t1016-8">
   <w.rf>
    <LM>w#w-d1t1016-8</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m114-d1t1016-9">
   <w.rf>
    <LM>w#w-d1t1016-9</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t1016-10">
   <w.rf>
    <LM>w#w-d1t1016-10</LM>
   </w.rf>
   <form>náplavu</form>
   <lemma>náplav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d-id100003-punct">
   <w.rf>
    <LM>w#w-d-id100003-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1016-12">
   <w.rf>
    <LM>w#w-d1t1016-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1016-13">
   <w.rf>
    <LM>w#w-d1t1016-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1016-14">
   <w.rf>
    <LM>w#w-d1t1016-14</LM>
   </w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m114-d1t1016-15">
   <w.rf>
    <LM>w#w-d1t1016-15</LM>
   </w.rf>
   <form>náplav</form>
   <lemma>náplav</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1016-16">
   <w.rf>
    <LM>w#w-d1t1016-16</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1020-1">
   <w.rf>
    <LM>w#w-d1t1020-1</LM>
   </w.rf>
   <form>vyndávat</form>
   <lemma>vyndávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d-id100122-punct">
   <w.rf>
    <LM>w#w-d-id100122-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1020-3">
   <w.rf>
    <LM>w#w-d1t1020-3</LM>
   </w.rf>
   <form>čistit</form>
   <lemma>čistit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d-id100147-punct">
   <w.rf>
    <LM>w#w-d-id100147-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1020-5">
   <w.rf>
    <LM>w#w-d1t1020-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1020-7">
   <w.rf>
    <LM>w#w-d1t1020-7</LM>
   </w.rf>
   <form>průtok</form>
   <lemma>průtok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1020-8">
   <w.rf>
    <LM>w#w-d1t1020-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1020-9">
   <w.rf>
    <LM>w#w-d1t1020-9</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1020-10">
   <w.rf>
    <LM>w#w-d1t1020-10</LM>
   </w.rf>
   <form>stejný</form>
   <lemma>stejný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1e1000-x3-118">
   <w.rf>
    <LM>w#w-d1e1000-x3-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-117">
  <m id="m114-d1t1024-1">
   <w.rf>
    <LM>w#w-d1t1024-1</LM>
   </w.rf>
   <form>Hladina</form>
   <lemma>hladina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1024-2">
   <w.rf>
    <LM>w#w-d1t1024-2</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d1t1024-3">
   <w.rf>
    <LM>w#w-d1t1024-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1024-4">
   <w.rf>
    <LM>w#w-d1t1024-4</LM>
   </w.rf>
   <form>udržovala</form>
   <lemma>udržovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1024-5">
   <w.rf>
    <LM>w#w-d1t1024-5</LM>
   </w.rf>
   <form>takovým</form>
   <lemma>takový</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m114-d1t1024-6">
   <w.rf>
    <LM>w#w-d1t1024-6</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m114-d-id100366-punct">
   <w.rf>
    <LM>w#w-d-id100366-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1024-8">
   <w.rf>
    <LM>w#w-d1t1024-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1027-1">
   <w.rf>
    <LM>w#w-d1t1027-1</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1027-2">
   <w.rf>
    <LM>w#w-d1t1027-2</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1027-3">
   <w.rf>
    <LM>w#w-d1t1027-3</LM>
   </w.rf>
   <form>stoupala</form>
   <lemma>stoupat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d-id100446-punct">
   <w.rf>
    <LM>w#w-d-id100446-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1027-5">
   <w.rf>
    <LM>w#w-d1t1027-5</LM>
   </w.rf>
   <form>vytahovala</form>
   <lemma>vytahovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1027-6">
   <w.rf>
    <LM>w#w-d1t1027-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1027-8">
   <w.rf>
    <LM>w#w-d1t1027-8</LM>
   </w.rf>
   <form>jednotlivá</form>
   <lemma>jednotlivý</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m114-d1t1027-9">
   <w.rf>
    <LM>w#w-d1t1027-9</LM>
   </w.rf>
   <form>hradla</form>
   <lemma>hradlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m114-d-id100532-punct">
   <w.rf>
    <LM>w#w-d-id100532-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1031-1">
   <w.rf>
    <LM>w#w-d1t1031-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1031-2">
   <w.rf>
    <LM>w#w-d1t1031-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1031-3">
   <w.rf>
    <LM>w#w-d1t1031-3</LM>
   </w.rf>
   <form>vytvořily</form>
   <lemma>vytvořit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m114-d1t1031-4">
   <w.rf>
    <LM>w#w-d1t1031-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1031-5">
   <w.rf>
    <LM>w#w-d1t1031-5</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m114-d1t1031-6">
   <w.rf>
    <LM>w#w-d1t1031-6</LM>
   </w.rf>
   <form>mezery</form>
   <lemma>mezera</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m114-d-id100652-punct">
   <w.rf>
    <LM>w#w-d-id100652-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1031-8">
   <w.rf>
    <LM>w#w-d1t1031-8</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1031-9">
   <w.rf>
    <LM>w#w-d1t1031-9</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m114-d1t1031-10">
   <w.rf>
    <LM>w#w-d1t1031-10</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1031-11">
   <w.rf>
    <LM>w#w-d1t1031-11</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m114-d1t1031-12">
   <w.rf>
    <LM>w#w-d1t1031-12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1031-13">
   <w.rf>
    <LM>w#w-d1t1031-13</LM>
   </w.rf>
   <form>stačila</form>
   <lemma>stačit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1031-14">
   <w.rf>
    <LM>w#w-d1t1031-14</LM>
   </w.rf>
   <form>proplout</form>
   <lemma>proplout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-117-119">
   <w.rf>
    <LM>w#w-117-119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-120">
  <m id="m114-d1t1035-1">
   <w.rf>
    <LM>w#w-d1t1035-1</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1035-3">
   <w.rf>
    <LM>w#w-d1t1035-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1035-2">
   <w.rf>
    <LM>w#w-d1t1035-2</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-2_,s_^(^DD**zase-2)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1035-4">
   <w.rf>
    <LM>w#w-d1t1035-4</LM>
   </w.rf>
   <form>průtok</form>
   <lemma>průtok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1035-5">
   <w.rf>
    <LM>w#w-d1t1035-5</LM>
   </w.rf>
   <form>nižší</form>
   <lemma>nízký</lemma>
   <tag>AAIS1----2A----</tag>
  </m>
  <m id="m114-d-id100871-punct">
   <w.rf>
    <LM>w#w-d-id100871-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1035-7">
   <w.rf>
    <LM>w#w-d1t1035-7</LM>
   </w.rf>
   <form>ubývala</form>
   <lemma>ubývat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1035-8">
   <w.rf>
    <LM>w#w-d1t1035-8</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d-id100911-punct">
   <w.rf>
    <LM>w#w-d-id100911-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1035-10">
   <w.rf>
    <LM>w#w-d1t1035-10</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1035-11">
   <w.rf>
    <LM>w#w-d1t1035-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1037-1">
   <w.rf>
    <LM>w#w-d1t1037-1</LM>
   </w.rf>
   <form>otvor</form>
   <lemma>otvor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1037-2">
   <w.rf>
    <LM>w#w-d1t1037-2</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1t1042-1">
   <w.rf>
    <LM>w#w-d1t1042-1</LM>
   </w.rf>
   <form>vyčistit</form>
   <lemma>vyčistit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m114-d1t1044-1">
   <w.rf>
    <LM>w#w-d1t1044-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1044-8">
   <w.rf>
    <LM>w#w-d1t1044-8</LM>
   </w.rf>
   <form>hradla</form>
   <lemma>hradlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m114-d1t1044-3">
   <w.rf>
    <LM>w#w-d1t1044-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1044-2">
   <w.rf>
    <LM>w#w-d1t1044-2</LM>
   </w.rf>
   <form>ručně</form>
   <lemma>ručně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1044-4">
   <w.rf>
    <LM>w#w-d1t1044-4</LM>
   </w.rf>
   <form>vkládala</form>
   <lemma>vkládat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1044-5">
   <w.rf>
    <LM>w#w-d1t1044-5</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t1044-7">
   <w.rf>
    <LM>w#w-d1t1044-7</LM>
   </w.rf>
   <form>otvory</form>
   <lemma>otvor</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m114-d-id101181-punct">
   <w.rf>
    <LM>w#w-d-id101181-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1044-10">
   <w.rf>
    <LM>w#w-d1t1044-10</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1044-11">
   <w.rf>
    <LM>w#w-d1t1044-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1044-12">
   <w.rf>
    <LM>w#w-d1t1044-12</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1044-14">
   <w.rf>
    <LM>w#w-d1t1044-14</LM>
   </w.rf>
   <form>otvor</form>
   <lemma>otvor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1044-15">
   <w.rf>
    <LM>w#w-d1t1044-15</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t1044-16">
   <w.rf>
    <LM>w#w-d1t1044-16</LM>
   </w.rf>
   <form>propouštění</form>
   <lemma>propouštění_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m114-d1t1044-17">
   <w.rf>
    <LM>w#w-d1t1044-17</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d1t1044-18">
   <w.rf>
    <LM>w#w-d1t1044-18</LM>
   </w.rf>
   <form>zmenšil</form>
   <lemma>zmenšit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1e1000-x4-125">
   <w.rf>
    <LM>w#w-d1e1000-x4-125</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1000-x4">
  <m id="m114-d1t1050-4">
   <w.rf>
    <LM>w#w-d1t1050-4</LM>
   </w.rf>
   <form>Hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d1t1050-6">
   <w.rf>
    <LM>w#w-d1t1050-6</LM>
   </w.rf>
   <form>úkol</form>
   <lemma>úkol</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1050-7">
   <w.rf>
    <LM>w#w-d1t1050-7</LM>
   </w.rf>
   <form>obsluhy</form>
   <lemma>obsluha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d1t1050-3">
   <w.rf>
    <LM>w#w-d1t1050-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1050-8">
   <w.rf>
    <LM>w#w-d1t1050-8</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d1t1050-9">
   <w.rf>
    <LM>w#w-d1t1050-9</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m114-d1t1050-10">
   <w.rf>
    <LM>w#w-d1t1050-10</LM>
   </w.rf>
   <form>čistý</form>
   <lemma>čistý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m114-d1t1050-11">
   <w.rf>
    <LM>w#w-d1t1050-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1050-12">
   <w.rf>
    <LM>w#w-d1t1050-12</LM>
   </w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1050-13">
   <w.rf>
    <LM>w#w-d1t1050-13</LM>
   </w.rf>
   <form>ovladatelný</form>
   <lemma>ovladatelný_^(*8ádat)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m114-d-m-d1e1000-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1000-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1051-x2">
  <m id="m114-d1t1054-1">
   <w.rf>
    <LM>w#w-d1t1054-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1054-2">
   <w.rf>
    <LM>w#w-d1t1054-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1054-3">
   <w.rf>
    <LM>w#w-d1t1054-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1054-4">
   <w.rf>
    <LM>w#w-d1t1054-4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1054-5">
   <w.rf>
    <LM>w#w-d1t1054-5</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m114-d1t1054-6">
   <w.rf>
    <LM>w#w-d1t1054-6</LM>
   </w.rf>
   <form>čistit</form>
   <lemma>čistit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m114-d-id101710-punct">
   <w.rf>
    <LM>w#w-d-id101710-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1055-x2">
  <m id="m114-d1t1058-4">
   <w.rf>
    <LM>w#w-d1t1058-4</LM>
   </w.rf>
   <form>Jez</form>
   <lemma>jez</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1058-5">
   <w.rf>
    <LM>w#w-d1t1058-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1058-6">
   <w.rf>
    <LM>w#w-d1t1058-6</LM>
   </w.rf>
   <form>čistil</form>
   <lemma>čistit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1058-7">
   <w.rf>
    <LM>w#w-d1t1058-7</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1058-8">
   <w.rf>
    <LM>w#w-d1t1058-8</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1e1055-x2-134">
   <w.rf>
    <LM>w#w-d1e1055-x2-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-135">
  <m id="m114-d1t1058-10">
   <w.rf>
    <LM>w#w-d1t1058-10</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1058-11">
   <w.rf>
    <LM>w#w-d1t1058-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1058-12">
   <w.rf>
    <LM>w#w-d1t1058-12</LM>
   </w.rf>
   <form>průtok</form>
   <lemma>průtok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1058-13">
   <w.rf>
    <LM>w#w-d1t1058-13</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m114-d-id101959-punct">
   <w.rf>
    <LM>w#w-d-id101959-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1058-15">
   <w.rf>
    <LM>w#w-d1t1058-15</LM>
   </w.rf>
   <form>nenesla</form>
   <lemma>nést</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m114-d1t1058-16">
   <w.rf>
    <LM>w#w-d1t1058-16</LM>
   </w.rf>
   <form>řeka</form>
   <lemma>řeka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1058-17">
   <w.rf>
    <LM>w#w-d1t1058-17</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m114-d1t1058-18">
   <w.rf>
    <LM>w#w-d1t1058-18</LM>
   </w.rf>
   <form>splavenin</form>
   <lemma>splavenina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m114-135-587">
   <w.rf>
    <LM>w#w-135-587</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-588">
  <m id="m114-d1t1060-1">
   <w.rf>
    <LM>w#w-d1t1060-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1060-2">
   <w.rf>
    <LM>w#w-d1t1060-2</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m114-d1t1060-3">
   <w.rf>
    <LM>w#w-d1t1060-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1060-4">
   <w.rf>
    <LM>w#w-d1t1060-4</LM>
   </w.rf>
   <form>přehnala</form>
   <lemma>přehnat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m114-d1t1060-5">
   <w.rf>
    <LM>w#w-d1t1060-5</LM>
   </w.rf>
   <form>bouřka</form>
   <lemma>bouřka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1060-6">
   <w.rf>
    <LM>w#w-d1t1060-6</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t1060-8">
   <w.rf>
    <LM>w#w-d1t1060-8</LM>
   </w.rf>
   <form>Prahou</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m114-135-136">
   <w.rf>
    <LM>w#w-135-136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1060-11">
   <w.rf>
    <LM>w#w-d1t1060-11</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1060-12">
   <w.rf>
    <LM>w#w-d1t1060-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1060-13">
   <w.rf>
    <LM>w#w-d1t1060-13</LM>
   </w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m114-d1t1060-14">
   <w.rf>
    <LM>w#w-d1t1060-14</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d-id102252-punct">
   <w.rf>
    <LM>w#w-d-id102252-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1062-1">
   <w.rf>
    <LM>w#w-d1t1062-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1062-2">
   <w.rf>
    <LM>w#w-d1t1062-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1062-3">
   <w.rf>
    <LM>w#w-d1t1062-3</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m114-d1t1062-5">
   <w.rf>
    <LM>w#w-d1t1062-5</LM>
   </w.rf>
   <form>čistil</form>
   <lemma>čistit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1062-6">
   <w.rf>
    <LM>w#w-d1t1062-6</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1062-7">
   <w.rf>
    <LM>w#w-d1t1062-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m114-d1t1062-8">
   <w.rf>
    <LM>w#w-d1t1062-8</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m114-d1t1062-9">
   <w.rf>
    <LM>w#w-d1t1062-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1062-10">
   <w.rf>
    <LM>w#w-d1t1062-10</LM>
   </w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS6----------</tag>
  </m>
  <m id="m114-d1t1062-11">
   <w.rf>
    <LM>w#w-d1t1062-11</LM>
   </w.rf>
   <form>kuse</form>
   <lemma>kus</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d-m-d1e1055-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1055-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1063-x3">
  <m id="m114-d1t1070-1">
   <w.rf>
    <LM>w#w-d1t1070-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1070-2">
   <w.rf>
    <LM>w#w-d1t1070-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t1070-3">
   <w.rf>
    <LM>w#w-d1t1070-3</LM>
   </w.rf>
   <form>náročná</form>
   <lemma>náročný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t1070-4">
   <w.rf>
    <LM>w#w-d1t1070-4</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d-id102598-punct">
   <w.rf>
    <LM>w#w-d-id102598-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1071-x2">
  <m id="m114-d1t1074-1">
   <w.rf>
    <LM>w#w-d1t1074-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1074-2">
   <w.rf>
    <LM>w#w-d1t1074-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m114-d1t1074-7">
   <w.rf>
    <LM>w#w-d1t1074-7</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1074-8">
   <w.rf>
    <LM>w#w-d1t1074-8</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1074-9">
   <w.rf>
    <LM>w#w-d1t1074-9</LM>
   </w.rf>
   <form>namáhavá</form>
   <lemma>namáhavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1e1071-x2-141">
   <w.rf>
    <LM>w#w-d1e1071-x2-141</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d1t1076-1">
   <w.rf>
    <LM>w#w-d1t1076-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t1076-2">
   <w.rf>
    <LM>w#w-d1t1076-2</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m114-d1t1076-3">
   <w.rf>
    <LM>w#w-d1t1076-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1076-4">
   <w.rf>
    <LM>w#w-d1t1076-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1082-1">
   <w.rf>
    <LM>w#w-d1t1082-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t1082-2">
   <w.rf>
    <LM>w#w-d1t1082-2</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m114-d1t1082-3">
   <w.rf>
    <LM>w#w-d1t1082-3</LM>
   </w.rf>
   <form>postavu</form>
   <lemma>postava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t1082-4">
   <w.rf>
    <LM>w#w-d1t1082-4</LM>
   </w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m114-d-m-d1e1071-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1071-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1083-x2">
  <m id="m114-d1t1086-1">
   <w.rf>
    <LM>w#w-d1t1086-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1086-2">
   <w.rf>
    <LM>w#w-d1t1086-2</LM>
   </w.rf>
   <form>dlouhá</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m114-d1t1086-3">
   <w.rf>
    <LM>w#w-d1t1086-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1086-4">
   <w.rf>
    <LM>w#w-d1t1086-4</LM>
   </w.rf>
   <form>hůl</form>
   <lemma>hůl_^(klacek)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m114-d-id103123-punct">
   <w.rf>
    <LM>w#w-d-id103123-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1086-6">
   <w.rf>
    <LM>w#w-d1t1086-6</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS7----------</tag>
  </m>
  <m id="m114-d1t1086-7">
   <w.rf>
    <LM>w#w-d1t1086-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m114-d1t1086-8">
   <w.rf>
    <LM>w#w-d1t1086-8</LM>
   </w.rf>
   <form>čistilo</form>
   <lemma>čistit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d-id103178-punct">
   <w.rf>
    <LM>w#w-d-id103178-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1087-x2">
  <m id="m114-d1t1090-7">
   <w.rf>
    <LM>w#w-d1t1090-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>2.5</form>
   <lemma>2.5</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1t1090-10">
   <w.rf>
    <LM>w#w-d1t1090-10</LM>
   </w.rf>
   <form>m</form>
   <lemma>metr</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m114-d1t1090-12">
   <w.rf>
    <LM>w#w-d1t1090-12</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m114-d1t1090-11">
   <w.rf>
    <LM>w#w-d1t1090-11</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1e1087-x2-608">
   <w.rf>
    <LM>w#w-d1e1087-x2-608</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-609">
  <m id="m114-d1t1090-14">
   <w.rf>
    <LM>w#w-d1t1090-14</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1090-15">
   <w.rf>
    <LM>w#w-d1t1090-15</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1090-16">
   <w.rf>
    <LM>w#w-d1t1090-16</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m114-d1t1090-17">
   <w.rf>
    <LM>w#w-d1t1090-17</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1090-18">
   <w.rf>
    <LM>w#w-d1t1090-18</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1090-19">
   <w.rf>
    <LM>w#w-d1t1090-19</LM>
   </w.rf>
   <form>delší</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m114-d-id103513-punct">
   <w.rf>
    <LM>w#w-d-id103513-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1092-1">
   <w.rf>
    <LM>w#w-d1t1092-1</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m114-d-id103562-punct">
   <w.rf>
    <LM>w#w-d-id103562-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1092-4">
   <w.rf>
    <LM>w#w-d1t1092-4</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m114-d1t1092-5">
   <w.rf>
    <LM>w#w-d1t1092-5</LM>
   </w.rf>
   <form>dosáhly</form>
   <lemma>dosáhnout</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m114-d1t1092-6">
   <w.rf>
    <LM>w#w-d1t1092-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1092-7">
   <w.rf>
    <LM>w#w-d1t1092-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t1092-8">
   <w.rf>
    <LM>w#w-d1t1092-8</LM>
   </w.rf>
   <form>dno</form>
   <lemma>dno_^(např._propasti)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m114-609-610">
   <w.rf>
    <LM>w#w-609-610</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-611">
  <m id="m114-d1t1092-10">
   <w.rf>
    <LM>w#w-d1t1092-10</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m114-d1t1092-11">
   <w.rf>
    <LM>w#w-d1t1092-11</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m114-d1t1092-12">
   <w.rf>
    <LM>w#w-d1t1092-12</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m114-d1t1092-15">
   <w.rf>
    <LM>w#w-d1t1092-15</LM>
   </w.rf>
   <form>3</form>
   <lemma>3</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1t1092-16">
   <w.rf>
    <LM>w#w-d1t1092-16</LM>
   </w.rf>
   <form>m</form>
   <lemma>metr</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m114-d-m-d1e1087-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1087-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1093-x3">
  <m id="m114-d1t1102-1">
   <w.rf>
    <LM>w#w-d1t1102-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m114-d1t1102-2">
   <w.rf>
    <LM>w#w-d1t1102-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m114-d1t1102-3">
   <w.rf>
    <LM>w#w-d1t1102-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m114-d1t1102-4">
   <w.rf>
    <LM>w#w-d1t1102-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1102-5">
   <w.rf>
    <LM>w#w-d1t1102-5</LM>
   </w.rf>
   <form>jezu</form>
   <lemma>jez</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m114-d1t1102-6">
   <w.rf>
    <LM>w#w-d1t1102-6</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m114-d-id103973-punct">
   <w.rf>
    <LM>w#w-d-id103973-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1103-x2">
  <m id="m114-d1t1106-5">
   <w.rf>
    <LM>w#w-d1t1106-5</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1t1106-2">
   <w.rf>
    <LM>w#w-d1t1106-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m114-d1t1106-3">
   <w.rf>
    <LM>w#w-d1t1106-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m114-d1t1106-4">
   <w.rf>
    <LM>w#w-d1t1106-4</LM>
   </w.rf>
   <form>jez</form>
   <lemma>jez</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m114-d1t1106-6">
   <w.rf>
    <LM>w#w-d1t1106-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m114-d1t1106-7">
   <w.rf>
    <LM>w#w-d1t1106-7</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m114-d1t1110-1">
   <w.rf>
    <LM>w#w-d1t1110-1</LM>
   </w.rf>
   <form>1964</form>
   <lemma>1964</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1t1110-6">
   <w.rf>
    <LM>w#w-d1t1110-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m114-d1t1110-7">
   <w.rf>
    <LM>w#w-d1t1110-7</LM>
   </w.rf>
   <form>ukončil</form>
   <lemma>ukončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m114-d1t1110-8">
   <w.rf>
    <LM>w#w-d1t1110-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m114-d1t1110-9">
   <w.rf>
    <LM>w#w-d1t1110-9</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m114-d1t1110-10">
   <w.rf>
    <LM>w#w-d1t1110-10</LM>
   </w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m114-d1t1110-11">
   <w.rf>
    <LM>w#w-d1t1110-11</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m114-d1t1110-12">
   <w.rf>
    <LM>w#w-d1t1110-12</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m114-d1t1110-13">
   <w.rf>
    <LM>w#w-d1t1110-13</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m114-d1e1103-x2-10">
   <w.rf>
    <LM>w#w-d1e1103-x2-10</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1110-14">
   <w.rf>
    <LM>w#w-d1t1110-14</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d1e1103-x2-11">
   <w.rf>
    <LM>w#w-d1e1103-x2-11</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m114-d1t1110-15">
   <w.rf>
    <LM>w#w-d1t1110-15</LM>
   </w.rf>
   <form>července</form>
   <lemma>červenec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m114-d1t1112-1">
   <w.rf>
    <LM>w#w-d1t1112-1</LM>
   </w.rf>
   <form>2006</form>
   <lemma>2006</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m114-d-m-d1e1103-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1103-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m114-d1e1114-x2">
  <m id="m114-d1t1117-1">
   <w.rf>
    <LM>w#w-d1t1117-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m114-d1t1117-2">
   <w.rf>
    <LM>w#w-d1t1117-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m114-d1t1117-3">
   <w.rf>
    <LM>w#w-d1t1117-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m114-d1t1117-4">
   <w.rf>
    <LM>w#w-d1t1117-4</LM>
   </w.rf>
   <form>náplní</form>
   <lemma>náplň</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m114-d1t1117-5">
   <w.rf>
    <LM>w#w-d1t1117-5</LM>
   </w.rf>
   <form>vaší</form>
   <lemma>váš</lemma>
   <tag>PSFS2-P2-------</tag>
  </m>
  <m id="m114-d1t1117-6">
   <w.rf>
    <LM>w#w-d1t1117-6</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m114-d-m-d1e1114-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1114-x2-punct-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
