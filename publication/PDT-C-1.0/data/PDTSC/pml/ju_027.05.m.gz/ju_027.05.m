<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_027.05.w.gz" />
  </references>
 </head>
 <s id="m027-d1e1444-x2">
  <m id="m027-d1t1449-1">
   <w.rf>
    <LM>w#w-d1t1449-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t1449-2">
   <w.rf>
    <LM>w#w-d1t1449-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1449-6">
   <w.rf>
    <LM>w#w-d1t1449-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1449-7">
   <w.rf>
    <LM>w#w-d1t1449-7</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m027-d1t1449-8">
   <w.rf>
    <LM>w#w-d1t1449-8</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1t1449-9">
   <w.rf>
    <LM>w#w-d1t1449-9</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m027-d1t1449-11">
   <w.rf>
    <LM>w#w-d1t1449-11</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1449-12">
   <w.rf>
    <LM>w#w-d1t1449-12</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d-m-d1e1444-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1444-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1444-x3">
  <m id="m027-d1t1451-1">
   <w.rf>
    <LM>w#w-d1t1451-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1451-2">
   <w.rf>
    <LM>w#w-d1t1451-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m027-d1t1451-3">
   <w.rf>
    <LM>w#w-d1t1451-3</LM>
   </w.rf>
   <form>mrzí</form>
   <lemma>mrzet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e1444-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1444-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1452-x2">
  <m id="m027-d1t1457-1">
   <w.rf>
    <LM>w#w-d1t1457-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1457-3">
   <w.rf>
    <LM>w#w-d1t1457-3</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t1457-4">
   <w.rf>
    <LM>w#w-d1t1457-4</LM>
   </w.rf>
   <form>bratranec</form>
   <lemma>bratranec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id109196-punct">
   <w.rf>
    <LM>w#w-d-id109196-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1457-9">
   <w.rf>
    <LM>w#w-d1t1457-9</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1457-10">
   <w.rf>
    <LM>w#w-d1t1457-10</LM>
   </w.rf>
   <form>Štilip</form>
   <lemma>Štilip_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id109271-punct">
   <w.rf>
    <LM>w#w-d-id109271-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1459-1">
   <w.rf>
    <LM>w#w-d1t1459-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1459-2">
   <w.rf>
    <LM>w#w-d1t1459-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1461-1">
   <w.rf>
    <LM>w#w-d1t1461-1</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t1461-2">
   <w.rf>
    <LM>w#w-d1t1461-2</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m027-d1t1461-3">
   <w.rf>
    <LM>w#w-d1t1461-3</LM>
   </w.rf>
   <form>tatínka</form>
   <lemma>tatínek</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m027-d1t1461-4">
   <w.rf>
    <LM>w#w-d1t1461-4</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e1452-x2-204">
   <w.rf>
    <LM>w#w-d1e1452-x2-204</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1463-1">
   <w.rf>
    <LM>w#w-d1t1463-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1463-2">
   <w.rf>
    <LM>w#w-d1t1463-2</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1463-3">
   <w.rf>
    <LM>w#w-d1t1463-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1463-4">
   <w.rf>
    <LM>w#w-d1t1463-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1463-5">
   <w.rf>
    <LM>w#w-d1t1463-5</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t1463-6">
   <w.rf>
    <LM>w#w-d1t1463-6</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m027-d1t1463-7">
   <w.rf>
    <LM>w#w-d1t1463-7</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1e1452-x2-628">
   <w.rf>
    <LM>w#w-d1e1452-x2-628</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1452-x2-214">
   <w.rf>
    <LM>w#w-d1e1452-x2-214</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1452-x2-215">
   <w.rf>
    <LM>w#w-d1e1452-x2-215</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-630">
  <m id="m027-d1t1463-10">
   <w.rf>
    <LM>w#w-d1t1463-10</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m027-d1t1463-9">
   <w.rf>
    <LM>w#w-d1t1463-9</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t1463-11">
   <w.rf>
    <LM>w#w-d1t1463-11</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1463-12">
   <w.rf>
    <LM>w#w-d1t1463-12</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m027-d1t1463-13">
   <w.rf>
    <LM>w#w-d1t1463-13</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d-id109656-punct">
   <w.rf>
    <LM>w#w-d-id109656-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1463-15">
   <w.rf>
    <LM>w#w-d1t1463-15</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1463-16">
   <w.rf>
    <LM>w#w-d1t1463-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1463-17">
   <w.rf>
    <LM>w#w-d1t1463-17</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-630-632">
   <w.rf>
    <LM>w#w-630-632</LM>
   </w.rf>
   <form>ony</form>
   <lemma>on-1</lemma>
   <tag>PEFP1--3-------</tag>
  </m>
  <m id="m027-630-634">
   <w.rf>
    <LM>w#w-630-634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-636">
  <m id="m027-d1t1466-3">
   <w.rf>
    <LM>w#w-d1t1466-3</LM>
   </w.rf>
   <form>Alenka</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t1466-5">
   <w.rf>
    <LM>w#w-d1t1466-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1466-6">
   <w.rf>
    <LM>w#w-d1t1466-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1466-7">
   <w.rf>
    <LM>w#w-d1t1466-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m027-d1t1466-8">
   <w.rf>
    <LM>w#w-d1t1466-8</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m027-636-638">
   <w.rf>
    <LM>w#w-636-638</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1466-15">
   <w.rf>
    <LM>w#w-d1t1466-15</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1466-13">
   <w.rf>
    <LM>w#w-d1t1466-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1466-14">
   <w.rf>
    <LM>w#w-d1t1466-14</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m027-d1t1466-11">
   <w.rf>
    <LM>w#w-d1t1466-11</LM>
   </w.rf>
   <form>Zdeňka</form>
   <lemma>Zdeňka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-636-247">
   <w.rf>
    <LM>w#w-636-247</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1466-16">
   <w.rf>
    <LM>w#w-d1t1466-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1466-17">
   <w.rf>
    <LM>w#w-d1t1466-17</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t1466-18">
   <w.rf>
    <LM>w#w-d1t1466-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1466-19">
   <w.rf>
    <LM>w#w-d1t1466-19</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1466-20">
   <w.rf>
    <LM>w#w-d1t1466-20</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m027-636-640">
   <w.rf>
    <LM>w#w-636-640</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1466-21">
   <w.rf>
    <LM>w#w-d1t1466-21</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1466-23">
   <w.rf>
    <LM>w#w-d1t1466-23</LM>
   </w.rf>
   <form>Liduš</form>
   <lemma>Liduš_;Y_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m027-636-642">
   <w.rf>
    <LM>w#w-636-642</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1468-1">
   <w.rf>
    <LM>w#w-d1t1468-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1468-2">
   <w.rf>
    <LM>w#w-d1t1468-2</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m027-d1t1468-3">
   <w.rf>
    <LM>w#w-d1t1468-3</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1468-4">
   <w.rf>
    <LM>w#w-d1t1468-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1468-6">
   <w.rf>
    <LM>w#w-d1t1468-6</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1452-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1452-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1469-x2">
  <m id="m027-d1t1474-1">
   <w.rf>
    <LM>w#w-d1t1474-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1474-2">
   <w.rf>
    <LM>w#w-d1t1474-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1474-3">
   <w.rf>
    <LM>w#w-d1t1474-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1474-4">
   <w.rf>
    <LM>w#w-d1t1474-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1474-6">
   <w.rf>
    <LM>w#w-d1t1474-6</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1474-7">
   <w.rf>
    <LM>w#w-d1t1474-7</LM>
   </w.rf>
   <form>Štilip</form>
   <lemma>Štilip_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id110288-punct">
   <w.rf>
    <LM>w#w-d-id110288-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1474-10">
   <w.rf>
    <LM>w#w-d1t1474-10</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m027-d1t1474-11">
   <w.rf>
    <LM>w#w-d1t1474-11</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1474-12">
   <w.rf>
    <LM>w#w-d1t1474-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1474-14">
   <w.rf>
    <LM>w#w-d1t1474-14</LM>
   </w.rf>
   <form>Klabavě</form>
   <lemma>Klabava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1469-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1469-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1479-x2">
  <m id="m027-d1t1484-2">
   <w.rf>
    <LM>w#w-d1t1484-2</LM>
   </w.rf>
   <form>Dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1484-3">
   <w.rf>
    <LM>w#w-d1t1484-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1484-5">
   <w.rf>
    <LM>w#w-d1t1484-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t1484-6">
   <w.rf>
    <LM>w#w-d1t1484-6</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1484-11">
   <w.rf>
    <LM>w#w-d1t1484-11</LM>
   </w.rf>
   <form>Vlastík</form>
   <lemma>Vlastík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1484-13">
   <w.rf>
    <LM>w#w-d1t1484-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1484-14">
   <w.rf>
    <LM>w#w-d1t1484-14</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e1479-x2-702">
   <w.rf>
    <LM>w#w-d1e1479-x2-702</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1484-15">
   <w.rf>
    <LM>w#w-d1t1484-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1484-16">
   <w.rf>
    <LM>w#w-d1t1484-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1484-17">
   <w.rf>
    <LM>w#w-d1t1484-17</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1484-18">
   <w.rf>
    <LM>w#w-d1t1484-18</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m027-d1t1484-19">
   <w.rf>
    <LM>w#w-d1t1484-19</LM>
   </w.rf>
   <form>manžela</form>
   <lemma>manžel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m027-d1t1484-23">
   <w.rf>
    <LM>w#w-d1t1484-23</LM>
   </w.rf>
   <form>Mirek</form>
   <lemma>Mirek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e1479-x2-704">
   <w.rf>
    <LM>w#w-d1e1479-x2-704</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-706_2">
  <m id="m027-d1t1484-26">
   <w.rf>
    <LM>w#w-d1t1484-26</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1484-27">
   <w.rf>
    <LM>w#w-d1t1484-27</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1484-28">
   <w.rf>
    <LM>w#w-d1t1484-28</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m027-d1t1484-29">
   <w.rf>
    <LM>w#w-d1t1484-29</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id110852-punct">
   <w.rf>
    <LM>w#w-d-id110852-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1484-31">
   <w.rf>
    <LM>w#w-d1t1484-31</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m027-d1t1484-32">
   <w.rf>
    <LM>w#w-d1t1484-32</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m027-d1t1484-33">
   <w.rf>
    <LM>w#w-d1t1484-33</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1484-34">
   <w.rf>
    <LM>w#w-d1t1484-34</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m027-d1t1484-35">
   <w.rf>
    <LM>w#w-d1t1484-35</LM>
   </w.rf>
   <form>bratři</form>
   <lemma>bratr</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-706_2-712">
   <w.rf>
    <LM>w#w-706_2-712</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-714_1">
  <m id="m027-d1t1486-3">
   <w.rf>
    <LM>w#w-d1t1486-3</LM>
   </w.rf>
   <form>Mirek</form>
   <lemma>Mirek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id111004-punct">
   <w.rf>
    <LM>w#w-d-id111004-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1486-6">
   <w.rf>
    <LM>w#w-d1t1486-6</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t1486-8">
   <w.rf>
    <LM>w#w-d1t1486-8</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-id111053-punct">
   <w.rf>
    <LM>w#w-d-id111053-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1486-11">
   <w.rf>
    <LM>w#w-d1t1486-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1486-12">
   <w.rf>
    <LM>w#w-d1t1486-12</LM>
   </w.rf>
   <form>lékař</form>
   <lemma>lékař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id111108-punct">
   <w.rf>
    <LM>w#w-d-id111108-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1486-16">
   <w.rf>
    <LM>w#w-d1t1486-16</LM>
   </w.rf>
   <form>chirurg</form>
   <lemma>chirurg</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1479-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1479-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1495-x2">
  <m id="m027-d1t1498-2">
   <w.rf>
    <LM>w#w-d1t1498-2</LM>
   </w.rf>
   <form>Žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1498-3">
   <w.rf>
    <LM>w#w-d1t1498-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1498-4">
   <w.rf>
    <LM>w#w-d1t1498-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1498-6">
   <w.rf>
    <LM>w#w-d1t1498-6</LM>
   </w.rf>
   <form>Počátcích</form>
   <lemma>Počátky_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m027-d1t1498-8">
   <w.rf>
    <LM>w#w-d1t1498-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1498-10">
   <w.rf>
    <LM>w#w-d1t1498-10</LM>
   </w.rf>
   <form>Vysočině</form>
   <lemma>Vysočina_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t1500-1">
   <w.rf>
    <LM>w#w-d1t1500-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1500-2">
   <w.rf>
    <LM>w#w-d1t1500-2</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t1500-3">
   <w.rf>
    <LM>w#w-d1t1500-3</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m027-d1t1500-4">
   <w.rf>
    <LM>w#w-d1t1500-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1500-6">
   <w.rf>
    <LM>w#w-d1t1500-6</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id111527-punct">
   <w.rf>
    <LM>w#w-d-id111527-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1500-9">
   <w.rf>
    <LM>w#w-d1t1500-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1500-10">
   <w.rf>
    <LM>w#w-d1t1500-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1502-2">
   <w.rf>
    <LM>w#w-d1t1502-2</LM>
   </w.rf>
   <form>dopravní</form>
   <lemma>dopravní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1t1502-1">
   <w.rf>
    <LM>w#w-d1t1502-1</LM>
   </w.rf>
   <form>inženýr</form>
   <lemma>inženýr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1502-3">
   <w.rf>
    <LM>w#w-d1t1502-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1502-4">
   <w.rf>
    <LM>w#w-d1t1502-4</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t1502-5">
   <w.rf>
    <LM>w#w-d1t1502-5</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1502-6">
   <w.rf>
    <LM>w#w-d1t1502-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1502-8">
   <w.rf>
    <LM>w#w-d1t1502-8</LM>
   </w.rf>
   <form>Břeclavi</form>
   <lemma>Břeclav_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1e1495-x2-738">
   <w.rf>
    <LM>w#w-d1e1495-x2-738</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-740">
  <m id="m027-d1t1504-2">
   <w.rf>
    <LM>w#w-d1t1504-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1504-3">
   <w.rf>
    <LM>w#w-d1t1504-3</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1504-4">
   <w.rf>
    <LM>w#w-d1t1504-4</LM>
   </w.rf>
   <form>slouží</form>
   <lemma>sloužit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1504-7">
   <w.rf>
    <LM>w#w-d1t1504-7</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t1504-8">
   <w.rf>
    <LM>w#w-d1t1504-8</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t1504-9">
   <w.rf>
    <LM>w#w-d1t1504-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1504-10">
   <w.rf>
    <LM>w#w-d1t1504-10</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1504-13">
   <w.rf>
    <LM>w#w-d1t1504-13</LM>
   </w.rf>
   <form>náměstka</form>
   <lemma>náměstek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m027-d1t1504-14">
   <w.rf>
    <LM>w#w-d1t1504-14</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1504-15">
   <w.rf>
    <LM>w#w-d1t1504-15</LM>
   </w.rf>
   <form>dopravu</form>
   <lemma>doprava-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1506-1">
   <w.rf>
    <LM>w#w-d1t1506-1</LM>
   </w.rf>
   <form>náčelníkovi</form>
   <lemma>náčelník</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m027-d1t1506-2">
   <w.rf>
    <LM>w#w-d1t1506-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1506-3">
   <w.rf>
    <LM>w#w-d1t1506-3</LM>
   </w.rf>
   <form>stanici</form>
   <lemma>stanice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t1506-5">
   <w.rf>
    <LM>w#w-d1t1506-5</LM>
   </w.rf>
   <form>Břeclav</form>
   <lemma>Břeclav_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1495-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1495-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1507-x3">
  <m id="m027-d1t1516-2">
   <w.rf>
    <LM>w#w-d1t1516-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1516-3">
   <w.rf>
    <LM>w#w-d1t1516-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1516-4">
   <w.rf>
    <LM>w#w-d1t1516-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t1516-5">
   <w.rf>
    <LM>w#w-d1t1516-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1516-6">
   <w.rf>
    <LM>w#w-d1t1516-6</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1-------</tag>
  </m>
  <m id="m027-d1t1516-7">
   <w.rf>
    <LM>w#w-d1t1516-7</LM>
   </w.rf>
   <form>svatby</form>
   <lemma>svatba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1507-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1507-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1517-x3">
  <m id="m027-d1t1524-1">
   <w.rf>
    <LM>w#w-d1t1524-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1524-2">
   <w.rf>
    <LM>w#w-d1t1524-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1524-3">
   <w.rf>
    <LM>w#w-d1t1524-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1524-4">
   <w.rf>
    <LM>w#w-d1t1524-4</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-id112338-punct">
   <w.rf>
    <LM>w#w-d-id112338-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1526-x2">
  <m id="m027-d1t1529-1">
   <w.rf>
    <LM>w#w-d1t1529-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1529-2">
   <w.rf>
    <LM>w#w-d1t1529-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1529-3">
   <w.rf>
    <LM>w#w-d1t1529-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1529-5">
   <w.rf>
    <LM>w#w-d1t1529-5</LM>
   </w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-2_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d-id112472-punct">
   <w.rf>
    <LM>w#w-d-id112472-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1529-10">
   <w.rf>
    <LM>w#w-d1t1529-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1529-11">
   <w.rf>
    <LM>w#w-d1t1529-11</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m027-d1t1529-12">
   <w.rf>
    <LM>w#w-d1t1529-12</LM>
   </w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m027-d-id112557-punct">
   <w.rf>
    <LM>w#w-d-id112557-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1529-14">
   <w.rf>
    <LM>w#w-d1t1529-14</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1529-15">
   <w.rf>
    <LM>w#w-d1t1529-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1529-16">
   <w.rf>
    <LM>w#w-d1t1529-16</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1529-17">
   <w.rf>
    <LM>w#w-d1t1529-17</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d-id112628-punct">
   <w.rf>
    <LM>w#w-d-id112628-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1529-19">
   <w.rf>
    <LM>w#w-d1t1529-19</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1529-20">
   <w.rf>
    <LM>w#w-d1t1529-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1529-21">
   <w.rf>
    <LM>w#w-d1t1529-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1529-22">
   <w.rf>
    <LM>w#w-d1t1529-22</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t1529-23">
   <w.rf>
    <LM>w#w-d1t1529-23</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1529-25">
   <w.rf>
    <LM>w#w-d1t1529-25</LM>
   </w.rf>
   <form>Litohlav</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m027-d1e1526-x2-784">
   <w.rf>
    <LM>w#w-d1e1526-x2-784</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-786">
  <m id="m027-d1t1531-2">
   <w.rf>
    <LM>w#w-d1t1531-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1531-4">
   <w.rf>
    <LM>w#w-d1t1531-4</LM>
   </w.rf>
   <form>19</form>
   <lemma>19</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m027-786-788">
   <w.rf>
    <LM>w#w-786-788</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>června</form>
   <lemma>červen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-d1t1531-6">
   <w.rf>
    <LM>w#w-d1t1531-6</LM>
   </w.rf>
   <form>1965</form>
   <lemma>1965</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m027-786-798">
   <w.rf>
    <LM>w#w-786-798</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1532-x3">
  <m id="m027-d1t1539-1">
   <w.rf>
    <LM>w#w-d1t1539-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m027-d1t1539-2">
   <w.rf>
    <LM>w#w-d1t1539-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m027-d1t1539-3">
   <w.rf>
    <LM>w#w-d1t1539-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1539-4">
   <w.rf>
    <LM>w#w-d1t1539-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d-id113044-punct">
   <w.rf>
    <LM>w#w-d-id113044-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1540-x2">
  <m id="m027-d1t1543-1">
   <w.rf>
    <LM>w#w-d1t1543-1</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1543-2">
   <w.rf>
    <LM>w#w-d1t1543-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t1543-3">
   <w.rf>
    <LM>w#w-d1t1543-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1543-4">
   <w.rf>
    <LM>w#w-d1t1543-4</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1t1543-5">
   <w.rf>
    <LM>w#w-d1t1543-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1540-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1540-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1544-x3">
  <m id="m027-d1t1551-1">
   <w.rf>
    <LM>w#w-d1t1551-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t1551-3">
   <w.rf>
    <LM>w#w-d1t1551-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1551-4">
   <w.rf>
    <LM>w#w-d1t1551-4</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-id113383-punct">
   <w.rf>
    <LM>w#w-d-id113383-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1552-x2">
  <m id="m027-d1t1555-1">
   <w.rf>
    <LM>w#w-d1t1555-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m027-d1t1555-2">
   <w.rf>
    <LM>w#w-d1t1555-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1555-3">
   <w.rf>
    <LM>w#w-d1t1555-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1555-4">
   <w.rf>
    <LM>w#w-d1t1555-4</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1e1552-x2-812">
   <w.rf>
    <LM>w#w-d1e1552-x2-812</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1555-5">
   <w.rf>
    <LM>w#w-d1t1555-5</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d-m-d1e1552-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1552-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1556-x2">
  <m id="m027-d1t1559-1">
   <w.rf>
    <LM>w#w-d1t1559-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t1559-2">
   <w.rf>
    <LM>w#w-d1t1559-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1t1559-3">
   <w.rf>
    <LM>w#w-d1t1559-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1559-4">
   <w.rf>
    <LM>w#w-d1t1559-4</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1559-5">
   <w.rf>
    <LM>w#w-d1t1559-5</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id113653-punct">
   <w.rf>
    <LM>w#w-d-id113653-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1560-x2">
  <m id="m027-d1t1563-1">
   <w.rf>
    <LM>w#w-d1t1563-1</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1563-2">
   <w.rf>
    <LM>w#w-d1t1563-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1t1563-3">
   <w.rf>
    <LM>w#w-d1t1563-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1563-4">
   <w.rf>
    <LM>w#w-d1t1563-4</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1563-5">
   <w.rf>
    <LM>w#w-d1t1563-5</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e1560-x2-826">
   <w.rf>
    <LM>w#w-d1e1560-x2-826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-828">
  <m id="m027-d1t1563-6">
   <w.rf>
    <LM>w#w-d1t1563-6</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1563-7">
   <w.rf>
    <LM>w#w-d1t1563-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1563-8">
   <w.rf>
    <LM>w#w-d1t1563-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1563-9">
   <w.rf>
    <LM>w#w-d1t1563-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1563-10">
   <w.rf>
    <LM>w#w-d1t1563-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t1563-11">
   <w.rf>
    <LM>w#w-d1t1563-11</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m027-d1t1563-12">
   <w.rf>
    <LM>w#w-d1t1563-12</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1563-13">
   <w.rf>
    <LM>w#w-d1t1563-13</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1563-14">
   <w.rf>
    <LM>w#w-d1t1563-14</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m027-d1t1563-15">
   <w.rf>
    <LM>w#w-d1t1563-15</LM>
   </w.rf>
   <form>rozvedli</form>
   <lemma>rozvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d-id113947-punct">
   <w.rf>
    <LM>w#w-d-id113947-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1563-17">
   <w.rf>
    <LM>w#w-d1t1563-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1563-18">
   <w.rf>
    <LM>w#w-d1t1563-18</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1565-1">
   <w.rf>
    <LM>w#w-d1t1565-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1565-2">
   <w.rf>
    <LM>w#w-d1t1565-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1565-4">
   <w.rf>
    <LM>w#w-d1t1565-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1565-5">
   <w.rf>
    <LM>w#w-d1t1565-5</LM>
   </w.rf>
   <form>jediný</form>
   <lemma>jediný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1t1565-6">
   <w.rf>
    <LM>w#w-d1t1565-6</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1565-7">
   <w.rf>
    <LM>w#w-d1t1565-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t1565-8">
   <w.rf>
    <LM>w#w-d1t1565-8</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m027-d1t1565-9">
   <w.rf>
    <LM>w#w-d1t1565-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1565-10">
   <w.rf>
    <LM>w#w-d1t1565-10</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1565-11">
   <w.rf>
    <LM>w#w-d1t1565-11</LM>
   </w.rf>
   <form>prožít</form>
   <lemma>prožít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m027-d1t1565-12">
   <w.rf>
    <LM>w#w-d1t1565-12</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t1565-13">
   <w.rf>
    <LM>w#w-d1t1565-13</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-828-830">
   <w.rf>
    <LM>w#w-828-830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-832">
  <m id="m027-d1t1565-16">
   <w.rf>
    <LM>w#w-d1t1565-16</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1567-1">
   <w.rf>
    <LM>w#w-d1t1567-1</LM>
   </w.rf>
   <form>osud</form>
   <lemma>osud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1t1567-3">
   <w.rf>
    <LM>w#w-d1t1567-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t1567-4">
   <w.rf>
    <LM>w#w-d1t1567-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t1567-2">
   <w.rf>
    <LM>w#w-d1t1567-2</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1567-5">
   <w.rf>
    <LM>w#w-d1t1567-5</LM>
   </w.rf>
   <form>zamotal</form>
   <lemma>zamotat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d-id114325-punct">
   <w.rf>
    <LM>w#w-d-id114325-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1567-7">
   <w.rf>
    <LM>w#w-d1t1567-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1567-8">
   <w.rf>
    <LM>w#w-d1t1567-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1567-9">
   <w.rf>
    <LM>w#w-d1t1567-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1567-11">
   <w.rf>
    <LM>w#w-d1t1567-11</LM>
   </w.rf>
   <form>rozvedli</form>
   <lemma>rozvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d-id114427-punct">
   <w.rf>
    <LM>w#w-d-id114427-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1567-14">
   <w.rf>
    <LM>w#w-d1t1567-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1569-2">
   <w.rf>
    <LM>w#w-d1t1569-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1569-3">
   <w.rf>
    <LM>w#w-d1t1569-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1569-4">
   <w.rf>
    <LM>w#w-d1t1569-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t1569-5">
   <w.rf>
    <LM>w#w-d1t1569-5</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m027-d1t1569-6">
   <w.rf>
    <LM>w#w-d1t1569-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>šťastná</form>
   <lemma>šťastný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e1560-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1560-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1570-x2">
  <m id="m027-d1t1573-1">
   <w.rf>
    <LM>w#w-d1t1573-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1573-2">
   <w.rf>
    <LM>w#w-d1t1573-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t1573-3">
   <w.rf>
    <LM>w#w-d1t1573-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1573-4">
   <w.rf>
    <LM>w#w-d1t1573-4</LM>
   </w.rf>
   <form>rozešli</form>
   <lemma>rozejít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d-id114668-punct">
   <w.rf>
    <LM>w#w-d-id114668-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1574-x2">
  <m id="m027-d1t1577-2">
   <w.rf>
    <LM>w#w-d1t1577-2</LM>
   </w.rf>
   <form>Rozešli</form>
   <lemma>rozejít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t1577-3">
   <w.rf>
    <LM>w#w-d1t1577-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1577-4">
   <w.rf>
    <LM>w#w-d1t1577-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d-id114792-punct">
   <w.rf>
    <LM>w#w-d-id114792-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1577-6">
   <w.rf>
    <LM>w#w-d1t1577-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1577-7">
   <w.rf>
    <LM>w#w-d1t1577-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1577-8">
   <w.rf>
    <LM>w#w-d1t1577-8</LM>
   </w.rf>
   <form>našla</form>
   <lemma>najít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m027-d1t1577-9">
   <w.rf>
    <LM>w#w-d1t1577-9</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t1577-10">
   <w.rf>
    <LM>w#w-d1t1577-10</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id114878-punct">
   <w.rf>
    <LM>w#w-d-id114878-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1577-12">
   <w.rf>
    <LM>w#w-d1t1577-12</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m027-d1t1577-14">
   <w.rf>
    <LM>w#w-d1t1577-14</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t1577-15">
   <w.rf>
    <LM>w#w-d1t1577-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t1579-1">
   <w.rf>
    <LM>w#w-d1t1579-1</LM>
   </w.rf>
   <form>manželství</form>
   <lemma>manželství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d1t1579-2">
   <w.rf>
    <LM>w#w-d1t1579-2</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1579-3">
   <w.rf>
    <LM>w#w-d1t1579-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1581-1">
   <w.rf>
    <LM>w#w-d1t1581-1</LM>
   </w.rf>
   <form>pokazila</form>
   <lemma>pokazit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m027-d1t1581-2">
   <w.rf>
    <LM>w#w-d1t1581-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1581-3">
   <w.rf>
    <LM>w#w-d1t1581-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1581-4">
   <w.rf>
    <LM>w#w-d1t1581-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1581-5">
   <w.rf>
    <LM>w#w-d1t1581-5</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m027-d1t1581-6">
   <w.rf>
    <LM>w#w-d1t1581-6</LM>
   </w.rf>
   <form>rozumný</form>
   <lemma>rozumný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1e1574-x2-411">
   <w.rf>
    <LM>w#w-d1e1574-x2-411</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-412">
  <m id="m027-d1t1581-8">
   <w.rf>
    <LM>w#w-d1t1581-8</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1581-9">
   <w.rf>
    <LM>w#w-d1t1581-9</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m027-d1t1581-10">
   <w.rf>
    <LM>w#w-d1t1581-10</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1581-11">
   <w.rf>
    <LM>w#w-d1t1581-11</LM>
   </w.rf>
   <form>litoval</form>
   <lemma>litovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1e1574-x2-852">
   <w.rf>
    <LM>w#w-d1e1574-x2-852</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-854">
  <m id="m027-d1t1581-14">
   <w.rf>
    <LM>w#w-d1t1581-14</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1581-13">
   <w.rf>
    <LM>w#w-d1t1581-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1581-16">
   <w.rf>
    <LM>w#w-d1t1581-16</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t1581-17">
   <w.rf>
    <LM>w#w-d1t1581-17</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1t1581-15">
   <w.rf>
    <LM>w#w-d1t1581-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1581-18">
   <w.rf>
    <LM>w#w-d1t1581-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1581-20">
   <w.rf>
    <LM>w#w-d1t1581-20</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t1581-19">
   <w.rf>
    <LM>w#w-d1t1581-19</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1581-21">
   <w.rf>
    <LM>w#w-d1t1581-21</LM>
   </w.rf>
   <form>zamotal</form>
   <lemma>zamotat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d-m-d1e1574-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1574-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1582-x2">
  <m id="m027-d1t1585-1">
   <w.rf>
    <LM>w#w-d1t1585-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e1582-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1582-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1586-x2">
  <m id="m027-d1t1589-1">
   <w.rf>
    <LM>w#w-d1t1589-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1589-2">
   <w.rf>
    <LM>w#w-d1t1589-2</LM>
   </w.rf>
   <form>stýkáme</form>
   <lemma>stýkat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1589-3">
   <w.rf>
    <LM>w#w-d1t1589-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1589-5">
   <w.rf>
    <LM>w#w-d1t1589-5</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e1586-x2-866">
   <w.rf>
    <LM>w#w-d1e1586-x2-866</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1589-7">
   <w.rf>
    <LM>w#w-d1t1589-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1589-8">
   <w.rf>
    <LM>w#w-d1t1589-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t1589-9">
   <w.rf>
    <LM>w#w-d1t1589-9</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m027-d1t1589-10">
   <w.rf>
    <LM>w#w-d1t1589-10</LM>
   </w.rf>
   <form>sourozenci</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m027-d-id115590-punct">
   <w.rf>
    <LM>w#w-d-id115590-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1591-1">
   <w.rf>
    <LM>w#w-d1t1591-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1591-2">
   <w.rf>
    <LM>w#w-d1t1591-2</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1591-3">
   <w.rf>
    <LM>w#w-d1t1591-3</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m027-d-id115654-punct">
   <w.rf>
    <LM>w#w-d-id115654-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1591-5">
   <w.rf>
    <LM>w#w-d1t1591-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1593-2">
   <w.rf>
    <LM>w#w-d1t1593-2</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1593-1">
   <w.rf>
    <LM>w#w-d1t1593-1</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m027-d1t1593-3">
   <w.rf>
    <LM>w#w-d1t1593-3</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWYP4----------</tag>
  </m>
  <m id="m027-d1t1593-4">
   <w.rf>
    <LM>w#w-d1t1593-4</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1e1586-x2-418">
   <w.rf>
    <LM>w#w-d1e1586-x2-418</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-419">
  <m id="m027-d1t1593-6">
   <w.rf>
    <LM>w#w-d1t1593-6</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1593-8">
   <w.rf>
    <LM>w#w-d1t1593-8</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1593-9">
   <w.rf>
    <LM>w#w-d1t1593-9</LM>
   </w.rf>
   <form>přátelský</form>
   <lemma>přátelský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t1593-10">
   <w.rf>
    <LM>w#w-d1t1593-10</LM>
   </w.rf>
   <form>vztah</form>
   <lemma>vztah</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1e1586-x2-868">
   <w.rf>
    <LM>w#w-d1e1586-x2-868</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-870">
  <m id="m027-d1t1593-12">
   <w.rf>
    <LM>w#w-d1t1593-12</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1595-1">
   <w.rf>
    <LM>w#w-d1t1595-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1595-2">
   <w.rf>
    <LM>w#w-d1t1595-2</LM>
   </w.rf>
   <form>manželství</form>
   <lemma>manželství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m027-d1t1595-3">
   <w.rf>
    <LM>w#w-d1t1595-3</LM>
   </w.rf>
   <form>neskončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m027-d1t1595-4">
   <w.rf>
    <LM>w#w-d1t1595-4</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id115965-punct">
   <w.rf>
    <LM>w#w-d-id115965-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1595-7">
   <w.rf>
    <LM>w#w-d1t1595-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1595-8">
   <w.rf>
    <LM>w#w-d1t1595-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1595-9">
   <w.rf>
    <LM>w#w-d1t1595-9</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1595-11">
   <w.rf>
    <LM>w#w-d1t1595-11</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1595-10">
   <w.rf>
    <LM>w#w-d1t1595-10</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e1586-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1586-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1599-x2">
  <m id="m027-d1t1604-1">
   <w.rf>
    <LM>w#w-d1t1604-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1604-2">
   <w.rf>
    <LM>w#w-d1t1604-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1604-3">
   <w.rf>
    <LM>w#w-d1t1604-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1604-4">
   <w.rf>
    <LM>w#w-d1t1604-4</LM>
   </w.rf>
   <form>konala</form>
   <lemma>konat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1604-5">
   <w.rf>
    <LM>w#w-d1t1604-5</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t1604-6">
   <w.rf>
    <LM>w#w-d1t1604-6</LM>
   </w.rf>
   <form>hostina</form>
   <lemma>hostina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id116219-punct">
   <w.rf>
    <LM>w#w-d-id116219-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1607-x2">
  <m id="m027-d1t1610-1">
   <w.rf>
    <LM>w#w-d1t1610-1</LM>
   </w.rf>
   <form>Svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t1610-2">
   <w.rf>
    <LM>w#w-d1t1610-2</LM>
   </w.rf>
   <form>hostinu</form>
   <lemma>hostina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1610-3">
   <w.rf>
    <LM>w#w-d1t1610-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1610-4">
   <w.rf>
    <LM>w#w-d1t1610-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1610-5">
   <w.rf>
    <LM>w#w-d1t1610-5</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e1607-x2-429">
   <w.rf>
    <LM>w#w-d1e1607-x2-429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-430">
  <m id="m027-d1t1612-1">
   <w.rf>
    <LM>w#w-d1t1612-1</LM>
   </w.rf>
   <form>Svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1612-3">
   <w.rf>
    <LM>w#w-d1t1612-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1612-4">
   <w.rf>
    <LM>w#w-d1t1612-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1612-6">
   <w.rf>
    <LM>w#w-d1t1612-6</LM>
   </w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-2_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d1t1612-8">
   <w.rf>
    <LM>w#w-d1t1612-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1612-10">
   <w.rf>
    <LM>w#w-d1t1612-10</LM>
   </w.rf>
   <form>obecním</form>
   <lemma>obecní_^(v_obci;_např._úřad)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m027-d1t1612-11">
   <w.rf>
    <LM>w#w-d1t1612-11</LM>
   </w.rf>
   <form>úřadě</form>
   <lemma>úřad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m027-d1t1612-13">
   <w.rf>
    <LM>w#w-d1t1612-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1612-14">
   <w.rf>
    <LM>w#w-d1t1612-14</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1614-1">
   <w.rf>
    <LM>w#w-d1t1614-1</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t1614-2">
   <w.rf>
    <LM>w#w-d1t1614-2</LM>
   </w.rf>
   <form>hostinu</form>
   <lemma>hostina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1612-15">
   <w.rf>
    <LM>w#w-d1t1612-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1612-16">
   <w.rf>
    <LM>w#w-d1t1612-16</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1614-3">
   <w.rf>
    <LM>w#w-d1t1614-3</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e1607-x2-908">
   <w.rf>
    <LM>w#w-d1e1607-x2-908</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-910">
  <m id="m027-d1t1614-4">
   <w.rf>
    <LM>w#w-d1t1614-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1614-5">
   <w.rf>
    <LM>w#w-d1t1614-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m027-d1t1614-6">
   <w.rf>
    <LM>w#w-d1t1614-6</LM>
   </w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m027-d1t1614-8">
   <w.rf>
    <LM>w#w-d1t1614-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1614-9">
   <w.rf>
    <LM>w#w-d1t1614-9</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1614-10">
   <w.rf>
    <LM>w#w-d1t1614-10</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m027-d1t1614-11">
   <w.rf>
    <LM>w#w-d1t1614-11</LM>
   </w.rf>
   <form>rodinnou</form>
   <lemma>rodinný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t1616-1">
   <w.rf>
    <LM>w#w-d1t1616-1</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1607-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1607-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1617-x2">
  <m id="m027-d1t1622-1">
   <w.rf>
    <LM>w#w-d1t1622-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m027-d1t1622-2">
   <w.rf>
    <LM>w#w-d1t1622-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1622-5">
   <w.rf>
    <LM>w#w-d1t1622-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1622-3">
   <w.rf>
    <LM>w#w-d1t1622-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1622-6">
   <w.rf>
    <LM>w#w-d1t1622-6</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m027-d-id117004-punct">
   <w.rf>
    <LM>w#w-d-id117004-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1623-x2">
  <m id="m027-d1t1626-1">
   <w.rf>
    <LM>w#w-d1t1626-1</LM>
   </w.rf>
   <form>No</form>
   <lemma>no</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1626-2">
   <w.rf>
    <LM>w#w-d1t1626-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t1626-3">
   <w.rf>
    <LM>w#w-d1t1626-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1626-4">
   <w.rf>
    <LM>w#w-d1t1626-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1t1626-5">
   <w.rf>
    <LM>w#w-d1t1626-5</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1628-1">
   <w.rf>
    <LM>w#w-d1t1628-1</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m027-d-id117161-punct">
   <w.rf>
    <LM>w#w-d-id117161-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1630-1">
   <w.rf>
    <LM>w#w-d1t1630-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1630-4">
   <w.rf>
    <LM>w#w-d1t1630-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1630-2">
   <w.rf>
    <LM>w#w-d1t1630-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1630-5">
   <w.rf>
    <LM>w#w-d1t1630-5</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1630-6">
   <w.rf>
    <LM>w#w-d1t1630-6</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m027-d-id117326-punct">
   <w.rf>
    <LM>w#w-d-id117326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1630-12">
   <w.rf>
    <LM>w#w-d1t1630-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1630-13">
   <w.rf>
    <LM>w#w-d1t1630-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1630-14">
   <w.rf>
    <LM>w#w-d1t1630-14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t1630-15">
   <w.rf>
    <LM>w#w-d1t1630-15</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t1630-17">
   <w.rf>
    <LM>w#w-d1t1630-17</LM>
   </w.rf>
   <form>babičky</form>
   <lemma>babička</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t1632-1">
   <w.rf>
    <LM>w#w-d1t1632-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1632-2">
   <w.rf>
    <LM>w#w-d1t1632-2</LM>
   </w.rf>
   <form>teta</form>
   <lemma>teta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1e1623-x2-924">
   <w.rf>
    <LM>w#w-d1e1623-x2-924</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1623-x2-926">
   <w.rf>
    <LM>w#w-d1e1623-x2-926</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1623-x2-928">
   <w.rf>
    <LM>w#w-d1e1623-x2-928</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-930">
  <m id="m027-d1t1632-4">
   <w.rf>
    <LM>w#w-d1t1632-4</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1632-5">
   <w.rf>
    <LM>w#w-d1t1632-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1632-6">
   <w.rf>
    <LM>w#w-d1t1632-6</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1632-7">
   <w.rf>
    <LM>w#w-d1t1632-7</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m027-d1t1632-8">
   <w.rf>
    <LM>w#w-d1t1632-8</LM>
   </w.rf>
   <form>dvaceti</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m027-d1t1632-9">
   <w.rf>
    <LM>w#w-d1t1632-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m027-d1t1632-10">
   <w.rf>
    <LM>w#w-d1t1632-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e1623-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1623-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1633-x2">
  <m id="m027-d1t1636-1">
   <w.rf>
    <LM>w#w-d1t1636-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1636-2">
   <w.rf>
    <LM>w#w-d1t1636-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1636-3">
   <w.rf>
    <LM>w#w-d1t1636-3</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1636-4">
   <w.rf>
    <LM>w#w-d1t1636-4</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1636-5">
   <w.rf>
    <LM>w#w-d1t1636-5</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id117725-punct">
   <w.rf>
    <LM>w#w-d-id117725-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1637-x2">
  <m id="m027-d1t1642-1">
   <w.rf>
    <LM>w#w-d1t1642-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1642-2">
   <w.rf>
    <LM>w#w-d1t1642-2</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e1637-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1637-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1647-x2">
  <m id="m027-d1t1650-1">
   <w.rf>
    <LM>w#w-d1t1650-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1650-2">
   <w.rf>
    <LM>w#w-d1t1650-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m027-d1t1650-3">
   <w.rf>
    <LM>w#w-d1t1650-3</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t1650-4">
   <w.rf>
    <LM>w#w-d1t1650-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1650-5">
   <w.rf>
    <LM>w#w-d1t1650-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1e1647-x2-284">
   <w.rf>
    <LM>w#w-d1e1647-x2-284</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1647-x2-286">
   <w.rf>
    <LM>w#w-d1e1647-x2-286</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1647-x2-288">
   <w.rf>
    <LM>w#w-d1e1647-x2-288</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-290_1">
  <m id="m027-d1t1650-7">
   <w.rf>
    <LM>w#w-d1t1650-7</LM>
   </w.rf>
   <form>Mému</form>
   <lemma>můj</lemma>
   <tag>PSZS3-S1-------</tag>
  </m>
  <m id="m027-d1t1650-8">
   <w.rf>
    <LM>w#w-d1t1650-8</LM>
   </w.rf>
   <form>bratrovi</form>
   <lemma>bratr</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m027-d1t1650-9">
   <w.rf>
    <LM>w#w-d1t1650-9</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1650-10">
   <w.rf>
    <LM>w#w-d1t1650-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1650-12">
   <w.rf>
    <LM>w#w-d1t1650-12</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1t1650-13">
   <w.rf>
    <LM>w#w-d1t1650-13</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d1t1652-1">
   <w.rf>
    <LM>w#w-d1t1652-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1652-2">
   <w.rf>
    <LM>w#w-d1t1652-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1652-3">
   <w.rf>
    <LM>w#w-d1t1652-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1652-4">
   <w.rf>
    <LM>w#w-d1t1652-4</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1652-7">
   <w.rf>
    <LM>w#w-d1t1652-7</LM>
   </w.rf>
   <form>ochutnával</form>
   <lemma>ochutnávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1652-8">
   <w.rf>
    <LM>w#w-d1t1652-8</LM>
   </w.rf>
   <form>pití</form>
   <lemma>pití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1647-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1647-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1665-x2">
  <m id="m027-d1t1660-2">
   <w.rf>
    <LM>w#w-d1t1660-2</LM>
   </w.rf>
   <form>Musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1670-1">
   <w.rf>
    <LM>w#w-d1t1670-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1670-2">
   <w.rf>
    <LM>w#w-d1t1670-2</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m027-d1t1670-3">
   <w.rf>
    <LM>w#w-d1t1670-3</LM>
   </w.rf>
   <form>prozradit</form>
   <lemma>prozradit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m027-d-id118475-punct">
   <w.rf>
    <LM>w#w-d-id118475-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1670-5">
   <w.rf>
    <LM>w#w-d1t1670-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1670-6">
   <w.rf>
    <LM>w#w-d1t1670-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1670-7">
   <w.rf>
    <LM>w#w-d1t1670-7</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1670-8">
   <w.rf>
    <LM>w#w-d1t1670-8</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNP4---------6</tag>
  </m>
  <m id="m027-d1t1670-9">
   <w.rf>
    <LM>w#w-d1t1670-9</LM>
   </w.rf>
   <form>skleněné</form>
   <lemma>skleněný</lemma>
   <tag>AANP4----1A---6</tag>
  </m>
  <m id="m027-d1t1670-10">
   <w.rf>
    <LM>w#w-d1t1670-10</LM>
   </w.rf>
   <form>očíčka</form>
   <lemma>očíčko_,s_^(^DD**očičko)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1665-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1665-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1671-x3">
  <m id="m027-d1t1680-1">
   <w.rf>
    <LM>w#w-d1t1680-1</LM>
   </w.rf>
   <form>Opil</form>
   <lemma>opít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d1t1680-2">
   <w.rf>
    <LM>w#w-d1t1680-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d-id118682-punct">
   <w.rf>
    <LM>w#w-d-id118682-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1681-x2">
  <m id="m027-d1t1686-1">
   <w.rf>
    <LM>w#w-d1t1686-1</LM>
   </w.rf>
   <form>Neopil</form>
   <lemma>opít</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m027-d1e1681-x2-306">
   <w.rf>
    <LM>w#w-d1e1681-x2-306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1686-2">
   <w.rf>
    <LM>w#w-d1t1686-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1686-3">
   <w.rf>
    <LM>w#w-d1t1686-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t1686-6">
   <w.rf>
    <LM>w#w-d1t1686-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1686-7">
   <w.rf>
    <LM>w#w-d1t1686-7</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1686-8">
   <w.rf>
    <LM>w#w-d1t1686-8</LM>
   </w.rf>
   <form>ochutnal</form>
   <lemma>ochutnat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d-id118863-punct">
   <w.rf>
    <LM>w#w-d-id118863-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1686-10">
   <w.rf>
    <LM>w#w-d1t1686-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1686-11">
   <w.rf>
    <LM>w#w-d1t1686-11</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m027-d1t1686-12">
   <w.rf>
    <LM>w#w-d1t1686-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1686-13">
   <w.rf>
    <LM>w#w-d1t1686-13</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1e1681-x2-446">
   <w.rf>
    <LM>w#w-d1e1681-x2-446</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-447">
  <m id="m027-d1t1686-19">
   <w.rf>
    <LM>w#w-d1t1686-19</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t1686-20">
   <w.rf>
    <LM>w#w-d1t1686-20</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1693-1">
   <w.rf>
    <LM>w#w-d1t1693-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t1693-2">
   <w.rf>
    <LM>w#w-d1t1693-2</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS4-P1------6</tag>
  </m>
  <m id="m027-d1t1693-3">
   <w.rf>
    <LM>w#w-d1t1693-3</LM>
   </w.rf>
   <form>svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1686-24">
   <w.rf>
    <LM>w#w-d1t1686-24</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d1t1686-25">
   <w.rf>
    <LM>w#w-d1t1686-25</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m027-d-m-d1e1681-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1681-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1688-x3">
  <m id="m027-d1t1702-1">
   <w.rf>
    <LM>w#w-d1t1702-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1702-2">
   <w.rf>
    <LM>w#w-d1t1702-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1702-3">
   <w.rf>
    <LM>w#w-d1t1702-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1702-4">
   <w.rf>
    <LM>w#w-d1t1702-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1702-5">
   <w.rf>
    <LM>w#w-d1t1702-5</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e1688-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1688-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1688-x4">
  <m id="m027-d1t1704-1">
   <w.rf>
    <LM>w#w-d1t1704-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1704-2">
   <w.rf>
    <LM>w#w-d1t1704-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1704-4">
   <w.rf>
    <LM>w#w-d1t1704-4</LM>
   </w.rf>
   <form>jmenoval</form>
   <lemma>jmenovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m027-d1t1704-5">
   <w.rf>
    <LM>w#w-d1t1704-5</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m027-d1t1704-6">
   <w.rf>
    <LM>w#w-d1t1704-6</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id119399-punct">
   <w.rf>
    <LM>w#w-d-id119399-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1705-x2">
  <m id="m027-d1t1708-1">
   <w.rf>
    <LM>w#w-d1t1708-1</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1708-2">
   <w.rf>
    <LM>w#w-d1t1708-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1708-3">
   <w.rf>
    <LM>w#w-d1t1708-3</LM>
   </w.rf>
   <form>jmenoval</form>
   <lemma>jmenovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m027-d1t1708-5">
   <w.rf>
    <LM>w#w-d1t1708-5</LM>
   </w.rf>
   <form>Pepík</form>
   <lemma>Pepík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e1705-x2-338">
   <w.rf>
    <LM>w#w-d1e1705-x2-338</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1708-8">
   <w.rf>
    <LM>w#w-d1t1708-8</LM>
   </w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1705-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1705-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1715-x2">
  <m id="m027-d1t1718-6">
   <w.rf>
    <LM>w#w-d1t1718-6</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m027-d1t1718-7">
   <w.rf>
    <LM>w#w-d1t1718-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1718-9">
   <w.rf>
    <LM>w#w-d1t1718-9</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Moravák</form>
   <lemma>Moravák_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1718-15">
   <w.rf>
    <LM>w#w-d1t1718-15</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1718-16">
   <w.rf>
    <LM>w#w-d1t1718-16</LM>
   </w.rf>
   <form>Hrušek</form>
   <lemma>Hrušky_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d1t1718-19">
   <w.rf>
    <LM>w#w-d1t1718-19</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1718-21">
   <w.rf>
    <LM>w#w-d1t1718-21</LM>
   </w.rf>
   <form>Břeclavi</form>
   <lemma>Břeclav_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d-id119942-punct">
   <w.rf>
    <LM>w#w-d-id119942-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1720-2">
   <w.rf>
    <LM>w#w-d1t1720-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1720-3">
   <w.rf>
    <LM>w#w-d1t1720-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1720-4">
   <w.rf>
    <LM>w#w-d1t1720-4</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1720-6">
   <w.rf>
    <LM>w#w-d1t1720-6</LM>
   </w.rf>
   <form>Jožka</form>
   <lemma>Jožka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id120054-punct">
   <w.rf>
    <LM>w#w-d-id120054-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1720-10">
   <w.rf>
    <LM>w#w-d1t1720-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1720-11">
   <w.rf>
    <LM>w#w-d1t1720-11</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m027-d1t1720-12">
   <w.rf>
    <LM>w#w-d1t1720-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1720-13">
   <w.rf>
    <LM>w#w-d1t1720-13</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m027-d1t1720-14">
   <w.rf>
    <LM>w#w-d1t1720-14</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t1720-16">
   <w.rf>
    <LM>w#w-d1t1720-16</LM>
   </w.rf>
   <form>Pepo</form>
   <lemma>Pepa_;Y</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m027-d1t1720-19">
   <w.rf>
    <LM>w#w-d1t1720-19</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1720-20">
   <w.rf>
    <LM>w#w-d1t1720-20</LM>
   </w.rf>
   <form>našem</form>
   <lemma>náš</lemma>
   <tag>PSZS6-P1-------</tag>
  </m>
  <m id="m027-d-m-d1e1715-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1715-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
