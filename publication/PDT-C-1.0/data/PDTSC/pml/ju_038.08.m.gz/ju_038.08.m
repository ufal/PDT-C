<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_038.08.w.gz" />
  </references>
 </head>
 <s id="m038-d1e2484-x2">
  <m id="m038-d1t2487-1">
   <w.rf>
    <LM>w#w-d1t2487-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2487-2">
   <w.rf>
    <LM>w#w-d1t2487-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2487-3">
   <w.rf>
    <LM>w#w-d1t2487-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t2487-4">
   <w.rf>
    <LM>w#w-d1t2487-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m038-d1t2487-5">
   <w.rf>
    <LM>w#w-d1t2487-5</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1e2484-x2-535">
   <w.rf>
    <LM>w#w-d1e2484-x2-535</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-536">
  <m id="m038-d1t2487-7">
   <w.rf>
    <LM>w#w-d1t2487-7</LM>
   </w.rf>
   <form>Slavili</form>
   <lemma>slavit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t2487-8">
   <w.rf>
    <LM>w#w-d1t2487-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d-id137489-punct">
   <w.rf>
    <LM>w#w-d-id137489-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2487-12">
   <w.rf>
    <LM>w#w-d1t2487-12</LM>
   </w.rf>
   <form>udělaly</form>
   <lemma>udělat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m038-d1t2487-13">
   <w.rf>
    <LM>w#w-d1t2487-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2487-15">
   <w.rf>
    <LM>w#w-d1t2487-15</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m038-d1t2487-16">
   <w.rf>
    <LM>w#w-d1t2487-16</LM>
   </w.rf>
   <form>chlebíčky</form>
   <lemma>chlebíček</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m038-d-id137575-punct">
   <w.rf>
    <LM>w#w-d-id137575-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2487-19">
   <w.rf>
    <LM>w#w-d1t2487-19</LM>
   </w.rf>
   <form>pohoštění</form>
   <lemma>pohoštění_^(*5stit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m038-d-id137615-punct">
   <w.rf>
    <LM>w#w-d-id137615-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2489-4">
   <w.rf>
    <LM>w#w-d1t2489-4</LM>
   </w.rf>
   <form>sedli</form>
   <lemma>sednout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m038-d1t2489-5">
   <w.rf>
    <LM>w#w-d1t2489-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2489-6">
   <w.rf>
    <LM>w#w-d1t2489-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d-id137726-punct">
   <w.rf>
    <LM>w#w-d-id137726-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2489-8">
   <w.rf>
    <LM>w#w-d1t2489-8</LM>
   </w.rf>
   <form>popovídali</form>
   <lemma>popovídat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-536-556">
   <w.rf>
    <LM>w#w-536-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2506-x2">
  <m id="m038-d1t2491-3">
   <w.rf>
    <LM>w#w-d1t2491-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t2491-4">
   <w.rf>
    <LM>w#w-d1t2491-4</LM>
   </w.rf>
   <form>děláme</form>
   <lemma>dělat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2491-6">
   <w.rf>
    <LM>w#w-d1t2491-6</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e2506-x2-572">
   <w.rf>
    <LM>w#w-d1e2506-x2-572</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2506-x2-571">
   <w.rf>
    <LM>w#w-d1e2506-x2-571</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2499-3">
   <w.rf>
    <LM>w#w-d1t2499-3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2499-4">
   <w.rf>
    <LM>w#w-d1t2499-4</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m038-d1t2499-5">
   <w.rf>
    <LM>w#w-d1t2499-5</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m038-d1t2499-6">
   <w.rf>
    <LM>w#w-d1t2499-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2499-7">
   <w.rf>
    <LM>w#w-d1t2499-7</LM>
   </w.rf>
   <form>svátek</form>
   <lemma>svátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d1e2506-x2-555">
   <w.rf>
    <LM>w#w-d1e2506-x2-555</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2506-x2-573">
   <w.rf>
    <LM>w#w-d1e2506-x2-573</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2509-2">
   <w.rf>
    <LM>w#w-d1t2509-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t2511-1">
   <w.rf>
    <LM>w#w-d1t2511-1</LM>
   </w.rf>
   <form>sedneme</form>
   <lemma>sednout</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d-id138187-punct">
   <w.rf>
    <LM>w#w-d-id138187-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2511-3">
   <w.rf>
    <LM>w#w-d1t2511-3</LM>
   </w.rf>
   <form>sejdeme</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d1t2511-4">
   <w.rf>
    <LM>w#w-d1t2511-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d-id138227-punct">
   <w.rf>
    <LM>w#w-d-id138227-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2513-1">
   <w.rf>
    <LM>w#w-d1t2513-1</LM>
   </w.rf>
   <form>popovídáme</form>
   <lemma>popovídat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d1e2506-x2-554">
   <w.rf>
    <LM>w#w-d1e2506-x2-554</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2513-4">
   <w.rf>
    <LM>w#w-d1t2513-4</LM>
   </w.rf>
   <form>oslavíme</form>
   <lemma>oslavit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d1t2513-5">
   <w.rf>
    <LM>w#w-d1t2513-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d-m-d1e2506-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2506-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2514-x2">
  <m id="m038-d1t2519-1">
   <w.rf>
    <LM>w#w-d1t2519-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2519-2">
   <w.rf>
    <LM>w#w-d1t2519-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2519-3">
   <w.rf>
    <LM>w#w-d1t2519-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-d-m-d1e2514-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2514-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2514-x3">
  <m id="m038-d1t2521-1">
   <w.rf>
    <LM>w#w-d1t2521-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d-m-d1e2514-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2514-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2523-x2">
  <m id="m038-d1t2526-1">
   <w.rf>
    <LM>w#w-d1t2526-1</LM>
   </w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m038-d1t2526-2">
   <w.rf>
    <LM>w#w-d1t2526-2</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m038-d1t2526-3">
   <w.rf>
    <LM>w#w-d1t2526-3</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m038-d1t2526-4">
   <w.rf>
    <LM>w#w-d1t2526-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2526-5">
   <w.rf>
    <LM>w#w-d1t2526-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2526-6">
   <w.rf>
    <LM>w#w-d1t2526-6</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d-id138588-punct">
   <w.rf>
    <LM>w#w-d-id138588-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2527-x2">
  <m id="m038-d1t2532-2">
   <w.rf>
    <LM>w#w-d1t2532-2</LM>
   </w.rf>
   <form>Martin</form>
   <lemma>Martin-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t2532-4">
   <w.rf>
    <LM>w#w-d1t2532-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2532-5">
   <w.rf>
    <LM>w#w-d1t2532-5</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1e2527-x2-582">
   <w.rf>
    <LM>w#w-d1e2527-x2-582</LM>
   </w.rf>
   <form>1973</form>
   <lemma>1973</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-id138754-punct">
   <w.rf>
    <LM>w#w-d-id138754-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2534-4">
   <w.rf>
    <LM>w#w-d1t2534-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e2527-x2-302">
   <w.rf>
    <LM>w#w-d1e2527-x2-302</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2534-5">
   <w.rf>
    <LM>w#w-d1t2534-5</LM>
   </w.rf>
   <form>šedesát</form>
   <lemma>šedesát`60</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d1e2527-x2-303">
   <w.rf>
    <LM>w#w-d1e2527-x2-303</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2527-x2-304">
   <w.rf>
    <LM>w#w-d1e2527-x2-304</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2527-x2-305">
   <w.rf>
    <LM>w#w-d1e2527-x2-305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d-id138912-punct">
   <w.rf>
    <LM>w#w-d-id138912-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2534-12">
   <w.rf>
    <LM>w#w-d1t2534-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2534-13">
   <w.rf>
    <LM>w#w-d1t2534-13</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m038-d1t2534-14">
   <w.rf>
    <LM>w#w-d1t2534-14</LM>
   </w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-id138954-punct">
   <w.rf>
    <LM>w#w-d-id138954-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2534-16">
   <w.rf>
    <LM>w#w-d1t2534-16</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m038-d1t2534-17">
   <w.rf>
    <LM>w#w-d1t2534-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t2534-18">
   <w.rf>
    <LM>w#w-d1t2534-18</LM>
   </w.rf>
   <form>musím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2534-19">
   <w.rf>
    <LM>w#w-d1t2534-19</LM>
   </w.rf>
   <form>spočítat</form>
   <lemma>spočítat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m038-d1e2527-x2-299">
   <w.rf>
    <LM>w#w-d1e2527-x2-299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2537-x2">
  <m id="m038-d1t2544-1">
   <w.rf>
    <LM>w#w-d1t2544-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2544-2">
   <w.rf>
    <LM>w#w-d1t2544-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m038-d1t2544-3">
   <w.rf>
    <LM>w#w-d1t2544-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2544-4">
   <w.rf>
    <LM>w#w-d1t2544-4</LM>
   </w.rf>
   <form>14</form>
   <lemma>14</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-id139147-punct">
   <w.rf>
    <LM>w#w-d-id139147-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2544-6">
   <w.rf>
    <LM>w#w-d1t2544-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2544-7">
   <w.rf>
    <LM>w#w-d1t2544-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1e2537-x2-306">
   <w.rf>
    <LM>w#w-d1e2537-x2-306</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m038-d1t2544-8">
   <w.rf>
    <LM>w#w-d1t2544-8</LM>
   </w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d-m-d1e2537-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2537-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2549-x2">
  <m id="m038-d1t2552-1">
   <w.rf>
    <LM>w#w-d1t2552-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m038-d1t2552-2">
   <w.rf>
    <LM>w#w-d1t2552-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t2552-3">
   <w.rf>
    <LM>w#w-d1t2552-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m038-d1t2552-4">
   <w.rf>
    <LM>w#w-d1t2552-4</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2552-5">
   <w.rf>
    <LM>w#w-d1t2552-5</LM>
   </w.rf>
   <form>zaskočila</form>
   <lemma>zaskočit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m038-d-m-d1e2549-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2549-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2569-x2">
  <m id="m038-d1t2564-2">
   <w.rf>
    <LM>w#w-d1t2564-2</LM>
   </w.rf>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m038-d1e2569-x2-307">
   <w.rf>
    <LM>w#w-d1e2569-x2-307</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2572-1">
   <w.rf>
    <LM>w#w-d1t2572-1</LM>
   </w.rf>
   <form>devět</form>
   <lemma>devět`9</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d-id139551-punct">
   <w.rf>
    <LM>w#w-d-id139551-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2572-3">
   <w.rf>
    <LM>w#w-d1t2572-3</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d-id139575-punct">
   <w.rf>
    <LM>w#w-d-id139575-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2572-5">
   <w.rf>
    <LM>w#w-d1t2572-5</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m038-d1t2572-5-sw1">
   <w.rf>
    <LM>w#w-d1t2572-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>tisíce</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIP1----------</tag>
  </m>
  <m id="m038-d1t2572-6">
   <w.rf>
    <LM>w#w-d1t2572-6</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d-id139615-punct">
   <w.rf>
    <LM>w#w-d-id139615-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2572-8">
   <w.rf>
    <LM>w#w-d1t2572-8</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m038-d1t2572-9">
   <w.rf>
    <LM>w#w-d1t2572-9</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m038-d-id139654-punct">
   <w.rf>
    <LM>w#w-d-id139654-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2574-1">
   <w.rf>
    <LM>w#w-d1t2574-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2574-2">
   <w.rf>
    <LM>w#w-d1t2574-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2574-3">
   <w.rf>
    <LM>w#w-d1t2574-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m038-d1t2574-4">
   <w.rf>
    <LM>w#w-d1t2574-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t2574-5">
   <w.rf>
    <LM>w#w-d1t2574-5</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m038-d1e2569-x2-308">
   <w.rf>
    <LM>w#w-d1e2569-x2-308</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2569-x2-309">
   <w.rf>
    <LM>w#w-d1e2569-x2-309</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2569-x2-310">
   <w.rf>
    <LM>w#w-d1e2569-x2-310</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-311">
  <m id="m038-d1t2574-7">
   <w.rf>
    <LM>w#w-d1t2574-7</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m038-d1t2574-8">
   <w.rf>
    <LM>w#w-d1t2574-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2574-9">
   <w.rf>
    <LM>w#w-d1t2574-9</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-311-312">
   <w.rf>
    <LM>w#w-311-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-311-313">
   <w.rf>
    <LM>w#w-311-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-311-314">
   <w.rf>
    <LM>w#w-311-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-298">
  <m id="m038-d1t2578-1">
   <w.rf>
    <LM>w#w-d1t2578-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m038-d1t2578-2">
   <w.rf>
    <LM>w#w-d1t2578-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2578-3">
   <w.rf>
    <LM>w#w-d1t2578-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2578-4">
   <w.rf>
    <LM>w#w-d1t2578-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2578-5">
   <w.rf>
    <LM>w#w-d1t2578-5</LM>
   </w.rf>
   <form>vypadlo</form>
   <lemma>vypadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m038-d-m-d1e2569-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2569-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2579-x2">
  <m id="m038-d1t2584-4">
   <w.rf>
    <LM>w#w-d1t2584-4</LM>
   </w.rf>
   <form>Můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2584-6">
   <w.rf>
    <LM>w#w-d1t2584-6</LM>
   </w.rf>
   <form>chviličku</form>
   <lemma>chvilička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t2584-5">
   <w.rf>
    <LM>w#w-d1t2584-5</LM>
   </w.rf>
   <form>přemýšlet</form>
   <lemma>přemýšlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m038-d1e2579-x2-297">
   <w.rf>
    <LM>w#w-d1e2579-x2-297</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2579-x3">
  <m id="m038-d1t2586-1">
   <w.rf>
    <LM>w#w-d1t2586-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2586-2">
   <w.rf>
    <LM>w#w-d1t2586-2</LM>
   </w.rf>
   <form>nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d-m-d1e2579-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2579-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2587-x2">
  <m id="m038-d1t2590-1">
   <w.rf>
    <LM>w#w-d1t2590-1</LM>
   </w.rf>
   <form>Nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d1t2590-2">
   <w.rf>
    <LM>w#w-d1t2590-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d-id140162-punct">
   <w.rf>
    <LM>w#w-d-id140162-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2597-x2">
  <m id="m038-d1t2600-1">
   <w.rf>
    <LM>w#w-d1t2600-1</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m038-d1t2600-2">
   <w.rf>
    <LM>w#w-d1t2600-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2600-3">
   <w.rf>
    <LM>w#w-d1t2600-3</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m038-d1t2600-4">
   <w.rf>
    <LM>w#w-d1t2600-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2600-5">
   <w.rf>
    <LM>w#w-d1t2600-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m038-d1e2597-x2-294">
   <w.rf>
    <LM>w#w-d1e2597-x2-294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2597-x2-295">
   <w.rf>
    <LM>w#w-d1e2597-x2-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d-m-d1e2597-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2597-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2601-x2">
  <m id="m038-d1t2606-1">
   <w.rf>
    <LM>w#w-d1t2606-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t2606-2">
   <w.rf>
    <LM>w#w-d1t2606-2</LM>
   </w.rf>
   <form>nepočítejte</form>
   <lemma>počítat</lemma>
   <tag>Vi-P---2--N-I--</tag>
  </m>
  <m id="m038-d-id140443-punct">
   <w.rf>
    <LM>w#w-d-id140443-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2606-4">
   <w.rf>
    <LM>w#w-d1t2606-4</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2606-5">
   <w.rf>
    <LM>w#w-d1t2606-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2606-6">
   <w.rf>
    <LM>w#w-d1t2606-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2606-8">
   <w.rf>
    <LM>w#w-d1t2606-8</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2606-9">
   <w.rf>
    <LM>w#w-d1t2606-9</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m038-d1t2606-10">
   <w.rf>
    <LM>w#w-d1t2606-10</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2601-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2601-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2601-x3">
  <m id="m038-d1t2608-1">
   <w.rf>
    <LM>w#w-d1t2608-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e2601-x3-67">
   <w.rf>
    <LM>w#w-d1e2601-x3-67</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2608-2">
   <w.rf>
    <LM>w#w-d1t2608-2</LM>
   </w.rf>
   <form>nemusím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m038-d1t2608-3">
   <w.rf>
    <LM>w#w-d1t2608-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t2608-4">
   <w.rf>
    <LM>w#w-d1t2608-4</LM>
   </w.rf>
   <form>počítat</form>
   <lemma>počítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m038-d-m-d1e2601-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2601-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2612-x2">
  <m id="m038-d1t2615-1">
   <w.rf>
    <LM>w#w-d1t2615-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e2612-x2-68">
   <w.rf>
    <LM>w#w-d1e2612-x2-68</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2615-2">
   <w.rf>
    <LM>w#w-d1t2615-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2615-3">
   <w.rf>
    <LM>w#w-d1t2615-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2615-4">
   <w.rf>
    <LM>w#w-d1t2615-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2615-5">
   <w.rf>
    <LM>w#w-d1t2615-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2615-6">
   <w.rf>
    <LM>w#w-d1t2615-6</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m038-d1t2615-7">
   <w.rf>
    <LM>w#w-d1t2615-7</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2612-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2612-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2616-x2">
  <m id="m038-d1t2619-1">
   <w.rf>
    <LM>w#w-d1t2619-1</LM>
   </w.rf>
   <form>Hlídávala</form>
   <lemma>hlídávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m038-d1t2619-2">
   <w.rf>
    <LM>w#w-d1t2619-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t2619-3">
   <w.rf>
    <LM>w#w-d1t2619-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m038-d1t2619-4">
   <w.rf>
    <LM>w#w-d1t2619-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-id140876-punct">
   <w.rf>
    <LM>w#w-d-id140876-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2622-x2">
  <m id="m038-d1t2625-1">
   <w.rf>
    <LM>w#w-d1t2625-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1e2622-x2-77">
   <w.rf>
    <LM>w#w-d1e2622-x2-77</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2625-3">
   <w.rf>
    <LM>w#w-d1t2625-3</LM>
   </w.rf>
   <form>hlídávam</form>
   <lemma>hlídávat_^(*4at)</lemma>
   <tag>VB-S---1P-AAI-6</tag>
  </m>
  <m id="m038-d-id140993-punct">
   <w.rf>
    <LM>w#w-d-id140993-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2625-5">
   <w.rf>
    <LM>w#w-d1t2625-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2625-6">
   <w.rf>
    <LM>w#w-d1t2625-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e2622-x2-78">
   <w.rf>
    <LM>w#w-d1e2622-x2-78</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-79">
  <m id="m038-d1t2625-13">
   <w.rf>
    <LM>w#w-d1t2625-13</LM>
   </w.rf>
   <form>Karolínka</form>
   <lemma>Karolínka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t2625-15">
   <w.rf>
    <LM>w#w-d1t2625-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2625-16">
   <w.rf>
    <LM>w#w-d1t2625-16</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m038-d1t2627-1">
   <w.rf>
    <LM>w#w-d1t2627-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2627-2">
   <w.rf>
    <LM>w#w-d1t2627-2</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m038-d1t2627-4">
   <w.rf>
    <LM>w#w-d1t2627-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2627-3">
   <w.rf>
    <LM>w#w-d1t2627-3</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2627-5">
   <w.rf>
    <LM>w#w-d1t2627-5</LM>
   </w.rf>
   <form>perou</form>
   <lemma>prát</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e2622-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2622-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2644-x2">
  <m id="m038-d1e2644-x2-373">
   <w.rf>
    <LM>w#w-d1e2644-x2-373</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2647-4">
   <w.rf>
    <LM>w#w-d1t2647-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2647-1">
   <w.rf>
    <LM>w#w-d1t2647-1</LM>
   </w.rf>
   <form>máma</form>
   <lemma>máma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t2647-2">
   <w.rf>
    <LM>w#w-d1t2647-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2647-3">
   <w.rf>
    <LM>w#w-d1t2647-3</LM>
   </w.rf>
   <form>táta</form>
   <lemma>táta</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t2647-5">
   <w.rf>
    <LM>w#w-d1t2647-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2647-6">
   <w.rf>
    <LM>w#w-d1t2647-6</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m038-d1e2644-x2-372">
   <w.rf>
    <LM>w#w-d1e2644-x2-372</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2649-2">
   <w.rf>
    <LM>w#w-d1t2649-2</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m038-d1t2649-3">
   <w.rf>
    <LM>w#w-d1t2649-3</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m038-d1t2649-4">
   <w.rf>
    <LM>w#w-d1t2649-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m038-d1t2649-5">
   <w.rf>
    <LM>w#w-d1t2649-5</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-id141775-punct">
   <w.rf>
    <LM>w#w-d-id141775-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2644-x2-374">
   <w.rf>
    <LM>w#w-d1e2644-x2-374</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2651-8">
   <w.rf>
    <LM>w#w-d1t2651-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2651-9">
   <w.rf>
    <LM>w#w-d1t2651-9</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m038-d1e2644-x2-375">
   <w.rf>
    <LM>w#w-d1e2644-x2-375</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2651-12">
   <w.rf>
    <LM>w#w-d1t2651-12</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2651-7">
   <w.rf>
    <LM>w#w-d1t2651-7</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2651-10">
   <w.rf>
    <LM>w#w-d1t2651-10</LM>
   </w.rf>
   <form>dávam</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-S---1P-AAI-6</tag>
  </m>
  <m id="m038-d1t2651-11">
   <w.rf>
    <LM>w#w-d1t2651-11</LM>
   </w.rf>
   <form>pozor</form>
   <lemma>pozor-2</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d-id141640-punct">
   <w.rf>
    <LM>w#w-d-id141640-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2644-x2-376">
   <w.rf>
    <LM>w#w-d1e2644-x2-376</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1e2644-x2-377">
   <w.rf>
    <LM>w#w-d1e2644-x2-377</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2651-1">
   <w.rf>
    <LM>w#w-d1t2651-1</LM>
   </w.rf>
   <form>ony</form>
   <lemma>on-1</lemma>
   <tag>PEFP1--3-------</tag>
  </m>
  <m id="m038-d1t2651-2">
   <w.rf>
    <LM>w#w-d1t2651-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2651-3">
   <w.rf>
    <LM>w#w-d1t2651-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m038-d1t2651-4">
   <w.rf>
    <LM>w#w-d1t2651-4</LM>
   </w.rf>
   <form>nechtějí</form>
   <lemma>chtít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m038-d-m-d1e2644-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2644-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2664-x2">
  <m id="m038-d1t2669-2">
   <w.rf>
    <LM>w#w-d1t2669-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2669-3">
   <w.rf>
    <LM>w#w-d1t2669-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2669-4">
   <w.rf>
    <LM>w#w-d1t2669-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2669-5">
   <w.rf>
    <LM>w#w-d1t2669-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2669-6">
   <w.rf>
    <LM>w#w-d1t2669-6</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m038-d-m-d1e2664-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2664-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2664-x3">
  <m id="m038-d1t2673-1">
   <w.rf>
    <LM>w#w-d1t2673-1</LM>
   </w.rf>
   <form>Bývají</form>
   <lemma>bývat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2673-2">
   <w.rf>
    <LM>w#w-d1t2673-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t2673-3">
   <w.rf>
    <LM>w#w-d1t2673-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m038-d1t2673-4">
   <w.rf>
    <LM>w#w-d1t2673-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2673-5">
   <w.rf>
    <LM>w#w-d1t2673-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2673-6">
   <w.rf>
    <LM>w#w-d1t2673-6</LM>
   </w.rf>
   <form>prázdniny</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m038-d-id142181-punct">
   <w.rf>
    <LM>w#w-d-id142181-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2674-x2">
  <m id="m038-d1t2677-2">
   <w.rf>
    <LM>w#w-d1t2677-2</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2677-3">
   <w.rf>
    <LM>w#w-d1t2677-3</LM>
   </w.rf>
   <form>jedou</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2679-1">
   <w.rf>
    <LM>w#w-d1t2679-1</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e2674-x2-120">
   <w.rf>
    <LM>w#w-d1e2674-x2-120</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2679-4">
   <w.rf>
    <LM>w#w-d1t2679-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2679-5">
   <w.rf>
    <LM>w#w-d1t2679-5</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d-id142369-punct">
   <w.rf>
    <LM>w#w-d-id142369-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2681-1">
   <w.rf>
    <LM>w#w-d1t2681-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2683-1">
   <w.rf>
    <LM>w#w-d1t2683-1</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2685-1">
   <w.rf>
    <LM>w#w-d1t2685-1</LM>
   </w.rf>
   <form>bývají</form>
   <lemma>bývat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2685-2">
   <w.rf>
    <LM>w#w-d1t2685-2</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t2685-4">
   <w.rf>
    <LM>w#w-d1t2685-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2685-5">
   <w.rf>
    <LM>w#w-d1t2685-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2685-6">
   <w.rf>
    <LM>w#w-d1t2685-6</LM>
   </w.rf>
   <form>jedou</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2685-7">
   <w.rf>
    <LM>w#w-d1t2685-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t2685-8">
   <w.rf>
    <LM>w#w-d1t2685-8</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS7----------</tag>
  </m>
  <m id="m038-d1t2685-9">
   <w.rf>
    <LM>w#w-d1t2685-9</LM>
   </w.rf>
   <form>babičkou</form>
   <lemma>babička</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d1e2674-x2-121">
   <w.rf>
    <LM>w#w-d1e2674-x2-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-122">
  <m id="m038-d1t2685-11">
   <w.rf>
    <LM>w#w-d1t2685-11</LM>
   </w.rf>
   <form>Tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m038-d1t2685-12">
   <w.rf>
    <LM>w#w-d1t2685-12</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2690-1">
   <w.rf>
    <LM>w#w-d1t2690-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2690-3">
   <w.rf>
    <LM>w#w-d1t2690-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Mariánských</form>
   <lemma>mariánský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m038-122-1348">
   <w.rf>
    <LM>w#w-122-1348</LM>
   </w.rf>
   <form>Lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m038-d-id142667-punct">
   <w.rf>
    <LM>w#w-d-id142667-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2690-6">
   <w.rf>
    <LM>w#w-d1t2690-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2690-7">
   <w.rf>
    <LM>w#w-d1t2690-7</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2690-8">
   <w.rf>
    <LM>w#w-d1t2690-8</LM>
   </w.rf>
   <form>jedou</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2690-11">
   <w.rf>
    <LM>w#w-d1t2690-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2690-12">
   <w.rf>
    <LM>w#w-d1t2690-12</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m038-d1t2692-1">
   <w.rf>
    <LM>w#w-d1t2692-1</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d1t2690-9">
   <w.rf>
    <LM>w#w-d1t2690-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id142802-punct">
   <w.rf>
    <LM>w#w-d-id142802-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2692-3">
   <w.rf>
    <LM>w#w-d1t2692-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2692-4">
   <w.rf>
    <LM>w#w-d1t2692-4</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d1t2692-5">
   <w.rf>
    <LM>w#w-d1t2692-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2692-6">
   <w.rf>
    <LM>w#w-d1t2692-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2692-7">
   <w.rf>
    <LM>w#w-d1t2692-7</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m038-d1t2692-8">
   <w.rf>
    <LM>w#w-d1t2692-8</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m038-122-1349">
   <w.rf>
    <LM>w#w-122-1349</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-1350">
  <m id="m038-d1t2692-12">
   <w.rf>
    <LM>w#w-d1t2692-12</LM>
   </w.rf>
   <form>Nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2692-14">
   <w.rf>
    <LM>w#w-d1t2692-14</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2692-15">
   <w.rf>
    <LM>w#w-d1t2692-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2692-16">
   <w.rf>
    <LM>w#w-d1t2692-16</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m038-d1t2692-17">
   <w.rf>
    <LM>w#w-d1t2692-17</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m038-d1t2692-18">
   <w.rf>
    <LM>w#w-d1t2692-18</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-122-123">
   <w.rf>
    <LM>w#w-122-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-124">
  <m id="m038-d1t2692-22">
   <w.rf>
    <LM>w#w-d1t2692-22</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2692-23">
   <w.rf>
    <LM>w#w-d1t2692-23</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t2692-21">
   <w.rf>
    <LM>w#w-d1t2692-21</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2692-24">
   <w.rf>
    <LM>w#w-d1t2692-24</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2692-25">
   <w.rf>
    <LM>w#w-d1t2692-25</LM>
   </w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m038-d1t2692-26">
   <w.rf>
    <LM>w#w-d1t2692-26</LM>
   </w.rf>
   <form>ozdravném</form>
   <lemma>ozdravný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m038-d1t2692-27">
   <w.rf>
    <LM>w#w-d1t2692-27</LM>
   </w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m038-d-id143184-punct">
   <w.rf>
    <LM>w#w-d-id143184-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2692-29">
   <w.rf>
    <LM>w#w-d1t2692-29</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2692-30">
   <w.rf>
    <LM>w#w-d1t2692-30</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2692-32">
   <w.rf>
    <LM>w#w-d1t2692-32</LM>
   </w.rf>
   <form>prázdninách</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m038-d1t2692-33">
   <w.rf>
    <LM>w#w-d1t2692-33</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2692-34">
   <w.rf>
    <LM>w#w-d1t2692-34</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t2692-35">
   <w.rf>
    <LM>w#w-d1t2692-35</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id143295-punct">
   <w.rf>
    <LM>w#w-d-id143295-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2674-x3">
  <m id="m038-d1t2692-41">
   <w.rf>
    <LM>w#w-d1t2692-41</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t2692-42">
   <w.rf>
    <LM>w#w-d1t2692-42</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m038-d1t2692-43">
   <w.rf>
    <LM>w#w-d1t2692-43</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2692-44">
   <w.rf>
    <LM>w#w-d1t2692-44</LM>
   </w.rf>
   <form>jedou</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d-id143428-punct">
   <w.rf>
    <LM>w#w-d-id143428-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2696-1">
   <w.rf>
    <LM>w#w-d1t2696-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t2696-2">
   <w.rf>
    <LM>w#w-d1t2696-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>leckdes</form>
   <lemma>leckdes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id143501-punct">
   <w.rf>
    <LM>w#w-d-id143501-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2696-5">
   <w.rf>
    <LM>w#w-d1t2696-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2696-6">
   <w.rf>
    <LM>w#w-d1t2696-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t2696-7">
   <w.rf>
    <LM>w#w-d1t2696-7</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m038-d1t2698-1">
   <w.rf>
    <LM>w#w-d1t2698-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id143580-punct">
   <w.rf>
    <LM>w#w-d-id143580-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2701-1">
   <w.rf>
    <LM>w#w-d1t2701-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2701-2">
   <w.rf>
    <LM>w#w-d1t2701-2</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2701-4">
   <w.rf>
    <LM>w#w-d1t2701-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m038-d1t2701-5">
   <w.rf>
    <LM>w#w-d1t2701-5</LM>
   </w.rf>
   <form>rodiči</form>
   <lemma>rodič</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m038-d1t2701-6">
   <w.rf>
    <LM>w#w-d1t2701-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2701-8">
   <w.rf>
    <LM>w#w-d1t2701-8</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m038-d1t2701-9">
   <w.rf>
    <LM>w#w-d1t2701-9</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2701-10">
   <w.rf>
    <LM>w#w-d1t2701-10</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1e2674-x3-161">
   <w.rf>
    <LM>w#w-d1e2674-x3-161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2707-1">
   <w.rf>
    <LM>w#w-d1t2707-1</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2707-2">
   <w.rf>
    <LM>w#w-d1t2707-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t2707-3">
   <w.rf>
    <LM>w#w-d1t2707-3</LM>
   </w.rf>
   <form>ciziny</form>
   <lemma>cizina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2702-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2702-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2712-x2">
  <m id="m038-d1t2715-1">
   <w.rf>
    <LM>w#w-d1t2715-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m038-d1e2712-x2-168">
   <w.rf>
    <LM>w#w-d1e2712-x2-168</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-169">
  <m id="m038-d1t2717-1">
   <w.rf>
    <LM>w#w-d1t2717-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m038-d1t2717-2">
   <w.rf>
    <LM>w#w-d1t2717-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t2717-3">
   <w.rf>
    <LM>w#w-d1t2717-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2717-4">
   <w.rf>
    <LM>w#w-d1t2717-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m038-d1t2717-5">
   <w.rf>
    <LM>w#w-d1t2717-5</LM>
   </w.rf>
   <form>dětskou</form>
   <lemma>dětský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m038-d1t2717-6">
   <w.rf>
    <LM>w#w-d1t2717-6</LM>
   </w.rf>
   <form>lumpárnu</form>
   <lemma>lumpárna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-169-170">
   <w.rf>
    <LM>w#w-169-170</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2717-8">
   <w.rf>
    <LM>w#w-d1t2717-8</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m038-d1t2717-9">
   <w.rf>
    <LM>w#w-d1t2717-9</LM>
   </w.rf>
   <form>provedli</form>
   <lemma>provést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d-id144084-punct">
   <w.rf>
    <LM>w#w-d-id144084-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2718-x2">
  <m id="m038-d1t2725-2">
   <w.rf>
    <LM>w#w-d1t2725-2</LM>
   </w.rf>
   <form>Těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m038-d1t2725-3">
   <w.rf>
    <LM>w#w-d1t2725-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t2725-4">
   <w.rf>
    <LM>w#w-d1t2725-4</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m038-d-id144225-punct">
   <w.rf>
    <LM>w#w-d-id144225-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2725-6">
   <w.rf>
    <LM>w#w-d1t2725-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2725-9">
   <w.rf>
    <LM>w#w-d1t2725-9</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2725-8">
   <w.rf>
    <LM>w#w-d1t2725-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t2725-7">
   <w.rf>
    <LM>w#w-d1t2725-7</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2725-10">
   <w.rf>
    <LM>w#w-d1t2725-10</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m038-d1e2718-x2-178">
   <w.rf>
    <LM>w#w-d1e2718-x2-178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-179">
  <m id="m038-d1t2727-3">
   <w.rf>
    <LM>w#w-d1t2727-3</LM>
   </w.rf>
   <form>Dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d1t2727-2">
   <w.rf>
    <LM>w#w-d1t2727-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2729-1">
   <w.rf>
    <LM>w#w-d1t2729-1</LM>
   </w.rf>
   <form>kočkují</form>
   <lemma>kočkovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d-id144399-punct">
   <w.rf>
    <LM>w#w-d-id144399-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2729-4">
   <w.rf>
    <LM>w#w-d1t2729-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2729-3">
   <w.rf>
    <LM>w#w-d1t2729-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2729-5">
   <w.rf>
    <LM>w#w-d1t2729-5</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m038-d-id144454-punct">
   <w.rf>
    <LM>w#w-d-id144454-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2729-7">
   <w.rf>
    <LM>w#w-d1t2729-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m038-d1t2729-8">
   <w.rf>
    <LM>w#w-d1t2729-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2729-9">
   <w.rf>
    <LM>w#w-d1t2729-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t2729-10">
   <w.rf>
    <LM>w#w-d1t2729-10</LM>
   </w.rf>
   <form>malí</form>
   <lemma>malý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
 </s>
 <s id="m038-181">
  <m id="m038-d1t2729-12">
   <w.rf>
    <LM>w#w-d1t2729-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2729-13">
   <w.rf>
    <LM>w#w-d1t2729-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2729-16">
   <w.rf>
    <LM>w#w-d1t2729-16</LM>
   </w.rf>
   <form>normální</form>
   <lemma>normální</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-181-182">
   <w.rf>
    <LM>w#w-181-182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-184">
  <m id="m038-184-187">
   <w.rf>
    <LM>w#w-184-187</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2732-2">
   <w.rf>
    <LM>w#w-d1t2732-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2732-3">
   <w.rf>
    <LM>w#w-d1t2732-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2732-4">
   <w.rf>
    <LM>w#w-d1t2732-4</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m038-184-185">
   <w.rf>
    <LM>w#w-184-185</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-186">
  <m id="m038-d1t2732-8">
   <w.rf>
    <LM>w#w-d1t2732-8</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2732-9">
   <w.rf>
    <LM>w#w-d1t2732-9</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m038-d1t2732-11">
   <w.rf>
    <LM>w#w-d1t2732-11</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m038-d1t2732-12">
   <w.rf>
    <LM>w#w-d1t2732-12</LM>
   </w.rf>
   <form>lumpárnu</form>
   <lemma>lumpárna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1t2732-14">
   <w.rf>
    <LM>w#w-d1t2732-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m038-d1t2732-13">
   <w.rf>
    <LM>w#w-d1t2732-13</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2732-15">
   <w.rf>
    <LM>w#w-d1t2732-15</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2732-16">
   <w.rf>
    <LM>w#w-d1t2732-16</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m038-d-m-d1e2718-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2718-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2736-x2">
  <m id="m038-d1t2739-1">
   <w.rf>
    <LM>w#w-d1t2739-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m038-d-m-d1e2736-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2736-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2740-x2">
  <m id="m038-d1t2745-1">
   <w.rf>
    <LM>w#w-d1t2745-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2745-2">
   <w.rf>
    <LM>w#w-d1t2745-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2745-3">
   <w.rf>
    <LM>w#w-d1t2745-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2745-4">
   <w.rf>
    <LM>w#w-d1t2745-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2745-5">
   <w.rf>
    <LM>w#w-d1t2745-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m038-d-m-d1e2740-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2740-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2740-x3">
  <m id="m038-d1t2747-2">
   <w.rf>
    <LM>w#w-d1t2747-2</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m038-d1t2747-3">
   <w.rf>
    <LM>w#w-d1t2747-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m038-d1t2747-4">
   <w.rf>
    <LM>w#w-d1t2747-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m038-d1t2747-5">
   <w.rf>
    <LM>w#w-d1t2747-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2740-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2740-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2740-x4">
  <m id="m038-d1t2756-1">
   <w.rf>
    <LM>w#w-d1t2756-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m038-d1t2756-2">
   <w.rf>
    <LM>w#w-d1t2756-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2756-3">
   <w.rf>
    <LM>w#w-d1t2756-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2756-4">
   <w.rf>
    <LM>w#w-d1t2756-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d-id145259-punct">
   <w.rf>
    <LM>w#w-d-id145259-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2757-x2">
  <m id="m038-d1t2760-1">
   <w.rf>
    <LM>w#w-d1t2760-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2760-2">
   <w.rf>
    <LM>w#w-d1t2760-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2760-3">
   <w.rf>
    <LM>w#w-d1t2760-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2760-4">
   <w.rf>
    <LM>w#w-d1t2760-4</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m038-d1t2762-1">
   <w.rf>
    <LM>w#w-d1t2762-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m038-d1t2762-2">
   <w.rf>
    <LM>w#w-d1t2762-2</LM>
   </w.rf>
   <form>švagrem</form>
   <lemma>švagr</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m038-d1t2762-3">
   <w.rf>
    <LM>w#w-d1t2762-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2762-4">
   <w.rf>
    <LM>w#w-d1t2762-4</LM>
   </w.rf>
   <form>švagrovou</form>
   <lemma>švagrová</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m038-d1e2757-x2-199">
   <w.rf>
    <LM>w#w-d1e2757-x2-199</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-200">
  <m id="m038-d1t2764-1">
   <w.rf>
    <LM>w#w-d1t2764-1</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t2764-2">
   <w.rf>
    <LM>w#w-d1t2764-2</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2764-3">
   <w.rf>
    <LM>w#w-d1t2764-3</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2764-4">
   <w.rf>
    <LM>w#w-d1t2764-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m038-d-id145526-punct">
   <w.rf>
    <LM>w#w-d-id145526-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2764-7">
   <w.rf>
    <LM>w#w-d1t2764-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m038-d1t2764-9">
   <w.rf>
    <LM>w#w-d1t2764-9</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2764-10">
   <w.rf>
    <LM>w#w-d1t2764-10</LM>
   </w.rf>
   <form>běhá</form>
   <lemma>běhat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2764-11">
   <w.rf>
    <LM>w#w-d1t2764-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2764-12">
   <w.rf>
    <LM>w#w-d1t2764-12</LM>
   </w.rf>
   <form>lese</form>
   <lemma>les</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2757-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2757-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2769-x2">
  <m id="m038-d1t2774-1">
   <w.rf>
    <LM>w#w-d1t2774-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2774-2">
   <w.rf>
    <LM>w#w-d1t2774-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e2769-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2769-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2769-x2-202">
   <w.rf>
    <LM>w#w-d1e2769-x2-202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1e2769-x2-204">
   <w.rf>
    <LM>w#w-d1e2769-x2-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2769-x3">
  <m id="m038-d1t2778-1">
   <w.rf>
    <LM>w#w-d1t2778-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2778-2">
   <w.rf>
    <LM>w#w-d1t2778-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m038-d1t2778-3">
   <w.rf>
    <LM>w#w-d1t2778-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d-id145799-punct">
   <w.rf>
    <LM>w#w-d-id145799-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2779-x2">
  <m id="m038-d1t2786-1">
   <w.rf>
    <LM>w#w-d1t2786-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2786-2">
   <w.rf>
    <LM>w#w-d1t2786-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2786-3">
   <w.rf>
    <LM>w#w-d1t2786-3</LM>
   </w.rf>
   <form>jezero</form>
   <lemma>jezero</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m038-d1t2786-5">
   <w.rf>
    <LM>w#w-d1t2786-5</LM>
   </w.rf>
   <form>Laka</form>
   <lemma>Laka_;G_^(jezero_na_Šumavě)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t2788-1">
   <w.rf>
    <LM>w#w-d1t2788-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m038-d1t2788-3">
   <w.rf>
    <LM>w#w-d1t2788-3</LM>
   </w.rf>
   <form>Špičáku</form>
   <lemma>Špičák-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m038-d-m-d1e2779-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2779-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2789-x2">
  <m id="m038-d1t2804-2">
   <w.rf>
    <LM>w#w-d1t2804-2</LM>
   </w.rf>
   <form>Fanda</form>
   <lemma>Fanda_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m038-d1t2804-4">
   <w.rf>
    <LM>w#w-d1t2804-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2804-6">
   <w.rf>
    <LM>w#w-d1t2804-6</LM>
   </w.rf>
   <form>Hanina</form>
   <lemma>Hanina_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1t2794-3">
   <w.rf>
    <LM>w#w-d1t2794-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2794-4">
   <w.rf>
    <LM>w#w-d1t2794-4</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2794-6">
   <w.rf>
    <LM>w#w-d1t2794-6</LM>
   </w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m038-d1e2789-x2-233">
   <w.rf>
    <LM>w#w-d1e2789-x2-233</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2804-10">
   <w.rf>
    <LM>w#w-d1t2804-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2804-11">
   <w.rf>
    <LM>w#w-d1t2804-11</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m038-d1t2804-13">
   <w.rf>
    <LM>w#w-d1t2804-13</LM>
   </w.rf>
   <form>pozvali</form>
   <lemma>pozvat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m038-d1e2789-x2-234">
   <w.rf>
    <LM>w#w-d1e2789-x2-234</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-d1e2799-x2">
  <m id="m038-d1t2804-17">
   <w.rf>
    <LM>w#w-d1t2804-17</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m038-d1t2804-16">
   <w.rf>
    <LM>w#w-d1t2804-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m038-d1t2804-18">
   <w.rf>
    <LM>w#w-d1t2804-18</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m038-d1t2804-19">
   <w.rf>
    <LM>w#w-d1t2804-19</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m038-d-id146498-punct">
   <w.rf>
    <LM>w#w-d-id146498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2804-21">
   <w.rf>
    <LM>w#w-d1t2804-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m038-d1t2804-22">
   <w.rf>
    <LM>w#w-d1t2804-22</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2804-23">
   <w.rf>
    <LM>w#w-d1t2804-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m038-d1t2804-24">
   <w.rf>
    <LM>w#w-d1t2804-24</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m038-d1t2804-25">
   <w.rf>
    <LM>w#w-d1t2804-25</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m038-d1t2804-27">
   <w.rf>
    <LM>w#w-d1t2804-27</LM>
   </w.rf>
   <form>jezera</form>
   <lemma>jezero</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m038-d1t2804-29">
   <w.rf>
    <LM>w#w-d1t2804-29</LM>
   </w.rf>
   <form>Laka</form>
   <lemma>Laka_;G_^(jezero_na_Šumavě)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m038-d1e2799-x2-235">
   <w.rf>
    <LM>w#w-d1e2799-x2-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-236">
  <m id="m038-d1t2804-32">
   <w.rf>
    <LM>w#w-d1t2804-32</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d1t2804-33">
   <w.rf>
    <LM>w#w-d1t2804-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2804-34">
   <w.rf>
    <LM>w#w-d1t2804-34</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-236-237">
   <w.rf>
    <LM>w#w-236-237</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m038-d1t2804-36">
   <w.rf>
    <LM>w#w-d1t2804-36</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2804-37">
   <w.rf>
    <LM>w#w-d1t2804-37</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m038-236-239">
   <w.rf>
    <LM>w#w-236-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m038-240">
  <m id="m038-d1t2806-1">
   <w.rf>
    <LM>w#w-d1t2806-1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m038-d1t2806-2">
   <w.rf>
    <LM>w#w-d1t2806-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m038-d1t2806-3">
   <w.rf>
    <LM>w#w-d1t2806-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m038-d1t2806-4">
   <w.rf>
    <LM>w#w-d1t2806-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m038-d1t2806-5">
   <w.rf>
    <LM>w#w-d1t2806-5</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m038-d-m-d1e2799-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2799-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
