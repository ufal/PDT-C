<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_993.01.w.gz" />
  </references>
 </head>
 <s id="m993-25819_03-d1e253-x2">
  <m id="m993-d1t256-1">
   <w.rf>
    <LM>w#w-d1t256-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t256-2">
   <w.rf>
    <LM>w#w-d1t256-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t256-3">
   <w.rf>
    <LM>w#w-d1t256-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t256-4">
   <w.rf>
    <LM>w#w-d1t256-4</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d-id65988">
   <w.rf>
    <LM>w#w-d-id65988</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e257-x2">
  <m id="m993-d1t262-1">
   <w.rf>
    <LM>w#w-d1t262-1</LM>
   </w.rf>
   <form>Cože</form>
   <lemma>cože-1</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m993-d-id66077">
   <w.rf>
    <LM>w#w-d-id66077</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e263-x2">
  <m id="m993-d1t266-1">
   <w.rf>
    <LM>w#w-d1t266-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t266-2">
   <w.rf>
    <LM>w#w-d1t266-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t266-3">
   <w.rf>
    <LM>w#w-d1t266-3</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t268-1">
   <w.rf>
    <LM>w#w-d1t268-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m993-d1t268-2">
   <w.rf>
    <LM>w#w-d1t268-2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m993-d1t268-3">
   <w.rf>
    <LM>w#w-d1t268-3</LM>
   </w.rf>
   <form>transportu</form>
   <lemma>transport</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m993-d-id66231">
   <w.rf>
    <LM>w#w-d-id66231</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e269-x2">
  <m id="m993-d1t276-2">
   <w.rf>
    <LM>w#w-d1t276-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t276-3">
   <w.rf>
    <LM>w#w-d1t276-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t276-4">
   <w.rf>
    <LM>w#w-d1t276-4</LM>
   </w.rf>
   <form>věděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d-id66477">
   <w.rf>
    <LM>w#w-d-id66477</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t276-6">
   <w.rf>
    <LM>w#w-d1t276-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t276-7">
   <w.rf>
    <LM>w#w-d1t276-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t276-8">
   <w.rf>
    <LM>w#w-d1t276-8</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m993-d1t276-9">
   <w.rf>
    <LM>w#w-d1t276-9</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m993-d1t276-10">
   <w.rf>
    <LM>w#w-d1t276-10</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t278-1">
   <w.rf>
    <LM>w#w-d1t278-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t278-2">
   <w.rf>
    <LM>w#w-d1t278-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t278-3">
   <w.rf>
    <LM>w#w-d1t278-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t278-4">
   <w.rf>
    <LM>w#w-d1t278-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m993-d1t278-5">
   <w.rf>
    <LM>w#w-d1t278-5</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d1e269-x2-224">
   <w.rf>
    <LM>w#w-d1e269-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-225">
  <m id="m993-d1t278-7">
   <w.rf>
    <LM>w#w-d1t278-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t278-10">
   <w.rf>
    <LM>w#w-d1t278-10</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t278-9">
   <w.rf>
    <LM>w#w-d1t278-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t278-11">
   <w.rf>
    <LM>w#w-d1t278-11</LM>
   </w.rf>
   <form>doufala</form>
   <lemma>doufat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d-id66736">
   <w.rf>
    <LM>w#w-d-id66736</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t278-13">
   <w.rf>
    <LM>w#w-d1t278-13</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t278-15">
   <w.rf>
    <LM>w#w-d1t278-15</LM>
   </w.rf>
   <form>nepřijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-NAP--</tag>
  </m>
  <m id="m993-d1e269-x2-2172">
   <w.rf>
    <LM>w#w-d1e269-x2-2172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-2165">
  <m id="m993-d1t278-20">
   <w.rf>
    <LM>w#w-d1t278-20</LM>
   </w.rf>
   <form>Hledala</form>
   <lemma>hledat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t278-18">
   <w.rf>
    <LM>w#w-d1t278-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t278-19">
   <w.rf>
    <LM>w#w-d1t278-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m993-d-id66862">
   <w.rf>
    <LM>w#w-d-id66862</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-2165-1703">
   <w.rf>
    <LM>w#w-2165-1703</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t280-6">
   <w.rf>
    <LM>w#w-d1t280-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t280-5">
   <w.rf>
    <LM>w#w-d1t280-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t280-7">
   <w.rf>
    <LM>w#w-d1t280-7</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m993-d1t280-9">
   <w.rf>
    <LM>w#w-d1t280-9</LM>
   </w.rf>
   <form>chránění</form>
   <lemma>chráněný_^(*3it)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m993-d-id67005">
   <w.rf>
    <LM>w#w-d-id67005</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t280-11">
   <w.rf>
    <LM>w#w-d1t280-11</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t280-13">
   <w.rf>
    <LM>w#w-d1t280-13</LM>
   </w.rf>
   <form>Reslerovi</form>
   <lemma>Reslerův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m993-d1t280-15">
   <w.rf>
    <LM>w#w-d1t280-15</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t280-16">
   <w.rf>
    <LM>w#w-d1t280-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t280-18">
   <w.rf>
    <LM>w#w-d1t280-18</LM>
   </w.rf>
   <form>Ältestenratu</form>
   <lemma>Ältestenrat_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m993-d-id67147">
   <w.rf>
    <LM>w#w-d-id67147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e281-x2">
  <m id="m993-d1t286-1">
   <w.rf>
    <LM>w#w-d1t286-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m993-d1t286-2">
   <w.rf>
    <LM>w#w-d1t286-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t286-3">
   <w.rf>
    <LM>w#w-d1t286-3</LM>
   </w.rf>
   <form>Reslerovi</form>
   <lemma>Reslerův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m993-d-id67262">
   <w.rf>
    <LM>w#w-d-id67262</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e281-x5">
  <m id="m993-d1t299-1">
   <w.rf>
    <LM>w#w-d1t299-1</LM>
   </w.rf>
   <form>Reslerovi</form>
   <lemma>Reslerův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m993-d1t311-5">
   <w.rf>
    <LM>w#w-d1t311-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t311-2">
   <w.rf>
    <LM>w#w-d1t311-2</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m993-d1t311-3">
   <w.rf>
    <LM>w#w-d1t311-3</LM>
   </w.rf>
   <form>bratři</form>
   <lemma>bratr</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m993-d1e281-x5-1775">
   <w.rf>
    <LM>w#w-d1e281-x5-1775</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1e281-x5-1776">
   <w.rf>
    <LM>w#w-d1e281-x5-1776</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m993-d1t322-1">
   <w.rf>
    <LM>w#w-d1t322-1</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1-------</tag>
  </m>
  <m id="m993-d1t322-2">
   <w.rf>
    <LM>w#w-d1t322-2</LM>
   </w.rf>
   <form>matku</form>
   <lemma>matka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m993-d1t322-3">
   <w.rf>
    <LM>w#w-d1t322-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t322-4">
   <w.rf>
    <LM>w#w-d1t322-4</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m993-d1t317-6">
   <w.rf>
    <LM>w#w-d1t317-6</LM>
   </w.rf>
   <form>chránili</form>
   <lemma>chránit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1e281-x5-240">
   <w.rf>
    <LM>w#w-d1e281-x5-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-241">
  <m id="m993-d1t322-7">
   <w.rf>
    <LM>w#w-d1t322-7</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t322-8">
   <w.rf>
    <LM>w#w-d1t322-8</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m993-d1t322-9">
   <w.rf>
    <LM>w#w-d1t322-9</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m993-d-id67892">
   <w.rf>
    <LM>w#w-d-id67892</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t322-11">
   <w.rf>
    <LM>w#w-d1t322-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t322-17">
   <w.rf>
    <LM>w#w-d1t322-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t322-12">
   <w.rf>
    <LM>w#w-d1t322-12</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t322-14">
   <w.rf>
    <LM>w#w-d1t322-14</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m993-d1t322-16">
   <w.rf>
    <LM>w#w-d1t322-16</LM>
   </w.rf>
   <form>transportu</form>
   <lemma>transport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m993-d1t322-18">
   <w.rf>
    <LM>w#w-d1t322-18</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m993-d1e281-x5-2591">
   <w.rf>
    <LM>w#w-d1e281-x5-2591</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e306-x4">
  <m id="m993-d1t326-1">
   <w.rf>
    <LM>w#w-d1t326-1</LM>
   </w.rf>
   <form>Chápete</form>
   <lemma>chápat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t326-2">
   <w.rf>
    <LM>w#w-d1t326-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m993-d-id68104">
   <w.rf>
    <LM>w#w-d-id68104</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e327-x2">
  <m id="m993-d1t330-1">
   <w.rf>
    <LM>w#w-d1t330-1</LM>
   </w.rf>
   <form>Chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d-id68178">
   <w.rf>
    <LM>w#w-d-id68178</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t332-1">
   <w.rf>
    <LM>w#w-d1t332-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t332-2">
   <w.rf>
    <LM>w#w-d1t332-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m993-d-id68213">
   <w.rf>
    <LM>w#w-d-id68213</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t332-4">
   <w.rf>
    <LM>w#w-d1t332-4</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m993-d1t332-6">
   <w.rf>
    <LM>w#w-d1t332-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t332-8">
   <w.rf>
    <LM>w#w-d1t332-8</LM>
   </w.rf>
   <form>Reslerovi</form>
   <lemma>Reslerův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m993-d-id68279">
   <w.rf>
    <LM>w#w-d-id68279</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t332-10">
   <w.rf>
    <LM>w#w-d1t332-10</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m993-d1t332-11">
   <w.rf>
    <LM>w#w-d1t332-11</LM>
   </w.rf>
   <form>bratři</form>
   <lemma>bratr</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m993-d-id68305">
   <w.rf>
    <LM>w#w-d-id68305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e338-x2">
  <m id="m993-d1t341-1">
   <w.rf>
    <LM>w#w-d1t341-1</LM>
   </w.rf>
   <form>Čí</form>
   <lemma>čí</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m993-d1t341-2">
   <w.rf>
    <LM>w#w-d1t341-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t341-3">
   <w.rf>
    <LM>w#w-d1t341-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t341-4">
   <w.rf>
    <LM>w#w-d1t341-4</LM>
   </w.rf>
   <form>bratři</form>
   <lemma>bratr</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m993-d-id68515">
   <w.rf>
    <LM>w#w-d-id68515</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e344-x2">
  <m id="m993-d1t347-1">
   <w.rf>
    <LM>w#w-d1t347-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m993-d1t351-5">
   <w.rf>
    <LM>w#w-d1t351-5</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m993-d1t351-6">
   <w.rf>
    <LM>w#w-d1t351-6</LM>
   </w.rf>
   <form>Reslerové</form>
   <lemma>Reslerová_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m993-d-id68730">
   <w.rf>
    <LM>w#w-d-id68730</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e344-x3">
  <m id="m993-d1t355-1">
   <w.rf>
    <LM>w#w-d1t355-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m993-d1t358-1">
   <w.rf>
    <LM>w#w-d1t358-1</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m993-d1t355-2">
   <w.rf>
    <LM>w#w-d1t355-2</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m993-d1t355-3">
   <w.rf>
    <LM>w#w-d1t355-3</LM>
   </w.rf>
   <form>strýce</form>
   <lemma>strýc</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m993-d-id68834">
   <w.rf>
    <LM>w#w-d-id68834</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e359-x2">
  <m id="m993-d1t362-1">
   <w.rf>
    <LM>w#w-d1t362-1</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m993-d-id68939">
   <w.rf>
    <LM>w#w-d-id68939</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e363-x2">
  <m id="m993-d1t370-3">
   <w.rf>
    <LM>w#w-d1t370-3</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m993-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t370-5">
   <w.rf>
    <LM>w#w-d1t370-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t370-6">
   <w.rf>
    <LM>w#w-d1t370-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t370-7">
   <w.rf>
    <LM>w#w-d1t370-7</LM>
   </w.rf>
   <form>zamiloval</form>
   <lemma>zamilovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m993-d1e363-x2-2911">
   <w.rf>
    <LM>w#w-d1e363-x2-2911</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t370-9">
   <w.rf>
    <LM>w#w-d1t370-9</LM>
   </w.rf>
   <form>oženil</form>
   <lemma>oženit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m993-d1t370-10">
   <w.rf>
    <LM>w#w-d1t370-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t370-11">
   <w.rf>
    <LM>w#w-d1t370-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1e363-x2-2919">
   <w.rf>
    <LM>w#w-d1e363-x2-2919</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-2912">
  <m id="m993-d1t370-13">
   <w.rf>
    <LM>w#w-d1t370-13</LM>
   </w.rf>
   <form>Nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m993-d1t370-14">
   <w.rf>
    <LM>w#w-d1t370-14</LM>
   </w.rf>
   <form>Ilse</form>
   <lemma>Ilse_;Y</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m993-d1t370-15">
   <w.rf>
    <LM>w#w-d1t370-15</LM>
   </w.rf>
   <form>Frankfurter</form>
   <lemma>Frankfurter-2_;Y</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m993-2912-2929">
   <w.rf>
    <LM>w#w-2912-2929</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t372-1">
   <w.rf>
    <LM>w#w-d1t372-1</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t372-2">
   <w.rf>
    <LM>w#w-d1t372-2</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m993-d1t372-3">
   <w.rf>
    <LM>w#w-d1t372-3</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d-id69311">
   <w.rf>
    <LM>w#w-d-id69311</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e363-x4">
  <m id="m993-d1t377-2">
   <w.rf>
    <LM>w#w-d1t377-2</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m993-d1t377-3">
   <w.rf>
    <LM>w#w-d1t377-3</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t377-4">
   <w.rf>
    <LM>w#w-d1t377-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m993-d1t377-5">
   <w.rf>
    <LM>w#w-d1t377-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t377-6">
   <w.rf>
    <LM>w#w-d1t377-6</LM>
   </w.rf>
   <form>kuchyni</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m993-d1t381-3">
   <w.rf>
    <LM>w#w-d1t381-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t381-6">
   <w.rf>
    <LM>w#w-d1t381-6</LM>
   </w.rf>
   <form>Kavalíru</form>
   <lemma>Kavalír-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m993-d1e363-x4-190">
   <w.rf>
    <LM>w#w-d1e363-x4-190</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t385-1">
   <w.rf>
    <LM>w#w-d1t385-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t385-2">
   <w.rf>
    <LM>w#w-d1t385-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t387-2">
   <w.rf>
    <LM>w#w-d1t387-2</LM>
   </w.rf>
   <form>kasárna</form>
   <lemma>kasárna</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m993-d1t387-3">
   <w.rf>
    <LM>w#w-d1t387-3</LM>
   </w.rf>
   <form>Kavalír</form>
   <lemma>Kavalír-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m993-d1e363-x4-191">
   <w.rf>
    <LM>w#w-d1e363-x4-191</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t390-1">
   <w.rf>
    <LM>w#w-d1t390-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t390-4">
   <w.rf>
    <LM>w#w-d1t390-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m993-d1t390-5">
   <w.rf>
    <LM>w#w-d1t390-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t390-3">
   <w.rf>
    <LM>w#w-d1t390-3</LM>
   </w.rf>
   <form>ukradl</form>
   <lemma>ukradnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m993-d-id69659">
   <w.rf>
    <LM>w#w-d-id69659</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-183">
  <m id="m993-d1t390-6">
   <w.rf>
    <LM>w#w-d1t390-6</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t390-7">
   <w.rf>
    <LM>w#w-d1t390-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t390-8">
   <w.rf>
    <LM>w#w-d1t390-8</LM>
   </w.rf>
   <form>kradlo</form>
   <lemma>krást</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m993-183-320">
   <w.rf>
    <LM>w#w-183-320</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-312">
  <m id="m993-d1t392-5">
   <w.rf>
    <LM>w#w-d1t392-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t392-8">
   <w.rf>
    <LM>w#w-d1t392-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t392-9">
   <w.rf>
    <LM>w#w-d1t392-9</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m993-312-331">
   <w.rf>
    <LM>w#w-312-331</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-323">
  <m id="m993-d1t392-11">
   <w.rf>
    <LM>w#w-d1t392-11</LM>
   </w.rf>
   <form>Abyste</form>
   <lemma>aby</lemma>
   <tag>J,-----------e-</tag>
  </m>
  <m id="m993-d1t392-12">
   <w.rf>
    <LM>w#w-d1t392-12</LM>
   </w.rf>
   <form>přežila</form>
   <lemma>přežít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m993-323-335">
   <w.rf>
    <LM>w#w-323-335</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t392-13">
   <w.rf>
    <LM>w#w-d1t392-13</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t392-14">
   <w.rf>
    <LM>w#w-d1t392-14</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t392-15">
   <w.rf>
    <LM>w#w-d1t392-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m993-d1t392-16">
   <w.rf>
    <LM>w#w-d1t392-16</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m993-d1t392-17">
   <w.rf>
    <LM>w#w-d1t392-17</LM>
   </w.rf>
   <form>ukrást</form>
   <lemma>ukradnout</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m993-323-345">
   <w.rf>
    <LM>w#w-323-345</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-337">
  <m id="m993-d1t394-6">
   <w.rf>
    <LM>w#w-d1t394-6</LM>
   </w.rf>
   <form>Celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m993-d1t394-7">
   <w.rf>
    <LM>w#w-d1t394-7</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d1t394-4">
   <w.rf>
    <LM>w#w-d1t394-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m993-d1t394-5">
   <w.rf>
    <LM>w#w-d1t394-5</LM>
   </w.rf>
   <form>trest</form>
   <lemma>trest</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d1t394-8">
   <w.rf>
    <LM>w#w-d1t394-8</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t394-9">
   <w.rf>
    <LM>w#w-d1t394-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m993-d1t394-10">
   <w.rf>
    <LM>w#w-d1t394-10</LM>
   </w.rf>
   <form>transportu</form>
   <lemma>transport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m993-337-519">
   <w.rf>
    <LM>w#w-337-519</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t394-11">
   <w.rf>
    <LM>w#w-d1t394-11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d1t396-1">
   <w.rf>
    <LM>w#w-d1t396-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m993-d1t396-2">
   <w.rf>
    <LM>w#w-d1t396-2</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t396-3">
   <w.rf>
    <LM>w#w-d1t396-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m993-337-278">
   <w.rf>
    <LM>w#w-337-278</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m993-337-279">
   <w.rf>
    <LM>w#w-337-279</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m993-337-516">
   <w.rf>
    <LM>w#w-337-516</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-509">
  <m id="m993-d1t396-6">
   <w.rf>
    <LM>w#w-d1t396-6</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d1t396-7">
   <w.rf>
    <LM>w#w-d1t396-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t403-1">
   <w.rf>
    <LM>w#w-d1t403-1</LM>
   </w.rf>
   <form>nechtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m993-d1t403-2">
   <w.rf>
    <LM>w#w-d1t403-2</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m993-337-412">
   <w.rf>
    <LM>w#w-337-412</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t403-3">
   <w.rf>
    <LM>w#w-d1t403-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t403-4">
   <w.rf>
    <LM>w#w-d1t403-4</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t403-5">
   <w.rf>
    <LM>w#w-d1t403-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d-id70544">
   <w.rf>
    <LM>w#w-d-id70544</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e363-x6">
  <m id="m993-d1t405-4">
   <w.rf>
    <LM>w#w-d1t405-4</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t405-3">
   <w.rf>
    <LM>w#w-d1t405-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t405-5">
   <w.rf>
    <LM>w#w-d1t405-5</LM>
   </w.rf>
   <form>doufala</form>
   <lemma>doufat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d-id70645">
   <w.rf>
    <LM>w#w-d-id70645</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t405-9">
   <w.rf>
    <LM>w#w-d1t405-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t405-10">
   <w.rf>
    <LM>w#w-d1t405-10</LM>
   </w.rf>
   <form>přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m993-d1t405-12">
   <w.rf>
    <LM>w#w-d1t405-12</LM>
   </w.rf>
   <form>transporty</form>
   <lemma>transport</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m993-d1e363-x6-573">
   <w.rf>
    <LM>w#w-d1e363-x6-573</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t405-13">
   <w.rf>
    <LM>w#w-d1t405-13</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4IP1----------</tag>
  </m>
  <m id="m993-d1t405-14">
   <w.rf>
    <LM>w#w-d1t405-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t405-15">
   <w.rf>
    <LM>w#w-d1t405-15</LM>
   </w.rf>
   <form>vracely</form>
   <lemma>vracet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m993-d-id70794">
   <w.rf>
    <LM>w#w-d-id70794</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t405-17">
   <w.rf>
    <LM>w#w-d1t405-17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t405-18">
   <w.rf>
    <LM>w#w-d1t405-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m993-d1t405-19">
   <w.rf>
    <LM>w#w-d1t405-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t405-20">
   <w.rf>
    <LM>w#w-d1t405-20</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t405-21">
   <w.rf>
    <LM>w#w-d1t405-21</LM>
   </w.rf>
   <form>uvidím</form>
   <lemma>uvidět</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m993-d1e363-x6-575">
   <w.rf>
    <LM>w#w-d1e363-x6-575</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e406-x2">
  <m id="m993-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d-id70947">
   <w.rf>
    <LM>w#w-d-id70947</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e410-x2">
  <m id="m993-d1t415-2">
   <w.rf>
    <LM>w#w-d1t415-2</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d1t421-1">
   <w.rf>
    <LM>w#w-d1t421-1</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m993-d1t421-2">
   <w.rf>
    <LM>w#w-d1t421-2</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m993-d1t419-2">
   <w.rf>
    <LM>w#w-d1t419-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>cholera</form>
   <lemma>cholera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d1e410-x2-674">
   <w.rf>
    <LM>w#w-d1e410-x2-674</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t426-4">
   <w.rf>
    <LM>w#w-d1t426-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t426-5">
   <w.rf>
    <LM>w#w-d1t426-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m993-d1t426-6">
   <w.rf>
    <LM>w#w-d1t426-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t428-1">
   <w.rf>
    <LM>w#w-d1t428-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m993-d-id71352">
   <w.rf>
    <LM>w#w-d-id71352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e410-x3">
  <m id="m993-d1t432-1">
   <w.rf>
    <LM>w#w-d1t432-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t432-2">
   <w.rf>
    <LM>w#w-d1t432-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m993-d1t432-3">
   <w.rf>
    <LM>w#w-d1t432-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t432-4">
   <w.rf>
    <LM>w#w-d1t432-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t432-5">
   <w.rf>
    <LM>w#w-d1t432-5</LM>
   </w.rf>
   <form>nemyslí</form>
   <lemma>myslit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m993-d-id71456">
   <w.rf>
    <LM>w#w-d-id71456</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e410-x4">
  <m id="m993-d1t434-3">
   <w.rf>
    <LM>w#w-d1t434-3</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t434-4">
   <w.rf>
    <LM>w#w-d1t434-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t434-5">
   <w.rf>
    <LM>w#w-d1t434-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t434-8">
   <w.rf>
    <LM>w#w-d1t434-8</LM>
   </w.rf>
   <form>vracela</form>
   <lemma>vracet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d-id71465">
   <w.rf>
    <LM>w#w-d-id71465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e435-x2">
  <m id="m993-d1t440-1">
   <w.rf>
    <LM>w#w-d1t440-1</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t440-2">
   <w.rf>
    <LM>w#w-d1t440-2</LM>
   </w.rf>
   <form>tyfus</form>
   <lemma>tyfus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d-id71688">
   <w.rf>
    <LM>w#w-d-id71688</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e445-x2">
  <m id="m993-d1t448-1">
   <w.rf>
    <LM>w#w-d1t448-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d-id71786">
   <w.rf>
    <LM>w#w-d-id71786</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e449-x2">
  <m id="m993-d1t454-1">
   <w.rf>
    <LM>w#w-d1t454-1</LM>
   </w.rf>
   <form>Tyfus</form>
   <lemma>tyfus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d1t454-4">
   <w.rf>
    <LM>w#w-d1t454-4</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t454-6">
   <w.rf>
    <LM>w#w-d1t454-6</LM>
   </w.rf>
   <form>mysli</form>
   <lemma>mysl</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m993-d-id71840">
   <w.rf>
    <LM>w#w-d-id71840</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e449-x3">
  <m id="m993-d1t456-2">
   <w.rf>
    <LM>w#w-d1t456-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-803-813">
   <w.rf>
    <LM>w#w-803-813</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t456-3">
   <w.rf>
    <LM>w#w-d1t456-3</LM>
   </w.rf>
   <form>tyfus</form>
   <lemma>tyfus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d-id71976">
   <w.rf>
    <LM>w#w-d-id71976</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x2">
  <m id="m993-d1t471-5">
   <w.rf>
    <LM>w#w-d1t471-5</LM>
   </w.rf>
   <form>Četníci</form>
   <lemma>četník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m993-d1t471-2">
   <w.rf>
    <LM>w#w-d1t471-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t471-3">
   <w.rf>
    <LM>w#w-d1t471-3</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m993-d1t471-4">
   <w.rf>
    <LM>w#w-d1t471-4</LM>
   </w.rf>
   <form>úplatní</form>
   <lemma>úplatný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m993-d-id72294">
   <w.rf>
    <LM>w#w-d-id72294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x3">
  <m id="m993-d1t475-1">
   <w.rf>
    <LM>w#w-d1t475-1</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m993-d1e457-x3-904">
   <w.rf>
    <LM>w#w-d1e457-x3-904</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-896">
  <m id="m993-d1t477-4">
   <w.rf>
    <LM>w#w-d1t477-4</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m993-d1t477-7">
   <w.rf>
    <LM>w#w-d1t477-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t477-5">
   <w.rf>
    <LM>w#w-d1t477-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m993-d1t477-8">
   <w.rf>
    <LM>w#w-d1t477-8</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-896-950">
   <w.rf>
    <LM>w#w-896-950</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t477-10">
   <w.rf>
    <LM>w#w-d1t477-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m993-d1t477-14">
   <w.rf>
    <LM>w#w-d1t477-14</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m993-d1t477-15">
   <w.rf>
    <LM>w#w-d1t477-15</LM>
   </w.rf>
   <form>můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t477-16">
   <w.rf>
    <LM>w#w-d1t477-16</LM>
   </w.rf>
   <form>komunikovat</form>
   <lemma>komunikovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m993-d1t477-17">
   <w.rf>
    <LM>w#w-d1t477-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t477-18">
   <w.rf>
    <LM>w#w-d1t477-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m993-d1t477-19">
   <w.rf>
    <LM>w#w-d1t477-19</LM>
   </w.rf>
   <form>kterým</form>
   <lemma>který</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m993-d1t477-20">
   <w.rf>
    <LM>w#w-d1t477-20</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d-id72622">
   <w.rf>
    <LM>w#w-d-id72622</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x4">
  <m id="m993-d1t479-1">
   <w.rf>
    <LM>w#w-d1t479-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t479-2">
   <w.rf>
    <LM>w#w-d1t479-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t479-3">
   <w.rf>
    <LM>w#w-d1t479-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m993-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>židovská</form>
   <lemma>židovský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m993-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m993-d-id72834">
   <w.rf>
    <LM>w#w-d-id72834</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x5">
  <m id="m993-d1t486-1">
   <w.rf>
    <LM>w#w-d1t486-1</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m993-d1t486-2">
   <w.rf>
    <LM>w#w-d1t486-2</LM>
   </w.rf>
   <form>legraci</form>
   <lemma>legrace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m993-d1e457-x5-1092">
   <w.rf>
    <LM>w#w-d1e457-x5-1092</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-1085">
  <m id="m993-d1t490-1">
   <w.rf>
    <LM>w#w-d1t490-1</LM>
   </w.rf>
   <form>Nosili</form>
   <lemma>nosit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t490-3">
   <w.rf>
    <LM>w#w-d1t490-3</LM>
   </w.rf>
   <form>pásky</form>
   <lemma>páska_^(proužek;_do_stroje)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m993-d1t490-4">
   <w.rf>
    <LM>w#w-d1t490-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t490-5">
   <w.rf>
    <LM>w#w-d1t490-5</LM>
   </w.rf>
   <form>čepice</form>
   <lemma>čepice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m993-1085-319">
   <w.rf>
    <LM>w#w-1085-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-320">
  <m id="m993-d1t492-4">
   <w.rf>
    <LM>w#w-d1t492-4</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m993-d1t492-5">
   <w.rf>
    <LM>w#w-d1t492-5</LM>
   </w.rf>
   <form>krást</form>
   <lemma>krást</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m993-d1t492-6">
   <w.rf>
    <LM>w#w-d1t492-6</LM>
   </w.rf>
   <form>brambory</form>
   <lemma>brambora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m993-1085-1167">
   <w.rf>
    <LM>w#w-1085-1167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-1168">
  <m id="m993-d1t501-1">
   <w.rf>
    <LM>w#w-d1t501-1</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t501-2">
   <w.rf>
    <LM>w#w-d1t501-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m993-d1t501-3">
   <w.rf>
    <LM>w#w-d1t501-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m993-d1t505-1">
   <w.rf>
    <LM>w#w-d1t505-1</LM>
   </w.rf>
   <form>bosáky</form>
   <lemma>bosák</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m993-1168-1228">
   <w.rf>
    <LM>w#w-1168-1228</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t505-5">
   <w.rf>
    <LM>w#w-d1t505-5</LM>
   </w.rf>
   <form>bramborové</form>
   <lemma>bramborový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m993-d1t505-6">
   <w.rf>
    <LM>w#w-d1t505-6</LM>
   </w.rf>
   <form>knedlíky</form>
   <lemma>knedlík</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m993-d1t505-7">
   <w.rf>
    <LM>w#w-d1t505-7</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m993-d1t505-9">
   <w.rf>
    <LM>w#w-d1t505-9</LM>
   </w.rf>
   <form>syrových</form>
   <lemma>syrový</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m993-d1t505-10">
   <w.rf>
    <LM>w#w-d1t505-10</LM>
   </w.rf>
   <form>brambor</form>
   <lemma>brambora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m993-d-id73489">
   <w.rf>
    <LM>w#w-d-id73489</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x6">
  <m id="m993-d1t510-1">
   <w.rf>
    <LM>w#w-d1t510-1</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m993-d1t510-3">
   <w.rf>
    <LM>w#w-d1t510-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t510-2">
   <w.rf>
    <LM>w#w-d1t510-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m993-d1t510-4">
   <w.rf>
    <LM>w#w-d1t510-4</LM>
   </w.rf>
   <form>ohýnek</form>
   <lemma>ohýnek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d-id73599">
   <w.rf>
    <LM>w#w-d-id73599</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e457-x7">
  <m id="m993-d1t514-3">
   <w.rf>
    <LM>w#w-d1t514-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t514-2">
   <w.rf>
    <LM>w#w-d1t514-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t514-6">
   <w.rf>
    <LM>w#w-d1t514-6</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m993-d1t514-7">
   <w.rf>
    <LM>w#w-d1t514-7</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AANS4----2A----</tag>
  </m>
  <m id="m993-d1t514-8">
   <w.rf>
    <LM>w#w-d1t514-8</LM>
   </w.rf>
   <form>ubytování</form>
   <lemma>ubytování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m993-d1e457-x7-1410">
   <w.rf>
    <LM>w#w-d1e457-x7-1410</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t514-9">
   <w.rf>
    <LM>w#w-d1t514-9</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1e457-x7-1411">
   <w.rf>
    <LM>w#w-d1e457-x7-1411</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d1t514-10">
   <w.rf>
    <LM>w#w-d1t514-10</LM>
   </w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m993-d1t514-11">
   <w.rf>
    <LM>w#w-d1t514-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m993-d1t514-12">
   <w.rf>
    <LM>w#w-d1t514-12</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS3-S1------1</tag>
  </m>
  <m id="m993-d1t514-13">
   <w.rf>
    <LM>w#w-d1t514-13</LM>
   </w.rf>
   <form>funkci</form>
   <lemma>funkce</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m993-d-id73845">
   <w.rf>
    <LM>w#w-d-id73845</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t516-1">
   <w.rf>
    <LM>w#w-d1t516-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t516-4">
   <w.rf>
    <LM>w#w-d1t516-4</LM>
   </w.rf>
   <form>nevydržela</form>
   <lemma>vydržet</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m993-d1t516-3">
   <w.rf>
    <LM>w#w-d1t516-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t516-2">
   <w.rf>
    <LM>w#w-d1t516-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1e457-x7-1414">
   <w.rf>
    <LM>w#w-d1e457-x7-1414</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t516-5">
   <w.rf>
    <LM>w#w-d1t516-5</LM>
   </w.rf>
   <form>ženské</form>
   <lemma>ženská_^(osoba)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m993-d1t516-7">
   <w.rf>
    <LM>w#w-d1t516-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m993-d1t516-8">
   <w.rf>
    <LM>w#w-d1t516-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m993-d1t516-6">
   <w.rf>
    <LM>w#w-d1t516-6</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m993-d1t516-9">
   <w.rf>
    <LM>w#w-d1t516-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t516-10">
   <w.rf>
    <LM>w#w-d1t516-10</LM>
   </w.rf>
   <form>vosy</form>
   <lemma>vosa</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m993-d-id74017">
   <w.rf>
    <LM>w#w-d-id74017</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e518-x2">
  <m id="m993-d1t521-3">
   <w.rf>
    <LM>w#w-d1t521-3</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m993-d1t521-8">
   <w.rf>
    <LM>w#w-d1t521-8</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t521-7">
   <w.rf>
    <LM>w#w-d1t521-7</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t521-4">
   <w.rf>
    <LM>w#w-d1t521-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t521-5">
   <w.rf>
    <LM>w#w-d1t521-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m993-d1t521-6">
   <w.rf>
    <LM>w#w-d1t521-6</LM>
   </w.rf>
   <form>funkci</form>
   <lemma>funkce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m993-d1t521-9">
   <w.rf>
    <LM>w#w-d1t521-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t521-10">
   <w.rf>
    <LM>w#w-d1t521-10</LM>
   </w.rf>
   <form>náplň</form>
   <lemma>náplň</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m993-d-id74191">
   <w.rf>
    <LM>w#w-d-id74191</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e524-x2">
  <m id="m993-d1t527-1">
   <w.rf>
    <LM>w#w-d1t527-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m993-d1t527-2">
   <w.rf>
    <LM>w#w-d1t527-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t527-3">
   <w.rf>
    <LM>w#w-d1t527-3</LM>
   </w.rf>
   <form>funkci</form>
   <lemma>funkce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m993-d1t529-1">
   <w.rf>
    <LM>w#w-d1t529-1</LM>
   </w.rf>
   <form>psát</form>
   <lemma>psát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m993-d1t529-2">
   <w.rf>
    <LM>w#w-d1t529-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t529-3">
   <w.rf>
    <LM>w#w-d1t529-3</LM>
   </w.rf>
   <form>stroji</form>
   <lemma>stroj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m993-d1t529-4">
   <w.rf>
    <LM>w#w-d1t529-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m993-d1t529-6">
   <w.rf>
    <LM>w#w-d1t529-6</LM>
   </w.rf>
   <form>hlášení</form>
   <lemma>hlášení_^(*4sit)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m993-d-id74428">
   <w.rf>
    <LM>w#w-d-id74428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e524-x3">
  <m id="m993-d1t533-1">
   <w.rf>
    <LM>w#w-d1t533-1</LM>
   </w.rf>
   <form>Ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m993-d1t533-6">
   <w.rf>
    <LM>w#w-d1t533-6</LM>
   </w.rf>
   <form>nemohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m993-d1t533-3">
   <w.rf>
    <LM>w#w-d1t533-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t533-4">
   <w.rf>
    <LM>w#w-d1t533-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m993-d1t533-5">
   <w.rf>
    <LM>w#w-d1t533-5</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m993-d1t533-7">
   <w.rf>
    <LM>w#w-d1t533-7</LM>
   </w.rf>
   <form>vyrovnat</form>
   <lemma>vyrovnat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m993-d1e524-x3-1530">
   <w.rf>
    <LM>w#w-d1e524-x3-1530</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-1531">
  <m id="m993-d1t533-13">
   <w.rf>
    <LM>w#w-d1t533-13</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m993-d1t533-12">
   <w.rf>
    <LM>w#w-d1t533-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t533-14">
   <w.rf>
    <LM>w#w-d1t533-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t533-15">
   <w.rf>
    <LM>w#w-d1t533-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m993-d1t533-16">
   <w.rf>
    <LM>w#w-d1t533-16</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m993-d1t533-17">
   <w.rf>
    <LM>w#w-d1t533-17</LM>
   </w.rf>
   <form>neviděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m993-d-id74711">
   <w.rf>
    <LM>w#w-d-id74711</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t533-21">
   <w.rf>
    <LM>w#w-d1t533-21</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t533-20">
   <w.rf>
    <LM>w#w-d1t533-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m993-d1t533-22">
   <w.rf>
    <LM>w#w-d1t533-22</LM>
   </w.rf>
   <form>zachránit</form>
   <lemma>zachránit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m993-d1t533-23">
   <w.rf>
    <LM>w#w-d1t533-23</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d-id74791">
   <w.rf>
    <LM>w#w-d-id74791</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t533-26">
   <w.rf>
    <LM>w#w-d1t533-26</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t533-27">
   <w.rf>
    <LM>w#w-d1t533-27</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t533-28">
   <w.rf>
    <LM>w#w-d1t533-28</LM>
   </w.rf>
   <form>diví</form>
   <lemma>divý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m993-1531-1594">
   <w.rf>
    <LM>w#w-1531-1594</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e524-x4">
  <m id="m993-d1t542-1">
   <w.rf>
    <LM>w#w-d1t542-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m993-d1t542-2">
   <w.rf>
    <LM>w#w-d1t542-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t542-3">
   <w.rf>
    <LM>w#w-d1t542-3</LM>
   </w.rf>
   <form>vztek</form>
   <lemma>vztek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m993-d-id74999">
   <w.rf>
    <LM>w#w-d-id74999</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m993-d1t544-6">
   <w.rf>
    <LM>w#w-d1t544-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m993-d1t544-7">
   <w.rf>
    <LM>w#w-d1t544-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m993-d1t544-8">
   <w.rf>
    <LM>w#w-d1t544-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m993-d1t544-3">
   <w.rf>
    <LM>w#w-d1t544-3</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t544-4">
   <w.rf>
    <LM>w#w-d1t544-4</LM>
   </w.rf>
   <form>Morgenstein</form>
   <lemma>Morgenstein_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m993-d1t544-10">
   <w.rf>
    <LM>w#w-d1t544-10</LM>
   </w.rf>
   <form>považoval</form>
   <lemma>považovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m993-d-id75330">
   <w.rf>
    <LM>w#w-d-id75330</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e552-x2">
  <m id="m993-d1t555-1">
   <w.rf>
    <LM>w#w-d1t555-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m993-d1t555-2">
   <w.rf>
    <LM>w#w-d1t555-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m993-d1t555-3">
   <w.rf>
    <LM>w#w-d1t555-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t555-4">
   <w.rf>
    <LM>w#w-d1t555-4</LM>
   </w.rf>
   <form>nevydržela</form>
   <lemma>vydržet</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m993-d1e552-x2-1698">
   <w.rf>
    <LM>w#w-d1e552-x2-1698</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-1690">
  <m id="m993-d1t557-2">
   <w.rf>
    <LM>w#w-d1t557-2</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t557-3">
   <w.rf>
    <LM>w#w-d1t557-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m993-d1t557-4">
   <w.rf>
    <LM>w#w-d1t557-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m993-d1t557-5">
   <w.rf>
    <LM>w#w-d1t557-5</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d-id75560">
   <w.rf>
    <LM>w#w-d-id75560</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m993-25819_03-d1e558-x2">
  <m id="m993-d1t563-3">
   <w.rf>
    <LM>w#w-d1t563-3</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m993-d1t563-4">
   <w.rf>
    <LM>w#w-d1t563-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m993-d1t563-5">
   <w.rf>
    <LM>w#w-d1t563-5</LM>
   </w.rf>
   <form>podplatila</form>
   <lemma>podplatit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m993-d1t563-8">
   <w.rf>
    <LM>w#w-d1t563-8</LM>
   </w.rf>
   <form>lékaře</form>
   <lemma>lékař</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m993-d1e558-x2-356">
   <w.rf>
    <LM>w#w-d1e558-x2-356</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
