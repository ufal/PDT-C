<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_027.03.w.gz" />
  </references>
 </head>
 <s id="m027-d1e842-x2">
  <m id="m027-d1t845-2">
   <w.rf>
    <LM>w#w-d1t845-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t845-3">
   <w.rf>
    <LM>w#w-d1t845-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t845-4">
   <w.rf>
    <LM>w#w-d1t845-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d-id85406-punct">
   <w.rf>
    <LM>w#w-d-id85406-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t845-6">
   <w.rf>
    <LM>w#w-d1t845-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m027-d1t845-7">
   <w.rf>
    <LM>w#w-d1t845-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t845-8">
   <w.rf>
    <LM>w#w-d1t845-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m027-d1t845-9">
   <w.rf>
    <LM>w#w-d1t845-9</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS3----------</tag>
  </m>
  <m id="m027-d1e842-x2-64">
   <w.rf>
    <LM>w#w-d1e842-x2-64</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-66">
  <m id="m027-d1t847-1">
   <w.rf>
    <LM>w#w-d1t847-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t847-3">
   <w.rf>
    <LM>w#w-d1t847-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-id85565-punct">
   <w.rf>
    <LM>w#w-d-id85565-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t847-5">
   <w.rf>
    <LM>w#w-d1t847-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t847-12">
   <w.rf>
    <LM>w#w-d1t847-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t847-11">
   <w.rf>
    <LM>w#w-d1t847-11</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t847-9">
   <w.rf>
    <LM>w#w-d1t847-9</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m027-d-id85693-punct">
   <w.rf>
    <LM>w#w-d-id85693-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t847-15">
   <w.rf>
    <LM>w#w-d1t847-15</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t847-16">
   <w.rf>
    <LM>w#w-d1t847-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t847-17">
   <w.rf>
    <LM>w#w-d1t847-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t847-19">
   <w.rf>
    <LM>w#w-d1t847-19</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-id85773-punct">
   <w.rf>
    <LM>w#w-d-id85773-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-66-68">
   <w.rf>
    <LM>w#w-66-68</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t847-21">
   <w.rf>
    <LM>w#w-d1t847-21</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t847-22">
   <w.rf>
    <LM>w#w-d1t847-22</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t847-23">
   <w.rf>
    <LM>w#w-d1t847-23</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t847-24">
   <w.rf>
    <LM>w#w-d1t847-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t849-1">
   <w.rf>
    <LM>w#w-d1t849-1</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t849-2">
   <w.rf>
    <LM>w#w-d1t849-2</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t849-3">
   <w.rf>
    <LM>w#w-d1t849-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t849-4">
   <w.rf>
    <LM>w#w-d1t849-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-m-d1e842-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e842-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e850-x2">
  <m id="m027-d1t855-1">
   <w.rf>
    <LM>w#w-d1t855-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t855-2">
   <w.rf>
    <LM>w#w-d1t855-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t855-3">
   <w.rf>
    <LM>w#w-d1t855-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t855-4">
   <w.rf>
    <LM>w#w-d1t855-4</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e850-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e850-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e858-x2">
  <m id="m027-d1t861-1">
   <w.rf>
    <LM>w#w-d1t861-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d1t861-2">
   <w.rf>
    <LM>w#w-d1t861-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t861-3">
   <w.rf>
    <LM>w#w-d1t861-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t861-5">
   <w.rf>
    <LM>w#w-d1t861-5</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t861-6">
   <w.rf>
    <LM>w#w-d1t861-6</LM>
   </w.rf>
   <form>mračím</form>
   <lemma>mračit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e858-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e858-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e862-x2">
  <m id="m027-d1t867-1">
   <w.rf>
    <LM>w#w-d1t867-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t867-2">
   <w.rf>
    <LM>w#w-d1t867-2</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m027-d1t867-3">
   <w.rf>
    <LM>w#w-d1t867-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m027-d1t867-4">
   <w.rf>
    <LM>w#w-d1t867-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t867-5">
   <w.rf>
    <LM>w#w-d1t867-5</LM>
   </w.rf>
   <form>patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e862-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e862-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e878-x2">
  <m id="m027-d1t881-1">
   <w.rf>
    <LM>w#w-d1t881-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id86628-punct">
   <w.rf>
    <LM>w#w-d-id86628-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t881-4">
   <w.rf>
    <LM>w#w-d1t881-4</LM>
   </w.rf>
   <form>jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t881-5">
   <w.rf>
    <LM>w#w-d1t881-5</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-m-d1e878-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e878-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e882-x2">
  <m id="m027-d1t885-1">
   <w.rf>
    <LM>w#w-d1t885-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e882-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e882-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e886-x3">
  <m id="m027-d1t893-1">
   <w.rf>
    <LM>w#w-d1t893-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m027-d1t893-2">
   <w.rf>
    <LM>w#w-d1t893-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t893-3">
   <w.rf>
    <LM>w#w-d1t893-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t893-4">
   <w.rf>
    <LM>w#w-d1t893-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t893-5">
   <w.rf>
    <LM>w#w-d1t893-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-id86903-punct">
   <w.rf>
    <LM>w#w-d-id86903-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e894-x2">
  <m id="m027-d1t897-2">
   <w.rf>
    <LM>w#w-d1t897-2</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t897-3">
   <w.rf>
    <LM>w#w-d1t897-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t897-4">
   <w.rf>
    <LM>w#w-d1t897-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1e894-x2-130">
   <w.rf>
    <LM>w#w-d1e894-x2-130</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e894-x2-132">
   <w.rf>
    <LM>w#w-d1e894-x2-132</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t897-20">
   <w.rf>
    <LM>w#w-d1t897-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t897-21">
   <w.rf>
    <LM>w#w-d1t897-21</LM>
   </w.rf>
   <form>vyfocená</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t897-22">
   <w.rf>
    <LM>w#w-d1t897-22</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t897-23">
   <w.rf>
    <LM>w#w-d1t897-23</LM>
   </w.rf>
   <form>mým</form>
   <lemma>můj</lemma>
   <tag>PSZS7-S1-------</tag>
  </m>
  <m id="m027-d1t897-24">
   <w.rf>
    <LM>w#w-d1t897-24</LM>
   </w.rf>
   <form>bratrem</form>
   <lemma>bratr</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m027-d1e894-x2-118">
   <w.rf>
    <LM>w#w-d1e894-x2-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-119">
  <m id="m027-d1t897-26">
   <w.rf>
    <LM>w#w-d1t897-26</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t897-27">
   <w.rf>
    <LM>w#w-d1t897-27</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t897-28">
   <w.rf>
    <LM>w#w-d1t897-28</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t897-29">
   <w.rf>
    <LM>w#w-d1t897-29</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t897-31">
   <w.rf>
    <LM>w#w-d1t897-31</LM>
   </w.rf>
   <form>Vlastík</form>
   <lemma>Vlastík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e894-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e894-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-120">
  <m id="m027-d1t897-8">
   <w.rf>
    <LM>w#w-d1t897-8</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t897-7">
   <w.rf>
    <LM>w#w-d1t897-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t897-9">
   <w.rf>
    <LM>w#w-d1t897-9</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t897-10">
   <w.rf>
    <LM>w#w-d1t897-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t897-13">
   <w.rf>
    <LM>w#w-d1t897-13</LM>
   </w.rf>
   <form>Litohlavech</form>
   <lemma>Litohlavy_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m027-120-122">
   <w.rf>
    <LM>w#w-120-122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-120-124">
   <w.rf>
    <LM>w#w-120-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-120-126">
   <w.rf>
    <LM>w#w-120-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e910-x2">
  <m id="m027-d1t905-1">
   <w.rf>
    <LM>w#w-d1t905-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m027-d1t905-2">
   <w.rf>
    <LM>w#w-d1t905-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m027-d1t905-3">
   <w.rf>
    <LM>w#w-d1t905-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t905-4">
   <w.rf>
    <LM>w#w-d1t905-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t905-5">
   <w.rf>
    <LM>w#w-d1t905-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t913-1">
   <w.rf>
    <LM>w#w-d1t913-1</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m027-d1t913-2">
   <w.rf>
    <LM>w#w-d1t913-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m027-d1e910-x2-180">
   <w.rf>
    <LM>w#w-d1e910-x2-180</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e910-x2-194">
   <w.rf>
    <LM>w#w-d1e910-x2-194</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t915-2">
   <w.rf>
    <LM>w#w-d1t915-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m027-d1t915-5">
   <w.rf>
    <LM>w#w-d1t915-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t915-4">
   <w.rf>
    <LM>w#w-d1t915-4</LM>
   </w.rf>
   <form>jedenáct</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1e910-x2-182">
   <w.rf>
    <LM>w#w-d1e910-x2-182</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t915-6">
   <w.rf>
    <LM>w#w-d1t915-6</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d-m-d1e910-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e910-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e917-x2">
  <m id="m027-d1t922-1">
   <w.rf>
    <LM>w#w-d1t922-1</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t922-2">
   <w.rf>
    <LM>w#w-d1t922-2</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m027-d1t922-3">
   <w.rf>
    <LM>w#w-d1t922-3</LM>
   </w.rf>
   <form>příležitosti</form>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t922-5">
   <w.rf>
    <LM>w#w-d1t922-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t922-6">
   <w.rf>
    <LM>w#w-d1t922-6</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-id87914-punct">
   <w.rf>
    <LM>w#w-d-id87914-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e925-x2">
  <m id="m027-d1t930-4">
   <w.rf>
    <LM>w#w-d1t930-4</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t930-5">
   <w.rf>
    <LM>w#w-d1t930-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-id88200-punct">
   <w.rf>
    <LM>w#w-d-id88200-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t930-7">
   <w.rf>
    <LM>w#w-d1t930-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t930-8">
   <w.rf>
    <LM>w#w-d1t930-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t930-9">
   <w.rf>
    <LM>w#w-d1t930-9</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t930-10">
   <w.rf>
    <LM>w#w-d1t930-10</LM>
   </w.rf>
   <form>kostelík</form>
   <lemma>kostelík</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d-id88271-punct">
   <w.rf>
    <LM>w#w-d-id88271-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t930-14">
   <w.rf>
    <LM>w#w-d1t930-14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t930-15">
   <w.rf>
    <LM>w#w-d1t930-15</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m027-d1t930-16">
   <w.rf>
    <LM>w#w-d1t930-16</LM>
   </w.rf>
   <form>slavnost</form>
   <lemma>slavnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id88357-punct">
   <w.rf>
    <LM>w#w-d-id88357-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t930-18">
   <w.rf>
    <LM>w#w-d1t930-18</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t930-19">
   <w.rf>
    <LM>w#w-d1t930-19</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t930-20">
   <w.rf>
    <LM>w#w-d1t930-20</LM>
   </w.rf>
   <form>tancovali</form>
   <lemma>tancovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t932-2">
   <w.rf>
    <LM>w#w-d1t932-2</LM>
   </w.rf>
   <form>Českou</form>
   <lemma>český</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t932-3">
   <w.rf>
    <LM>w#w-d1t932-3</LM>
   </w.rf>
   <form>besedu</form>
   <lemma>beseda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1e925-x2-133">
   <w.rf>
    <LM>w#w-d1e925-x2-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-135">
  <m id="m027-d1t934-2">
   <w.rf>
    <LM>w#w-d1t934-2</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t934-3">
   <w.rf>
    <LM>w#w-d1t934-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t934-4">
   <w.rf>
    <LM>w#w-d1t934-4</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m027-d1t934-5">
   <w.rf>
    <LM>w#w-d1t934-5</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m027-d1t934-6">
   <w.rf>
    <LM>w#w-d1t934-6</LM>
   </w.rf>
   <form>kroje</form>
   <lemma>kroj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1t934-7">
   <w.rf>
    <LM>w#w-d1t934-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t934-8">
   <w.rf>
    <LM>w#w-d1t934-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d1e925-x2-260">
   <w.rf>
    <LM>w#w-d1e925-x2-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e925-x2-262">
   <w.rf>
    <LM>w#w-d1e925-x2-262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e925-x2-264">
   <w.rf>
    <LM>w#w-d1e925-x2-264</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-266">
  <m id="m027-d1t934-16">
   <w.rf>
    <LM>w#w-d1t934-16</LM>
   </w.rf>
   <form>Počkejte</form>
   <lemma>počkat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m027-266-268">
   <w.rf>
    <LM>w#w-266-268</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t934-11">
   <w.rf>
    <LM>w#w-d1t934-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t934-12">
   <w.rf>
    <LM>w#w-d1t934-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t934-13">
   <w.rf>
    <LM>w#w-d1t934-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t934-14">
   <w.rf>
    <LM>w#w-d1t934-14</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t934-15">
   <w.rf>
    <LM>w#w-d1t934-15</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m027-266-139">
   <w.rf>
    <LM>w#w-266-139</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e943-x2">
  <m id="m027-d1t934-19">
   <w.rf>
    <LM>w#w-d1t934-19</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t934-20">
   <w.rf>
    <LM>w#w-d1t934-20</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t934-21">
   <w.rf>
    <LM>w#w-d1t934-21</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t934-22">
   <w.rf>
    <LM>w#w-d1t934-22</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t934-23">
   <w.rf>
    <LM>w#w-d1t934-23</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1t934-27">
   <w.rf>
    <LM>w#w-d1t934-27</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t946-1">
   <w.rf>
    <LM>w#w-d1t946-1</LM>
   </w.rf>
   <form>bratrovi</form>
   <lemma>bratr</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m027-d1t946-4">
   <w.rf>
    <LM>w#w-d1t946-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t946-2">
   <w.rf>
    <LM>w#w-d1t946-2</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t946-6">
   <w.rf>
    <LM>w#w-d1t946-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m027-d1t946-7">
   <w.rf>
    <LM>w#w-d1t946-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m027-d1t946-13">
   <w.rf>
    <LM>w#w-d1t946-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t946-14">
   <w.rf>
    <LM>w#w-d1t946-14</LM>
   </w.rf>
   <form>kousíček</form>
   <lemma>kousíček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1e943-x2-146">
   <w.rf>
    <LM>w#w-d1e943-x2-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-147">
  <m id="m027-d1t946-16">
   <w.rf>
    <LM>w#w-d1t946-16</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m027-d1t946-17">
   <w.rf>
    <LM>w#w-d1t946-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t946-18">
   <w.rf>
    <LM>w#w-d1t946-18</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t946-19">
   <w.rf>
    <LM>w#w-d1t946-19</LM>
   </w.rf>
   <form>narozený</form>
   <lemma>narozený_^(*4dit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1t946-20">
   <w.rf>
    <LM>w#w-d1t946-20</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t946-21">
   <w.rf>
    <LM>w#w-d1t946-21</LM>
   </w.rf>
   <form>jara</form>
   <lemma>jaro</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m027-d1e943-x2-354">
   <w.rf>
    <LM>w#w-d1e943-x2-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-356">
  <m id="m027-d1t948-2">
   <w.rf>
    <LM>w#w-d1t948-2</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t948-4">
   <w.rf>
    <LM>w#w-d1t948-4</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t948-5">
   <w.rf>
    <LM>w#w-d1t948-5</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t948-6">
   <w.rf>
    <LM>w#w-d1t948-6</LM>
   </w.rf>
   <form>krásný</form>
   <lemma>krásný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-356-358">
   <w.rf>
    <LM>w#w-356-358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-360">
  <m id="m027-d1t948-9">
   <w.rf>
    <LM>w#w-d1t948-9</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t948-8">
   <w.rf>
    <LM>w#w-d1t948-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t950-2">
   <w.rf>
    <LM>w#w-d1t950-2</LM>
   </w.rf>
   <form>moravský</form>
   <lemma>moravský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m027-d1t950-3">
   <w.rf>
    <LM>w#w-d1t950-3</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-360-362">
   <w.rf>
    <LM>w#w-360-362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t950-5">
   <w.rf>
    <LM>w#w-d1t950-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t950-6">
   <w.rf>
    <LM>w#w-d1t950-6</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t950-8">
   <w.rf>
    <LM>w#w-d1t950-8</LM>
   </w.rf>
   <form>Kyjovský</form>
   <lemma>kyjovský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m027-d-id89548-punct">
   <w.rf>
    <LM>w#w-d-id89548-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t950-11">
   <w.rf>
    <LM>w#w-d1t950-11</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t950-12">
   <w.rf>
    <LM>w#w-d1t950-12</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m027-d1t950-13">
   <w.rf>
    <LM>w#w-d1t950-13</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t950-14">
   <w.rf>
    <LM>w#w-d1t950-14</LM>
   </w.rf>
   <form>učitelka</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id89619-punct">
   <w.rf>
    <LM>w#w-d-id89619-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t950-16">
   <w.rf>
    <LM>w#w-d1t950-16</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m027-d1t950-17">
   <w.rf>
    <LM>w#w-d1t950-17</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m027-d1t950-19">
   <w.rf>
    <LM>w#w-d1t950-19</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t950-20">
   <w.rf>
    <LM>w#w-d1t950-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t950-23">
   <w.rf>
    <LM>w#w-d1t950-23</LM>
   </w.rf>
   <form>základní</form>
   <lemma>základní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m027-d1t950-24">
   <w.rf>
    <LM>w#w-d1t950-24</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id89763-punct">
   <w.rf>
    <LM>w#w-d-id89763-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t950-27">
   <w.rf>
    <LM>w#w-d1t950-27</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m027-d1t950-28">
   <w.rf>
    <LM>w#w-d1t950-28</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t952-2">
   <w.rf>
    <LM>w#w-d1t952-2</LM>
   </w.rf>
   <form>dvoutřídka</form>
   <lemma>dvoutřídka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-360-406">
   <w.rf>
    <LM>w#w-360-406</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t952-4">
   <w.rf>
    <LM>w#w-d1t952-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t952-5">
   <w.rf>
    <LM>w#w-d1t952-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t952-7">
   <w.rf>
    <LM>w#w-d1t952-7</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t952-8">
   <w.rf>
    <LM>w#w-d1t952-8</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m027-d1t952-9">
   <w.rf>
    <LM>w#w-d1t952-9</LM>
   </w.rf>
   <form>tříd</form>
   <lemma>třída</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d-id89938-punct">
   <w.rf>
    <LM>w#w-d-id89938-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t957-3">
   <w.rf>
    <LM>w#w-d1t957-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t957-4">
   <w.rf>
    <LM>w#w-d1t957-4</LM>
   </w.rf>
   <form>tenhle</form>
   <lemma>tenhle</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m027-d1t957-5">
   <w.rf>
    <LM>w#w-d1t957-5</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t957-6">
   <w.rf>
    <LM>w#w-d1t957-6</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-360-408">
   <w.rf>
    <LM>w#w-360-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e943-x3">
  <m id="m027-d1t957-8">
   <w.rf>
    <LM>w#w-d1t957-8</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t957-9">
   <w.rf>
    <LM>w#w-d1t957-9</LM>
   </w.rf>
   <form>nádherný</form>
   <lemma>nádherný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m027-d1e943-x3-170">
   <w.rf>
    <LM>w#w-d1e943-x3-170</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-171">
  <m id="m027-d1t957-15">
   <w.rf>
    <LM>w#w-d1t957-15</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d1t957-16">
   <w.rf>
    <LM>w#w-d1t957-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t957-17">
   <w.rf>
    <LM>w#w-d1t957-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t957-18">
   <w.rf>
    <LM>w#w-d1t957-18</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t957-19">
   <w.rf>
    <LM>w#w-d1t957-19</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t957-20">
   <w.rf>
    <LM>w#w-d1t957-20</LM>
   </w.rf>
   <form>drobounká</form>
   <lemma>drobounký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-id90269-punct">
   <w.rf>
    <LM>w#w-d-id90269-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t957-22">
   <w.rf>
    <LM>w#w-d1t957-22</LM>
   </w.rf>
   <form>malá</form>
   <lemma>malý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1e943-x3-420">
   <w.rf>
    <LM>w#w-d1e943-x3-420</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e943-x3-422">
   <w.rf>
    <LM>w#w-d1e943-x3-422</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t957-12">
   <w.rf>
    <LM>w#w-d1t957-12</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m027-d1t957-13">
   <w.rf>
    <LM>w#w-d1t957-13</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t957-14">
   <w.rf>
    <LM>w#w-d1t957-14</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e943-x3-414">
   <w.rf>
    <LM>w#w-d1e943-x3-414</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t959-1">
   <w.rf>
    <LM>w#w-d1t959-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t959-2">
   <w.rf>
    <LM>w#w-d1t959-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m027-d1t959-3">
   <w.rf>
    <LM>w#w-d1t959-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m027-d1t959-4">
   <w.rf>
    <LM>w#w-d1t959-4</LM>
   </w.rf>
   <form>půjčila</form>
   <lemma>půjčit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m027-d1t959-5">
   <w.rf>
    <LM>w#w-d1t959-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t959-6">
   <w.rf>
    <LM>w#w-d1t959-6</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m027-d1t959-7">
   <w.rf>
    <LM>w#w-d1t959-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t959-8">
   <w.rf>
    <LM>w#w-d1t959-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t959-9">
   <w.rf>
    <LM>w#w-d1t959-9</LM>
   </w.rf>
   <form>něm</form>
   <lemma>on-1</lemma>
   <tag>PEZS6--3-------</tag>
  </m>
  <m id="m027-d1t959-10">
   <w.rf>
    <LM>w#w-d1t959-10</LM>
   </w.rf>
   <form>tancovala</form>
   <lemma>tancovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t959-11">
   <w.rf>
    <LM>w#w-d1t959-11</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m027-d1t959-13">
   <w.rf>
    <LM>w#w-d1t959-13</LM>
   </w.rf>
   <form>Besedu</form>
   <lemma>beseda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1e943-x3-416">
   <w.rf>
    <LM>w#w-d1e943-x3-416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-418_1">
  <m id="m027-d1t959-17">
   <w.rf>
    <LM>w#w-d1t959-17</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t959-18">
   <w.rf>
    <LM>w#w-d1t959-18</LM>
   </w.rf>
   <form>tenhle</form>
   <lemma>tenhle</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m027-d1t959-19">
   <w.rf>
    <LM>w#w-d1t959-19</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t961-1">
   <w.rf>
    <LM>w#w-d1t961-1</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t961-2">
   <w.rf>
    <LM>w#w-d1t961-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t961-3">
   <w.rf>
    <LM>w#w-d1t961-3</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id90606-punct">
   <w.rf>
    <LM>w#w-d-id90606-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t961-5">
   <w.rf>
    <LM>w#w-d1t961-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t961-7">
   <w.rf>
    <LM>w#w-d1t961-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t961-8">
   <w.rf>
    <LM>w#w-d1t961-8</LM>
   </w.rf>
   <form>nádherně</form>
   <lemma>nádherně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t961-9">
   <w.rf>
    <LM>w#w-d1t961-9</LM>
   </w.rf>
   <form>vyšívaný</form>
   <lemma>vyšívaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m027-d1t963-1">
   <w.rf>
    <LM>w#w-d1t963-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t963-2">
   <w.rf>
    <LM>w#w-d1t963-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t963-3">
   <w.rf>
    <LM>w#w-d1t963-3</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t963-4">
   <w.rf>
    <LM>w#w-d1t963-4</LM>
   </w.rf>
   <form>krásný</form>
   <lemma>krásný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e943-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e943-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e964-x2">
  <m id="m027-d1t969-1">
   <w.rf>
    <LM>w#w-d1t969-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e964-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e964-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e964-x2-444">
   <w.rf>
    <LM>w#w-d1e964-x2-444</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e964-x2-446">
   <w.rf>
    <LM>w#w-d1e964-x2-446</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e964-x3">
  <m id="m027-d1t971-1">
   <w.rf>
    <LM>w#w-d1t971-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t971-2">
   <w.rf>
    <LM>w#w-d1t971-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t971-3">
   <w.rf>
    <LM>w#w-d1t971-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e964-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e964-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e972-x2">
  <m id="m027-d1t975-1">
   <w.rf>
    <LM>w#w-d1t975-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t975-3">
   <w.rf>
    <LM>w#w-d1t975-3</LM>
   </w.rf>
   <form>Vlastík</form>
   <lemma>Vlastík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e972-x2-450">
   <w.rf>
    <LM>w#w-d1e972-x2-450</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t975-6">
   <w.rf>
    <LM>w#w-d1t975-6</LM>
   </w.rf>
   <form>muj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1------6</tag>
  </m>
  <m id="m027-d1t975-7">
   <w.rf>
    <LM>w#w-d1t975-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>bratříček</form>
   <lemma>bratříček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e972-x2-452">
   <w.rf>
    <LM>w#w-d1e972-x2-452</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t975-8">
   <w.rf>
    <LM>w#w-d1t975-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t975-9">
   <w.rf>
    <LM>w#w-d1t975-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t975-11">
   <w.rf>
    <LM>w#w-d1t975-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t975-10">
   <w.rf>
    <LM>w#w-d1t975-10</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t975-12">
   <w.rf>
    <LM>w#w-d1t975-12</LM>
   </w.rf>
   <form>zamračený</form>
   <lemma>zamračený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1t991-1">
   <w.rf>
    <LM>w#w-d1t991-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t991-3">
   <w.rf>
    <LM>w#w-d1t991-3</LM>
   </w.rf>
   <form>býváme</form>
   <lemma>bývat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d-id91308-punct">
   <w.rf>
    <LM>w#w-d-id91308-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t991-5">
   <w.rf>
    <LM>w#w-d1t991-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t991-6">
   <w.rf>
    <LM>w#w-d1t991-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t991-7">
   <w.rf>
    <LM>w#w-d1t991-7</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMP1----1A---6</tag>
  </m>
  <m id="m027-d-m-d1e972-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e972-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e988-x2">
  <m id="m027-d1t991-10">
   <w.rf>
    <LM>w#w-d1t991-10</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t991-11">
   <w.rf>
    <LM>w#w-d1t991-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t991-12">
   <w.rf>
    <LM>w#w-d1t991-12</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m027-d1t991-13">
   <w.rf>
    <LM>w#w-d1t991-13</LM>
   </w.rf>
   <form>buclík</form>
   <lemma>buclík</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e988-x2-486">
   <w.rf>
    <LM>w#w-d1e988-x2-486</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-488">
  <m id="m027-d1t991-15">
   <w.rf>
    <LM>w#w-d1t991-15</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t991-16">
   <w.rf>
    <LM>w#w-d1t991-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t991-17">
   <w.rf>
    <LM>w#w-d1t991-17</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-id91498-punct">
   <w.rf>
    <LM>w#w-d-id91498-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t991-19">
   <w.rf>
    <LM>w#w-d1t991-19</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t991-20">
   <w.rf>
    <LM>w#w-d1t991-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t991-21">
   <w.rf>
    <LM>w#w-d1t991-21</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t991-22">
   <w.rf>
    <LM>w#w-d1t991-22</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d-id91569-punct">
   <w.rf>
    <LM>w#w-d-id91569-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t991-24">
   <w.rf>
    <LM>w#w-d1t991-24</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t991-25">
   <w.rf>
    <LM>w#w-d1t991-25</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t991-26">
   <w.rf>
    <LM>w#w-d1t991-26</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t991-27">
   <w.rf>
    <LM>w#w-d1t991-27</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t991-28">
   <w.rf>
    <LM>w#w-d1t991-28</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m027-488-490">
   <w.rf>
    <LM>w#w-488-490</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d1t991-29">
   <w.rf>
    <LM>w#w-d1t991-29</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m027-488-198">
   <w.rf>
    <LM>w#w-488-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-199">
  <m id="m027-d1t991-33">
   <w.rf>
    <LM>w#w-d1t991-33</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t991-32">
   <w.rf>
    <LM>w#w-d1t991-32</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t991-34">
   <w.rf>
    <LM>w#w-d1t991-34</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m027-d-id91742-punct">
   <w.rf>
    <LM>w#w-d-id91742-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t991-36">
   <w.rf>
    <LM>w#w-d1t991-36</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t991-37">
   <w.rf>
    <LM>w#w-d1t991-37</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m027-d1t991-38">
   <w.rf>
    <LM>w#w-d1t991-38</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-488-492">
   <w.rf>
    <LM>w#w-488-492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-494_1">
  <m id="m027-d1t993-2">
   <w.rf>
    <LM>w#w-d1t993-2</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t993-3">
   <w.rf>
    <LM>w#w-d1t993-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m027-d1t993-4">
   <w.rf>
    <LM>w#w-d1t993-4</LM>
   </w.rf>
   <form>krásný</form>
   <lemma>krásný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t993-6">
   <w.rf>
    <LM>w#w-d1t993-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>vyplítaný</form>
   <lemma>vyplítaný_^(^DD**vyplétaný)_(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t993-5">
   <w.rf>
    <LM>w#w-d1t993-5</LM>
   </w.rf>
   <form>svetříček</form>
   <lemma>svetříček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e988-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e988-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1000-x2">
  <m id="m027-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>vyfocení</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d1t1003-6">
   <w.rf>
    <LM>w#w-d1t1003-6</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d-m-d1e1000-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1000-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1004-x2">
  <m id="m027-d1t1007-1">
   <w.rf>
    <LM>w#w-d1t1007-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m027-d1t1007-2">
   <w.rf>
    <LM>w#w-d1t1007-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1007-3">
   <w.rf>
    <LM>w#w-d1t1007-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1007-4">
   <w.rf>
    <LM>w#w-d1t1007-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m027-d1t1007-5">
   <w.rf>
    <LM>w#w-d1t1007-5</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id92254-punct">
   <w.rf>
    <LM>w#w-d-id92254-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1009-x2">
  <m id="m027-d1t1012-1">
   <w.rf>
    <LM>w#w-d1t1012-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t1012-2">
   <w.rf>
    <LM>w#w-d1t1012-2</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1012-7">
   <w.rf>
    <LM>w#w-d1t1012-7</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1014-1">
   <w.rf>
    <LM>w#w-d1t1014-1</LM>
   </w.rf>
   <form>ředitele</form>
   <lemma>ředitel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m027-d1t1014-2">
   <w.rf>
    <LM>w#w-d1t1014-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1014-4">
   <w.rf>
    <LM>w#w-d1t1014-4</LM>
   </w.rf>
   <form>Hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m027-d1t1014-5">
   <w.rf>
    <LM>w#w-d1t1014-5</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t1014-8">
   <w.rf>
    <LM>w#w-d1t1014-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1014-10">
   <w.rf>
    <LM>w#w-d1t1014-10</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id92556-punct">
   <w.rf>
    <LM>w#w-d-id92556-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1016-1">
   <w.rf>
    <LM>w#w-d1t1016-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1016-6">
   <w.rf>
    <LM>w#w-d1t1016-6</LM>
   </w.rf>
   <form>nemocný</form>
   <lemma>nemocný-2_^(vlastnost)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m027-d1e1009-x2-209">
   <w.rf>
    <LM>w#w-d1e1009-x2-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-211">
  <m id="m027-d1t1016-9">
   <w.rf>
    <LM>w#w-d1t1016-9</LM>
   </w.rf>
   <form>Musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t1016-10">
   <w.rf>
    <LM>w#w-d1t1016-10</LM>
   </w.rf>
   <form>přestat</form>
   <lemma>přestat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m027-d1t1016-11">
   <w.rf>
    <LM>w#w-d1t1016-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1018-1">
   <w.rf>
    <LM>w#w-d1t1018-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1018-2">
   <w.rf>
    <LM>w#w-d1t1018-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1018-3">
   <w.rf>
    <LM>w#w-d1t1018-3</LM>
   </w.rf>
   <form>částečném</form>
   <lemma>částečný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m027-d1t1018-4">
   <w.rf>
    <LM>w#w-d1t1018-4</LM>
   </w.rf>
   <form>invalidním</form>
   <lemma>invalidní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m027-d1t1018-5">
   <w.rf>
    <LM>w#w-d1t1018-5</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d-id92817-punct">
   <w.rf>
    <LM>w#w-d-id92817-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1018-7">
   <w.rf>
    <LM>w#w-d1t1018-7</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1018-8">
   <w.rf>
    <LM>w#w-d1t1018-8</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1018-9">
   <w.rf>
    <LM>w#w-d1t1018-9</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1018-10">
   <w.rf>
    <LM>w#w-d1t1018-10</LM>
   </w.rf>
   <form>starost</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1009-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1009-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1019-x2">
  <m id="m027-d1t1022-1">
   <w.rf>
    <LM>w#w-d1t1022-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m027-d1t1022-2">
   <w.rf>
    <LM>w#w-d1t1022-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m027-d1t1022-3">
   <w.rf>
    <LM>w#w-d1t1022-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d-id92987-punct">
   <w.rf>
    <LM>w#w-d-id92987-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1023-x2">
  <m id="m027-d1t1026-2">
   <w.rf>
    <LM>w#w-d1t1026-2</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1026-4">
   <w.rf>
    <LM>w#w-d1t1026-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m027-d1t1026-7">
   <w.rf>
    <LM>w#w-d1t1026-7</LM>
   </w.rf>
   <form>záhadnou</form>
   <lemma>záhadný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t1026-8">
   <w.rf>
    <LM>w#w-d1t1026-8</LM>
   </w.rf>
   <form>nemoc</form>
   <lemma>nemoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1026-9">
   <w.rf>
    <LM>w#w-d1t1026-9</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1026-10">
   <w.rf>
    <LM>w#w-d1t1026-10</LM>
   </w.rf>
   <form>páteře</form>
   <lemma>páteř</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t1026-11">
   <w.rf>
    <LM>w#w-d1t1026-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1026-14">
   <w.rf>
    <LM>w#w-d1t1026-14</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m027-d1t1026-12">
   <w.rf>
    <LM>w#w-d1t1026-12</LM>
   </w.rf>
   <form>mozkového</form>
   <lemma>mozkový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m027-d-m-d1e1023-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1023-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1029-x2">
  <m id="m027-d1t1034-1">
   <w.rf>
    <LM>w#w-d1t1034-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1034-2">
   <w.rf>
    <LM>w#w-d1t1034-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m027-d1t1034-3">
   <w.rf>
    <LM>w#w-d1t1034-3</LM>
   </w.rf>
   <form>mrzí</form>
   <lemma>mrzet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e1029-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1029-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1029-x3">
  <m id="m027-d1t1036-1">
   <w.rf>
    <LM>w#w-d1t1036-1</LM>
   </w.rf>
   <form>Trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>problematické</form>
   <lemma>problematický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-id93467-punct">
   <w.rf>
    <LM>w#w-d-id93467-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1029-x3-564">
   <w.rf>
    <LM>w#w-d1e1029-x3-564</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1e1029-x3-566">
   <w.rf>
    <LM>w#w-d1e1029-x3-566</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e1029-x3-568">
   <w.rf>
    <LM>w#w-d1e1029-x3-568</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d-m-d1e1029-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1029-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1041-x2">
  <m id="m027-d1t1044-1">
   <w.rf>
    <LM>w#w-d1t1044-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1044-2">
   <w.rf>
    <LM>w#w-d1t1044-2</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d-id93584-punct">
   <w.rf>
    <LM>w#w-d-id93584-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1045-x2">
  <m id="m027-d1t1048-2">
   <w.rf>
    <LM>w#w-d1t1048-2</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1048-3">
   <w.rf>
    <LM>w#w-d1t1048-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1048-5">
   <w.rf>
    <LM>w#w-d1t1048-5</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t1048-7">
   <w.rf>
    <LM>w#w-d1t1048-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1048-9">
   <w.rf>
    <LM>w#w-d1t1048-9</LM>
   </w.rf>
   <form>Slovanech</form>
   <lemma>Slovany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1045-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1045-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1055-x2">
  <m id="m027-d1t1060-4">
   <w.rf>
    <LM>w#w-d1t1060-4</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1060-5">
   <w.rf>
    <LM>w#w-d1t1060-5</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1060-6">
   <w.rf>
    <LM>w#w-d1t1060-6</LM>
   </w.rf>
   <form>muzikant</form>
   <lemma>muzikant</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1e1055-x2-612">
   <w.rf>
    <LM>w#w-d1e1055-x2-612</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-614_1">
  <m id="m027-d1t1060-7">
   <w.rf>
    <LM>w#w-d1t1060-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1060-10">
   <w.rf>
    <LM>w#w-d1t1060-10</LM>
   </w.rf>
   <form>hudebník</form>
   <lemma>hudebník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t1060-11">
   <w.rf>
    <LM>w#w-d1t1060-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1060-12">
   <w.rf>
    <LM>w#w-d1t1060-12</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m027-614_1-616_1">
   <w.rf>
    <LM>w#w-614_1-616_1</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1060-13">
   <w.rf>
    <LM>w#w-d1t1060-13</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1060-14">
   <w.rf>
    <LM>w#w-d1t1060-14</LM>
   </w.rf>
   <form>konzervatoř</form>
   <lemma>konzervatoř</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-id94162-punct">
   <w.rf>
    <LM>w#w-d-id94162-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1060-16">
   <w.rf>
    <LM>w#w-d1t1060-16</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1062-4">
   <w.rf>
    <LM>w#w-d1t1062-4</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1062-2">
   <w.rf>
    <LM>w#w-d1t1062-2</LM>
   </w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1062-5">
   <w.rf>
    <LM>w#w-d1t1062-5</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1062-6">
   <w.rf>
    <LM>w#w-d1t1062-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1062-8">
   <w.rf>
    <LM>w#w-d1t1062-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1062-9">
   <w.rf>
    <LM>w#w-d1t1062-9</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1062-7">
   <w.rf>
    <LM>w#w-d1t1062-7</LM>
   </w.rf>
   <form>živit</form>
   <lemma>živit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1062-12">
   <w.rf>
    <LM>w#w-d1t1062-12</LM>
   </w.rf>
   <form>muzikou</form>
   <lemma>muzika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m027-614_1-281">
   <w.rf>
    <LM>w#w-614_1-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-270">
  <m id="m027-d1t1062-14">
   <w.rf>
    <LM>w#w-d1t1062-14</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1062-15">
   <w.rf>
    <LM>w#w-d1t1062-15</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m027-d1t1062-16">
   <w.rf>
    <LM>w#w-d1t1062-16</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1062-17">
   <w.rf>
    <LM>w#w-d1t1062-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1062-18">
   <w.rf>
    <LM>w#w-d1t1062-18</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m027-282-288">
   <w.rf>
    <LM>w#w-282-288</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1062-20">
   <w.rf>
    <LM>w#w-d1t1062-20</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1062-21">
   <w.rf>
    <LM>w#w-d1t1062-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1062-22">
   <w.rf>
    <LM>w#w-d1t1062-22</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m027-d1t1062-24">
   <w.rf>
    <LM>w#w-d1t1062-24</LM>
   </w.rf>
   <form>hudebce</form>
   <lemma>hudebka_,h</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id94522-punct">
   <w.rf>
    <LM>w#w-d-id94522-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1066-1">
   <w.rf>
    <LM>w#w-d1t1066-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1066-4">
   <w.rf>
    <LM>w#w-d1t1066-4</LM>
   </w.rf>
   <form>aranžmá</form>
   <lemma>aranžmá</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m027-270-295">
   <w.rf>
    <LM>w#w-270-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-296">
  <m id="m027-d1t1066-7">
   <w.rf>
    <LM>w#w-d1t1066-7</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1066-8">
   <w.rf>
    <LM>w#w-d1t1066-8</LM>
   </w.rf>
   <form>orchestr</form>
   <lemma>orchestr</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t1066-9">
   <w.rf>
    <LM>w#w-d1t1066-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1069-1">
   <w.rf>
    <LM>w#w-d1t1069-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1066-12">
   <w.rf>
    <LM>w#w-d1t1066-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t1066-15">
   <w.rf>
    <LM>w#w-d1t1066-15</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1069-2">
   <w.rf>
    <LM>w#w-d1t1069-2</LM>
   </w.rf>
   <form>zábavu</form>
   <lemma>zábava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t1069-5">
   <w.rf>
    <LM>w#w-d1t1069-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-296-297">
   <w.rf>
    <LM>w#w-296-297</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1069-6">
   <w.rf>
    <LM>w#w-d1t1069-6</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-620-670">
   <w.rf>
    <LM>w#w-620-670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1055-x3">
  <m id="m027-d1t1069-7">
   <w.rf>
    <LM>w#w-d1t1069-7</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1069-11">
   <w.rf>
    <LM>w#w-d1t1069-11</LM>
   </w.rf>
   <form>necítí</form>
   <lemma>cítit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m027-d1t1069-10">
   <w.rf>
    <LM>w#w-d1t1069-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1069-14">
   <w.rf>
    <LM>w#w-d1t1069-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1071-1">
   <w.rf>
    <LM>w#w-d1t1071-1</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id95057-punct">
   <w.rf>
    <LM>w#w-d-id95057-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1071-3">
   <w.rf>
    <LM>w#w-d1t1071-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1071-5">
   <w.rf>
    <LM>w#w-d1t1071-5</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1071-6">
   <w.rf>
    <LM>w#w-d1t1071-6</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m027-d1t1071-9">
   <w.rf>
    <LM>w#w-d1t1071-9</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1071-10">
   <w.rf>
    <LM>w#w-d1t1071-10</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1071-11">
   <w.rf>
    <LM>w#w-d1t1071-11</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e1055-x3-700">
   <w.rf>
    <LM>w#w-d1e1055-x3-700</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t1071-12">
   <w.rf>
    <LM>w#w-d1t1071-12</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m027-d1t1071-13">
   <w.rf>
    <LM>w#w-d1t1071-13</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t1071-14">
   <w.rf>
    <LM>w#w-d1t1071-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1071-15">
   <w.rf>
    <LM>w#w-d1t1071-15</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1e1055-x3-702">
   <w.rf>
    <LM>w#w-d1e1055-x3-702</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1071-17">
   <w.rf>
    <LM>w#w-d1t1071-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1071-18">
   <w.rf>
    <LM>w#w-d1t1071-18</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1055-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1055-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1074-x2">
  <m id="m027-d1t1077-1">
   <w.rf>
    <LM>w#w-d1t1077-1</LM>
   </w.rf>
   <form>Vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t1077-2">
   <w.rf>
    <LM>w#w-d1t1077-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m027-d1t1077-3">
   <w.rf>
    <LM>w#w-d1t1077-3</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-id95396-punct">
   <w.rf>
    <LM>w#w-d-id95396-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1078-x2">
  <m id="m027-d1t1081-2">
   <w.rf>
    <LM>w#w-d1t1081-2</LM>
   </w.rf>
   <form>Vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1081-3">
   <w.rf>
    <LM>w#w-d1t1081-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1081-4">
   <w.rf>
    <LM>w#w-d1t1081-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1e1078-x2-306">
   <w.rf>
    <LM>w#w-d1e1078-x2-306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1081-6">
   <w.rf>
    <LM>w#w-d1t1081-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t1081-7">
   <w.rf>
    <LM>w#w-d1t1081-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1081-8">
   <w.rf>
    <LM>w#w-d1t1081-8</LM>
   </w.rf>
   <form>vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1081-9">
   <w.rf>
    <LM>w#w-d1t1081-9</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t1081-10">
   <w.rf>
    <LM>w#w-d1t1081-10</LM>
   </w.rf>
   <form>rodičů</form>
   <lemma>rodič</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m027-d1e1078-x2-710">
   <w.rf>
    <LM>w#w-d1e1078-x2-710</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-712_1">
  <m id="m027-d1t1083-4">
   <w.rf>
    <LM>w#w-d1t1083-4</LM>
   </w.rf>
   <form>Vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t1083-3">
   <w.rf>
    <LM>w#w-d1t1083-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t1083-1">
   <w.rf>
    <LM>w#w-d1t1083-1</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t1083-2">
   <w.rf>
    <LM>w#w-d1t1083-2</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e1078-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1078-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1084-x2">
  <m id="m027-d1t1087-1">
   <w.rf>
    <LM>w#w-d1t1087-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t1087-2">
   <w.rf>
    <LM>w#w-d1t1087-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t1087-3">
   <w.rf>
    <LM>w#w-d1t1087-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e1084-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1084-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e1094-x2">
  <m id="m027-d1t1097-1">
   <w.rf>
    <LM>w#w-d1t1097-1</LM>
   </w.rf>
   <form>Řekněte</form>
   <lemma>říci</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m027-d1t1097-2">
   <w.rf>
    <LM>w#w-d1t1097-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m027-d1t1097-3">
   <w.rf>
    <LM>w#w-d1t1097-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t1097-4">
   <w.rf>
    <LM>w#w-d1t1097-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m027-d1t1097-5">
   <w.rf>
    <LM>w#w-d1t1097-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t1097-6">
   <w.rf>
    <LM>w#w-d1t1097-6</LM>
   </w.rf>
   <form>vašem</form>
   <lemma>váš</lemma>
   <tag>PSZS6-P2-------</tag>
  </m>
  <m id="m027-d1t1097-7">
   <w.rf>
    <LM>w#w-d1t1097-7</LM>
   </w.rf>
   <form>bratrovi</form>
   <lemma>bratr</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m027-d-id95955-punct">
   <w.rf>
    <LM>w#w-d-id95955-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t1097-9">
   <w.rf>
    <LM>w#w-d1t1097-9</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t1097-10">
   <w.rf>
    <LM>w#w-d1t1097-10</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m027-d1t1097-11">
   <w.rf>
    <LM>w#w-d1t1097-11</LM>
   </w.rf>
   <form>společný</form>
   <lemma>společný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t1097-12">
   <w.rf>
    <LM>w#w-d1t1097-12</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e1094-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1094-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
