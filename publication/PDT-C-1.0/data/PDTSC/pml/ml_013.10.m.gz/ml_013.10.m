<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_013.10.w.gz" />
  </references>
 </head>
 <s id="m013-d1e3819-x2">
  <m id="m013-d1t3822-1">
   <w.rf>
    <LM>w#w-d1t3822-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m013-d1e3819-x2-1313">
   <w.rf>
    <LM>w#w-d1e3819-x2-1313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-1314">
  <m id="m013-d1t3822-2">
   <w.rf>
    <LM>w#w-d1t3822-2</LM>
   </w.rf>
   <form>Díky</form>
   <lemma>dík-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3819-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3819-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3823-x2">
  <m id="m013-d1e3823-x2-1126">
   <w.rf>
    <LM>w#w-d1e3823-x2-1126</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3828-1">
   <w.rf>
    <LM>w#w-d1t3828-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3823-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3823-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m013-d1e3823-x3">
  <m id="m013-d1e3823-x3-1128">
   <w.rf>
    <LM>w#w-d1e3823-x3-1128</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m013-d1t3830-1">
   <w.rf>
    <LM>w#w-d1t3830-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m013-d-m-d1e3823-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3823-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
