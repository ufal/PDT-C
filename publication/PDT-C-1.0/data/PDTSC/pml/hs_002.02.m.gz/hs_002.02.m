<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_002.02.w.gz" />
  </references>
 </head>
 <s id="m002-d1e500-x2">
  <m id="m002-d1t503-1">
   <w.rf>
    <LM>w#w-d1t503-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t503-2">
   <w.rf>
    <LM>w#w-d1t503-2</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t503-4">
   <w.rf>
    <LM>w#w-d1t503-4</LM>
   </w.rf>
   <form>oblečeni</form>
   <lemma>obléci</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m002-d1t503-6">
   <w.rf>
    <LM>w#w-d1t503-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t503-7">
   <w.rf>
    <LM>w#w-d1t503-7</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d-id2599004">
   <w.rf>
    <LM>w#w-d-id2599004</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e504-x2">
  <m id="m002-d1t507-1">
   <w.rf>
    <LM>w#w-d1t507-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1e504-x2-1050">
   <w.rf>
    <LM>w#w-d1e504-x2-1050</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t507-2">
   <w.rf>
    <LM>w#w-d1t507-2</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t507-3">
   <w.rf>
    <LM>w#w-d1t507-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1e504-x2-3050">
   <w.rf>
    <LM>w#w-d1e504-x2-3050</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-3051">
  <m id="m002-d1t509-7">
   <w.rf>
    <LM>w#w-d1t509-7</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t509-1">
   <w.rf>
    <LM>w#w-d1t509-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1e504-x2-1054">
   <w.rf>
    <LM>w#w-d1e504-x2-1054</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t509-4">
   <w.rf>
    <LM>w#w-d1t509-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t509-5">
   <w.rf>
    <LM>w#w-d1t509-5</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d-id2599207">
   <w.rf>
    <LM>w#w-d-id2599207</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t509-8">
   <w.rf>
    <LM>w#w-d1t509-8</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m002-d1t509-9">
   <w.rf>
    <LM>w#w-d1t509-9</LM>
   </w.rf>
   <form>slavnostního</form>
   <lemma>slavnostní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m002-d-id2599263">
   <w.rf>
    <LM>w#w-d-id2599263</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t509-11">
   <w.rf>
    <LM>w#w-d1t509-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t509-12">
   <w.rf>
    <LM>w#w-d1t509-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t509-13">
   <w.rf>
    <LM>w#w-d1t509-13</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t509-14">
   <w.rf>
    <LM>w#w-d1t509-14</LM>
   </w.rf>
   <form>oblékli</form>
   <lemma>obléknout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m002-d-id2599335">
   <w.rf>
    <LM>w#w-d-id2599335</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t509-16">
   <w.rf>
    <LM>w#w-d1t509-16</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t509-17">
   <w.rf>
    <LM>w#w-d1t509-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t509-18">
   <w.rf>
    <LM>w#w-d1t509-18</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t509-19">
   <w.rf>
    <LM>w#w-d1t509-19</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t509-20">
   <w.rf>
    <LM>w#w-d1t509-20</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t509-21">
   <w.rf>
    <LM>w#w-d1t509-21</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t509-22">
   <w.rf>
    <LM>w#w-d1t509-22</LM>
   </w.rf>
   <form>oblečeni</form>
   <lemma>obléci</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m002-d1e504-x2-1056">
   <w.rf>
    <LM>w#w-d1e504-x2-1056</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1058">
  <m id="m002-d1t509-25">
   <w.rf>
    <LM>w#w-d1t509-25</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t511-1">
   <w.rf>
    <LM>w#w-d1t511-1</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d-id2599512">
   <w.rf>
    <LM>w#w-d-id2599512</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t511-5">
   <w.rf>
    <LM>w#w-d1t511-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m002-d1t511-4">
   <w.rf>
    <LM>w#w-d1t511-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t511-7">
   <w.rf>
    <LM>w#w-d1t511-7</LM>
   </w.rf>
   <form>šaty</form>
   <lemma>šat</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m002-d1t511-8">
   <w.rf>
    <LM>w#w-d1t511-8</LM>
   </w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m002-d1t511-10">
   <w.rf>
    <LM>w#w-d1t511-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t513-3">
   <w.rf>
    <LM>w#w-d1t513-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t513-4">
   <w.rf>
    <LM>w#w-d1t513-4</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m002-d1t513-2">
   <w.rf>
    <LM>w#w-d1t513-2</LM>
   </w.rf>
   <form>boty</form>
   <lemma>bota</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m002-1058-1104">
   <w.rf>
    <LM>w#w-1058-1104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1106">
  <m id="m002-d1t515-5">
   <w.rf>
    <LM>w#w-d1t515-5</LM>
   </w.rf>
   <form>Děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-d1t515-6">
   <w.rf>
    <LM>w#w-d1t515-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t515-7">
   <w.rf>
    <LM>w#w-d1t515-7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t515-8">
   <w.rf>
    <LM>w#w-d1t515-8</LM>
   </w.rf>
   <form>klobouk</form>
   <lemma>klobouk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-d1t515-9">
   <w.rf>
    <LM>w#w-d1t515-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t515-10">
   <w.rf>
    <LM>w#w-d1t515-10</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m002-d1t515-11">
   <w.rf>
    <LM>w#w-d1t515-11</LM>
   </w.rf>
   <form>strejda</form>
   <lemma>strejda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-1106-3156">
   <w.rf>
    <LM>w#w-1106-3156</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t515-13">
   <w.rf>
    <LM>w#w-d1t515-13</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t515-14">
   <w.rf>
    <LM>w#w-d1t515-14</LM>
   </w.rf>
   <form>klobouk</form>
   <lemma>klobouk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-1106-1108">
   <w.rf>
    <LM>w#w-1106-1108</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t515-15">
   <w.rf>
    <LM>w#w-d1t515-15</LM>
   </w.rf>
   <form>slamák</form>
   <lemma>slamák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-d-id2599958">
   <w.rf>
    <LM>w#w-d-id2599958</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t515-17">
   <w.rf>
    <LM>w#w-d1t515-17</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t515-19">
   <w.rf>
    <LM>w#w-d1t515-19</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m002-d1t515-20">
   <w.rf>
    <LM>w#w-d1t515-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t515-21">
   <w.rf>
    <LM>w#w-d1t515-21</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t515-22">
   <w.rf>
    <LM>w#w-d1t515-22</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t515-23">
   <w.rf>
    <LM>w#w-d1t515-23</LM>
   </w.rf>
   <form>bývalo</form>
   <lemma>bývat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t515-24">
   <w.rf>
    <LM>w#w-d1t515-24</LM>
   </w.rf>
   <form>nešlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m002-1106-1124">
   <w.rf>
    <LM>w#w-1106-1124</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t515-25">
   <w.rf>
    <LM>w#w-d1t515-25</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t522-1">
   <w.rf>
    <LM>w#w-d1t522-1</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t522-2">
   <w.rf>
    <LM>w#w-d1t522-2</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d-id2600158">
   <w.rf>
    <LM>w#w-d-id2600158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e517-x3">
  <m id="m002-d1t524-1">
   <w.rf>
    <LM>w#w-d1t524-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t524-2">
   <w.rf>
    <LM>w#w-d1t524-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t524-3">
   <w.rf>
    <LM>w#w-d1t524-3</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t524-4">
   <w.rf>
    <LM>w#w-d1t524-4</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m002-d1t524-5">
   <w.rf>
    <LM>w#w-d1t524-5</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m002-d1t524-6">
   <w.rf>
    <LM>w#w-d1t524-6</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2600307">
   <w.rf>
    <LM>w#w-d-id2600307</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e525-x2">
  <m id="m002-d1t528-1">
   <w.rf>
    <LM>w#w-d1t528-1</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t528-2">
   <w.rf>
    <LM>w#w-d1t528-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t528-3">
   <w.rf>
    <LM>w#w-d1t528-3</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m002-d1t528-5">
   <w.rf>
    <LM>w#w-d1t528-5</LM>
   </w.rf>
   <form>Emilie</form>
   <lemma>Emilie_;Y_,s_^(^DD**Emílie)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1e525-x2-1138">
   <w.rf>
    <LM>w#w-d1e525-x2-1138</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t530-2">
   <w.rf>
    <LM>w#w-d1t530-2</LM>
   </w.rf>
   <form>Emilka</form>
   <lemma>Emilka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1e525-x2-3214">
   <w.rf>
    <LM>w#w-d1e525-x2-3214</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-3215">
  <m id="m002-d1t530-4">
   <w.rf>
    <LM>w#w-d1t530-4</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t530-6">
   <w.rf>
    <LM>w#w-d1t530-6</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m002-d1t530-7">
   <w.rf>
    <LM>w#w-d1t530-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t530-8">
   <w.rf>
    <LM>w#w-d1t530-8</LM>
   </w.rf>
   <form>stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d-id2600570">
   <w.rf>
    <LM>w#w-d-id2600570</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t530-10">
   <w.rf>
    <LM>w#w-d1t530-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t530-11">
   <w.rf>
    <LM>w#w-d1t530-11</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t530-12">
   <w.rf>
    <LM>w#w-d1t530-12</LM>
   </w.rf>
   <form>nevěstu</form>
   <lemma>nevěsta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t530-13">
   <w.rf>
    <LM>w#w-d1t530-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t530-14">
   <w.rf>
    <LM>w#w-d1t530-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t530-15">
   <w.rf>
    <LM>w#w-d1t530-15</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m002-d1t530-16">
   <w.rf>
    <LM>w#w-d1t530-16</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t530-17">
   <w.rf>
    <LM>w#w-d1t530-17</LM>
   </w.rf>
   <form>představil</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d-id2600354">
   <w.rf>
    <LM>w#w-d-id2600354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e531-x2">
  <m id="m002-d1t538-1">
   <w.rf>
    <LM>w#w-d1t538-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t538-2">
   <w.rf>
    <LM>w#w-d1t538-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t538-3">
   <w.rf>
    <LM>w#w-d1t538-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t538-4">
   <w.rf>
    <LM>w#w-d1t538-4</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m002-d-id2600838">
   <w.rf>
    <LM>w#w-d-id2600838</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e539-x2">
  <m id="m002-d1t542-1">
   <w.rf>
    <LM>w#w-d1t542-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t542-2">
   <w.rf>
    <LM>w#w-d1t542-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t542-3">
   <w.rf>
    <LM>w#w-d1t542-3</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m002-d1t542-4">
   <w.rf>
    <LM>w#w-d1t542-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t542-6">
   <w.rf>
    <LM>w#w-d1t542-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t542-8">
   <w.rf>
    <LM>w#w-d1t542-8</LM>
   </w.rf>
   <form>Jarově</form>
   <lemma>Jarov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m002-d-id2601021">
   <w.rf>
    <LM>w#w-d-id2601021</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t542-11">
   <w.rf>
    <LM>w#w-d1t542-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1e539-x2-1152">
   <w.rf>
    <LM>w#w-d1e539-x2-1152</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t542-12">
   <w.rf>
    <LM>w#w-d1t542-12</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t542-13">
   <w.rf>
    <LM>w#w-d1t542-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t542-14">
   <w.rf>
    <LM>w#w-d1t542-14</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t542-15">
   <w.rf>
    <LM>w#w-d1t542-15</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2601100">
   <w.rf>
    <LM>w#w-d-id2601100</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t542-18">
   <w.rf>
    <LM>w#w-d1t542-18</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t542-19">
   <w.rf>
    <LM>w#w-d1t542-19</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t542-20">
   <w.rf>
    <LM>w#w-d1t542-20</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m002-d1t542-21">
   <w.rf>
    <LM>w#w-d1t542-21</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m002-d1t542-22">
   <w.rf>
    <LM>w#w-d1t542-22</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m002-d1t542-23">
   <w.rf>
    <LM>w#w-d1t542-23</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m002-d1t542-24">
   <w.rf>
    <LM>w#w-d1t542-24</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m002-d1e539-x2-1154">
   <w.rf>
    <LM>w#w-d1e539-x2-1154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t542-25">
   <w.rf>
    <LM>w#w-d1t542-25</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t542-26">
   <w.rf>
    <LM>w#w-d1t542-26</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t542-27">
   <w.rf>
    <LM>w#w-d1t542-27</LM>
   </w.rf>
   <form>svatební</form>
   <lemma>svatební</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m002-d1t542-28">
   <w.rf>
    <LM>w#w-d1t542-28</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2600885">
   <w.rf>
    <LM>w#w-d-id2600885</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e543-x2">
  <m id="m002-d1t546-1">
   <w.rf>
    <LM>w#w-d1t546-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m002-d1t546-2">
   <w.rf>
    <LM>w#w-d1t546-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m002-d1t546-3">
   <w.rf>
    <LM>w#w-d1t546-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t546-4">
   <w.rf>
    <LM>w#w-d1t546-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m002-d1t546-5">
   <w.rf>
    <LM>w#w-d1t546-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t546-6">
   <w.rf>
    <LM>w#w-d1t546-6</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t546-7">
   <w.rf>
    <LM>w#w-d1t546-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d-id2601461">
   <w.rf>
    <LM>w#w-d-id2601461</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e547-x2">
  <m id="m002-d1t550-2">
   <w.rf>
    <LM>w#w-d1t550-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t550-3">
   <w.rf>
    <LM>w#w-d1t550-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t550-4">
   <w.rf>
    <LM>w#w-d1t550-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m002-d1t550-5">
   <w.rf>
    <LM>w#w-d1t550-5</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-d1e547-x2-1216">
   <w.rf>
    <LM>w#w-d1e547-x2-1216</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t552-1">
   <w.rf>
    <LM>w#w-d1t552-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t552-2">
   <w.rf>
    <LM>w#w-d1t552-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t552-3">
   <w.rf>
    <LM>w#w-d1t552-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t552-4">
   <w.rf>
    <LM>w#w-d1t552-4</LM>
   </w.rf>
   <form>pracovalo</form>
   <lemma>pracovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1e547-x2-1218">
   <w.rf>
    <LM>w#w-d1e547-x2-1218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1220">
  <m id="m002-d1t552-8">
   <w.rf>
    <LM>w#w-d1t552-8</LM>
   </w.rf>
   <form>Tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m002-d1t552-9">
   <w.rf>
    <LM>w#w-d1t552-9</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t552-7">
   <w.rf>
    <LM>w#w-d1t552-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m002-d1t552-10">
   <w.rf>
    <LM>w#w-d1t552-10</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t552-11">
   <w.rf>
    <LM>w#w-d1t552-11</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d-id2601775">
   <w.rf>
    <LM>w#w-d-id2601775</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t552-13">
   <w.rf>
    <LM>w#w-d1t552-13</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t552-14">
   <w.rf>
    <LM>w#w-d1t552-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t552-15">
   <w.rf>
    <LM>w#w-d1t552-15</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m002-d1t552-16">
   <w.rf>
    <LM>w#w-d1t552-16</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t552-17">
   <w.rf>
    <LM>w#w-d1t552-17</LM>
   </w.rf>
   <form>vybavuje</form>
   <lemma>vybavovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d-id2601862">
   <w.rf>
    <LM>w#w-d-id2601862</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t554-1">
   <w.rf>
    <LM>w#w-d1t554-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t554-2">
   <w.rf>
    <LM>w#w-d1t554-2</LM>
   </w.rf>
   <form>strejda</form>
   <lemma>strejda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-d1t556-1">
   <w.rf>
    <LM>w#w-d1t556-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t556-3">
   <w.rf>
    <LM>w#w-d1t556-3</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t556-2">
   <w.rf>
    <LM>w#w-d1t556-2</LM>
   </w.rf>
   <form>dědeček</form>
   <lemma>dědeček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-d1t556-6">
   <w.rf>
    <LM>w#w-d1t556-6</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t556-7">
   <w.rf>
    <LM>w#w-d1t556-7</LM>
   </w.rf>
   <form>kosil</form>
   <lemma>kosit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t556-8">
   <w.rf>
    <LM>w#w-d1t556-8</LM>
   </w.rf>
   <form>obilí</form>
   <lemma>obilí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m002-d1t556-10">
   <w.rf>
    <LM>w#w-d1t556-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t556-11">
   <w.rf>
    <LM>w#w-d1t556-11</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t558-1">
   <w.rf>
    <LM>w#w-d1t558-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t558-2">
   <w.rf>
    <LM>w#w-d1t558-2</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m002-d1t558-5">
   <w.rf>
    <LM>w#w-d1t558-5</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m002-d1t558-3">
   <w.rf>
    <LM>w#w-d1t558-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t558-4">
   <w.rf>
    <LM>w#w-d1t558-4</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t558-6">
   <w.rf>
    <LM>w#w-d1t558-6</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t558-7">
   <w.rf>
    <LM>w#w-d1t558-7</LM>
   </w.rf>
   <form>hrsti</form>
   <lemma>hrst</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m002-d-id2602197">
   <w.rf>
    <LM>w#w-d-id2602197</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t558-9">
   <w.rf>
    <LM>w#w-d1t558-9</LM>
   </w.rf>
   <form>dávala</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t558-10">
   <w.rf>
    <LM>w#w-d1t558-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m002-d1t558-11">
   <w.rf>
    <LM>w#w-d1t558-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t558-12">
   <w.rf>
    <LM>w#w-d1t558-12</LM>
   </w.rf>
   <form>povříslo</form>
   <lemma>povříslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m002-1220-1222">
   <w.rf>
    <LM>w#w-1220-1222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1224">
  <m id="m002-d1t558-14">
   <w.rf>
    <LM>w#w-d1t558-14</LM>
   </w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m002-d1t558-15">
   <w.rf>
    <LM>w#w-d1t558-15</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d1t558-16">
   <w.rf>
    <LM>w#w-d1t558-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t558-17">
   <w.rf>
    <LM>w#w-d1t558-17</LM>
   </w.rf>
   <form>zatáhl</form>
   <lemma>zatáhnout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d1t558-18">
   <w.rf>
    <LM>w#w-d1t558-18</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m002-d1t558-19">
   <w.rf>
    <LM>w#w-d1t558-19</LM>
   </w.rf>
   <form>snop</form>
   <lemma>snop</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-d-id2602372">
   <w.rf>
    <LM>w#w-d-id2602372</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t558-21">
   <w.rf>
    <LM>w#w-d1t558-21</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m002-d1t558-22">
   <w.rf>
    <LM>w#w-d1t558-22</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t558-23">
   <w.rf>
    <LM>w#w-d1t558-23</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-1224-1226">
   <w.rf>
    <LM>w#w-1224-1226</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t558-25">
   <w.rf>
    <LM>w#w-d1t558-25</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t558-26">
   <w.rf>
    <LM>w#w-d1t558-26</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t558-27">
   <w.rf>
    <LM>w#w-d1t558-27</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m002-d1t558-28">
   <w.rf>
    <LM>w#w-d1t558-28</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t558-29">
   <w.rf>
    <LM>w#w-d1t558-29</LM>
   </w.rf>
   <form>pevný</form>
   <lemma>pevný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m002-d1t558-30">
   <w.rf>
    <LM>w#w-d1t558-30</LM>
   </w.rf>
   <form>snop</form>
   <lemma>snop</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-1224-3475">
   <w.rf>
    <LM>w#w-1224-3475</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-3476">
  <m id="m002-d1t561-2">
   <w.rf>
    <LM>w#w-d1t561-2</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m002-d1t561-3">
   <w.rf>
    <LM>w#w-d1t561-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t561-4">
   <w.rf>
    <LM>w#w-d1t561-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t561-5">
   <w.rf>
    <LM>w#w-d1t561-5</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t561-6">
   <w.rf>
    <LM>w#w-d1t561-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t561-7">
   <w.rf>
    <LM>w#w-d1t561-7</LM>
   </w.rf>
   <form>ostatními</form>
   <lemma>ostatní</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m002-d1t561-8">
   <w.rf>
    <LM>w#w-d1t561-8</LM>
   </w.rf>
   <form>stavěl</form>
   <lemma>stavět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t563-1">
   <w.rf>
    <LM>w#w-d1t563-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t563-2">
   <w.rf>
    <LM>w#w-d1t563-2</LM>
   </w.rf>
   <form>takzvaných</form>
   <lemma>takzvaný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m002-d1t563-3">
   <w.rf>
    <LM>w#w-d1t563-3</LM>
   </w.rf>
   <form>panáků</form>
   <lemma>panák-1</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m002-d1t563-4">
   <w.rf>
    <LM>w#w-d1t563-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t563-5">
   <w.rf>
    <LM>w#w-d1t563-5</LM>
   </w.rf>
   <form>budek</form>
   <lemma>budka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m002-1224-1228">
   <w.rf>
    <LM>w#w-1224-1228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1230">
  <m id="m002-d1t565-4">
   <w.rf>
    <LM>w#w-d1t565-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t565-6">
   <w.rf>
    <LM>w#w-d1t565-6</LM>
   </w.rf>
   <form>Jarově</form>
   <lemma>Jarov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m002-d1t565-8">
   <w.rf>
    <LM>w#w-d1t565-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t565-9">
   <w.rf>
    <LM>w#w-d1t565-9</LM>
   </w.rf>
   <form>Blovicku</form>
   <lemma>Blovicko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m002-d1t565-11">
   <w.rf>
    <LM>w#w-d1t565-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t565-12">
   <w.rf>
    <LM>w#w-d1t565-12</LM>
   </w.rf>
   <form>říkalo</form>
   <lemma>říkat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t565-13">
   <w.rf>
    <LM>w#w-d1t565-13</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t565-14">
   <w.rf>
    <LM>w#w-d1t565-14</LM>
   </w.rf>
   <form>budky</form>
   <lemma>budka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m002-1230-1450">
   <w.rf>
    <LM>w#w-1230-1450</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1452">
  <m id="m002-d1t567-2">
   <w.rf>
    <LM>w#w-d1t567-2</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t567-3">
   <w.rf>
    <LM>w#w-d1t567-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t567-5">
   <w.rf>
    <LM>w#w-d1t567-5</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m002-d1t567-6">
   <w.rf>
    <LM>w#w-d1t567-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t567-7">
   <w.rf>
    <LM>w#w-d1t567-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t567-9">
   <w.rf>
    <LM>w#w-d1t567-9</LM>
   </w.rf>
   <form>fotkách</form>
   <lemma>fotka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m002-d1t567-10">
   <w.rf>
    <LM>w#w-d1t567-10</LM>
   </w.rf>
   <form>malířů</form>
   <lemma>malíř</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m002-1452-3558">
   <w.rf>
    <LM>w#w-1452-3558</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t567-12">
   <w.rf>
    <LM>w#w-d1t567-12</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t567-15">
   <w.rf>
    <LM>w#w-d1t567-15</LM>
   </w.rf>
   <form>stály</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m002-d1t567-13">
   <w.rf>
    <LM>w#w-d1t567-13</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m002-d1t567-14">
   <w.rf>
    <LM>w#w-d1t567-14</LM>
   </w.rf>
   <form>budky</form>
   <lemma>budka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m002-1452-3560">
   <w.rf>
    <LM>w#w-1452-3560</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t569-1">
   <w.rf>
    <LM>w#w-d1t569-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m002-d1t569-2">
   <w.rf>
    <LM>w#w-d1t569-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t569-3">
   <w.rf>
    <LM>w#w-d1t569-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t569-4">
   <w.rf>
    <LM>w#w-d1t569-4</LM>
   </w.rf>
   <form>stavěl</form>
   <lemma>stavět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-1452-1454">
   <w.rf>
    <LM>w#w-1452-1454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1456">
  <m id="m002-d1t569-12">
   <w.rf>
    <LM>w#w-d1t569-12</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t569-13">
   <w.rf>
    <LM>w#w-d1t569-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t569-14">
   <w.rf>
    <LM>w#w-d1t569-14</LM>
   </w.rf>
   <form>obilí</form>
   <lemma>obilí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m002-d1t569-15">
   <w.rf>
    <LM>w#w-d1t569-15</LM>
   </w.rf>
   <form>vyschlo</form>
   <lemma>vyschnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m002-d-id2603473">
   <w.rf>
    <LM>w#w-d-id2603473</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t569-9">
   <w.rf>
    <LM>w#w-d1t569-9</LM>
   </w.rf>
   <form>přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d1t569-10">
   <w.rf>
    <LM>w#w-d1t569-10</LM>
   </w.rf>
   <form>žebřiňák</form>
   <lemma>žebřiňák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-d1t569-17">
   <w.rf>
    <LM>w#w-d1t569-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t571-3">
   <w.rf>
    <LM>w#w-d1t571-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m002-d1t571-4">
   <w.rf>
    <LM>w#w-d1t571-4</LM>
   </w.rf>
   <form>snopy</form>
   <lemma>snop</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m002-d1t571-2">
   <w.rf>
    <LM>w#w-d1t571-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t571-6">
   <w.rf>
    <LM>w#w-d1t571-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t571-7">
   <w.rf>
    <LM>w#w-d1t571-7</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m002-d1t571-1">
   <w.rf>
    <LM>w#w-d1t571-1</LM>
   </w.rf>
   <form>vidlemi</form>
   <lemma>vidle</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m002-d1t571-5">
   <w.rf>
    <LM>w#w-d1t571-5</LM>
   </w.rf>
   <form>naložily</form>
   <lemma>naložit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m002-1456-3645">
   <w.rf>
    <LM>w#w-1456-3645</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-3646">
  <m id="m002-d1t571-11">
   <w.rf>
    <LM>w#w-d1t571-11</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t571-10">
   <w.rf>
    <LM>w#w-d1t571-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t571-9">
   <w.rf>
    <LM>w#w-d1t571-9</LM>
   </w.rf>
   <form>odvezly</form>
   <lemma>odvézt</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m002-d1t571-12">
   <w.rf>
    <LM>w#w-d1t571-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t571-13">
   <w.rf>
    <LM>w#w-d1t571-13</LM>
   </w.rf>
   <form>stodoly</form>
   <lemma>stodola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-d-id2603696">
   <w.rf>
    <LM>w#w-d-id2603696</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t574-1">
   <w.rf>
    <LM>w#w-d1t574-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t574-2">
   <w.rf>
    <LM>w#w-d1t574-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t574-3">
   <w.rf>
    <LM>w#w-d1t574-3</LM>
   </w.rf>
   <form>daly</form>
   <lemma>dát-1</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m002-d1t574-4">
   <w.rf>
    <LM>w#w-d1t574-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t574-5">
   <w.rf>
    <LM>w#w-d1t574-5</LM>
   </w.rf>
   <form>perny</form>
   <lemma>perna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-d-id2603791">
   <w.rf>
    <LM>w#w-d-id2603791</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t574-7">
   <w.rf>
    <LM>w#w-d1t574-7</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t574-8">
   <w.rf>
    <LM>w#w-d1t574-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t574-9">
   <w.rf>
    <LM>w#w-d1t574-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t574-10">
   <w.rf>
    <LM>w#w-d1t574-10</LM>
   </w.rf>
   <form>mašinovalo</form>
   <lemma>mašinovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-1456-490">
   <w.rf>
    <LM>w#w-1456-490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t574-13">
   <w.rf>
    <LM>w#w-d1t574-13</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t574-14">
   <w.rf>
    <LM>w#w-d1t574-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t574-18">
   <w.rf>
    <LM>w#w-d1t574-18</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t574-15">
   <w.rf>
    <LM>w#w-d1t574-15</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m002-d1t574-17">
   <w.rf>
    <LM>w#w-d1t574-17</LM>
   </w.rf>
   <form>mlátičku</form>
   <lemma>mlátička_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-1456-1460">
   <w.rf>
    <LM>w#w-1456-1460</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1462">
  <m id="m002-d1t574-20">
   <w.rf>
    <LM>w#w-d1t574-20</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t574-21">
   <w.rf>
    <LM>w#w-d1t574-21</LM>
   </w.rf>
   <form>mlátičku</form>
   <lemma>mlátička_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t574-22">
   <w.rf>
    <LM>w#w-d1t574-22</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m002-1462-1464">
   <w.rf>
    <LM>w#w-1462-1464</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t574-23">
   <w.rf>
    <LM>w#w-d1t574-23</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t574-29">
   <w.rf>
    <LM>w#w-d1t574-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t574-30">
   <w.rf>
    <LM>w#w-d1t574-30</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t574-35">
   <w.rf>
    <LM>w#w-d1t574-35</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t574-37">
   <w.rf>
    <LM>w#w-d1t574-37</LM>
   </w.rf>
   <form>perně</form>
   <lemma>perna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-1462-3740">
   <w.rf>
    <LM>w#w-1462-3740</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t574-31">
   <w.rf>
    <LM>w#w-d1t574-31</LM>
   </w.rf>
   <form>mlátilo</form>
   <lemma>mlátit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t574-26">
   <w.rf>
    <LM>w#w-d1t574-26</LM>
   </w.rf>
   <form>pěkně</form>
   <lemma>pěkně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t574-27">
   <w.rf>
    <LM>w#w-d1t574-27</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t574-28">
   <w.rf>
    <LM>w#w-d1t574-28</LM>
   </w.rf>
   <form>cepy</form>
   <lemma>cep</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m002-1462-1466">
   <w.rf>
    <LM>w#w-1462-1466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1468">
  <m id="m002-1468-1470">
   <w.rf>
    <LM>w#w-1468-1470</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t576-3">
   <w.rf>
    <LM>w#w-d1t576-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m002-d1t576-4">
   <w.rf>
    <LM>w#w-d1t576-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m002-d1t576-5">
   <w.rf>
    <LM>w#w-d1t576-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t576-6">
   <w.rf>
    <LM>w#w-d1t576-6</LM>
   </w.rf>
   <form>vzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m002-1468-1472">
   <w.rf>
    <LM>w#w-1468-1472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t576-7">
   <w.rf>
    <LM>w#w-d1t576-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t576-8">
   <w.rf>
    <LM>w#w-d1t576-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m002-d1t576-11">
   <w.rf>
    <LM>w#w-d1t576-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t576-10">
   <w.rf>
    <LM>w#w-d1t576-10</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t576-12">
   <w.rf>
    <LM>w#w-d1t576-12</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t576-13">
   <w.rf>
    <LM>w#w-d1t576-13</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t576-14">
   <w.rf>
    <LM>w#w-d1t576-14</LM>
   </w.rf>
   <form>snazší</form>
   <lemma>snadný</lemma>
   <tag>AAFS1----2A---1</tag>
  </m>
  <m id="m002-d1t576-16">
   <w.rf>
    <LM>w#w-d1t576-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t576-17">
   <w.rf>
    <LM>w#w-d1t576-17</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m002-d1t576-18">
   <w.rf>
    <LM>w#w-d1t576-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t576-19">
   <w.rf>
    <LM>w#w-d1t576-19</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3------1</tag>
  </m>
  <m id="m002-d1t576-20">
   <w.rf>
    <LM>w#w-d1t576-20</LM>
   </w.rf>
   <form>ubylo</form>
   <lemma>ubýt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d-id2601507">
   <w.rf>
    <LM>w#w-d-id2601507</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e577-x2">
  <m id="m002-d1t580-1">
   <w.rf>
    <LM>w#w-d1t580-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1e577-x2-3790">
   <w.rf>
    <LM>w#w-d1e577-x2-3790</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-3817">
  <m id="m002-d1t582-2">
   <w.rf>
    <LM>w#w-d1t582-2</LM>
   </w.rf>
   <form>Jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m002-d1t582-3">
   <w.rf>
    <LM>w#w-d1t582-3</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m002-d-id2604551">
   <w.rf>
    <LM>w#w-d-id2604551</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e583-x2">
  <m id="m002-d1t586-1">
   <w.rf>
    <LM>w#w-d1t586-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d-id2604683">
   <w.rf>
    <LM>w#w-d-id2604683</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e589-x2">
  <m id="m002-d1t592-1">
   <w.rf>
    <LM>w#w-d1t592-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m002-d1t592-2">
   <w.rf>
    <LM>w#w-d1t592-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t592-3">
   <w.rf>
    <LM>w#w-d1t592-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t592-4">
   <w.rf>
    <LM>w#w-d1t592-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t592-5">
   <w.rf>
    <LM>w#w-d1t592-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d-id2604854">
   <w.rf>
    <LM>w#w-d-id2604854</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e593-x2">
  <m id="m002-d1t598-2">
   <w.rf>
    <LM>w#w-d1t598-2</LM>
   </w.rf>
   <form>Jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t598-3">
   <w.rf>
    <LM>w#w-d1t598-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t598-5">
   <w.rf>
    <LM>w#w-d1t598-5</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t598-4">
   <w.rf>
    <LM>w#w-d1t598-4</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t598-6">
   <w.rf>
    <LM>w#w-d1t598-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t598-7">
   <w.rf>
    <LM>w#w-d1t598-7</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m002-d1t598-8">
   <w.rf>
    <LM>w#w-d1t598-8</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP6----------</tag>
  </m>
  <m id="m002-d1t598-9">
   <w.rf>
    <LM>w#w-d1t598-9</LM>
   </w.rf>
   <form>fotkách</form>
   <lemma>fotka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m002-d-id2605066">
   <w.rf>
    <LM>w#w-d-id2605066</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t598-11">
   <w.rf>
    <LM>w#w-d1t598-11</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m002-d1t600-1">
   <w.rf>
    <LM>w#w-d1t600-1</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m002-d1t600-2">
   <w.rf>
    <LM>w#w-d1t600-2</LM>
   </w.rf>
   <form>víceméně</form>
   <lemma>víceméně</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t600-3">
   <w.rf>
    <LM>w#w-d1t600-3</LM>
   </w.rf>
   <form>veselé</form>
   <lemma>veselý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m002-d-id2605147">
   <w.rf>
    <LM>w#w-d-id2605147</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t600-5">
   <w.rf>
    <LM>w#w-d1t600-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t600-6">
   <w.rf>
    <LM>w#w-d1t600-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t600-7">
   <w.rf>
    <LM>w#w-d1t600-7</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t600-8">
   <w.rf>
    <LM>w#w-d1t600-8</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t600-9">
   <w.rf>
    <LM>w#w-d1t600-9</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t600-10">
   <w.rf>
    <LM>w#w-d1t600-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d-id2605244">
   <w.rf>
    <LM>w#w-d-id2605244</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t602-1">
   <w.rf>
    <LM>w#w-d1t602-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t602-2">
   <w.rf>
    <LM>w#w-d1t602-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t602-3">
   <w.rf>
    <LM>w#w-d1t602-3</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m002-d1t602-4">
   <w.rf>
    <LM>w#w-d1t602-4</LM>
   </w.rf>
   <form>zvuk</form>
   <lemma>zvuk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-d1t602-6">
   <w.rf>
    <LM>w#w-d1t602-6</LM>
   </w.rf>
   <form>tamodtud</form>
   <lemma>tamodtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t602-7">
   <w.rf>
    <LM>w#w-d1t602-7</LM>
   </w.rf>
   <form>neslyšíme</form>
   <lemma>slyšet</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m002-d-id2605364">
   <w.rf>
    <LM>w#w-d-id2605364</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t602-9">
   <w.rf>
    <LM>w#w-d1t602-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t604-1">
   <w.rf>
    <LM>w#w-d1t604-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t604-2">
   <w.rf>
    <LM>w#w-d1t604-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t604-3">
   <w.rf>
    <LM>w#w-d1t604-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t604-4">
   <w.rf>
    <LM>w#w-d1t604-4</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m002-d1t604-5">
   <w.rf>
    <LM>w#w-d1t604-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t604-6">
   <w.rf>
    <LM>w#w-d1t604-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m002-d1t604-7">
   <w.rf>
    <LM>w#w-d1t604-7</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t604-8">
   <w.rf>
    <LM>w#w-d1t604-8</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m002-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>radostnou</form>
   <lemma>radostný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m002-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>pohodu</form>
   <lemma>pohoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-d-id2605581">
   <w.rf>
    <LM>w#w-d-id2605581</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t607-6">
   <w.rf>
    <LM>w#w-d1t607-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t607-7">
   <w.rf>
    <LM>w#w-d1t607-7</LM>
   </w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-d-id2605621">
   <w.rf>
    <LM>w#w-d-id2605621</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t609-1">
   <w.rf>
    <LM>w#w-d1t609-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t609-2">
   <w.rf>
    <LM>w#w-d1t609-2</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t609-3">
   <w.rf>
    <LM>w#w-d1t609-3</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m002-d1t609-4">
   <w.rf>
    <LM>w#w-d1t609-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t611-1">
   <w.rf>
    <LM>w#w-d1t611-1</LM>
   </w.rf>
   <form>pohodu</form>
   <lemma>pohoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t611-2">
   <w.rf>
    <LM>w#w-d1t611-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t611-3">
   <w.rf>
    <LM>w#w-d1t611-3</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t611-4">
   <w.rf>
    <LM>w#w-d1t611-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1e593-x2-1532">
   <w.rf>
    <LM>w#w-d1e593-x2-1532</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1534">
  <m id="m002-d1t613-1">
   <w.rf>
    <LM>w#w-d1t613-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t613-2">
   <w.rf>
    <LM>w#w-d1t613-2</LM>
   </w.rf>
   <form>kdykoliv</form>
   <lemma>kdykoliv_,s_^(^DD**kdykoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t613-3">
   <w.rf>
    <LM>w#w-d1t613-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m002-d1t613-4">
   <w.rf>
    <LM>w#w-d1t613-4</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t613-5">
   <w.rf>
    <LM>w#w-d1t613-5</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-1534-1536">
   <w.rf>
    <LM>w#w-1534-1536</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t613-6">
   <w.rf>
    <LM>w#w-d1t613-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t613-7">
   <w.rf>
    <LM>w#w-d1t613-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m002-d1t613-10">
   <w.rf>
    <LM>w#w-d1t613-10</LM>
   </w.rf>
   <form>rozesmutní</form>
   <lemma>rozesmutnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m002-1534-4029">
   <w.rf>
    <LM>w#w-1534-4029</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4030">
  <m id="m002-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d-id2606013">
   <w.rf>
    <LM>w#w-d-id2606013</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-1534-1538">
   <w.rf>
    <LM>w#w-1534-1538</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t617-5">
   <w.rf>
    <LM>w#w-d1t617-5</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m002-d1t617-6">
   <w.rf>
    <LM>w#w-d1t617-6</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m002-d-id2606053">
   <w.rf>
    <LM>w#w-d-id2606053</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t617-8">
   <w.rf>
    <LM>w#w-d1t617-8</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m002-d1t617-9">
   <w.rf>
    <LM>w#w-d1t617-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t617-10">
   <w.rf>
    <LM>w#w-d1t617-10</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t617-11">
   <w.rf>
    <LM>w#w-d1t617-11</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t617-12">
   <w.rf>
    <LM>w#w-d1t617-12</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m002-4030-4093">
   <w.rf>
    <LM>w#w-4030-4093</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t617-13">
   <w.rf>
    <LM>w#w-d1t617-13</LM>
   </w.rf>
   <form>kromě</form>
   <lemma>kromě</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t617-14">
   <w.rf>
    <LM>w#w-d1t617-14</LM>
   </w.rf>
   <form>dědečka</form>
   <lemma>dědeček</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m002-d-id2606165">
   <w.rf>
    <LM>w#w-d-id2606165</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t617-16">
   <w.rf>
    <LM>w#w-d1t617-16</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m002-d1t617-18">
   <w.rf>
    <LM>w#w-d1t617-18</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m002-d1t617-17">
   <w.rf>
    <LM>w#w-d1t617-17</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d1t617-19">
   <w.rf>
    <LM>w#w-d1t617-19</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m002-4030-4094">
   <w.rf>
    <LM>w#w-4030-4094</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-4030-4095">
   <w.rf>
    <LM>w#w-4030-4095</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-4030-4096">
   <w.rf>
    <LM>w#w-4030-4096</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4097">
  <m id="m002-d1t620-5">
   <w.rf>
    <LM>w#w-d1t620-5</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t620-6">
   <w.rf>
    <LM>w#w-d1t620-6</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t620-1">
   <w.rf>
    <LM>w#w-d1t620-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t620-7">
   <w.rf>
    <LM>w#w-d1t620-7</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t620-8">
   <w.rf>
    <LM>w#w-d1t620-8</LM>
   </w.rf>
   <form>tragický</form>
   <lemma>tragický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m002-d1t620-9">
   <w.rf>
    <LM>w#w-d1t620-9</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-1534-1544">
   <w.rf>
    <LM>w#w-1534-1544</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1546">
  <m id="m002-d1t624-2">
   <w.rf>
    <LM>w#w-d1t624-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m002-d1t624-1">
   <w.rf>
    <LM>w#w-d1t624-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t624-3">
   <w.rf>
    <LM>w#w-d1t624-3</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m002-d1t624-4">
   <w.rf>
    <LM>w#w-d1t624-4</LM>
   </w.rf>
   <form>příbuzní</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m002-1546-4163">
   <w.rf>
    <LM>w#w-1546-4163</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4164">
  <m id="m002-d1t626-1">
   <w.rf>
    <LM>w#w-d1t626-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t626-2">
   <w.rf>
    <LM>w#w-d1t626-2</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2606516">
   <w.rf>
    <LM>w#w-d-id2606516</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t626-4">
   <w.rf>
    <LM>w#w-d1t626-4</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m002-d1t626-6">
   <w.rf>
    <LM>w#w-d1t626-6</LM>
   </w.rf>
   <form>drží</form>
   <lemma>držet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t626-7">
   <w.rf>
    <LM>w#w-d1t626-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t626-8">
   <w.rf>
    <LM>w#w-d1t626-8</LM>
   </w.rf>
   <form>ruku</form>
   <lemma>ruka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t626-9">
   <w.rf>
    <LM>w#w-d1t626-9</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m002-d1t626-10">
   <w.rf>
    <LM>w#w-d1t626-10</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d-id2606635">
   <w.rf>
    <LM>w#w-d-id2606635</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t626-12">
   <w.rf>
    <LM>w#w-d1t626-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t626-13">
   <w.rf>
    <LM>w#w-d1t626-13</LM>
   </w.rf>
   <form>sestřenicí</form>
   <lemma>sestřenice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m002-d1t626-14">
   <w.rf>
    <LM>w#w-d1t626-14</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m002-d1t626-15">
   <w.rf>
    <LM>w#w-d1t626-15</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-4164-4172">
   <w.rf>
    <LM>w#w-4164-4172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4173">
  <m id="m002-d1t628-1">
   <w.rf>
    <LM>w#w-d1t628-1</LM>
   </w.rf>
   <form>Bydlili</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI-1</tag>
  </m>
  <m id="m002-d1t628-2">
   <w.rf>
    <LM>w#w-d1t628-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t628-4">
   <w.rf>
    <LM>w#w-d1t628-4</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t628-6">
   <w.rf>
    <LM>w#w-d1t628-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t628-8">
   <w.rf>
    <LM>w#w-d1t628-8</LM>
   </w.rf>
   <form>Vinohradech</form>
   <lemma>Vinohrady_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m002-1546-1550">
   <w.rf>
    <LM>w#w-1546-1550</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1552">
  <m id="m002-d1t633-1">
   <w.rf>
    <LM>w#w-d1t633-1</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m002-d1t633-2">
   <w.rf>
    <LM>w#w-d1t633-2</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-1552-4231">
   <w.rf>
    <LM>w#w-1552-4231</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t633-3">
   <w.rf>
    <LM>w#w-d1t633-3</LM>
   </w.rf>
   <form>vpravo</form>
   <lemma>vpravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-1552-4232">
   <w.rf>
    <LM>w#w-1552-4232</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t635-1">
   <w.rf>
    <LM>w#w-d1t635-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t635-2">
   <w.rf>
    <LM>w#w-d1t635-2</LM>
   </w.rf>
   <form>kadeřníkem</form>
   <lemma>kadeřník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m002-d1t635-4">
   <w.rf>
    <LM>w#w-d1t635-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t635-5">
   <w.rf>
    <LM>w#w-d1t635-5</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t635-6">
   <w.rf>
    <LM>w#w-d1t635-6</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m002-d1t635-7">
   <w.rf>
    <LM>w#w-d1t635-7</LM>
   </w.rf>
   <form>holčičky</form>
   <lemma>holčička</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m002-1552-4233">
   <w.rf>
    <LM>w#w-1552-4233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4234">
  <m id="m002-d1t635-9">
   <w.rf>
    <LM>w#w-d1t635-9</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t635-10">
   <w.rf>
    <LM>w#w-d1t635-10</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m002-d1t635-11">
   <w.rf>
    <LM>w#w-d1t635-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t635-12">
   <w.rf>
    <LM>w#w-d1t635-12</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m002-d1t635-14">
   <w.rf>
    <LM>w#w-d1t635-14</LM>
   </w.rf>
   <form>Jana</form>
   <lemma>Jana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t637-1">
   <w.rf>
    <LM>w#w-d1t637-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t637-2">
   <w.rf>
    <LM>w#w-d1t637-2</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t637-3">
   <w.rf>
    <LM>w#w-d1t637-3</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m002-d1t637-4">
   <w.rf>
    <LM>w#w-d1t637-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t637-5">
   <w.rf>
    <LM>w#w-d1t637-5</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m002-d1t637-7">
   <w.rf>
    <LM>w#w-d1t637-7</LM>
   </w.rf>
   <form>Maruška</form>
   <lemma>Maruška-1_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2604900">
   <w.rf>
    <LM>w#w-d-id2604900</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e642-x2">
  <m id="m002-d1t645-1">
   <w.rf>
    <LM>w#w-d1t645-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m002-d1t645-2">
   <w.rf>
    <LM>w#w-d1t645-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t645-3">
   <w.rf>
    <LM>w#w-d1t645-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m002-d1t645-4">
   <w.rf>
    <LM>w#w-d1t645-4</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d-id2607370">
   <w.rf>
    <LM>w#w-d-id2607370</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e649-x2">
  <m id="m002-d1t658-1">
   <w.rf>
    <LM>w#w-d1t658-1</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d-id2607594">
   <w.rf>
    <LM>w#w-d-id2607594</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t658-4">
   <w.rf>
    <LM>w#w-d1t658-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m002-d1t658-5">
   <w.rf>
    <LM>w#w-d1t658-5</LM>
   </w.rf>
   <form>někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m002-d1t658-6">
   <w.rf>
    <LM>w#w-d1t658-6</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m002-d1t658-7">
   <w.rf>
    <LM>w#w-d1t658-7</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m002-d1t658-8">
   <w.rf>
    <LM>w#w-d1t658-8</LM>
   </w.rf>
   <form>pamatovat</form>
   <lemma>pamatovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m002-d1t660-1">
   <w.rf>
    <LM>w#w-d1t660-1</LM>
   </w.rf>
   <form>nálet</form>
   <lemma>nálet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m002-d1t660-4">
   <w.rf>
    <LM>w#w-d1t660-4</LM>
   </w.rf>
   <form>Američanů</form>
   <lemma>Američan_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m002-d1t660-6">
   <w.rf>
    <LM>w#w-d1t660-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t660-8">
   <w.rf>
    <LM>w#w-d1t660-8</LM>
   </w.rf>
   <form>Prahu</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t654-3">
   <w.rf>
    <LM>w#w-d1t654-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m002-d1t654-4">
   <w.rf>
    <LM>w#w-d1t654-4</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m002-d1e649-x2-1600">
   <w.rf>
    <LM>w#w-d1e649-x2-1600</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1602">
  <m id="m002-d1t665-1">
   <w.rf>
    <LM>w#w-d1t665-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t665-2">
   <w.rf>
    <LM>w#w-d1t665-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t665-3">
   <w.rf>
    <LM>w#w-d1t665-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t665-4">
   <w.rf>
    <LM>w#w-d1t665-4</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m002-d1t665-5">
   <w.rf>
    <LM>w#w-d1t665-5</LM>
   </w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2607917">
   <w.rf>
    <LM>w#w-d-id2607917</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t665-7">
   <w.rf>
    <LM>w#w-d1t665-7</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t667-2">
   <w.rf>
    <LM>w#w-d1t667-2</LM>
   </w.rf>
   <form>Američané</form>
   <lemma>Američan_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m002-d1t667-4">
   <w.rf>
    <LM>w#w-d1t667-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t667-5">
   <w.rf>
    <LM>w#w-d1t667-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t667-6">
   <w.rf>
    <LM>w#w-d1t667-6</LM>
   </w.rf>
   <form>letadlech</form>
   <lemma>letadlo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m002-d1t667-7">
   <w.rf>
    <LM>w#w-d1t667-7</LM>
   </w.rf>
   <form>přelétávali</form>
   <lemma>přelétávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t667-9">
   <w.rf>
    <LM>w#w-d1t667-9</LM>
   </w.rf>
   <form>Prahu</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t669-1">
   <w.rf>
    <LM>w#w-d1t669-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t669-2">
   <w.rf>
    <LM>w#w-d1t669-2</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m002-d1t669-3">
   <w.rf>
    <LM>w#w-d1t669-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t669-4">
   <w.rf>
    <LM>w#w-d1t669-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t669-5">
   <w.rf>
    <LM>w#w-d1t669-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t669-6">
   <w.rf>
    <LM>w#w-d1t669-6</LM>
   </w.rf>
   <form>krytů</form>
   <lemma>kryt</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m002-d1t669-7">
   <w.rf>
    <LM>w#w-d1t669-7</LM>
   </w.rf>
   <form>nechodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m002-d-id2608207">
   <w.rf>
    <LM>w#w-d-id2608207</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t669-9">
   <w.rf>
    <LM>w#w-d1t669-9</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t669-10">
   <w.rf>
    <LM>w#w-d1t669-10</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d-id2608248">
   <w.rf>
    <LM>w#w-d-id2608248</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t669-12">
   <w.rf>
    <LM>w#w-d1t669-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m002-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m002-d1t673-4">
   <w.rf>
    <LM>w#w-d1t673-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m002-d1t673-5">
   <w.rf>
    <LM>w#w-d1t673-5</LM>
   </w.rf>
   <form>stát</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m002-d-id2608368">
   <w.rf>
    <LM>w#w-d-id2608368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t673-7">
   <w.rf>
    <LM>w#w-d1t673-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t673-8">
   <w.rf>
    <LM>w#w-d1t673-8</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m002-d1t673-9">
   <w.rf>
    <LM>w#w-d1t673-9</LM>
   </w.rf>
   <form>bomby</form>
   <lemma>bomba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m002-d1t676-1">
   <w.rf>
    <LM>w#w-d1t676-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t676-3">
   <w.rf>
    <LM>w#w-d1t676-3</LM>
   </w.rf>
   <form>Prahu</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-d1t676-5">
   <w.rf>
    <LM>w#w-d1t676-5</LM>
   </w.rf>
   <form>nepadnou</form>
   <lemma>padnout</lemma>
   <tag>VB-P---3P-NAP--</tag>
  </m>
  <m id="m002-1602-1604">
   <w.rf>
    <LM>w#w-1602-1604</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1606">
  <m id="m002-d1t678-1">
   <w.rf>
    <LM>w#w-d1t678-1</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-1606-1802">
   <w.rf>
    <LM>w#w-1606-1802</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t678-2">
   <w.rf>
    <LM>w#w-d1t678-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t678-3">
   <w.rf>
    <LM>w#w-d1t678-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t678-4">
   <w.rf>
    <LM>w#w-d1t678-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t678-5">
   <w.rf>
    <LM>w#w-d1t678-5</LM>
   </w.rf>
   <form>popeleční</form>
   <lemma>popeleční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m002-d1t678-6">
   <w.rf>
    <LM>w#w-d1t678-6</LM>
   </w.rf>
   <form>středu</form>
   <lemma>středa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m002-1606-1804">
   <w.rf>
    <LM>w#w-1606-1804</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t678-9">
   <w.rf>
    <LM>w#w-d1t678-9</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t678-7">
   <w.rf>
    <LM>w#w-d1t678-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m002-d1t678-8">
   <w.rf>
    <LM>w#w-d1t678-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m002-1606-1806">
   <w.rf>
    <LM>w#w-1606-1806</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d-id2608649">
   <w.rf>
    <LM>w#w-d-id2608649</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t678-16">
   <w.rf>
    <LM>w#w-d1t678-16</LM>
   </w.rf>
   <form>tuším</form>
   <lemma>tušit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d-id2608731">
   <w.rf>
    <LM>w#w-d-id2608731</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t678-18">
   <w.rf>
    <LM>w#w-d1t678-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t678-19">
   <w.rf>
    <LM>w#w-d1t678-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t678-20">
   <w.rf>
    <LM>w#w-d1t678-20</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t678-21">
   <w.rf>
    <LM>w#w-d1t678-21</LM>
   </w.rf>
   <form>únor</form>
   <lemma>únor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-d1t678-22">
   <w.rf>
    <LM>w#w-d1t678-22</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t678-23">
   <w.rf>
    <LM>w#w-d1t678-23</LM>
   </w.rf>
   <form>březen</form>
   <lemma>březen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-d1t678-24">
   <w.rf>
    <LM>w#w-d1t678-24</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m002-1606-1816">
   <w.rf>
    <LM>w#w-1606-1816</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t697-1">
   <w.rf>
    <LM>w#w-d1t697-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t697-2">
   <w.rf>
    <LM>w#w-d1t697-2</LM>
   </w.rf>
   <form>stala</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m002-d1t697-3">
   <w.rf>
    <LM>w#w-d1t697-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m002-d1t697-4">
   <w.rf>
    <LM>w#w-d1t697-4</LM>
   </w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-1606-1814">
   <w.rf>
    <LM>w#w-1606-1814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1812">
  <m id="m002-d1t697-7">
   <w.rf>
    <LM>w#w-d1t697-7</LM>
   </w.rf>
   <form>Moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m002-d1t697-8">
   <w.rf>
    <LM>w#w-d1t697-8</LM>
   </w.rf>
   <form>příbuzní</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m002-d-id2609154">
   <w.rf>
    <LM>w#w-d-id2609154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t697-11">
   <w.rf>
    <LM>w#w-d1t697-11</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m002-d1t697-15">
   <w.rf>
    <LM>w#w-d1t697-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t697-16">
   <w.rf>
    <LM>w#w-d1t697-16</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m002-d1t697-17">
   <w.rf>
    <LM>w#w-d1t697-17</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t697-13">
   <w.rf>
    <LM>w#w-d1t697-13</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t697-14">
   <w.rf>
    <LM>w#w-d1t697-14</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m002-d-id2609281">
   <w.rf>
    <LM>w#w-d-id2609281</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t697-19">
   <w.rf>
    <LM>w#w-d1t697-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t697-20">
   <w.rf>
    <LM>w#w-d1t697-20</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t697-21">
   <w.rf>
    <LM>w#w-d1t697-21</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m002-d1t699-1">
   <w.rf>
    <LM>w#w-d1t699-1</LM>
   </w.rf>
   <form>strejda</form>
   <lemma>strejda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m002-d1t699-2">
   <w.rf>
    <LM>w#w-d1t699-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t699-4">
   <w.rf>
    <LM>w#w-d1t699-4</LM>
   </w.rf>
   <form>kosou</form>
   <lemma>kosa</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m002-1812-1818">
   <w.rf>
    <LM>w#w-1812-1818</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t699-5">
   <w.rf>
    <LM>w#w-d1t699-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t699-6">
   <w.rf>
    <LM>w#w-d1t699-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t699-7">
   <w.rf>
    <LM>w#w-d1t699-7</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d-id2609441">
   <w.rf>
    <LM>w#w-d-id2609441</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t699-9">
   <w.rf>
    <LM>w#w-d1t699-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t699-11">
   <w.rf>
    <LM>w#w-d1t699-11</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m002-d1t699-12">
   <w.rf>
    <LM>w#w-d1t699-12</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2609505">
   <w.rf>
    <LM>w#w-d-id2609505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t699-14">
   <w.rf>
    <LM>w#w-d1t699-14</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m002-d1t699-15">
   <w.rf>
    <LM>w#w-d1t699-15</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t699-16">
   <w.rf>
    <LM>w#w-d1t699-16</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m002-d1t699-18">
   <w.rf>
    <LM>w#w-d1t699-18</LM>
   </w.rf>
   <form>Vršovicích</form>
   <lemma>Vršovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m002-d-id2609595">
   <w.rf>
    <LM>w#w-d-id2609595</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t708-1">
   <w.rf>
    <LM>w#w-d1t708-1</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t708-2">
   <w.rf>
    <LM>w#w-d1t708-2</LM>
   </w.rf>
   <form>puštěné</form>
   <lemma>puštěný_^(*5stit)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m002-d1t708-3">
   <w.rf>
    <LM>w#w-d1t708-3</LM>
   </w.rf>
   <form>rádio</form>
   <lemma>rádio</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m002-1812-1820">
   <w.rf>
    <LM>w#w-1812-1820</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t705-1">
   <w.rf>
    <LM>w#w-d1t705-1</LM>
   </w.rf>
   <form>najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t705-2">
   <w.rf>
    <LM>w#w-d1t705-2</LM>
   </w.rf>
   <form>slyšeli</form>
   <lemma>slyšet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m002-d1t712-1">
   <w.rf>
    <LM>w#w-d1t712-1</LM>
   </w.rf>
   <form>rány</form>
   <lemma>rána</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m002-1812-4554">
   <w.rf>
    <LM>w#w-1812-4554</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4555">
  <m id="m002-d1t712-3">
   <w.rf>
    <LM>w#w-d1t712-3</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t712-4">
   <w.rf>
    <LM>w#w-d1t712-4</LM>
   </w.rf>
   <form>spadly</form>
   <lemma>spadnout</lemma>
   <tag>VpTP----R-AAP-1</tag>
  </m>
  <m id="m002-d1t712-5">
   <w.rf>
    <LM>w#w-d1t712-5</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m002-d1t712-6">
   <w.rf>
    <LM>w#w-d1t712-6</LM>
   </w.rf>
   <form>bomby</form>
   <lemma>bomba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m002-d-id2609894">
   <w.rf>
    <LM>w#w-d-id2609894</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t712-8">
   <w.rf>
    <LM>w#w-d1t712-8</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m002-d1t712-9">
   <w.rf>
    <LM>w#w-d1t712-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t712-10">
   <w.rf>
    <LM>w#w-d1t712-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t712-11">
   <w.rf>
    <LM>w#w-d1t712-11</LM>
   </w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t712-12">
   <w.rf>
    <LM>w#w-d1t712-12</LM>
   </w.rf>
   <form>zachránili</form>
   <lemma>zachránit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
 </s>
 <s id="m002-1826">
  <m id="m002-d1t714-2">
   <w.rf>
    <LM>w#w-d1t714-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t714-5">
   <w.rf>
    <LM>w#w-d1t714-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t714-6">
   <w.rf>
    <LM>w#w-d1t714-6</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t714-7">
   <w.rf>
    <LM>w#w-d1t714-7</LM>
   </w.rf>
   <form>nálet</form>
   <lemma>nálet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m002-d-id2610099">
   <w.rf>
    <LM>w#w-d-id2610099</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t714-9">
   <w.rf>
    <LM>w#w-d1t714-9</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m002-d1t714-10">
   <w.rf>
    <LM>w#w-d1t714-10</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m002-d1t714-11">
   <w.rf>
    <LM>w#w-d1t714-11</LM>
   </w.rf>
   <form>nečekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m002-1826-1830">
   <w.rf>
    <LM>w#w-1826-1830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1832">
  <m id="m002-d1t718-1">
   <w.rf>
    <LM>w#w-d1t718-1</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m002-d1t718-3">
   <w.rf>
    <LM>w#w-d1t718-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t718-4">
   <w.rf>
    <LM>w#w-d1t718-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t718-5">
   <w.rf>
    <LM>w#w-d1t718-5</LM>
   </w.rf>
   <form>vysvětloval</form>
   <lemma>vysvětlovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m002-d1t718-6">
   <w.rf>
    <LM>w#w-d1t718-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d-id2610273">
   <w.rf>
    <LM>w#w-d-id2610273</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t718-8">
   <w.rf>
    <LM>w#w-d1t718-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t718-9">
   <w.rf>
    <LM>w#w-d1t718-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t718-10">
   <w.rf>
    <LM>w#w-d1t718-10</LM>
   </w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d1t718-11">
   <w.rf>
    <LM>w#w-d1t718-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m002-d1t718-12">
   <w.rf>
    <LM>w#w-d1t718-12</LM>
   </w.rf>
   <form>nějakému</form>
   <lemma>nějaký</lemma>
   <tag>PZZS3----------</tag>
  </m>
  <m id="m002-d1t718-13">
   <w.rf>
    <LM>w#w-d1t718-13</LM>
   </w.rf>
   <form>omylu</form>
   <lemma>omyl</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m002-d-id2610370">
   <w.rf>
    <LM>w#w-d-id2610370</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t718-15">
   <w.rf>
    <LM>w#w-d1t718-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t718-16">
   <w.rf>
    <LM>w#w-d1t718-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t718-19">
   <w.rf>
    <LM>w#w-d1t718-19</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t718-17">
   <w.rf>
    <LM>w#w-d1t718-17</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m002-d1t718-18">
   <w.rf>
    <LM>w#w-d1t718-18</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m002-d1t718-21">
   <w.rf>
    <LM>w#w-d1t718-21</LM>
   </w.rf>
   <form>Drážďany</form>
   <lemma>Drážďany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m002-1832-4681">
   <w.rf>
    <LM>w#w-1832-4681</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4682">
  <m id="m002-d1t721-1">
   <w.rf>
    <LM>w#w-d1t721-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m002-1832-1900">
   <w.rf>
    <LM>w#w-1832-1900</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t721-2">
   <w.rf>
    <LM>w#w-d1t721-2</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t721-11">
   <w.rf>
    <LM>w#w-d1t721-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m002-d1t721-13">
   <w.rf>
    <LM>w#w-d1t721-13</LM>
   </w.rf>
   <form>Američany</form>
   <lemma>Američan_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m002-d1t721-5">
   <w.rf>
    <LM>w#w-d1t721-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t721-6">
   <w.rf>
    <LM>w#w-d1t721-6</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m002-d1t721-7">
   <w.rf>
    <LM>w#w-d1t721-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m002-d1t721-9">
   <w.rf>
    <LM>w#w-d1t721-9</LM>
   </w.rf>
   <form>Němců</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m002-d1t721-15">
   <w.rf>
    <LM>w#w-d1t721-15</LM>
   </w.rf>
   <form>vystřelil</form>
   <lemma>vystřelit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-4682-4690">
   <w.rf>
    <LM>w#w-4682-4690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4691">
  <m id="m002-d1t723-1">
   <w.rf>
    <LM>w#w-d1t723-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m002-d1t725-2">
   <w.rf>
    <LM>w#w-d1t725-2</LM>
   </w.rf>
   <form>mohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m002-d1t725-1">
   <w.rf>
    <LM>w#w-d1t725-1</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t725-3">
   <w.rf>
    <LM>w#w-d1t725-3</LM>
   </w.rf>
   <form>posoudit</form>
   <lemma>posoudit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m002-d-id2610799">
   <w.rf>
    <LM>w#w-d-id2610799</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t725-5">
   <w.rf>
    <LM>w#w-d1t725-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t725-6">
   <w.rf>
    <LM>w#w-d1t725-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m002-d1t725-8">
   <w.rf>
    <LM>w#w-d1t725-8</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t725-7">
   <w.rf>
    <LM>w#w-d1t725-7</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m002-d1t725-9">
   <w.rf>
    <LM>w#w-d1t725-9</LM>
   </w.rf>
   <form>vysvětleno</form>
   <lemma>vysvětlit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m002-1832-1906">
   <w.rf>
    <LM>w#w-1832-1906</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1908">
  <m id="m002-d1t729-1">
   <w.rf>
    <LM>w#w-d1t729-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t729-2">
   <w.rf>
    <LM>w#w-d1t729-2</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t729-3">
   <w.rf>
    <LM>w#w-d1t729-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d-id2610966">
   <w.rf>
    <LM>w#w-d-id2610966</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t729-5">
   <w.rf>
    <LM>w#w-d1t729-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t729-6">
   <w.rf>
    <LM>w#w-d1t729-6</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t729-7">
   <w.rf>
    <LM>w#w-d1t729-7</LM>
   </w.rf>
   <form>zahynulo</form>
   <lemma>zahynout</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d1t729-8">
   <w.rf>
    <LM>w#w-d1t729-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t729-10">
   <w.rf>
    <LM>w#w-d1t729-10</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d1t729-12">
   <w.rf>
    <LM>w#w-d1t729-12</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m002-d1t729-13">
   <w.rf>
    <LM>w#w-d1t729-13</LM>
   </w.rf>
   <form>množství</form>
   <lemma>množství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m002-d1t729-14">
   <w.rf>
    <LM>w#w-d1t729-14</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m002-1908-4791">
   <w.rf>
    <LM>w#w-1908-4791</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-4792">
  <m id="m002-d1t731-1">
   <w.rf>
    <LM>w#w-d1t731-1</LM>
   </w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t731-2">
   <w.rf>
    <LM>w#w-d1t731-2</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m002-d1t731-3">
   <w.rf>
    <LM>w#w-d1t731-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d1t731-4">
   <w.rf>
    <LM>w#w-d1t731-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t731-5">
   <w.rf>
    <LM>w#w-d1t731-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t731-6">
   <w.rf>
    <LM>w#w-d1t731-6</LM>
   </w.rf>
   <form>dcerka</form>
   <lemma>dcerka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t731-8">
   <w.rf>
    <LM>w#w-d1t731-8</LM>
   </w.rf>
   <form>Josefa</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m002-d1t731-9">
   <w.rf>
    <LM>w#w-d1t731-9</LM>
   </w.rf>
   <form>Lady</form>
   <lemma>Lada-2_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m002-d-id2611287">
   <w.rf>
    <LM>w#w-d-id2611287</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t731-12">
   <w.rf>
    <LM>w#w-d1t731-12</LM>
   </w.rf>
   <form>malíře</form>
   <lemma>malíř</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m002-d-id2611311">
   <w.rf>
    <LM>w#w-d-id2611311</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t731-14">
   <w.rf>
    <LM>w#w-d1t731-14</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m002-d1t731-15">
   <w.rf>
    <LM>w#w-d1t731-15</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m002-d1t734-1">
   <w.rf>
    <LM>w#w-d1t734-1</LM>
   </w.rf>
   <form>dává</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m002-d1t736-1">
   <w.rf>
    <LM>w#w-d1t736-1</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m002-d1t736-2">
   <w.rf>
    <LM>w#w-d1t736-2</LM>
   </w.rf>
   <form>radosti</form>
   <lemma>radost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m002-d1t736-5">
   <w.rf>
    <LM>w#w-d1t736-5</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m002-d1t736-4">
   <w.rf>
    <LM>w#w-d1t736-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t736-6">
   <w.rf>
    <LM>w#w-d1t736-6</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m002-d1t736-8">
   <w.rf>
    <LM>w#w-d1t736-8</LM>
   </w.rf>
   <form>Vánoci</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m002-d-id2611500">
   <w.rf>
    <LM>w#w-d-id2611500</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t736-10">
   <w.rf>
    <LM>w#w-d1t736-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t736-11">
   <w.rf>
    <LM>w#w-d1t736-11</LM>
   </w.rf>
   <form>dovedl</form>
   <lemma>dovést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m002-d1t736-12">
   <w.rf>
    <LM>w#w-d1t736-12</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m002-d1t738-1">
   <w.rf>
    <LM>w#w-d1t738-1</LM>
   </w.rf>
   <form>obrázky</form>
   <lemma>obrázek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m002-d1t738-2">
   <w.rf>
    <LM>w#w-d1t738-2</LM>
   </w.rf>
   <form>malovat</form>
   <lemma>malovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m002-d1t738-3">
   <w.rf>
    <LM>w#w-d1t738-3</LM>
   </w.rf>
   <form>krásně</form>
   <lemma>krásně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-1908-1910">
   <w.rf>
    <LM>w#w-1908-1910</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-1912">
  <m id="m002-d1t738-7">
   <w.rf>
    <LM>w#w-d1t738-7</LM>
   </w.rf>
   <form>Jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m002-d1t738-8">
   <w.rf>
    <LM>w#w-d1t738-8</LM>
   </w.rf>
   <form>dcerka</form>
   <lemma>dcerka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t738-10">
   <w.rf>
    <LM>w#w-d1t738-10</LM>
   </w.rf>
   <form>Eva</form>
   <lemma>Eva_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d1t740-2">
   <w.rf>
    <LM>w#w-d1t740-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-3">
   <w.rf>
    <LM>w#w-d1t740-3</LM>
   </w.rf>
   <form>zahynula</form>
   <lemma>zahynout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m002-d-id2611781">
   <w.rf>
    <LM>w#w-d-id2611781</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t740-5">
   <w.rf>
    <LM>w#w-d1t740-5</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-6">
   <w.rf>
    <LM>w#w-d1t740-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t740-9">
   <w.rf>
    <LM>w#w-d1t740-9</LM>
   </w.rf>
   <form>Alenka</form>
   <lemma>Alenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m002-d-id2611856">
   <w.rf>
    <LM>w#w-d-id2611856</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t740-12">
   <w.rf>
    <LM>w#w-d1t740-12</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m002-d1t740-13">
   <w.rf>
    <LM>w#w-d1t740-13</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-16">
   <w.rf>
    <LM>w#w-d1t740-16</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-14">
   <w.rf>
    <LM>w#w-d1t740-14</LM>
   </w.rf>
   <form>malovala</form>
   <lemma>malovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m002-d-id2611912">
   <w.rf>
    <LM>w#w-d-id2611912</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t740-18">
   <w.rf>
    <LM>w#w-d1t740-18</LM>
   </w.rf>
   <form>naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-19">
   <w.rf>
    <LM>w#w-d1t740-19</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m002-d1t740-20">
   <w.rf>
    <LM>w#w-d1t740-20</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-21">
   <w.rf>
    <LM>w#w-d1t740-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t740-22">
   <w.rf>
    <LM>w#w-d1t740-22</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m002-d1t740-23">
   <w.rf>
    <LM>w#w-d1t740-23</LM>
   </w.rf>
   <form>domě</form>
   <lemma>dům</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m002-d-id2612046">
   <w.rf>
    <LM>w#w-d-id2612046</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t740-25">
   <w.rf>
    <LM>w#w-d1t740-25</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t740-26">
   <w.rf>
    <LM>w#w-d1t740-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t740-28">
   <w.rf>
    <LM>w#w-d1t740-28</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t740-30">
   <w.rf>
    <LM>w#w-d1t740-30</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d-id2609019">
   <w.rf>
    <LM>w#w-d-id2609019</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e741-x2">
  <m id="m002-d1t746-1">
   <w.rf>
    <LM>w#w-d1t746-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m002-d1t746-2">
   <w.rf>
    <LM>w#w-d1t746-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m002-d1t746-3">
   <w.rf>
    <LM>w#w-d1t746-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m002-d1t746-4">
   <w.rf>
    <LM>w#w-d1t746-4</LM>
   </w.rf>
   <form>vrátím</form>
   <lemma>vrátit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m002-d1e741-x2-5200">
   <w.rf>
    <LM>w#w-d1e741-x2-5200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1e741-x2-5201">
   <w.rf>
    <LM>w#w-d1e741-x2-5201</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d-id2612162">
   <w.rf>
    <LM>w#w-d-id2612162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-d1e741-x3">
  <m id="m002-d1t752-1">
   <w.rf>
    <LM>w#w-d1t752-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m002-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m002-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m002-d1t752-5">
   <w.rf>
    <LM>w#w-d1t752-5</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m002-d1t752-6">
   <w.rf>
    <LM>w#w-d1t752-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m002-d1t752-7">
   <w.rf>
    <LM>w#w-d1t752-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m002-d-id2612363">
   <w.rf>
    <LM>w#w-d-id2612363</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m002-2002">
  <m id="m002-d1t756-8">
   <w.rf>
    <LM>w#w-d1t756-8</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m002-d1t756-7">
   <w.rf>
    <LM>w#w-d1t756-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m002-d-id2612537">
   <w.rf>
    <LM>w#w-d-id2612537</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t758-1">
   <w.rf>
    <LM>w#w-d1t758-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t758-2">
   <w.rf>
    <LM>w#w-d1t758-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m002-d1t758-3">
   <w.rf>
    <LM>w#w-d1t758-3</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m002-d1t758-4">
   <w.rf>
    <LM>w#w-d1t758-4</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m002-d1t760-1">
   <w.rf>
    <LM>w#w-d1t760-1</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m002-2002-2004">
   <w.rf>
    <LM>w#w-2002-2004</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m002-d1t760-2">
   <w.rf>
    <LM>w#w-d1t760-2</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m002-d1t760-3">
   <w.rf>
    <LM>w#w-d1t760-3</LM>
   </w.rf>
   <form>došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m002-d1t760-4">
   <w.rf>
    <LM>w#w-d1t760-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m002-d1t760-5">
   <w.rf>
    <LM>w#w-d1t760-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m002-d1t760-6">
   <w.rf>
    <LM>w#w-d1t760-6</LM>
   </w.rf>
   <form>tragédii</form>
   <lemma>tragédie</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m002-d-id2612410">
   <w.rf>
    <LM>w#w-d-id2612410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
