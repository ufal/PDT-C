<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_116.07.w.gz" />
  </references>
 </head>
 <s id="m116-320">
  <m id="m116-d1t1383-1">
   <w.rf>
    <LM>w#w-d1t1383-1</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m116-d1t1383-2">
   <w.rf>
    <LM>w#w-d1t1383-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1383-3">
   <w.rf>
    <LM>w#w-d1t1383-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m116-d1t1383-4">
   <w.rf>
    <LM>w#w-d1t1383-4</LM>
   </w.rf>
   <form>bojí</form>
   <lemma>bát-1</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d-id121695-punct">
   <w.rf>
    <LM>w#w-d-id121695-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1383-6">
   <w.rf>
    <LM>w#w-d1t1383-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m116-d1t1383-7">
   <w.rf>
    <LM>w#w-d1t1383-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1383-8">
   <w.rf>
    <LM>w#w-d1t1383-8</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m116-d1t1383-9">
   <w.rf>
    <LM>w#w-d1t1383-9</LM>
   </w.rf>
   <form>nebojíme</form>
   <lemma>bát-1</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m116-d-m-d1e1378-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1378-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1384-x2">
  <m id="m116-d1t1387-1">
   <w.rf>
    <LM>w#w-d1t1387-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1387-2">
   <w.rf>
    <LM>w#w-d1t1387-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1387-3">
   <w.rf>
    <LM>w#w-d1t1387-3</LM>
   </w.rf>
   <form>nejlépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m116-d1t1387-4">
   <w.rf>
    <LM>w#w-d1t1387-4</LM>
   </w.rf>
   <form>odpočinete</form>
   <lemma>odpočinout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m116-d-id121881-punct">
   <w.rf>
    <LM>w#w-d-id121881-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1388-x2">
  <m id="m116-d1t1393-3">
   <w.rf>
    <LM>w#w-d1t1393-3</LM>
   </w.rf>
   <form>Nejlépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m116-d1t1393-2">
   <w.rf>
    <LM>w#w-d1t1393-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1393-4">
   <w.rf>
    <LM>w#w-d1t1393-4</LM>
   </w.rf>
   <form>odpočinu</form>
   <lemma>odpočinout</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m116-d1t1393-5">
   <w.rf>
    <LM>w#w-d1t1393-5</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m116-d-id122029-punct">
   <w.rf>
    <LM>w#w-d-id122029-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1393-10">
   <w.rf>
    <LM>w#w-d1t1393-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1393-11">
   <w.rf>
    <LM>w#w-d1t1393-11</LM>
   </w.rf>
   <form>chodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1e1388-x2-327">
   <w.rf>
    <LM>w#w-d1e1388-x2-327</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1393-13">
   <w.rf>
    <LM>w#w-d1t1393-13</LM>
   </w.rf>
   <form>procházkami</form>
   <lemma>procházka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m116-d1e1388-x2-328">
   <w.rf>
    <LM>w#w-d1e1388-x2-328</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-329">
  <m id="m116-d1t1395-1">
   <w.rf>
    <LM>w#w-d1t1395-1</LM>
   </w.rf>
   <form>Odpočinu</form>
   <lemma>odpočinout</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m116-d1t1395-2">
   <w.rf>
    <LM>w#w-d1t1395-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1395-3">
   <w.rf>
    <LM>w#w-d1t1395-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m116-d-id122201-punct">
   <w.rf>
    <LM>w#w-d-id122201-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1395-5">
   <w.rf>
    <LM>w#w-d1t1395-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1395-6">
   <w.rf>
    <LM>w#w-d1t1395-6</LM>
   </w.rf>
   <form>nemusím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m116-d1t1395-7">
   <w.rf>
    <LM>w#w-d1t1395-7</LM>
   </w.rf>
   <form>přemýšlet</form>
   <lemma>přemýšlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t1395-8">
   <w.rf>
    <LM>w#w-d1t1395-8</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1395-9">
   <w.rf>
    <LM>w#w-d1t1395-9</LM>
   </w.rf>
   <form>nějakými</form>
   <lemma>nějaký</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m116-d1t1395-10">
   <w.rf>
    <LM>w#w-d1t1395-10</LM>
   </w.rf>
   <form>úkoly</form>
   <lemma>úkol</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m116-329-330">
   <w.rf>
    <LM>w#w-329-330</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-331">
  <m id="m116-d1t1397-1">
   <w.rf>
    <LM>w#w-d1t1397-1</LM>
   </w.rf>
   <form>Zkrátka</form>
   <lemma>zkrátka-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1397-4">
   <w.rf>
    <LM>w#w-d1t1397-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1397-5">
   <w.rf>
    <LM>w#w-d1t1397-5</LM>
   </w.rf>
   <form>snažím</form>
   <lemma>snažit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1397-6">
   <w.rf>
    <LM>w#w-d1t1397-6</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d1t1397-2">
   <w.rf>
    <LM>w#w-d1t1397-2</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m116-d1t1397-3">
   <w.rf>
    <LM>w#w-d1t1397-3</LM>
   </w.rf>
   <form>problémy</form>
   <lemma>problém</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m116-d1t1397-7">
   <w.rf>
    <LM>w#w-d1t1397-7</LM>
   </w.rf>
   <form>vymazat</form>
   <lemma>vymazat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m116-d1t1397-8">
   <w.rf>
    <LM>w#w-d1t1397-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1397-9">
   <w.rf>
    <LM>w#w-d1t1397-9</LM>
   </w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d-m-d1e1388-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1388-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1398-x2">
  <m id="m116-d1t1401-1">
   <w.rf>
    <LM>w#w-d1t1401-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m116-d1e1398-x2-334">
   <w.rf>
    <LM>w#w-d1e1398-x2-334</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-335">
  <m id="m116-d1t1403-1">
   <w.rf>
    <LM>w#w-d1t1403-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t1403-2">
   <w.rf>
    <LM>w#w-d1t1403-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1403-3">
   <w.rf>
    <LM>w#w-d1t1403-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1403-4">
   <w.rf>
    <LM>w#w-d1t1403-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t1403-5">
   <w.rf>
    <LM>w#w-d1t1403-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id122620-punct">
   <w.rf>
    <LM>w#w-d-id122620-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1404-x2">
  <m id="m116-d1t1409-1">
   <w.rf>
    <LM>w#w-d1t1409-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1409-2">
   <w.rf>
    <LM>w#w-d1t1409-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1409-3">
   <w.rf>
    <LM>w#w-d1t1409-3</LM>
   </w.rf>
   <form>obdoba</form>
   <lemma>obdoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-id122737-punct">
   <w.rf>
    <LM>w#w-d-id122737-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1409-5">
   <w.rf>
    <LM>w#w-d1t1409-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1409-6">
   <w.rf>
    <LM>w#w-d1t1409-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1409-7">
   <w.rf>
    <LM>w#w-d1t1409-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1409-8">
   <w.rf>
    <LM>w#w-d1t1409-8</LM>
   </w.rf>
   <form>procházce</form>
   <lemma>procházka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1409-9">
   <w.rf>
    <LM>w#w-d1t1409-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1409-10">
   <w.rf>
    <LM>w#w-d1t1409-10</LM>
   </w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d1e1404-x2-339">
   <w.rf>
    <LM>w#w-d1e1404-x2-339</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-340">
  <m id="m116-d1t1411-1">
   <w.rf>
    <LM>w#w-d1t1411-1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1411-2">
   <w.rf>
    <LM>w#w-d1t1411-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1411-3">
   <w.rf>
    <LM>w#w-d1t1411-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m116-d-id122900-punct">
   <w.rf>
    <LM>w#w-d-id122900-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1411-5">
   <w.rf>
    <LM>w#w-d1t1411-5</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t1411-6">
   <w.rf>
    <LM>w#w-d1t1411-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1411-8">
   <w.rf>
    <LM>w#w-d1t1411-8</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m116-d1t1411-9">
   <w.rf>
    <LM>w#w-d1t1411-9</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-340-341">
   <w.rf>
    <LM>w#w-340-341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-342">
  <m id="m116-d1t1411-16">
   <w.rf>
    <LM>w#w-d1t1411-16</LM>
   </w.rf>
   <form>Než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1411-17">
   <w.rf>
    <LM>w#w-d1t1411-17</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d1t1411-18">
   <w.rf>
    <LM>w#w-d1t1411-18</LM>
   </w.rf>
   <form>přítele</form>
   <lemma>přítel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m116-d1t1411-19">
   <w.rf>
    <LM>w#w-d1t1411-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1411-20">
   <w.rf>
    <LM>w#w-d1t1411-20</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1411-21">
   <w.rf>
    <LM>w#w-d1t1411-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1411-22">
   <w.rf>
    <LM>w#w-d1t1411-22</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-342-343">
   <w.rf>
    <LM>w#w-342-343</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1411-10">
   <w.rf>
    <LM>w#w-d1t1411-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1411-11">
   <w.rf>
    <LM>w#w-d1t1411-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1411-12">
   <w.rf>
    <LM>w#w-d1t1411-12</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m116-d1t1411-13">
   <w.rf>
    <LM>w#w-d1t1411-13</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1411-14">
   <w.rf>
    <LM>w#w-d1t1411-14</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d-m-d1e1404-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1404-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1412-x2">
  <m id="m116-d1t1415-1">
   <w.rf>
    <LM>w#w-d1t1415-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1415-2">
   <w.rf>
    <LM>w#w-d1t1415-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1415-3">
   <w.rf>
    <LM>w#w-d1t1415-3</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1415-4">
   <w.rf>
    <LM>w#w-d1t1415-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d-id123296-punct">
   <w.rf>
    <LM>w#w-d-id123296-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1416-x2">
  <m id="m116-d1t1419-1">
   <w.rf>
    <LM>w#w-d1t1419-1</LM>
   </w.rf>
   <form>Abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m116-d1t1419-2">
   <w.rf>
    <LM>w#w-d1t1419-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m116-d1t1419-3">
   <w.rf>
    <LM>w#w-d1t1419-3</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d1t1419-4">
   <w.rf>
    <LM>w#w-d1t1419-4</LM>
   </w.rf>
   <form>pravdu</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d-id123420-punct">
   <w.rf>
    <LM>w#w-d-id123420-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1419-6">
   <w.rf>
    <LM>w#w-d1t1419-6</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m116-d1t1419-7">
   <w.rf>
    <LM>w#w-d1t1419-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m116-d-id123460-punct">
   <w.rf>
    <LM>w#w-d-id123460-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1419-9">
   <w.rf>
    <LM>w#w-d1t1419-9</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1419-10">
   <w.rf>
    <LM>w#w-d1t1419-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1419-11">
   <w.rf>
    <LM>w#w-d1t1419-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1419-12">
   <w.rf>
    <LM>w#w-d1t1419-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m116-d1t1419-13">
   <w.rf>
    <LM>w#w-d1t1419-13</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m116-d-m-d1e1416-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1416-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1420-x2">
  <m id="m116-d1t1423-2">
   <w.rf>
    <LM>w#w-d1t1423-2</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m116-d1t1423-3">
   <w.rf>
    <LM>w#w-d1t1423-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m116-d1t1423-4">
   <w.rf>
    <LM>w#w-d1t1423-4</LM>
   </w.rf>
   <form>fotil</form>
   <lemma>fotit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d-id123661-punct">
   <w.rf>
    <LM>w#w-d-id123661-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1424-x2">
  <m id="m116-d1t1429-1">
   <w.rf>
    <LM>w#w-d1t1429-1</LM>
   </w.rf>
   <form>Fotila</form>
   <lemma>fotit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d1t1429-2">
   <w.rf>
    <LM>w#w-d1t1429-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m116-d1t1429-3">
   <w.rf>
    <LM>w#w-d1t1429-3</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m116-d1t1429-4">
   <w.rf>
    <LM>w#w-d1t1429-4</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známá-1_^(*3ý-1)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-id123794-punct">
   <w.rf>
    <LM>w#w-d-id123794-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1429-6">
   <w.rf>
    <LM>w#w-d1t1429-6</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m116-d1t1429-9">
   <w.rf>
    <LM>w#w-d1t1429-9</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d1t1429-11">
   <w.rf>
    <LM>w#w-d1t1429-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1429-12">
   <w.rf>
    <LM>w#w-d1t1429-12</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1429-10">
   <w.rf>
    <LM>w#w-d1t1429-10</LM>
   </w.rf>
   <form>mobil</form>
   <lemma>mobil</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d1e1424-x2-352">
   <w.rf>
    <LM>w#w-d1e1424-x2-352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-353">
  <m id="m116-d1t1429-14">
   <w.rf>
    <LM>w#w-d1t1429-14</LM>
   </w.rf>
   <form>Nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m116-d1t1429-15">
   <w.rf>
    <LM>w#w-d1t1429-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1429-16">
   <w.rf>
    <LM>w#w-d1t1429-16</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m116-d-id123966-punct">
   <w.rf>
    <LM>w#w-d-id123966-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1429-19">
   <w.rf>
    <LM>w#w-d1t1429-19</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m116-d1t1429-20">
   <w.rf>
    <LM>w#w-d1t1429-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1429-21">
   <w.rf>
    <LM>w#w-d1t1429-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1429-22">
   <w.rf>
    <LM>w#w-d1t1429-22</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1429-23">
   <w.rf>
    <LM>w#w-d1t1429-23</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m116-d1t1429-24">
   <w.rf>
    <LM>w#w-d1t1429-24</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1429-25">
   <w.rf>
    <LM>w#w-d1t1429-25</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-353-354">
   <w.rf>
    <LM>w#w-353-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-355">
  <m id="m116-d1t1429-28">
   <w.rf>
    <LM>w#w-d1t1429-28</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m116-d1t1429-29">
   <w.rf>
    <LM>w#w-d1t1429-29</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m116-d1t1429-30">
   <w.rf>
    <LM>w#w-d1t1429-30</LM>
   </w.rf>
   <form>vyfotila</form>
   <lemma>vyfotit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m116-d-m-d1e1424-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1424-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1436-x2">
  <m id="m116-d1t1439-1">
   <w.rf>
    <LM>w#w-d1t1439-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t1439-2">
   <w.rf>
    <LM>w#w-d1t1439-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m116-d1t1439-3">
   <w.rf>
    <LM>w#w-d1t1439-3</LM>
   </w.rf>
   <form>nesete</form>
   <lemma>nést</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1439-4">
   <w.rf>
    <LM>w#w-d1t1439-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1439-5">
   <w.rf>
    <LM>w#w-d1t1439-5</LM>
   </w.rf>
   <form>batohu</form>
   <lemma>batoh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m116-d-id124300-punct">
   <w.rf>
    <LM>w#w-d-id124300-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1439-7">
   <w.rf>
    <LM>w#w-d1t1439-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1439-8">
   <w.rf>
    <LM>w#w-d1t1439-8</LM>
   </w.rf>
   <form>jdete</form>
   <lemma>jít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1439-9">
   <w.rf>
    <LM>w#w-d1t1439-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1439-10">
   <w.rf>
    <LM>w#w-d1t1439-10</LM>
   </w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d-id124370-punct">
   <w.rf>
    <LM>w#w-d-id124370-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1440-x2">
  <m id="m116-d1t1443-1">
   <w.rf>
    <LM>w#w-d1t1443-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1443-2">
   <w.rf>
    <LM>w#w-d1t1443-2</LM>
   </w.rf>
   <form>jdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1443-3">
   <w.rf>
    <LM>w#w-d1t1443-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1443-4">
   <w.rf>
    <LM>w#w-d1t1443-4</LM>
   </w.rf>
   <form>přírody</form>
   <lemma>příroda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d-id124494-punct">
   <w.rf>
    <LM>w#w-d-id124494-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1445-1">
   <w.rf>
    <LM>w#w-d1t1445-1</LM>
   </w.rf>
   <form>nosím</form>
   <lemma>nosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1e1440-x2-360">
   <w.rf>
    <LM>w#w-d1e1440-x2-360</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1445-2">
   <w.rf>
    <LM>w#w-d1t1445-2</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m116-d1t1445-3">
   <w.rf>
    <LM>w#w-d1t1445-3</LM>
   </w.rf>
   <form>turistickou</form>
   <lemma>turistický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m116-d1t1445-4">
   <w.rf>
    <LM>w#w-d1t1445-4</LM>
   </w.rf>
   <form>mapu</form>
   <lemma>mapa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d1e1440-x2-361">
   <w.rf>
    <LM>w#w-d1e1440-x2-361</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1447-3">
   <w.rf>
    <LM>w#w-d1t1447-3</LM>
   </w.rf>
   <form>pláštěnku</form>
   <lemma>pláštěnka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d-id124667-punct">
   <w.rf>
    <LM>w#w-d-id124667-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1447-5">
   <w.rf>
    <LM>w#w-d1t1447-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1447-6">
   <w.rf>
    <LM>w#w-d1t1447-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1447-7">
   <w.rf>
    <LM>w#w-d1t1447-7</LM>
   </w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d1t1447-8">
   <w.rf>
    <LM>w#w-d1t1447-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1449-1">
   <w.rf>
    <LM>w#w-d1t1449-1</LM>
   </w.rf>
   <form>změna</form>
   <lemma>změna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t1449-2">
   <w.rf>
    <LM>w#w-d1t1449-2</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m116-d1t1449-3">
   <w.rf>
    <LM>w#w-d1t1449-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d1t1449-4">
   <w.rf>
    <LM>w#w-d1t1449-4</LM>
   </w.rf>
   <form>rychlá</form>
   <lemma>rychlý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d1e1440-x2-362">
   <w.rf>
    <LM>w#w-d1e1440-x2-362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1451-3">
   <w.rf>
    <LM>w#w-d1t1451-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m116-d1t1451-4">
   <w.rf>
    <LM>w#w-d1t1451-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1451-5">
   <w.rf>
    <LM>w#w-d1t1451-5</LM>
   </w.rf>
   <form>jídlu</form>
   <lemma>jídlo</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m116-d1t1451-6">
   <w.rf>
    <LM>w#w-d1t1451-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1451-7">
   <w.rf>
    <LM>w#w-d1t1451-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m116-d1t1451-8">
   <w.rf>
    <LM>w#w-d1t1451-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1451-9">
   <w.rf>
    <LM>w#w-d1t1451-9</LM>
   </w.rf>
   <form>pití</form>
   <lemma>pití_^(*3ít)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m116-d-m-d1e1440-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1440-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1452-x2">
  <m id="m116-d1t1455-1">
   <w.rf>
    <LM>w#w-d1t1455-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m116-d-m-d1e1452-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1452-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1456-x2">
  <m id="m116-d1t1459-1">
   <w.rf>
    <LM>w#w-d1t1459-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d-m-d1e1456-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1456-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1460-x2">
  <m id="m116-d1t1463-1">
   <w.rf>
    <LM>w#w-d1t1463-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1463-2">
   <w.rf>
    <LM>w#w-d1t1463-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1463-3">
   <w.rf>
    <LM>w#w-d1t1463-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m116-d1t1463-4">
   <w.rf>
    <LM>w#w-d1t1463-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-id125215-punct">
   <w.rf>
    <LM>w#w-d-id125215-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1464-x2">
  <m id="m116-d1t1467-1">
   <w.rf>
    <LM>w#w-d1t1467-1</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m116-d1t1467-2">
   <w.rf>
    <LM>w#w-d1t1467-2</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t1469-1">
   <w.rf>
    <LM>w#w-d1t1469-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1e1464-x2-368">
   <w.rf>
    <LM>w#w-d1e1464-x2-368</LM>
   </w.rf>
   <form>vyfocená</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d-id125332-punct">
   <w.rf>
    <LM>w#w-d-id125332-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1469-3">
   <w.rf>
    <LM>w#w-d1t1469-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1469-4">
   <w.rf>
    <LM>w#w-d1t1469-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1469-5">
   <w.rf>
    <LM>w#w-d1t1469-5</LM>
   </w.rf>
   <form>jezdíval</form>
   <lemma>jezdívat_^(*4it)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1469-6">
   <w.rf>
    <LM>w#w-d1t1469-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1469-7">
   <w.rf>
    <LM>w#w-d1t1469-7</LM>
   </w.rf>
   <form>lázní</form>
   <lemma>lázně</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m116-d1e1464-x2-369">
   <w.rf>
    <LM>w#w-d1e1464-x2-369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-370">
  <m id="m116-d1t1469-10">
   <w.rf>
    <LM>w#w-d1t1469-10</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1469-11">
   <w.rf>
    <LM>w#w-d1t1469-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1469-12">
   <w.rf>
    <LM>w#w-d1t1469-12</LM>
   </w.rf>
   <form>parta</form>
   <lemma>parta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d1t1469-13">
   <w.rf>
    <LM>w#w-d1t1469-13</LM>
   </w.rf>
   <form>lázeňských</form>
   <lemma>lázeňský-2_^(např._dům,_péče,_oplatky)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m116-d1t1469-14">
   <w.rf>
    <LM>w#w-d1t1469-14</LM>
   </w.rf>
   <form>hostů</form>
   <lemma>host</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m116-d1t1469-15">
   <w.rf>
    <LM>w#w-d1t1469-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1469-16">
   <w.rf>
    <LM>w#w-d1t1469-16</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-m-d1e1464-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1464-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1470-x2">
  <m id="m116-d1t1473-1">
   <w.rf>
    <LM>w#w-d1t1473-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m116-d1t1473-2">
   <w.rf>
    <LM>w#w-d1t1473-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m116-d1t1473-3">
   <w.rf>
    <LM>w#w-d1t1473-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1473-4">
   <w.rf>
    <LM>w#w-d1t1473-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m116-d1t1473-5">
   <w.rf>
    <LM>w#w-d1t1473-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d-id125681-punct">
   <w.rf>
    <LM>w#w-d-id125681-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1474-x2">
  <m id="m116-d1t1477-1">
   <w.rf>
    <LM>w#w-d1t1477-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1477-2">
   <w.rf>
    <LM>w#w-d1t1477-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t1477-3">
   <w.rf>
    <LM>w#w-d1t1477-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1477-4">
   <w.rf>
    <LM>w#w-d1t1477-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1477-5">
   <w.rf>
    <LM>w#w-d1t1477-5</LM>
   </w.rf>
   <form>kamarádi</form>
   <lemma>kamarád</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m116-d1t1477-6">
   <w.rf>
    <LM>w#w-d1t1477-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1477-7">
   <w.rf>
    <LM>w#w-d1t1477-7</LM>
   </w.rf>
   <form>kamarádky</form>
   <lemma>kamarádka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d-id125851-punct">
   <w.rf>
    <LM>w#w-d-id125851-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1477-9">
   <w.rf>
    <LM>w#w-d1t1477-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m116-d1t1477-10">
   <w.rf>
    <LM>w#w-d1t1477-10</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m116-d1t1477-11">
   <w.rf>
    <LM>w#w-d1t1477-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1477-12">
   <w.rf>
    <LM>w#w-d1t1477-12</LM>
   </w.rf>
   <form>prožíval</form>
   <lemma>prožívat_^(*3t)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1477-13">
   <w.rf>
    <LM>w#w-d1t1477-13</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m116-d1t1477-14">
   <w.rf>
    <LM>w#w-d1t1477-14</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m116-d1e1474-x2-377">
   <w.rf>
    <LM>w#w-d1e1474-x2-377</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-379">
  <m id="m116-d1t1479-5">
   <w.rf>
    <LM>w#w-d1t1479-5</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m116-d1t1479-6">
   <w.rf>
    <LM>w#w-d1t1479-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1479-7">
   <w.rf>
    <LM>w#w-d1t1479-7</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t1479-8">
   <w.rf>
    <LM>w#w-d1t1479-8</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-id126093-punct">
   <w.rf>
    <LM>w#w-d-id126093-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1479-10">
   <w.rf>
    <LM>w#w-d1t1479-10</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m116-379-381">
   <w.rf>
    <LM>w#w-379-381</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-382">
  <m id="m116-d1t1479-17">
   <w.rf>
    <LM>w#w-d1t1479-17</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1479-18">
   <w.rf>
    <LM>w#w-d1t1479-18</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t1479-19">
   <w.rf>
    <LM>w#w-d1t1479-19</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1479-20">
   <w.rf>
    <LM>w#w-d1t1479-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1479-21">
   <w.rf>
    <LM>w#w-d1t1479-21</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1479-14">
   <w.rf>
    <LM>w#w-d1t1479-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1479-15">
   <w.rf>
    <LM>w#w-d1t1479-15</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1479-22">
   <w.rf>
    <LM>w#w-d1t1479-22</LM>
   </w.rf>
   <form>cizí</form>
   <lemma>cizí</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m116-d1t1479-23">
   <w.rf>
    <LM>w#w-d1t1479-23</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m116-379-380">
   <w.rf>
    <LM>w#w-379-380</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1479-24">
   <w.rf>
    <LM>w#w-d1t1479-24</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1479-25">
   <w.rf>
    <LM>w#w-d1t1479-25</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1479-26">
   <w.rf>
    <LM>w#w-d1t1479-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1479-27">
   <w.rf>
    <LM>w#w-d1t1479-27</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1479-28">
   <w.rf>
    <LM>w#w-d1t1479-28</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m116-d-id126382-punct">
   <w.rf>
    <LM>w#w-d-id126382-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1479-30">
   <w.rf>
    <LM>w#w-d1t1479-30</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1479-31">
   <w.rf>
    <LM>w#w-d1t1479-31</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1479-32">
   <w.rf>
    <LM>w#w-d1t1479-32</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t1479-34">
   <w.rf>
    <LM>w#w-d1t1479-34</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1479-33">
   <w.rf>
    <LM>w#w-d1t1479-33</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1479-35">
   <w.rf>
    <LM>w#w-d1t1479-35</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m116-d1t1479-36">
   <w.rf>
    <LM>w#w-d1t1479-36</LM>
   </w.rf>
   <form>kamarádi</form>
   <lemma>kamarád</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m116-d-m-d1e1474-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1474-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1480-x2">
  <m id="m116-d1t1483-1">
   <w.rf>
    <LM>w#w-d1t1483-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1483-2">
   <w.rf>
    <LM>w#w-d1t1483-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1483-5">
   <w.rf>
    <LM>w#w-d1t1483-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1483-3">
   <w.rf>
    <LM>w#w-d1t1483-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1483-4">
   <w.rf>
    <LM>w#w-d1t1483-4</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d-id126630-punct">
   <w.rf>
    <LM>w#w-d-id126630-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1484-x2">
  <m id="m116-d1t1487-3">
   <w.rf>
    <LM>w#w-d1t1487-3</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1487-4">
   <w.rf>
    <LM>w#w-d1t1487-4</LM>
   </w.rf>
   <form>lázní</form>
   <lemma>lázně</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m116-d1t1487-2">
   <w.rf>
    <LM>w#w-d1t1487-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1487-5">
   <w.rf>
    <LM>w#w-d1t1487-5</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1487-6">
   <w.rf>
    <LM>w#w-d1t1487-6</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d1t1487-7">
   <w.rf>
    <LM>w#w-d1t1487-7</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d1e1484-x2-389">
   <w.rf>
    <LM>w#w-d1e1484-x2-389</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-390">
  <m id="m116-d1t1487-9">
   <w.rf>
    <LM>w#w-d1t1487-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1487-10">
   <w.rf>
    <LM>w#w-d1t1487-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1487-11">
   <w.rf>
    <LM>w#w-d1t1487-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1487-12">
   <w.rf>
    <LM>w#w-d1t1487-12</LM>
   </w.rf>
   <form>vojákem</form>
   <lemma>voják</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m116-d-id126911-punct">
   <w.rf>
    <LM>w#w-d-id126911-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1487-19">
   <w.rf>
    <LM>w#w-d1t1487-19</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1487-18">
   <w.rf>
    <LM>w#w-d1t1487-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1487-20">
   <w.rf>
    <LM>w#w-d1t1487-20</LM>
   </w.rf>
   <form>takzvané</form>
   <lemma>takzvaný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m116-d1t1487-21">
   <w.rf>
    <LM>w#w-d1t1487-21</LM>
   </w.rf>
   <form>rehabilitace</form>
   <lemma>rehabilitace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m116-390-391">
   <w.rf>
    <LM>w#w-390-391</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-392">
  <m id="m116-d1t1487-23">
   <w.rf>
    <LM>w#w-d1t1487-23</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1487-24">
   <w.rf>
    <LM>w#w-d1t1487-24</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1487-25">
   <w.rf>
    <LM>w#w-d1t1487-25</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m116-d1t1487-26">
   <w.rf>
    <LM>w#w-d1t1487-26</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m116-d1t1487-27">
   <w.rf>
    <LM>w#w-d1t1487-27</LM>
   </w.rf>
   <form>rehabilitace</form>
   <lemma>rehabilitace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-d1t1487-28">
   <w.rf>
    <LM>w#w-d1t1487-28</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1487-29">
   <w.rf>
    <LM>w#w-d1t1487-29</LM>
   </w.rf>
   <form>dával</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1487-30">
   <w.rf>
    <LM>w#w-d1t1487-30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1487-31">
   <w.rf>
    <LM>w#w-d1t1487-31</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1487-32">
   <w.rf>
    <LM>w#w-d1t1487-32</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m116-d1t1487-33">
   <w.rf>
    <LM>w#w-d1t1487-33</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-d1t1487-34">
   <w.rf>
    <LM>w#w-d1t1487-34</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m116-392-393">
   <w.rf>
    <LM>w#w-392-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-394">
  <m id="m116-d1t1489-1">
   <w.rf>
    <LM>w#w-d1t1489-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1489-2">
   <w.rf>
    <LM>w#w-d1t1489-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1489-3">
   <w.rf>
    <LM>w#w-d1t1489-3</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m116-d1t1489-4">
   <w.rf>
    <LM>w#w-d1t1489-4</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d-id127270-punct">
   <w.rf>
    <LM>w#w-d-id127270-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1489-6">
   <w.rf>
    <LM>w#w-d1t1489-6</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1489-7">
   <w.rf>
    <LM>w#w-d1t1489-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1489-10">
   <w.rf>
    <LM>w#w-d1t1489-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1489-8">
   <w.rf>
    <LM>w#w-d1t1489-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1489-9">
   <w.rf>
    <LM>w#w-d1t1489-9</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d1t1489-11">
   <w.rf>
    <LM>w#w-d1t1489-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t1489-12">
   <w.rf>
    <LM>w#w-d1t1489-12</LM>
   </w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1489-13">
   <w.rf>
    <LM>w#w-d1t1489-13</LM>
   </w.rf>
   <form>patnáctkrát</form>
   <lemma>patnáctkrát`15_^(*4)</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m116-394-395">
   <w.rf>
    <LM>w#w-394-395</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1489-14">
   <w.rf>
    <LM>w#w-d1t1489-14</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m116-d1t1489-15">
   <w.rf>
    <LM>w#w-d1t1489-15</LM>
   </w.rf>
   <form>dvacetkrát</form>
   <lemma>dvacetkrát`20</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m116-d-m-d1e1484-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1484-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1490-x2">
  <m id="m116-d1t1493-1">
   <w.rf>
    <LM>w#w-d1t1493-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1493-2">
   <w.rf>
    <LM>w#w-d1t1493-2</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1493-3">
   <w.rf>
    <LM>w#w-d1t1493-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1493-4">
   <w.rf>
    <LM>w#w-d1t1493-4</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d-id127549-punct">
   <w.rf>
    <LM>w#w-d-id127549-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1495-x2">
  <m id="m116-d1t1498-3">
   <w.rf>
    <LM>w#w-d1t1498-3</LM>
   </w.rf>
   <form>Jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1498-2">
   <w.rf>
    <LM>w#w-d1t1498-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1498-4">
   <w.rf>
    <LM>w#w-d1t1498-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m116-d1t1498-5">
   <w.rf>
    <LM>w#w-d1t1498-5</LM>
   </w.rf>
   <form>jedněch</form>
   <lemma>jedny`1</lemma>
   <tag>CdXP2----------</tag>
  </m>
  <m id="m116-d1t1498-6">
   <w.rf>
    <LM>w#w-d1t1498-6</LM>
   </w.rf>
   <form>jediných</form>
   <lemma>jediný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m116-d1t1498-7">
   <w.rf>
    <LM>w#w-d1t1498-7</LM>
   </w.rf>
   <form>lázní</form>
   <lemma>lázně</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m116-d1t1498-8">
   <w.rf>
    <LM>w#w-d1t1498-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1498-9">
   <w.rf>
    <LM>w#w-d1t1498-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1498-10">
   <w.rf>
    <LM>w#w-d1t1498-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1498-12">
   <w.rf>
    <LM>w#w-d1t1498-12</LM>
   </w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d1t1498-13">
   <w.rf>
    <LM>w#w-d1t1498-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1498-14">
   <w.rf>
    <LM>w#w-d1t1498-14</LM>
   </w.rf>
   <form>Čechách</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d1e1495-x2-406">
   <w.rf>
    <LM>w#w-d1e1495-x2-406</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-407">
  <m id="m116-d1e1495-x2-405">
   <w.rf>
    <LM>w#w-d1e1495-x2-405</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m116-d1t1498-17">
   <w.rf>
    <LM>w#w-d1t1498-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1498-18">
   <w.rf>
    <LM>w#w-d1t1498-18</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1498-19">
   <w.rf>
    <LM>w#w-d1t1498-19</LM>
   </w.rf>
   <form>nejradši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m116-d-id127885-punct">
   <w.rf>
    <LM>w#w-d-id127885-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1498-21">
   <w.rf>
    <LM>w#w-d1t1498-21</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1498-33">
   <w.rf>
    <LM>w#w-d1t1498-33</LM>
   </w.rf>
   <form>lázeňský</form>
   <lemma>lázeňský-2_^(např._dům,_péče,_oplatky)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m116-d1t1498-34">
   <w.rf>
    <LM>w#w-d1t1498-34</LM>
   </w.rf>
   <form>ústav</form>
   <lemma>ústav</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-d1t1498-29">
   <w.rf>
    <LM>w#w-d1t1498-29</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m116-d1t1498-31">
   <w.rf>
    <LM>w#w-d1t1498-31</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m116-d1t1500-1">
   <w.rf>
    <LM>w#w-d1t1500-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1500-2">
   <w.rf>
    <LM>w#w-d1t1500-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1500-3">
   <w.rf>
    <LM>w#w-d1t1500-3</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d1t1500-4">
   <w.rf>
    <LM>w#w-d1t1500-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1500-5">
   <w.rf>
    <LM>w#w-d1t1500-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1500-6">
   <w.rf>
    <LM>w#w-d1t1500-6</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m116-d1t1500-7">
   <w.rf>
    <LM>w#w-d1t1500-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t1500-8">
   <w.rf>
    <LM>w#w-d1t1500-8</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDNP4----------</tag>
  </m>
  <m id="m116-d1t1500-9">
   <w.rf>
    <LM>w#w-d1t1500-9</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léta</lemma>
   <tag>NNNP4-----A---2</tag>
  </m>
  <m id="m116-d1t1500-10">
   <w.rf>
    <LM>w#w-d1t1500-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1500-11">
   <w.rf>
    <LM>w#w-d1t1500-11</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m116-d1t1500-12">
   <w.rf>
    <LM>w#w-d1t1500-12</LM>
   </w.rf>
   <form>znali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-407-408">
   <w.rf>
    <LM>w#w-407-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-409">
  <m id="m116-d1t1502-2">
   <w.rf>
    <LM>w#w-d1t1502-2</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1502-3">
   <w.rf>
    <LM>w#w-d1t1502-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1502-4">
   <w.rf>
    <LM>w#w-d1t1502-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1502-5">
   <w.rf>
    <LM>w#w-d1t1502-5</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m116-d1t1502-6">
   <w.rf>
    <LM>w#w-d1t1502-6</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-409-410">
   <w.rf>
    <LM>w#w-409-410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-411">
  <m id="m116-d1t1504-1">
   <w.rf>
    <LM>w#w-d1t1504-1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1504-2">
   <w.rf>
    <LM>w#w-d1t1504-2</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d-id128453-punct">
   <w.rf>
    <LM>w#w-d-id128453-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1504-4">
   <w.rf>
    <LM>w#w-d1t1504-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-d1t1504-5">
   <w.rf>
    <LM>w#w-d1t1504-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1504-6">
   <w.rf>
    <LM>w#w-d1t1504-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m116-d1t1504-7">
   <w.rf>
    <LM>w#w-d1t1504-7</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d1t1504-8">
   <w.rf>
    <LM>w#w-d1t1504-8</LM>
   </w.rf>
   <form>lékařská</form>
   <lemma>lékařský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m116-d1t1504-9">
   <w.rf>
    <LM>w#w-d1t1504-9</LM>
   </w.rf>
   <form>péče</form>
   <lemma>péče</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m116-d-m-d1e1495-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1495-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1505-x2">
  <m id="m116-d1t1508-1">
   <w.rf>
    <LM>w#w-d1t1508-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t1508-2">
   <w.rf>
    <LM>w#w-d1t1508-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m116-d1t1508-3">
   <w.rf>
    <LM>w#w-d1t1508-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m116-d1t1508-4">
   <w.rf>
    <LM>w#w-d1t1508-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1508-5">
   <w.rf>
    <LM>w#w-d1t1508-5</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d-id128685-punct">
   <w.rf>
    <LM>w#w-d-id128685-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1509-x2">
  <m id="m116-d1t1514-6">
   <w.rf>
    <LM>w#w-d1t1514-6</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m116-d1t1514-7">
   <w.rf>
    <LM>w#w-d1t1514-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1514-9">
   <w.rf>
    <LM>w#w-d1t1514-9</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1514-3">
   <w.rf>
    <LM>w#w-d1t1514-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1514-4">
   <w.rf>
    <LM>w#w-d1t1514-4</LM>
   </w.rf>
   <form>lázních</form>
   <lemma>lázně</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m116-d1e1509-x2-421">
   <w.rf>
    <LM>w#w-d1e1509-x2-421</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-422">
  <m id="m116-d1t1514-14">
   <w.rf>
    <LM>w#w-d1t1514-14</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1514-15">
   <w.rf>
    <LM>w#w-d1t1514-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1514-17">
   <w.rf>
    <LM>w#w-d1t1514-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t1514-18">
   <w.rf>
    <LM>w#w-d1t1514-18</LM>
   </w.rf>
   <form>procedury</form>
   <lemma>procedura</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m116-422-423">
   <w.rf>
    <LM>w#w-422-423</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1516-5">
   <w.rf>
    <LM>w#w-d1t1516-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1516-4">
   <w.rf>
    <LM>w#w-d1t1516-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1516-6">
   <w.rf>
    <LM>w#w-d1t1516-6</LM>
   </w.rf>
   <form>vířivky</form>
   <lemma>vířivka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d-id129122-punct">
   <w.rf>
    <LM>w#w-d-id129122-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1516-8">
   <w.rf>
    <LM>w#w-d1t1516-8</LM>
   </w.rf>
   <form>masáže</form>
   <lemma>masáž</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d1t1516-12">
   <w.rf>
    <LM>w#w-d1t1516-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1516-13">
   <w.rf>
    <LM>w#w-d1t1516-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1516-14">
   <w.rf>
    <LM>w#w-d1t1516-14</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-422-427">
   <w.rf>
    <LM>w#w-422-427</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1516-16">
   <w.rf>
    <LM>w#w-d1t1516-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-422-424">
   <w.rf>
    <LM>w#w-422-424</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1516-17">
   <w.rf>
    <LM>w#w-d1t1516-17</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t1516-18">
   <w.rf>
    <LM>w#w-d1t1516-18</LM>
   </w.rf>
   <form>předepisoval</form>
   <lemma>předepisovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1516-19">
   <w.rf>
    <LM>w#w-d1t1516-19</LM>
   </w.rf>
   <form>doktor</form>
   <lemma>doktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m116-422-425">
   <w.rf>
    <LM>w#w-422-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-426">
  <m id="m116-d1t1518-1">
   <w.rf>
    <LM>w#w-d1t1518-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1518-2">
   <w.rf>
    <LM>w#w-d1t1518-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1518-3">
   <w.rf>
    <LM>w#w-d1t1518-3</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1518-4">
   <w.rf>
    <LM>w#w-d1t1518-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t1518-5">
   <w.rf>
    <LM>w#w-d1t1518-5</LM>
   </w.rf>
   <form>zábavy</form>
   <lemma>zábava</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m116-d-id129402-punct">
   <w.rf>
    <LM>w#w-d-id129402-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1518-8">
   <w.rf>
    <LM>w#w-d1t1518-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1518-7">
   <w.rf>
    <LM>w#w-d1t1518-7</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1518-9">
   <w.rf>
    <LM>w#w-d1t1518-9</LM>
   </w.rf>
   <form>patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1518-10">
   <w.rf>
    <LM>w#w-d1t1518-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1518-11">
   <w.rf>
    <LM>w#w-d1t1518-11</LM>
   </w.rf>
   <form>lázeňské</form>
   <lemma>lázeňský-2_^(např._dům,_péče,_oplatky)</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m116-d1t1518-12">
   <w.rf>
    <LM>w#w-d1t1518-12</LM>
   </w.rf>
   <form>terapii</form>
   <lemma>terapie</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m116-426-428">
   <w.rf>
    <LM>w#w-426-428</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-426-432">
   <w.rf>
    <LM>w#w-426-432</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1520-2">
   <w.rf>
    <LM>w#w-d1t1520-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t1520-3">
   <w.rf>
    <LM>w#w-d1t1520-3</LM>
   </w.rf>
   <form>procházky</form>
   <lemma>procházka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m116-426-429">
   <w.rf>
    <LM>w#w-426-429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-430">
  <m id="m116-d1t1520-5">
   <w.rf>
    <LM>w#w-d1t1520-5</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1520-6">
   <w.rf>
    <LM>w#w-d1t1520-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1520-7">
   <w.rf>
    <LM>w#w-d1t1520-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1520-8">
   <w.rf>
    <LM>w#w-d1t1520-8</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-430-431">
   <w.rf>
    <LM>w#w-430-431</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-433">
  <m id="m116-d1t1523-1">
   <w.rf>
    <LM>w#w-d1t1523-1</LM>
   </w.rf>
   <form>Zkrátka</form>
   <lemma>zkrátka-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1523-3">
   <w.rf>
    <LM>w#w-d1t1523-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1523-4">
   <w.rf>
    <LM>w#w-d1t1523-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1523-2">
   <w.rf>
    <LM>w#w-d1t1523-2</LM>
   </w.rf>
   <form>užívali</form>
   <lemma>užívat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m116-d1t1523-5">
   <w.rf>
    <LM>w#w-d1t1523-5</LM>
   </w.rf>
   <form>klid</form>
   <lemma>klid</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d1t1523-6">
   <w.rf>
    <LM>w#w-d1t1523-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1523-7">
   <w.rf>
    <LM>w#w-d1t1523-7</LM>
   </w.rf>
   <form>pohodu</form>
   <lemma>pohoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m116-d-id129760-punct">
   <w.rf>
    <LM>w#w-d-id129760-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1523-9">
   <w.rf>
    <LM>w#w-d1t1523-9</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m116-d1t1523-10">
   <w.rf>
    <LM>w#w-d1t1523-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m116-d1t1523-11">
   <w.rf>
    <LM>w#w-d1t1523-11</LM>
   </w.rf>
   <form>odpočinuli</form>
   <lemma>odpočinout</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m116-d-m-d1e1509-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1509-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1524-x2">
  <m id="m116-d1t1527-2">
   <w.rf>
    <LM>w#w-d1t1527-2</LM>
   </w.rf>
   <form>Pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1527-3">
   <w.rf>
    <LM>w#w-d1t1527-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m116-d1t1527-4">
   <w.rf>
    <LM>w#w-d1t1527-4</LM>
   </w.rf>
   <form>lázeňský</form>
   <lemma>lázeňský-2_^(např._dům,_péče,_oplatky)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m116-d1t1527-5">
   <w.rf>
    <LM>w#w-d1t1527-5</LM>
   </w.rf>
   <form>pobyt</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m116-d1t1527-6">
   <w.rf>
    <LM>w#w-d1t1527-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1527-7">
   <w.rf>
    <LM>w#w-d1t1527-7</LM>
   </w.rf>
   <form>fyzické</form>
   <lemma>fyzický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m116-d1t1527-8">
   <w.rf>
    <LM>w#w-d1t1527-8</LM>
   </w.rf>
   <form>stránce</form>
   <lemma>stránka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id129992-punct">
   <w.rf>
    <LM>w#w-d-id129992-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1528-x2">
  <m id="m116-d1t1531-1">
   <w.rf>
    <LM>w#w-d1t1531-1</LM>
   </w.rf>
   <form>Lázně</form>
   <lemma>lázně</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>Teplice</form>
   <lemma>Teplice_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m116-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m116-d1t1531-6">
   <w.rf>
    <LM>w#w-d1t1531-6</LM>
   </w.rf>
   <form>zavedené</form>
   <lemma>zavedený_^(*5ést)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m116-d1t1531-7">
   <w.rf>
    <LM>w#w-d1t1531-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m116-d1t1531-8">
   <w.rf>
    <LM>w#w-d1t1531-8</LM>
   </w.rf>
   <form>pohybová</form>
   <lemma>pohybový</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m116-d1t1531-9">
   <w.rf>
    <LM>w#w-d1t1531-9</LM>
   </w.rf>
   <form>ústrojí</form>
   <lemma>ústrojí</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m116-d1e1528-x2-441">
   <w.rf>
    <LM>w#w-d1e1528-x2-441</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-442">
  <m id="m116-d1t1533-2">
   <w.rf>
    <LM>w#w-d1t1533-2</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m116-d1t1533-3">
   <w.rf>
    <LM>w#w-d1t1533-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1533-4">
   <w.rf>
    <LM>w#w-d1t1533-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m116-d-id130258-punct">
   <w.rf>
    <LM>w#w-d-id130258-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1533-6">
   <w.rf>
    <LM>w#w-d1t1533-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m116-442-443">
   <w.rf>
    <LM>w#w-442-443</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1535-5">
   <w.rf>
    <LM>w#w-d1t1535-5</LM>
   </w.rf>
   <form>trpěl</form>
   <lemma>trpět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1535-6">
   <w.rf>
    <LM>w#w-d1t1535-6</LM>
   </w.rf>
   <form>ischemickou</form>
   <lemma>ischemický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m116-d1t1535-7">
   <w.rf>
    <LM>w#w-d1t1535-7</LM>
   </w.rf>
   <form>chorobou</form>
   <lemma>choroba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m116-d1t1535-8">
   <w.rf>
    <LM>w#w-d1t1535-8</LM>
   </w.rf>
   <form>dolních</form>
   <lemma>dolní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m116-d1t1535-9">
   <w.rf>
    <LM>w#w-d1t1535-9</LM>
   </w.rf>
   <form>končetin</form>
   <lemma>končetina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m116-d-id130431-punct">
   <w.rf>
    <LM>w#w-d-id130431-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1535-13">
   <w.rf>
    <LM>w#w-d1t1535-13</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m116-d1t1535-12">
   <w.rf>
    <LM>w#w-d1t1535-12</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m116-d1t1535-14">
   <w.rf>
    <LM>w#w-d1t1535-14</LM>
   </w.rf>
   <form>pomáhaly</form>
   <lemma>pomáhat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m116-442-444">
   <w.rf>
    <LM>w#w-442-444</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-445">
  <m id="m116-d1t1535-19">
   <w.rf>
    <LM>w#w-d1t1535-19</LM>
   </w.rf>
   <form>Lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m116-d1t1535-17">
   <w.rf>
    <LM>w#w-d1t1535-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m116-d1t1535-18">
   <w.rf>
    <LM>w#w-d1t1535-18</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m116-d1t1535-20">
   <w.rf>
    <LM>w#w-d1t1535-20</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1535-21">
   <w.rf>
    <LM>w#w-d1t1535-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m116-d1t1535-22">
   <w.rf>
    <LM>w#w-d1t1535-22</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m116-d1t1535-23">
   <w.rf>
    <LM>w#w-d1t1535-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m116-d1t1535-24">
   <w.rf>
    <LM>w#w-d1t1535-24</LM>
   </w.rf>
   <form>znát</form>
   <lemma>znát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m116-d1t1535-25">
   <w.rf>
    <LM>w#w-d1t1535-25</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m116-d1t1535-26">
   <w.rf>
    <LM>w#w-d1t1535-26</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m116-d-id130681-punct">
   <w.rf>
    <LM>w#w-d-id130681-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m116-d1t1535-28">
   <w.rf>
    <LM>w#w-d1t1535-28</LM>
   </w.rf>
   <form>kdykoli</form>
   <lemma>kdykoli</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1535-29">
   <w.rf>
    <LM>w#w-d1t1535-29</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1535-30">
   <w.rf>
    <LM>w#w-d1t1535-30</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m116-d1t1535-31">
   <w.rf>
    <LM>w#w-d1t1535-31</LM>
   </w.rf>
   <form>přijel</form>
   <lemma>přijet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m116-d-m-d1e1528-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1528-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-d1e1536-x2">
  <m id="m116-d1t1539-1">
   <w.rf>
    <LM>w#w-d1t1539-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m116-d1e1536-x2-447">
   <w.rf>
    <LM>w#w-d1e1536-x2-447</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-450">
  <m id="m116-d1t1541-1">
   <w.rf>
    <LM>w#w-d1t1541-1</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m116-d1t1541-2">
   <w.rf>
    <LM>w#w-d1t1541-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m116-d1t1541-3">
   <w.rf>
    <LM>w#w-d1t1541-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m116-d1t1541-4">
   <w.rf>
    <LM>w#w-d1t1541-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m116-d1e1536-x2-448">
   <w.rf>
    <LM>w#w-d1e1536-x2-448</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m116-449">
  <m id="m116-d1t1543-1">
   <w.rf>
    <LM>w#w-d1t1543-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m116-d1t1543-2">
   <w.rf>
    <LM>w#w-d1t1543-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m116-d1t1543-3">
   <w.rf>
    <LM>w#w-d1t1543-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m116-d1t1543-4">
   <w.rf>
    <LM>w#w-d1t1543-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m116-d1t1543-5">
   <w.rf>
    <LM>w#w-d1t1543-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m116-d-id130991-punct">
   <w.rf>
    <LM>w#w-d-id130991-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
