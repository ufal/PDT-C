<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_048.05.w.gz" />
  </references>
 </head>
 <s id="m048-d1e1418-x2">
  <m id="m048-d1t1421-3">
   <w.rf>
    <LM>w#w-d1t1421-3</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m048-d1t1421-4">
   <w.rf>
    <LM>w#w-d1t1421-4</LM>
   </w.rf>
   <form>nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1421-5">
   <w.rf>
    <LM>w#w-d1t1421-5</LM>
   </w.rf>
   <form>nejezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m048-d-id100671-punct">
   <w.rf>
    <LM>w#w-d-id100671-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1421-7">
   <w.rf>
    <LM>w#w-d1t1421-7</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m048-d1e1418-x2-96">
   <w.rf>
    <LM>w#w-d1e1418-x2-96</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1421-8">
   <w.rf>
    <LM>w#w-d1t1421-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m048-d1t1421-9">
   <w.rf>
    <LM>w#w-d1t1421-9</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m048-d1e1418-x2-94">
   <w.rf>
    <LM>w#w-d1e1418-x2-94</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1423-1">
   <w.rf>
    <LM>w#w-d1t1423-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1423-2">
   <w.rf>
    <LM>w#w-d1t1423-2</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1423-3">
   <w.rf>
    <LM>w#w-d1t1423-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1423-6">
   <w.rf>
    <LM>w#w-d1t1423-6</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m048-d1t1423-7">
   <w.rf>
    <LM>w#w-d1t1423-7</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m048-d1t1423-4">
   <w.rf>
    <LM>w#w-d1t1423-4</LM>
   </w.rf>
   <form>bydliště</form>
   <lemma>bydliště</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1418-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1418-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1427-x2">
  <m id="m048-d1t1432-2">
   <w.rf>
    <LM>w#w-d1t1432-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1432-3">
   <w.rf>
    <LM>w#w-d1t1432-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1432-4">
   <w.rf>
    <LM>w#w-d1t1432-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1432-5">
   <w.rf>
    <LM>w#w-d1t1432-5</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m048-d-m-d1e1427-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1427-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1427-x3">
  <m id="m048-d1t1434-1">
   <w.rf>
    <LM>w#w-d1t1434-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d-m-d1e1427-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1427-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1435-x2">
  <m id="m048-d1t1438-1">
   <w.rf>
    <LM>w#w-d1t1438-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m048-d1t1438-2">
   <w.rf>
    <LM>w#w-d1t1438-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1438-3">
   <w.rf>
    <LM>w#w-d1t1438-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1438-4">
   <w.rf>
    <LM>w#w-d1t1438-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1438-5">
   <w.rf>
    <LM>w#w-d1t1438-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m048-d1t1438-7">
   <w.rf>
    <LM>w#w-d1t1438-7</LM>
   </w.rf>
   <form>psa</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m048-d-id101146-punct">
   <w.rf>
    <LM>w#w-d-id101146-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1439-x2">
  <m id="m048-d1t1442-5">
   <w.rf>
    <LM>w#w-d1t1442-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1442-6">
   <w.rf>
    <LM>w#w-d1t1442-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m048-d1t1444-1">
   <w.rf>
    <LM>w#w-d1t1444-1</LM>
   </w.rf>
   <form>krásný</form>
   <lemma>krásný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-d1t1444-2">
   <w.rf>
    <LM>w#w-d1t1444-2</LM>
   </w.rf>
   <form>pejsek</form>
   <lemma>pejsek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d1e1439-x2-102">
   <w.rf>
    <LM>w#w-d1e1439-x2-102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1446-1">
   <w.rf>
    <LM>w#w-d1t1446-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1446-2">
   <w.rf>
    <LM>w#w-d1t1446-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m048-d1t1446-3">
   <w.rf>
    <LM>w#w-d1t1446-3</LM>
   </w.rf>
   <form>bráchova</form>
   <lemma>bráchův_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m048-d1t1450-3">
   <w.rf>
    <LM>w#w-d1t1450-3</LM>
   </w.rf>
   <form>Ťapinka</form>
   <lemma>Ťapinka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1e1439-x2-103">
   <w.rf>
    <LM>w#w-d1e1439-x2-103</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1450-5">
   <w.rf>
    <LM>w#w-d1t1450-5</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1450-6">
   <w.rf>
    <LM>w#w-d1t1450-6</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-d1t1450-7">
   <w.rf>
    <LM>w#w-d1t1450-7</LM>
   </w.rf>
   <form>pejseček</form>
   <lemma>pejseček_,e</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d-id101501-punct">
   <w.rf>
    <LM>w#w-d-id101501-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1450-9">
   <w.rf>
    <LM>w#w-d1t1450-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1450-10">
   <w.rf>
    <LM>w#w-d1t1450-10</LM>
   </w.rf>
   <form>zajelo</form>
   <lemma>zajet_^(např._autem)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m048-d1t1450-11">
   <w.rf>
    <LM>w#w-d1t1450-11</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m048-d1e1439-x2-108">
   <w.rf>
    <LM>w#w-d1e1439-x2-108</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m048-d1t1450-12">
   <w.rf>
    <LM>w#w-d1t1450-12</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1439-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1439-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1454-x2">
  <m id="m048-d1t1459-1">
   <w.rf>
    <LM>w#w-d1t1459-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m048-d1t1459-2">
   <w.rf>
    <LM>w#w-d1t1459-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1459-4">
   <w.rf>
    <LM>w#w-d1t1459-4</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m048-d1t1459-5">
   <w.rf>
    <LM>w#w-d1t1459-5</LM>
   </w.rf>
   <form>oplakali</form>
   <lemma>oplakat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m048-d-m-d1e1454-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1454-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1454-x3">
  <m id="m048-d1t1461-1">
   <w.rf>
    <LM>w#w-d1t1461-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1461-2">
   <w.rf>
    <LM>w#w-d1t1461-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1461-3">
   <w.rf>
    <LM>w#w-d1t1461-3</LM>
   </w.rf>
   <form>smutné</form>
   <lemma>smutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m048-d-m-d1e1454-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1454-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1462-x2">
  <m id="m048-d1t1471-1">
   <w.rf>
    <LM>w#w-d1t1471-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1471-2">
   <w.rf>
    <LM>w#w-d1t1471-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1471-3">
   <w.rf>
    <LM>w#w-d1t1471-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1473-1">
   <w.rf>
    <LM>w#w-d1t1473-1</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1473-4">
   <w.rf>
    <LM>w#w-d1t1473-4</LM>
   </w.rf>
   <form>Ťapinku</form>
   <lemma>Ťapinka_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m048-d-id102047-punct">
   <w.rf>
    <LM>w#w-d-id102047-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1473-7">
   <w.rf>
    <LM>w#w-d1t1473-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1473-8">
   <w.rf>
    <LM>w#w-d1t1473-8</LM>
   </w.rf>
   <form>jezevčíka</form>
   <lemma>jezevčík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m048-d1e1462-x2-116">
   <w.rf>
    <LM>w#w-d1e1462-x2-116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-117">
  <m id="m048-d1t1478-1">
   <w.rf>
    <LM>w#w-d1t1478-1</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1478-2">
   <w.rf>
    <LM>w#w-d1t1478-2</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m048-d1t1478-3">
   <w.rf>
    <LM>w#w-d1t1478-3</LM>
   </w.rf>
   <form>mazel</form>
   <lemma>mazel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-117-118">
   <w.rf>
    <LM>w#w-117-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-119">
  <m id="m048-d1t1480-2">
   <w.rf>
    <LM>w#w-d1t1480-2</LM>
   </w.rf>
   <form>Přijdete</form>
   <lemma>přijít</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m048-d1t1480-1">
   <w.rf>
    <LM>w#w-d1t1480-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-119-120">
   <w.rf>
    <LM>w#w-119-120</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1480-3">
   <w.rf>
    <LM>w#w-d1t1480-3</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m048-d1t1480-4">
   <w.rf>
    <LM>w#w-d1t1480-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m048-d1t1480-5">
   <w.rf>
    <LM>w#w-d1t1480-5</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1480-6">
   <w.rf>
    <LM>w#w-d1t1480-6</LM>
   </w.rf>
   <form>lehne</form>
   <lemma>lehnout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m048-d-id102253-punct">
   <w.rf>
    <LM>w#w-d-id102253-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1480-8">
   <w.rf>
    <LM>w#w-d1t1480-8</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1480-9">
   <w.rf>
    <LM>w#w-d1t1480-9</LM>
   </w.rf>
   <form>hladit</form>
   <lemma>hladit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m048-119-121">
   <w.rf>
    <LM>w#w-119-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-122">
  <m id="m048-d1t1484-2">
   <w.rf>
    <LM>w#w-d1t1484-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1484-3">
   <w.rf>
    <LM>w#w-d1t1484-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1484-4">
   <w.rf>
    <LM>w#w-d1t1484-4</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1484-5">
   <w.rf>
    <LM>w#w-d1t1484-5</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-d1t1484-6">
   <w.rf>
    <LM>w#w-d1t1484-6</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-122-123">
   <w.rf>
    <LM>w#w-122-123</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1484-7">
   <w.rf>
    <LM>w#w-d1t1484-7</LM>
   </w.rf>
   <form>miloučký</form>
   <lemma>miloučký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-122-124">
   <w.rf>
    <LM>w#w-122-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-125">
  <m id="m048-d1t1486-1">
   <w.rf>
    <LM>w#w-d1t1486-1</LM>
   </w.rf>
   <form>Přitom</form>
   <lemma>přitom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1489-1">
   <w.rf>
    <LM>w#w-d1t1489-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1489-2">
   <w.rf>
    <LM>w#w-d1t1489-2</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1489-3">
   <w.rf>
    <LM>w#w-d1t1489-3</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m048-d1t1489-4">
   <w.rf>
    <LM>w#w-d1t1489-4</LM>
   </w.rf>
   <form>cizí</form>
   <lemma>cizí</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-125-126">
   <w.rf>
    <LM>w#w-125-126</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1491-1">
   <w.rf>
    <LM>w#w-d1t1491-1</LM>
   </w.rf>
   <form>nastraží</form>
   <lemma>nastražit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m048-d1t1491-2">
   <w.rf>
    <LM>w#w-d1t1491-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1493-1">
   <w.rf>
    <LM>w#w-d1t1493-1</LM>
   </w.rf>
   <form>štěká</form>
   <lemma>štěkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-125-127">
   <w.rf>
    <LM>w#w-125-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-128">
  <m id="m048-d1t1493-3">
   <w.rf>
    <LM>w#w-d1t1493-3</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1493-4">
   <w.rf>
    <LM>w#w-d1t1493-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1493-5">
   <w.rf>
    <LM>w#w-d1t1493-5</LM>
   </w.rf>
   <form>přijdeme</form>
   <lemma>přijít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m048-d1t1493-6">
   <w.rf>
    <LM>w#w-d1t1493-6</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m048-d-id102704-punct">
   <w.rf>
    <LM>w#w-d-id102704-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1493-9">
   <w.rf>
    <LM>w#w-d1t1493-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1493-10">
   <w.rf>
    <LM>w#w-d1t1493-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1493-11">
   <w.rf>
    <LM>w#w-d1t1493-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1493-12">
   <w.rf>
    <LM>w#w-d1t1493-12</LM>
   </w.rf>
   <form>směje</form>
   <lemma>smát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1493-13">
   <w.rf>
    <LM>w#w-d1t1493-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m048-d1t1493-14">
   <w.rf>
    <LM>w#w-d1t1493-14</LM>
   </w.rf>
   <form>dálku</form>
   <lemma>dálka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m048-128-129">
   <w.rf>
    <LM>w#w-128-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1462-x3">
  <m id="m048-d1t1495-2">
   <w.rf>
    <LM>w#w-d1t1495-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1e1462-x3-135">
   <w.rf>
    <LM>w#w-d1e1462-x3-135</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1495-3">
   <w.rf>
    <LM>w#w-d1t1495-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1495-4">
   <w.rf>
    <LM>w#w-d1t1495-4</LM>
   </w.rf>
   <form>přivezla</form>
   <lemma>přivézt</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m048-d1t1497-1">
   <w.rf>
    <LM>w#w-d1t1497-1</LM>
   </w.rf>
   <form>neteř</form>
   <lemma>neteř</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1t1497-5">
   <w.rf>
    <LM>w#w-d1t1497-5</LM>
   </w.rf>
   <form>miminko</form>
   <lemma>miminko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m048-d1t1497-6">
   <w.rf>
    <LM>w#w-d1t1497-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m048-d1t1497-7">
   <w.rf>
    <LM>w#w-d1t1497-7</LM>
   </w.rf>
   <form>porodnice</form>
   <lemma>porodnice_^(*3ík)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m048-d-id102988-punct">
   <w.rf>
    <LM>w#w-d-id102988-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1499-1">
   <w.rf>
    <LM>w#w-d1t1499-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1499-3">
   <w.rf>
    <LM>w#w-d1t1499-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1499-4">
   <w.rf>
    <LM>w#w-d1t1499-4</LM>
   </w.rf>
   <form>máma</form>
   <lemma>máma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1e1462-x3-136">
   <w.rf>
    <LM>w#w-d1e1462-x3-136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1502-1">
   <w.rf>
    <LM>w#w-d1t1502-1</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1502-2">
   <w.rf>
    <LM>w#w-d1t1502-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m048-d1t1502-3">
   <w.rf>
    <LM>w#w-d1t1502-3</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m048-d1t1502-5">
   <w.rf>
    <LM>w#w-d1t1502-5</LM>
   </w.rf>
   <form>běhá</form>
   <lemma>běhat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d-m-d1e1462-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1462-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1505-x2">
  <m id="m048-d1t1510-1">
   <w.rf>
    <LM>w#w-d1t1510-1</LM>
   </w.rf>
   <form>Ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1510-2">
   <w.rf>
    <LM>w#w-d1t1510-2</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1510-3">
   <w.rf>
    <LM>w#w-d1t1510-3</LM>
   </w.rf>
   <form>kojit</form>
   <lemma>kojit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m048-d1t1510-4">
   <w.rf>
    <LM>w#w-d1t1510-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1510-5">
   <w.rf>
    <LM>w#w-d1t1510-5</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m048-d-id103321-punct">
   <w.rf>
    <LM>w#w-d-id103321-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1510-7">
   <w.rf>
    <LM>w#w-d1t1510-7</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d1t1510-8">
   <w.rf>
    <LM>w#w-d1t1510-8</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1510-9">
   <w.rf>
    <LM>w#w-d1t1510-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m048-d1t1510-10">
   <w.rf>
    <LM>w#w-d1t1510-10</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m048-d1e1505-x2-141">
   <w.rf>
    <LM>w#w-d1e1505-x2-141</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-142">
  <m id="m048-d1t1512-2">
   <w.rf>
    <LM>w#w-d1t1512-2</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m048-d1t1512-3">
   <w.rf>
    <LM>w#w-d1t1512-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1512-5">
   <w.rf>
    <LM>w#w-d1t1512-5</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1512-6">
   <w.rf>
    <LM>w#w-d1t1512-6</LM>
   </w.rf>
   <form>žravá</form>
   <lemma>žravý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m048-142-145">
   <w.rf>
    <LM>w#w-142-145</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1512-7">
   <w.rf>
    <LM>w#w-d1t1512-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m048-d1t1512-9">
   <w.rf>
    <LM>w#w-d1t1512-9</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1512-8">
   <w.rf>
    <LM>w#w-d1t1512-8</LM>
   </w.rf>
   <form>chutná</form>
   <lemma>chutnat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d-m-d1e1505-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1505-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1517-x2">
  <m id="m048-d1t1520-3">
   <w.rf>
    <LM>w#w-d1t1520-3</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrIP4----------</tag>
  </m>
  <m id="m048-d1t1520-4">
   <w.rf>
    <LM>w#w-d1t1520-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m048-d1t1520-5">
   <w.rf>
    <LM>w#w-d1t1520-5</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m048-d1t1520-6">
   <w.rf>
    <LM>w#w-d1t1520-6</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1520-7">
   <w.rf>
    <LM>w#w-d1t1520-7</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m048-d1t1520-8">
   <w.rf>
    <LM>w#w-d1t1520-8</LM>
   </w.rf>
   <form>nevzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m048-d-id103748-punct">
   <w.rf>
    <LM>w#w-d-id103748-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1520-10">
   <w.rf>
    <LM>w#w-d1t1520-10</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1520-11">
   <w.rf>
    <LM>w#w-d1t1520-11</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m048-d1t1520-12">
   <w.rf>
    <LM>w#w-d1t1520-12</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m048-d1t1520-13">
   <w.rf>
    <LM>w#w-d1t1520-13</LM>
   </w.rf>
   <form>brácha</form>
   <lemma>brácha</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d1t1520-14">
   <w.rf>
    <LM>w#w-d1t1520-14</LM>
   </w.rf>
   <form>dušené</form>
   <lemma>dušený_^(*4sit)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m048-d1t1520-15">
   <w.rf>
    <LM>w#w-d1t1520-15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1522-1">
   <w.rf>
    <LM>w#w-d1t1522-1</LM>
   </w.rf>
   <form>granule</form>
   <lemma>granule</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m048-d-id103867-punct">
   <w.rf>
    <LM>w#w-d-id103867-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1522-3">
   <w.rf>
    <LM>w#w-d1t1522-3</LM>
   </w.rf>
   <form>kosti</form>
   <lemma>kost</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m048-d1e1517-x2-146">
   <w.rf>
    <LM>w#w-d1e1517-x2-146</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1522-5">
   <w.rf>
    <LM>w#w-d1t1522-5</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1522-4">
   <w.rf>
    <LM>w#w-d1t1522-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m048-d1e1517-x2-673">
   <w.rf>
    <LM>w#w-d1e1517-x2-673</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-676">
  <m id="m048-d1t1522-10">
   <w.rf>
    <LM>w#w-d1t1522-10</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1522-9">
   <w.rf>
    <LM>w#w-d1t1522-9</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1522-6">
   <w.rf>
    <LM>w#w-d1t1522-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m048-d1t1522-7">
   <w.rf>
    <LM>w#w-d1t1522-7</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m048-d1t1522-8">
   <w.rf>
    <LM>w#w-d1t1522-8</LM>
   </w.rf>
   <form>miminem</form>
   <lemma>mimino</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1517-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1517-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1537-x2">
  <m id="m048-d1t1540-3">
   <w.rf>
    <LM>w#w-d1t1540-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1540-2">
   <w.rf>
    <LM>w#w-d1t1540-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1540-4">
   <w.rf>
    <LM>w#w-d1t1540-4</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1540-5">
   <w.rf>
    <LM>w#w-d1t1540-5</LM>
   </w.rf>
   <form>máma</form>
   <lemma>máma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1e1537-x2-41">
   <w.rf>
    <LM>w#w-d1e1537-x2-41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-42">
  <m id="m048-d1t1544-1">
   <w.rf>
    <LM>w#w-d1t1544-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1544-2">
   <w.rf>
    <LM>w#w-d1t1544-2</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m048-d1t1544-3">
   <w.rf>
    <LM>w#w-d1t1544-3</LM>
   </w.rf>
   <form>kočička</form>
   <lemma>kočička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1t1546-1">
   <w.rf>
    <LM>w#w-d1t1546-1</LM>
   </w.rf>
   <form>odložila</form>
   <lemma>odložit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m048-d1t1546-2">
   <w.rf>
    <LM>w#w-d1t1546-2</LM>
   </w.rf>
   <form>koťata</form>
   <lemma>kotě</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m048-d-id104375-punct">
   <w.rf>
    <LM>w#w-d-id104375-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1546-5">
   <w.rf>
    <LM>w#w-d1t1546-5</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m048-d1t1546-6">
   <w.rf>
    <LM>w#w-d1t1546-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1546-7">
   <w.rf>
    <LM>w#w-d1t1546-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m048-d1t1546-8">
   <w.rf>
    <LM>w#w-d1t1546-8</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m048-d1t1546-9">
   <w.rf>
    <LM>w#w-d1t1546-9</LM>
   </w.rf>
   <form>starala</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m048-d-id104463-punct">
   <w.rf>
    <LM>w#w-d-id104463-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1546-13">
   <w.rf>
    <LM>w#w-d1t1546-13</LM>
   </w.rf>
   <form>nosila</form>
   <lemma>nosit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m048-d1t1546-12">
   <w.rf>
    <LM>w#w-d1t1546-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m048-d-m-d1e1537-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1537-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1555-x2">
  <m id="m048-d1t1548-3">
   <w.rf>
    <LM>w#w-d1t1548-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1548-2">
   <w.rf>
    <LM>w#w-d1t1548-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1558-6">
   <w.rf>
    <LM>w#w-d1t1558-6</LM>
   </w.rf>
   <form>fakt</form>
   <lemma>fakt-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1558-3">
   <w.rf>
    <LM>w#w-d1t1558-3</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m048-d1t1558-4">
   <w.rf>
    <LM>w#w-d1t1558-4</LM>
   </w.rf>
   <form>milý</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m048-d1t1558-5">
   <w.rf>
    <LM>w#w-d1t1558-5</LM>
   </w.rf>
   <form>pejsek</form>
   <lemma>pejsek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1555-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1555-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1560-x2">
  <m id="m048-d1t1565-1">
   <w.rf>
    <LM>w#w-d1t1565-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1565-2">
   <w.rf>
    <LM>w#w-d1t1565-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1565-3">
   <w.rf>
    <LM>w#w-d1t1565-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1565-4">
   <w.rf>
    <LM>w#w-d1t1565-4</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1560-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1560-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1560-x3">
  <m id="m048-d1t1567-4">
   <w.rf>
    <LM>w#w-d1t1567-4</LM>
   </w.rf>
   <form>Legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1t1567-3">
   <w.rf>
    <LM>w#w-d1t1567-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1567-2">
   <w.rf>
    <LM>w#w-d1t1567-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d-id104958-punct">
   <w.rf>
    <LM>w#w-d-id104958-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1567-6">
   <w.rf>
    <LM>w#w-d1t1567-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1569-1">
   <w.rf>
    <LM>w#w-d1t1569-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1571-1">
   <w.rf>
    <LM>w#w-d1t1571-1</LM>
   </w.rf>
   <form>fakt</form>
   <lemma>fakt-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1569-2">
   <w.rf>
    <LM>w#w-d1t1569-2</LM>
   </w.rf>
   <form>příjemná</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m048-d-m-d1e1560-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1560-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1575-x3">
  <m id="m048-d1t1584-1">
   <w.rf>
    <LM>w#w-d1t1584-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1584-2">
   <w.rf>
    <LM>w#w-d1t1584-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1584-4">
   <w.rf>
    <LM>w#w-d1t1584-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m048-d1t1584-5">
   <w.rf>
    <LM>w#w-d1t1584-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1584-6">
   <w.rf>
    <LM>w#w-d1t1584-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m048-d1t1584-7">
   <w.rf>
    <LM>w#w-d1t1584-7</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m048-d-id105267-punct">
   <w.rf>
    <LM>w#w-d-id105267-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1585-x2">
  <m id="m048-d1t1592-1">
   <w.rf>
    <LM>w#w-d1t1592-1</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1594-1">
   <w.rf>
    <LM>w#w-d1t1594-1</LM>
   </w.rf>
   <form>zařízení</form>
   <lemma>zařízení_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-d1t1594-2">
   <w.rf>
    <LM>w#w-d1t1594-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1594-3">
   <w.rf>
    <LM>w#w-d1t1594-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1594-4">
   <w.rf>
    <LM>w#w-d1t1594-4</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1e1585-x2-65">
   <w.rf>
    <LM>w#w-d1e1585-x2-65</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-67">
  <m id="m048-d1t1596-1">
   <w.rf>
    <LM>w#w-d1t1596-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1596-2">
   <w.rf>
    <LM>w#w-d1t1596-2</LM>
   </w.rf>
   <form>sezení</form>
   <lemma>sezení_^(*4dět)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-d1t1599-2">
   <w.rf>
    <LM>w#w-d1t1599-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1599-3">
   <w.rf>
    <LM>w#w-d1t1599-3</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m048-d1t1599-4">
   <w.rf>
    <LM>w#w-d1t1599-4</LM>
   </w.rf>
   <form>kout</form>
   <lemma>kout-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m048-d1t1599-5">
   <w.rf>
    <LM>w#w-d1t1599-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m048-d1t1599-6">
   <w.rf>
    <LM>w#w-d1t1599-6</LM>
   </w.rf>
   <form>bývalé</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m048-d1t1599-7">
   <w.rf>
    <LM>w#w-d1t1599-7</LM>
   </w.rf>
   <form>stodoly</form>
   <lemma>stodola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m048-67-68">
   <w.rf>
    <LM>w#w-67-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-69">
  <m id="m048-d1t1603-3">
   <w.rf>
    <LM>w#w-d1t1603-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m048-d1t1603-2">
   <w.rf>
    <LM>w#w-d1t1603-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1603-4">
   <w.rf>
    <LM>w#w-d1t1603-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1603-5">
   <w.rf>
    <LM>w#w-d1t1603-5</LM>
   </w.rf>
   <form>hospodářské</form>
   <lemma>hospodářský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m048-d1t1603-6">
   <w.rf>
    <LM>w#w-d1t1603-6</LM>
   </w.rf>
   <form>stavení</form>
   <lemma>stavení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-d-id105815-punct">
   <w.rf>
    <LM>w#w-d-id105815-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1603-9">
   <w.rf>
    <LM>w#w-d1t1603-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m048-d1t1603-10">
   <w.rf>
    <LM>w#w-d1t1603-10</LM>
   </w.rf>
   <form>zbourali</form>
   <lemma>zbourat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m048-d-id105870-punct">
   <w.rf>
    <LM>w#w-d-id105870-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1603-12">
   <w.rf>
    <LM>w#w-d1t1603-12</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m048-d1t1603-13">
   <w.rf>
    <LM>w#w-d1t1603-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m048-d1t1603-14">
   <w.rf>
    <LM>w#w-d1t1603-14</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1605-9">
   <w.rf>
    <LM>w#w-d1t1605-9</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m048-d1t1605-10">
   <w.rf>
    <LM>w#w-d1t1605-10</LM>
   </w.rf>
   <form>výklenek</form>
   <lemma>výklenek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m048-d-id105940-punct">
   <w.rf>
    <LM>w#w-d-id105940-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1605-1">
   <w.rf>
    <LM>w#w-d1t1605-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1605-2">
   <w.rf>
    <LM>w#w-d1t1605-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1605-3">
   <w.rf>
    <LM>w#w-d1t1605-3</LM>
   </w.rf>
   <form>nefoukal</form>
   <lemma>foukat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m048-d1t1605-4">
   <w.rf>
    <LM>w#w-d1t1605-4</LM>
   </w.rf>
   <form>vítr</form>
   <lemma>vítr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m048-69-70">
   <w.rf>
    <LM>w#w-69-70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-72">
  <m id="m048-d1t1607-4">
   <w.rf>
    <LM>w#w-d1t1607-4</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1607-3">
   <w.rf>
    <LM>w#w-d1t1607-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1609-1">
   <w.rf>
    <LM>w#w-d1t1609-1</LM>
   </w.rf>
   <form>pořádají</form>
   <lemma>pořádat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1609-2">
   <w.rf>
    <LM>w#w-d1t1609-2</LM>
   </w.rf>
   <form>sezení</form>
   <lemma>sezení_^(*4dět)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m048-72-73">
   <w.rf>
    <LM>w#w-72-73</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-84">
  <m id="m048-d1t1609-8">
   <w.rf>
    <LM>w#w-d1t1609-8</LM>
   </w.rf>
   <form>Odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1609-6">
   <w.rf>
    <LM>w#w-d1t1609-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1609-7">
   <w.rf>
    <LM>w#w-d1t1609-7</LM>
   </w.rf>
   <form>podává</form>
   <lemma>podávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1609-9">
   <w.rf>
    <LM>w#w-d1t1609-9</LM>
   </w.rf>
   <form>káva</form>
   <lemma>káva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1585-x3">
  <m id="m048-d1t1609-11">
   <w.rf>
    <LM>w#w-d1t1609-11</LM>
   </w.rf>
   <form>Jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m048-d1t1609-12">
   <w.rf>
    <LM>w#w-d1t1609-12</LM>
   </w.rf>
   <form>uvařím</form>
   <lemma>uvařit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m048-d1t1609-13">
   <w.rf>
    <LM>w#w-d1t1609-13</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m048-d-id106360-punct">
   <w.rf>
    <LM>w#w-d-id106360-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1609-15">
   <w.rf>
    <LM>w#w-d1t1609-15</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m048-d1t1609-16">
   <w.rf>
    <LM>w#w-d1t1609-16</LM>
   </w.rf>
   <form>brácha</form>
   <lemma>brácha</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d-id106400-punct">
   <w.rf>
    <LM>w#w-d-id106400-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1609-18">
   <w.rf>
    <LM>w#w-d1t1609-18</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m048-d1t1609-19">
   <w.rf>
    <LM>w#w-d1t1609-19</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1t1612-2">
   <w.rf>
    <LM>w#w-d1t1612-2</LM>
   </w.rf>
   <form>Kovářová</form>
   <lemma>Kovářová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1e1585-x3-99">
   <w.rf>
    <LM>w#w-d1e1585-x3-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-100">
  <m id="m048-d1t1614-1">
   <w.rf>
    <LM>w#w-d1t1614-1</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1614-3">
   <w.rf>
    <LM>w#w-d1t1614-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1614-4">
   <w.rf>
    <LM>w#w-d1t1614-4</LM>
   </w.rf>
   <form>střídáme</form>
   <lemma>střídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d-id106546-punct">
   <w.rf>
    <LM>w#w-d-id106546-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1614-9">
   <w.rf>
    <LM>w#w-d1t1614-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1614-7">
   <w.rf>
    <LM>w#w-d1t1614-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1614-8">
   <w.rf>
    <LM>w#w-d1t1614-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1614-10">
   <w.rf>
    <LM>w#w-d1t1614-10</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1614-11">
   <w.rf>
    <LM>w#w-d1t1614-11</LM>
   </w.rf>
   <form>zvyklí</form>
   <lemma>zvyklý_^(*2nout)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m048-100-101">
   <w.rf>
    <LM>w#w-100-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-102">
  <m id="m048-d1t1614-13">
   <w.rf>
    <LM>w#w-d1t1614-13</LM>
   </w.rf>
   <form>Každé</form>
   <lemma>každý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m048-d1t1614-14">
   <w.rf>
    <LM>w#w-d1t1614-14</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-2</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m048-d1t1614-18">
   <w.rf>
    <LM>w#w-d1t1614-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1614-15">
   <w.rf>
    <LM>w#w-d1t1614-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1614-16">
   <w.rf>
    <LM>w#w-d1t1614-16</LM>
   </w.rf>
   <form>jednom</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS6----------</tag>
  </m>
  <m id="m048-d1t1614-17">
   <w.rf>
    <LM>w#w-d1t1614-17</LM>
   </w.rf>
   <form>dvoře</form>
   <lemma>dvůr_^(u_domu)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m048-d1t1614-19">
   <w.rf>
    <LM>w#w-d1t1614-19</LM>
   </w.rf>
   <form>pije</form>
   <lemma>pít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1614-20">
   <w.rf>
    <LM>w#w-d1t1614-20</LM>
   </w.rf>
   <form>káva</form>
   <lemma>káva</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-102-103">
   <w.rf>
    <LM>w#w-102-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-104">
  <m id="m048-d1t1614-22">
   <w.rf>
    <LM>w#w-d1t1614-22</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m048-d1t1614-23">
   <w.rf>
    <LM>w#w-d1t1614-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m048-d1t1614-24">
   <w.rf>
    <LM>w#w-d1t1614-24</LM>
   </w.rf>
   <form>přinesu</form>
   <lemma>přinést</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m048-d1t1614-25">
   <w.rf>
    <LM>w#w-d1t1614-25</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1614-26">
   <w.rf>
    <LM>w#w-d1t1614-26</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m048-d1t1614-27">
   <w.rf>
    <LM>w#w-d1t1614-27</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m048-d-id106862-punct">
   <w.rf>
    <LM>w#w-d-id106862-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1614-29">
   <w.rf>
    <LM>w#w-d1t1614-29</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1614-30">
   <w.rf>
    <LM>w#w-d1t1614-30</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1614-31">
   <w.rf>
    <LM>w#w-d1t1614-31</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1614-32">
   <w.rf>
    <LM>w#w-d1t1614-32</LM>
   </w.rf>
   <form>lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m048-d1t1614-33">
   <w.rf>
    <LM>w#w-d1t1614-33</LM>
   </w.rf>
   <form>sedí</form>
   <lemma>sedět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-104-105">
   <w.rf>
    <LM>w#w-104-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-106">
  <m id="m048-d1t1618-1">
   <w.rf>
    <LM>w#w-d1t1618-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m048-d1t1618-2">
   <w.rf>
    <LM>w#w-d1t1618-2</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m048-d1t1618-3">
   <w.rf>
    <LM>w#w-d1t1618-3</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m048-106-107">
   <w.rf>
    <LM>w#w-106-107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1620-1">
   <w.rf>
    <LM>w#w-d1t1620-1</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1620-2">
   <w.rf>
    <LM>w#w-d1t1620-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1620-3">
   <w.rf>
    <LM>w#w-d1t1620-3</LM>
   </w.rf>
   <form>dvorek</form>
   <lemma>dvorek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m048-d-id107101-punct">
   <w.rf>
    <LM>w#w-d-id107101-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1620-5">
   <w.rf>
    <LM>w#w-d1t1620-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1620-7">
   <w.rf>
    <LM>w#w-d1t1620-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m048-d1t1620-6">
   <w.rf>
    <LM>w#w-d1t1620-6</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1620-8">
   <w.rf>
    <LM>w#w-d1t1620-8</LM>
   </w.rf>
   <form>nosím</form>
   <lemma>nosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1620-9">
   <w.rf>
    <LM>w#w-d1t1620-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m048-d1t1620-10">
   <w.rf>
    <LM>w#w-d1t1620-10</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m048-d1t1620-11">
   <w.rf>
    <LM>w#w-d1t1620-11</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m048-d1t1620-12">
   <w.rf>
    <LM>w#w-d1t1620-12</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m048-d1t1620-13">
   <w.rf>
    <LM>w#w-d1t1620-13</LM>
   </w.rf>
   <form>bráchovi</form>
   <lemma>brácha</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m048-106-110">
   <w.rf>
    <LM>w#w-106-110</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1626-1">
   <w.rf>
    <LM>w#w-d1t1626-1</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m048-d1t1626-2">
   <w.rf>
    <LM>w#w-d1t1626-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1626-3">
   <w.rf>
    <LM>w#w-d1t1626-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1626-4">
   <w.rf>
    <LM>w#w-d1t1626-4</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m048-d1t1626-5">
   <w.rf>
    <LM>w#w-d1t1626-5</LM>
   </w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1585-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1585-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1631-x2">
  <m id="m048-d1t1634-2">
   <w.rf>
    <LM>w#w-d1t1634-2</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1634-4">
   <w.rf>
    <LM>w#w-d1t1634-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1634-6">
   <w.rf>
    <LM>w#w-d1t1634-6</LM>
   </w.rf>
   <form>střídáme</form>
   <lemma>střídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d-m-d1e1631-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1631-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1637-x3">
  <m id="m048-d1t1648-1">
   <w.rf>
    <LM>w#w-d1t1648-1</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m048-d1t1648-3">
   <w.rf>
    <LM>w#w-d1t1648-3</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1648-4">
   <w.rf>
    <LM>w#w-d1t1648-4</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m048-d1t1648-5">
   <w.rf>
    <LM>w#w-d1t1648-5</LM>
   </w.rf>
   <form>zahradu</form>
   <lemma>zahrada</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m048-d-id107727-punct">
   <w.rf>
    <LM>w#w-d-id107727-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1649-x2">
  <m id="m048-d1t1652-1">
   <w.rf>
    <LM>w#w-d1t1652-1</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m048-d1t1652-2">
   <w.rf>
    <LM>w#w-d1t1652-2</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1652-5">
   <w.rf>
    <LM>w#w-d1t1652-5</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m048-d1t1652-6">
   <w.rf>
    <LM>w#w-d1t1652-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m048-d1t1652-3">
   <w.rf>
    <LM>w#w-d1t1652-3</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m048-d1e1649-x2-121">
   <w.rf>
    <LM>w#w-d1e1649-x2-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-123">
  <m id="m048-d1t1654-2">
   <w.rf>
    <LM>w#w-d1t1654-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1654-1">
   <w.rf>
    <LM>w#w-d1t1654-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1654-5">
   <w.rf>
    <LM>w#w-d1t1654-5</LM>
   </w.rf>
   <form>dlouhý</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m048-d1t1654-6">
   <w.rf>
    <LM>w#w-d1t1654-6</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m048-123-124">
   <w.rf>
    <LM>w#w-123-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-126">
  <m id="m048-d1t1656-3">
   <w.rf>
    <LM>w#w-d1t1656-3</LM>
   </w.rf>
   <form>Stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m048-d-id108031-punct">
   <w.rf>
    <LM>w#w-d-id108031-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1656-5">
   <w.rf>
    <LM>w#w-d1t1656-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m048-d1t1656-6">
   <w.rf>
    <LM>w#w-d1t1656-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1656-7">
   <w.rf>
    <LM>w#w-d1t1656-7</LM>
   </w.rf>
   <form>vysázeli</form>
   <lemma>vysázet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m048-d1t1658-6">
   <w.rf>
    <LM>w#w-d1t1658-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1658-7">
   <w.rf>
    <LM>w#w-d1t1658-7</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m048-d1t1658-8">
   <w.rf>
    <LM>w#w-d1t1658-8</LM>
   </w.rf>
   <form>1975</form>
   <lemma>1975</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m048-d-id108198-punct">
   <w.rf>
    <LM>w#w-d-id108198-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1658-10">
   <w.rf>
    <LM>w#w-d1t1658-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-129-140">
   <w.rf>
    <LM>w#w-129-140</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m048-d1t1658-11">
   <w.rf>
    <LM>w#w-d1t1658-11</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m048-126-127">
   <w.rf>
    <LM>w#w-126-127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1660-4">
   <w.rf>
    <LM>w#w-d1t1660-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1660-3">
   <w.rf>
    <LM>w#w-d1t1660-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1660-2">
   <w.rf>
    <LM>w#w-d1t1660-2</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1660-5">
   <w.rf>
    <LM>w#w-d1t1660-5</LM>
   </w.rf>
   <form>několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m048-d1t1660-6">
   <w.rf>
    <LM>w#w-d1t1660-6</LM>
   </w.rf>
   <form>zkrácené</form>
   <lemma>zkrácený_^(*4tit)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m048-126-128">
   <w.rf>
    <LM>w#w-126-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-143">
  <m id="m048-d1t1660-8">
   <w.rf>
    <LM>w#w-d1t1660-8</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1660-9">
   <w.rf>
    <LM>w#w-d1t1660-9</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d-id108361-punct">
   <w.rf>
    <LM>w#w-d-id108361-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1660-11">
   <w.rf>
    <LM>w#w-d1t1660-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1660-12">
   <w.rf>
    <LM>w#w-d1t1660-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1660-13">
   <w.rf>
    <LM>w#w-d1t1660-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1660-17">
   <w.rf>
    <LM>w#w-d1t1660-17</LM>
   </w.rf>
   <form>dopoledne</form>
   <lemma>dopoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1660-14">
   <w.rf>
    <LM>w#w-d1t1660-14</LM>
   </w.rf>
   <form>seděli</form>
   <lemma>sedět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m048-d1t1660-15">
   <w.rf>
    <LM>w#w-d1t1660-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1660-16">
   <w.rf>
    <LM>w#w-d1t1660-16</LM>
   </w.rf>
   <form>kávě</form>
   <lemma>káva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m048-d-id108471-punct">
   <w.rf>
    <LM>w#w-d-id108471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1660-20">
   <w.rf>
    <LM>w#w-d1t1660-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m048-d1t1660-21">
   <w.rf>
    <LM>w#w-d1t1660-21</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m048-d-id108520-punct">
   <w.rf>
    <LM>w#w-d-id108520-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1660-23">
   <w.rf>
    <LM>w#w-d1t1660-23</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1660-24">
   <w.rf>
    <LM>w#w-d1t1660-24</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1660-25">
   <w.rf>
    <LM>w#w-d1t1660-25</LM>
   </w.rf>
   <form>poporostlo</form>
   <lemma>poporůst</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m048-143-144">
   <w.rf>
    <LM>w#w-143-144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-145">
  <m id="m048-d1t1667-3">
   <w.rf>
    <LM>w#w-d1t1667-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1667-4">
   <w.rf>
    <LM>w#w-d1t1667-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1667-5">
   <w.rf>
    <LM>w#w-d1t1667-5</LM>
   </w.rf>
   <form>jaře</form>
   <lemma>jaro</lemma>
   <tag>NNNS6-----A---1</tag>
  </m>
  <m id="m048-d1t1665-1">
   <w.rf>
    <LM>w#w-d1t1665-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1665-2">
   <w.rf>
    <LM>w#w-d1t1665-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1665-3">
   <w.rf>
    <LM>w#w-d1t1665-3</LM>
   </w.rf>
   <form>nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-145-146">
   <w.rf>
    <LM>w#w-145-146</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1667-1">
   <w.rf>
    <LM>w#w-d1t1667-1</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m048-d1t1671-2">
   <w.rf>
    <LM>w#w-d1t1671-2</LM>
   </w.rf>
   <form>bráchova</form>
   <lemma>bráchův_^(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m048-d1t1667-2">
   <w.rf>
    <LM>w#w-d1t1667-2</LM>
   </w.rf>
   <form>zeleň</form>
   <lemma>zeleň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-145-159">
   <w.rf>
    <LM>w#w-145-159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1649-x3">
  <m id="m048-d1t1671-6">
   <w.rf>
    <LM>w#w-d1t1671-6</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1671-5">
   <w.rf>
    <LM>w#w-d1t1671-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1671-7">
   <w.rf>
    <LM>w#w-d1t1671-7</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1671-8">
   <w.rf>
    <LM>w#w-d1t1671-8</LM>
   </w.rf>
   <form>ovocné</form>
   <lemma>ovocný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m048-d1e1649-x3-160">
   <w.rf>
    <LM>w#w-d1e1649-x3-160</LM>
   </w.rf>
   <form>stromy</form>
   <lemma>strom</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m048-d-id108916-punct">
   <w.rf>
    <LM>w#w-d-id108916-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1673-1">
   <w.rf>
    <LM>w#w-d1t1673-1</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m048-d1t1673-3">
   <w.rf>
    <LM>w#w-d1t1673-3</LM>
   </w.rf>
   <form>Pražáci</form>
   <lemma>Pražák_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m048-d1t1673-7">
   <w.rf>
    <LM>w#w-d1t1673-7</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1673-8">
   <w.rf>
    <LM>w#w-d1t1673-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1673-9">
   <w.rf>
    <LM>w#w-d1t1673-9</LM>
   </w.rf>
   <form>okrasné</form>
   <lemma>okrasný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m048-d1e1649-x3-157">
   <w.rf>
    <LM>w#w-d1e1649-x3-157</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-158">
  <m id="m048-d1t1676-1">
   <w.rf>
    <LM>w#w-d1t1676-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m048-d1t1676-2">
   <w.rf>
    <LM>w#w-d1t1676-2</LM>
   </w.rf>
   <form>bráchy</form>
   <lemma>brácha</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m048-d1t1676-3">
   <w.rf>
    <LM>w#w-d1t1676-3</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m048-d1t1676-5">
   <w.rf>
    <LM>w#w-d1t1676-5</LM>
   </w.rf>
   <form>jabloně</form>
   <lemma>jabloň</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m048-d1t1676-6">
   <w.rf>
    <LM>w#w-d1t1676-6</LM>
   </w.rf>
   <form>kvetou</form>
   <lemma>kvést</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d1e1649-x3-156">
   <w.rf>
    <LM>w#w-d1e1649-x3-156</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1678-2">
   <w.rf>
    <LM>w#w-d1t1678-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1678-1">
   <w.rf>
    <LM>w#w-d1t1678-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1678-3">
   <w.rf>
    <LM>w#w-d1t1678-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1678-4">
   <w.rf>
    <LM>w#w-d1t1678-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1678-5">
   <w.rf>
    <LM>w#w-d1t1678-5</LM>
   </w.rf>
   <form>pohádce</form>
   <lemma>pohádka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m048-158-164">
   <w.rf>
    <LM>w#w-158-164</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1684-1">
   <w.rf>
    <LM>w#w-d1t1684-1</LM>
   </w.rf>
   <form>nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1649-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1649-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1679-x2">
  <m id="m048-d1t1684-2">
   <w.rf>
    <LM>w#w-d1t1684-2</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1684-3">
   <w.rf>
    <LM>w#w-d1t1684-3</LM>
   </w.rf>
   <form>včeličky</form>
   <lemma>včelička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m048-d1t1684-4">
   <w.rf>
    <LM>w#w-d1t1684-4</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1684-5">
   <w.rf>
    <LM>w#w-d1t1684-5</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m048-d-id109412-punct">
   <w.rf>
    <LM>w#w-d-id109412-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1684-7">
   <w.rf>
    <LM>w#w-d1t1684-7</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1684-8">
   <w.rf>
    <LM>w#w-d1t1684-8</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m048-d1t1684-9">
   <w.rf>
    <LM>w#w-d1t1684-9</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1684-10">
   <w.rf>
    <LM>w#w-d1t1684-10</LM>
   </w.rf>
   <form>přišly</form>
   <lemma>přijít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m048-d1t1684-11">
   <w.rf>
    <LM>w#w-d1t1684-11</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d-m-d1e1679-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1679-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1689-x2">
  <m id="m048-d1t1692-2">
   <w.rf>
    <LM>w#w-d1t1692-2</LM>
   </w.rf>
   <form>Sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1692-3">
   <w.rf>
    <LM>w#w-d1t1692-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1692-4">
   <w.rf>
    <LM>w#w-d1t1692-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m048-d1t1692-5">
   <w.rf>
    <LM>w#w-d1t1692-5</LM>
   </w.rf>
   <form>čmelák</form>
   <lemma>čmelák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m048-d-id109633-punct">
   <w.rf>
    <LM>w#w-d-id109633-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1692-7">
   <w.rf>
    <LM>w#w-d1t1692-7</LM>
   </w.rf>
   <form>vosa</form>
   <lemma>vosa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m048-d1e1689-x2-169">
   <w.rf>
    <LM>w#w-d1e1689-x2-169</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-170">
  <m id="m048-d1t1692-9">
   <w.rf>
    <LM>w#w-d1t1692-9</LM>
   </w.rf>
   <form>Včeličky</form>
   <lemma>včelička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m048-d1t1692-11">
   <w.rf>
    <LM>w#w-d1t1692-11</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m048-170-171">
   <w.rf>
    <LM>w#w-170-171</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1692-12">
   <w.rf>
    <LM>w#w-d1t1692-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1692-13">
   <w.rf>
    <LM>w#w-d1t1692-13</LM>
   </w.rf>
   <form>bzučení</form>
   <lemma>bzučení_^(*2t)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-170-172">
   <w.rf>
    <LM>w#w-170-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-173">
  <m id="m048-d1t1696-2">
   <w.rf>
    <LM>w#w-d1t1696-2</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1696-3">
   <w.rf>
    <LM>w#w-d1t1696-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m048-d1t1696-4">
   <w.rf>
    <LM>w#w-d1t1696-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1696-5">
   <w.rf>
    <LM>w#w-d1t1696-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m048-d1t1696-6">
   <w.rf>
    <LM>w#w-d1t1696-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m048-d1t1696-7">
   <w.rf>
    <LM>w#w-d1t1696-7</LM>
   </w.rf>
   <form>pohádce</form>
   <lemma>pohádka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m048-173-174">
   <w.rf>
    <LM>w#w-173-174</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1698-3">
   <w.rf>
    <LM>w#w-d1t1698-3</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m048-d1t1698-4">
   <w.rf>
    <LM>w#w-d1t1698-4</LM>
   </w.rf>
   <form>rozkvetlé</form>
   <lemma>rozkvetlý_^(*4ést)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m048-d-id109927-punct">
   <w.rf>
    <LM>w#w-d-id109927-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m048-d1t1698-6">
   <w.rf>
    <LM>w#w-d1t1698-6</LM>
   </w.rf>
   <form>fakt</form>
   <lemma>fakt-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1698-7">
   <w.rf>
    <LM>w#w-d1t1698-7</LM>
   </w.rf>
   <form>nádherné</form>
   <lemma>nádherný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m048-d1t1698-8">
   <w.rf>
    <LM>w#w-d1t1698-8</LM>
   </w.rf>
   <form>posezení</form>
   <lemma>posezení_^(*4dět)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m048-d-m-d1e1689-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1689-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1699-x2">
  <m id="m048-d1t1708-1">
   <w.rf>
    <LM>w#w-d1t1708-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m048-d1t1708-2">
   <w.rf>
    <LM>w#w-d1t1708-2</LM>
   </w.rf>
   <form>věřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m048-d-m-d1e1699-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1699-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-176">
  <m id="m048-d1t1706-2">
   <w.rf>
    <LM>w#w-d1t1706-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m048-d1t1706-6">
   <w.rf>
    <LM>w#w-d1t1706-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m048-d1t1706-7">
   <w.rf>
    <LM>w#w-d1t1706-7</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m048-d1t1706-3">
   <w.rf>
    <LM>w#w-d1t1706-3</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m048-d1t1706-4">
   <w.rf>
    <LM>w#w-d1t1706-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m048-d1t1706-5">
   <w.rf>
    <LM>w#w-d1t1706-5</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m048-d-m-d1e1699-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1699-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m048-d1e1716-x2">
  <m id="m048-d1t1719-1">
   <w.rf>
    <LM>w#w-d1t1719-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m048-d1t1719-2">
   <w.rf>
    <LM>w#w-d1t1719-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m048-d1t1719-3">
   <w.rf>
    <LM>w#w-d1t1719-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m048-d1t1719-4">
   <w.rf>
    <LM>w#w-d1t1719-4</LM>
   </w.rf>
   <form>pěstují</form>
   <lemma>pěstovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m048-d-id110346-punct">
   <w.rf>
    <LM>w#w-d-id110346-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
