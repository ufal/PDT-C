<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_915.00.w.gz" />
  </references>
 </head>
 <s id="m915-12941_05-d1e8-x2">
  <m id="m915-d1e8-x2-17">
   <w.rf>
    <LM>w#w-d1e8-x2-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1e8-x2-18">
   <w.rf>
    <LM>w#w-d1e8-x2-18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1e8-x2-19">
   <w.rf>
    <LM>w#w-d1e8-x2-19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1e8-x2-16">
   <w.rf>
    <LM>w#w-d1e8-x2-16</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t17-1">
   <w.rf>
    <LM>w#w-d1t17-1</LM>
   </w.rf>
   <form>Jiřím</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m915-d1t17-2">
   <w.rf>
    <LM>w#w-d1t17-2</LM>
   </w.rf>
   <form>Boehmem</form>
   <lemma>Boehm_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m915-d-id54964">
   <w.rf>
    <LM>w#w-d-id54964</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e8-x3">
  <m id="m915-d1t19-2">
   <w.rf>
    <LM>w#w-d1t19-2</LM>
   </w.rf>
   <form>Skončili</form>
   <lemma>skončit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t19-3">
   <w.rf>
    <LM>w#w-d1t19-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t19-4">
   <w.rf>
    <LM>w#w-d1t19-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t19-5">
   <w.rf>
    <LM>w#w-d1t19-5</LM>
   </w.rf>
   <form>vašeho</form>
   <lemma>váš</lemma>
   <tag>PSZS2-P2-------</tag>
  </m>
  <m id="m915-d1t19-6">
   <w.rf>
    <LM>w#w-d1t19-6</LM>
   </w.rf>
   <form>návratu</form>
   <lemma>návrat</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t19-7">
   <w.rf>
    <LM>w#w-d1t19-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t19-8">
   <w.rf>
    <LM>w#w-d1t19-8</LM>
   </w.rf>
   <form>původního</form>
   <lemma>původní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m915-d1t19-9">
   <w.rf>
    <LM>w#w-d1t19-9</LM>
   </w.rf>
   <form>bydliště</form>
   <lemma>bydliště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m915-d-id55097">
   <w.rf>
    <LM>w#w-d-id55097</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t22-1">
   <w.rf>
    <LM>w#w-d1t22-1</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m915-d1t22-2">
   <w.rf>
    <LM>w#w-d1t22-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t22-3">
   <w.rf>
    <LM>w#w-d1t22-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m915-d1t22-4">
   <w.rf>
    <LM>w#w-d1t22-4</LM>
   </w.rf>
   <form>dodat</form>
   <lemma>dodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m915-d-id55151">
   <w.rf>
    <LM>w#w-d-id55151</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e25-x2">
  <m id="m915-d1t30-1">
   <w.rf>
    <LM>w#w-d1t30-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d-id55245">
   <w.rf>
    <LM>w#w-d-id55245</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t32-1">
   <w.rf>
    <LM>w#w-d1t32-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t32-2">
   <w.rf>
    <LM>w#w-d1t32-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1e25-x2-126">
   <w.rf>
    <LM>w#w-d1e25-x2-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-127">
  <m id="m915-d1t34-1">
   <w.rf>
    <LM>w#w-d1t34-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t34-2">
   <w.rf>
    <LM>w#w-d1t34-2</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t32-5">
   <w.rf>
    <LM>w#w-d1t32-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t34-3">
   <w.rf>
    <LM>w#w-d1t34-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t32-6">
   <w.rf>
    <LM>w#w-d1t32-6</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t34-4">
   <w.rf>
    <LM>w#w-d1t34-4</LM>
   </w.rf>
   <form>hledal</form>
   <lemma>hledat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t36-1">
   <w.rf>
    <LM>w#w-d1t36-1</LM>
   </w.rf>
   <form>náhradní</form>
   <lemma>náhradní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m915-d1t36-2">
   <w.rf>
    <LM>w#w-d1t36-2</LM>
   </w.rf>
   <form>ubytování</form>
   <lemma>ubytování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d-id55456">
   <w.rf>
    <LM>w#w-d-id55456</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t39-1">
   <w.rf>
    <LM>w#w-d1t39-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t43-1">
   <w.rf>
    <LM>w#w-d1t43-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t43-2">
   <w.rf>
    <LM>w#w-d1t43-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t43-3">
   <w.rf>
    <LM>w#w-d1t43-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t43-4">
   <w.rf>
    <LM>w#w-d1t43-4</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t43-5">
   <w.rf>
    <LM>w#w-d1t43-5</LM>
   </w.rf>
   <form>zmínil</form>
   <lemma>zmínit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d-id55573">
   <w.rf>
    <LM>w#w-d-id55573</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t43-9">
   <w.rf>
    <LM>w#w-d1t43-9</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m915-d1t43-10">
   <w.rf>
    <LM>w#w-d1t43-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t43-14">
   <w.rf>
    <LM>w#w-d1t43-14</LM>
   </w.rf>
   <form>odvahu</form>
   <lemma>odvaha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d1t43-16">
   <w.rf>
    <LM>w#w-d1t43-16</LM>
   </w.rf>
   <form>intenzivněji</form>
   <lemma>intenzivně_^(^DD**intenzívně)_(*1í)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m915-d1t43-15">
   <w.rf>
    <LM>w#w-d1t43-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t43-17">
   <w.rf>
    <LM>w#w-d1t43-17</LM>
   </w.rf>
   <form>ucházet</form>
   <lemma>ucházet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m915-d1t43-18">
   <w.rf>
    <LM>w#w-d1t43-18</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t43-19">
   <w.rf>
    <LM>w#w-d1t43-19</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t45-1">
   <w.rf>
    <LM>w#w-d1t45-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t45-2">
   <w.rf>
    <LM>w#w-d1t45-2</LM>
   </w.rf>
   <form>rodičích</form>
   <lemma>rodič</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m915-d-id55810">
   <w.rf>
    <LM>w#w-d-id55810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e25-x3">
  <m id="m915-d1t49-2">
   <w.rf>
    <LM>w#w-d1t49-2</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m915-d1t49-3">
   <w.rf>
    <LM>w#w-d1t49-3</LM>
   </w.rf>
   <form>řešení</form>
   <lemma>řešení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m915-d1t49-4">
   <w.rf>
    <LM>w#w-d1t49-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t52-1">
   <w.rf>
    <LM>w#w-d1t52-1</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t52-2">
   <w.rf>
    <LM>w#w-d1t52-2</LM>
   </w.rf>
   <form>lopotné</form>
   <lemma>lopotný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d1t52-5">
   <w.rf>
    <LM>w#w-d1t52-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t52-6">
   <w.rf>
    <LM>w#w-d1t52-6</LM>
   </w.rf>
   <form>obtížné</form>
   <lemma>obtížný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d-id56001">
   <w.rf>
    <LM>w#w-d-id56001</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t52-8">
   <w.rf>
    <LM>w#w-d1t52-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t52-9">
   <w.rf>
    <LM>w#w-d1t52-9</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t52-10">
   <w.rf>
    <LM>w#w-d1t52-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t54-1">
   <w.rf>
    <LM>w#w-d1t54-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t54-2">
   <w.rf>
    <LM>w#w-d1t54-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t54-3">
   <w.rf>
    <LM>w#w-d1t54-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t54-4">
   <w.rf>
    <LM>w#w-d1t54-4</LM>
   </w.rf>
   <form>nevrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m915-d-id56127">
   <w.rf>
    <LM>w#w-d-id56127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e55-x2">
  <m id="m915-d1t60-1">
   <w.rf>
    <LM>w#w-d1t60-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1e55-x2-1810">
   <w.rf>
    <LM>w#w-d1e55-x2-1810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1811">
  <m id="m915-d1t60-3">
   <w.rf>
    <LM>w#w-d1t60-3</LM>
   </w.rf>
   <form>Vraťme</form>
   <lemma>vrátit</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m915-d1t60-4">
   <w.rf>
    <LM>w#w-d1t60-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t66-1">
   <w.rf>
    <LM>w#w-d1t66-1</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m915-d1t66-2">
   <w.rf>
    <LM>w#w-d1t66-2</LM>
   </w.rf>
   <form>chvíli</form>
   <lemma>chvíle</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m915-d-id56297">
   <w.rf>
    <LM>w#w-d-id56297</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t66-4">
   <w.rf>
    <LM>w#w-d1t66-4</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t66-5">
   <w.rf>
    <LM>w#w-d1t66-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m915-d1t66-6">
   <w.rf>
    <LM>w#w-d1t66-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t69-1">
   <w.rf>
    <LM>w#w-d1t69-1</LM>
   </w.rf>
   <form>chystal</form>
   <lemma>chystat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t71-1">
   <w.rf>
    <LM>w#w-d1t71-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t71-2">
   <w.rf>
    <LM>w#w-d1t71-2</LM>
   </w.rf>
   <form>odchod</form>
   <lemma>odchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t71-3">
   <w.rf>
    <LM>w#w-d1t71-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t71-4">
   <w.rf>
    <LM>w#w-d1t71-4</LM>
   </w.rf>
   <form>Anglie</form>
   <lemma>Anglie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id56429">
   <w.rf>
    <LM>w#w-d-id56429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e72-x2">
  <m id="m915-d1t79-1">
   <w.rf>
    <LM>w#w-d1t79-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t79-2">
   <w.rf>
    <LM>w#w-d1t79-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t79-3">
   <w.rf>
    <LM>w#w-d1t79-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t81-1">
   <w.rf>
    <LM>w#w-d1t81-1</LM>
   </w.rf>
   <form>zmínil</form>
   <lemma>zmínit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d-id56575">
   <w.rf>
    <LM>w#w-d-id56575</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t81-4">
   <w.rf>
    <LM>w#w-d1t81-4</LM>
   </w.rf>
   <form>jednotka</form>
   <lemma>jednotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d1t81-5">
   <w.rf>
    <LM>w#w-d1t81-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m915-d1t81-6">
   <w.rf>
    <LM>w#w-d1t81-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t81-7">
   <w.rf>
    <LM>w#w-d1t81-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t81-8">
   <w.rf>
    <LM>w#w-d1t81-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m915-d1t83-1">
   <w.rf>
    <LM>w#w-d1t83-1</LM>
   </w.rf>
   <form>nejtajnější</form>
   <lemma>tajný-1</lemma>
   <tag>AAFS6----3A----</tag>
  </m>
  <m id="m915-d1t83-2">
   <w.rf>
    <LM>w#w-d1t83-2</LM>
   </w.rf>
   <form>soustřeďovací</form>
   <lemma>soustřeďovací_^(*2t)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m915-d1t86-2">
   <w.rf>
    <LM>w#w-d1t86-2</LM>
   </w.rf>
   <form>vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m915-d1t86-1">
   <w.rf>
    <LM>w#w-d1t86-1</LM>
   </w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t88-1">
   <w.rf>
    <LM>w#w-d1t88-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t90-1">
   <w.rf>
    <LM>w#w-d1t90-1</LM>
   </w.rf>
   <form>odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t90-2">
   <w.rf>
    <LM>w#w-d1t90-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t90-3">
   <w.rf>
    <LM>w#w-d1t90-3</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t90-4">
   <w.rf>
    <LM>w#w-d1t90-4</LM>
   </w.rf>
   <form>směřovali</form>
   <lemma>směřovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t90-5">
   <w.rf>
    <LM>w#w-d1t90-5</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t90-6">
   <w.rf>
    <LM>w#w-d1t90-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t90-7">
   <w.rf>
    <LM>w#w-d1t90-7</LM>
   </w.rf>
   <form>pevninu</form>
   <lemma>pevnina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d1e72-x2-276">
   <w.rf>
    <LM>w#w-d1e72-x2-276</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t90-8">
   <w.rf>
    <LM>w#w-d1t90-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t90-9">
   <w.rf>
    <LM>w#w-d1t90-9</LM>
   </w.rf>
   <form>Normandie</form>
   <lemma>Normandie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id56932">
   <w.rf>
    <LM>w#w-d-id56932</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e72-x3">
  <m id="m915-d1t99-1">
   <w.rf>
    <LM>w#w-d1t99-1</LM>
   </w.rf>
   <form>Přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t99-2">
   <w.rf>
    <LM>w#w-d1t99-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t99-3">
   <w.rf>
    <LM>w#w-d1t99-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t99-4">
   <w.rf>
    <LM>w#w-d1t99-4</LM>
   </w.rf>
   <form>Normandie</form>
   <lemma>Normandie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t105-1">
   <w.rf>
    <LM>w#w-d1t105-1</LM>
   </w.rf>
   <form>necelé</form>
   <lemma>celý</lemma>
   <tag>AAIP4----1N----</tag>
  </m>
  <m id="m915-d1t105-2">
   <w.rf>
    <LM>w#w-d1t105-2</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m915-d1t105-3">
   <w.rf>
    <LM>w#w-d1t105-3</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m915-d1t107-1">
   <w.rf>
    <LM>w#w-d1t107-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t107-2">
   <w.rf>
    <LM>w#w-d1t107-2</LM>
   </w.rf>
   <form>invazi</form>
   <lemma>invaze</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1e72-x3-413">
   <w.rf>
    <LM>w#w-d1e72-x3-413</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t114-1">
   <w.rf>
    <LM>w#w-d1t114-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t114-2">
   <w.rf>
    <LM>w#w-d1t114-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t114-3">
   <w.rf>
    <LM>w#w-d1t114-3</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d-id57213">
   <w.rf>
    <LM>w#w-d-id57213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e72-x4">
  <m id="m915-d1t116-1">
   <w.rf>
    <LM>w#w-d1t116-1</LM>
   </w.rf>
   <form>Přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t116-2">
   <w.rf>
    <LM>w#w-d1t116-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t116-3">
   <w.rf>
    <LM>w#w-d1t116-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t116-4">
   <w.rf>
    <LM>w#w-d1t116-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t116-5">
   <w.rf>
    <LM>w#w-d1t116-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t116-6">
   <w.rf>
    <LM>w#w-d1t116-6</LM>
   </w.rf>
   <form>zrání</form>
   <lemma>zrání_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m915-d1t116-7">
   <w.rf>
    <LM>w#w-d1t116-7</LM>
   </w.rf>
   <form>jablek</form>
   <lemma>jablko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m915-d1e72-x4-423">
   <w.rf>
    <LM>w#w-d1e72-x4-423</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1e72-x4-424">
   <w.rf>
    <LM>w#w-d1e72-x4-424</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NP1---------6</tag>
  </m>
  <m id="m915-d1e72-x4-425">
   <w.rf>
    <LM>w#w-d1e72-x4-425</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d1t120-1">
   <w.rf>
    <LM>w#w-d1t120-1</LM>
   </w.rf>
   <form>původně</form>
   <lemma>původně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t120-2">
   <w.rf>
    <LM>w#w-d1t120-2</LM>
   </w.rf>
   <form>určeny</form>
   <lemma>určit</lemma>
   <tag>VsTP----X-APP--</tag>
  </m>
  <m id="m915-d1t120-3">
   <w.rf>
    <LM>w#w-d1t120-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t122-1">
   <w.rf>
    <LM>w#w-d1t122-1</LM>
   </w.rf>
   <form>výrobu</form>
   <lemma>výroba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d1t122-2">
   <w.rf>
    <LM>w#w-d1t122-2</LM>
   </w.rf>
   <form>kalvadosu</form>
   <lemma>kalvados_,s_^(^DD**calvados)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d-id57540">
   <w.rf>
    <LM>w#w-d-id57540</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t122-4">
   <w.rf>
    <LM>w#w-d1t122-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1e72-x4-420">
   <w.rf>
    <LM>w#w-d1e72-x4-420</LM>
   </w.rf>
   <form>nyní</form>
   <lemma>nyní</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t125-1">
   <w.rf>
    <LM>w#w-d1t125-1</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t125-2">
   <w.rf>
    <LM>w#w-d1t125-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m915-d1t125-3">
   <w.rf>
    <LM>w#w-d1t125-3</LM>
   </w.rf>
   <form>zabitým</form>
   <lemma>zabitý_^(*3ít)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m915-d1t125-4">
   <w.rf>
    <LM>w#w-d1t125-4</LM>
   </w.rf>
   <form>dobytkem</form>
   <lemma>dobytek-1_^(zvířata)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m915-d1t122-5">
   <w.rf>
    <LM>w#w-d1t122-5</LM>
   </w.rf>
   <form>ležely</form>
   <lemma>ležet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d1t122-6">
   <w.rf>
    <LM>w#w-d1t122-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t122-7">
   <w.rf>
    <LM>w#w-d1t122-7</LM>
   </w.rf>
   <form>hnily</form>
   <lemma>hnít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d1t122-8">
   <w.rf>
    <LM>w#w-d1t122-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t122-9">
   <w.rf>
    <LM>w#w-d1t122-9</LM>
   </w.rf>
   <form>obrovských</form>
   <lemma>obrovský</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m915-d1t122-10">
   <w.rf>
    <LM>w#w-d1t122-10</LM>
   </w.rf>
   <form>plochách</form>
   <lemma>plocha</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m915-d1e72-x4-650">
   <w.rf>
    <LM>w#w-d1e72-x4-650</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-651">
  <m id="m915-d1e72-x4-646">
   <w.rf>
    <LM>w#w-d1e72-x4-646</LM>
   </w.rf>
   <form>Kolem</form>
   <lemma>kolem-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-651-658">
   <w.rf>
    <LM>w#w-651-658</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d1t127-1">
   <w.rf>
    <LM>w#w-d1t127-1</LM>
   </w.rf>
   <form>poničené</form>
   <lemma>poničený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m915-d1t127-2">
   <w.rf>
    <LM>w#w-d1t127-2</LM>
   </w.rf>
   <form>lesy</form>
   <lemma>les</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m915-d1t131-1">
   <w.rf>
    <LM>w#w-d1t131-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t131-2">
   <w.rf>
    <LM>w#w-d1t131-2</LM>
   </w.rf>
   <form>vypálené</form>
   <lemma>vypálený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m915-d1t131-3">
   <w.rf>
    <LM>w#w-d1t131-3</LM>
   </w.rf>
   <form>obce</form>
   <lemma>obec</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m915-651-688">
   <w.rf>
    <LM>w#w-651-688</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-659">
  <m id="m915-d1t138-1">
   <w.rf>
    <LM>w#w-d1t138-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t138-2">
   <w.rf>
    <LM>w#w-d1t138-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t138-3">
   <w.rf>
    <LM>w#w-d1t138-3</LM>
   </w.rf>
   <form>kontakt</form>
   <lemma>kontakt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t138-4">
   <w.rf>
    <LM>w#w-d1t138-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t138-5">
   <w.rf>
    <LM>w#w-d1t138-5</LM>
   </w.rf>
   <form>válkou</form>
   <lemma>válka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m915-d1t138-6">
   <w.rf>
    <LM>w#w-d1t138-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t138-7">
   <w.rf>
    <LM>w#w-d1t138-7</LM>
   </w.rf>
   <form>velkým</form>
   <lemma>velký</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m915-d1t138-8">
   <w.rf>
    <LM>w#w-d1t138-8</LM>
   </w.rf>
   <form>V</form>
   <lemma>V-33</lemma>
   <tag>Q3-------------</tag>
  </m>
  <m id="m915-659-722">
   <w.rf>
    <LM>w#w-659-722</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t140-2">
   <w.rf>
    <LM>w#w-d1t140-2</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m915-d1t140-3">
   <w.rf>
    <LM>w#w-d1t140-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t140-4">
   <w.rf>
    <LM>w#w-d1t140-4</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t140-5">
   <w.rf>
    <LM>w#w-d1t140-5</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m915-d1t140-6">
   <w.rf>
    <LM>w#w-d1t140-6</LM>
   </w.rf>
   <form>sousedské</form>
   <lemma>sousedský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m915-d1t140-7">
   <w.rf>
    <LM>w#w-d1t140-7</LM>
   </w.rf>
   <form>šarvátky</form>
   <lemma>šarvátka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m915-d-id58121">
   <w.rf>
    <LM>w#w-d-id58121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t142-2">
   <w.rf>
    <LM>w#w-d1t142-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t144-2">
   <w.rf>
    <LM>w#w-d1t144-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t144-1">
   <w.rf>
    <LM>w#w-d1t144-1</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m915-d1t144-5">
   <w.rf>
    <LM>w#w-d1t144-5</LM>
   </w.rf>
   <form>zvykem</form>
   <lemma>zvyk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m915-659-724">
   <w.rf>
    <LM>w#w-659-724</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-725">
  <m id="m915-d1t148-1">
   <w.rf>
    <LM>w#w-d1t148-1</LM>
   </w.rf>
   <form>Postupně</form>
   <lemma>postupně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-725-745">
   <w.rf>
    <LM>w#w-725-745</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t151-1">
   <w.rf>
    <LM>w#w-d1t151-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t151-2">
   <w.rf>
    <LM>w#w-d1t151-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t151-3">
   <w.rf>
    <LM>w#w-d1t151-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t151-4">
   <w.rf>
    <LM>w#w-d1t151-4</LM>
   </w.rf>
   <form>seznamovali</form>
   <lemma>seznamovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t153-1">
   <w.rf>
    <LM>w#w-d1t153-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t153-2">
   <w.rf>
    <LM>w#w-d1t153-2</LM>
   </w.rf>
   <form>tímto</form>
   <lemma>tento</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m915-d1t153-3">
   <w.rf>
    <LM>w#w-d1t153-3</LM>
   </w.rf>
   <form>novým</form>
   <lemma>nový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m915-d1t153-4">
   <w.rf>
    <LM>w#w-d1t153-4</LM>
   </w.rf>
   <form>stavem</form>
   <lemma>stav</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m915-d-id58427">
   <w.rf>
    <LM>w#w-d-id58427</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t155-1">
   <w.rf>
    <LM>w#w-d1t155-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t155-2">
   <w.rf>
    <LM>w#w-d1t155-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t155-3">
   <w.rf>
    <LM>w#w-d1t155-3</LM>
   </w.rf>
   <form>dostávali</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t159-1">
   <w.rf>
    <LM>w#w-d1t159-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t159-2">
   <w.rf>
    <LM>w#w-d1t159-2</LM>
   </w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t161-1">
   <w.rf>
    <LM>w#w-d1t161-1</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t161-2">
   <w.rf>
    <LM>w#w-d1t161-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t161-3">
   <w.rf>
    <LM>w#w-d1t161-3</LM>
   </w.rf>
   <form>rozmezí</form>
   <lemma>rozmezí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d1t161-4">
   <w.rf>
    <LM>w#w-d1t161-4</LM>
   </w.rf>
   <form>francouzsko</form>
   <lemma>francouzsko</lemma>
   <tag>S2--------A----</tag>
  </m>
  <m id="m915-725-750">
   <w.rf>
    <LM>w#w-725-750</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t161-5">
   <w.rf>
    <LM>w#w-d1t161-5</LM>
   </w.rf>
   <form>belgických</form>
   <lemma>belgický</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m915-d1t161-6">
   <w.rf>
    <LM>w#w-d1t161-6</LM>
   </w.rf>
   <form>hranic</form>
   <lemma>hranice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m915-725-1840">
   <w.rf>
    <LM>w#w-725-1840</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1841">
  <m id="m915-d1t164-1">
   <w.rf>
    <LM>w#w-d1t164-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t164-2">
   <w.rf>
    <LM>w#w-d1t164-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t166-1">
   <w.rf>
    <LM>w#w-d1t166-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t166-2">
   <w.rf>
    <LM>w#w-d1t166-2</LM>
   </w.rf>
   <form>útočných</form>
   <lemma>útočný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m915-d1t166-3">
   <w.rf>
    <LM>w#w-d1t166-3</LM>
   </w.rf>
   <form>jednotkách</form>
   <lemma>jednotka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m915-d1t168-1">
   <w.rf>
    <LM>w#w-d1t168-1</LM>
   </w.rf>
   <form>převzali</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t168-2">
   <w.rf>
    <LM>w#w-d1t168-2</LM>
   </w.rf>
   <form>hlídání</form>
   <lemma>hlídání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d1t168-6">
   <w.rf>
    <LM>w#w-d1t168-6</LM>
   </w.rf>
   <form>perimetru</form>
   <lemma>perimetr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t170-1">
   <w.rf>
    <LM>w#w-d1t170-1</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t170-3">
   <w.rf>
    <LM>w#w-d1t170-3</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m915-d-id58898">
   <w.rf>
    <LM>w#w-d-id58898</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e72-x6">
  <m id="m915-d1t174-1">
   <w.rf>
    <LM>w#w-d1t174-1</LM>
   </w.rf>
   <form>Spojenci</form>
   <lemma>spojenec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m915-d1t174-2">
   <w.rf>
    <LM>w#w-d1t174-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t174-3">
   <w.rf>
    <LM>w#w-d1t174-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m915-d1t174-4">
   <w.rf>
    <LM>w#w-d1t174-4</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t177-1">
   <w.rf>
    <LM>w#w-d1t177-1</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t177-2">
   <w.rf>
    <LM>w#w-d1t177-2</LM>
   </w.rf>
   <form>šetřili</form>
   <lemma>šetřit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t179-1">
   <w.rf>
    <LM>w#w-d1t179-1</LM>
   </w.rf>
   <form>silami</form>
   <lemma>síla_^(fyzická,_vojenská;_moc)</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m915-d1t181-1">
   <w.rf>
    <LM>w#w-d1t181-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t181-2">
   <w.rf>
    <LM>w#w-d1t181-2</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m915-d1t181-3">
   <w.rf>
    <LM>w#w-d1t181-3</LM>
   </w.rf>
   <form>strategicky</form>
   <lemma>strategicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t181-4">
   <w.rf>
    <LM>w#w-d1t181-4</LM>
   </w.rf>
   <form>účelné</form>
   <lemma>účelný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d1e72-x6-797">
   <w.rf>
    <LM>w#w-d1e72-x6-797</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t181-5">
   <w.rf>
    <LM>w#w-d1t181-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t181-6">
   <w.rf>
    <LM>w#w-d1t181-6</LM>
   </w.rf>
   <form>moudré</form>
   <lemma>moudrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d1e72-x6-798">
   <w.rf>
    <LM>w#w-d1e72-x6-798</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t181-7">
   <w.rf>
    <LM>w#w-d1t181-7</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t181-8">
   <w.rf>
    <LM>w#w-d1t181-8</LM>
   </w.rf>
   <form>nutné</form>
   <lemma>nutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d1t183-1">
   <w.rf>
    <LM>w#w-d1t183-1</LM>
   </w.rf>
   <form>dobýt</form>
   <lemma>dobýt</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m915-d1t183-2">
   <w.rf>
    <LM>w#w-d1t183-2</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t183-3">
   <w.rf>
    <LM>w#w-d1t183-3</LM>
   </w.rf>
   <form>bojem</form>
   <lemma>boj</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m915-d-id59246">
   <w.rf>
    <LM>w#w-d-id59246</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e72-x7">
  <m id="m915-d1t187-1">
   <w.rf>
    <LM>w#w-d1t187-1</LM>
   </w.rf>
   <form>Stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t187-2">
   <w.rf>
    <LM>w#w-d1t187-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t187-3">
   <w.rf>
    <LM>w#w-d1t187-3</LM>
   </w.rf>
   <form>izolovat</form>
   <lemma>izolovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m915-d1t187-4">
   <w.rf>
    <LM>w#w-d1t187-4</LM>
   </w.rf>
   <form>vojenskou</form>
   <lemma>vojenský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m915-d1t187-5">
   <w.rf>
    <LM>w#w-d1t187-5</LM>
   </w.rf>
   <form>jednotku</form>
   <lemma>jednotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d-id59357">
   <w.rf>
    <LM>w#w-d-id59357</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t187-7">
   <w.rf>
    <LM>w#w-d1t187-7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m915-d1t187-8">
   <w.rf>
    <LM>w#w-d1t187-8</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t187-9">
   <w.rf>
    <LM>w#w-d1t187-9</LM>
   </w.rf>
   <form>obsadila</form>
   <lemma>obsadit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m915-d1e72-x7-841">
   <w.rf>
    <LM>w#w-d1e72-x7-841</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t190-1">
   <w.rf>
    <LM>w#w-d1t190-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t190-2">
   <w.rf>
    <LM>w#w-d1t190-2</LM>
   </w.rf>
   <form>čekat</form>
   <lemma>čekat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m915-d1t190-3">
   <w.rf>
    <LM>w#w-d1t190-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t190-4">
   <w.rf>
    <LM>w#w-d1t190-4</LM>
   </w.rf>
   <form>zhroucení</form>
   <lemma>zhroucení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d1t192-1">
   <w.rf>
    <LM>w#w-d1t192-1</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t192-2">
   <w.rf>
    <LM>w#w-d1t192-2</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t192-3">
   <w.rf>
    <LM>w#w-d1t192-3</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m915-d-id59539">
   <w.rf>
    <LM>w#w-d-id59539</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e193-x2">
  <m id="m915-d1t196-1">
   <w.rf>
    <LM>w#w-d1t196-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t196-2">
   <w.rf>
    <LM>w#w-d1t196-2</LM>
   </w.rf>
   <form>probíhal</form>
   <lemma>probíhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t196-3">
   <w.rf>
    <LM>w#w-d1t196-3</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m915-d1t196-4">
   <w.rf>
    <LM>w#w-d1t196-4</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t200-1">
   <w.rf>
    <LM>w#w-d1t200-1</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m915-d1t200-2">
   <w.rf>
    <LM>w#w-d1t200-2</LM>
   </w.rf>
   <form>dobou</form>
   <lemma>doba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m915-d-id59649">
   <w.rf>
    <LM>w#w-d-id59649</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e203-x2">
  <m id="m915-d1t206-1">
   <w.rf>
    <LM>w#w-d1t206-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t206-2">
   <w.rf>
    <LM>w#w-d1t206-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m915-d1t206-3">
   <w.rf>
    <LM>w#w-d1t206-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t206-4">
   <w.rf>
    <LM>w#w-d1t206-4</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m915-d1e203-x2-978">
   <w.rf>
    <LM>w#w-d1e203-x2-978</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t206-5">
   <w.rf>
    <LM>w#w-d1t206-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t206-6">
   <w.rf>
    <LM>w#w-d1t206-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t206-7">
   <w.rf>
    <LM>w#w-d1t206-7</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t208-1">
   <w.rf>
    <LM>w#w-d1t208-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t208-3">
   <w.rf>
    <LM>w#w-d1t208-3</LM>
   </w.rf>
   <form>technickém</form>
   <lemma>technický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m915-d1t208-2">
   <w.rf>
    <LM>w#w-d1t208-2</LM>
   </w.rf>
   <form>úseku</form>
   <lemma>úsek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d1t208-4">
   <w.rf>
    <LM>w#w-d1t208-4</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t208-5">
   <w.rf>
    <LM>w#w-d1t208-5</LM>
   </w.rf>
   <form>zásobování</form>
   <lemma>zásobování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d1t212-1">
   <w.rf>
    <LM>w#w-d1t212-1</LM>
   </w.rf>
   <form>vozidel</form>
   <lemma>vozidlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m915-d1e203-x2-980">
   <w.rf>
    <LM>w#w-d1e203-x2-980</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t214-1">
   <w.rf>
    <LM>w#w-d1t214-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t214-2">
   <w.rf>
    <LM>w#w-d1t214-2</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m915-d1t214-3">
   <w.rf>
    <LM>w#w-d1t214-3</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t214-4">
   <w.rf>
    <LM>w#w-d1t214-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t214-5">
   <w.rf>
    <LM>w#w-d1t214-5</LM>
   </w.rf>
   <form>perimetru</form>
   <lemma>perimetr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d1e203-x2-1861">
   <w.rf>
    <LM>w#w-d1e203-x2-1861</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1862">
  <m id="m915-d1t214-8">
   <w.rf>
    <LM>w#w-d1t214-8</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t214-9">
   <w.rf>
    <LM>w#w-d1t214-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t214-10">
   <w.rf>
    <LM>w#w-d1t214-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t214-11">
   <w.rf>
    <LM>w#w-d1t214-11</LM>
   </w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t214-12">
   <w.rf>
    <LM>w#w-d1t214-12</LM>
   </w.rf>
   <form>La</form>
   <lemma>La-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-1862-1863">
   <w.rf>
    <LM>w#w-1862-1863</LM>
   </w.rf>
   <form>Panne</form>
   <lemma>Panne_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m915-d-id60187">
   <w.rf>
    <LM>w#w-d-id60187</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t217-1">
   <w.rf>
    <LM>w#w-d1t217-1</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m915-d1t217-2">
   <w.rf>
    <LM>w#w-d1t217-2</LM>
   </w.rf>
   <form>jest</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI-2</tag>
  </m>
  <m id="m915-d1t217-3">
   <w.rf>
    <LM>w#w-d1t217-3</LM>
   </w.rf>
   <form>město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m915-d1t217-4">
   <w.rf>
    <LM>w#w-d1t217-4</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t217-5">
   <w.rf>
    <LM>w#w-d1t217-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t217-6">
   <w.rf>
    <LM>w#w-d1t217-6</LM>
   </w.rf>
   <form>francouzskou</form>
   <lemma>francouzský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m915-d1t217-7">
   <w.rf>
    <LM>w#w-d1t217-7</LM>
   </w.rf>
   <form>hranicí</form>
   <lemma>hranice</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m915-d1t217-8">
   <w.rf>
    <LM>w#w-d1t217-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t217-9">
   <w.rf>
    <LM>w#w-d1t217-9</LM>
   </w.rf>
   <form>belgickém</form>
   <lemma>belgický</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d1t217-10">
   <w.rf>
    <LM>w#w-d1t217-10</LM>
   </w.rf>
   <form>území</form>
   <lemma>území</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d-id60347">
   <w.rf>
    <LM>w#w-d-id60347</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t219-1">
   <w.rf>
    <LM>w#w-d1t219-1</LM>
   </w.rf>
   <form>nedaleko</form>
   <lemma>nedaleko</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t219-2">
   <w.rf>
    <LM>w#w-d1t219-2</LM>
   </w.rf>
   <form>Ostende</form>
   <lemma>Ostende_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m915-d-id60396">
   <w.rf>
    <LM>w#w-d-id60396</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t221-1">
   <w.rf>
    <LM>w#w-d1t221-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t221-2">
   <w.rf>
    <LM>w#w-d1t221-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t221-3">
   <w.rf>
    <LM>w#w-d1t221-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t221-4">
   <w.rf>
    <LM>w#w-d1t221-4</LM>
   </w.rf>
   <form>velitelství</form>
   <lemma>velitelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m915-d1t221-5">
   <w.rf>
    <LM>w#w-d1t221-5</LM>
   </w.rf>
   <form>praporu</form>
   <lemma>prapor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d-id60491">
   <w.rf>
    <LM>w#w-d-id60491</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e203-x3">
  <m id="m915-d1t225-1">
   <w.rf>
    <LM>w#w-d1t225-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t225-2">
   <w.rf>
    <LM>w#w-d1t225-2</LM>
   </w.rf>
   <form>frontu</form>
   <lemma>fronta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d1t225-3">
   <w.rf>
    <LM>w#w-d1t225-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t225-4">
   <w.rf>
    <LM>w#w-d1t225-4</LM>
   </w.rf>
   <form>jezdívali</form>
   <lemma>jezdívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t225-5">
   <w.rf>
    <LM>w#w-d1t225-5</LM>
   </w.rf>
   <form>vystřídat</form>
   <lemma>vystřídat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m915-d1t225-6">
   <w.rf>
    <LM>w#w-d1t225-6</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m915-d1t225-7">
   <w.rf>
    <LM>w#w-d1t225-7</LM>
   </w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d-id60633">
   <w.rf>
    <LM>w#w-d-id60633</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t225-9">
   <w.rf>
    <LM>w#w-d1t225-9</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m915-d1t225-10">
   <w.rf>
    <LM>w#w-d1t225-10</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m915-d1t225-11">
   <w.rf>
    <LM>w#w-d1t225-11</LM>
   </w.rf>
   <form>umožnili</form>
   <lemma>umožnit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t230-1">
   <w.rf>
    <LM>w#w-d1t230-1</LM>
   </w.rf>
   <form>krátký</form>
   <lemma>krátký</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m915-d1t230-2">
   <w.rf>
    <LM>w#w-d1t230-2</LM>
   </w.rf>
   <form>oddych</form>
   <lemma>oddych</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1e203-x3-1044">
   <w.rf>
    <LM>w#w-d1e203-x3-1044</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t232-1">
   <w.rf>
    <LM>w#w-d1t232-1</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d1e203-x3-1045">
   <w.rf>
    <LM>w#w-d1e203-x3-1045</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t232-2">
   <w.rf>
    <LM>w#w-d1t232-2</LM>
   </w.rf>
   <form>propustky</form>
   <lemma>propustka_^(potvrzení_o_možnosti_vstupu/odchodu)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d1e203-x3-1046">
   <w.rf>
    <LM>w#w-d1e203-x3-1046</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1047">
  <m id="m915-d1t236-2">
   <w.rf>
    <LM>w#w-d1t236-2</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t236-3">
   <w.rf>
    <LM>w#w-d1t236-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t236-4">
   <w.rf>
    <LM>w#w-d1t236-4</LM>
   </w.rf>
   <form>zprostředkovávali</form>
   <lemma>zprostředkovávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t236-5">
   <w.rf>
    <LM>w#w-d1t236-5</LM>
   </w.rf>
   <form>styk</form>
   <lemma>styk</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t236-6">
   <w.rf>
    <LM>w#w-d1t236-6</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t236-7">
   <w.rf>
    <LM>w#w-d1t236-7</LM>
   </w.rf>
   <form>jednotlivými</form>
   <lemma>jednotlivý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m915-d1t238-1">
   <w.rf>
    <LM>w#w-d1t238-1</LM>
   </w.rf>
   <form>útvary</form>
   <lemma>útvar</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m915-d1t240-1">
   <w.rf>
    <LM>w#w-d1t240-1</LM>
   </w.rf>
   <form>československé</form>
   <lemma>československý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t240-2">
   <w.rf>
    <LM>w#w-d1t240-2</LM>
   </w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id60964">
   <w.rf>
    <LM>w#w-d-id60964</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e203-x4">
  <m id="m915-d1t245-1">
   <w.rf>
    <LM>w#w-d1t245-1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t245-2">
   <w.rf>
    <LM>w#w-d1t245-2</LM>
   </w.rf>
   <form>přesto</form>
   <lemma>přesto-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d-id61028">
   <w.rf>
    <LM>w#w-d-id61028</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t245-4">
   <w.rf>
    <LM>w#w-d1t245-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t245-9">
   <w.rf>
    <LM>w#w-d1t245-9</LM>
   </w.rf>
   <form>dobytí</form>
   <lemma>dobytí_^(*3ýt)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m915-d1t247-1">
   <w.rf>
    <LM>w#w-d1t247-1</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m915-d1t245-6">
   <w.rf>
    <LM>w#w-d1t245-6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m915-d1t245-7">
   <w.rf>
    <LM>w#w-d1t245-7</LM>
   </w.rf>
   <form>strategický</form>
   <lemma>strategický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m915-d1t245-8">
   <w.rf>
    <LM>w#w-d1t245-8</LM>
   </w.rf>
   <form>cíl</form>
   <lemma>cíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d-id61155">
   <w.rf>
    <LM>w#w-d-id61155</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t247-4">
   <w.rf>
    <LM>w#w-d1t247-4</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t247-5">
   <w.rf>
    <LM>w#w-d1t247-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t251-1">
   <w.rf>
    <LM>w#w-d1t251-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t251-3">
   <w.rf>
    <LM>w#w-d1t251-3</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t251-2">
   <w.rf>
    <LM>w#w-d1t251-2</LM>
   </w.rf>
   <form>jednalo</form>
   <lemma>jednat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t251-4">
   <w.rf>
    <LM>w#w-d1t251-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t251-5">
   <w.rf>
    <LM>w#w-d1t251-5</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m915-d1t251-6">
   <w.rf>
    <LM>w#w-d1t251-6</LM>
   </w.rf>
   <form>zneklidnění</form>
   <lemma>zneklidnění_^(*2t)_(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d1t253-1">
   <w.rf>
    <LM>w#w-d1t253-1</LM>
   </w.rf>
   <form>Němců</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m915-d1e203-x4-1287">
   <w.rf>
    <LM>w#w-d1e203-x4-1287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1288">
  <m id="m915-d1t256-1">
   <w.rf>
    <LM>w#w-d1t256-1</LM>
   </w.rf>
   <form>Jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t256-3">
   <w.rf>
    <LM>w#w-d1t256-3</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m915-d1t256-4">
   <w.rf>
    <LM>w#w-d1t256-4</LM>
   </w.rf>
   <form>válečná</form>
   <lemma>válečný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m915-d1t256-5">
   <w.rf>
    <LM>w#w-d1t256-5</LM>
   </w.rf>
   <form>strategie</form>
   <lemma>strategie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d1t256-6">
   <w.rf>
    <LM>w#w-d1t256-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m915-d1t256-2">
   <w.rf>
    <LM>w#w-d1t256-2</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t256-7">
   <w.rf>
    <LM>w#w-d1t256-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t256-8">
   <w.rf>
    <LM>w#w-d1t256-8</LM>
   </w.rf>
   <form>krátkozraká</form>
   <lemma>krátkozraký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m915-d-id61488">
   <w.rf>
    <LM>w#w-d-id61488</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t256-10">
   <w.rf>
    <LM>w#w-d1t256-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t256-11">
   <w.rf>
    <LM>w#w-d1t256-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t258-2">
   <w.rf>
    <LM>w#w-d1t258-2</LM>
   </w.rf>
   <form>svoje</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP4----------</tag>
  </m>
  <m id="m915-d1t258-3">
   <w.rf>
    <LM>w#w-d1t258-3</LM>
   </w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d1t258-4">
   <w.rf>
    <LM>w#w-d1t258-4</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t258-5">
   <w.rf>
    <LM>w#w-d1t258-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t258-6">
   <w.rf>
    <LM>w#w-d1t258-6</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t258-7">
   <w.rf>
    <LM>w#w-d1t258-7</LM>
   </w.rf>
   <form>státních</form>
   <lemma>státní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m915-d1t258-8">
   <w.rf>
    <LM>w#w-d1t258-8</LM>
   </w.rf>
   <form>svátků</form>
   <lemma>svátek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m915-1288-1878">
   <w.rf>
    <LM>w#w-1288-1878</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1879">
  <m id="m915-d1t262-3">
   <w.rf>
    <LM>w#w-d1t262-3</LM>
   </w.rf>
   <form>Němcům</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m915-d1t262-4">
   <w.rf>
    <LM>w#w-d1t262-4</LM>
   </w.rf>
   <form>stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t262-5">
   <w.rf>
    <LM>w#w-d1t262-5</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m915-d1t262-6">
   <w.rf>
    <LM>w#w-d1t262-6</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m915-d1t262-7">
   <w.rf>
    <LM>w#w-d1t262-7</LM>
   </w.rf>
   <form>kalendář</form>
   <lemma>kalendář</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d-id61790">
   <w.rf>
    <LM>w#w-d-id61790</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t262-9">
   <w.rf>
    <LM>w#w-d1t262-9</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t262-10">
   <w.rf>
    <LM>w#w-d1t262-10</LM>
   </w.rf>
   <form>věděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d-id61823">
   <w.rf>
    <LM>w#w-d-id61823</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t264-1">
   <w.rf>
    <LM>w#w-d1t264-1</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t264-2">
   <w.rf>
    <LM>w#w-d1t264-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t264-3">
   <w.rf>
    <LM>w#w-d1t264-3</LM>
   </w.rf>
   <form>Češi</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m915-d1t264-4">
   <w.rf>
    <LM>w#w-d1t264-4</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m915-d1t264-5">
   <w.rf>
    <LM>w#w-d1t264-5</LM>
   </w.rf>
   <form>útočit</form>
   <lemma>útočit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m915-1288-1306">
   <w.rf>
    <LM>w#w-1288-1306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-1288-1307">
   <w.rf>
    <LM>w#w-1288-1307</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t264-7">
   <w.rf>
    <LM>w#w-d1t264-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t264-9">
   <w.rf>
    <LM>w#w-d1t264-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t264-10">
   <w.rf>
    <LM>w#w-d1t264-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m915-d1t264-8">
   <w.rf>
    <LM>w#w-d1t264-8</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t264-11">
   <w.rf>
    <LM>w#w-d1t264-11</LM>
   </w.rf>
   <form>připraveni</form>
   <lemma>připravit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m915-d1e203-x4-1279">
   <w.rf>
    <LM>w#w-d1e203-x4-1279</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1280">
  <m id="m915-d1t266-2">
   <w.rf>
    <LM>w#w-d1t266-2</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t266-3">
   <w.rf>
    <LM>w#w-d1t266-3</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m915-d1t266-4">
   <w.rf>
    <LM>w#w-d1t266-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t266-5">
   <w.rf>
    <LM>w#w-d1t266-5</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t266-6">
   <w.rf>
    <LM>w#w-d1t266-6</LM>
   </w.rf>
   <form>zbytečné</form>
   <lemma>zbytečný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m915-d1t266-7">
   <w.rf>
    <LM>w#w-d1t266-7</LM>
   </w.rf>
   <form>ztráty</form>
   <lemma>ztráta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d1t269-1">
   <w.rf>
    <LM>w#w-d1t269-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t269-2">
   <w.rf>
    <LM>w#w-d1t269-2</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d-id62200">
   <w.rf>
    <LM>w#w-d-id62200</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t269-4">
   <w.rf>
    <LM>w#w-d1t269-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t269-5">
   <w.rf>
    <LM>w#w-d1t269-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t273-1">
   <w.rf>
    <LM>w#w-d1t273-1</LM>
   </w.rf>
   <form>podceňovali</form>
   <lemma>podceňovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t271-1">
   <w.rf>
    <LM>w#w-d1t271-1</LM>
   </w.rf>
   <form>nepřítele</form>
   <lemma>nepřítel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m915-d1t271-2">
   <w.rf>
    <LM>w#w-d1t271-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t271-3">
   <w.rf>
    <LM>w#w-d1t271-3</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m915-d1t271-4">
   <w.rf>
    <LM>w#w-d1t271-4</LM>
   </w.rf>
   <form>inteligenci</form>
   <lemma>inteligence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d-id62333">
   <w.rf>
    <LM>w#w-d-id62333</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e203-x5">
  <m id="m915-d1t282-1">
   <w.rf>
    <LM>w#w-d1t282-1</LM>
   </w.rf>
   <form>Jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m915-d1t282-2">
   <w.rf>
    <LM>w#w-d1t282-2</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t282-3">
   <w.rf>
    <LM>w#w-d1t282-3</LM>
   </w.rf>
   <form>však</form>
   <lemma>však-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t282-4">
   <w.rf>
    <LM>w#w-d1t282-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t282-5">
   <w.rf>
    <LM>w#w-d1t282-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t282-6">
   <w.rf>
    <LM>w#w-d1t282-6</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t282-8">
   <w.rf>
    <LM>w#w-d1t282-8</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id62499">
   <w.rf>
    <LM>w#w-d-id62499</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t284-1">
   <w.rf>
    <LM>w#w-d1t284-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t284-2">
   <w.rf>
    <LM>w#w-d1t284-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t284-3">
   <w.rf>
    <LM>w#w-d1t284-3</LM>
   </w.rf>
   <form>mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t284-5">
   <w.rf>
    <LM>w#w-d1t284-5</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m915-d1t284-6">
   <w.rf>
    <LM>w#w-d1t284-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t284-8">
   <w.rf>
    <LM>w#w-d1t284-8</LM>
   </w.rf>
   <form>epizoda</form>
   <lemma>epizoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d1t284-9">
   <w.rf>
    <LM>w#w-d1t284-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t284-10">
   <w.rf>
    <LM>w#w-d1t284-10</LM>
   </w.rf>
   <form>Ardenách</form>
   <lemma>Ardeny_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m915-d-id62672">
   <w.rf>
    <LM>w#w-d-id62672</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e285-x2">
  <m id="m915-d1t288-1">
   <w.rf>
    <LM>w#w-d1t288-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m915-d1t288-2">
   <w.rf>
    <LM>w#w-d1t288-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t288-3">
   <w.rf>
    <LM>w#w-d1t288-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t288-4">
   <w.rf>
    <LM>w#w-d1t288-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t288-5">
   <w.rf>
    <LM>w#w-d1t288-5</LM>
   </w.rf>
   <form>epizodu</form>
   <lemma>epizoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d-id62791">
   <w.rf>
    <LM>w#w-d-id62791</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x2">
  <m id="m915-d1t292-1">
   <w.rf>
    <LM>w#w-d1t292-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t292-2">
   <w.rf>
    <LM>w#w-d1t292-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m915-d1t292-3">
   <w.rf>
    <LM>w#w-d1t292-3</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t292-4">
   <w.rf>
    <LM>w#w-d1t292-4</LM>
   </w.rf>
   <form>nepříjemná</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m915-d1t292-5">
   <w.rf>
    <LM>w#w-d1t292-5</LM>
   </w.rf>
   <form>epizoda</form>
   <lemma>epizoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d1t292-6">
   <w.rf>
    <LM>w#w-d1t292-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t292-7">
   <w.rf>
    <LM>w#w-d1t292-7</LM>
   </w.rf>
   <form>vyplývala</form>
   <lemma>vyplývat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m915-d1t292-8">
   <w.rf>
    <LM>w#w-d1t292-8</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t292-9">
   <w.rf>
    <LM>w#w-d1t292-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t292-10">
   <w.rf>
    <LM>w#w-d1t292-10</LM>
   </w.rf>
   <form>podceňování</form>
   <lemma>podceňování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m915-d1t292-11">
   <w.rf>
    <LM>w#w-d1t292-11</LM>
   </w.rf>
   <form>nepřítele</form>
   <lemma>nepřítel</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m915-d1e289-x2-1496">
   <w.rf>
    <LM>w#w-d1e289-x2-1496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1497">
  <m id="m915-d1t294-2">
   <w.rf>
    <LM>w#w-d1t294-2</LM>
   </w.rf>
   <form>Došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m915-d1t294-1">
   <w.rf>
    <LM>w#w-d1t294-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t296-1">
   <w.rf>
    <LM>w#w-d1t296-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m915-d1t296-2">
   <w.rf>
    <LM>w#w-d1t296-2</LM>
   </w.rf>
   <form>věhlasně</form>
   <lemma>věhlasně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t296-3">
   <w.rf>
    <LM>w#w-d1t296-3</LM>
   </w.rf>
   <form>známé</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m915-d1t296-4">
   <w.rf>
    <LM>w#w-d1t296-4</LM>
   </w.rf>
   <form>Rundstedtově</form>
   <lemma>Rundstedtův_;Y_^(*2)</lemma>
   <tag>AUFS3M---------</tag>
  </m>
  <m id="m915-d1t296-5">
   <w.rf>
    <LM>w#w-d1t296-5</LM>
   </w.rf>
   <form>ofenzívě</form>
   <lemma>ofenzíva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m915-d-id63328">
   <w.rf>
    <LM>w#w-d-id63328</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t298-1">
   <w.rf>
    <LM>w#w-d1t298-1</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m915-d1t300-1">
   <w.rf>
    <LM>w#w-d1t300-1</LM>
   </w.rf>
   <form>chytila</form>
   <lemma>chytit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m915-d1t303-1">
   <w.rf>
    <LM>w#w-d1t303-1</LM>
   </w.rf>
   <form>Američany</form>
   <lemma>Američan_;E</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m915-d1t303-2">
   <w.rf>
    <LM>w#w-d1t303-2</LM>
   </w.rf>
   <form>with</form>
   <lemma>with-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-1497-1509">
   <w.rf>
    <LM>w#w-1497-1509</LM>
   </w.rf>
   <form>their</form>
   <lemma>their-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-d1t303-4">
   <w.rf>
    <LM>w#w-d1t303-4</LM>
   </w.rf>
   <form>pants</form>
   <lemma>pants-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-d1t303-5">
   <w.rf>
    <LM>w#w-d1t303-5</LM>
   </w.rf>
   <form>down</form>
   <lemma>down-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-1497-1514">
   <w.rf>
    <LM>w#w-1497-1514</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t305-1">
   <w.rf>
    <LM>w#w-d1t305-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t305-2">
   <w.rf>
    <LM>w#w-d1t305-2</LM>
   </w.rf>
   <form>kalhotami</form>
   <lemma>kalhoty</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m915-d1t305-3">
   <w.rf>
    <LM>w#w-d1t305-3</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-1497-1516">
   <w.rf>
    <LM>w#w-1497-1516</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1517">
  <m id="m915-d1t307-1">
   <w.rf>
    <LM>w#w-d1t307-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t307-2">
   <w.rf>
    <LM>w#w-d1t307-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t307-3">
   <w.rf>
    <LM>w#w-d1t307-3</LM>
   </w.rf>
   <form>jakýsi</form>
   <lemma>jakýsi</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m915-d1t307-4">
   <w.rf>
    <LM>w#w-d1t307-4</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m915-d1t307-5">
   <w.rf>
    <LM>w#w-d1t307-5</LM>
   </w.rf>
   <form>záchvěv</form>
   <lemma>záchvěv</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t309-1">
   <w.rf>
    <LM>w#w-d1t309-1</LM>
   </w.rf>
   <form>organizované</form>
   <lemma>organizovaný_^(*2t)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t309-2">
   <w.rf>
    <LM>w#w-d1t309-2</LM>
   </w.rf>
   <form>německé</form>
   <lemma>německý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t309-3">
   <w.rf>
    <LM>w#w-d1t309-3</LM>
   </w.rf>
   <form>branné</form>
   <lemma>branný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t309-4">
   <w.rf>
    <LM>w#w-d1t309-4</LM>
   </w.rf>
   <form>moci</form>
   <lemma>moc-1_^(nad_někým;_politická,_vojenská;_plná,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id63679">
   <w.rf>
    <LM>w#w-d-id63679</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x3">
  <m id="m915-d1t318-1">
   <w.rf>
    <LM>w#w-d1t318-1</LM>
   </w.rf>
   <form>Došlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m915-d1t318-2">
   <w.rf>
    <LM>w#w-d1t318-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m915-d1t318-3">
   <w.rf>
    <LM>w#w-d1t318-3</LM>
   </w.rf>
   <form>zbytečným</form>
   <lemma>zbytečný</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m915-d1t318-6">
   <w.rf>
    <LM>w#w-d1t318-6</LM>
   </w.rf>
   <form>velikým</form>
   <lemma>veliký</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m915-d1t318-7">
   <w.rf>
    <LM>w#w-d1t318-7</LM>
   </w.rf>
   <form>ztrátám</form>
   <lemma>ztráta</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m915-d1t318-8">
   <w.rf>
    <LM>w#w-d1t318-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t318-9">
   <w.rf>
    <LM>w#w-d1t318-9</LM>
   </w.rf>
   <form>lidských</form>
   <lemma>lidský</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m915-d1t318-10">
   <w.rf>
    <LM>w#w-d1t318-10</LM>
   </w.rf>
   <form>životech</form>
   <lemma>život</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m915-d1t318-11">
   <w.rf>
    <LM>w#w-d1t318-11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t318-12">
   <w.rf>
    <LM>w#w-d1t318-12</LM>
   </w.rf>
   <form>materiálu</form>
   <lemma>materiál</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d1e289-x3-99">
   <w.rf>
    <LM>w#w-d1e289-x3-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-100">
  <m id="m915-d1t320-2">
   <w.rf>
    <LM>w#w-d1t320-2</LM>
   </w.rf>
   <form>Mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t320-3">
   <w.rf>
    <LM>w#w-d1t320-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t320-4">
   <w.rf>
    <LM>w#w-d1t320-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m915-d1t320-5">
   <w.rf>
    <LM>w#w-d1t320-5</LM>
   </w.rf>
   <form>klidně</form>
   <lemma>klidně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t320-6">
   <w.rf>
    <LM>w#w-d1t320-6</LM>
   </w.rf>
   <form>předejít</form>
   <lemma>předejít_^(díky_rychlejší_chůzi;;předejít_zřícení)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m915-100-1897">
   <w.rf>
    <LM>w#w-100-1897</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1898">
  <m id="m915-d1t320-8">
   <w.rf>
    <LM>w#w-d1t320-8</LM>
   </w.rf>
   <form>Nejsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m915-d1t320-9">
   <w.rf>
    <LM>w#w-d1t320-9</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m915-d1t320-10">
   <w.rf>
    <LM>w#w-d1t320-10</LM>
   </w.rf>
   <form>stratég</form>
   <lemma>stratég</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m915-d-id64066">
   <w.rf>
    <LM>w#w-d-id64066</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t320-12">
   <w.rf>
    <LM>w#w-d1t320-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t324-2">
   <w.rf>
    <LM>w#w-d1t324-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t324-3">
   <w.rf>
    <LM>w#w-d1t324-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t324-4">
   <w.rf>
    <LM>w#w-d1t324-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t324-5">
   <w.rf>
    <LM>w#w-d1t324-5</LM>
   </w.rf>
   <form>zmínil</form>
   <lemma>zmínit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t324-6">
   <w.rf>
    <LM>w#w-d1t324-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t324-7">
   <w.rf>
    <LM>w#w-d1t324-7</LM>
   </w.rf>
   <form>chybách</form>
   <lemma>chyba</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m915-d-id64216">
   <w.rf>
    <LM>w#w-d-id64216</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t324-9">
   <w.rf>
    <LM>w#w-d1t324-9</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m915-d1t324-10">
   <w.rf>
    <LM>w#w-d1t324-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t324-11">
   <w.rf>
    <LM>w#w-d1t324-11</LM>
   </w.rf>
   <form>staly</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m915-d1t326-1">
   <w.rf>
    <LM>w#w-d1t326-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t326-2">
   <w.rf>
    <LM>w#w-d1t326-2</LM>
   </w.rf>
   <form>českém</form>
   <lemma>český</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d1t326-3">
   <w.rf>
    <LM>w#w-d1t326-3</LM>
   </w.rf>
   <form>velení</form>
   <lemma>velení_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-100-230">
   <w.rf>
    <LM>w#w-100-230</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t324-1">
   <w.rf>
    <LM>w#w-d1t324-1</LM>
   </w.rf>
   <form>stejně</form>
   <lemma>stejně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t326-4">
   <w.rf>
    <LM>w#w-d1t326-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t326-6">
   <w.rf>
    <LM>w#w-d1t326-6</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d1t326-5">
   <w.rf>
    <LM>w#w-d1t326-5</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t326-7">
   <w.rf>
    <LM>w#w-d1t326-7</LM>
   </w.rf>
   <form>hrubé</form>
   <lemma>hrubý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m915-d1t326-8">
   <w.rf>
    <LM>w#w-d1t326-8</LM>
   </w.rf>
   <form>chyby</form>
   <lemma>chyba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m915-d1t326-9">
   <w.rf>
    <LM>w#w-d1t326-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m915-d1t326-10">
   <w.rf>
    <LM>w#w-d1t326-10</LM>
   </w.rf>
   <form>velení</form>
   <lemma>velení_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d1t326-11">
   <w.rf>
    <LM>w#w-d1t326-11</LM>
   </w.rf>
   <form>spojeneckém</form>
   <lemma>spojenecký</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d-id64451">
   <w.rf>
    <LM>w#w-d-id64451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x4">
  <m id="m915-d1t331-5">
   <w.rf>
    <LM>w#w-d1t331-5</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t331-6">
   <w.rf>
    <LM>w#w-d1t331-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t331-7">
   <w.rf>
    <LM>w#w-d1t331-7</LM>
   </w.rf>
   <form>blížil</form>
   <lemma>blížit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t331-8">
   <w.rf>
    <LM>w#w-d1t331-8</LM>
   </w.rf>
   <form>konec</form>
   <lemma>konec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t331-9">
   <w.rf>
    <LM>w#w-d1t331-9</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t333-1">
   <w.rf>
    <LM>w#w-d1t333-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t333-2">
   <w.rf>
    <LM>w#w-d1t333-2</LM>
   </w.rf>
   <form>jednotlivé</form>
   <lemma>jednotlivý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m915-d1t333-3">
   <w.rf>
    <LM>w#w-d1t333-3</LM>
   </w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m915-d1t333-4">
   <w.rf>
    <LM>w#w-d1t333-4</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t333-5">
   <w.rf>
    <LM>w#w-d1t333-5</LM>
   </w.rf>
   <form>kapitulovaly</form>
   <lemma>kapitulovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m915-d-id64697">
   <w.rf>
    <LM>w#w-d-id64697</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t333-8">
   <w.rf>
    <LM>w#w-d1t333-8</LM>
   </w.rf>
   <form>kapitulovala</form>
   <lemma>kapitulovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m915-d1t333-9">
   <w.rf>
    <LM>w#w-d1t333-9</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t333-10">
   <w.rf>
    <LM>w#w-d1t333-10</LM>
   </w.rf>
   <form>posádka</form>
   <lemma>posádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d1t335-1">
   <w.rf>
    <LM>w#w-d1t335-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t335-2">
   <w.rf>
    <LM>w#w-d1t335-2</LM>
   </w.rf>
   <form>Dunkerque</form>
   <lemma>Dunkerque_;G</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m915-d1e289-x4-1909">
   <w.rf>
    <LM>w#w-d1e289-x4-1909</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1910">
  <m id="m915-d1t337-2">
   <w.rf>
    <LM>w#w-d1t337-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t337-3">
   <w.rf>
    <LM>w#w-d1t337-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m915-d1t337-4">
   <w.rf>
    <LM>w#w-d1t337-4</LM>
   </w.rf>
   <form>kapitulaci</form>
   <lemma>kapitulace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t337-5">
   <w.rf>
    <LM>w#w-d1t337-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t337-6">
   <w.rf>
    <LM>w#w-d1t337-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t337-7">
   <w.rf>
    <LM>w#w-d1t337-7</LM>
   </w.rf>
   <form>shromáždili</form>
   <lemma>shromáždit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t337-8">
   <w.rf>
    <LM>w#w-d1t337-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t337-9">
   <w.rf>
    <LM>w#w-d1t337-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t337-10">
   <w.rf>
    <LM>w#w-d1t337-10</LM>
   </w.rf>
   <form>dlouhém</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d1t337-11">
   <w.rf>
    <LM>w#w-d1t337-11</LM>
   </w.rf>
   <form>konvoji</form>
   <lemma>konvoj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d1t339-1">
   <w.rf>
    <LM>w#w-d1t339-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m915-d1t344-1">
   <w.rf>
    <LM>w#w-d1t344-1</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t339-2">
   <w.rf>
    <LM>w#w-d1t339-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t339-3">
   <w.rf>
    <LM>w#w-d1t339-3</LM>
   </w.rf>
   <form>Německo</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m915-d1t342-1">
   <w.rf>
    <LM>w#w-d1t342-1</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t342-2">
   <w.rf>
    <LM>w#w-d1t342-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m915-d1t342-3">
   <w.rf>
    <LM>w#w-d1t342-3</LM>
   </w.rf>
   <form>Pattonovou</form>
   <lemma>Pattonův_;Y_^(*2)</lemma>
   <tag>AUFS7M---------</tag>
  </m>
  <m id="m915-d1t342-4">
   <w.rf>
    <LM>w#w-d1t342-4</LM>
   </w.rf>
   <form>armádou</form>
   <lemma>armáda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m915-d1t344-2">
   <w.rf>
    <LM>w#w-d1t344-2</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d-id65133">
   <w.rf>
    <LM>w#w-d-id65133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x5">
  <m id="m915-d1t346-2">
   <w.rf>
    <LM>w#w-d1t346-2</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t346-3">
   <w.rf>
    <LM>w#w-d1t346-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m915-d1t346-4">
   <w.rf>
    <LM>w#w-d1t346-4</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t346-5">
   <w.rf>
    <LM>w#w-d1t346-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m915-d1t346-6">
   <w.rf>
    <LM>w#w-d1t346-6</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d-id65244">
   <w.rf>
    <LM>w#w-d-id65244</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t346-8">
   <w.rf>
    <LM>w#w-d1t346-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m915-d1t346-9">
   <w.rf>
    <LM>w#w-d1t346-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t348-1">
   <w.rf>
    <LM>w#w-d1t348-1</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t348-2">
   <w.rf>
    <LM>w#w-d1t348-2</LM>
   </w.rf>
   <form>ukazuje</form>
   <lemma>ukazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m915-d-id65324">
   <w.rf>
    <LM>w#w-d-id65324</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t350-1">
   <w.rf>
    <LM>w#w-d1t350-1</LM>
   </w.rf>
   <form>dospěl</form>
   <lemma>dospět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t348-5">
   <w.rf>
    <LM>w#w-d1t348-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t348-6">
   <w.rf>
    <LM>w#w-d1t348-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t348-8">
   <w.rf>
    <LM>w#w-d1t348-8</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t348-9">
   <w.rf>
    <LM>w#w-d1t348-9</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t350-2">
   <w.rf>
    <LM>w#w-d1t350-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m915-d1t350-3">
   <w.rf>
    <LM>w#w-d1t350-3</LM>
   </w.rf>
   <form>nejtěžšímu</form>
   <lemma>těžký</lemma>
   <tag>AANS3----3A----</tag>
  </m>
  <m id="m915-d1t350-4">
   <w.rf>
    <LM>w#w-d1t350-4</LM>
   </w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m915-d-id65490">
   <w.rf>
    <LM>w#w-d-id65490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t350-6">
   <w.rf>
    <LM>w#w-d1t350-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m915-d1t350-7">
   <w.rf>
    <LM>w#w-d1t350-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t350-8">
   <w.rf>
    <LM>w#w-d1t350-8</LM>
   </w.rf>
   <form>během</form>
   <lemma>během</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t350-9">
   <w.rf>
    <LM>w#w-d1t350-9</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t350-10">
   <w.rf>
    <LM>w#w-d1t350-10</LM>
   </w.rf>
   <form>válečné</form>
   <lemma>válečný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t350-11">
   <w.rf>
    <LM>w#w-d1t350-11</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t352-1">
   <w.rf>
    <LM>w#w-d1t352-1</LM>
   </w.rf>
   <form>utrpěl</form>
   <lemma>utrpět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1e289-x5-623">
   <w.rf>
    <LM>w#w-d1e289-x5-623</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-624">
  <m id="m915-d1t352-7">
   <w.rf>
    <LM>w#w-d1t352-7</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m915-d1t352-8">
   <w.rf>
    <LM>w#w-d1t352-8</LM>
   </w.rf>
   <form>náklaďák</form>
   <lemma>náklaďák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t352-6">
   <w.rf>
    <LM>w#w-d1t352-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m915-d1t352-9">
   <w.rf>
    <LM>w#w-d1t352-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t352-10">
   <w.rf>
    <LM>w#w-d1t352-10</LM>
   </w.rf>
   <form>silnici</form>
   <lemma>silnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t352-11">
   <w.rf>
    <LM>w#w-d1t352-11</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t352-12">
   <w.rf>
    <LM>w#w-d1t352-12</LM>
   </w.rf>
   <form>předjíždění</form>
   <lemma>předjíždění_^(*2t)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-624-637">
   <w.rf>
    <LM>w#w-624-637</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t352-15">
   <w.rf>
    <LM>w#w-d1t352-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t352-14">
   <w.rf>
    <LM>w#w-d1t352-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t352-16">
   <w.rf>
    <LM>w#w-d1t352-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t352-17">
   <w.rf>
    <LM>w#w-d1t352-17</LM>
   </w.rf>
   <form>motorce</form>
   <lemma>motorka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d-id65844">
   <w.rf>
    <LM>w#w-d-id65844</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t355-1">
   <w.rf>
    <LM>w#w-d1t355-1</LM>
   </w.rf>
   <form>vtlačil</form>
   <lemma>vtlačit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t355-2">
   <w.rf>
    <LM>w#w-d1t355-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t355-3">
   <w.rf>
    <LM>w#w-d1t355-3</LM>
   </w.rf>
   <form>kráteru</form>
   <lemma>kráter</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t355-4">
   <w.rf>
    <LM>w#w-d1t355-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t355-5">
   <w.rf>
    <LM>w#w-d1t355-5</LM>
   </w.rf>
   <form>pumě</form>
   <lemma>puma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-624-1925">
   <w.rf>
    <LM>w#w-624-1925</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1926">
  <m id="m915-d1t355-10">
   <w.rf>
    <LM>w#w-d1t355-10</LM>
   </w.rf>
   <form>Převrátil</form>
   <lemma>převrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t355-8">
   <w.rf>
    <LM>w#w-d1t355-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t355-9">
   <w.rf>
    <LM>w#w-d1t355-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d-id66016">
   <w.rf>
    <LM>w#w-d-id66016</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t355-12">
   <w.rf>
    <LM>w#w-d1t355-12</LM>
   </w.rf>
   <form>motocykl</form>
   <lemma>motocykl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t355-13">
   <w.rf>
    <LM>w#w-d1t355-13</LM>
   </w.rf>
   <form>padl</form>
   <lemma>padnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m915-d1t357-1">
   <w.rf>
    <LM>w#w-d1t357-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m915-d1t357-2">
   <w.rf>
    <LM>w#w-d1t357-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m915-d1t357-3">
   <w.rf>
    <LM>w#w-d1t357-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t357-4">
   <w.rf>
    <LM>w#w-d1t357-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t359-1">
   <w.rf>
    <LM>w#w-d1t359-1</LM>
   </w.rf>
   <form>značně</form>
   <lemma>značně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t359-2">
   <w.rf>
    <LM>w#w-d1t359-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t359-3">
   <w.rf>
    <LM>w#w-d1t359-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m915-d1t359-4">
   <w.rf>
    <LM>w#w-d1t359-4</LM>
   </w.rf>
   <form>poranil</form>
   <lemma>poranit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t359-5">
   <w.rf>
    <LM>w#w-d1t359-5</LM>
   </w.rf>
   <form>levou</form>
   <lemma>levý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m915-d1t359-6">
   <w.rf>
    <LM>w#w-d1t359-6</LM>
   </w.rf>
   <form>nohu</form>
   <lemma>noha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d-id66222">
   <w.rf>
    <LM>w#w-d-id66222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x6">
  <m id="m915-d1t363-2">
   <w.rf>
    <LM>w#w-d1t363-2</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t363-3">
   <w.rf>
    <LM>w#w-d1t363-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m915-d1t363-4">
   <w.rf>
    <LM>w#w-d1t363-4</LM>
   </w.rf>
   <form>okamžiku</form>
   <lemma>okamžik</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1e289-x6-694">
   <w.rf>
    <LM>w#w-d1e289-x6-694</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t363-7">
   <w.rf>
    <LM>w#w-d1t363-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t363-6">
   <w.rf>
    <LM>w#w-d1t363-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t363-8">
   <w.rf>
    <LM>w#w-d1t363-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t363-9">
   <w.rf>
    <LM>w#w-d1t363-9</LM>
   </w.rf>
   <form>blízkosti</form>
   <lemma>blízkost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t363-10">
   <w.rf>
    <LM>w#w-d1t363-10</LM>
   </w.rf>
   <form>Bad</form>
   <lemma>Bad_;G</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m915-d1e289-x6-696">
   <w.rf>
    <LM>w#w-d1e289-x6-696</LM>
   </w.rf>
   <form>Kreuznachu</form>
   <lemma>Kreuznach</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t363-11">
   <w.rf>
    <LM>w#w-d1t363-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t363-12">
   <w.rf>
    <LM>w#w-d1t363-12</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d1e289-x6-697">
   <w.rf>
    <LM>w#w-d1e289-x6-697</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t368-1">
   <w.rf>
    <LM>w#w-d1t368-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t368-2">
   <w.rf>
    <LM>w#w-d1t368-2</LM>
   </w.rf>
   <form>zbytek</form>
   <lemma>zbytek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m915-d1t368-4">
   <w.rf>
    <LM>w#w-d1t368-4</LM>
   </w.rf>
   <form>epopeje</form>
   <lemma>epopej</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t370-1">
   <w.rf>
    <LM>w#w-d1t370-1</LM>
   </w.rf>
   <form>návratu</form>
   <lemma>návrat</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t370-2">
   <w.rf>
    <LM>w#w-d1t370-2</LM>
   </w.rf>
   <form>trávil</form>
   <lemma>trávit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t370-3">
   <w.rf>
    <LM>w#w-d1t370-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>sanitce</form>
   <lemma>sanitka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d-id66592">
   <w.rf>
    <LM>w#w-d-id66592</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x7">
  <m id="m915-d1t374-2">
   <w.rf>
    <LM>w#w-d1t374-2</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t374-3">
   <w.rf>
    <LM>w#w-d1t374-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t374-4">
   <w.rf>
    <LM>w#w-d1t374-4</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t374-5">
   <w.rf>
    <LM>w#w-d1t374-5</LM>
   </w.rf>
   <form>značné</form>
   <lemma>značný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m915-d1t374-6">
   <w.rf>
    <LM>w#w-d1t374-6</LM>
   </w.rf>
   <form>bolesti</form>
   <lemma>bolest</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d-id66712">
   <w.rf>
    <LM>w#w-d-id66712</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t374-10">
   <w.rf>
    <LM>w#w-d1t374-10</LM>
   </w.rf>
   <form>dostával</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t374-9">
   <w.rf>
    <LM>w#w-d1t374-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t374-11">
   <w.rf>
    <LM>w#w-d1t374-11</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t374-12">
   <w.rf>
    <LM>w#w-d1t374-12</LM>
   </w.rf>
   <form>morfiové</form>
   <lemma>morfiový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m915-d1t374-13">
   <w.rf>
    <LM>w#w-d1t374-13</LM>
   </w.rf>
   <form>injekce</form>
   <lemma>injekce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m915-d1e289-x7-808">
   <w.rf>
    <LM>w#w-d1e289-x7-808</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-809">
  <m id="m915-d1t374-18">
   <w.rf>
    <LM>w#w-d1t374-18</LM>
   </w.rf>
   <form>Probudil</form>
   <lemma>probudit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t374-16">
   <w.rf>
    <LM>w#w-d1t374-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t374-17">
   <w.rf>
    <LM>w#w-d1t374-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t376-1">
   <w.rf>
    <LM>w#w-d1t376-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t376-2">
   <w.rf>
    <LM>w#w-d1t376-2</LM>
   </w.rf>
   <form>slavnostním</form>
   <lemma>slavnostní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d1t376-3">
   <w.rf>
    <LM>w#w-d1t376-3</LM>
   </w.rf>
   <form>vítání</form>
   <lemma>vítání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-d1t376-4">
   <w.rf>
    <LM>w#w-d1t376-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t376-5">
   <w.rf>
    <LM>w#w-d1t376-5</LM>
   </w.rf>
   <form>plzeňském</form>
   <lemma>plzeňský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m915-d1t376-6">
   <w.rf>
    <LM>w#w-d1t376-6</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m915-809-1939">
   <w.rf>
    <LM>w#w-809-1939</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1940">
  <m id="m915-d1t376-9">
   <w.rf>
    <LM>w#w-d1t376-9</LM>
   </w.rf>
   <form>Vykoukl</form>
   <lemma>vykouknout_^(podívat_se_ven;_zčásti_se_ukázat)</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m915-d1t376-8">
   <w.rf>
    <LM>w#w-d1t376-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t378-1">
   <w.rf>
    <LM>w#w-d1t378-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t378-3">
   <w.rf>
    <LM>w#w-d1t378-3</LM>
   </w.rf>
   <form>malého</form>
   <lemma>malý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m915-d1t381-1">
   <w.rf>
    <LM>w#w-d1t381-1</LM>
   </w.rf>
   <form>okénka</form>
   <lemma>okénko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m915-d1t381-3">
   <w.rf>
    <LM>w#w-d1t381-3</LM>
   </w.rf>
   <form>sanitky</form>
   <lemma>sanitka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id67130">
   <w.rf>
    <LM>w#w-d-id67130</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t383-1">
   <w.rf>
    <LM>w#w-d1t383-1</LM>
   </w.rf>
   <form>vystrčil</form>
   <lemma>vystrčit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t383-2">
   <w.rf>
    <LM>w#w-d1t383-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t385-1">
   <w.rf>
    <LM>w#w-d1t385-1</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4----------</tag>
  </m>
  <m id="m915-d1t387-1">
   <w.rf>
    <LM>w#w-d1t387-1</LM>
   </w.rf>
   <form>zraněnou</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m915-d1t387-2">
   <w.rf>
    <LM>w#w-d1t387-2</LM>
   </w.rf>
   <form>ruku</form>
   <lemma>ruka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d-id67234">
   <w.rf>
    <LM>w#w-d-id67234</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t387-4">
   <w.rf>
    <LM>w#w-d1t387-4</LM>
   </w.rf>
   <form>omotanou</form>
   <lemma>omotaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m915-d1t387-5">
   <w.rf>
    <LM>w#w-d1t387-5</LM>
   </w.rf>
   <form>hlavu</form>
   <lemma>hlava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m915-d1t387-6">
   <w.rf>
    <LM>w#w-d1t387-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t387-7">
   <w.rf>
    <LM>w#w-d1t387-7</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m915-d1t387-8">
   <w.rf>
    <LM>w#w-d1t387-8</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t387-9">
   <w.rf>
    <LM>w#w-d1t387-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t387-10">
   <w.rf>
    <LM>w#w-d1t387-10</LM>
   </w.rf>
   <form>volali</form>
   <lemma>volat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-809-823">
   <w.rf>
    <LM>w#w-809-823</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-809-824">
   <w.rf>
    <LM>w#w-809-824</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t387-11">
   <w.rf>
    <LM>w#w-d1t387-11</LM>
   </w.rf>
   <form>Jé</form>
   <lemma>jé</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m915-809-826">
   <w.rf>
    <LM>w#w-809-826</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t387-12">
   <w.rf>
    <LM>w#w-d1t387-12</LM>
   </w.rf>
   <form>hele</form>
   <lemma>hele</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m915-809-827">
   <w.rf>
    <LM>w#w-809-827</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t387-13">
   <w.rf>
    <LM>w#w-d1t387-13</LM>
   </w.rf>
   <form>raněný</form>
   <lemma>raněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m915-d-id67379">
   <w.rf>
    <LM>w#w-d-id67379</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-809-829">
   <w.rf>
    <LM>w#w-809-829</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x8">
  <m id="m915-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>Připadal</form>
   <lemma>připadat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m915-d1t391-4">
   <w.rf>
    <LM>w#w-d1t391-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t391-5">
   <w.rf>
    <LM>w#w-d1t391-5</LM>
   </w.rf>
   <form>Štursův</form>
   <lemma>Štursův_;Y_^(*2a)</lemma>
   <tag>AUMS1M---------</tag>
  </m>
  <m id="m915-d1t391-6">
   <w.rf>
    <LM>w#w-d1t391-6</LM>
   </w.rf>
   <form>Raněný</form>
   <lemma>raněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m915-d-id67531">
   <w.rf>
    <LM>w#w-d-id67531</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x9">
  <m id="m915-d1t396-2">
   <w.rf>
    <LM>w#w-d1t396-2</LM>
   </w.rf>
   <form>Odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1e289-x9-1037">
   <w.rf>
    <LM>w#w-d1e289-x9-1037</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t396-3">
   <w.rf>
    <LM>w#w-d1t396-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t396-5">
   <w.rf>
    <LM>w#w-d1t396-5</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>plzeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1e289-x9-1038">
   <w.rf>
    <LM>w#w-d1e289-x9-1038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t396-6">
   <w.rf>
    <LM>w#w-d1t396-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t396-7">
   <w.rf>
    <LM>w#w-d1t396-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t396-10">
   <w.rf>
    <LM>w#w-d1t396-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m915-d1t396-11">
   <w.rf>
    <LM>w#w-d1t396-11</LM>
   </w.rf>
   <form>jednotce</form>
   <lemma>jednotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m915-d1t396-9">
   <w.rf>
    <LM>w#w-d1t396-9</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t396-8">
   <w.rf>
    <LM>w#w-d1t396-8</LM>
   </w.rf>
   <form>nevrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m915-d-id67714">
   <w.rf>
    <LM>w#w-d-id67714</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t396-13">
   <w.rf>
    <LM>w#w-d1t396-13</LM>
   </w.rf>
   <form>nýbrž</form>
   <lemma>nýbrž</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t396-14">
   <w.rf>
    <LM>w#w-d1t396-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t396-15">
   <w.rf>
    <LM>w#w-d1t396-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t396-16">
   <w.rf>
    <LM>w#w-d1t396-16</LM>
   </w.rf>
   <form>přemístěn</form>
   <lemma>přemístit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m915-d1t398-1">
   <w.rf>
    <LM>w#w-d1t398-1</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m915-d1t398-2">
   <w.rf>
    <LM>w#w-d1t398-2</LM>
   </w.rf>
   <form>Strakonicím</form>
   <lemma>Strakonice_;G</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m915-d1t398-3">
   <w.rf>
    <LM>w#w-d1t398-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m915-d1t398-4">
   <w.rf>
    <LM>w#w-d1t398-4</LM>
   </w.rf>
   <form>americké</form>
   <lemma>americký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t398-5">
   <w.rf>
    <LM>w#w-d1t398-5</LM>
   </w.rf>
   <form>vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t398-6">
   <w.rf>
    <LM>w#w-d1t398-6</LM>
   </w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d-id67887">
   <w.rf>
    <LM>w#w-d-id67887</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t398-8">
   <w.rf>
    <LM>w#w-d1t398-8</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t398-9">
   <w.rf>
    <LM>w#w-d1t398-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t398-11">
   <w.rf>
    <LM>w#w-d1t398-11</LM>
   </w.rf>
   <form>pobyl</form>
   <lemma>pobýt</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t400-1">
   <w.rf>
    <LM>w#w-d1t400-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t400-2">
   <w.rf>
    <LM>w#w-d1t400-2</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m915-d1t400-3">
   <w.rf>
    <LM>w#w-d1t400-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t400-4">
   <w.rf>
    <LM>w#w-d1t400-4</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m915-d1t400-5">
   <w.rf>
    <LM>w#w-d1t400-5</LM>
   </w.rf>
   <form>dnů</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m915-d1e289-x9-1027">
   <w.rf>
    <LM>w#w-d1e289-x9-1027</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1028">
  <m id="m915-d1t404-1">
   <w.rf>
    <LM>w#w-d1t404-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t404-2">
   <w.rf>
    <LM>w#w-d1t404-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t404-3">
   <w.rf>
    <LM>w#w-d1t404-3</LM>
   </w.rf>
   <form>umístěn</form>
   <lemma>umístit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m915-d1t404-4">
   <w.rf>
    <LM>w#w-d1t404-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t404-5">
   <w.rf>
    <LM>w#w-d1t404-5</LM>
   </w.rf>
   <form>obrovském</form>
   <lemma>obrovský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m915-d1t404-6">
   <w.rf>
    <LM>w#w-d1t404-6</LM>
   </w.rf>
   <form>vojenském</form>
   <lemma>vojenský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m915-d1t404-7">
   <w.rf>
    <LM>w#w-d1t404-7</LM>
   </w.rf>
   <form>stanu</form>
   <lemma>stan</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d-id68179">
   <w.rf>
    <LM>w#w-d-id68179</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t407-13">
   <w.rf>
    <LM>w#w-d1t407-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m915-d1t407-12">
   <w.rf>
    <LM>w#w-d1t407-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t407-14">
   <w.rf>
    <LM>w#w-d1t407-14</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t407-15">
   <w.rf>
    <LM>w#w-d1t407-15</LM>
   </w.rf>
   <form>čtyřicet</form>
   <lemma>čtyřicet`40</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m915-d1t407-16">
   <w.rf>
    <LM>w#w-d1t407-16</LM>
   </w.rf>
   <form>lůžek</form>
   <lemma>lůžko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m915-1028-1055">
   <w.rf>
    <LM>w#w-1028-1055</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1056">
  <m id="m915-d1t407-7">
   <w.rf>
    <LM>w#w-d1t407-7</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t407-8">
   <w.rf>
    <LM>w#w-d1t407-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t407-9">
   <w.rf>
    <LM>w#w-d1t407-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t407-10">
   <w.rf>
    <LM>w#w-d1t407-10</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-1028-1045">
   <w.rf>
    <LM>w#w-1028-1045</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t407-3">
   <w.rf>
    <LM>w#w-d1t407-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t407-2">
   <w.rf>
    <LM>w#w-d1t407-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t407-4">
   <w.rf>
    <LM>w#w-d1t407-4</LM>
   </w.rf>
   <form>jediný</form>
   <lemma>jediný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m915-d1t407-5">
   <w.rf>
    <LM>w#w-d1t407-5</LM>
   </w.rf>
   <form>pacient</form>
   <lemma>pacient</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m915-d-id68430">
   <w.rf>
    <LM>w#w-d-id68430</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t409-3">
   <w.rf>
    <LM>w#w-d1t409-3</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m915-d1t409-4">
   <w.rf>
    <LM>w#w-d1t409-4</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m915-d1t409-5">
   <w.rf>
    <LM>w#w-d1t409-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m915-d1t409-6">
   <w.rf>
    <LM>w#w-d1t409-6</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m915-d1t409-7">
   <w.rf>
    <LM>w#w-d1t409-7</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d1t409-8">
   <w.rf>
    <LM>w#w-d1t409-8</LM>
   </w.rf>
   <form>náhle</form>
   <lemma>náhle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t409-9">
   <w.rf>
    <LM>w#w-d1t409-9</LM>
   </w.rf>
   <form>zaplnil</form>
   <lemma>zaplnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d1t409-10">
   <w.rf>
    <LM>w#w-d1t409-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t409-11">
   <w.rf>
    <LM>w#w-d1t409-11</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m915-d1t409-12">
   <w.rf>
    <LM>w#w-d1t409-12</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m915-d1t409-13">
   <w.rf>
    <LM>w#w-d1t409-13</LM>
   </w.rf>
   <form>lůžko</form>
   <lemma>lůžko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m915-d1t409-14">
   <w.rf>
    <LM>w#w-d1t409-14</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m915-d-id68665">
   <w.rf>
    <LM>w#w-d-id68665</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x10">
  <m id="m915-d1t413-1">
   <w.rf>
    <LM>w#w-d1t413-1</LM>
   </w.rf>
   <form>Dodatečně</form>
   <lemma>dodatečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t413-2">
   <w.rf>
    <LM>w#w-d1t413-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t413-3">
   <w.rf>
    <LM>w#w-d1t413-3</LM>
   </w.rf>
   <form>zjistil</form>
   <lemma>zjistit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m915-d-id68745">
   <w.rf>
    <LM>w#w-d-id68745</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t413-5">
   <w.rf>
    <LM>w#w-d1t413-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m915-d1t413-6">
   <w.rf>
    <LM>w#w-d1t413-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t413-7">
   <w.rf>
    <LM>w#w-d1t413-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m915-d1t413-8">
   <w.rf>
    <LM>w#w-d1t413-8</LM>
   </w.rf>
   <form>samí</form>
   <lemma>samý</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m915-d1t413-9">
   <w.rf>
    <LM>w#w-d1t413-9</LM>
   </w.rf>
   <form>Češi</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m915-d-id68831">
   <w.rf>
    <LM>w#w-d-id68831</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t415-1">
   <w.rf>
    <LM>w#w-d1t415-1</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m915-d1t415-2">
   <w.rf>
    <LM>w#w-d1t415-2</LM>
   </w.rf>
   <form>využili</form>
   <lemma>využít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t415-3">
   <w.rf>
    <LM>w#w-d1t415-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t415-4">
   <w.rf>
    <LM>w#w-d1t415-4</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t415-5">
   <w.rf>
    <LM>w#w-d1t415-5</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t415-6">
   <w.rf>
    <LM>w#w-d1t415-6</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t415-7">
   <w.rf>
    <LM>w#w-d1t415-7</LM>
   </w.rf>
   <form>volné</form>
   <lemma>volný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m915-d1t415-8">
   <w.rf>
    <LM>w#w-d1t415-8</LM>
   </w.rf>
   <form>chvíle</form>
   <lemma>chvíle</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m915-d1t415-9">
   <w.rf>
    <LM>w#w-d1t415-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t415-10">
   <w.rf>
    <LM>w#w-d1t415-10</LM>
   </w.rf>
   <form>Lille</form>
   <lemma>Lille_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m915-d1t420-1">
   <w.rf>
    <LM>w#w-d1t420-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m915-d1t420-2">
   <w.rf>
    <LM>w#w-d1t420-2</LM>
   </w.rf>
   <form>Francii</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t420-3">
   <w.rf>
    <LM>w#w-d1t420-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t420-4">
   <w.rf>
    <LM>w#w-d1t420-4</LM>
   </w.rf>
   <form>navštívili</form>
   <lemma>navštívit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t420-5">
   <w.rf>
    <LM>w#w-d1t420-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t420-6">
   <w.rf>
    <LM>w#w-d1t420-6</LM>
   </w.rf>
   <form>Rue</form>
   <lemma>Rue-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-d1e289-x10-673">
   <w.rf>
    <LM>w#w-d1e289-x10-673</LM>
   </w.rf>
   <form>de</form>
   <lemma>de-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m915-d1e289-x10-1213">
   <w.rf>
    <LM>w#w-d1e289-x10-1213</LM>
   </w.rf>
   <form>Abbesses</form>
   <lemma>Abbesses_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m915-d1e289-x10-1977">
   <w.rf>
    <LM>w#w-d1e289-x10-1977</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1978">
  <m id="m915-d1t422-1">
   <w.rf>
    <LM>w#w-d1t422-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m915-d1t422-2">
   <w.rf>
    <LM>w#w-d1t422-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m915-d1t422-4">
   <w.rf>
    <LM>w#w-d1t422-4</LM>
   </w.rf>
   <form>vykřičená</form>
   <lemma>vykřičený_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m915-d1t422-5">
   <w.rf>
    <LM>w#w-d1t422-5</LM>
   </w.rf>
   <form>čtvrť</form>
   <lemma>čtvrť_^(města)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m915-d-id69203">
   <w.rf>
    <LM>w#w-d-id69203</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t424-1">
   <w.rf>
    <LM>w#w-d1t424-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t424-2">
   <w.rf>
    <LM>w#w-d1t424-2</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m915-d1t424-3">
   <w.rf>
    <LM>w#w-d1t424-3</LM>
   </w.rf>
   <form>takzvaně</form>
   <lemma>takzvaně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t424-4">
   <w.rf>
    <LM>w#w-d1t424-4</LM>
   </w.rf>
   <form>nakoupili</form>
   <lemma>nakoupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m915-d1t424-5">
   <w.rf>
    <LM>w#w-d1t424-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m915-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m915-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>léčeni</form>
   <lemma>léčit</lemma>
   <tag>VsMP----X-API--</tag>
  </m>
  <m id="m915-d-id69354">
   <w.rf>
    <LM>w#w-d-id69354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-d1e289-x11">
  <m id="m915-d1t430-5">
   <w.rf>
    <LM>w#w-d1t430-5</LM>
   </w.rf>
   <form>Ležel</form>
   <lemma>ležet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t430-4">
   <w.rf>
    <LM>w#w-d1t430-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m915-d1t430-6">
   <w.rf>
    <LM>w#w-d1t430-6</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m915-d1t430-7">
   <w.rf>
    <LM>w#w-d1t430-7</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1e289-x11-1983">
   <w.rf>
    <LM>w#w-d1e289-x11-1983</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m915-12941_05-1984">
  <m id="m915-d1t430-9">
   <w.rf>
    <LM>w#w-d1t430-9</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t430-10">
   <w.rf>
    <LM>w#w-d1t430-10</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m915-d1t430-11">
   <w.rf>
    <LM>w#w-d1t430-11</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m915-d1t430-12">
   <w.rf>
    <LM>w#w-d1t430-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m915-d1t430-13">
   <w.rf>
    <LM>w#w-d1t430-13</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m915-d1t430-14">
   <w.rf>
    <LM>w#w-d1t430-14</LM>
   </w.rf>
   <form>vynalezen</form>
   <lemma>vynaleznout</lemma>
   <tag>VsYS----X-APP-1</tag>
  </m>
  <m id="m915-d1t430-15">
   <w.rf>
    <LM>w#w-d1t430-15</LM>
   </w.rf>
   <form>penicilin</form>
   <lemma>penicilin_,s_^(^DD**penicilín)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m915-d-id69615">
   <w.rf>
    <LM>w#w-d-id69615</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t435-1">
   <w.rf>
    <LM>w#w-d1t435-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m915-d1t437-1">
   <w.rf>
    <LM>w#w-d1t437-1</LM>
   </w.rf>
   <form>krystalický</form>
   <lemma>krystalický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m915-d1e289-x11-1305">
   <w.rf>
    <LM>w#w-d1e289-x11-1305</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m915-d1t437-2">
   <w.rf>
    <LM>w#w-d1t437-2</LM>
   </w.rf>
   <form>nikoliv</form>
   <lemma>nikoliv_,s_^(^DD**nikoli)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m915-d1t439-1">
   <w.rf>
    <LM>w#w-d1t439-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m915-d1t439-2">
   <w.rf>
    <LM>w#w-d1t439-2</LM>
   </w.rf>
   <form>olejovém</form>
   <lemma>olejový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m915-d1t441-1">
   <w.rf>
    <LM>w#w-d1t441-1</LM>
   </w.rf>
   <form>roztoku</form>
   <lemma>roztok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m915-d1e289-x11-1310">
   <w.rf>
    <LM>w#w-d1e289-x11-1310</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
