<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pk_143.11.w.gz" />
  </references>
 </head>
 <s id="m143-2580">
  <m id="m143-d1t3023-8">
   <w.rf>
    <LM>w#w-d1t3023-8</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m143-d-id186136-punct">
   <w.rf>
    <LM>w#w-d-id186136-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m143-d1t3023-10">
   <w.rf>
    <LM>w#w-d1t3023-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m143-d1t3023-12">
   <w.rf>
    <LM>w#w-d1t3023-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m143-d1t3023-13">
   <w.rf>
    <LM>w#w-d1t3023-13</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m143-d-id186207-punct">
   <w.rf>
    <LM>w#w-d-id186207-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e3026-x2">
  <m id="m143-d1e3026-x2-2589">
   <w.rf>
    <LM>w#w-d1e3026-x2-2589</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t3031-1">
   <w.rf>
    <LM>w#w-d1t3031-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m143-d-m-d1e3026-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3026-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m143-d1e3026-x3">
  <m id="m143-d1e3026-x3-2588">
   <w.rf>
    <LM>w#w-d1e3026-x3-2588</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m143-d1t3033-1">
   <w.rf>
    <LM>w#w-d1t3033-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m143-d-m-d1e3026-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3026-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
