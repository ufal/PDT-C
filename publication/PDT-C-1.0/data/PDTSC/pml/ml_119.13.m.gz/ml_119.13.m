<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_119.13.w.gz" />
  </references>
 </head>
 <s id="m119-437">
  <m id="m119-d1t2552-32">
   <w.rf>
    <LM>w#w-d1t2552-32</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2552-33">
   <w.rf>
    <LM>w#w-d1t2552-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m119-d1t2552-35">
   <w.rf>
    <LM>w#w-d1t2552-35</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m119-d-id179979-punct">
   <w.rf>
    <LM>w#w-d-id179979-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2552-37">
   <w.rf>
    <LM>w#w-d1t2552-37</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2552-44">
   <w.rf>
    <LM>w#w-d1t2552-44</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2552-39">
   <w.rf>
    <LM>w#w-d1t2552-39</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2552-40">
   <w.rf>
    <LM>w#w-d1t2552-40</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2552-42">
   <w.rf>
    <LM>w#w-d1t2552-42</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1t2552-43">
   <w.rf>
    <LM>w#w-d1t2552-43</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2525-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2525-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2553-x2">
  <m id="m119-d1t2556-1">
   <w.rf>
    <LM>w#w-d1t2556-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m119-d1t2556-2">
   <w.rf>
    <LM>w#w-d1t2556-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m119-d1t2556-3">
   <w.rf>
    <LM>w#w-d1t2556-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m119-d1t2556-4">
   <w.rf>
    <LM>w#w-d1t2556-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2556-6">
   <w.rf>
    <LM>w#w-d1t2556-6</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m119-d1t2556-8">
   <w.rf>
    <LM>w#w-d1t2556-8</LM>
   </w.rf>
   <form>navštívila</form>
   <lemma>navštívit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m119-d-id180275-punct">
   <w.rf>
    <LM>w#w-d-id180275-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2557-x2">
  <m id="m119-d1t2562-3">
   <w.rf>
    <LM>w#w-d1t2562-3</LM>
   </w.rf>
   <form>Navštívily</form>
   <lemma>navštívit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m119-d1t2562-4">
   <w.rf>
    <LM>w#w-d1t2562-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2562-5">
   <w.rf>
    <LM>w#w-d1t2562-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2562-6">
   <w.rf>
    <LM>w#w-d1t2562-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m119-d1t2562-7">
   <w.rf>
    <LM>w#w-d1t2562-7</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1e2557-x2-456">
   <w.rf>
    <LM>w#w-d1e2557-x2-456</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-462">
  <m id="m119-d1t2564-5">
   <w.rf>
    <LM>w#w-d1t2564-5</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2566-2">
   <w.rf>
    <LM>w#w-d1t2566-2</LM>
   </w.rf>
   <form>Olympu</form>
   <lemma>Olymp_;G_;m</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m119-d1t2566-4">
   <w.rf>
    <LM>w#w-d1t2566-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2566-5">
   <w.rf>
    <LM>w#w-d1t2566-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m119-d-id180609-punct">
   <w.rf>
    <LM>w#w-d-id180609-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2568-2">
   <w.rf>
    <LM>w#w-d1t2568-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2568-3">
   <w.rf>
    <LM>w#w-d1t2568-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2568-4">
   <w.rf>
    <LM>w#w-d1t2568-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m119-462-463">
   <w.rf>
    <LM>w#w-462-463</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2573-4">
   <w.rf>
    <LM>w#w-d1t2573-4</LM>
   </w.rf>
   <form>Mykénách</form>
   <lemma>Mykény_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m119-d-id180809-punct">
   <w.rf>
    <LM>w#w-d-id180809-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2573-7">
   <w.rf>
    <LM>w#w-d1t2573-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m119-d1t2573-8">
   <w.rf>
    <LM>w#w-d1t2573-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d-id180848-punct">
   <w.rf>
    <LM>w#w-d-id180848-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-464">
  <m id="m119-d1t2573-10">
   <w.rf>
    <LM>w#w-d1t2573-10</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2573-11">
   <w.rf>
    <LM>w#w-d1t2573-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2573-14">
   <w.rf>
    <LM>w#w-d1t2573-14</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1t2573-13">
   <w.rf>
    <LM>w#w-d1t2573-13</LM>
   </w.rf>
   <form>zaskočená</form>
   <lemma>zaskočený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m119-464-465">
   <w.rf>
    <LM>w#w-464-465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-466">
  <m id="m119-d1t2575-1">
   <w.rf>
    <LM>w#w-d1t2575-1</LM>
   </w.rf>
   <form>Nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m119-d1t2575-2">
   <w.rf>
    <LM>w#w-d1t2575-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m119-d1t2575-3">
   <w.rf>
    <LM>w#w-d1t2575-3</LM>
   </w.rf>
   <form>vzpomenout</form>
   <lemma>vzpomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m119-466-467">
   <w.rf>
    <LM>w#w-466-467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-468">
  <m id="m119-d1t2577-2">
   <w.rf>
    <LM>w#w-d1t2577-2</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m119-d1t2577-3">
   <w.rf>
    <LM>w#w-d1t2577-3</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m119-d1t2577-5">
   <w.rf>
    <LM>w#w-d1t2577-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2577-4">
   <w.rf>
    <LM>w#w-d1t2577-4</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2577-6">
   <w.rf>
    <LM>w#w-d1t2577-6</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m119-468-469">
   <w.rf>
    <LM>w#w-468-469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-473">
  <m id="m119-d1t2579-6">
   <w.rf>
    <LM>w#w-d1t2579-6</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m119-d1t2579-4">
   <w.rf>
    <LM>w#w-d1t2579-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m119-d1t2579-5">
   <w.rf>
    <LM>w#w-d1t2579-5</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2579-7">
   <w.rf>
    <LM>w#w-d1t2579-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2579-8">
   <w.rf>
    <LM>w#w-d1t2579-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m119-d1t2579-9">
   <w.rf>
    <LM>w#w-d1t2579-9</LM>
   </w.rf>
   <form>fotkách</form>
   <lemma>fotka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m119-d1t2579-10">
   <w.rf>
    <LM>w#w-d1t2579-10</LM>
   </w.rf>
   <form>napsané</form>
   <lemma>napsaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m119-d-id181280-punct">
   <w.rf>
    <LM>w#w-d-id181280-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2579-12">
   <w.rf>
    <LM>w#w-d1t2579-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2579-13">
   <w.rf>
    <LM>w#w-d1t2579-13</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m119-d1t2579-14">
   <w.rf>
    <LM>w#w-d1t2579-14</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2579-15">
   <w.rf>
    <LM>w#w-d1t2579-15</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2579-16">
   <w.rf>
    <LM>w#w-d1t2579-16</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2579-17">
   <w.rf>
    <LM>w#w-d1t2579-17</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m119-d-id181382-punct">
   <w.rf>
    <LM>w#w-d-id181382-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2579-19">
   <w.rf>
    <LM>w#w-d1t2579-19</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2579-20">
   <w.rf>
    <LM>w#w-d1t2579-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m119-d1t2579-21">
   <w.rf>
    <LM>w#w-d1t2579-21</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m119-473-482">
   <w.rf>
    <LM>w#w-473-482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2557-x3">
  <m id="m119-d1t2579-22">
   <w.rf>
    <LM>w#w-d1t2579-22</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d-m-d1e2557-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2557-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2580-x2">
  <m id="m119-d1t2583-1">
   <w.rf>
    <LM>w#w-d1t2583-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m119-d1t2583-2">
   <w.rf>
    <LM>w#w-d1t2583-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2583-3">
   <w.rf>
    <LM>w#w-d1t2583-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2583-4">
   <w.rf>
    <LM>w#w-d1t2583-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m119-d1t2583-5">
   <w.rf>
    <LM>w#w-d1t2583-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2580-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2580-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2585-x2">
  <m id="m119-d1t2590-3">
   <w.rf>
    <LM>w#w-d1t2590-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2590-4">
   <w.rf>
    <LM>w#w-d1t2590-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d1t2590-5">
   <w.rf>
    <LM>w#w-d1t2590-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2590-7">
   <w.rf>
    <LM>w#w-d1t2590-7</LM>
   </w.rf>
   <form>lodi</form>
   <lemma>loď</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m119-d-id181778-punct">
   <w.rf>
    <LM>w#w-d-id181778-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2590-9">
   <w.rf>
    <LM>w#w-d1t2590-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2590-10">
   <w.rf>
    <LM>w#w-d1t2590-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2592-10">
   <w.rf>
    <LM>w#w-d1t2592-10</LM>
   </w.rf>
   <form>pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2592-2">
   <w.rf>
    <LM>w#w-d1t2592-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m119-d1t2592-5">
   <w.rf>
    <LM>w#w-d1t2592-5</LM>
   </w.rf>
   <form>Řecka</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m119-d1e2585-x2-492">
   <w.rf>
    <LM>w#w-d1e2585-x2-492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-493">
  <m id="m119-d1t2594-3">
   <w.rf>
    <LM>w#w-d1t2594-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d1t2594-2">
   <w.rf>
    <LM>w#w-d1t2594-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2594-4">
   <w.rf>
    <LM>w#w-d1t2594-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2594-5">
   <w.rf>
    <LM>w#w-d1t2594-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m119-d1t2594-6">
   <w.rf>
    <LM>w#w-d1t2594-6</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m119-d1t2594-7">
   <w.rf>
    <LM>w#w-d1t2594-7</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m119-d-id182079-punct">
   <w.rf>
    <LM>w#w-d-id182079-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2594-9">
   <w.rf>
    <LM>w#w-d1t2594-9</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2599-3">
   <w.rf>
    <LM>w#w-d1t2599-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m119-d1t2599-5">
   <w.rf>
    <LM>w#w-d1t2599-5</LM>
   </w.rf>
   <form>bouře</form>
   <lemma>bouře</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-493-494">
   <w.rf>
    <LM>w#w-493-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-495">
  <m id="m119-d1t2601-2">
   <w.rf>
    <LM>w#w-d1t2601-2</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2601-3">
   <w.rf>
    <LM>w#w-d1t2601-3</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2601-8">
   <w.rf>
    <LM>w#w-d1t2601-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2601-9">
   <w.rf>
    <LM>w#w-d1t2601-9</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m119-d1t2601-10">
   <w.rf>
    <LM>w#w-d1t2601-10</LM>
   </w.rf>
   <form>hrůzu</form>
   <lemma>hrůza</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-d1t2601-5">
   <w.rf>
    <LM>w#w-d1t2601-5</LM>
   </w.rf>
   <form>stálo</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d-id182399-punct">
   <w.rf>
    <LM>w#w-d-id182399-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2601-12">
   <w.rf>
    <LM>w#w-d1t2601-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2601-14">
   <w.rf>
    <LM>w#w-d1t2601-14</LM>
   </w.rf>
   <form>svítilo</form>
   <lemma>svítit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d1t2601-15">
   <w.rf>
    <LM>w#w-d1t2601-15</LM>
   </w.rf>
   <form>sluníčko</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m119-495-496">
   <w.rf>
    <LM>w#w-495-496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-498">
  <m id="m119-d1t2601-19">
   <w.rf>
    <LM>w#w-d1t2601-19</LM>
   </w.rf>
   <form>Čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2601-18">
   <w.rf>
    <LM>w#w-d1t2601-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d-id182525-punct">
   <w.rf>
    <LM>w#w-d-id182525-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2603-1">
   <w.rf>
    <LM>w#w-d1t2603-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2603-2">
   <w.rf>
    <LM>w#w-d1t2603-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2603-5">
   <w.rf>
    <LM>w#w-d1t2603-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2603-6">
   <w.rf>
    <LM>w#w-d1t2603-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m119-d1t2603-4">
   <w.rf>
    <LM>w#w-d1t2603-4</LM>
   </w.rf>
   <form>sluníčko</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m119-d1t2603-7">
   <w.rf>
    <LM>w#w-d1t2603-7</LM>
   </w.rf>
   <form>podívá</form>
   <lemma>podívat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m119-498-516">
   <w.rf>
    <LM>w#w-498-516</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2585-x3">
  <m id="m119-d1t2605-19">
   <w.rf>
    <LM>w#w-d1t2605-19</LM>
   </w.rf>
   <form>Cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d1t2605-10">
   <w.rf>
    <LM>w#w-d1t2605-10</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m119-d1t2605-11">
   <w.rf>
    <LM>w#w-d1t2605-11</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1t2605-12">
   <w.rf>
    <LM>w#w-d1t2605-12</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1e2585-x3-661">
   <w.rf>
    <LM>w#w-d1e2585-x3-661</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-662">
  <m id="m119-d1t2605-15">
   <w.rf>
    <LM>w#w-d1t2605-15</LM>
   </w.rf>
   <form>Skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2605-16">
   <w.rf>
    <LM>w#w-d1t2605-16</LM>
   </w.rf>
   <form>osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m119-d1t2605-17">
   <w.rf>
    <LM>w#w-d1t2605-17</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m119-d-id182972-punct">
   <w.rf>
    <LM>w#w-d-id182972-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2605-21">
   <w.rf>
    <LM>w#w-d1t2605-21</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m119-d1t2605-25">
   <w.rf>
    <LM>w#w-d1t2605-25</LM>
   </w.rf>
   <form>počítám</form>
   <lemma>počítat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2605-22">
   <w.rf>
    <LM>w#w-d1t2605-22</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2605-24">
   <w.rf>
    <LM>w#w-d1t2605-24</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-d1e2585-x3-527">
   <w.rf>
    <LM>w#w-d1e2585-x3-527</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-538">
  <m id="m119-d1t2612-12">
   <w.rf>
    <LM>w#w-d1t2612-12</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2612-14">
   <w.rf>
    <LM>w#w-d1t2612-14</LM>
   </w.rf>
   <form>palubě</form>
   <lemma>paluba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m119-d1t2612-7">
   <w.rf>
    <LM>w#w-d1t2612-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m119-d1t2612-8">
   <w.rf>
    <LM>w#w-d1t2612-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d1t2612-9">
   <w.rf>
    <LM>w#w-d1t2612-9</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2612-10">
   <w.rf>
    <LM>w#w-d1t2612-10</LM>
   </w.rf>
   <form>1100</form>
   <lemma>1100</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m119-538-539">
   <w.rf>
    <LM>w#w-538-539</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-540">
  <m id="m119-d1t2612-20">
   <w.rf>
    <LM>w#w-d1t2612-20</LM>
   </w.rf>
   <form>Japonci</form>
   <lemma>Japonec_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m119-540-547">
   <w.rf>
    <LM>w#w-540-547</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2612-22">
   <w.rf>
    <LM>w#w-d1t2612-22</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m119-d1t2612-23">
   <w.rf>
    <LM>w#w-d1t2612-23</LM>
   </w.rf>
   <form>možné</form>
   <lemma>možný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m119-d1t2614-1">
   <w.rf>
    <LM>w#w-d1t2614-1</LM>
   </w.rf>
   <form>národy</form>
   <lemma>národ</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m119-540-548">
   <w.rf>
    <LM>w#w-540-548</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-549">
  <m id="m119-d1t2616-1">
   <w.rf>
    <LM>w#w-d1t2616-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2616-2">
   <w.rf>
    <LM>w#w-d1t2616-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-d1t2616-3">
   <w.rf>
    <LM>w#w-d1t2616-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m119-d-id183523-punct">
   <w.rf>
    <LM>w#w-d-id183523-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2616-5">
   <w.rf>
    <LM>w#w-d1t2616-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2616-6">
   <w.rf>
    <LM>w#w-d1t2616-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2616-7">
   <w.rf>
    <LM>w#w-d1t2616-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m119-d1t2616-8">
   <w.rf>
    <LM>w#w-d1t2616-8</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m119-549-550">
   <w.rf>
    <LM>w#w-549-550</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-551">
  <m id="m119-d1t2616-12">
   <w.rf>
    <LM>w#w-d1t2616-12</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2616-13">
   <w.rf>
    <LM>w#w-d1t2616-13</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m119-d1t2616-14">
   <w.rf>
    <LM>w#w-d1t2616-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2616-15">
   <w.rf>
    <LM>w#w-d1t2616-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2616-16">
   <w.rf>
    <LM>w#w-d1t2616-16</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2616-17">
   <w.rf>
    <LM>w#w-d1t2616-17</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d-id183726-punct">
   <w.rf>
    <LM>w#w-d-id183726-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2616-19">
   <w.rf>
    <LM>w#w-d1t2616-19</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2616-20">
   <w.rf>
    <LM>w#w-d1t2616-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2616-21">
   <w.rf>
    <LM>w#w-d1t2616-21</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2616-22">
   <w.rf>
    <LM>w#w-d1t2616-22</LM>
   </w.rf>
   <form>dopadne</form>
   <lemma>dopadnout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m119-d-m-d1e2585-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2585-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2617-x2">
  <m id="m119-d1t2620-1">
   <w.rf>
    <LM>w#w-d1t2620-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2620-2">
   <w.rf>
    <LM>w#w-d1t2620-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m119-d1t2620-3">
   <w.rf>
    <LM>w#w-d1t2620-3</LM>
   </w.rf>
   <form>pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d-id183896-punct">
   <w.rf>
    <LM>w#w-d-id183896-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2621-x2">
  <m id="m119-d1t2624-7">
   <w.rf>
    <LM>w#w-d1t2624-7</LM>
   </w.rf>
   <form>Pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2624-5">
   <w.rf>
    <LM>w#w-d1t2624-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2624-2">
   <w.rf>
    <LM>w#w-d1t2624-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m119-d1t2624-3">
   <w.rf>
    <LM>w#w-d1t2624-3</LM>
   </w.rf>
   <form>Atén</form>
   <lemma>Atény_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m119-d1e2621-x2-557">
   <w.rf>
    <LM>w#w-d1e2621-x2-557</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-558">
  <m id="m119-d1t2624-15">
   <w.rf>
    <LM>w#w-d1t2624-15</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m119-d1t2624-17">
   <w.rf>
    <LM>w#w-d1t2624-17</LM>
   </w.rf>
   <form>přístavu</form>
   <lemma>přístav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m119-d1t2624-11">
   <w.rf>
    <LM>w#w-d1t2624-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2624-12">
   <w.rf>
    <LM>w#w-d1t2624-12</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2628-2">
   <w.rf>
    <LM>w#w-d1t2628-2</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2628-3">
   <w.rf>
    <LM>w#w-d1t2628-3</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m119-558-562">
   <w.rf>
    <LM>w#w-558-562</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-563">
  <m id="m119-563-564">
   <w.rf>
    <LM>w#w-563-564</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2628-7">
   <w.rf>
    <LM>w#w-d1t2628-7</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m119-d1t2628-8">
   <w.rf>
    <LM>w#w-d1t2628-8</LM>
   </w.rf>
   <form>přístav</form>
   <lemma>přístav</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m119-d1t2628-10">
   <w.rf>
    <LM>w#w-d1t2628-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m119-d1t2628-9">
   <w.rf>
    <LM>w#w-d1t2628-9</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2628-11">
   <w.rf>
    <LM>w#w-d1t2628-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2628-12">
   <w.rf>
    <LM>w#w-d1t2628-12</LM>
   </w.rf>
   <form>nevzpomenu</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m119-d-m-d1e2621-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2621-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2629-x2">
  <m id="m119-d1t2632-2">
   <w.rf>
    <LM>w#w-d1t2632-2</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2632-3">
   <w.rf>
    <LM>w#w-d1t2632-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m119-d1t2632-4">
   <w.rf>
    <LM>w#w-d1t2632-4</LM>
   </w.rf>
   <form>pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d-id184513-punct">
   <w.rf>
    <LM>w#w-d-id184513-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2633-x2">
  <m id="m119-d1t2640-6">
   <w.rf>
    <LM>w#w-d1t2640-6</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2640-5">
   <w.rf>
    <LM>w#w-d1t2640-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2642-4">
   <w.rf>
    <LM>w#w-d1t2642-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m119-d1t2642-6">
   <w.rf>
    <LM>w#w-d1t2642-6</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m119-d1t2640-7">
   <w.rf>
    <LM>w#w-d1t2640-7</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m119-d1e2633-x2-575">
   <w.rf>
    <LM>w#w-d1e2633-x2-575</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2647-2">
   <w.rf>
    <LM>w#w-d1t2647-2</LM>
   </w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m119-d1e2633-x2-576">
   <w.rf>
    <LM>w#w-d1e2633-x2-576</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1e2633-x2-577">
   <w.rf>
    <LM>w#w-d1e2633-x2-577</LM>
   </w.rf>
   <form>nelítali</form>
   <lemma>lítat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m119-d1e2633-x2-578">
   <w.rf>
    <LM>w#w-d1e2633-x2-578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-579">
  <m id="m119-d1t2653-8">
   <w.rf>
    <LM>w#w-d1t2653-8</LM>
   </w.rf>
   <form>Přístav</form>
   <lemma>přístav</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m119-579-682">
   <w.rf>
    <LM>w#w-579-682</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-579-683">
   <w.rf>
    <LM>w#w-579-683</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m119-579-684">
   <w.rf>
    <LM>w#w-579-684</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m119-d1t2649-3">
   <w.rf>
    <LM>w#w-d1t2649-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2649-2">
   <w.rf>
    <LM>w#w-d1t2649-2</LM>
   </w.rf>
   <form>pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d-id185029-punct">
   <w.rf>
    <LM>w#w-d-id185029-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2653-3">
   <w.rf>
    <LM>w#w-d1t2653-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2653-5">
   <w.rf>
    <LM>w#w-d1t2653-5</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m119-579-680">
   <w.rf>
    <LM>w#w-579-680</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2653-6">
   <w.rf>
    <LM>w#w-d1t2653-6</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-579-681">
   <w.rf>
    <LM>w#w-579-681</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2651-2">
   <w.rf>
    <LM>w#w-d1t2651-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Brindisi</form>
   <lemma>Brindisi_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m119-579-580">
   <w.rf>
    <LM>w#w-579-580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-581">
  <m id="m119-d1t2655-3">
   <w.rf>
    <LM>w#w-d1t2655-3</LM>
   </w.rf>
   <form>Napoví</form>
   <lemma>napovědět</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m119-d1t2655-4">
   <w.rf>
    <LM>w#w-d1t2655-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m119-d1t2655-5">
   <w.rf>
    <LM>w#w-d1t2655-5</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m119-d-id185223-punct">
   <w.rf>
    <LM>w#w-d-id185223-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-703">
  <m id="m119-d1t2655-8">
   <w.rf>
    <LM>w#w-d1t2655-8</LM>
   </w.rf>
   <form>Nenapoví</form>
   <lemma>napovědět</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m119-d1e2633-x3-593">
   <w.rf>
    <LM>w#w-d1e2633-x3-593</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-594">
  <m id="m119-d1t2657-7">
   <w.rf>
    <LM>w#w-d1t2657-7</LM>
   </w.rf>
   <form>Odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2657-8">
   <w.rf>
    <LM>w#w-d1t2657-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2657-9">
   <w.rf>
    <LM>w#w-d1t2657-9</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2660-1">
   <w.rf>
    <LM>w#w-d1t2660-1</LM>
   </w.rf>
   <form>pluli</form>
   <lemma>plout</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2660-2">
   <w.rf>
    <LM>w#w-d1t2660-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2660-4">
   <w.rf>
    <LM>w#w-d1t2660-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m119-d1t2660-7">
   <w.rf>
    <LM>w#w-d1t2660-7</LM>
   </w.rf>
   <form>Řecka</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2633-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2633-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2661-x2">
  <m id="m119-d1t2664-1">
   <w.rf>
    <LM>w#w-d1t2664-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2664-2">
   <w.rf>
    <LM>w#w-d1t2664-2</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m119-d1t2664-3">
   <w.rf>
    <LM>w#w-d1t2664-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2664-4">
   <w.rf>
    <LM>w#w-d1t2664-4</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m119-d1t2664-5">
   <w.rf>
    <LM>w#w-d1t2664-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d-id185663-punct">
   <w.rf>
    <LM>w#w-d-id185663-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2665-x2">
  <m id="m119-d1t2668-5">
   <w.rf>
    <LM>w#w-d1t2668-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2668-6">
   <w.rf>
    <LM>w#w-d1t2668-6</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m119-d1t2668-11">
   <w.rf>
    <LM>w#w-d1t2668-11</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2668-10">
   <w.rf>
    <LM>w#w-d1t2668-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2668-12">
   <w.rf>
    <LM>w#w-d1t2668-12</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m119-d1t2668-13">
   <w.rf>
    <LM>w#w-d1t2668-13</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2665-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2665-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2669-x2">
  <m id="m119-d1t2672-1">
   <w.rf>
    <LM>w#w-d1t2672-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m119-d-m-d1e2669-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2669-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2673-x2">
  <m id="m119-d1t2676-1">
   <w.rf>
    <LM>w#w-d1t2676-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d-m-d1e2673-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2673-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2677-x2">
  <m id="m119-d1t2680-1">
   <w.rf>
    <LM>w#w-d1t2680-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m119-d1t2680-2">
   <w.rf>
    <LM>w#w-d1t2680-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m119-d1t2680-3">
   <w.rf>
    <LM>w#w-d1t2680-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2680-4">
   <w.rf>
    <LM>w#w-d1t2680-4</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m119-d1t2680-5">
   <w.rf>
    <LM>w#w-d1t2680-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2677-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2677-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2681-x2">
  <m id="m119-d1t2684-1">
   <w.rf>
    <LM>w#w-d1t2684-1</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m119-d-m-d1e2681-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2681-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2686-x2">
  <m id="m119-d1t2689-1">
   <w.rf>
    <LM>w#w-d1t2689-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m119-d1t2689-2">
   <w.rf>
    <LM>w#w-d1t2689-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2689-3">
   <w.rf>
    <LM>w#w-d1t2689-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m119-d1t2689-4">
   <w.rf>
    <LM>w#w-d1t2689-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m119-d1t2689-5">
   <w.rf>
    <LM>w#w-d1t2689-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m119-d-id186378-punct">
   <w.rf>
    <LM>w#w-d-id186378-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2690-x2">
  <m id="m119-d1t2695-3">
   <w.rf>
    <LM>w#w-d1t2695-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2695-4">
   <w.rf>
    <LM>w#w-d1t2695-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2695-5">
   <w.rf>
    <LM>w#w-d1t2695-5</LM>
   </w.rf>
   <form>promoce</form>
   <lemma>promoce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d1t2695-6">
   <w.rf>
    <LM>w#w-d1t2695-6</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1-------</tag>
  </m>
  <m id="m119-d1t2695-7">
   <w.rf>
    <LM>w#w-d1t2695-7</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m119-d1t2695-8">
   <w.rf>
    <LM>w#w-d1t2695-8</LM>
   </w.rf>
   <form>vnučky</form>
   <lemma>vnučka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m119-d1e2690-x2-600">
   <w.rf>
    <LM>w#w-d1e2690-x2-600</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-601">
  <m id="m119-d1t2697-4">
   <w.rf>
    <LM>w#w-d1t2697-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2697-5">
   <w.rf>
    <LM>w#w-d1t2697-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2697-6">
   <w.rf>
    <LM>w#w-d1t2697-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m119-d1t2697-7">
   <w.rf>
    <LM>w#w-d1t2697-7</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d1t2697-8">
   <w.rf>
    <LM>w#w-d1t2697-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2697-9">
   <w.rf>
    <LM>w#w-d1t2697-9</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m119-d1t2697-10">
   <w.rf>
    <LM>w#w-d1t2697-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m119-d1t2697-11">
   <w.rf>
    <LM>w#w-d1t2697-11</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m119-601-602">
   <w.rf>
    <LM>w#w-601-602</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-603">
  <m id="m119-d1t2697-13">
   <w.rf>
    <LM>w#w-d1t2697-13</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m119-d1t2697-14">
   <w.rf>
    <LM>w#w-d1t2697-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2697-18">
   <w.rf>
    <LM>w#w-d1t2697-18</LM>
   </w.rf>
   <form>stojím</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2697-19">
   <w.rf>
    <LM>w#w-d1t2697-19</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d1t2697-16">
   <w.rf>
    <LM>w#w-d1t2697-16</LM>
   </w.rf>
   <form>hrdě</form>
   <lemma>hrdě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m119-d-id186875-punct">
   <w.rf>
    <LM>w#w-d-id186875-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-d1t2697-22">
   <w.rf>
    <LM>w#w-d1t2697-22</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m119-d1t2697-23">
   <w.rf>
    <LM>w#w-d1t2697-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2697-24">
   <w.rf>
    <LM>w#w-d1t2697-24</LM>
   </w.rf>
   <form>samozřejmé</form>
   <lemma>samozřejmý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m119-603-604">
   <w.rf>
    <LM>w#w-603-604</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-605">
  <m id="m119-d1t2701-2">
   <w.rf>
    <LM>w#w-d1t2701-2</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m119-d1t2701-1">
   <w.rf>
    <LM>w#w-d1t2701-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m119-d1t2701-3">
   <w.rf>
    <LM>w#w-d1t2701-3</LM>
   </w.rf>
   <form>velkou</form>
   <lemma>velký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m119-d1t2701-4">
   <w.rf>
    <LM>w#w-d1t2701-4</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-605-606">
   <w.rf>
    <LM>w#w-605-606</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-607">
  <m id="m119-d1t2701-5">
   <w.rf>
    <LM>w#w-d1t2701-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2701-6">
   <w.rf>
    <LM>w#w-d1t2701-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2701-7">
   <w.rf>
    <LM>w#w-d1t2701-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2701-8">
   <w.rf>
    <LM>w#w-d1t2701-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2701-10">
   <w.rf>
    <LM>w#w-d1t2701-10</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m119-d1t2701-11">
   <w.rf>
    <LM>w#w-d1t2701-11</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m119-d1t2701-12">
   <w.rf>
    <LM>w#w-d1t2701-12</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m119-d1t2701-13">
   <w.rf>
    <LM>w#w-d1t2701-13</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d-m-d1e2690-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2690-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2705-x2">
  <m id="m119-d1t2708-1">
   <w.rf>
    <LM>w#w-d1t2708-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m119-d1t2708-2">
   <w.rf>
    <LM>w#w-d1t2708-2</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m119-d1t2708-3">
   <w.rf>
    <LM>w#w-d1t2708-3</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m119-d1t2708-4">
   <w.rf>
    <LM>w#w-d1t2708-4</LM>
   </w.rf>
   <form>vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m119-d-id187296-punct">
   <w.rf>
    <LM>w#w-d-id187296-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-d1e2711-x2">
  <m id="m119-d1t2716-1">
   <w.rf>
    <LM>w#w-d1t2716-1</LM>
   </w.rf>
   <form>Bakaláře</form>
   <lemma>bakalář</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m119-d1e2711-x2-617">
   <w.rf>
    <LM>w#w-d1e2711-x2-617</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-618">
  <m id="m119-d1t2716-2">
   <w.rf>
    <LM>w#w-d1t2716-2</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2716-3">
   <w.rf>
    <LM>w#w-d1t2716-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-618-619">
   <w.rf>
    <LM>w#w-618-619</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-620">
  <m id="m119-d1t2718-4">
   <w.rf>
    <LM>w#w-d1t2718-4</LM>
   </w.rf>
   <form>Dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2720-9">
   <w.rf>
    <LM>w#w-d1t2720-9</LM>
   </w.rf>
   <form>Filosofickou</form>
   <lemma>filosofický_,s_^(^DD**filozofický)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m119-d1t2720-10">
   <w.rf>
    <LM>w#w-d1t2720-10</LM>
   </w.rf>
   <form>fakultu</form>
   <lemma>fakulta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-620-629">
   <w.rf>
    <LM>w#w-620-629</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m119-620-718">
   <w.rf>
    <LM>w#w-620-718</LM>
   </w.rf>
   <form>informatiku</form>
   <lemma>informatika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-620-1651">
   <w.rf>
    <LM>w#w-620-1651</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2722-2">
   <w.rf>
    <LM>w#w-d1t2722-2</LM>
   </w.rf>
   <form>knihovnictví</form>
   <lemma>knihovnictví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m119-620-630">
   <w.rf>
    <LM>w#w-620-630</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-631">
  <m id="m119-d1t2722-5">
   <w.rf>
    <LM>w#w-d1t2722-5</LM>
   </w.rf>
   <form>Studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2722-6">
   <w.rf>
    <LM>w#w-d1t2722-6</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d-id187837-punct">
   <w.rf>
    <LM>w#w-d-id187837-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m119-d1t2725-3">
   <w.rf>
    <LM>w#w-d1t2725-3</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m119-d1t2722-9">
   <w.rf>
    <LM>w#w-d1t2722-9</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m119-d1t2722-10">
   <w.rf>
    <LM>w#w-d1t2722-10</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m119-d1t2722-11">
   <w.rf>
    <LM>w#w-d1t2722-11</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m119-d1t2722-12">
   <w.rf>
    <LM>w#w-d1t2722-12</LM>
   </w.rf>
   <form>promoci</form>
   <lemma>promoce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-d1t2725-1">
   <w.rf>
    <LM>w#w-d1t2725-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m119-d1t2725-2">
   <w.rf>
    <LM>w#w-d1t2725-2</LM>
   </w.rf>
   <form>magistru</form>
   <lemma>magistra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m119-631-632">
   <w.rf>
    <LM>w#w-631-632</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-633">
  <m id="m119-d1t2729-3">
   <w.rf>
    <LM>w#w-d1t2729-3</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2729-4">
   <w.rf>
    <LM>w#w-d1t2729-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m119-d1t2729-5">
   <w.rf>
    <LM>w#w-d1t2729-5</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m119-633-635">
   <w.rf>
    <LM>w#w-633-635</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-636">
  <m id="m119-d1t2731-8">
   <w.rf>
    <LM>w#w-d1t2731-8</LM>
   </w.rf>
   <form>Snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2731-9">
   <w.rf>
    <LM>w#w-d1t2731-9</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m119-d1t2731-10">
   <w.rf>
    <LM>w#w-d1t2731-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2731-11">
   <w.rf>
    <LM>w#w-d1t2731-11</LM>
   </w.rf>
   <form>baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-636-638">
   <w.rf>
    <LM>w#w-636-638</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m119-639">
  <m id="m119-d1t2733-2">
   <w.rf>
    <LM>w#w-d1t2733-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m119-d1t2733-4">
   <w.rf>
    <LM>w#w-d1t2733-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m119-d1t2733-3">
   <w.rf>
    <LM>w#w-d1t2733-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m119-d1t2733-5">
   <w.rf>
    <LM>w#w-d1t2733-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m119-d-m-d1e2711-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2711-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
