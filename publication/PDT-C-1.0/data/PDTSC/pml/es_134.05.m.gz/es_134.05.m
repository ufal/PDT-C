<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_134.05.w.gz" />
  </references>
 </head>
 <s id="m134-54">
  <m id="m134-d1t635-4">
   <w.rf>
    <LM>w#w-d1t635-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t635-3">
   <w.rf>
    <LM>w#w-d1t635-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t635-5">
   <w.rf>
    <LM>w#w-d1t635-5</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t635-6">
   <w.rf>
    <LM>w#w-d1t635-6</LM>
   </w.rf>
   <form>potvora</form>
   <lemma>potvora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id114182-punct">
   <w.rf>
    <LM>w#w-d-id114182-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t635-10">
   <w.rf>
    <LM>w#w-d1t635-10</LM>
   </w.rf>
   <form>nevypadala</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m134-d1t635-9">
   <w.rf>
    <LM>w#w-d1t635-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t635-12">
   <w.rf>
    <LM>w#w-d1t635-12</LM>
   </w.rf>
   <form>nejhůř</form>
   <lemma>hůře</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m134-54-59">
   <w.rf>
    <LM>w#w-54-59</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-53">
  <m id="m134-d1t637-1">
   <w.rf>
    <LM>w#w-d1t637-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t637-2">
   <w.rf>
    <LM>w#w-d1t637-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t637-3">
   <w.rf>
    <LM>w#w-d1t637-3</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t637-4">
   <w.rf>
    <LM>w#w-d1t637-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t637-5">
   <w.rf>
    <LM>w#w-d1t637-5</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d-id114361-punct">
   <w.rf>
    <LM>w#w-d-id114361-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t637-7">
   <w.rf>
    <LM>w#w-d1t637-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t637-8">
   <w.rf>
    <LM>w#w-d1t637-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t637-9">
   <w.rf>
    <LM>w#w-d1t637-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t637-10">
   <w.rf>
    <LM>w#w-d1t637-10</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t637-11">
   <w.rf>
    <LM>w#w-d1t637-11</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-53-61">
   <w.rf>
    <LM>w#w-53-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-51">
  <m id="m134-d1t641-8">
   <w.rf>
    <LM>w#w-d1t641-8</LM>
   </w.rf>
   <form>Kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-51-94">
   <w.rf>
    <LM>w#w-51-94</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t641-9">
   <w.rf>
    <LM>w#w-d1t641-9</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m134-d1t641-10">
   <w.rf>
    <LM>w#w-d1t641-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t641-11">
   <w.rf>
    <LM>w#w-d1t641-11</LM>
   </w.rf>
   <form>nadbíhali</form>
   <lemma>nadbíhat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d-id114636-punct">
   <w.rf>
    <LM>w#w-d-id114636-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t641-15">
   <w.rf>
    <LM>w#w-d1t641-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t641-16">
   <w.rf>
    <LM>w#w-d1t641-16</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t641-17">
   <w.rf>
    <LM>w#w-d1t641-17</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t641-18">
   <w.rf>
    <LM>w#w-d1t641-18</LM>
   </w.rf>
   <form>nelíbili</form>
   <lemma>líbit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m134-d1t641-19">
   <w.rf>
    <LM>w#w-d1t641-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t641-20">
   <w.rf>
    <LM>w#w-d1t641-20</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m134-d1t641-27">
   <w.rf>
    <LM>w#w-d1t641-27</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t641-22">
   <w.rf>
    <LM>w#w-d1t641-22</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t641-28">
   <w.rf>
    <LM>w#w-d1t641-28</LM>
   </w.rf>
   <form>držel</form>
   <lemma>držet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t641-29">
   <w.rf>
    <LM>w#w-d1t641-29</LM>
   </w.rf>
   <form>odstup</form>
   <lemma>odstup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-51-95">
   <w.rf>
    <LM>w#w-51-95</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-93">
  <m id="m134-d1t641-32">
   <w.rf>
    <LM>w#w-d1t641-32</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m134-d1t641-33">
   <w.rf>
    <LM>w#w-d1t641-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t641-35">
   <w.rf>
    <LM>w#w-d1t641-35</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t641-36">
   <w.rf>
    <LM>w#w-d1t641-36</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t641-37">
   <w.rf>
    <LM>w#w-d1t641-37</LM>
   </w.rf>
   <form>vadilo</form>
   <lemma>vadit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d-id115018-punct">
   <w.rf>
    <LM>w#w-d-id115018-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t641-39">
   <w.rf>
    <LM>w#w-d1t641-39</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t641-40">
   <w.rf>
    <LM>w#w-d1t641-40</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t641-41">
   <w.rf>
    <LM>w#w-d1t641-41</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t641-42">
   <w.rf>
    <LM>w#w-d1t641-42</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m134-d1t641-43">
   <w.rf>
    <LM>w#w-d1t641-43</LM>
   </w.rf>
   <form>snažila</form>
   <lemma>snažit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t641-44">
   <w.rf>
    <LM>w#w-d1t641-44</LM>
   </w.rf>
   <form>získat</form>
   <lemma>získat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d-id115120-punct">
   <w.rf>
    <LM>w#w-d-id115120-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t641-46">
   <w.rf>
    <LM>w#w-d1t641-46</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m134-d1t641-47">
   <w.rf>
    <LM>w#w-d1t641-47</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t641-48">
   <w.rf>
    <LM>w#w-d1t641-48</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t641-49">
   <w.rf>
    <LM>w#w-d1t641-49</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t641-50">
   <w.rf>
    <LM>w#w-d1t641-50</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-93-100">
   <w.rf>
    <LM>w#w-93-100</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-92">
  <m id="m134-d1t644-1">
   <w.rf>
    <LM>w#w-d1t644-1</LM>
   </w.rf>
   <form>Žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t644-2">
   <w.rf>
    <LM>w#w-d1t644-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t644-3">
   <w.rf>
    <LM>w#w-d1t644-3</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t644-4">
   <w.rf>
    <LM>w#w-d1t644-4</LM>
   </w.rf>
   <form>jedenáct</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m134-d1t644-5">
   <w.rf>
    <LM>w#w-d1t644-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m134-92-116">
   <w.rf>
    <LM>w#w-92-116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-115">
  <m id="m134-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t646-6">
   <w.rf>
    <LM>w#w-d1t646-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t646-7">
   <w.rf>
    <LM>w#w-d1t646-7</LM>
   </w.rf>
   <form>rozvedl</form>
   <lemma>rozvést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d-id115422-punct">
   <w.rf>
    <LM>w#w-d-id115422-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t646-9">
   <w.rf>
    <LM>w#w-d1t646-9</LM>
   </w.rf>
   <form>našel</form>
   <lemma>najít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t646-10">
   <w.rf>
    <LM>w#w-d1t646-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t646-11">
   <w.rf>
    <LM>w#w-d1t646-11</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m134-115-118">
   <w.rf>
    <LM>w#w-115-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-114">
  <m id="m134-d1t648-3">
   <w.rf>
    <LM>w#w-d1t648-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t648-4">
   <w.rf>
    <LM>w#w-d1t648-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-5">
   <w.rf>
    <LM>w#w-d1t648-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t648-6">
   <w.rf>
    <LM>w#w-d1t648-6</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t648-7">
   <w.rf>
    <LM>w#w-d1t648-7</LM>
   </w.rf>
   <form>odstěhovala</form>
   <lemma>odstěhovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-114-190">
   <w.rf>
    <LM>w#w-114-190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-132">
  <m id="m134-d1t648-11">
   <w.rf>
    <LM>w#w-d1t648-11</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t648-10">
   <w.rf>
    <LM>w#w-d1t648-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-12">
   <w.rf>
    <LM>w#w-d1t648-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t648-14">
   <w.rf>
    <LM>w#w-d1t648-14</LM>
   </w.rf>
   <form>Krkově</form>
   <lemma>Krkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d-id115705-punct">
   <w.rf>
    <LM>w#w-d-id115705-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t648-17">
   <w.rf>
    <LM>w#w-d1t648-17</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t648-18">
   <w.rf>
    <LM>w#w-d1t648-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-19">
   <w.rf>
    <LM>w#w-d1t648-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t648-20">
   <w.rf>
    <LM>w#w-d1t648-20</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t648-21">
   <w.rf>
    <LM>w#w-d1t648-21</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m134-d1t648-22">
   <w.rf>
    <LM>w#w-d1t648-22</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-d1t648-23">
   <w.rf>
    <LM>w#w-d1t648-23</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t648-25">
   <w.rf>
    <LM>w#w-d1t648-25</LM>
   </w.rf>
   <form>Opočna</form>
   <lemma>Opočno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-132-199">
   <w.rf>
    <LM>w#w-132-199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t648-27">
   <w.rf>
    <LM>w#w-d1t648-27</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t648-28">
   <w.rf>
    <LM>w#w-d1t648-28</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-29">
   <w.rf>
    <LM>w#w-d1t648-29</LM>
   </w.rf>
   <form>budovali</form>
   <lemma>budovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t648-30">
   <w.rf>
    <LM>w#w-d1t648-30</LM>
   </w.rf>
   <form>domeček</form>
   <lemma>domeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-132-801">
   <w.rf>
    <LM>w#w-132-801</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-803">
  <m id="m134-d1t648-33">
   <w.rf>
    <LM>w#w-d1t648-33</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t648-34">
   <w.rf>
    <LM>w#w-d1t648-34</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-35">
   <w.rf>
    <LM>w#w-d1t648-35</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t648-36">
   <w.rf>
    <LM>w#w-d1t648-36</LM>
   </w.rf>
   <form>rozvedli</form>
   <lemma>rozvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-d1t648-37">
   <w.rf>
    <LM>w#w-d1t648-37</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t648-40">
   <w.rf>
    <LM>w#w-d1t648-40</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m134-d1t648-38">
   <w.rf>
    <LM>w#w-d1t648-38</LM>
   </w.rf>
   <form>1973</form>
   <lemma>1973</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-132-200">
   <w.rf>
    <LM>w#w-132-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-133">
  <m id="m134-d1t648-44">
   <w.rf>
    <LM>w#w-d1t648-44</LM>
   </w.rf>
   <form>Odešla</form>
   <lemma>odejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t648-43">
   <w.rf>
    <LM>w#w-d1t648-43</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t648-45">
   <w.rf>
    <LM>w#w-d1t648-45</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t648-47">
   <w.rf>
    <LM>w#w-d1t648-47</LM>
   </w.rf>
   <form>Opočna</form>
   <lemma>Opočno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-133-204">
   <w.rf>
    <LM>w#w-133-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-157">
  <m id="m134-d1t650-1">
   <w.rf>
    <LM>w#w-d1t650-1</LM>
   </w.rf>
   <form>Pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t650-2">
   <w.rf>
    <LM>w#w-d1t650-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t650-3">
   <w.rf>
    <LM>w#w-d1t650-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t650-5">
   <w.rf>
    <LM>w#w-d1t650-5</LM>
   </w.rf>
   <form>Pleši</form>
   <lemma>Pleš_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t650-10">
   <w.rf>
    <LM>w#w-d1t650-10</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t650-8">
   <w.rf>
    <LM>w#w-d1t650-8</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m134-d1t650-9">
   <w.rf>
    <LM>w#w-d1t650-9</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id116326-punct">
   <w.rf>
    <LM>w#w-d-id116326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t650-12">
   <w.rf>
    <LM>w#w-d1t650-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t650-13">
   <w.rf>
    <LM>w#w-d1t650-13</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t650-14">
   <w.rf>
    <LM>w#w-d1t650-14</LM>
   </w.rf>
   <form>dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-d1t650-16">
   <w.rf>
    <LM>w#w-d1t650-16</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m134-d1t650-15">
   <w.rf>
    <LM>w#w-d1t650-15</LM>
   </w.rf>
   <form>ubytovnu</form>
   <lemma>ubytovna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-157-814">
   <w.rf>
    <LM>w#w-157-814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-819">
  <m id="m134-d1t650-18">
   <w.rf>
    <LM>w#w-d1t650-18</LM>
   </w.rf>
   <form>Nesplňovalo</form>
   <lemma>splňovat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d1t650-19">
   <w.rf>
    <LM>w#w-d1t650-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t650-21">
   <w.rf>
    <LM>w#w-d1t650-21</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSNS4-S1-------</tag>
  </m>
  <m id="m134-d1t650-23">
   <w.rf>
    <LM>w#w-d1t650-23</LM>
   </w.rf>
   <form>nároky</form>
   <lemma>nárok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t650-24">
   <w.rf>
    <LM>w#w-d1t650-24</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t650-25">
   <w.rf>
    <LM>w#w-d1t650-25</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d-id116552-punct">
   <w.rf>
    <LM>w#w-d-id116552-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t650-27">
   <w.rf>
    <LM>w#w-d1t650-27</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m134-d1t650-28">
   <w.rf>
    <LM>w#w-d1t650-28</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t650-29">
   <w.rf>
    <LM>w#w-d1t650-29</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t650-30">
   <w.rf>
    <LM>w#w-d1t650-30</LM>
   </w.rf>
   <form>starat</form>
   <lemma>starat_^(se)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t650-31">
   <w.rf>
    <LM>w#w-d1t650-31</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t650-32">
   <w.rf>
    <LM>w#w-d1t650-32</LM>
   </w.rf>
   <form>syny</form>
   <lemma>syn</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-d1t650-33">
   <w.rf>
    <LM>w#w-d1t650-33</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t650-35">
   <w.rf>
    <LM>w#w-d1t650-35</LM>
   </w.rf>
   <form>slušně</form>
   <lemma>slušně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t650-34">
   <w.rf>
    <LM>w#w-d1t650-34</LM>
   </w.rf>
   <form>bydlet</form>
   <lemma>bydlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-157-213">
   <w.rf>
    <LM>w#w-157-213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-159">
  <m id="m134-d1t650-38">
   <w.rf>
    <LM>w#w-d1t650-38</LM>
   </w.rf>
   <form>Synové</form>
   <lemma>syn</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-d1t650-39">
   <w.rf>
    <LM>w#w-d1t650-39</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t650-40">
   <w.rf>
    <LM>w#w-d1t650-40</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-d1t650-41">
   <w.rf>
    <LM>w#w-d1t650-41</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t650-42">
   <w.rf>
    <LM>w#w-d1t650-42</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t650-44">
   <w.rf>
    <LM>w#w-d1t650-44</LM>
   </w.rf>
   <form>Opočna</form>
   <lemma>Opočno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-d-id116835-punct">
   <w.rf>
    <LM>w#w-d-id116835-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t650-47">
   <w.rf>
    <LM>w#w-d1t650-47</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t650-48">
   <w.rf>
    <LM>w#w-d1t650-48</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t650-53">
   <w.rf>
    <LM>w#w-d1t650-53</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t650-54">
   <w.rf>
    <LM>w#w-d1t650-54</LM>
   </w.rf>
   <form>sloužit</form>
   <lemma>sloužit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t650-55">
   <w.rf>
    <LM>w#w-d1t650-55</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t650-56">
   <w.rf>
    <LM>w#w-d1t650-56</LM>
   </w.rf>
   <form>Vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m134-d1t650-57">
   <w.rf>
    <LM>w#w-d1t650-57</LM>
   </w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-d1t650-58">
   <w.rf>
    <LM>w#w-d1t650-58</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t650-60">
   <w.rf>
    <LM>w#w-d1t650-60</LM>
   </w.rf>
   <form>Střešovicích</form>
   <lemma>Střešovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m134-159-220">
   <w.rf>
    <LM>w#w-159-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-158">
  <m id="m134-d1t652-3">
   <w.rf>
    <LM>w#w-d1t652-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t652-8">
   <w.rf>
    <LM>w#w-d1t652-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t652-4">
   <w.rf>
    <LM>w#w-d1t652-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t652-6">
   <w.rf>
    <LM>w#w-d1t652-6</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m134-d1t652-7">
   <w.rf>
    <LM>w#w-d1t652-7</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m134-d1t652-10">
   <w.rf>
    <LM>w#w-d1t652-10</LM>
   </w.rf>
   <form>potkala</form>
   <lemma>potkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t652-11">
   <w.rf>
    <LM>w#w-d1t652-11</LM>
   </w.rf>
   <form>dalšího</form>
   <lemma>další</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m134-d1t652-12">
   <w.rf>
    <LM>w#w-d1t652-12</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m134-158-224">
   <w.rf>
    <LM>w#w-158-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-160">
  <m id="m134-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m134-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t654-3">
   <w.rf>
    <LM>w#w-d1t654-3</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d-id117299-punct">
   <w.rf>
    <LM>w#w-d-id117299-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t654-5">
   <w.rf>
    <LM>w#w-d1t654-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t654-6">
   <w.rf>
    <LM>w#w-d1t654-6</LM>
   </w.rf>
   <form>kluky</form>
   <lemma>kluk</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-d1t654-9">
   <w.rf>
    <LM>w#w-d1t654-9</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m134-d1t654-10">
   <w.rf>
    <LM>w#w-d1t654-10</LM>
   </w.rf>
   <form>nezvládnu</form>
   <lemma>zvládnout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m134-d-id117402-punct">
   <w.rf>
    <LM>w#w-d-id117402-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t654-12">
   <w.rf>
    <LM>w#w-d1t654-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t654-13">
   <w.rf>
    <LM>w#w-d1t654-13</LM>
   </w.rf>
   <form>pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t654-14">
   <w.rf>
    <LM>w#w-d1t654-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t654-15">
   <w.rf>
    <LM>w#w-d1t654-15</LM>
   </w.rf>
   <form>nevdám</form>
   <lemma>vdát</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m134-d-id117472-punct">
   <w.rf>
    <LM>w#w-d-id117472-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t654-18">
   <w.rf>
    <LM>w#w-d1t654-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t654-19">
   <w.rf>
    <LM>w#w-d1t654-19</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t654-20">
   <w.rf>
    <LM>w#w-d1t654-20</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m134-d1t654-21">
   <w.rf>
    <LM>w#w-d1t654-21</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m134-160-270">
   <w.rf>
    <LM>w#w-160-270</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-236">
  <m id="m134-d1t654-23">
   <w.rf>
    <LM>w#w-d1t654-23</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m134-d1t654-24">
   <w.rf>
    <LM>w#w-d1t654-24</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t654-25">
   <w.rf>
    <LM>w#w-d1t654-25</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t654-26">
   <w.rf>
    <LM>w#w-d1t654-26</LM>
   </w.rf>
   <form>štíranda</form>
   <lemma>štíranda_,h</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-236-272">
   <w.rf>
    <LM>w#w-236-272</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t654-27">
   <w.rf>
    <LM>w#w-d1t654-27</LM>
   </w.rf>
   <form>autoritativní</form>
   <lemma>autoritativní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t654-28">
   <w.rf>
    <LM>w#w-d1t654-28</LM>
   </w.rf>
   <form>osoba</form>
   <lemma>osoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-236-273">
   <w.rf>
    <LM>w#w-236-273</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t654-30">
   <w.rf>
    <LM>w#w-d1t654-30</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t654-31">
   <w.rf>
    <LM>w#w-d1t654-31</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t654-32">
   <w.rf>
    <LM>w#w-d1t654-32</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t654-33">
   <w.rf>
    <LM>w#w-d1t654-33</LM>
   </w.rf>
   <form>slovo</form>
   <lemma>slovo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d1t654-34">
   <w.rf>
    <LM>w#w-d1t654-34</LM>
   </w.rf>
   <form>poslouchat</form>
   <lemma>poslouchat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-236-274">
   <w.rf>
    <LM>w#w-236-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-240">
  <m id="m134-d1t657-4">
   <w.rf>
    <LM>w#w-d1t657-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t657-2">
   <w.rf>
    <LM>w#w-d1t657-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t657-3">
   <w.rf>
    <LM>w#w-d1t657-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d1t657-5">
   <w.rf>
    <LM>w#w-d1t657-5</LM>
   </w.rf>
   <form>zvyklý</form>
   <lemma>zvyklý_^(*2nout)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m134-d1t657-6">
   <w.rf>
    <LM>w#w-d1t657-6</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t657-7">
   <w.rf>
    <LM>w#w-d1t657-7</LM>
   </w.rf>
   <form>dědečka</form>
   <lemma>dědeček</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m134-d-id117877-punct">
   <w.rf>
    <LM>w#w-d-id117877-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t657-9">
   <w.rf>
    <LM>w#w-d1t657-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t657-10">
   <w.rf>
    <LM>w#w-d1t657-10</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m134-d1t657-11">
   <w.rf>
    <LM>w#w-d1t657-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t657-12">
   <w.rf>
    <LM>w#w-d1t657-12</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t657-13">
   <w.rf>
    <LM>w#w-d1t657-13</LM>
   </w.rf>
   <form>nevadilo</form>
   <lemma>vadit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d-id117963-punct">
   <w.rf>
    <LM>w#w-d-id117963-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t657-15">
   <w.rf>
    <LM>w#w-d1t657-15</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m134-d1t657-16">
   <w.rf>
    <LM>w#w-d1t657-16</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t657-17">
   <w.rf>
    <LM>w#w-d1t657-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t657-18">
   <w.rf>
    <LM>w#w-d1t657-18</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t657-19">
   <w.rf>
    <LM>w#w-d1t657-19</LM>
   </w.rf>
   <form>koukal</form>
   <lemma>koukat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t657-20">
   <w.rf>
    <LM>w#w-d1t657-20</LM>
   </w.rf>
   <form>zbožně</form>
   <lemma>zbožně_^(*1í)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-240-277">
   <w.rf>
    <LM>w#w-240-277</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-241">
  <m id="m134-d1t657-22">
   <w.rf>
    <LM>w#w-d1t657-22</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m134-d1t657-23">
   <w.rf>
    <LM>w#w-d1t657-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t657-24">
   <w.rf>
    <LM>w#w-d1t657-24</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t657-25">
   <w.rf>
    <LM>w#w-d1t657-25</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t657-26">
   <w.rf>
    <LM>w#w-d1t657-26</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t657-27">
   <w.rf>
    <LM>w#w-d1t657-27</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m134-d-id118173-punct">
   <w.rf>
    <LM>w#w-d-id118173-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t657-29">
   <w.rf>
    <LM>w#w-d1t657-29</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t657-30">
   <w.rf>
    <LM>w#w-d1t657-30</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t657-31">
   <w.rf>
    <LM>w#w-d1t657-31</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m134-d1t657-32">
   <w.rf>
    <LM>w#w-d1t657-32</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m134-d1t657-33">
   <w.rf>
    <LM>w#w-d1t657-33</LM>
   </w.rf>
   <form>koukal</form>
   <lemma>koukat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t657-34">
   <w.rf>
    <LM>w#w-d1t657-34</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t657-35">
   <w.rf>
    <LM>w#w-d1t657-35</LM>
   </w.rf>
   <form>zbožně</form>
   <lemma>zbožně_^(*1í)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-241-280">
   <w.rf>
    <LM>w#w-241-280</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-264">
  <m id="m134-d1t657-37">
   <w.rf>
    <LM>w#w-d1t657-37</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t657-38">
   <w.rf>
    <LM>w#w-d1t657-38</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t657-39">
   <w.rf>
    <LM>w#w-d1t657-39</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t657-40">
   <w.rf>
    <LM>w#w-d1t657-40</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t657-41">
   <w.rf>
    <LM>w#w-d1t657-41</LM>
   </w.rf>
   <form>třikrát</form>
   <lemma>třikrát`3</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m134-d1t657-42">
   <w.rf>
    <LM>w#w-d1t657-42</LM>
   </w.rf>
   <form>vdaná</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d-id118392-punct">
   <w.rf>
    <LM>w#w-d-id118392-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t657-44">
   <w.rf>
    <LM>w#w-d1t657-44</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWYS1----------</tag>
  </m>
  <m id="m134-d1t657-45">
   <w.rf>
    <LM>w#w-d1t657-45</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t657-46">
   <w.rf>
    <LM>w#w-d1t657-46</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m134-d1t657-47">
   <w.rf>
    <LM>w#w-d1t657-47</LM>
   </w.rf>
   <form>partnerů</form>
   <lemma>partner</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m134-d1t657-48">
   <w.rf>
    <LM>w#w-d1t657-48</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t657-49">
   <w.rf>
    <LM>w#w-d1t657-49</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m134-d1t657-50">
   <w.rf>
    <LM>w#w-d1t657-50</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t657-51">
   <w.rf>
    <LM>w#w-d1t657-51</LM>
   </w.rf>
   <form>zbožně</form>
   <lemma>zbožně_^(*1í)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t657-52">
   <w.rf>
    <LM>w#w-d1t657-52</LM>
   </w.rf>
   <form>nekoukal</form>
   <lemma>koukat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m134-d1t657-53">
   <w.rf>
    <LM>w#w-d1t657-53</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t657-54">
   <w.rf>
    <LM>w#w-d1t657-54</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m134-d1t657-55">
   <w.rf>
    <LM>w#w-d1t657-55</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t657-56">
   <w.rf>
    <LM>w#w-d1t657-56</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t657-57">
   <w.rf>
    <LM>w#w-d1t657-57</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1-------</tag>
  </m>
  <m id="m134-d1t657-58">
   <w.rf>
    <LM>w#w-d1t657-58</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id118634-punct">
   <w.rf>
    <LM>w#w-d-id118634-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t657-60">
   <w.rf>
    <LM>w#w-d1t657-60</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t657-61">
   <w.rf>
    <LM>w#w-d1t657-61</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t657-62">
   <w.rf>
    <LM>w#w-d1t657-62</LM>
   </w.rf>
   <form>odbočuji</form>
   <lemma>odbočovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m134-264-284">
   <w.rf>
    <LM>w#w-264-284</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-263">
  <m id="m134-d1t659-8">
   <w.rf>
    <LM>w#w-d1t659-8</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t659-10">
   <w.rf>
    <LM>w#w-d1t659-10</LM>
   </w.rf>
   <form>partnerem</form>
   <lemma>partner</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m134-d1t659-4">
   <w.rf>
    <LM>w#w-d1t659-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t659-5">
   <w.rf>
    <LM>w#w-d1t659-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t659-6">
   <w.rf>
    <LM>w#w-d1t659-6</LM>
   </w.rf>
   <form>rozvedli</form>
   <lemma>rozvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m134-263-311">
   <w.rf>
    <LM>w#w-263-311</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t661-1">
   <w.rf>
    <LM>w#w-d1t661-1</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-d1t661-2">
   <w.rf>
    <LM>w#w-d1t661-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t661-3">
   <w.rf>
    <LM>w#w-d1t661-3</LM>
   </w.rf>
   <form>vrátily</form>
   <lemma>vrátit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m134-d1t661-4">
   <w.rf>
    <LM>w#w-d1t661-4</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t661-5">
   <w.rf>
    <LM>w#w-d1t661-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t661-7">
   <w.rf>
    <LM>w#w-d1t661-7</LM>
   </w.rf>
   <form>Opočna</form>
   <lemma>Opočno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-d1t663-1">
   <w.rf>
    <LM>w#w-d1t663-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t663-2">
   <w.rf>
    <LM>w#w-d1t663-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t663-3">
   <w.rf>
    <LM>w#w-d1t663-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t663-4">
   <w.rf>
    <LM>w#w-d1t663-4</LM>
   </w.rf>
   <form>sloužila</form>
   <lemma>sloužit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t663-5">
   <w.rf>
    <LM>w#w-d1t663-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t663-7">
   <w.rf>
    <LM>w#w-d1t663-7</LM>
   </w.rf>
   <form>Vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m134-d1t663-8">
   <w.rf>
    <LM>w#w-d1t663-8</LM>
   </w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-263-312">
   <w.rf>
    <LM>w#w-263-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-297">
  <m id="m134-d1t663-11">
   <w.rf>
    <LM>w#w-d1t663-11</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t663-12">
   <w.rf>
    <LM>w#w-d1t663-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t663-13">
   <w.rf>
    <LM>w#w-d1t663-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t663-14">
   <w.rf>
    <LM>w#w-d1t663-14</LM>
   </w.rf>
   <form>vdala</form>
   <lemma>vdát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d-id119197-punct">
   <w.rf>
    <LM>w#w-d-id119197-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t663-16">
   <w.rf>
    <LM>w#w-d1t663-16</LM>
   </w.rf>
   <form>odstěhovala</form>
   <lemma>odstěhovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t663-17">
   <w.rf>
    <LM>w#w-d1t663-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t663-18">
   <w.rf>
    <LM>w#w-d1t663-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t663-19">
   <w.rf>
    <LM>w#w-d1t663-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t663-21">
   <w.rf>
    <LM>w#w-d1t663-21</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-297-330">
   <w.rf>
    <LM>w#w-297-330</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t665-1">
   <w.rf>
    <LM>w#w-d1t665-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t665-3">
   <w.rf>
    <LM>w#w-d1t665-3</LM>
   </w.rf>
   <form>Libni</form>
   <lemma>Libeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t665-5">
   <w.rf>
    <LM>w#w-d1t665-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t665-6">
   <w.rf>
    <LM>w#w-d1t665-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t665-7">
   <w.rf>
    <LM>w#w-d1t665-7</LM>
   </w.rf>
   <form>vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t665-8">
   <w.rf>
    <LM>w#w-d1t665-8</LM>
   </w.rf>
   <form>podruhé</form>
   <lemma>podruhé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-297-331">
   <w.rf>
    <LM>w#w-297-331</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-329">
  <m id="m134-d1t667-2">
   <w.rf>
    <LM>w#w-d1t667-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t667-3">
   <w.rf>
    <LM>w#w-d1t667-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t667-1">
   <w.rf>
    <LM>w#w-d1t667-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t667-4">
   <w.rf>
    <LM>w#w-d1t667-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t667-5">
   <w.rf>
    <LM>w#w-d1t667-5</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t667-6">
   <w.rf>
    <LM>w#w-d1t667-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t667-7">
   <w.rf>
    <LM>w#w-d1t667-7</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t667-8">
   <w.rf>
    <LM>w#w-d1t667-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t667-9">
   <w.rf>
    <LM>w#w-d1t667-9</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m134-d1t667-10">
   <w.rf>
    <LM>w#w-d1t667-10</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-329-699">
   <w.rf>
    <LM>w#w-329-699</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-698">
  <m id="m134-d1t667-12">
   <w.rf>
    <LM>w#w-d1t667-12</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m134-d1t667-13">
   <w.rf>
    <LM>w#w-d1t667-13</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m134-d1t667-17">
   <w.rf>
    <LM>w#w-d1t667-17</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t667-18">
   <w.rf>
    <LM>w#w-d1t667-18</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m134-d1t667-16">
   <w.rf>
    <LM>w#w-d1t667-16</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t667-14">
   <w.rf>
    <LM>w#w-d1t667-14</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t667-15">
   <w.rf>
    <LM>w#w-d1t667-15</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m134-329-697">
   <w.rf>
    <LM>w#w-329-697</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e668-x2">
  <m id="m134-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m134-d-m-d1e668-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e668-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e668-x3">
  <m id="m134-d1t675-1">
   <w.rf>
    <LM>w#w-d1t675-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t675-2">
   <w.rf>
    <LM>w#w-d1t675-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t675-3">
   <w.rf>
    <LM>w#w-d1t675-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t675-4">
   <w.rf>
    <LM>w#w-d1t675-4</LM>
   </w.rf>
   <form>prvním</form>
   <lemma>první-1</lemma>
   <tag>CrMS7----------</tag>
  </m>
  <m id="m134-d1t675-5">
   <w.rf>
    <LM>w#w-d1t675-5</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m134-d1t675-6">
   <w.rf>
    <LM>w#w-d1t675-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m134-d1t675-7">
   <w.rf>
    <LM>w#w-d1t675-7</LM>
   </w.rf>
   <form>společné</form>
   <lemma>společný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m134-d1t675-8">
   <w.rf>
    <LM>w#w-d1t675-8</LM>
   </w.rf>
   <form>zájmy</form>
   <lemma>zájem</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id119951-punct">
   <w.rf>
    <LM>w#w-d-id119951-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e677-x2">
  <m id="m134-d1t680-3">
   <w.rf>
    <LM>w#w-d1t680-3</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t680-4">
   <w.rf>
    <LM>w#w-d1t680-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t680-5">
   <w.rf>
    <LM>w#w-d1t680-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1e677-x2-350">
   <w.rf>
    <LM>w#w-d1e677-x2-350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-349">
  <m id="m134-d1t682-1">
   <w.rf>
    <LM>w#w-d1t682-1</LM>
   </w.rf>
   <form>Studoval</form>
   <lemma>studovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t682-2">
   <w.rf>
    <LM>w#w-d1t682-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t682-3">
   <w.rf>
    <LM>w#w-d1t682-3</LM>
   </w.rf>
   <form>jedenáctiletce</form>
   <lemma>jedenáctiletka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t682-4">
   <w.rf>
    <LM>w#w-d1t682-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t682-5">
   <w.rf>
    <LM>w#w-d1t682-5</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t682-6">
   <w.rf>
    <LM>w#w-d1t682-6</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t682-7">
   <w.rf>
    <LM>w#w-d1t682-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t682-8">
   <w.rf>
    <LM>w#w-d1t682-8</LM>
   </w.rf>
   <form>chemickou</form>
   <lemma>chemický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d1t682-9">
   <w.rf>
    <LM>w#w-d1t682-9</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-349-868">
   <w.rf>
    <LM>w#w-349-868</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-871">
  <m id="m134-d1t682-11">
   <w.rf>
    <LM>w#w-d1t682-11</LM>
   </w.rf>
   <form>Nedostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m134-d1t682-12">
   <w.rf>
    <LM>w#w-d1t682-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d-id120348-punct">
   <w.rf>
    <LM>w#w-d-id120348-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t682-14">
   <w.rf>
    <LM>w#w-d1t682-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t684-1">
   <w.rf>
    <LM>w#w-d1t684-1</LM>
   </w.rf>
   <form>neudělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m134-d1t684-2">
   <w.rf>
    <LM>w#w-d1t684-2</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t684-3">
   <w.rf>
    <LM>w#w-d1t684-3</LM>
   </w.rf>
   <form>maturitu</form>
   <lemma>maturita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-871-872">
   <w.rf>
    <LM>w#w-871-872</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-873">
  <m id="m134-d1t684-6">
   <w.rf>
    <LM>w#w-d1t684-6</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d-id120483-punct">
   <w.rf>
    <LM>w#w-d-id120483-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t684-8">
   <w.rf>
    <LM>w#w-d1t684-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t684-9">
   <w.rf>
    <LM>w#w-d1t684-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t684-10">
   <w.rf>
    <LM>w#w-d1t684-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t684-11">
   <w.rf>
    <LM>w#w-d1t684-11</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d1t684-12">
   <w.rf>
    <LM>w#w-d1t684-12</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t684-13">
   <w.rf>
    <LM>w#w-d1t684-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t684-14">
   <w.rf>
    <LM>w#w-d1t684-14</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id120600-punct">
   <w.rf>
    <LM>w#w-d-id120600-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t684-16">
   <w.rf>
    <LM>w#w-d1t684-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-349-719">
   <w.rf>
    <LM>w#w-349-719</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t684-18">
   <w.rf>
    <LM>w#w-d1t684-18</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m134-349-358">
   <w.rf>
    <LM>w#w-349-358</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-348">
  <m id="m134-d1t684-21">
   <w.rf>
    <LM>w#w-d1t684-21</LM>
   </w.rf>
   <form>Nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m134-d1t684-22">
   <w.rf>
    <LM>w#w-d1t684-22</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t684-23">
   <w.rf>
    <LM>w#w-d1t684-23</LM>
   </w.rf>
   <form>vyučený</form>
   <lemma>vyučený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m134-348-877">
   <w.rf>
    <LM>w#w-348-877</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-878">
  <m id="m134-d1t686-5">
   <w.rf>
    <LM>w#w-d1t686-5</LM>
   </w.rf>
   <form>Dokopala</form>
   <lemma>dokopat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t686-3">
   <w.rf>
    <LM>w#w-d1t686-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t686-4">
   <w.rf>
    <LM>w#w-d1t686-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m134-d1t686-6">
   <w.rf>
    <LM>w#w-d1t686-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t686-7">
   <w.rf>
    <LM>w#w-d1t686-7</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m134-d-id120850-punct">
   <w.rf>
    <LM>w#w-d-id120850-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t686-9">
   <w.rf>
    <LM>w#w-d1t686-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t686-10">
   <w.rf>
    <LM>w#w-d1t686-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t686-11">
   <w.rf>
    <LM>w#w-d1t686-11</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t686-12">
   <w.rf>
    <LM>w#w-d1t686-12</LM>
   </w.rf>
   <form>vyučil</form>
   <lemma>vyučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-348-363">
   <w.rf>
    <LM>w#w-348-363</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-346">
  <m id="m134-d1t688-8">
   <w.rf>
    <LM>w#w-d1t688-8</LM>
   </w.rf>
   <form>Líbil</form>
   <lemma>líbit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t688-6">
   <w.rf>
    <LM>w#w-d1t688-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t688-7">
   <w.rf>
    <LM>w#w-d1t688-7</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d-id121060-punct">
   <w.rf>
    <LM>w#w-d-id121060-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t688-10">
   <w.rf>
    <LM>w#w-d1t688-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t688-11">
   <w.rf>
    <LM>w#w-d1t688-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t688-12">
   <w.rf>
    <LM>w#w-d1t688-12</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m134-d1t688-13">
   <w.rf>
    <LM>w#w-d1t688-13</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t688-14">
   <w.rf>
    <LM>w#w-d1t688-14</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t688-15">
   <w.rf>
    <LM>w#w-d1t688-15</LM>
   </w.rf>
   <form>dobývat</form>
   <lemma>dobývat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-346-371">
   <w.rf>
    <LM>w#w-346-371</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-370">
  <m id="m134-d1t688-18">
   <w.rf>
    <LM>w#w-d1t688-18</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t688-19">
   <w.rf>
    <LM>w#w-d1t688-19</LM>
   </w.rf>
   <form>lvice</form>
   <lemma>lvice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-m-d1e677-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e677-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e689-x3">
  <m id="m134-d1t698-1">
   <w.rf>
    <LM>w#w-d1t698-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m134-d1e689-x3-375">
   <w.rf>
    <LM>w#w-d1e689-x3-375</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-374">
  <m id="m134-d1t698-3">
   <w.rf>
    <LM>w#w-d1t698-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m134-d1t698-4">
   <w.rf>
    <LM>w#w-d1t698-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t698-5">
   <w.rf>
    <LM>w#w-d1t698-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t698-6">
   <w.rf>
    <LM>w#w-d1t698-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d1t698-7">
   <w.rf>
    <LM>w#w-d1t698-7</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-m-d1e689-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e689-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-793">
  <m id="m134-d1t706-1">
   <w.rf>
    <LM>w#w-d1t706-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m134-d1t706-2">
   <w.rf>
    <LM>w#w-d1t706-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t706-3">
   <w.rf>
    <LM>w#w-d1t706-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t706-4">
   <w.rf>
    <LM>w#w-d1t706-4</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m134-d1t706-5">
   <w.rf>
    <LM>w#w-d1t706-5</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-793-794">
   <w.rf>
    <LM>w#w-793-794</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e699-x2">
  <m id="m134-d1t704-7">
   <w.rf>
    <LM>w#w-d1t704-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t704-8">
   <w.rf>
    <LM>w#w-d1t704-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-d1t704-9">
   <w.rf>
    <LM>w#w-d1t704-9</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m134-d1t704-10">
   <w.rf>
    <LM>w#w-d1t704-10</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m134-d1t704-11">
   <w.rf>
    <LM>w#w-d1t704-11</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m134-d1t704-12">
   <w.rf>
    <LM>w#w-d1t704-12</LM>
   </w.rf>
   <form>synové</form>
   <lemma>syn</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-d1t710-1">
   <w.rf>
    <LM>w#w-d1t710-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>prvním</form>
   <lemma>první-1</lemma>
   <tag>CrMS7----------</tag>
  </m>
  <m id="m134-d1t710-3">
   <w.rf>
    <LM>w#w-d1t710-3</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m134-d-m-d1e699-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e699-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e707-x2">
  <m id="m134-d1t710-8">
   <w.rf>
    <LM>w#w-d1t710-8</LM>
   </w.rf>
   <form>Jaroušek</form>
   <lemma>Jaroušek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t710-10">
   <w.rf>
    <LM>w#w-d1t710-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t710-11">
   <w.rf>
    <LM>w#w-d1t710-11</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m134-d-id121957-punct">
   <w.rf>
    <LM>w#w-d-id121957-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-15">
   <w.rf>
    <LM>w#w-d1t710-15</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t710-14">
   <w.rf>
    <LM>w#w-d1t710-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t710-16">
   <w.rf>
    <LM>w#w-d1t710-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t710-17">
   <w.rf>
    <LM>w#w-d1t710-17</LM>
   </w.rf>
   <form>11</form>
   <lemma>11</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1e707-x2-21">
   <w.rf>
    <LM>w#w-d1e707-x2-21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-18">
   <w.rf>
    <LM>w#w-d1t710-18</LM>
   </w.rf>
   <form>1</form>
   <lemma>1</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1e707-x2-22">
   <w.rf>
    <LM>w#w-d1e707-x2-22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-19">
   <w.rf>
    <LM>w#w-d1t710-19</LM>
   </w.rf>
   <form>1963</form>
   <lemma>1963</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1e707-x2-905">
   <w.rf>
    <LM>w#w-d1e707-x2-905</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-906">
  <m id="m134-d1t710-22">
   <w.rf>
    <LM>w#w-d1t710-22</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m134-d1t710-23">
   <w.rf>
    <LM>w#w-d1t710-23</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m134-d1t710-24">
   <w.rf>
    <LM>w#w-d1t710-24</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t710-25">
   <w.rf>
    <LM>w#w-d1t710-25</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t710-26">
   <w.rf>
    <LM>w#w-d1t710-26</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1e707-x2-23">
   <w.rf>
    <LM>w#w-d1e707-x2-23</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-27">
   <w.rf>
    <LM>w#w-d1t710-27</LM>
   </w.rf>
   <form>9</form>
   <lemma>9</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1e707-x2-24">
   <w.rf>
    <LM>w#w-d1e707-x2-24</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-28">
   <w.rf>
    <LM>w#w-d1t710-28</LM>
   </w.rf>
   <form>1965</form>
   <lemma>1965</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d-id122229-punct">
   <w.rf>
    <LM>w#w-d-id122229-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t710-31">
   <w.rf>
    <LM>w#w-d1t710-31</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t710-32">
   <w.rf>
    <LM>w#w-d1t710-32</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-d1t710-33">
   <w.rf>
    <LM>w#w-d1t710-33</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t710-34">
   <w.rf>
    <LM>w#w-d1t710-34</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t710-35">
   <w.rf>
    <LM>w#w-d1t710-35</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m134-d1e707-x2-25">
   <w.rf>
    <LM>w#w-d1e707-x2-25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-19">
  <m id="m134-d1t710-37">
   <w.rf>
    <LM>w#w-d1t710-37</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t710-38">
   <w.rf>
    <LM>w#w-d1t710-38</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t710-39">
   <w.rf>
    <LM>w#w-d1t710-39</LM>
   </w.rf>
   <form>nádherní</form>
   <lemma>nádherný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m134-d1t710-40">
   <w.rf>
    <LM>w#w-d1t710-40</LM>
   </w.rf>
   <form>blonďatí</form>
   <lemma>blonďatý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m134-d1t710-41">
   <w.rf>
    <LM>w#w-d1t710-41</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-19-26">
   <w.rf>
    <LM>w#w-19-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-20">
  <m id="m134-d1t712-1">
   <w.rf>
    <LM>w#w-d1t712-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t712-2">
   <w.rf>
    <LM>w#w-d1t712-2</LM>
   </w.rf>
   <form>úžasní</form>
   <lemma>úžasný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m134-20-807">
   <w.rf>
    <LM>w#w-20-807</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t712-4">
   <w.rf>
    <LM>w#w-d1t712-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-d1t712-5">
   <w.rf>
    <LM>w#w-d1t712-5</LM>
   </w.rf>
   <form>úžasní</form>
   <lemma>úžasný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m134-d1t712-6">
   <w.rf>
    <LM>w#w-d1t712-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t712-7">
   <w.rf>
    <LM>w#w-d1t712-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t712-8">
   <w.rf>
    <LM>w#w-d1t712-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t712-9">
   <w.rf>
    <LM>w#w-d1t712-9</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t712-10">
   <w.rf>
    <LM>w#w-d1t712-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t712-11">
   <w.rf>
    <LM>w#w-d1t712-11</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m134-d1t712-12">
   <w.rf>
    <LM>w#w-d1t712-12</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m134-d-m-d1e707-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e707-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e713-x2">
  <m id="m134-d1t716-1">
   <w.rf>
    <LM>w#w-d1t716-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m134-d1t716-2">
   <w.rf>
    <LM>w#w-d1t716-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t716-3">
   <w.rf>
    <LM>w#w-d1t716-3</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t716-4">
   <w.rf>
    <LM>w#w-d1t716-4</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m134-d-id122734-punct">
   <w.rf>
    <LM>w#w-d-id122734-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e717-x2">
  <m id="m134-d1t720-2">
   <w.rf>
    <LM>w#w-d1t720-2</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t720-3">
   <w.rf>
    <LM>w#w-d1t720-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t720-4">
   <w.rf>
    <LM>w#w-d1t720-4</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id122858-punct">
   <w.rf>
    <LM>w#w-d-id122858-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t720-6">
   <w.rf>
    <LM>w#w-d1t720-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t720-7">
   <w.rf>
    <LM>w#w-d1t720-7</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m134-d1t720-8">
   <w.rf>
    <LM>w#w-d1t720-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t720-9">
   <w.rf>
    <LM>w#w-d1t720-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t720-10">
   <w.rf>
    <LM>w#w-d1t720-10</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m134-d1t720-11">
   <w.rf>
    <LM>w#w-d1t720-11</LM>
   </w.rf>
   <form>manželství</form>
   <lemma>manželství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-d1e717-x2-30">
   <w.rf>
    <LM>w#w-d1e717-x2-30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t722-1">
   <w.rf>
    <LM>w#w-d1t722-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t722-2">
   <w.rf>
    <LM>w#w-d1t722-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t722-5">
   <w.rf>
    <LM>w#w-d1t722-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t722-6">
   <w.rf>
    <LM>w#w-d1t722-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m134-d1t722-7">
   <w.rf>
    <LM>w#w-d1t722-7</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m134-d1t722-9">
   <w.rf>
    <LM>w#w-d1t722-9</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t722-10">
   <w.rf>
    <LM>w#w-d1t722-10</LM>
   </w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-d-m-d1e717-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e717-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e723-x2">
  <m id="m134-d1t726-1">
   <w.rf>
    <LM>w#w-d1t726-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m134-d1t726-2">
   <w.rf>
    <LM>w#w-d1t726-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t726-3">
   <w.rf>
    <LM>w#w-d1t726-3</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m134-d1t726-4">
   <w.rf>
    <LM>w#w-d1t726-4</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m134-d1t726-5">
   <w.rf>
    <LM>w#w-d1t726-5</LM>
   </w.rf>
   <form>dělají</form>
   <lemma>dělat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-d1t726-6">
   <w.rf>
    <LM>w#w-d1t726-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t726-7">
   <w.rf>
    <LM>w#w-d1t726-7</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d-id123315-punct">
   <w.rf>
    <LM>w#w-d-id123315-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e727-x2">
  <m id="m134-d1t730-4">
   <w.rf>
    <LM>w#w-d1t730-4</LM>
   </w.rf>
   <form>Jára</form>
   <lemma>Jára_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d1t730-6">
   <w.rf>
    <LM>w#w-d1t730-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t730-7">
   <w.rf>
    <LM>w#w-d1t730-7</LM>
   </w.rf>
   <form>vyučil</form>
   <lemma>vyučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t730-8">
   <w.rf>
    <LM>w#w-d1t730-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t730-10">
   <w.rf>
    <LM>w#w-d1t730-10</LM>
   </w.rf>
   <form>Kladně</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d1t730-12">
   <w.rf>
    <LM>w#w-d1t730-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t730-13">
   <w.rf>
    <LM>w#w-d1t730-13</LM>
   </w.rf>
   <form>horník</form>
   <lemma>horník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m134-d-id123551-punct">
   <w.rf>
    <LM>w#w-d-id123551-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t730-15">
   <w.rf>
    <LM>w#w-d1t730-15</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t730-16">
   <w.rf>
    <LM>w#w-d1t730-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t730-17">
   <w.rf>
    <LM>w#w-d1t730-17</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t730-18">
   <w.rf>
    <LM>w#w-d1t730-18</LM>
   </w.rf>
   <form>nástavbu</form>
   <lemma>nástavba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t730-19">
   <w.rf>
    <LM>w#w-d1t730-19</LM>
   </w.rf>
   <form>střelmistra</form>
   <lemma>střelmistr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m134-d1t730-20">
   <w.rf>
    <LM>w#w-d1t730-20</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t730-21">
   <w.rf>
    <LM>w#w-d1t730-21</LM>
   </w.rf>
   <form>dálkově</form>
   <lemma>dálkově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t730-22">
   <w.rf>
    <LM>w#w-d1t730-22</LM>
   </w.rf>
   <form>vystudoval</form>
   <lemma>vystudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1t730-23">
   <w.rf>
    <LM>w#w-d1t730-23</LM>
   </w.rf>
   <form>maturitu</form>
   <lemma>maturita</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1e727-x2-99">
   <w.rf>
    <LM>w#w-d1e727-x2-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-44">
  <m id="m134-d1t732-1">
   <w.rf>
    <LM>w#w-d1t732-1</LM>
   </w.rf>
   <form>Mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t732-2">
   <w.rf>
    <LM>w#w-d1t732-2</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t732-3">
   <w.rf>
    <LM>w#w-d1t732-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t732-4">
   <w.rf>
    <LM>w#w-d1t732-4</LM>
   </w.rf>
   <form>báňskou</form>
   <lemma>báňský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d-id123777-punct">
   <w.rf>
    <LM>w#w-d-id123777-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t732-6">
   <w.rf>
    <LM>w#w-d1t732-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t732-7">
   <w.rf>
    <LM>w#w-d1t732-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t732-8">
   <w.rf>
    <LM>w#w-d1t732-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t732-10">
   <w.rf>
    <LM>w#w-d1t732-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t732-11">
   <w.rf>
    <LM>w#w-d1t732-11</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m134-d1t732-12">
   <w.rf>
    <LM>w#w-d1t732-12</LM>
   </w.rf>
   <form>zájmy</form>
   <lemma>zájem</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id123895-punct">
   <w.rf>
    <LM>w#w-d-id123895-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t732-14">
   <w.rf>
    <LM>w#w-d1t732-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t732-16">
   <w.rf>
    <LM>w#w-d1t732-16</LM>
   </w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m134-d1t732-17">
   <w.rf>
    <LM>w#w-d1t732-17</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t732-18">
   <w.rf>
    <LM>w#w-d1t732-18</LM>
   </w.rf>
   <form>neudělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m134-44-103">
   <w.rf>
    <LM>w#w-44-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-47">
  <m id="m134-d1t734-1">
   <w.rf>
    <LM>w#w-d1t734-1</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t734-4">
   <w.rf>
    <LM>w#w-d1t734-4</LM>
   </w.rf>
   <form>nepracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d1t734-6">
   <w.rf>
    <LM>w#w-d1t734-6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t734-7">
   <w.rf>
    <LM>w#w-d1t734-7</LM>
   </w.rf>
   <form>svém</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS6----------</tag>
  </m>
  <m id="m134-d1t734-8">
   <w.rf>
    <LM>w#w-d1t734-8</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d-id124123-punct">
   <w.rf>
    <LM>w#w-d-id124123-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t736-2">
   <w.rf>
    <LM>w#w-d1t736-2</LM>
   </w.rf>
   <form>pracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t736-5">
   <w.rf>
    <LM>w#w-d1t736-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t736-6">
   <w.rf>
    <LM>w#w-d1t736-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS2----------</tag>
  </m>
  <m id="m134-d1t736-7">
   <w.rf>
    <LM>w#w-d1t736-7</LM>
   </w.rf>
   <form>německé</form>
   <lemma>německý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m134-d1t736-8">
   <w.rf>
    <LM>w#w-d1t736-8</LM>
   </w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-47-107">
   <w.rf>
    <LM>w#w-47-107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t736-9">
   <w.rf>
    <LM>w#w-d1t736-9</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t736-10">
   <w.rf>
    <LM>w#w-d1t736-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t736-12">
   <w.rf>
    <LM>w#w-d1t736-12</LM>
   </w.rf>
   <form>šéfa</form>
   <lemma>šéf</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m134-d1t736-13">
   <w.rf>
    <LM>w#w-d1t736-13</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t738-2">
   <w.rf>
    <LM>w#w-d1t738-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t738-3">
   <w.rf>
    <LM>w#w-d1t738-3</LM>
   </w.rf>
   <form>sklady</form>
   <lemma>sklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t738-4">
   <w.rf>
    <LM>w#w-d1t738-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t738-5">
   <w.rf>
    <LM>w#w-d1t738-5</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t738-6">
   <w.rf>
    <LM>w#w-d1t738-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m134-d1t738-7">
   <w.rf>
    <LM>w#w-d1t738-7</LM>
   </w.rf>
   <form>takového</form>
   <lemma>takový</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m134-47-108">
   <w.rf>
    <LM>w#w-47-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-49">
  <m id="m134-d1t741-1">
   <w.rf>
    <LM>w#w-d1t741-1</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t741-2">
   <w.rf>
    <LM>w#w-d1t741-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t741-4">
   <w.rf>
    <LM>w#w-d1t741-4</LM>
   </w.rf>
   <form>Kladně</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-49-111">
   <w.rf>
    <LM>w#w-49-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e727-x3">
  <m id="m134-d1t743-1">
   <w.rf>
    <LM>w#w-d1t743-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d1t743-2">
   <w.rf>
    <LM>w#w-d1t743-2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m134-d1t743-3">
   <w.rf>
    <LM>w#w-d1t743-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d-id124578-punct">
   <w.rf>
    <LM>w#w-d-id124578-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t743-5">
   <w.rf>
    <LM>w#w-d1t743-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t743-6">
   <w.rf>
    <LM>w#w-d1t743-6</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m134-d1t743-7">
   <w.rf>
    <LM>w#w-d1t743-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t743-8">
   <w.rf>
    <LM>w#w-d1t743-8</LM>
   </w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m134-d1t743-9">
   <w.rf>
    <LM>w#w-d1t743-9</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m134-d1t743-11">
   <w.rf>
    <LM>w#w-d1t743-11</LM>
   </w.rf>
   <form>porazilo</form>
   <lemma>porazit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-d1t743-12">
   <w.rf>
    <LM>w#w-d1t743-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t743-14">
   <w.rf>
    <LM>w#w-d1t743-14</LM>
   </w.rf>
   <form>Kladně</form>
   <lemma>Kladno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d1t743-16">
   <w.rf>
    <LM>w#w-d1t743-16</LM>
   </w.rf>
   <form>auto</form>
   <lemma>auto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d1t743-17">
   <w.rf>
    <LM>w#w-d1t743-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t743-18">
   <w.rf>
    <LM>w#w-d1t743-18</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t743-19">
   <w.rf>
    <LM>w#w-d1t743-19</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t743-20">
   <w.rf>
    <LM>w#w-d1t743-20</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m134-d1e727-x3-936">
   <w.rf>
    <LM>w#w-d1e727-x3-936</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-937">
  <m id="m134-d1t743-22">
   <w.rf>
    <LM>w#w-d1t743-22</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t743-23">
   <w.rf>
    <LM>w#w-d1t743-23</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t743-24">
   <w.rf>
    <LM>w#w-d1t743-24</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t743-25">
   <w.rf>
    <LM>w#w-d1t743-25</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t743-26">
   <w.rf>
    <LM>w#w-d1t743-26</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t743-27">
   <w.rf>
    <LM>w#w-d1t743-27</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m134-d1t743-28">
   <w.rf>
    <LM>w#w-d1t743-28</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-d1t743-36">
   <w.rf>
    <LM>w#w-d1t743-36</LM>
   </w.rf>
   <form>Pavlínce</form>
   <lemma>Pavlínka_;Y</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m134-d1t743-29">
   <w.rf>
    <LM>w#w-d1t743-29</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t743-30">
   <w.rf>
    <LM>w#w-d1t743-30</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t743-31">
   <w.rf>
    <LM>w#w-d1t743-31</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t743-32">
   <w.rf>
    <LM>w#w-d1t743-32</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m134-d1t743-33">
   <w.rf>
    <LM>w#w-d1t743-33</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m134-d1e727-x3-121">
   <w.rf>
    <LM>w#w-d1e727-x3-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
