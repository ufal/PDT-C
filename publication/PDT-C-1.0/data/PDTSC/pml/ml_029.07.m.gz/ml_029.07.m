<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_029.07.w.gz" />
  </references>
 </head>
 <s id="m029-d1e2167-x2">
  <m id="m029-d1t2172-1">
   <w.rf>
    <LM>w#w-d1t2172-1</LM>
   </w.rf>
   <form>Scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m029-d-id124852-punct">
   <w.rf>
    <LM>w#w-d-id124852-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2172-3">
   <w.rf>
    <LM>w#w-d1t2172-3</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2172-4">
   <w.rf>
    <LM>w#w-d1t2172-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m029-d1t2172-5">
   <w.rf>
    <LM>w#w-d1t2172-5</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m029-d1e2167-x2-69">
   <w.rf>
    <LM>w#w-d1e2167-x2-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-70">
  <m id="m029-d1t2172-8">
   <w.rf>
    <LM>w#w-d1t2172-8</LM>
   </w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m029-d1t2172-10">
   <w.rf>
    <LM>w#w-d1t2172-10</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m029-d1t2172-11">
   <w.rf>
    <LM>w#w-d1t2172-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m029-d1t2172-12">
   <w.rf>
    <LM>w#w-d1t2172-12</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m029-d1t2172-13">
   <w.rf>
    <LM>w#w-d1t2172-13</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-70-71">
   <w.rf>
    <LM>w#w-70-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-73">
  <m id="m029-d1t2174-1">
   <w.rf>
    <LM>w#w-d1t2174-1</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2174-3">
   <w.rf>
    <LM>w#w-d1t2174-3</LM>
   </w.rf>
   <form>jedny</form>
   <lemma>jedny`1</lemma>
   <tag>CdFP4----------</tag>
  </m>
  <m id="m029-d1t2174-4">
   <w.rf>
    <LM>w#w-d1t2174-4</LM>
   </w.rf>
   <form>dvojčata</form>
   <lemma>dvojče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m029-73-77">
   <w.rf>
    <LM>w#w-73-77</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2174-5">
   <w.rf>
    <LM>w#w-d1t2174-5</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m029-d1t2174-6">
   <w.rf>
    <LM>w#w-d1t2174-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2174-7">
   <w.rf>
    <LM>w#w-d1t2174-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2174-8">
   <w.rf>
    <LM>w#w-d1t2174-8</LM>
   </w.rf>
   <form>24</form>
   <lemma>24</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m029-d1t2174-10">
   <w.rf>
    <LM>w#w-d1t2174-10</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m029-d-id125150-punct">
   <w.rf>
    <LM>w#w-d-id125150-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2174-13">
   <w.rf>
    <LM>w#w-d1t2174-13</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS6----3A----</tag>
  </m>
  <m id="m029-d1t2174-14">
   <w.rf>
    <LM>w#w-d1t2174-14</LM>
   </w.rf>
   <form>vnučce</form>
   <lemma>vnučka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1t2174-17">
   <w.rf>
    <LM>w#w-d1t2174-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2174-18">
   <w.rf>
    <LM>w#w-d1t2174-18</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m029-d1t2174-19">
   <w.rf>
    <LM>w#w-d1t2174-19</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m029-d-id125276-punct">
   <w.rf>
    <LM>w#w-d-id125276-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2174-22">
   <w.rf>
    <LM>w#w-d1t2174-22</LM>
   </w.rf>
   <form>nejstaršímu</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS3----3A----</tag>
  </m>
  <m id="m029-d1t2174-23">
   <w.rf>
    <LM>w#w-d1t2174-23</LM>
   </w.rf>
   <form>vnukovi</form>
   <lemma>vnuk</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m029-73-78">
   <w.rf>
    <LM>w#w-73-78</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2174-24">
   <w.rf>
    <LM>w#w-d1t2174-24</LM>
   </w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m029-d1t2174-26">
   <w.rf>
    <LM>w#w-d1t2174-26</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2167-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2167-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2189-x2">
  <m id="m029-d1t2192-1">
   <w.rf>
    <LM>w#w-d1t2192-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m029-d1t2192-2">
   <w.rf>
    <LM>w#w-d1t2192-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m029-d1t2192-3">
   <w.rf>
    <LM>w#w-d1t2192-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2194-1">
   <w.rf>
    <LM>w#w-d1t2194-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2194-2">
   <w.rf>
    <LM>w#w-d1t2194-2</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m029-d1t2196-1">
   <w.rf>
    <LM>w#w-d1t2196-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2196-2">
   <w.rf>
    <LM>w#w-d1t2196-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m029-d1t2196-3">
   <w.rf>
    <LM>w#w-d1t2196-3</LM>
   </w.rf>
   <form>oslavy</form>
   <lemma>oslava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d-id125694-punct">
   <w.rf>
    <LM>w#w-d-id125694-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2197-x2">
  <m id="m029-d1t2202-2">
   <w.rf>
    <LM>w#w-d1t2202-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2202-3">
   <w.rf>
    <LM>w#w-d1t2202-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m029-d1t2202-4">
   <w.rf>
    <LM>w#w-d1t2202-4</LM>
   </w.rf>
   <form>oslavy</form>
   <lemma>oslava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d1t2202-5">
   <w.rf>
    <LM>w#w-d1t2202-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2202-6">
   <w.rf>
    <LM>w#w-d1t2202-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2202-7">
   <w.rf>
    <LM>w#w-d1t2202-7</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d-m-d1e2197-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2197-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2205-x2">
  <m id="m029-d1t2210-3">
   <w.rf>
    <LM>w#w-d1t2210-3</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2210-4">
   <w.rf>
    <LM>w#w-d1t2210-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m029-d1t2210-5">
   <w.rf>
    <LM>w#w-d1t2210-5</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d1t2210-1">
   <w.rf>
    <LM>w#w-d1t2210-1</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m029-d1t2210-2">
   <w.rf>
    <LM>w#w-d1t2210-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2212-4">
   <w.rf>
    <LM>w#w-d1t2212-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d-m-d1e2205-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2205-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2205-x3">
  <m id="m029-d1t2214-3">
   <w.rf>
    <LM>w#w-d1t2214-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m029-d1t2214-2">
   <w.rf>
    <LM>w#w-d1t2214-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m029-d1t2214-4">
   <w.rf>
    <LM>w#w-d1t2214-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d-m-d1e2205-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2205-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2216-x2">
  <m id="m029-d1t2219-1">
   <w.rf>
    <LM>w#w-d1t2219-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m029-d1t2219-2">
   <w.rf>
    <LM>w#w-d1t2219-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2219-3">
   <w.rf>
    <LM>w#w-d1t2219-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2219-4">
   <w.rf>
    <LM>w#w-d1t2219-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2219-5">
   <w.rf>
    <LM>w#w-d1t2219-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m029-d-id126256-punct">
   <w.rf>
    <LM>w#w-d-id126256-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2220-x2">
  <m id="m029-d1t2223-3">
   <w.rf>
    <LM>w#w-d1t2223-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m029-d1t2223-4">
   <w.rf>
    <LM>w#w-d1t2223-4</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m029-d1t2223-5">
   <w.rf>
    <LM>w#w-d1t2223-5</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2223-6">
   <w.rf>
    <LM>w#w-d1t2223-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m029-d1e2220-x2-147">
   <w.rf>
    <LM>w#w-d1e2220-x2-147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-148">
  <m id="m029-d1t2223-8">
   <w.rf>
    <LM>w#w-d1t2223-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2223-9">
   <w.rf>
    <LM>w#w-d1t2223-9</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m029-d1t2223-10">
   <w.rf>
    <LM>w#w-d1t2223-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2223-12">
   <w.rf>
    <LM>w#w-d1t2223-12</LM>
   </w.rf>
   <form>75</form>
   <lemma>75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m029-d1t2223-15">
   <w.rf>
    <LM>w#w-d1t2223-15</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m029-d1e2220-x2-85">
   <w.rf>
    <LM>w#w-d1e2220-x2-85</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2234-x2">
  <m id="m029-d1t2229-2">
   <w.rf>
    <LM>w#w-d1t2229-2</LM>
   </w.rf>
   <form>Vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2229-3">
   <w.rf>
    <LM>w#w-d1t2229-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m029-d1t2239-1">
   <w.rf>
    <LM>w#w-d1t2239-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2239-2">
   <w.rf>
    <LM>w#w-d1t2239-2</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d1t2239-4">
   <w.rf>
    <LM>w#w-d1t2239-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2239-5">
   <w.rf>
    <LM>w#w-d1t2239-5</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m029-d1t2239-6">
   <w.rf>
    <LM>w#w-d1t2239-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2239-7">
   <w.rf>
    <LM>w#w-d1t2239-7</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m029-d1t2239-8">
   <w.rf>
    <LM>w#w-d1t2239-8</LM>
   </w.rf>
   <form>vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m029-d1e2234-x2-96">
   <w.rf>
    <LM>w#w-d1e2234-x2-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-97">
  <m id="m029-d1t2239-14">
   <w.rf>
    <LM>w#w-d1t2239-14</LM>
   </w.rf>
   <form>Nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m029-d1t2239-15">
   <w.rf>
    <LM>w#w-d1t2239-15</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2239-16">
   <w.rf>
    <LM>w#w-d1t2239-16</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2239-17">
   <w.rf>
    <LM>w#w-d1t2239-17</LM>
   </w.rf>
   <form>služebně</form>
   <lemma>služebně-1_^(*3ý-1)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2239-18">
   <w.rf>
    <LM>w#w-d1t2239-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2239-19">
   <w.rf>
    <LM>w#w-d1t2239-19</LM>
   </w.rf>
   <form>cizině</form>
   <lemma>cizina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1t2239-21">
   <w.rf>
    <LM>w#w-d1t2239-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2239-23">
   <w.rf>
    <LM>w#w-d1t2239-23</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m029-d1t2239-24">
   <w.rf>
    <LM>w#w-d1t2239-24</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d1t2239-25">
   <w.rf>
    <LM>w#w-d1t2239-25</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m029-d1t2239-26">
   <w.rf>
    <LM>w#w-d1t2239-26</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2239-28">
   <w.rf>
    <LM>w#w-d1t2239-28</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2239-27">
   <w.rf>
    <LM>w#w-d1t2239-27</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-97-98">
   <w.rf>
    <LM>w#w-97-98</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2239-29">
   <w.rf>
    <LM>w#w-d1t2239-29</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2239-30">
   <w.rf>
    <LM>w#w-d1t2239-30</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m029-97-101">
   <w.rf>
    <LM>w#w-97-101</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-97-99">
   <w.rf>
    <LM>w#w-97-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-100">
  <m id="m029-d1t2239-32">
   <w.rf>
    <LM>w#w-d1t2239-32</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2239-33">
   <w.rf>
    <LM>w#w-d1t2239-33</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2239-34">
   <w.rf>
    <LM>w#w-d1t2239-34</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m029-d1t2239-35">
   <w.rf>
    <LM>w#w-d1t2239-35</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m029-100-102">
   <w.rf>
    <LM>w#w-100-102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2241-1">
   <w.rf>
    <LM>w#w-d1t2241-1</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m029-d1t2241-2">
   <w.rf>
    <LM>w#w-d1t2241-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2241-3">
   <w.rf>
    <LM>w#w-d1t2241-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-100-103">
   <w.rf>
    <LM>w#w-100-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-104">
  <m id="m029-d1t2241-5">
   <w.rf>
    <LM>w#w-d1t2241-5</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2241-6">
   <w.rf>
    <LM>w#w-d1t2241-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2241-8">
   <w.rf>
    <LM>w#w-d1t2241-8</LM>
   </w.rf>
   <form>dvojčata</form>
   <lemma>dvojče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m029-d1t2241-10">
   <w.rf>
    <LM>w#w-d1t2241-10</LM>
   </w.rf>
   <form>Marek</form>
   <lemma>Marek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2241-12">
   <w.rf>
    <LM>w#w-d1t2241-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2241-14">
   <w.rf>
    <LM>w#w-d1t2241-14</LM>
   </w.rf>
   <form>Tomáš</form>
   <lemma>Tomáš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2241-15">
   <w.rf>
    <LM>w#w-d1t2241-15</LM>
   </w.rf>
   <form>Francánovi</form>
   <lemma>Francánův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m029-d-m-d1e2234-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2234-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2250-x2">
  <m id="m029-d1t2253-1">
   <w.rf>
    <LM>w#w-d1t2253-1</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2253-3">
   <w.rf>
    <LM>w#w-d1t2253-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2255-1">
   <w.rf>
    <LM>w#w-d1t2255-1</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d1e2250-x2-110">
   <w.rf>
    <LM>w#w-d1e2250-x2-110</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2255-4">
   <w.rf>
    <LM>w#w-d1t2255-4</LM>
   </w.rf>
   <form>synova</form>
   <lemma>synův_^(*2)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m029-d1t2255-5">
   <w.rf>
    <LM>w#w-d1t2255-5</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d-id127640-punct">
   <w.rf>
    <LM>w#w-d-id127640-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1e2250-x2-166">
   <w.rf>
    <LM>w#w-d1e2250-x2-166</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m029-d1t2255-9">
   <w.rf>
    <LM>w#w-d1t2255-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2255-10">
   <w.rf>
    <LM>w#w-d1t2255-10</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m029-d1t2255-11">
   <w.rf>
    <LM>w#w-d1t2255-11</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1t2255-8">
   <w.rf>
    <LM>w#w-d1t2255-8</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m029-d1t2255-12">
   <w.rf>
    <LM>w#w-d1t2255-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2255-13">
   <w.rf>
    <LM>w#w-d1t2255-13</LM>
   </w.rf>
   <form>obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m029-d1t2255-14">
   <w.rf>
    <LM>w#w-d1t2255-14</LM>
   </w.rf>
   <form>akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d1e2250-x2-111">
   <w.rf>
    <LM>w#w-d1e2250-x2-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-112">
  <m id="m029-d1t2261-1">
   <w.rf>
    <LM>w#w-d1t2261-1</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2264-9">
   <w.rf>
    <LM>w#w-d1t2264-9</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2264-10">
   <w.rf>
    <LM>w#w-d1t2264-10</LM>
   </w.rf>
   <form>vnučky</form>
   <lemma>vnučka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m029-112-117">
   <w.rf>
    <LM>w#w-112-117</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2264-4">
   <w.rf>
    <LM>w#w-d1t2264-4</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m029-d1t2264-5">
   <w.rf>
    <LM>w#w-d1t2264-5</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m029-d1t2264-1">
   <w.rf>
    <LM>w#w-d1t2264-1</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m029-d1t2264-2">
   <w.rf>
    <LM>w#w-d1t2264-2</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2250-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2250-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2265-x2">
  <m id="m029-d1t2270-1">
   <w.rf>
    <LM>w#w-d1t2270-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2270-2">
   <w.rf>
    <LM>w#w-d1t2270-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2270-4">
   <w.rf>
    <LM>w#w-d1t2270-4</LM>
   </w.rf>
   <form>Hanička</form>
   <lemma>Hanička_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d-id128099-punct">
   <w.rf>
    <LM>w#w-d-id128099-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2270-7">
   <w.rf>
    <LM>w#w-d1t2270-7</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m029-d1t2270-8">
   <w.rf>
    <LM>w#w-d1t2270-8</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2270-9">
   <w.rf>
    <LM>w#w-d1t2270-9</LM>
   </w.rf>
   <form>práva</form>
   <lemma>právo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m029-d1e2265-x2-1744">
   <w.rf>
    <LM>w#w-d1e2265-x2-1744</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-1745">
  <m id="m029-d1t2278-2">
   <w.rf>
    <LM>w#w-d1t2278-2</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2278-4">
   <w.rf>
    <LM>w#w-d1t2278-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2278-6">
   <w.rf>
    <LM>w#w-d1t2278-6</LM>
   </w.rf>
   <form>Markétka</form>
   <lemma>Markétka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d-id128320-punct">
   <w.rf>
    <LM>w#w-d-id128320-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1e2265-x2-131">
   <w.rf>
    <LM>w#w-d1e2265-x2-131</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m029-d1t2278-10">
   <w.rf>
    <LM>w#w-d1t2278-10</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2278-11">
   <w.rf>
    <LM>w#w-d1t2278-11</LM>
   </w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m029-d1t2278-12">
   <w.rf>
    <LM>w#w-d1t2278-12</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m029-d1e2265-x2-132">
   <w.rf>
    <LM>w#w-d1e2265-x2-132</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2280-1">
   <w.rf>
    <LM>w#w-d1t2280-1</LM>
   </w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m029-d1t2280-2">
   <w.rf>
    <LM>w#w-d1t2280-2</LM>
   </w.rf>
   <form>práva</form>
   <lemma>právo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m029-d1e2275-x2-130">
   <w.rf>
    <LM>w#w-d1e2275-x2-130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-129">
  <m id="m029-d1t2280-5">
   <w.rf>
    <LM>w#w-d1t2280-5</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2280-7">
   <w.rf>
    <LM>w#w-d1t2280-7</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m029-d1t2280-8">
   <w.rf>
    <LM>w#w-d1t2280-8</LM>
   </w.rf>
   <form>nadání</form>
   <lemma>nadání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m029-d1t2280-9">
   <w.rf>
    <LM>w#w-d1t2280-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2280-10">
   <w.rf>
    <LM>w#w-d1t2280-10</LM>
   </w.rf>
   <form>řeči</form>
   <lemma>řeč</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2275-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2275-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2281-x2">
  <m id="m029-d1t2286-2">
   <w.rf>
    <LM>w#w-d1t2286-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2286-3">
   <w.rf>
    <LM>w#w-d1t2286-3</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2286-4">
   <w.rf>
    <LM>w#w-d1t2286-4</LM>
   </w.rf>
   <form>umí</form>
   <lemma>umět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2286-5">
   <w.rf>
    <LM>w#w-d1t2286-5</LM>
   </w.rf>
   <form>perfektně</form>
   <lemma>perfektně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2286-6">
   <w.rf>
    <LM>w#w-d1t2286-6</LM>
   </w.rf>
   <form>španělsky</form>
   <lemma>španělsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1e2281-x2-137">
   <w.rf>
    <LM>w#w-d1e2281-x2-137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2299-1">
   <w.rf>
    <LM>w#w-d1t2299-1</LM>
   </w.rf>
   <form>anglicky</form>
   <lemma>anglicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2299-2">
   <w.rf>
    <LM>w#w-d1t2299-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2299-3">
   <w.rf>
    <LM>w#w-d1t2299-3</LM>
   </w.rf>
   <form>německy</form>
   <lemma>německy_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d-m-d1e2281-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2281-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2296-x2">
  <m id="m029-d1t2301-2">
   <w.rf>
    <LM>w#w-d1t2301-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2301-3">
   <w.rf>
    <LM>w#w-d1t2301-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m029-d1t2301-4">
   <w.rf>
    <LM>w#w-d1t2301-4</LM>
   </w.rf>
   <form>učí</form>
   <lemma>učit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2301-6">
   <w.rf>
    <LM>w#w-d1t2301-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2301-5">
   <w.rf>
    <LM>w#w-d1t2301-5</LM>
   </w.rf>
   <form>rusky</form>
   <lemma>rusky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1e2296-x2-138">
   <w.rf>
    <LM>w#w-d1e2296-x2-138</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2304-x2">
  <m id="m029-d1t2307-1">
   <w.rf>
    <LM>w#w-d1t2307-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2307-3">
   <w.rf>
    <LM>w#w-d1t2307-3</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d-id129095-punct">
   <w.rf>
    <LM>w#w-d-id129095-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2309-x2">
  <m id="m029-d1t2312-1">
   <w.rf>
    <LM>w#w-d1t2312-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2312-3">
   <w.rf>
    <LM>w#w-d1t2312-3</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2309-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2309-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2313-x2">
  <m id="m029-d1t2318-1">
   <w.rf>
    <LM>w#w-d1t2318-1</LM>
   </w.rf>
   <form>Vysoká</form>
   <lemma>vysoký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m029-d1t2318-2">
   <w.rf>
    <LM>w#w-d1t2318-2</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-d1t2318-4">
   <w.rf>
    <LM>w#w-d1t2318-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2318-5">
   <w.rf>
    <LM>w#w-d1t2318-5</LM>
   </w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m029-d1t2318-6">
   <w.rf>
    <LM>w#w-d1t2318-6</LM>
   </w.rf>
   <form>vztahy</form>
   <lemma>vztah</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2313-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2313-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2325-x2">
  <m id="m029-d1t2328-7">
   <w.rf>
    <LM>w#w-d1t2328-7</LM>
   </w.rf>
   <form>Chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2328-4">
   <w.rf>
    <LM>w#w-d1t2328-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2328-5">
   <w.rf>
    <LM>w#w-d1t2328-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2328-2">
   <w.rf>
    <LM>w#w-d1t2328-2</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m029-d1t2328-3">
   <w.rf>
    <LM>w#w-d1t2328-3</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m029-d1e2325-x2-167">
   <w.rf>
    <LM>w#w-d1e2325-x2-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-168">
  <m id="m029-d1t2330-2">
   <w.rf>
    <LM>w#w-d1t2330-2</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2330-4">
   <w.rf>
    <LM>w#w-d1t2330-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2332-7">
   <w.rf>
    <LM>w#w-d1t2332-7</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m029-d1t2332-5">
   <w.rf>
    <LM>w#w-d1t2332-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m029-d1t2332-2">
   <w.rf>
    <LM>w#w-d1t2332-2</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m029-d1t2332-3">
   <w.rf>
    <LM>w#w-d1t2332-3</LM>
   </w.rf>
   <form>nejmladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS2----3A----</tag>
  </m>
  <m id="m029-d1t2332-4">
   <w.rf>
    <LM>w#w-d1t2332-4</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS2-----A---6</tag>
  </m>
  <m id="m029-d-id129826-punct">
   <w.rf>
    <LM>w#w-d-id129826-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2332-12">
   <w.rf>
    <LM>w#w-d1t2332-12</LM>
   </w.rf>
   <form>Lubošek</form>
   <lemma>Lubošek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2332-14">
   <w.rf>
    <LM>w#w-d1t2332-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2332-16">
   <w.rf>
    <LM>w#w-d1t2332-16</LM>
   </w.rf>
   <form>Barborka</form>
   <lemma>Barborka-1_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m029-168-181">
   <w.rf>
    <LM>w#w-168-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-183">
  <m id="m029-d1t2334-3">
   <w.rf>
    <LM>w#w-d1t2334-3</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2334-4">
   <w.rf>
    <LM>w#w-d1t2334-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m029-d1t2334-5">
   <w.rf>
    <LM>w#w-d1t2334-5</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m029-d1t2334-6">
   <w.rf>
    <LM>w#w-d1t2334-6</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m029-d1t2334-7">
   <w.rf>
    <LM>w#w-d1t2334-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2334-8">
   <w.rf>
    <LM>w#w-d1t2334-8</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m029-d-id130102-punct">
   <w.rf>
    <LM>w#w-d-id130102-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2334-11">
   <w.rf>
    <LM>w#w-d1t2334-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2336-1">
   <w.rf>
    <LM>w#w-d1t2336-1</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2336-2">
   <w.rf>
    <LM>w#w-d1t2336-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m029-d1t2336-3">
   <w.rf>
    <LM>w#w-d1t2336-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2336-4">
   <w.rf>
    <LM>w#w-d1t2336-4</LM>
   </w.rf>
   <form>vystavené</form>
   <lemma>vystavený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m029-d-id130205-punct">
   <w.rf>
    <LM>w#w-d-id130205-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2336-8">
   <w.rf>
    <LM>w#w-d1t2336-8</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2336-7">
   <w.rf>
    <LM>w#w-d1t2336-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m029-d1t2336-10">
   <w.rf>
    <LM>w#w-d1t2336-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2336-11">
   <w.rf>
    <LM>w#w-d1t2336-11</LM>
   </w.rf>
   <form>dodatečně</form>
   <lemma>dodatečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2336-13">
   <w.rf>
    <LM>w#w-d1t2336-13</LM>
   </w.rf>
   <form>dané</form>
   <lemma>daný-1_^(*5át-1)</lemma>
   <tag>AANP4----1A---6</tag>
  </m>
  <m id="m029-183-188">
   <w.rf>
    <LM>w#w-183-188</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2352-x2">
  <m id="m029-d1t2349-1">
   <w.rf>
    <LM>w#w-d1t2349-1</LM>
   </w.rf>
   <form>Nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m029-d1t2349-2">
   <w.rf>
    <LM>w#w-d1t2349-2</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2355-2">
   <w.rf>
    <LM>w#w-d1t2355-2</LM>
   </w.rf>
   <form>umí</form>
   <lemma>umět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2355-3">
   <w.rf>
    <LM>w#w-d1t2355-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2355-4">
   <w.rf>
    <LM>w#w-d1t2355-4</LM>
   </w.rf>
   <form>perfektně</form>
   <lemma>perfektně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2355-5">
   <w.rf>
    <LM>w#w-d1t2355-5</LM>
   </w.rf>
   <form>anglicky</form>
   <lemma>anglicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2357-1">
   <w.rf>
    <LM>w#w-d1t2357-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2357-2">
   <w.rf>
    <LM>w#w-d1t2357-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2357-4">
   <w.rf>
    <LM>w#w-d1t2357-4</LM>
   </w.rf>
   <form>zdařilým</form>
   <lemma>zdařilý</lemma>
   <tag>AAMS7----1A----</tag>
  </m>
  <m id="m029-d1t2357-5">
   <w.rf>
    <LM>w#w-d1t2357-5</LM>
   </w.rf>
   <form>podnikatelem</form>
   <lemma>podnikatel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m029-d1e2352-x2-185">
   <w.rf>
    <LM>w#w-d1e2352-x2-185</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-184">
  <m id="m029-d1t2357-7">
   <w.rf>
    <LM>w#w-d1t2357-7</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2357-9">
   <w.rf>
    <LM>w#w-d1t2357-9</LM>
   </w.rf>
   <form>podnikatelskou</form>
   <lemma>podnikatelský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m029-d1t2357-8">
   <w.rf>
    <LM>w#w-d1t2357-8</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m029-d1e2352-x2-209">
   <w.rf>
    <LM>w#w-d1e2352-x2-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-211">
  <m id="m029-d1t2359-1">
   <w.rf>
    <LM>w#w-d1t2359-1</LM>
   </w.rf>
   <form>Mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2359-2">
   <w.rf>
    <LM>w#w-d1t2359-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m029-d1t2359-3">
   <w.rf>
    <LM>w#w-d1t2359-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2359-4">
   <w.rf>
    <LM>w#w-d1t2359-4</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m029-d1t2359-5">
   <w.rf>
    <LM>w#w-d1t2359-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2359-7">
   <w.rf>
    <LM>w#w-d1t2359-7</LM>
   </w.rf>
   <form>Kanadě</form>
   <lemma>Kanada_;G_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1t2359-9">
   <w.rf>
    <LM>w#w-d1t2359-9</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m029-d1t2359-11">
   <w.rf>
    <LM>w#w-d1t2359-11</LM>
   </w.rf>
   <form>Vancouveru</form>
   <lemma>Vancouver_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m029-211-194">
   <w.rf>
    <LM>w#w-211-194</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-195">
  <m id="m029-d1t2361-5">
   <w.rf>
    <LM>w#w-d1t2361-5</LM>
   </w.rf>
   <form>Naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m029-d1t2361-4">
   <w.rf>
    <LM>w#w-d1t2361-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m029-d1t2361-3">
   <w.rf>
    <LM>w#w-d1t2361-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2363-1">
   <w.rf>
    <LM>w#w-d1t2363-1</LM>
   </w.rf>
   <form>perfektně</form>
   <lemma>perfektně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2363-2">
   <w.rf>
    <LM>w#w-d1t2363-2</LM>
   </w.rf>
   <form>anglicky</form>
   <lemma>anglicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-211-221">
   <w.rf>
    <LM>w#w-211-221</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-222">
  <m id="m029-d1t2363-5">
   <w.rf>
    <LM>w#w-d1t2363-5</LM>
   </w.rf>
   <form>Chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2363-4">
   <w.rf>
    <LM>w#w-d1t2363-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2363-6">
   <w.rf>
    <LM>w#w-d1t2363-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2363-7">
   <w.rf>
    <LM>w#w-d1t2363-7</LM>
   </w.rf>
   <form>jazykové</form>
   <lemma>jazykový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m029-d1t2363-8">
   <w.rf>
    <LM>w#w-d1t2363-8</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-222-223">
   <w.rf>
    <LM>w#w-222-223</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-225">
  <m id="m029-d1t2366-3">
   <w.rf>
    <LM>w#w-d1t2366-3</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2366-4">
   <w.rf>
    <LM>w#w-d1t2366-4</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2366-5">
   <w.rf>
    <LM>w#w-d1t2366-5</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m029-d1t2366-6">
   <w.rf>
    <LM>w#w-d1t2366-6</LM>
   </w.rf>
   <form>obchodů</form>
   <lemma>obchod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m029-d1t2366-7">
   <w.rf>
    <LM>w#w-d1t2366-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m029-d1t2366-8">
   <w.rf>
    <LM>w#w-d1t2366-8</LM>
   </w.rf>
   <form>sportovními</form>
   <lemma>sportovní</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m029-d1t2366-9">
   <w.rf>
    <LM>w#w-d1t2366-9</LM>
   </w.rf>
   <form>potřebami</form>
   <lemma>potřeba-1</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2352-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2352-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2367-x2">
  <m id="m029-d1t2372-1">
   <w.rf>
    <LM>w#w-d1t2372-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2372-2">
   <w.rf>
    <LM>w#w-d1t2372-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2372-4">
   <w.rf>
    <LM>w#w-d1t2372-4</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1t2372-6">
   <w.rf>
    <LM>w#w-d1t2372-6</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2372-7">
   <w.rf>
    <LM>w#w-d1t2372-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m029-d1e2367-x2-249">
   <w.rf>
    <LM>w#w-d1e2367-x2-249</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2380-1">
   <w.rf>
    <LM>w#w-d1t2380-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2380-2">
   <w.rf>
    <LM>w#w-d1t2380-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2380-8">
   <w.rf>
    <LM>w#w-d1t2380-8</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m029-d1t2380-3">
   <w.rf>
    <LM>w#w-d1t2380-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2380-5">
   <w.rf>
    <LM>w#w-d1t2380-5</LM>
   </w.rf>
   <form>Karlových</form>
   <lemma>Karlův_;Y_^(*2)_(*3el)</lemma>
   <tag>AUIP6M---------</tag>
  </m>
  <m id="m029-d1t2380-6">
   <w.rf>
    <LM>w#w-d1t2380-6</LM>
   </w.rf>
   <form>Varech</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m029-d-id131610-punct">
   <w.rf>
    <LM>w#w-d-id131610-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2380-15">
   <w.rf>
    <LM>w#w-d1t2380-15</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m029-d1t2380-10">
   <w.rf>
    <LM>w#w-d1t2380-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2380-12">
   <w.rf>
    <LM>w#w-d1t2380-12</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1e2367-x2-217">
   <w.rf>
    <LM>w#w-d1e2367-x2-217</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-218">
  <m id="m029-d1t2380-19">
   <w.rf>
    <LM>w#w-d1t2380-19</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m029-d1t2380-20">
   <w.rf>
    <LM>w#w-d1t2380-20</LM>
   </w.rf>
   <form>jedním</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS7----------</tag>
  </m>
  <m id="m029-d1t2380-21">
   <w.rf>
    <LM>w#w-d1t2380-21</LM>
   </w.rf>
   <form>kamarádem</form>
   <lemma>kamarád</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m029-d1t2380-22">
   <w.rf>
    <LM>w#w-d1t2380-22</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2380-24">
   <w.rf>
    <LM>w#w-d1t2380-24</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-d1t2380-26">
   <w.rf>
    <LM>w#w-d1t2380-26</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2380-18">
   <w.rf>
    <LM>w#w-d1t2380-18</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1e2367-x2-250">
   <w.rf>
    <LM>w#w-d1e2367-x2-250</LM>
   </w.rf>
   <form>obchod</form>
   <lemma>obchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m029-d1t2380-27">
   <w.rf>
    <LM>w#w-d1t2380-27</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2380-29">
   <w.rf>
    <LM>w#w-d1t2380-29</LM>
   </w.rf>
   <form>Liberci</form>
   <lemma>Liberec_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m029-d-id131884-punct">
   <w.rf>
    <LM>w#w-d-id131884-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2380-34">
   <w.rf>
    <LM>w#w-d1t2380-34</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m029-d1t2380-36">
   <w.rf>
    <LM>w#w-d1t2380-36</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2380-39">
   <w.rf>
    <LM>w#w-d1t2380-39</LM>
   </w.rf>
   <form>Ostravě</form>
   <lemma>Ostrava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d1e2377-x2-248">
   <w.rf>
    <LM>w#w-d1e2377-x2-248</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-247">
  <m id="m029-d1t2380-47">
   <w.rf>
    <LM>w#w-d1t2380-47</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m029-d1t2380-48">
   <w.rf>
    <LM>w#w-d1t2380-48</LM>
   </w.rf>
   <form>29</form>
   <lemma>29</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m029-d1t2380-49">
   <w.rf>
    <LM>w#w-d1t2380-49</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m029-d1t2380-44">
   <w.rf>
    <LM>w#w-d1t2380-44</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2380-46">
   <w.rf>
    <LM>w#w-d1t2380-46</LM>
   </w.rf>
   <form>podnikatel</form>
   <lemma>podnikatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d-id132118-punct">
   <w.rf>
    <LM>w#w-d-id132118-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2380-51">
   <w.rf>
    <LM>w#w-d1t2380-51</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2380-55">
   <w.rf>
    <LM>w#w-d1t2380-55</LM>
   </w.rf>
   <form>nakupovat</form>
   <lemma>nakupovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m029-d1t2380-52">
   <w.rf>
    <LM>w#w-d1t2380-52</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2380-53">
   <w.rf>
    <LM>w#w-d1t2380-53</LM>
   </w.rf>
   <form>celém</form>
   <lemma>celý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m029-d1t2380-54">
   <w.rf>
    <LM>w#w-d1t2380-54</LM>
   </w.rf>
   <form>světě</form>
   <lemma>svět</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2377-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2377-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2381-x2">
  <m id="m029-d1t2384-1">
   <w.rf>
    <LM>w#w-d1t2384-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2384-2">
   <w.rf>
    <LM>w#w-d1t2384-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m029-d1t2384-3">
   <w.rf>
    <LM>w#w-d1t2384-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2384-4">
   <w.rf>
    <LM>w#w-d1t2384-4</LM>
   </w.rf>
   <form>pyšný</form>
   <lemma>pyšný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d-id132334-punct">
   <w.rf>
    <LM>w#w-d-id132334-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2384-6">
   <w.rf>
    <LM>w#w-d1t2384-6</LM>
   </w.rf>
   <form>viďte</form>
   <lemma>viďte</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d-id132358-punct">
   <w.rf>
    <LM>w#w-d-id132358-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2385-x2">
  <m id="m029-d1t2388-6">
   <w.rf>
    <LM>w#w-d1t2388-6</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1e2385-x2-265">
   <w.rf>
    <LM>w#w-d1e2385-x2-265</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2388-2">
   <w.rf>
    <LM>w#w-d1t2388-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m029-d1t2388-3">
   <w.rf>
    <LM>w#w-d1t2388-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2388-4">
   <w.rf>
    <LM>w#w-d1t2388-4</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m029-d1t2388-5">
   <w.rf>
    <LM>w#w-d1t2388-5</LM>
   </w.rf>
   <form>pyšný</form>
   <lemma>pyšný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1e2385-x2-266">
   <w.rf>
    <LM>w#w-d1e2385-x2-266</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-267">
  <m id="m029-d1t2388-8">
   <w.rf>
    <LM>w#w-d1t2388-8</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m029-d1t2388-9">
   <w.rf>
    <LM>w#w-d1t2388-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2388-10">
   <w.rf>
    <LM>w#w-d1t2388-10</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2388-11">
   <w.rf>
    <LM>w#w-d1t2388-11</LM>
   </w.rf>
   <form>šikovný</form>
   <lemma>šikovný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1t2388-12">
   <w.rf>
    <LM>w#w-d1t2388-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2388-13">
   <w.rf>
    <LM>w#w-d1t2388-13</LM>
   </w.rf>
   <form>pracovitý</form>
   <lemma>pracovitý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1t2390-1">
   <w.rf>
    <LM>w#w-d1t2390-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2390-2">
   <w.rf>
    <LM>w#w-d1t2390-2</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2390-3">
   <w.rf>
    <LM>w#w-d1t2390-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m029-d1t2390-4">
   <w.rf>
    <LM>w#w-d1t2390-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2390-5">
   <w.rf>
    <LM>w#w-d1t2390-5</LM>
   </w.rf>
   <form>výborný</form>
   <lemma>výborný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1t2390-6">
   <w.rf>
    <LM>w#w-d1t2390-6</LM>
   </w.rf>
   <form>sportovec</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-267-276">
   <w.rf>
    <LM>w#w-267-276</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-277">
  <m id="m029-d1t2392-2">
   <w.rf>
    <LM>w#w-d1t2392-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2392-3">
   <w.rf>
    <LM>w#w-d1t2392-3</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m029-d1t2392-4">
   <w.rf>
    <LM>w#w-d1t2392-4</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m029-d1t2394-1">
   <w.rf>
    <LM>w#w-d1t2394-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m029-d1t2394-2">
   <w.rf>
    <LM>w#w-d1t2394-2</LM>
   </w.rf>
   <form>snowboardu</form>
   <lemma>snowboard</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m029-d1t2394-3">
   <w.rf>
    <LM>w#w-d1t2394-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2394-4">
   <w.rf>
    <LM>w#w-d1t2394-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2394-5">
   <w.rf>
    <LM>w#w-d1t2394-5</LM>
   </w.rf>
   <form>Plzeňském</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m029-d1t2394-6">
   <w.rf>
    <LM>w#w-d1t2394-6</LM>
   </w.rf>
   <form>kraji</form>
   <lemma>kraj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m029-d1t2394-8">
   <w.rf>
    <LM>w#w-d1t2394-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2394-11">
   <w.rf>
    <LM>w#w-d1t2394-11</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2394-10">
   <w.rf>
    <LM>w#w-d1t2394-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-277-228">
   <w.rf>
    <LM>w#w-277-228</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2394-9">
   <w.rf>
    <LM>w#w-d1t2394-9</LM>
   </w.rf>
   <form>skateboardu</form>
   <lemma>skateboard</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m029-277-284">
   <w.rf>
    <LM>w#w-277-284</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-285">
  <m id="m029-d1t2394-14">
   <w.rf>
    <LM>w#w-d1t2394-14</LM>
   </w.rf>
   <form>Skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2394-15">
   <w.rf>
    <LM>w#w-d1t2394-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2394-16">
   <w.rf>
    <LM>w#w-d1t2394-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2394-17">
   <w.rf>
    <LM>w#w-d1t2394-17</LM>
   </w.rf>
   <form>sportovec</form>
   <lemma>sportovec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d1t2394-18">
   <w.rf>
    <LM>w#w-d1t2394-18</LM>
   </w.rf>
   <form>tělem</form>
   <lemma>tělo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m029-d1t2394-19">
   <w.rf>
    <LM>w#w-d1t2394-19</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2394-20">
   <w.rf>
    <LM>w#w-d1t2394-20</LM>
   </w.rf>
   <form>duší</form>
   <lemma>duše</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m029-285-286">
   <w.rf>
    <LM>w#w-285-286</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-288">
  <m id="m029-d1t2394-24">
   <w.rf>
    <LM>w#w-d1t2394-24</LM>
   </w.rf>
   <form>Chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m029-d1t2394-23">
   <w.rf>
    <LM>w#w-d1t2394-23</LM>
   </w.rf>
   <form>zápasit</form>
   <lemma>zápasit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m029-288-295">
   <w.rf>
    <LM>w#w-288-295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2394-26">
   <w.rf>
    <LM>w#w-d1t2394-26</LM>
    <LM>w#w-d1t2394-27</LM>
   </w.rf>
   <form>řeckořímský</form>
   <lemma>řeckořímský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m029-d1t2394-28">
   <w.rf>
    <LM>w#w-d1t2394-28</LM>
   </w.rf>
   <form>zápas</form>
   <lemma>zápas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m029-d-id133168-punct">
   <w.rf>
    <LM>w#w-d-id133168-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2394-30">
   <w.rf>
    <LM>w#w-d1t2394-30</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m029-d1t2394-31">
   <w.rf>
    <LM>w#w-d1t2394-31</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2394-33">
   <w.rf>
    <LM>w#w-d1t2394-33</LM>
   </w.rf>
   <form>dobrou</form>
   <lemma>dobrý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m029-d1t2394-32">
   <w.rf>
    <LM>w#w-d1t2394-32</LM>
   </w.rf>
   <form>průpravu</form>
   <lemma>průprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2385-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2385-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2397-x2">
  <m id="m029-d1t2400-1">
   <w.rf>
    <LM>w#w-d1t2400-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m029-d1t2400-2">
   <w.rf>
    <LM>w#w-d1t2400-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2400-3">
   <w.rf>
    <LM>w#w-d1t2400-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m029-d-m-d1e2397-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2397-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2401-x2">
  <m id="m029-d1t2404-1">
   <w.rf>
    <LM>w#w-d1t2404-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2404-2">
   <w.rf>
    <LM>w#w-d1t2404-2</LM>
   </w.rf>
   <form>zajímavý</form>
   <lemma>zajímavý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1e2401-x2-298">
   <w.rf>
    <LM>w#w-d1e2401-x2-298</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-300">
  <m id="m029-d1t2404-5">
   <w.rf>
    <LM>w#w-d1t2404-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2404-6">
   <w.rf>
    <LM>w#w-d1t2404-6</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2404-8">
   <w.rf>
    <LM>w#w-d1t2404-8</LM>
   </w.rf>
   <form>šikovný</form>
   <lemma>šikovný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m029-d1t2404-7">
   <w.rf>
    <LM>w#w-d1t2404-7</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m029-d-m-d1e2401-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2401-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2410-x2">
  <m id="m029-d1t2413-1">
   <w.rf>
    <LM>w#w-d1t2413-1</LM>
   </w.rf>
   <form>Bývají</form>
   <lemma>bývat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2413-2">
   <w.rf>
    <LM>w#w-d1t2413-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2413-3">
   <w.rf>
    <LM>w#w-d1t2413-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m029-d1t2413-4">
   <w.rf>
    <LM>w#w-d1t2413-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d-id133643-punct">
   <w.rf>
    <LM>w#w-d-id133643-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-d1e2414-x2">
  <m id="m029-d1t2417-2">
   <w.rf>
    <LM>w#w-d1t2417-2</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m029-d1t2417-3">
   <w.rf>
    <LM>w#w-d1t2417-3</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2417-4">
   <w.rf>
    <LM>w#w-d1t2417-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m029-d1t2417-5">
   <w.rf>
    <LM>w#w-d1t2417-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d-id133768-punct">
   <w.rf>
    <LM>w#w-d-id133768-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m029-d1t2417-7">
   <w.rf>
    <LM>w#w-d1t2417-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m029-d1t2417-9">
   <w.rf>
    <LM>w#w-d1t2417-9</LM>
   </w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m029-d1t2417-10">
   <w.rf>
    <LM>w#w-d1t2417-10</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2417-11">
   <w.rf>
    <LM>w#w-d1t2417-11</LM>
   </w.rf>
   <form>času</form>
   <lemma>čas</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m029-d1e2414-x2-319">
   <w.rf>
    <LM>w#w-d1e2414-x2-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-321">
  <m id="m029-d1t2417-14">
   <w.rf>
    <LM>w#w-d1t2417-14</LM>
   </w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2417-15">
   <w.rf>
    <LM>w#w-d1t2417-15</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2417-16">
   <w.rf>
    <LM>w#w-d1t2417-16</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2417-18">
   <w.rf>
    <LM>w#w-d1t2417-18</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m029-d-id133945-punct">
   <w.rf>
    <LM>w#w-d-id133945-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2419-1">
   <w.rf>
    <LM>w#w-d1t2419-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2419-2">
   <w.rf>
    <LM>w#w-d1t2419-2</LM>
   </w.rf>
   <form>pětkrát</form>
   <lemma>pětkrát`5</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m029-d1t2419-3">
   <w.rf>
    <LM>w#w-d1t2419-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2419-4">
   <w.rf>
    <LM>w#w-d1t2419-4</LM>
   </w.rf>
   <form>roka</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m029-d1t2419-5">
   <w.rf>
    <LM>w#w-d1t2419-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2419-6">
   <w.rf>
    <LM>w#w-d1t2419-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2419-8">
   <w.rf>
    <LM>w#w-d1t2419-8</LM>
   </w.rf>
   <form>Ameriky</form>
   <lemma>Amerika_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m029-321-322">
   <w.rf>
    <LM>w#w-321-322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-323">
  <m id="m029-d1t2419-14">
   <w.rf>
    <LM>w#w-d1t2419-14</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2419-13">
   <w.rf>
    <LM>w#w-d1t2419-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m029-d1t2419-16">
   <w.rf>
    <LM>w#w-d1t2419-16</LM>
   </w.rf>
   <form>kontakty</form>
   <lemma>kontakt</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m029-d1t2421-1">
   <w.rf>
    <LM>w#w-d1t2421-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m029-d1t2421-2">
   <w.rf>
    <LM>w#w-d1t2421-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m029-d1t2421-4">
   <w.rf>
    <LM>w#w-d1t2421-4</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m029-d1t2421-3">
   <w.rf>
    <LM>w#w-d1t2421-3</LM>
   </w.rf>
   <form>zboží</form>
   <lemma>zboží</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m029-323-324">
   <w.rf>
    <LM>w#w-323-324</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m029-325">
  <m id="m029-d1t2421-8">
   <w.rf>
    <LM>w#w-d1t2421-8</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m029-d1t2421-9">
   <w.rf>
    <LM>w#w-d1t2421-9</LM>
   </w.rf>
   <form>tyhlety</form>
   <lemma>tenhleten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m029-d1t2421-10">
   <w.rf>
    <LM>w#w-d1t2421-10</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m029-d1t2421-11">
   <w.rf>
    <LM>w#w-d1t2421-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m029-d1t2421-13">
   <w.rf>
    <LM>w#w-d1t2421-13</LM>
   </w.rf>
   <form>Chrástu</form>
   <lemma>Chrást-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m029-d1t2421-24">
   <w.rf>
    <LM>w#w-d1t2421-24</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m029-d1t2421-25">
   <w.rf>
    <LM>w#w-d1t2421-25</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m029-d1t2421-26">
   <w.rf>
    <LM>w#w-d1t2421-26</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m029-d1t2421-27">
   <w.rf>
    <LM>w#w-d1t2421-27</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m029-d1t2421-28">
   <w.rf>
    <LM>w#w-d1t2421-28</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m029-d1t2421-29">
   <w.rf>
    <LM>w#w-d1t2421-29</LM>
   </w.rf>
   <form>kolech</form>
   <lemma>kolo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m029-325-326">
   <w.rf>
    <LM>w#w-325-326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
