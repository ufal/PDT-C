<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jv_133.01.w.gz" />
  </references>
 </head>
 <s id="m133-59">
  <m id="m133-d1t257-17">
   <w.rf>
    <LM>w#w-d1t257-17</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t257-15">
   <w.rf>
    <LM>w#w-d1t257-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t257-16">
   <w.rf>
    <LM>w#w-d1t257-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t259-3">
   <w.rf>
    <LM>w#w-d1t259-3</LM>
   </w.rf>
   <form>zralí</form>
   <lemma>zralý_^(*3át)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m133-d1t259-4">
   <w.rf>
    <LM>w#w-d1t259-4</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m133-d1t259-5">
   <w.rf>
    <LM>w#w-d1t259-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t259-6">
   <w.rf>
    <LM>w#w-d1t259-6</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m133-d1t259-8">
   <w.rf>
    <LM>w#w-d1t259-8</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m133-d1t259-9">
   <w.rf>
    <LM>w#w-d1t259-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t259-10">
   <w.rf>
    <LM>w#w-d1t259-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t261-1">
   <w.rf>
    <LM>w#w-d1t261-1</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m133-d1t261-2">
   <w.rf>
    <LM>w#w-d1t261-2</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m133-d1t261-3">
   <w.rf>
    <LM>w#w-d1t261-3</LM>
   </w.rf>
   <form>nepořídili</form>
   <lemma>pořídit</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m133-59-61">
   <w.rf>
    <LM>w#w-59-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-62">
  <m id="m133-d1t261-6">
   <w.rf>
    <LM>w#w-d1t261-6</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m133-d1t261-7">
   <w.rf>
    <LM>w#w-d1t261-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t261-9">
   <w.rf>
    <LM>w#w-d1t261-9</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m133-d1t261-10">
   <w.rf>
    <LM>w#w-d1t261-10</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m133-d-id64223-punct">
   <w.rf>
    <LM>w#w-d-id64223-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t261-12">
   <w.rf>
    <LM>w#w-d1t261-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t261-13">
   <w.rf>
    <LM>w#w-d1t261-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t264-1">
   <w.rf>
    <LM>w#w-d1t264-1</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t264-2">
   <w.rf>
    <LM>w#w-d1t264-2</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZMS4----------</tag>
  </m>
  <m id="m133-d1t264-3">
   <w.rf>
    <LM>w#w-d1t264-3</LM>
   </w.rf>
   <form>sourozence</form>
   <lemma>sourozenec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m133-d1t264-4">
   <w.rf>
    <LM>w#w-d1t264-4</LM>
   </w.rf>
   <form>toužila</form>
   <lemma>toužit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t264-5">
   <w.rf>
    <LM>w#w-d1t264-5</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m133-62-81">
   <w.rf>
    <LM>w#w-62-81</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e265-x2">
  <m id="m133-d1t268-1">
   <w.rf>
    <LM>w#w-d1t268-1</LM>
   </w.rf>
   <form>Pamatujete</form>
   <lemma>pamatovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m133-d1t268-2">
   <w.rf>
    <LM>w#w-d1t268-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t268-4">
   <w.rf>
    <LM>w#w-d1t268-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t268-5">
   <w.rf>
    <LM>w#w-d1t268-5</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d1t268-3">
   <w.rf>
    <LM>w#w-d1t268-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m133-d-id64480-punct">
   <w.rf>
    <LM>w#w-d-id64480-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e269-x2">
  <m id="m133-d1t274-1">
   <w.rf>
    <LM>w#w-d1t274-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1e269-x2-171">
   <w.rf>
    <LM>w#w-d1e269-x2-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-172">
  <m id="m133-d1t274-3">
   <w.rf>
    <LM>w#w-d1t274-3</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t274-4">
   <w.rf>
    <LM>w#w-d1t274-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d1t274-5">
   <w.rf>
    <LM>w#w-d1t274-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t274-6">
   <w.rf>
    <LM>w#w-d1t274-6</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t274-7">
   <w.rf>
    <LM>w#w-d1t274-7</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t274-8">
   <w.rf>
    <LM>w#w-d1t274-8</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m133-172-184">
   <w.rf>
    <LM>w#w-172-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-185">
  <m id="m133-d1t280-2">
   <w.rf>
    <LM>w#w-d1t280-2</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t280-3">
   <w.rf>
    <LM>w#w-d1t280-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t285-4">
   <w.rf>
    <LM>w#w-d1t285-4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d-id64747-punct">
   <w.rf>
    <LM>w#w-d-id64747-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t280-5">
   <w.rf>
    <LM>w#w-d1t280-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t285-2">
   <w.rf>
    <LM>w#w-d1t285-2</LM>
   </w.rf>
   <form>ohlušující</form>
   <lemma>ohlušující_^(*5ovat)</lemma>
   <tag>AGFP1-----A----</tag>
  </m>
  <m id="m133-d1t285-1">
   <w.rf>
    <LM>w#w-d1t285-1</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t285-3">
   <w.rf>
    <LM>w#w-d1t285-3</LM>
   </w.rf>
   <form>rány</form>
   <lemma>rána</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-d-id64851-punct">
   <w.rf>
    <LM>w#w-d-id64851-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t289-1">
   <w.rf>
    <LM>w#w-d1t289-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t289-2">
   <w.rf>
    <LM>w#w-d1t289-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t289-3">
   <w.rf>
    <LM>w#w-d1t289-3</LM>
   </w.rf>
   <form>nálety</form>
   <lemma>nálet</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m133-185-186">
   <w.rf>
    <LM>w#w-185-186</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-187">
  <m id="m133-d1t291-1">
   <w.rf>
    <LM>w#w-d1t291-1</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t291-2">
   <w.rf>
    <LM>w#w-d1t291-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d-id64971-punct">
   <w.rf>
    <LM>w#w-d-id64971-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t296-1">
   <w.rf>
    <LM>w#w-d1t296-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t296-2">
   <w.rf>
    <LM>w#w-d1t296-2</LM>
   </w.rf>
   <form>vylítla</form>
   <lemma>vylítnout_,h_^(^GC**vylétnout)</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m133-d1t296-3">
   <w.rf>
    <LM>w#w-d1t296-3</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m133-d1t296-4">
   <w.rf>
    <LM>w#w-d1t296-4</LM>
   </w.rf>
   <form>naproti</form>
   <lemma>naproti-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t296-5">
   <w.rf>
    <LM>w#w-d1t296-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t296-6">
   <w.rf>
    <LM>w#w-d1t296-6</LM>
   </w.rf>
   <form>baráku</form>
   <lemma>barák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m133-187-188">
   <w.rf>
    <LM>w#w-187-188</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-189">
  <m id="m133-d1t302-1">
   <w.rf>
    <LM>w#w-d1t302-1</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t302-2">
   <w.rf>
    <LM>w#w-d1t302-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d-id65193-punct">
   <w.rf>
    <LM>w#w-d-id65193-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t302-4">
   <w.rf>
    <LM>w#w-d1t302-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t302-5">
   <w.rf>
    <LM>w#w-d1t302-5</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t302-6">
   <w.rf>
    <LM>w#w-d1t302-6</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m133-d1t302-7">
   <w.rf>
    <LM>w#w-d1t302-7</LM>
   </w.rf>
   <form>troubení</form>
   <lemma>troubení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m133-d1t302-8">
   <w.rf>
    <LM>w#w-d1t302-8</LM>
   </w.rf>
   <form>náletů</form>
   <lemma>nálet</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m133-d1t302-9">
   <w.rf>
    <LM>w#w-d1t302-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m133-d1t302-10">
   <w.rf>
    <LM>w#w-d1t302-10</LM>
   </w.rf>
   <form>utíkali</form>
   <lemma>utíkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t302-11">
   <w.rf>
    <LM>w#w-d1t302-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t302-12">
   <w.rf>
    <LM>w#w-d1t302-12</LM>
   </w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m133-d-id65342-punct">
   <w.rf>
    <LM>w#w-d-id65342-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t304-1">
   <w.rf>
    <LM>w#w-d1t304-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t304-2">
   <w.rf>
    <LM>w#w-d1t304-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t304-3">
   <w.rf>
    <LM>w#w-d1t304-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t304-9">
   <w.rf>
    <LM>w#w-d1t304-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t304-10">
   <w.rf>
    <LM>w#w-d1t304-10</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m133-d1t304-4">
   <w.rf>
    <LM>w#w-d1t304-4</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t304-7">
   <w.rf>
    <LM>w#w-d1t304-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t304-8">
   <w.rf>
    <LM>w#w-d1t304-8</LM>
   </w.rf>
   <form>okně</form>
   <lemma>okno</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m133-d1t304-5">
   <w.rf>
    <LM>w#w-d1t304-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t304-6">
   <w.rf>
    <LM>w#w-d1t304-6</LM>
   </w.rf>
   <form>panenkami</form>
   <lemma>panenka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
 </s>
 <s id="m133-191">
  <m id="m133-d1t311-1">
   <w.rf>
    <LM>w#w-d1t311-1</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t311-2">
   <w.rf>
    <LM>w#w-d1t311-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m133-d1t311-4">
   <w.rf>
    <LM>w#w-d1t311-4</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t311-5">
   <w.rf>
    <LM>w#w-d1t311-5</LM>
   </w.rf>
   <form>chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d-id65625-punct">
   <w.rf>
    <LM>w#w-d-id65625-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t311-7">
   <w.rf>
    <LM>w#w-d1t311-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t311-8">
   <w.rf>
    <LM>w#w-d1t311-8</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m133-d1t311-9">
   <w.rf>
    <LM>w#w-d1t311-9</LM>
   </w.rf>
   <form>sklepy</form>
   <lemma>sklep</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m133-d1t311-10">
   <w.rf>
    <LM>w#w-d1t311-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t311-11">
   <w.rf>
    <LM>w#w-d1t311-11</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t311-12">
   <w.rf>
    <LM>w#w-d1t311-12</LM>
   </w.rf>
   <form>špinavé</form>
   <lemma>špinavý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m133-191-42">
   <w.rf>
    <LM>w#w-191-42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e269-x3">
  <m id="m133-d1t313-2">
   <w.rf>
    <LM>w#w-d1t313-2</LM>
   </w.rf>
   <form>Neumím</form>
   <lemma>umět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m133-d1t313-3">
   <w.rf>
    <LM>w#w-d1t313-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t313-4">
   <w.rf>
    <LM>w#w-d1t313-4</LM>
   </w.rf>
   <form>představit</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m133-d-id65798-punct">
   <w.rf>
    <LM>w#w-d-id65798-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t313-6">
   <w.rf>
    <LM>w#w-d1t313-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t313-8">
   <w.rf>
    <LM>w#w-d1t313-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t313-9">
   <w.rf>
    <LM>w#w-d1t313-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t313-7">
   <w.rf>
    <LM>w#w-d1t313-7</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-d1t313-10">
   <w.rf>
    <LM>w#w-d1t313-10</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t313-11">
   <w.rf>
    <LM>w#w-d1t313-11</LM>
   </w.rf>
   <form>hrály</form>
   <lemma>hrát</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d-id65900-punct">
   <w.rf>
    <LM>w#w-d-id65900-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t317-1">
   <w.rf>
    <LM>w#w-d1t317-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t317-2">
   <w.rf>
    <LM>w#w-d1t317-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t317-3">
   <w.rf>
    <LM>w#w-d1t317-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t317-4">
   <w.rf>
    <LM>w#w-d1t317-4</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t317-5">
   <w.rf>
    <LM>w#w-d1t317-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1e269-x3-43">
   <w.rf>
    <LM>w#w-d1e269-x3-43</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-44">
  <m id="m133-d1t322-1">
   <w.rf>
    <LM>w#w-d1t322-1</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t322-2">
   <w.rf>
    <LM>w#w-d1t322-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t322-3">
   <w.rf>
    <LM>w#w-d1t322-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t322-4">
   <w.rf>
    <LM>w#w-d1t322-4</LM>
   </w.rf>
   <form>vybombardovaný</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m133-d1t322-5">
   <w.rf>
    <LM>w#w-d1t322-5</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t324-1">
   <w.rf>
    <LM>w#w-d1t324-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t324-3">
   <w.rf>
    <LM>w#w-d1t324-3</LM>
   </w.rf>
   <form>Vinohradech</form>
   <lemma>Vinohrady_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m133-d-id66163-punct">
   <w.rf>
    <LM>w#w-d-id66163-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t328-2">
   <w.rf>
    <LM>w#w-d1t328-2</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m133-d1t328-10">
   <w.rf>
    <LM>w#w-d1t328-10</LM>
   </w.rf>
   <form>bomba</form>
   <lemma>bomba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t328-4">
   <w.rf>
    <LM>w#w-d1t328-4</LM>
   </w.rf>
   <form>strhnula</form>
   <lemma>strhnout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m133-d1t328-5">
   <w.rf>
    <LM>w#w-d1t328-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t328-6">
   <w.rf>
    <LM>w#w-d1t328-6</LM>
   </w.rf>
   <form>půlky</form>
   <lemma>půlka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-44-45">
   <w.rf>
    <LM>w#w-44-45</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-46">
  <m id="m133-d1t332-2">
   <w.rf>
    <LM>w#w-d1t332-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t332-3">
   <w.rf>
    <LM>w#w-d1t332-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m133-d1t332-4">
   <w.rf>
    <LM>w#w-d1t332-4</LM>
   </w.rf>
   <form>půlka</form>
   <lemma>půlka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t332-5">
   <w.rf>
    <LM>w#w-d1t332-5</LM>
   </w.rf>
   <form>zařízených</form>
   <lemma>zařízený_^(*4dit)</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m133-d1t332-6">
   <w.rf>
    <LM>w#w-d1t332-6</LM>
   </w.rf>
   <form>bytů</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m133-46-47">
   <w.rf>
    <LM>w#w-46-47</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-48">
  <m id="m133-d1t335-1">
   <w.rf>
    <LM>w#w-d1t335-1</LM>
   </w.rf>
   <form>Někteří</form>
   <lemma>některý</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m133-d1t335-2">
   <w.rf>
    <LM>w#w-d1t335-2</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m133-d1t335-3">
   <w.rf>
    <LM>w#w-d1t335-3</LM>
   </w.rf>
   <form>prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t335-5">
   <w.rf>
    <LM>w#w-d1t335-5</LM>
   </w.rf>
   <form>vyskákali</form>
   <lemma>vyskákat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m133-d1t335-6">
   <w.rf>
    <LM>w#w-d1t335-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t335-7">
   <w.rf>
    <LM>w#w-d1t335-7</LM>
   </w.rf>
   <form>oken</form>
   <lemma>okno</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m133-d1t335-9">
   <w.rf>
    <LM>w#w-d1t335-9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t335-10">
   <w.rf>
    <LM>w#w-d1t335-10</LM>
   </w.rf>
   <form>spadli</form>
   <lemma>spadnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m133-d1t335-11">
   <w.rf>
    <LM>w#w-d1t335-11</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-48-50">
   <w.rf>
    <LM>w#w-48-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-51">
  <m id="m133-d1t335-15">
   <w.rf>
    <LM>w#w-d1t335-15</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t335-14">
   <w.rf>
    <LM>w#w-d1t335-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t335-16">
   <w.rf>
    <LM>w#w-d1t335-16</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m133-d1t335-17">
   <w.rf>
    <LM>w#w-d1t335-17</LM>
   </w.rf>
   <form>katastrofa</form>
   <lemma>katastrofa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-51-52">
   <w.rf>
    <LM>w#w-51-52</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e269-x4">
  <m id="m133-d1t341-8">
   <w.rf>
    <LM>w#w-d1t341-8</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t341-9">
   <w.rf>
    <LM>w#w-d1t341-9</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m133-d1t341-10">
   <w.rf>
    <LM>w#w-d1t341-10</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m133-d1t341-6">
   <w.rf>
    <LM>w#w-d1t341-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t341-7">
   <w.rf>
    <LM>w#w-d1t341-7</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t341-11">
   <w.rf>
    <LM>w#w-d1t341-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t341-12">
   <w.rf>
    <LM>w#w-d1t341-12</LM>
   </w.rf>
   <form>prvé</form>
   <lemma>prvý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m133-d1t341-13">
   <w.rf>
    <LM>w#w-d1t341-13</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d1e269-x4-83">
   <w.rf>
    <LM>w#w-d1e269-x4-83</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-84">
  <m id="m133-d1t345-3">
   <w.rf>
    <LM>w#w-d1t345-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t345-4">
   <w.rf>
    <LM>w#w-d1t345-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t345-5">
   <w.rf>
    <LM>w#w-d1t345-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t345-6">
   <w.rf>
    <LM>w#w-d1t345-6</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m133-d1t345-7">
   <w.rf>
    <LM>w#w-d1t345-7</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m133-d-id67076-punct">
   <w.rf>
    <LM>w#w-d-id67076-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t345-9">
   <w.rf>
    <LM>w#w-d1t345-9</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t348-2">
   <w.rf>
    <LM>w#w-d1t348-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t348-1">
   <w.rf>
    <LM>w#w-d1t348-1</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t348-4">
   <w.rf>
    <LM>w#w-d1t348-4</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-84-85">
   <w.rf>
    <LM>w#w-84-85</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-86">
  <m id="m133-d1t348-6">
   <w.rf>
    <LM>w#w-d1t348-6</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t348-8">
   <w.rf>
    <LM>w#w-d1t348-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t348-10">
   <w.rf>
    <LM>w#w-d1t348-10</LM>
   </w.rf>
   <form>osvobození</form>
   <lemma>osvobození_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m133-d1e269-x4-58">
   <w.rf>
    <LM>w#w-d1e269-x4-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-61">
  <m id="m133-d1t341-3">
   <w.rf>
    <LM>w#w-d1t341-3</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t341-2">
   <w.rf>
    <LM>w#w-d1t341-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-61-87">
   <w.rf>
    <LM>w#w-61-87</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-61-88">
   <w.rf>
    <LM>w#w-61-88</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t350-3">
   <w.rf>
    <LM>w#w-d1t350-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m133-d1t350-4">
   <w.rf>
    <LM>w#w-d1t350-4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m133-d1t350-1">
   <w.rf>
    <LM>w#w-d1t350-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t350-2">
   <w.rf>
    <LM>w#w-d1t350-2</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d1t350-5">
   <w.rf>
    <LM>w#w-d1t350-5</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m133-d1t350-6">
   <w.rf>
    <LM>w#w-d1t350-6</LM>
   </w.rf>
   <form>holčička</form>
   <lemma>holčička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t350-7">
   <w.rf>
    <LM>w#w-d1t350-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t350-8">
   <w.rf>
    <LM>w#w-d1t350-8</LM>
   </w.rf>
   <form>koncentračního</form>
   <lemma>koncentrační</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m133-d1t350-9">
   <w.rf>
    <LM>w#w-d1t350-9</LM>
   </w.rf>
   <form>tábora</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m133-d-id67421-punct">
   <w.rf>
    <LM>w#w-d-id67421-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t352-1">
   <w.rf>
    <LM>w#w-d1t352-1</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m133-d1t352-2">
   <w.rf>
    <LM>w#w-d1t352-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t352-5">
   <w.rf>
    <LM>w#w-d1t352-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t352-6">
   <w.rf>
    <LM>w#w-d1t352-6</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m133-d1t352-3">
   <w.rf>
    <LM>w#w-d1t352-3</LM>
   </w.rf>
   <form>vytetované</form>
   <lemma>vytetovaný_^(*2t)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m133-d1t352-4">
   <w.rf>
    <LM>w#w-d1t352-4</LM>
   </w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m133-61-89">
   <w.rf>
    <LM>w#w-61-89</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-90">
  <m id="m133-d1t352-8">
   <w.rf>
    <LM>w#w-d1t352-8</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t352-11">
   <w.rf>
    <LM>w#w-d1t352-11</LM>
   </w.rf>
   <form>panenku</form>
   <lemma>panenka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-d-id67610-punct">
   <w.rf>
    <LM>w#w-d-id67610-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t354-1">
   <w.rf>
    <LM>w#w-d1t354-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS3----------</tag>
  </m>
  <m id="m133-d1t354-2">
   <w.rf>
    <LM>w#w-d1t354-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m133-d1t354-3">
   <w.rf>
    <LM>w#w-d1t354-3</LM>
   </w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m133-d1t354-4">
   <w.rf>
    <LM>w#w-d1t354-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t354-5">
   <w.rf>
    <LM>w#w-d1t354-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t354-7">
   <w.rf>
    <LM>w#w-d1t354-7</LM>
   </w.rf>
   <form>ruku</form>
   <lemma>ruka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-d1t354-8">
   <w.rf>
    <LM>w#w-d1t354-8</LM>
   </w.rf>
   <form>napsala</form>
   <lemma>napsat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m133-90-91">
   <w.rf>
    <LM>w#w-90-91</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-92">
  <m id="m133-d1t361-2">
   <w.rf>
    <LM>w#w-d1t361-2</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t361-3">
   <w.rf>
    <LM>w#w-d1t361-3</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d1t361-5">
   <w.rf>
    <LM>w#w-d1t361-5</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t361-6">
   <w.rf>
    <LM>w#w-d1t361-6</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t361-7">
   <w.rf>
    <LM>w#w-d1t361-7</LM>
   </w.rf>
   <form>vzpomínek</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m133-92-108">
   <w.rf>
    <LM>w#w-92-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e269-x5">
  <m id="m133-d1t361-9">
   <w.rf>
    <LM>w#w-d1t361-9</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t361-10">
   <w.rf>
    <LM>w#w-d1t361-10</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m133-d1t361-11">
   <w.rf>
    <LM>w#w-d1t361-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t361-12">
   <w.rf>
    <LM>w#w-d1t361-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m133-d-id67971-punct">
   <w.rf>
    <LM>w#w-d-id67971-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t361-14">
   <w.rf>
    <LM>w#w-d1t361-14</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t361-15">
   <w.rf>
    <LM>w#w-d1t361-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m133-d1t363-1">
   <w.rf>
    <LM>w#w-d1t363-1</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t363-2">
   <w.rf>
    <LM>w#w-d1t363-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t363-3">
   <w.rf>
    <LM>w#w-d1t363-3</LM>
   </w.rf>
   <form>obchodu</form>
   <lemma>obchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m133-d-id68066-punct">
   <w.rf>
    <LM>w#w-d-id68066-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t367-1">
   <w.rf>
    <LM>w#w-d1t367-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t367-2">
   <w.rf>
    <LM>w#w-d1t367-2</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t367-7">
   <w.rf>
    <LM>w#w-d1t367-7</LM>
   </w.rf>
   <form>nakupovat</form>
   <lemma>nakupovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m133-d1t367-3">
   <w.rf>
    <LM>w#w-d1t367-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t367-5">
   <w.rf>
    <LM>w#w-d1t367-5</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m133-d1e269-x5-119">
   <w.rf>
    <LM>w#w-d1e269-x5-119</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-121">
  <m id="m133-d1t367-9">
   <w.rf>
    <LM>w#w-d1t367-9</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m133-d1t367-10">
   <w.rf>
    <LM>w#w-d1t367-10</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t367-11">
   <w.rf>
    <LM>w#w-d1t367-11</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t367-14">
   <w.rf>
    <LM>w#w-d1t367-14</LM>
   </w.rf>
   <form>oproti</form>
   <lemma>oproti</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m133-d1t367-15">
   <w.rf>
    <LM>w#w-d1t367-15</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m133-d1t367-12">
   <w.rf>
    <LM>w#w-d1t367-12</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m133-d1t367-13">
   <w.rf>
    <LM>w#w-d1t367-13</LM>
   </w.rf>
   <form>příděly</form>
   <lemma>příděl</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m133-121-126">
   <w.rf>
    <LM>w#w-121-126</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-127">
  <m id="m133-d1t371-2">
   <w.rf>
    <LM>w#w-d1t371-2</LM>
   </w.rf>
   <form>Německá</form>
   <lemma>německý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m133-d1t371-3">
   <w.rf>
    <LM>w#w-d1t371-3</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t371-4">
   <w.rf>
    <LM>w#w-d1t371-4</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m133-d1t371-5">
   <w.rf>
    <LM>w#w-d1t371-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t371-6">
   <w.rf>
    <LM>w#w-d1t371-6</LM>
   </w.rf>
   <form>másla</form>
   <lemma>máslo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m133-d-id68432-punct">
   <w.rf>
    <LM>w#w-d-id68432-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t371-8">
   <w.rf>
    <LM>w#w-d1t371-8</LM>
   </w.rf>
   <form>kdežto</form>
   <lemma>kdežto</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t374-1">
   <w.rf>
    <LM>w#w-d1t374-1</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m133-d1t374-2">
   <w.rf>
    <LM>w#w-d1t374-2</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t374-3">
   <w.rf>
    <LM>w#w-d1t374-3</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t374-4">
   <w.rf>
    <LM>w#w-d1t374-4</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS4----------</tag>
  </m>
  <m id="m133-121-123">
   <w.rf>
    <LM>w#w-121-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-125">
  <m id="m133-d1t384-4">
   <w.rf>
    <LM>w#w-d1t384-4</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t384-5">
   <w.rf>
    <LM>w#w-d1t384-5</LM>
   </w.rf>
   <form>jídle</form>
   <lemma>jídlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m133-d1t384-1">
   <w.rf>
    <LM>w#w-d1t384-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t384-2">
   <w.rf>
    <LM>w#w-d1t384-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t384-6">
   <w.rf>
    <LM>w#w-d1t384-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t384-7">
   <w.rf>
    <LM>w#w-d1t384-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m133-d1t384-8">
   <w.rf>
    <LM>w#w-d1t384-8</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-125-138">
   <w.rf>
    <LM>w#w-125-138</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e269-x6">
  <m id="m133-d1t387-3">
   <w.rf>
    <LM>w#w-d1t387-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t387-4">
   <w.rf>
    <LM>w#w-d1t387-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m133-d1t387-5">
   <w.rf>
    <LM>w#w-d1t387-5</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t387-6">
   <w.rf>
    <LM>w#w-d1t387-6</LM>
   </w.rf>
   <form>brambory</form>
   <lemma>brambor</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m133-d1t387-7">
   <w.rf>
    <LM>w#w-d1t387-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t387-8">
   <w.rf>
    <LM>w#w-d1t387-8</LM>
   </w.rf>
   <form>máslem</form>
   <lemma>máslo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m133-d-id68856-punct">
   <w.rf>
    <LM>w#w-d-id68856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t391-4">
   <w.rf>
    <LM>w#w-d1t391-4</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t391-5">
   <w.rf>
    <LM>w#w-d1t391-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t391-6">
   <w.rf>
    <LM>w#w-d1t391-6</LM>
   </w.rf>
   <form>německou</form>
   <lemma>německý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m133-d1t391-7">
   <w.rf>
    <LM>w#w-d1t391-7</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-d-id68991-punct">
   <w.rf>
    <LM>w#w-d-id68991-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t391-9">
   <w.rf>
    <LM>w#w-d1t391-9</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m133-d1t391-10">
   <w.rf>
    <LM>w#w-d1t391-10</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m133-d1t391-11">
   <w.rf>
    <LM>w#w-d1t391-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t391-12">
   <w.rf>
    <LM>w#w-d1t391-12</LM>
   </w.rf>
   <form>bramboru</form>
   <lemma>brambora</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-d1t391-13">
   <w.rf>
    <LM>w#w-d1t391-13</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t391-14">
   <w.rf>
    <LM>w#w-d1t391-14</LM>
   </w.rf>
   <form>másla</form>
   <lemma>máslo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m133-d1e269-x6-30">
   <w.rf>
    <LM>w#w-d1e269-x6-30</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t393-1">
   <w.rf>
    <LM>w#w-d1t393-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t393-2">
   <w.rf>
    <LM>w#w-d1t393-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1e269-x6-142">
   <w.rf>
    <LM>w#w-d1e269-x6-142</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m133-d1t393-3">
   <w.rf>
    <LM>w#w-d1t393-3</LM>
   </w.rf>
   <form>českou</form>
   <lemma>český</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m133-d1t393-4">
   <w.rf>
    <LM>w#w-d1t393-4</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-d1e269-x6-29">
   <w.rf>
    <LM>w#w-d1e269-x6-29</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1e269-x6-140">
   <w.rf>
    <LM>w#w-d1e269-x6-140</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t393-8">
   <w.rf>
    <LM>w#w-d1t393-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t393-9">
   <w.rf>
    <LM>w#w-d1t393-9</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m133-d1t393-10">
   <w.rf>
    <LM>w#w-d1t393-10</LM>
   </w.rf>
   <form>brambora</form>
   <lemma>brambora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t393-11">
   <w.rf>
    <LM>w#w-d1t393-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t393-12">
   <w.rf>
    <LM>w#w-d1t393-12</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t393-13">
   <w.rf>
    <LM>w#w-d1t393-13</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS1----------</tag>
  </m>
  <m id="m133-d1t393-14">
   <w.rf>
    <LM>w#w-d1t393-14</LM>
   </w.rf>
   <form>máslo</form>
   <lemma>máslo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m133-d1t393-15">
   <w.rf>
    <LM>w#w-d1t393-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t393-16">
   <w.rf>
    <LM>w#w-d1t393-16</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m133-d-m-d1e269-x6-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e269-x6-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e400-x2">
  <m id="m133-d1t403-1">
   <w.rf>
    <LM>w#w-d1t403-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m133-d1e400-x2-146">
   <w.rf>
    <LM>w#w-d1e400-x2-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-147">
  <m id="m133-d1t407-1">
   <w.rf>
    <LM>w#w-d1t407-1</LM>
   </w.rf>
   <form>Prohlédneme</form>
   <lemma>prohlédnout</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m133-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t409-2">
   <w.rf>
    <LM>w#w-d1t409-2</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m133-d1t409-3">
   <w.rf>
    <LM>w#w-d1t409-3</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m133-147-148">
   <w.rf>
    <LM>w#w-147-148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-149">
  <m id="m133-d1t411-1">
   <w.rf>
    <LM>w#w-d1t411-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m133-d1t411-2">
   <w.rf>
    <LM>w#w-d1t411-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m133-d1t411-3">
   <w.rf>
    <LM>w#w-d1t411-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t411-4">
   <w.rf>
    <LM>w#w-d1t411-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m133-d1t411-5">
   <w.rf>
    <LM>w#w-d1t411-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m133-d-id69602-punct">
   <w.rf>
    <LM>w#w-d-id69602-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e412-x2">
  <m id="m133-d1t419-3">
   <w.rf>
    <LM>w#w-d1t419-3</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m133-d1t419-4">
   <w.rf>
    <LM>w#w-d1t419-4</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m133-d1t419-5">
   <w.rf>
    <LM>w#w-d1t419-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t421-1">
   <w.rf>
    <LM>w#w-d1t421-1</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m133-d1t421-2">
   <w.rf>
    <LM>w#w-d1t421-2</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m133-d1e412-x2-160">
   <w.rf>
    <LM>w#w-d1e412-x2-160</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-161">
  <m id="m133-d1t421-5">
   <w.rf>
    <LM>w#w-d1t421-5</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t421-6">
   <w.rf>
    <LM>w#w-d1t421-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m133-d1t423-1">
   <w.rf>
    <LM>w#w-d1t423-1</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m133-d1t423-2">
   <w.rf>
    <LM>w#w-d1t423-2</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m133-d1t423-3">
   <w.rf>
    <LM>w#w-d1t423-3</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t423-4">
   <w.rf>
    <LM>w#w-d1t423-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t423-5">
   <w.rf>
    <LM>w#w-d1t423-5</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m133-161-162">
   <w.rf>
    <LM>w#w-161-162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-163">
  <m id="m133-d1t430-2">
   <w.rf>
    <LM>w#w-d1t430-2</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t430-3">
   <w.rf>
    <LM>w#w-d1t430-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t430-4">
   <w.rf>
    <LM>w#w-d1t430-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m133-d1t430-5">
   <w.rf>
    <LM>w#w-d1t430-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m133-d1t430-6">
   <w.rf>
    <LM>w#w-d1t430-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t434-2">
   <w.rf>
    <LM>w#w-d1t434-2</LM>
   </w.rf>
   <form>hitem</form>
   <lemma>hit</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m133-163-165">
   <w.rf>
    <LM>w#w-163-165</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t434-3">
   <w.rf>
    <LM>w#w-d1t434-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t434-4">
   <w.rf>
    <LM>w#w-d1t434-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t436-1">
   <w.rf>
    <LM>w#w-d1t436-1</LM>
   </w.rf>
   <form>všeobecně</form>
   <lemma>všeobecně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m133-d1t436-2">
   <w.rf>
    <LM>w#w-d1t436-2</LM>
   </w.rf>
   <form>známým</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m133-d1t436-3">
   <w.rf>
    <LM>w#w-d1t436-3</LM>
   </w.rf>
   <form>spolkem</form>
   <lemma>spolek</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m133-163-166">
   <w.rf>
    <LM>w#w-163-166</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t441-2">
   <w.rf>
    <LM>w#w-d1t441-2</LM>
   </w.rf>
   <form>spolek</form>
   <lemma>spolek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m133-d1t441-3">
   <w.rf>
    <LM>w#w-d1t441-3</LM>
   </w.rf>
   <form>baráčníků</form>
   <lemma>baráčník</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m133-d-id70263-punct">
   <w.rf>
    <LM>w#w-d-id70263-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t443-5">
   <w.rf>
    <LM>w#w-d1t443-5</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t443-2">
   <w.rf>
    <LM>w#w-d1t443-2</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m133-d1t443-3">
   <w.rf>
    <LM>w#w-d1t443-3</LM>
   </w.rf>
   <form>tatínkovy</form>
   <lemma>tatínkův_^(*3ek)</lemma>
   <tag>AUFP1M---------</tag>
  </m>
  <m id="m133-d1t443-4">
   <w.rf>
    <LM>w#w-d1t443-4</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-d1t443-6">
   <w.rf>
    <LM>w#w-d1t443-6</LM>
   </w.rf>
   <form>originál</form>
   <lemma>originál-2_^(originál_kroje)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m133-d1t443-7">
   <w.rf>
    <LM>w#w-d1t443-7</LM>
   </w.rf>
   <form>kroje</form>
   <lemma>kroj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m133-163-167">
   <w.rf>
    <LM>w#w-163-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-164">
  <m id="m133-d1t443-10">
   <w.rf>
    <LM>w#w-d1t443-10</LM>
   </w.rf>
   <form>Teta</form>
   <lemma>teta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t445-2">
   <w.rf>
    <LM>w#w-d1t445-2</LM>
   </w.rf>
   <form>Marie</form>
   <lemma>Marie_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t445-4">
   <w.rf>
    <LM>w#w-d1t445-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t445-5">
   <w.rf>
    <LM>w#w-d1t445-5</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t445-6">
   <w.rf>
    <LM>w#w-d1t445-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m133-164-181">
   <w.rf>
    <LM>w#w-164-181</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t445-8">
   <w.rf>
    <LM>w#w-d1t445-8</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t445-9">
   <w.rf>
    <LM>w#w-d1t445-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t445-10">
   <w.rf>
    <LM>w#w-d1t445-10</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m133-d1t447-1">
   <w.rf>
    <LM>w#w-d1t447-1</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m133-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>Mařenky</form>
   <lemma>Mařenka_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-d-id70644-punct">
   <w.rf>
    <LM>w#w-d-id70644-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t447-6">
   <w.rf>
    <LM>w#w-d1t447-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t447-7">
   <w.rf>
    <LM>w#w-d1t447-7</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t447-8">
   <w.rf>
    <LM>w#w-d1t447-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t447-9">
   <w.rf>
    <LM>w#w-d1t447-9</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t447-10">
   <w.rf>
    <LM>w#w-d1t447-10</LM>
   </w.rf>
   <form>mladoboleslavský</form>
   <lemma>mladoboleslavský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m133-164-183">
   <w.rf>
    <LM>w#w-164-183</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e412-x3">
  <m id="m133-d1t452-4">
   <w.rf>
    <LM>w#w-d1t452-4</LM>
   </w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m133-d1t452-5">
   <w.rf>
    <LM>w#w-d1t452-5</LM>
   </w.rf>
   <form>tety</form>
   <lemma>teta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-d1t452-3">
   <w.rf>
    <LM>w#w-d1t452-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m133-d1t452-2">
   <w.rf>
    <LM>w#w-d1t452-2</LM>
   </w.rf>
   <form>brávaly</form>
   <lemma>brávat_^(*3t)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t452-6">
   <w.rf>
    <LM>w#w-d1t452-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t452-7">
   <w.rf>
    <LM>w#w-d1t452-7</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m133-d-id70864-punct">
   <w.rf>
    <LM>w#w-d-id70864-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t452-10">
   <w.rf>
    <LM>w#w-d1t452-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t452-11">
   <w.rf>
    <LM>w#w-d1t452-11</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t452-12">
   <w.rf>
    <LM>w#w-d1t452-12</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m133-d1t454-1">
   <w.rf>
    <LM>w#w-d1t454-1</LM>
   </w.rf>
   <form>baráčnické</form>
   <lemma>baráčnický</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m133-d1t452-13">
   <w.rf>
    <LM>w#w-d1t452-13</LM>
   </w.rf>
   <form>slavnosti</form>
   <lemma>slavnost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-d1e412-x3-184">
   <w.rf>
    <LM>w#w-d1e412-x3-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-186">
  <m id="m133-d1t454-3">
   <w.rf>
    <LM>w#w-d1t454-3</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t454-4">
   <w.rf>
    <LM>w#w-d1t454-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t454-5">
   <w.rf>
    <LM>w#w-d1t454-5</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t454-6">
   <w.rf>
    <LM>w#w-d1t454-6</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m133-d1t454-7">
   <w.rf>
    <LM>w#w-d1t454-7</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t454-8">
   <w.rf>
    <LM>w#w-d1t454-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t454-9">
   <w.rf>
    <LM>w#w-d1t454-9</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t454-10">
   <w.rf>
    <LM>w#w-d1t454-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t454-11">
   <w.rf>
    <LM>w#w-d1t454-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m133-d1t454-12">
   <w.rf>
    <LM>w#w-d1t454-12</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m133-d-m-d1e412-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e412-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e461-x2">
  <m id="m133-d1t464-1">
   <w.rf>
    <LM>w#w-d1t464-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m133-d1t464-2">
   <w.rf>
    <LM>w#w-d1t464-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t464-3">
   <w.rf>
    <LM>w#w-d1t464-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t464-4">
   <w.rf>
    <LM>w#w-d1t464-4</LM>
   </w.rf>
   <form>baráčníci</form>
   <lemma>baráčník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m133-d-id71261-punct">
   <w.rf>
    <LM>w#w-d-id71261-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e465-x2">
  <m id="m133-d1t474-1">
   <w.rf>
    <LM>w#w-d1t474-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t474-2">
   <w.rf>
    <LM>w#w-d1t474-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t474-5">
   <w.rf>
    <LM>w#w-d1t474-5</LM>
   </w.rf>
   <form>dobrovolný</form>
   <lemma>dobrovolný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m133-d1t474-6">
   <w.rf>
    <LM>w#w-d1t474-6</LM>
   </w.rf>
   <form>spolek</form>
   <lemma>spolek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m133-d1t479-1">
   <w.rf>
    <LM>w#w-d1t479-1</LM>
   </w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m133-d-id71476-punct">
   <w.rf>
    <LM>w#w-d-id71476-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t479-3">
   <w.rf>
    <LM>w#w-d1t479-3</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m133-d1t479-4">
   <w.rf>
    <LM>w#w-d1t479-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m133-d1t479-5">
   <w.rf>
    <LM>w#w-d1t479-5</LM>
   </w.rf>
   <form>snažili</form>
   <lemma>snažit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t479-6">
   <w.rf>
    <LM>w#w-d1t479-6</LM>
   </w.rf>
   <form>udržovat</form>
   <lemma>udržovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m133-d1t481-6">
   <w.rf>
    <LM>w#w-d1t481-6</LM>
   </w.rf>
   <form>oblastní</form>
   <lemma>oblastní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m133-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>krojové</form>
   <lemma>krojový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m133-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>tradice</form>
   <lemma>tradice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m133-d1e465-x2-196">
   <w.rf>
    <LM>w#w-d1e465-x2-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-197">
  <m id="m133-d1t485-2">
   <w.rf>
    <LM>w#w-d1t485-2</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t489-2">
   <w.rf>
    <LM>w#w-d1t489-2</LM>
   </w.rf>
   <form>setkání</form>
   <lemma>setkání_^(*3at)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m133-d-id71754-punct">
   <w.rf>
    <LM>w#w-d-id71754-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t489-4">
   <w.rf>
    <LM>w#w-d1t489-4</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4NP1----------</tag>
  </m>
  <m id="m133-d1t489-6">
   <w.rf>
    <LM>w#w-d1t489-6</LM>
   </w.rf>
   <form>bývala</form>
   <lemma>bývat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t489-5">
   <w.rf>
    <LM>w#w-d1t489-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t492-1">
   <w.rf>
    <LM>w#w-d1t492-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t492-2">
   <w.rf>
    <LM>w#w-d1t492-2</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP6----------</tag>
  </m>
  <m id="m133-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>zahradních</form>
   <lemma>zahradní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m133-d1t492-4">
   <w.rf>
    <LM>w#w-d1t492-4</LM>
   </w.rf>
   <form>restauracích</form>
   <lemma>restaurace</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m133-d-id71881-punct">
   <w.rf>
    <LM>w#w-d-id71881-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t492-6">
   <w.rf>
    <LM>w#w-d1t492-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m133-d1t492-7">
   <w.rf>
    <LM>w#w-d1t492-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t492-8">
   <w.rf>
    <LM>w#w-d1t492-8</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m133-197-198">
   <w.rf>
    <LM>w#w-197-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-199">
  <m id="m133-d1t492-10">
   <w.rf>
    <LM>w#w-d1t492-10</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t492-11">
   <w.rf>
    <LM>w#w-d1t492-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t494-1">
   <w.rf>
    <LM>w#w-d1t494-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m133-d1t494-2">
   <w.rf>
    <LM>w#w-d1t494-2</LM>
   </w.rf>
   <form>živou</form>
   <lemma>živý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m133-d1t494-3">
   <w.rf>
    <LM>w#w-d1t494-3</LM>
   </w.rf>
   <form>muzikou</form>
   <lemma>muzika</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m133-199-200">
   <w.rf>
    <LM>w#w-199-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-201">
  <m id="m133-d1t494-7">
   <w.rf>
    <LM>w#w-d1t494-7</LM>
   </w.rf>
   <form>Tancovalo</form>
   <lemma>tancovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t494-6">
   <w.rf>
    <LM>w#w-d1t494-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m133-201-202">
   <w.rf>
    <LM>w#w-201-202</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-203">
  <m id="m133-d1t498-2">
   <w.rf>
    <LM>w#w-d1t498-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t498-5">
   <w.rf>
    <LM>w#w-d1t498-5</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d-id72195-punct">
   <w.rf>
    <LM>w#w-d-id72195-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t498-7">
   <w.rf>
    <LM>w#w-d1t498-7</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m133-d1t498-10">
   <w.rf>
    <LM>w#w-d1t498-10</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t498-9">
   <w.rf>
    <LM>w#w-d1t498-9</LM>
   </w.rf>
   <form>udržovala</form>
   <lemma>udržovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t498-12">
   <w.rf>
    <LM>w#w-d1t498-12</LM>
   </w.rf>
   <form>lidové</form>
   <lemma>lidový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m133-d1t498-13">
   <w.rf>
    <LM>w#w-d1t498-13</LM>
   </w.rf>
   <form>zábavy</form>
   <lemma>zábava</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m133-203-204">
   <w.rf>
    <LM>w#w-203-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-205">
  <m id="m133-d1t502-1">
   <w.rf>
    <LM>w#w-d1t502-1</LM>
   </w.rf>
   <form>Nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m133-d1t502-2">
   <w.rf>
    <LM>w#w-d1t502-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t502-3">
   <w.rf>
    <LM>w#w-d1t502-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t502-4">
   <w.rf>
    <LM>w#w-d1t502-4</LM>
   </w.rf>
   <form>obyčejných</form>
   <lemma>obyčejný</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m133-d1t502-5">
   <w.rf>
    <LM>w#w-d1t502-5</LM>
   </w.rf>
   <form>šatech</form>
   <lemma>šaty</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m133-d1t502-6">
   <w.rf>
    <LM>w#w-d1t502-6</LM>
   </w.rf>
   <form>nechodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m133-205-220">
   <w.rf>
    <LM>w#w-205-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e465-x3">
  <m id="m133-d1t502-8">
   <w.rf>
    <LM>w#w-d1t502-8</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m133-d1t502-9">
   <w.rf>
    <LM>w#w-d1t502-9</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t502-10">
   <w.rf>
    <LM>w#w-d1t502-10</LM>
   </w.rf>
   <form>svoje</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP4----------</tag>
  </m>
  <m id="m133-d1t505-1">
   <w.rf>
    <LM>w#w-d1t505-1</LM>
   </w.rf>
   <form>kroje</form>
   <lemma>kroj</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m133-d-id72510-punct">
   <w.rf>
    <LM>w#w-d-id72510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t505-3">
   <w.rf>
    <LM>w#w-d1t505-3</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4YP4----------</tag>
  </m>
  <m id="m133-d1t505-4">
   <w.rf>
    <LM>w#w-d1t505-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m133-d1t505-5">
   <w.rf>
    <LM>w#w-d1t505-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t505-6">
   <w.rf>
    <LM>w#w-d1t505-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1t509-1">
   <w.rf>
    <LM>w#w-d1t509-1</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m133-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>vyšívali</form>
   <lemma>vyšívat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d-id72630-punct">
   <w.rf>
    <LM>w#w-d-id72630-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t509-4">
   <w.rf>
    <LM>w#w-d1t509-4</LM>
   </w.rf>
   <form>šili</form>
   <lemma>šít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d-id72654-punct">
   <w.rf>
    <LM>w#w-d-id72654-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t509-6">
   <w.rf>
    <LM>w#w-d1t509-6</LM>
   </w.rf>
   <form>zhotovovali</form>
   <lemma>zhotovovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m133-d1t509-7">
   <w.rf>
    <LM>w#w-d1t509-7</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t511-1">
   <w.rf>
    <LM>w#w-d1t511-1</LM>
   </w.rf>
   <form>tradičních</form>
   <lemma>tradiční</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m133-d1t511-2">
   <w.rf>
    <LM>w#w-d1t511-2</LM>
   </w.rf>
   <form>krojů</form>
   <lemma>kroj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m133-d1e465-x3-221">
   <w.rf>
    <LM>w#w-d1e465-x3-221</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-222">
  <m id="m133-d1t515-4">
   <w.rf>
    <LM>w#w-d1t515-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t515-3">
   <w.rf>
    <LM>w#w-d1t515-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t515-5">
   <w.rf>
    <LM>w#w-d1t515-5</LM>
   </w.rf>
   <form>spolek</form>
   <lemma>spolek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m133-d-id72836-punct">
   <w.rf>
    <LM>w#w-d-id72836-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t515-7">
   <w.rf>
    <LM>w#w-d1t515-7</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m133-d1t515-8">
   <w.rf>
    <LM>w#w-d1t515-8</LM>
   </w.rf>
   <form>udržoval</form>
   <lemma>udržovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t515-13">
   <w.rf>
    <LM>w#w-d1t515-13</LM>
   </w.rf>
   <form>krajové</form>
   <lemma>krajový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m133-d1t515-14">
   <w.rf>
    <LM>w#w-d1t515-14</LM>
   </w.rf>
   <form>tradice</form>
   <lemma>tradice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m133-d-m-d1e465-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e465-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e522-x2">
  <m id="m133-d1t525-2">
   <w.rf>
    <LM>w#w-d1t525-2</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t525-3">
   <w.rf>
    <LM>w#w-d1t525-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m133-d1t525-4">
   <w.rf>
    <LM>w#w-d1t525-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t525-5">
   <w.rf>
    <LM>w#w-d1t525-5</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m133-d1t525-6">
   <w.rf>
    <LM>w#w-d1t525-6</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d-id73102-punct">
   <w.rf>
    <LM>w#w-d-id73102-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-d1e526-x2">
  <m id="m133-d1t529-1">
   <w.rf>
    <LM>w#w-d1t529-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m133-d1e526-x2-233">
   <w.rf>
    <LM>w#w-d1e526-x2-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-234">
  <m id="m133-d1t529-3">
   <w.rf>
    <LM>w#w-d1t529-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m133-d1t529-4">
   <w.rf>
    <LM>w#w-d1t529-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t529-5">
   <w.rf>
    <LM>w#w-d1t529-5</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t529-6">
   <w.rf>
    <LM>w#w-d1t529-6</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t533-4">
   <w.rf>
    <LM>w#w-d1t533-4</LM>
   </w.rf>
   <form>kroj</form>
   <lemma>kroj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t533-3">
   <w.rf>
    <LM>w#w-d1t533-3</LM>
   </w.rf>
   <form>české</form>
   <lemma>český</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m133-d1t533-7">
   <w.rf>
    <LM>w#w-d1t533-7</LM>
   </w.rf>
   <form>Mařenky</form>
   <lemma>Mařenka_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m133-234-235">
   <w.rf>
    <LM>w#w-234-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-236">
  <m id="m133-d1t542-1">
   <w.rf>
    <LM>w#w-d1t542-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m133-d1t542-2">
   <w.rf>
    <LM>w#w-d1t542-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t542-3">
   <w.rf>
    <LM>w#w-d1t542-3</LM>
   </w.rf>
   <form>podobné</form>
   <lemma>podobný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m133-d1t542-5">
   <w.rf>
    <LM>w#w-d1t542-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m133-d1t542-6">
   <w.rf>
    <LM>w#w-d1t542-6</LM>
   </w.rf>
   <form>kroji</form>
   <lemma>kroj</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m133-d-id73522-punct">
   <w.rf>
    <LM>w#w-d-id73522-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t542-8">
   <w.rf>
    <LM>w#w-d1t542-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m133-d1t542-9">
   <w.rf>
    <LM>w#w-d1t542-9</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m133-d1t542-10">
   <w.rf>
    <LM>w#w-d1t542-10</LM>
   </w.rf>
   <form>teta</form>
   <lemma>teta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m133-d1t542-11">
   <w.rf>
    <LM>w#w-d1t542-11</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m133-d1t542-12">
   <w.rf>
    <LM>w#w-d1t542-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t542-13">
   <w.rf>
    <LM>w#w-d1t542-13</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m133-236-40">
   <w.rf>
    <LM>w#w-236-40</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-228">
  <m id="m133-236-41">
   <w.rf>
    <LM>w#w-236-41</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t544-3">
   <w.rf>
    <LM>w#w-d1t544-3</LM>
   </w.rf>
   <form>vyšívané</form>
   <lemma>vyšívaný_^(*2t)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m133-d1t544-4">
   <w.rf>
    <LM>w#w-d1t544-4</LM>
   </w.rf>
   <form>rukávy</form>
   <lemma>rukáv</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m133-236-239">
   <w.rf>
    <LM>w#w-236-239</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m133-d1t550-3">
   <w.rf>
    <LM>w#w-d1t550-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m133-d1t550-2">
   <w.rf>
    <LM>w#w-d1t550-2</LM>
   </w.rf>
   <form>čepec</form>
   <lemma>čepec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t550-4">
   <w.rf>
    <LM>w#w-d1t550-4</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m133-d1t550-6">
   <w.rf>
    <LM>w#w-d1t550-6</LM>
   </w.rf>
   <form>vdané</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m133-d1t550-5">
   <w.rf>
    <LM>w#w-d1t550-5</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m133-236-240">
   <w.rf>
    <LM>w#w-236-240</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-241">
  <m id="m133-d1t553-1">
   <w.rf>
    <LM>w#w-d1t553-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m133-d1t553-2">
   <w.rf>
    <LM>w#w-d1t553-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m133-d1t553-3">
   <w.rf>
    <LM>w#w-d1t553-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m133-d1t553-5">
   <w.rf>
    <LM>w#w-d1t553-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m133-d1t553-6">
   <w.rf>
    <LM>w#w-d1t553-6</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m133-d1t553-8">
   <w.rf>
    <LM>w#w-d1t553-8</LM>
   </w.rf>
   <form>ozdobný</form>
   <lemma>ozdobný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m133-d1t553-9">
   <w.rf>
    <LM>w#w-d1t553-9</LM>
   </w.rf>
   <form>věnec</form>
   <lemma>věnec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m133-d1t553-11">
   <w.rf>
    <LM>w#w-d1t553-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t553-12">
   <w.rf>
    <LM>w#w-d1t553-12</LM>
   </w.rf>
   <form>kytek</form>
   <lemma>kytka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m133-241-242">
   <w.rf>
    <LM>w#w-241-242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m133-243">
  <m id="m133-d1t557-1">
   <w.rf>
    <LM>w#w-d1t557-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m133-d1t557-2">
   <w.rf>
    <LM>w#w-d1t557-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m133-d1t557-3">
   <w.rf>
    <LM>w#w-d1t557-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m133-d1t557-6">
   <w.rf>
    <LM>w#w-d1t557-6</LM>
   </w.rf>
   <form>věnec</form>
   <lemma>věnec</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m133-d1t557-7">
   <w.rf>
    <LM>w#w-d1t557-7</LM>
   </w.rf>
   <form>uvitý</form>
   <lemma>uvitý_^(*3ít)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m133-d1t557-8">
   <w.rf>
    <LM>w#w-d1t557-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m133-d1t557-9">
   <w.rf>
    <LM>w#w-d1t557-9</LM>
   </w.rf>
   <form>přírodních</form>
   <lemma>přírodní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m133-d1t557-10">
   <w.rf>
    <LM>w#w-d1t557-10</LM>
   </w.rf>
   <form>květů</form>
   <lemma>květ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m133-243-244">
   <w.rf>
    <LM>w#w-243-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
