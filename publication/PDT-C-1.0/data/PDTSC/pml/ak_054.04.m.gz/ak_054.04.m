<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_054.04.w.gz" />
  </references>
 </head>
 <s id="m054-304">
  <m id="m054-d1t938-24">
   <w.rf>
    <LM>w#w-d1t938-24</LM>
   </w.rf>
   <form>Neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t938-26">
   <w.rf>
    <LM>w#w-d1t938-26</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t938-27">
   <w.rf>
    <LM>w#w-d1t938-27</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m054-210-211">
   <w.rf>
    <LM>w#w-210-211</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t938-28">
   <w.rf>
    <LM>w#w-d1t938-28</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t938-29">
   <w.rf>
    <LM>w#w-d1t938-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d-id94469-punct">
   <w.rf>
    <LM>w#w-d-id94469-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t938-31">
   <w.rf>
    <LM>w#w-d1t938-31</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m054-d1t938-32">
   <w.rf>
    <LM>w#w-d1t938-32</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t938-33">
   <w.rf>
    <LM>w#w-d1t938-33</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t938-34">
   <w.rf>
    <LM>w#w-d1t938-34</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m054-210-212">
   <w.rf>
    <LM>w#w-210-212</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-213">
  <m id="m054-d1t943-2">
   <w.rf>
    <LM>w#w-d1t943-2</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t943-3">
   <w.rf>
    <LM>w#w-d1t943-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t943-11">
   <w.rf>
    <LM>w#w-d1t943-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t943-13">
   <w.rf>
    <LM>w#w-d1t943-13</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m054-d1t943-14">
   <w.rf>
    <LM>w#w-d1t943-14</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léta</lemma>
   <tag>NNNP4-----A---2</tag>
  </m>
  <m id="m054-d1e914-x4-228">
   <w.rf>
    <LM>w#w-d1e914-x4-228</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t943-16">
   <w.rf>
    <LM>w#w-d1t943-16</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m054-d1t943-17">
   <w.rf>
    <LM>w#w-d1t943-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t943-18">
   <w.rf>
    <LM>w#w-d1t943-18</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t943-19">
   <w.rf>
    <LM>w#w-d1t943-19</LM>
   </w.rf>
   <form>svoji</form>
   <lemma>svůj-1</lemma>
   <tag>P8MP1----------</tag>
  </m>
  <m id="m054-d1e914-x4-227">
   <w.rf>
    <LM>w#w-d1e914-x4-227</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t943-12">
   <w.rf>
    <LM>w#w-d1t943-12</LM>
   </w.rf>
   <form>zaměstnanec</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t945-4">
   <w.rf>
    <LM>w#w-d1t945-4</LM>
   </w.rf>
   <form>Plzeňském</form>
   <lemma>plzeňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m054-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>magistrátě</form>
   <lemma>magistrát</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d1e914-x4-229">
   <w.rf>
    <LM>w#w-d1e914-x4-229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-230">
  <m id="m054-d1t954-3">
   <w.rf>
    <LM>w#w-d1t954-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1t954-4">
   <w.rf>
    <LM>w#w-d1t954-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t954-5">
   <w.rf>
    <LM>w#w-d1t954-5</LM>
   </w.rf>
   <form>Technické</form>
   <lemma>technický</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m054-d1t956-1">
   <w.rf>
    <LM>w#w-d1t956-1</LM>
   </w.rf>
   <form>úřady</form>
   <lemma>úřad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m054-230-236">
   <w.rf>
    <LM>w#w-230-236</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-237">
  <m id="m054-d1t956-2">
   <w.rf>
    <LM>w#w-d1t956-2</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t956-3">
   <w.rf>
    <LM>w#w-d1t956-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t956-4">
   <w.rf>
    <LM>w#w-d1t956-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e957-x2-257">
   <w.rf>
    <LM>w#w-d1e957-x2-257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t962-1">
   <w.rf>
    <LM>w#w-d1t962-1</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1e957-x2-258">
   <w.rf>
    <LM>w#w-d1e957-x2-258</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t970-2">
   <w.rf>
    <LM>w#w-d1t970-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t962-2">
   <w.rf>
    <LM>w#w-d1t962-2</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m054-d1t970-1">
   <w.rf>
    <LM>w#w-d1t970-1</LM>
   </w.rf>
   <form>pobočka</form>
   <lemma>pobočka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t970-3">
   <w.rf>
    <LM>w#w-d1t970-3</LM>
   </w.rf>
   <form>magistrátu</form>
   <lemma>magistrát</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m054-d1e967-x2-259">
   <w.rf>
    <LM>w#w-d1e967-x2-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-260">
  <m id="m054-d1t972-2">
   <w.rf>
    <LM>w#w-d1t972-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t972-3">
   <w.rf>
    <LM>w#w-d1t972-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t972-4">
   <w.rf>
    <LM>w#w-d1t972-4</LM>
   </w.rf>
   <form>zaměstnanec</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-260-261">
   <w.rf>
    <LM>w#w-260-261</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-262">
  <m id="m054-d1t972-8">
   <w.rf>
    <LM>w#w-d1t972-8</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m054-d1t972-9">
   <w.rf>
    <LM>w#w-d1t972-9</LM>
   </w.rf>
   <form>nálet</form>
   <lemma>nálet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t972-11">
   <w.rf>
    <LM>w#w-d1t972-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t972-10">
   <w.rf>
    <LM>w#w-d1t972-10</LM>
   </w.rf>
   <form>hrozný</form>
   <lemma>hrozný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-262-263">
   <w.rf>
    <LM>w#w-262-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-265">
  <m id="m054-d1t974-4">
   <w.rf>
    <LM>w#w-d1t974-4</LM>
   </w.rf>
   <form>Neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t974-5">
   <w.rf>
    <LM>w#w-d1t974-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t974-6">
   <w.rf>
    <LM>w#w-d1t974-6</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-265-266">
   <w.rf>
    <LM>w#w-265-266</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t974-8">
   <w.rf>
    <LM>w#w-d1t974-8</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m054-265-267">
   <w.rf>
    <LM>w#w-265-267</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-269">
  <m id="m054-d1t974-12">
   <w.rf>
    <LM>w#w-d1t974-12</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t974-11">
   <w.rf>
    <LM>w#w-d1t974-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t974-13">
   <w.rf>
    <LM>w#w-d1t974-13</LM>
   </w.rf>
   <form>zaměstnaný</form>
   <lemma>zaměstnaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-d1t974-14">
   <w.rf>
    <LM>w#w-d1t974-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t981-2">
   <w.rf>
    <LM>w#w-d1t981-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t981-3">
   <w.rf>
    <LM>w#w-d1t981-3</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m054-d-id96040-punct">
   <w.rf>
    <LM>w#w-d-id96040-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t978-10">
   <w.rf>
    <LM>w#w-d1t978-10</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t978-11">
   <w.rf>
    <LM>w#w-d1t978-11</LM>
   </w.rf>
   <form>neštěstí</form>
   <lemma>neštěstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-d1t978-4">
   <w.rf>
    <LM>w#w-d1t978-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-d1t978-5">
   <w.rf>
    <LM>w#w-d1t978-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t978-6">
   <w.rf>
    <LM>w#w-d1t978-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t978-7">
   <w.rf>
    <LM>w#w-d1t978-7</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d1t978-8">
   <w.rf>
    <LM>w#w-d1t978-8</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d-id96308-punct">
   <w.rf>
    <LM>w#w-d-id96308-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t983-3">
   <w.rf>
    <LM>w#w-d1t983-3</LM>
   </w.rf>
   <form>přidělit</form>
   <lemma>přidělit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t983-4">
   <w.rf>
    <LM>w#w-d1t983-4</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t983-7">
   <w.rf>
    <LM>w#w-d1t983-7</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m054-d-id96420-punct">
   <w.rf>
    <LM>w#w-d-id96420-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t983-9">
   <w.rf>
    <LM>w#w-d1t983-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m054-d1t983-10">
   <w.rf>
    <LM>w#w-d1t983-10</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t987-4">
   <w.rf>
    <LM>w#w-d1t987-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m054-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-269-281">
   <w.rf>
    <LM>w#w-269-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e967-x3">
  <m id="m054-d1t987-20">
   <w.rf>
    <LM>w#w-d1t987-20</LM>
   </w.rf>
   <form>Pumy</form>
   <lemma>puma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d1t987-21">
   <w.rf>
    <LM>w#w-d1t987-21</LM>
   </w.rf>
   <form>padaly</form>
   <lemma>padat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m054-d1e967-x3-585">
   <w.rf>
    <LM>w#w-d1e967-x3-585</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t987-9">
   <w.rf>
    <LM>w#w-d1t987-9</LM>
   </w.rf>
   <form>Jateční</form>
   <lemma>jateční</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m054-d1t987-12">
   <w.rf>
    <LM>w#w-d1t987-12</LM>
   </w.rf>
   <form>kolonie</form>
   <lemma>kolonie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1t987-13">
   <w.rf>
    <LM>w#w-d1t987-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1e967-x3-583">
   <w.rf>
    <LM>w#w-d1e967-x3-583</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e967-x3-584">
   <w.rf>
    <LM>w#w-d1e967-x3-584</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-309-312">
   <w.rf>
    <LM>w#w-309-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-313">
  <m id="m054-d1t991-1">
   <w.rf>
    <LM>w#w-d1t991-1</LM>
   </w.rf>
   <form>Moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m054-d1t991-2">
   <w.rf>
    <LM>w#w-d1t991-2</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-d1t991-3">
   <w.rf>
    <LM>w#w-d1t991-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t991-4">
   <w.rf>
    <LM>w#w-d1t991-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t991-6">
   <w.rf>
    <LM>w#w-d1t991-6</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t991-5">
   <w.rf>
    <LM>w#w-d1t991-5</LM>
   </w.rf>
   <form>vybombardovaní</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-313-314">
   <w.rf>
    <LM>w#w-313-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-315">
  <m id="m054-d1t991-13">
   <w.rf>
    <LM>w#w-d1t991-13</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m054-d1t991-14">
   <w.rf>
    <LM>w#w-d1t991-14</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-d1t991-15">
   <w.rf>
    <LM>w#w-d1t991-15</LM>
   </w.rf>
   <form>manželé</form>
   <lemma>manžel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-d1t991-16">
   <w.rf>
    <LM>w#w-d1t991-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t991-18">
   <w.rf>
    <LM>w#w-d1t991-18</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t991-17">
   <w.rf>
    <LM>w#w-d1t991-17</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t991-19">
   <w.rf>
    <LM>w#w-d1t991-19</LM>
   </w.rf>
   <form>vybombardovaní</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-315-316">
   <w.rf>
    <LM>w#w-315-316</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-318">
  <m id="m054-d1t996-5">
   <w.rf>
    <LM>w#w-d1t996-5</LM>
   </w.rf>
   <form>Tadyhle</form>
   <lemma>tadyhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t996-6">
   <w.rf>
    <LM>w#w-d1t996-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m054-d1t996-7">
   <w.rf>
    <LM>w#w-d1t996-7</LM>
   </w.rf>
   <form>dívence</form>
   <lemma>dívenka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m054-d1t998-1">
   <w.rf>
    <LM>w#w-d1t998-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t998-3">
   <w.rf>
    <LM>w#w-d1t998-3</LM>
   </w.rf>
   <form>jejím</form>
   <lemma>jeho</lemma>
   <tag>P9XP3FS3-------</tag>
  </m>
  <m id="m054-d1t998-4">
   <w.rf>
    <LM>w#w-d1t998-4</LM>
   </w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m054-d1t998-6">
   <w.rf>
    <LM>w#w-d1t998-6</LM>
   </w.rf>
   <form>pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t998-7">
   <w.rf>
    <LM>w#w-d1t998-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m054-d1t998-8">
   <w.rf>
    <LM>w#w-d1t998-8</LM>
   </w.rf>
   <form>bytu</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m054-318-319">
   <w.rf>
    <LM>w#w-318-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-320">
  <m id="m054-d1t998-13">
   <w.rf>
    <LM>w#w-d1t998-13</LM>
   </w.rf>
   <form>Nemohou</form>
   <lemma>moci</lemma>
   <tag>VB-P---3P-NAI-1</tag>
  </m>
  <m id="m054-d1t998-10">
   <w.rf>
    <LM>w#w-d1t998-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t998-11">
   <w.rf>
    <LM>w#w-d1t998-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t998-14">
   <w.rf>
    <LM>w#w-d1t998-14</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-320-321">
   <w.rf>
    <LM>w#w-320-321</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-322">
  <m id="m054-d1t998-17">
   <w.rf>
    <LM>w#w-d1t998-17</LM>
   </w.rf>
   <form>Rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m054-d1t998-18">
   <w.rf>
    <LM>w#w-d1t998-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t998-19">
   <w.rf>
    <LM>w#w-d1t998-19</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t998-20">
   <w.rf>
    <LM>w#w-d1t998-20</LM>
   </w.rf>
   <form>mrtví</form>
   <lemma>mrtvý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-322-323">
   <w.rf>
    <LM>w#w-322-323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-325">
  <m id="m054-d1t998-23">
   <w.rf>
    <LM>w#w-d1t998-23</LM>
   </w.rf>
   <form>Ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m054-d1t998-24">
   <w.rf>
    <LM>w#w-d1t998-24</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t998-22">
   <w.rf>
    <LM>w#w-d1t998-22</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t998-25">
   <w.rf>
    <LM>w#w-d1t998-25</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1000-1">
   <w.rf>
    <LM>w#w-d1t1000-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1000-3">
   <w.rf>
    <LM>w#w-d1t1000-3</LM>
   </w.rf>
   <form>neustále</form>
   <lemma>neustále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t1000-4">
   <w.rf>
    <LM>w#w-d1t1000-4</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d-id97665-punct">
   <w.rf>
    <LM>w#w-d-id97665-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1000-6">
   <w.rf>
    <LM>w#w-d1t1000-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1000-7">
   <w.rf>
    <LM>w#w-d1t1000-7</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m054-d1t1000-8">
   <w.rf>
    <LM>w#w-d1t1000-8</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1002-1">
   <w.rf>
    <LM>w#w-d1t1002-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1002-2">
   <w.rf>
    <LM>w#w-d1t1002-2</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSMS4-S1-------</tag>
  </m>
  <m id="m054-d1t1002-3">
   <w.rf>
    <LM>w#w-d1t1002-3</LM>
   </w.rf>
   <form>manžela</form>
   <lemma>manžel</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d-id97776-punct">
   <w.rf>
    <LM>w#w-d-id97776-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1002-5">
   <w.rf>
    <LM>w#w-d1t1002-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1002-6">
   <w.rf>
    <LM>w#w-d1t1002-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1002-8">
   <w.rf>
    <LM>w#w-d1t1002-8</LM>
   </w.rf>
   <form>vůči</form>
   <lemma>vůči</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m054-d1t1002-9">
   <w.rf>
    <LM>w#w-d1t1002-9</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m054-d1t1002-7">
   <w.rf>
    <LM>w#w-d1t1002-7</LM>
   </w.rf>
   <form>zachoval</form>
   <lemma>zachovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1e967-x4-336">
   <w.rf>
    <LM>w#w-d1e967-x4-336</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1002-11">
   <w.rf>
    <LM>w#w-d1t1002-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1002-12">
   <w.rf>
    <LM>w#w-d1t1002-12</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m054-d1t1002-14">
   <w.rf>
    <LM>w#w-d1t1002-14</LM>
   </w.rf>
   <form>pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d-id97920-punct">
   <w.rf>
    <LM>w#w-d-id97920-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1002-16">
   <w.rf>
    <LM>w#w-d1t1002-16</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1002-17">
   <w.rf>
    <LM>w#w-d1t1002-17</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t1002-18">
   <w.rf>
    <LM>w#w-d1t1002-18</LM>
   </w.rf>
   <form>existovat</form>
   <lemma>existovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m054-d1e967-x4-337">
   <w.rf>
    <LM>w#w-d1e967-x4-337</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-338">
  <m id="m054-d1t1004-2">
   <w.rf>
    <LM>w#w-d1t1004-2</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1004-6">
   <w.rf>
    <LM>w#w-d1t1004-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1004-7">
   <w.rf>
    <LM>w#w-d1t1004-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1004-3">
   <w.rf>
    <LM>w#w-d1t1004-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1004-4">
   <w.rf>
    <LM>w#w-d1t1004-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1004-5">
   <w.rf>
    <LM>w#w-d1t1004-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1010-1">
   <w.rf>
    <LM>w#w-d1t1010-1</LM>
   </w.rf>
   <form>hrdá</form>
   <lemma>hrdý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-338-368">
   <w.rf>
    <LM>w#w-338-368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1017-1">
   <w.rf>
    <LM>w#w-d1t1017-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1017-2">
   <w.rf>
    <LM>w#w-d1t1017-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1017-3">
   <w.rf>
    <LM>w#w-d1t1017-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d-id98353-punct">
   <w.rf>
    <LM>w#w-d-id98353-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1017-5">
   <w.rf>
    <LM>w#w-d1t1017-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1017-6">
   <w.rf>
    <LM>w#w-d1t1017-6</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-338-369">
   <w.rf>
    <LM>w#w-338-369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1005-x3">
  <m id="m054-d1t1012-1">
   <w.rf>
    <LM>w#w-d1t1012-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1012-2">
   <w.rf>
    <LM>w#w-d1t1012-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1012-3">
   <w.rf>
    <LM>w#w-d1t1012-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1012-4">
   <w.rf>
    <LM>w#w-d1t1012-4</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-d-m-d1e1005-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1005-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1014-x2">
  <m id="m054-d1t1017-7">
   <w.rf>
    <LM>w#w-d1t1017-7</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1014-x2-370">
   <w.rf>
    <LM>w#w-d1e1014-x2-370</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1017-8">
   <w.rf>
    <LM>w#w-d1t1017-8</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1e1014-x2-371">
   <w.rf>
    <LM>w#w-d1e1014-x2-371</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-372">
  <m id="m054-372-373">
   <w.rf>
    <LM>w#w-372-373</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1019-1">
   <w.rf>
    <LM>w#w-d1t1019-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1019-4">
   <w.rf>
    <LM>w#w-d1t1019-4</LM>
   </w.rf>
   <form>všem</form>
   <lemma>všechen</lemma>
   <tag>PLXP3----------</tag>
  </m>
  <m id="m054-372-374">
   <w.rf>
    <LM>w#w-372-374</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-375">
  <m id="m054-d1t1019-7">
   <w.rf>
    <LM>w#w-d1t1019-7</LM>
   </w.rf>
   <form>Dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m054-d1t1019-6">
   <w.rf>
    <LM>w#w-d1t1019-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1019-8">
   <w.rf>
    <LM>w#w-d1t1019-8</LM>
   </w.rf>
   <form>zaměstnaný</form>
   <lemma>zaměstnaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m054-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>jatkách</form>
   <lemma>jatky</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m054-d1t1021-3">
   <w.rf>
    <LM>w#w-d1t1021-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1021-4">
   <w.rf>
    <LM>w#w-d1t1021-4</LM>
   </w.rf>
   <form>ekonom</form>
   <lemma>ekonom</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-375-388">
   <w.rf>
    <LM>w#w-375-388</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-389">
  <m id="m054-d1t1023-2">
   <w.rf>
    <LM>w#w-d1t1023-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1023-8">
   <w.rf>
    <LM>w#w-d1t1023-8</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-389-395">
   <w.rf>
    <LM>w#w-389-395</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m054-389-394">
   <w.rf>
    <LM>w#w-389-394</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1023-6">
   <w.rf>
    <LM>w#w-d1t1023-6</LM>
   </w.rf>
   <form>Jateční</form>
   <lemma>jateční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m054-d1t1023-9">
   <w.rf>
    <LM>w#w-d1t1023-9</LM>
   </w.rf>
   <form>vybombardovaní</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-389-390">
   <w.rf>
    <LM>w#w-389-390</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1023-10">
   <w.rf>
    <LM>w#w-d1t1023-10</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1023-11">
   <w.rf>
    <LM>w#w-d1t1023-11</LM>
   </w.rf>
   <form>byty</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m054-d-id98771-punct">
   <w.rf>
    <LM>w#w-d-id98771-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1023-13">
   <w.rf>
    <LM>w#w-d1t1023-13</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1023-15">
   <w.rf>
    <LM>w#w-d1t1023-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m054-d-id98826-punct">
   <w.rf>
    <LM>w#w-d-id98826-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1025-1">
   <w.rf>
    <LM>w#w-d1t1025-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1025-2">
   <w.rf>
    <LM>w#w-d1t1025-2</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m054-d1t1025-3">
   <w.rf>
    <LM>w#w-d1t1025-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1025-8">
   <w.rf>
    <LM>w#w-d1t1025-8</LM>
   </w.rf>
   <form>pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-389-391">
   <w.rf>
    <LM>w#w-389-391</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-389-392">
   <w.rf>
    <LM>w#w-389-392</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-389-393">
   <w.rf>
    <LM>w#w-389-393</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-389-396">
   <w.rf>
    <LM>w#w-389-396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-397">
  <m id="m054-d1t1025-11">
   <w.rf>
    <LM>w#w-d1t1025-11</LM>
   </w.rf>
   <form>Pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1025-10">
   <w.rf>
    <LM>w#w-d1t1025-10</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1025-12">
   <w.rf>
    <LM>w#w-d1t1025-12</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1025-13">
   <w.rf>
    <LM>w#w-d1t1025-13</LM>
   </w.rf>
   <form>vybombardovaným</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m054-397-398">
   <w.rf>
    <LM>w#w-397-398</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-399">
  <m id="m054-d1t1028-2">
   <w.rf>
    <LM>w#w-d1t1028-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1028-3">
   <w.rf>
    <LM>w#w-d1t1028-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1028-4">
   <w.rf>
    <LM>w#w-d1t1028-4</LM>
   </w.rf>
   <form>neštěstí</form>
   <lemma>neštěstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m054-399-400">
   <w.rf>
    <LM>w#w-399-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-401">
  <m id="m054-d1t1034-1">
   <w.rf>
    <LM>w#w-d1t1034-1</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m054-d1t1034-2">
   <w.rf>
    <LM>w#w-d1t1034-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1034-3">
   <w.rf>
    <LM>w#w-d1t1034-3</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t1034-4">
   <w.rf>
    <LM>w#w-d1t1034-4</LM>
   </w.rf>
   <form>naproti</form>
   <lemma>naproti-1_^(komu/čemu)</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m054-d1t1034-6">
   <w.rf>
    <LM>w#w-d1t1034-6</LM>
   </w.rf>
   <form>Hamburku</form>
   <lemma>Hamburk_;G</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m054-d1e1014-x3-416">
   <w.rf>
    <LM>w#w-d1e1014-x3-416</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1036-1">
   <w.rf>
    <LM>w#w-d1t1036-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1036-3">
   <w.rf>
    <LM>w#w-d1t1036-3</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m054-401-419">
   <w.rf>
    <LM>w#w-401-419</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-420">
  <m id="m054-d1t1036-6">
   <w.rf>
    <LM>w#w-d1t1036-6</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1036-7">
   <w.rf>
    <LM>w#w-d1t1036-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1036-9">
   <w.rf>
    <LM>w#w-d1t1036-9</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1036-8">
   <w.rf>
    <LM>w#w-d1t1036-8</LM>
   </w.rf>
   <form>spadlo</form>
   <lemma>spadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m054-d1e1014-x3-417">
   <w.rf>
    <LM>w#w-d1e1014-x3-417</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-418">
  <m id="m054-d1t1036-15">
   <w.rf>
    <LM>w#w-d1t1036-15</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m054-d1t1036-16">
   <w.rf>
    <LM>w#w-d1t1036-16</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t1036-18">
   <w.rf>
    <LM>w#w-d1t1036-18</LM>
   </w.rf>
   <form>existuje</form>
   <lemma>existovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1036-19">
   <w.rf>
    <LM>w#w-d1t1036-19</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1036-20">
   <w.rf>
    <LM>w#w-d1t1036-20</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d-id99682-punct">
   <w.rf>
    <LM>w#w-d-id99682-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1041-1">
   <w.rf>
    <LM>w#w-d1t1041-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1041-2">
   <w.rf>
    <LM>w#w-d1t1041-2</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m054-d1t1041-3">
   <w.rf>
    <LM>w#w-d1t1041-3</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d-id99761-punct">
   <w.rf>
    <LM>w#w-d-id99761-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1041-5">
   <w.rf>
    <LM>w#w-d1t1041-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1041-6">
   <w.rf>
    <LM>w#w-d1t1041-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1041-8">
   <w.rf>
    <LM>w#w-d1t1041-8</LM>
   </w.rf>
   <form>továrna</form>
   <lemma>továrna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1043-3">
   <w.rf>
    <LM>w#w-d1t1043-3</LM>
   </w.rf>
   <form>uzeniny</form>
   <lemma>uzenina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m054-d1t1043-4">
   <w.rf>
    <LM>w#w-d1t1043-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1043-6">
   <w.rf>
    <LM>w#w-d1t1043-6</LM>
   </w.rf>
   <form>maso</form>
   <lemma>maso_^(jídlo_apod.)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-429-430">
   <w.rf>
    <LM>w#w-429-430</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1047-5">
   <w.rf>
    <LM>w#w-d1t1047-5</LM>
   </w.rf>
   <form>slehl</form>
   <lemma>slehnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m054-429-431">
   <w.rf>
    <LM>w#w-429-431</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-432">
  <m id="m054-d1t1047-9">
   <w.rf>
    <LM>w#w-d1t1047-9</LM>
   </w.rf>
   <form>Probojovali</form>
   <lemma>probojovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m054-d1t1047-8">
   <w.rf>
    <LM>w#w-d1t1047-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1047-10">
   <w.rf>
    <LM>w#w-d1t1047-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m054-d1t1047-11">
   <w.rf>
    <LM>w#w-d1t1047-11</LM>
   </w.rf>
   <form>mým</form>
   <lemma>můj</lemma>
   <tag>PSXP3-S1-------</tag>
  </m>
  <m id="m054-d1t1047-12">
   <w.rf>
    <LM>w#w-d1t1047-12</LM>
   </w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m054-d1t1047-13">
   <w.rf>
    <LM>w#w-d1t1047-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1047-14">
   <w.rf>
    <LM>w#w-d1t1047-14</LM>
   </w.rf>
   <form>sklepa</form>
   <lemma>sklep</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m054-d-id100184-punct">
   <w.rf>
    <LM>w#w-d-id100184-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1049-2">
   <w.rf>
    <LM>w#w-d1t1049-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m054-d1t1049-3">
   <w.rf>
    <LM>w#w-d1t1049-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1049-4">
   <w.rf>
    <LM>w#w-d1t1049-4</LM>
   </w.rf>
   <form>zachránili</form>
   <lemma>zachránit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m054-432-26">
   <w.rf>
    <LM>w#w-432-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-27">
  <m id="m054-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1051-4">
   <w.rf>
    <LM>w#w-d1t1051-4</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1051-6">
   <w.rf>
    <LM>w#w-d1t1051-6</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t1051-8">
   <w.rf>
    <LM>w#w-d1t1051-8</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t1051-7">
   <w.rf>
    <LM>w#w-d1t1051-7</LM>
   </w.rf>
   <form>hotel</form>
   <lemma>hotel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-27-39">
   <w.rf>
    <LM>w#w-27-39</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-40">
  <m id="m054-d1t1051-10">
   <w.rf>
    <LM>w#w-d1t1051-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1051-11">
   <w.rf>
    <LM>w#w-d1t1051-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1051-14">
   <w.rf>
    <LM>w#w-d1t1051-14</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1051-12">
   <w.rf>
    <LM>w#w-d1t1051-12</LM>
   </w.rf>
   <form>nově</form>
   <lemma>nově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m054-d1t1051-13">
   <w.rf>
    <LM>w#w-d1t1051-13</LM>
   </w.rf>
   <form>postavené</form>
   <lemma>postavený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d1e1014-x4-41">
   <w.rf>
    <LM>w#w-d1e1014-x4-41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-42">
  <m id="m054-d1t1054-3">
   <w.rf>
    <LM>w#w-d1t1054-3</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1054-2">
   <w.rf>
    <LM>w#w-d1t1054-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d1t1054-1">
   <w.rf>
    <LM>w#w-d1t1054-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1054-5">
   <w.rf>
    <LM>w#w-d1t1054-5</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d-id100564-punct">
   <w.rf>
    <LM>w#w-d-id100564-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1054-7">
   <w.rf>
    <LM>w#w-d1t1054-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1054-9">
   <w.rf>
    <LM>w#w-d1t1054-9</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m054-d1t1054-10">
   <w.rf>
    <LM>w#w-d1t1054-10</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-42-51">
   <w.rf>
    <LM>w#w-42-51</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1054-11">
   <w.rf>
    <LM>w#w-d1t1054-11</LM>
   </w.rf>
   <form>třebaže</form>
   <lemma>třebaže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1054-14">
   <w.rf>
    <LM>w#w-d1t1054-14</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m054-d1t1054-15">
   <w.rf>
    <LM>w#w-d1t1054-15</LM>
   </w.rf>
   <form>vybombardovaní</form>
   <lemma>vybombardovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m054-42-46">
   <w.rf>
    <LM>w#w-42-46</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1054-21">
   <w.rf>
    <LM>w#w-d1t1054-21</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m054-d1t1054-22">
   <w.rf>
    <LM>w#w-d1t1054-22</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-42-44">
   <w.rf>
    <LM>w#w-42-44</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1054-23">
   <w.rf>
    <LM>w#w-d1t1054-23</LM>
   </w.rf>
   <form>zůstal</form>
   <lemma>zůstat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d-id100879-punct">
   <w.rf>
    <LM>w#w-d-id100879-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1056-3">
   <w.rf>
    <LM>w#w-d1t1056-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1056-4">
   <w.rf>
    <LM>w#w-d1t1056-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1056-5">
   <w.rf>
    <LM>w#w-d1t1056-5</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m054-d1t1056-6">
   <w.rf>
    <LM>w#w-d1t1056-6</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1056-7">
   <w.rf>
    <LM>w#w-d1t1056-7</LM>
   </w.rf>
   <form>nabízel</form>
   <lemma>nabízet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1056-8">
   <w.rf>
    <LM>w#w-d1t1056-8</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d-id100974-punct">
   <w.rf>
    <LM>w#w-d-id100974-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1056-10">
   <w.rf>
    <LM>w#w-d1t1056-10</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1056-11">
   <w.rf>
    <LM>w#w-d1t1056-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1056-12">
   <w.rf>
    <LM>w#w-d1t1056-12</LM>
   </w.rf>
   <form>vystěhovali</form>
   <lemma>vystěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m054-42-47">
   <w.rf>
    <LM>w#w-42-47</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1056-14">
   <w.rf>
    <LM>w#w-d1t1056-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1056-15">
   <w.rf>
    <LM>w#w-d1t1056-15</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m054-d1t1056-19">
   <w.rf>
    <LM>w#w-d1t1056-19</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1056-18">
   <w.rf>
    <LM>w#w-d1t1056-18</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1056-20">
   <w.rf>
    <LM>w#w-d1t1056-20</LM>
   </w.rf>
   <form>právo</form>
   <lemma>právo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d1t1056-17">
   <w.rf>
    <LM>w#w-d1t1056-17</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t1056-21">
   <w.rf>
    <LM>w#w-d1t1056-21</LM>
   </w.rf>
   <form>obstarat</form>
   <lemma>obstarat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d-id101168-punct">
   <w.rf>
    <LM>w#w-d-id101168-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1060-2">
   <w.rf>
    <LM>w#w-d1t1060-2</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m054-42-48">
   <w.rf>
    <LM>w#w-42-48</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-42-49">
   <w.rf>
    <LM>w#w-42-49</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1060-3">
   <w.rf>
    <LM>w#w-d1t1060-3</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-42-50">
   <w.rf>
    <LM>w#w-42-50</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1060-4">
   <w.rf>
    <LM>w#w-d1t1060-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m054-d1t1060-5">
   <w.rf>
    <LM>w#w-d1t1060-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1060-6">
   <w.rf>
    <LM>w#w-d1t1060-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1060-7">
   <w.rf>
    <LM>w#w-d1t1060-7</LM>
   </w.rf>
   <form>odtud</form>
   <lemma>odtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1060-8">
   <w.rf>
    <LM>w#w-d1t1060-8</LM>
   </w.rf>
   <form>nehnu</form>
   <lemma>hnout</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m054-42-645">
   <w.rf>
    <LM>w#w-42-645</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-647">
  <m id="m054-d1t1062-1">
   <w.rf>
    <LM>w#w-d1t1062-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m054-d1t1062-2">
   <w.rf>
    <LM>w#w-d1t1062-2</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWIS4----------</tag>
  </m>
  <m id="m054-d1t1062-3">
   <w.rf>
    <LM>w#w-d1t1062-3</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d1t1062-4">
   <w.rf>
    <LM>w#w-d1t1062-4</LM>
   </w.rf>
   <form>nechci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m054-42-53">
   <w.rf>
    <LM>w#w-42-53</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1062-5">
   <w.rf>
    <LM>w#w-d1t1062-5</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m054-d1t1062-6">
   <w.rf>
    <LM>w#w-d1t1062-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1062-7">
   <w.rf>
    <LM>w#w-d1t1062-7</LM>
   </w.rf>
   <form>zůstanu</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m054-42-55">
   <w.rf>
    <LM>w#w-42-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-42-56">
   <w.rf>
    <LM>w#w-42-56</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-58">
  <m id="m054-d1t1067-5">
   <w.rf>
    <LM>w#w-d1t1067-5</LM>
   </w.rf>
   <form>Zůstala</form>
   <lemma>zůstat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m054-d1t1067-4">
   <w.rf>
    <LM>w#w-d1t1067-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1067-1">
   <w.rf>
    <LM>w#w-d1t1067-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1067-2">
   <w.rf>
    <LM>w#w-d1t1067-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1067-3">
   <w.rf>
    <LM>w#w-d1t1067-3</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1e1014-x5-66">
   <w.rf>
    <LM>w#w-d1e1014-x5-66</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1067-8">
   <w.rf>
    <LM>w#w-d1t1067-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1067-9">
   <w.rf>
    <LM>w#w-d1t1067-9</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t1067-10">
   <w.rf>
    <LM>w#w-d1t1067-10</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1e1014-x5-67">
   <w.rf>
    <LM>w#w-d1e1014-x5-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-68">
  <m id="m054-d1t1067-12">
   <w.rf>
    <LM>w#w-d1t1067-12</LM>
   </w.rf>
   <form>Přesto</form>
   <lemma>přesto-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1067-13">
   <w.rf>
    <LM>w#w-d1t1067-13</LM>
   </w.rf>
   <form>přese</form>
   <lemma>přes-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m054-d1t1067-14">
   <w.rf>
    <LM>w#w-d1t1067-14</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m054-68-69">
   <w.rf>
    <LM>w#w-68-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-70">
  <m id="m054-d1t1067-16">
   <w.rf>
    <LM>w#w-d1t1067-16</LM>
   </w.rf>
   <form>Nechtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1067-17">
   <w.rf>
    <LM>w#w-d1t1067-17</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m054-d-id101831-punct">
   <w.rf>
    <LM>w#w-d-id101831-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1069-1">
   <w.rf>
    <LM>w#w-d1t1069-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1069-2">
   <w.rf>
    <LM>w#w-d1t1069-2</LM>
   </w.rf>
   <form>neubírali</form>
   <lemma>ubírat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1069-3">
   <w.rf>
    <LM>w#w-d1t1069-3</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m054-d-id101911-punct">
   <w.rf>
    <LM>w#w-d-id101911-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1069-5">
   <w.rf>
    <LM>w#w-d1t1069-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1069-7">
   <w.rf>
    <LM>w#w-d1t1069-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1069-6">
   <w.rf>
    <LM>w#w-d1t1069-6</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1069-8">
   <w.rf>
    <LM>w#w-d1t1069-8</LM>
   </w.rf>
   <form>tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m054-d1t1069-9">
   <w.rf>
    <LM>w#w-d1t1069-9</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d1t1069-10">
   <w.rf>
    <LM>w#w-d1t1069-10</LM>
   </w.rf>
   <form>spravit</form>
   <lemma>spravit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-d-m-d1e1014-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1014-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1070-x2">
  <m id="m054-d1t1077-1">
   <w.rf>
    <LM>w#w-d1t1077-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1077-2">
   <w.rf>
    <LM>w#w-d1t1077-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1077-4">
   <w.rf>
    <LM>w#w-d1t1077-4</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHP1-S1-------</tag>
  </m>
  <m id="m054-d1t1077-5">
   <w.rf>
    <LM>w#w-d1t1077-5</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1070-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1070-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1070-x3">
  <m id="m054-d1t1079-1">
   <w.rf>
    <LM>w#w-d1t1079-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1079-2">
   <w.rf>
    <LM>w#w-d1t1079-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1079-3">
   <w.rf>
    <LM>w#w-d1t1079-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m054-d-m-d1e1070-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1070-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1080-x2">
  <m id="m054-d1e1080-x2-659">
   <w.rf>
    <LM>w#w-d1e1080-x2-659</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1e1080-x2-660">
   <w.rf>
    <LM>w#w-d1e1080-x2-660</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m054-d1e1080-x2-661">
   <w.rf>
    <LM>w#w-d1e1080-x2-661</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1e1080-x2-662">
   <w.rf>
    <LM>w#w-d1e1080-x2-662</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m054-d1e1080-x2-663">
   <w.rf>
    <LM>w#w-d1e1080-x2-663</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1e1080-x2-664">
   <w.rf>
    <LM>w#w-d1e1080-x2-664</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1087-1">
   <w.rf>
    <LM>w#w-d1t1087-1</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1087-2">
   <w.rf>
    <LM>w#w-d1t1087-2</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m054-d1t1087-3">
   <w.rf>
    <LM>w#w-d1t1087-3</LM>
   </w.rf>
   <form>kožené</form>
   <lemma>kožený</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m054-d1t1087-4">
   <w.rf>
    <LM>w#w-d1t1087-4</LM>
   </w.rf>
   <form>botičky</form>
   <lemma>botička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m054-d1e1080-x2-21">
   <w.rf>
    <LM>w#w-d1e1080-x2-21</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-22">
  <m id="m054-d1t1089-3">
   <w.rf>
    <LM>w#w-d1t1089-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1089-4">
   <w.rf>
    <LM>w#w-d1t1089-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1089-5">
   <w.rf>
    <LM>w#w-d1t1089-5</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m054-d1t1089-6">
   <w.rf>
    <LM>w#w-d1t1089-6</LM>
   </w.rf>
   <form>bílé</form>
   <lemma>bílý_;o</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m054-d1t1089-7">
   <w.rf>
    <LM>w#w-d1t1089-7</LM>
   </w.rf>
   <form>dřeváčky</form>
   <lemma>dřeváček</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m054-22-23">
   <w.rf>
    <LM>w#w-22-23</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1089-8">
   <w.rf>
    <LM>w#w-d1t1089-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1089-9">
   <w.rf>
    <LM>w#w-d1t1089-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1089-12">
   <w.rf>
    <LM>w#w-d1t1089-12</LM>
   </w.rf>
   <form>nosí</form>
   <lemma>nosit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m054-d1t1089-11">
   <w.rf>
    <LM>w#w-d1t1089-11</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1089-10">
   <w.rf>
    <LM>w#w-d1t1089-10</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-22-29">
   <w.rf>
    <LM>w#w-22-29</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1097-2">
   <w.rf>
    <LM>w#w-d1t1097-2</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m054-d1t1097-3">
   <w.rf>
    <LM>w#w-d1t1097-3</LM>
   </w.rf>
   <form>moderní</form>
   <lemma>moderní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m054-d1t1097-5">
   <w.rf>
    <LM>w#w-d1t1097-5</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m054-d1t1097-6">
   <w.rf>
    <LM>w#w-d1t1097-6</LM>
   </w.rf>
   <form>dřeváčky</form>
   <lemma>dřeváček</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m054-d-m-d1e1092-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1092-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1104-x2">
  <m id="m054-d1t1107-1">
   <w.rf>
    <LM>w#w-d1t1107-1</LM>
   </w.rf>
   <form>Chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1107-2">
   <w.rf>
    <LM>w#w-d1t1107-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1107-4">
   <w.rf>
    <LM>w#w-d1t1107-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m054-d-id103041-punct">
   <w.rf>
    <LM>w#w-d-id103041-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1109-1">
   <w.rf>
    <LM>w#w-d1t1109-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1109-3">
   <w.rf>
    <LM>w#w-d1t1109-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1109-4">
   <w.rf>
    <LM>w#w-d1t1109-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1109-5">
   <w.rf>
    <LM>w#w-d1t1109-5</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t1109-2">
   <w.rf>
    <LM>w#w-d1t1109-2</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m054-d1t1107-3">
   <w.rf>
    <LM>w#w-d1t1107-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1109-6">
   <w.rf>
    <LM>w#w-d1t1109-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1109-7">
   <w.rf>
    <LM>w#w-d1t1109-7</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m054-d1t1109-8">
   <w.rf>
    <LM>w#w-d1t1109-8</LM>
   </w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m054-d-id103183-punct">
   <w.rf>
    <LM>w#w-d-id103183-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1e1104-x2-43">
   <w.rf>
    <LM>w#w-d1e1104-x2-43</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1109-10">
   <w.rf>
    <LM>w#w-d1t1109-10</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1t1109-11">
   <w.rf>
    <LM>w#w-d1t1109-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1109-12">
   <w.rf>
    <LM>w#w-d1t1109-12</LM>
   </w.rf>
   <form>zpěvák</form>
   <lemma>zpěvák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d1e1104-x2-44">
   <w.rf>
    <LM>w#w-d1e1104-x2-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-46">
  <m id="m054-d1t1113-1">
   <w.rf>
    <LM>w#w-d1t1113-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1113-3">
   <w.rf>
    <LM>w#w-d1t1113-3</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t1113-5">
   <w.rf>
    <LM>w#w-d1t1113-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1113-6">
   <w.rf>
    <LM>w#w-d1t1113-6</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1115-1">
   <w.rf>
    <LM>w#w-d1t1115-1</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m054-d1t1113-7">
   <w.rf>
    <LM>w#w-d1t1113-7</LM>
   </w.rf>
   <form>pěvecký</form>
   <lemma>pěvecký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t1113-8">
   <w.rf>
    <LM>w#w-d1t1113-8</LM>
   </w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-46-47">
   <w.rf>
    <LM>w#w-46-47</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1115-3">
   <w.rf>
    <LM>w#w-d1t1115-3</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m054-d1t1115-4">
   <w.rf>
    <LM>w#w-d1t1115-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1115-5">
   <w.rf>
    <LM>w#w-d1t1115-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1115-6">
   <w.rf>
    <LM>w#w-d1t1115-6</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m054-d1t1115-7">
   <w.rf>
    <LM>w#w-d1t1115-7</LM>
   </w.rf>
   <form>druhém</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m054-46-48">
   <w.rf>
    <LM>w#w-46-48</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-46-49">
   <w.rf>
    <LM>w#w-46-49</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1115-8">
   <w.rf>
    <LM>w#w-d1t1115-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1115-10">
   <w.rf>
    <LM>w#w-d1t1115-10</LM>
   </w.rf>
   <form>Hřímalý</form>
   <lemma>Hřímalý_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-46-50">
   <w.rf>
    <LM>w#w-46-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-51">
  <m id="m054-d1t1115-14">
   <w.rf>
    <LM>w#w-d1t1115-14</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1115-15">
   <w.rf>
    <LM>w#w-d1t1115-15</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m054-51-52">
   <w.rf>
    <LM>w#w-51-52</LM>
   </w.rf>
   <form>sboru</form>
   <lemma>sbor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m054-d1t1115-18">
   <w.rf>
    <LM>w#w-d1t1115-18</LM>
   </w.rf>
   <form>Hřímalý</form>
   <lemma>Hřímalý_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-51-53">
   <w.rf>
    <LM>w#w-51-53</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-54">
  <m id="m054-d1t1118-7">
   <w.rf>
    <LM>w#w-d1t1118-7</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m054-d1t1118-9">
   <w.rf>
    <LM>w#w-d1t1118-9</LM>
   </w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m054-d1t1118-10">
   <w.rf>
    <LM>w#w-d1t1118-10</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m054-d1t1118-11">
   <w.rf>
    <LM>w#w-d1t1118-11</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1118-12">
   <w.rf>
    <LM>w#w-d1t1118-12</LM>
   </w.rf>
   <form>zazpívat</form>
   <lemma>zazpívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m054-54-57">
   <w.rf>
    <LM>w#w-54-57</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-60">
  <m id="m054-d1t1120-5">
   <w.rf>
    <LM>w#w-d1t1120-5</LM>
   </w.rf>
   <form>Oddával</form>
   <lemma>oddávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1120-4">
   <w.rf>
    <LM>w#w-d1t1120-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m054-d1t1120-6">
   <w.rf>
    <LM>w#w-d1t1120-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m054-d1t1120-7">
   <w.rf>
    <LM>w#w-d1t1120-7</LM>
   </w.rf>
   <form>profesor</form>
   <lemma>profesor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m054-d-id103907-punct">
   <w.rf>
    <LM>w#w-d-id103907-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1122-1">
   <w.rf>
    <LM>w#w-d1t1122-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m054-d1t1122-2">
   <w.rf>
    <LM>w#w-d1t1122-2</LM>
   </w.rf>
   <form>učil</form>
   <lemma>učit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1122-4">
   <w.rf>
    <LM>w#w-d1t1122-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1122-5">
   <w.rf>
    <LM>w#w-d1t1122-5</LM>
   </w.rf>
   <form>reálce</form>
   <lemma>reálka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d-id104011-punct">
   <w.rf>
    <LM>w#w-d-id104011-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1124-2">
   <w.rf>
    <LM>w#w-d1t1124-2</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1124-3">
   <w.rf>
    <LM>w#w-d1t1124-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1126-1">
   <w.rf>
    <LM>w#w-d1t1126-1</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1126-2">
   <w.rf>
    <LM>w#w-d1t1126-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1126-3">
   <w.rf>
    <LM>w#w-d1t1126-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1126-4">
   <w.rf>
    <LM>w#w-d1t1126-4</LM>
   </w.rf>
   <form>kvarty</form>
   <lemma>kvarta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-d1e1104-x3-68">
   <w.rf>
    <LM>w#w-d1e1104-x3-68</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1126-5">
   <w.rf>
    <LM>w#w-d1t1126-5</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d1e1104-x3-69">
   <w.rf>
    <LM>w#w-d1e1104-x3-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-71">
  <m id="m054-d1t1126-8">
   <w.rf>
    <LM>w#w-d1t1126-8</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1126-7">
   <w.rf>
    <LM>w#w-d1t1126-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1126-9">
   <w.rf>
    <LM>w#w-d1t1126-9</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1126-10">
   <w.rf>
    <LM>w#w-d1t1126-10</LM>
   </w.rf>
   <form>pobožná</form>
   <lemma>pobožný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m054-d1t1126-11">
   <w.rf>
    <LM>w#w-d1t1126-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1126-12">
   <w.rf>
    <LM>w#w-d1t1126-12</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1126-13">
   <w.rf>
    <LM>w#w-d1t1126-13</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m054-d1t1126-14">
   <w.rf>
    <LM>w#w-d1t1126-14</LM>
   </w.rf>
   <form>pobožné</form>
   <lemma>pobožný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m054-d1t1126-15">
   <w.rf>
    <LM>w#w-d1t1126-15</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m054-71-77">
   <w.rf>
    <LM>w#w-71-77</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-78">
  <m id="m054-d1t1135-2">
   <w.rf>
    <LM>w#w-d1t1135-2</LM>
   </w.rf>
   <form>Učil</form>
   <lemma>učit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1135-1">
   <w.rf>
    <LM>w#w-d1t1135-1</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m054-d1t1135-3">
   <w.rf>
    <LM>w#w-d1t1135-3</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d1t1135-4">
   <w.rf>
    <LM>w#w-d1t1135-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1135-7">
   <w.rf>
    <LM>w#w-d1t1135-7</LM>
   </w.rf>
   <form>oddával</form>
   <lemma>oddávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1135-6">
   <w.rf>
    <LM>w#w-d1t1135-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m054-78-79">
   <w.rf>
    <LM>w#w-78-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-80">
  <m id="m054-d1t1135-11">
   <w.rf>
    <LM>w#w-d1t1135-11</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1135-10">
   <w.rf>
    <LM>w#w-d1t1135-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1135-12">
   <w.rf>
    <LM>w#w-d1t1135-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1135-13">
   <w.rf>
    <LM>w#w-d1t1135-13</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS6---------1</tag>
  </m>
  <m id="m054-d1t1135-14">
   <w.rf>
    <LM>w#w-d1t1135-14</LM>
   </w.rf>
   <form>svatbě</form>
   <lemma>svatba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t1137-1">
   <w.rf>
    <LM>w#w-d1t1137-1</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8MS4----------</tag>
  </m>
  <m id="m054-d1t1137-2">
   <w.rf>
    <LM>w#w-d1t1137-2</LM>
   </w.rf>
   <form>profesora</form>
   <lemma>profesor</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d1t1137-4">
   <w.rf>
    <LM>w#w-d1t1137-4</LM>
   </w.rf>
   <form>Multerera</form>
   <lemma>Multerer_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-80-81">
   <w.rf>
    <LM>w#w-80-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1139-1">
   <w.rf>
    <LM>w#w-d1t1139-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m054-d1t1139-2">
   <w.rf>
    <LM>w#w-d1t1139-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m054-d1t1139-4">
   <w.rf>
    <LM>w#w-d1t1139-4</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1139-5">
   <w.rf>
    <LM>w#w-d1t1139-5</LM>
   </w.rf>
   <form>celým</form>
   <lemma>celý</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m054-d1t1139-7">
   <w.rf>
    <LM>w#w-d1t1139-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>náboženstvím</form>
   <lemma>náboženství</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m054-d1t1139-3">
   <w.rf>
    <LM>w#w-d1t1139-3</LM>
   </w.rf>
   <form>vedl</form>
   <lemma>vést</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m054-d1t1139-8">
   <w.rf>
    <LM>w#w-d1t1139-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1141-1">
   <w.rf>
    <LM>w#w-d1t1141-1</LM>
   </w.rf>
   <form>postaral</form>
   <lemma>postarat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1141-2">
   <w.rf>
    <LM>w#w-d1t1141-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1141-3">
   <w.rf>
    <LM>w#w-d1t1141-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m054-d1t1141-4">
   <w.rf>
    <LM>w#w-d1t1141-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m054-d-id104827-punct">
   <w.rf>
    <LM>w#w-d-id104827-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1141-6">
   <w.rf>
    <LM>w#w-d1t1141-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1141-7">
   <w.rf>
    <LM>w#w-d1t1141-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1141-9">
   <w.rf>
    <LM>w#w-d1t1141-9</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1141-10">
   <w.rf>
    <LM>w#w-d1t1141-10</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m054-d1t1144-2">
   <w.rf>
    <LM>w#w-d1t1144-2</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m054-d1t1144-1">
   <w.rf>
    <LM>w#w-d1t1144-1</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1146-1">
   <w.rf>
    <LM>w#w-d1t1146-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1146-2">
   <w.rf>
    <LM>w#w-d1t1146-2</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m054-d1t1146-3">
   <w.rf>
    <LM>w#w-d1t1146-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m054-d1t1146-5">
   <w.rf>
    <LM>w#w-d1t1146-5</LM>
   </w.rf>
   <form>měšťanské</form>
   <lemma>měšťanský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m054-d1t1146-6">
   <w.rf>
    <LM>w#w-d1t1146-6</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d1t1146-7">
   <w.rf>
    <LM>w#w-d1t1146-7</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-80-82">
   <w.rf>
    <LM>w#w-80-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-83">
  <m id="m054-d1t1146-9">
   <w.rf>
    <LM>w#w-d1t1146-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m054-d1t1146-10">
   <w.rf>
    <LM>w#w-d1t1146-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1146-15">
   <w.rf>
    <LM>w#w-d1t1146-15</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-83-88">
   <w.rf>
    <LM>w#w-83-88</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1154-1">
   <w.rf>
    <LM>w#w-d1t1154-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1154-3">
   <w.rf>
    <LM>w#w-d1t1154-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m054-d-id105302-punct">
   <w.rf>
    <LM>w#w-d-id105302-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1154-5">
   <w.rf>
    <LM>w#w-d1t1154-5</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1154-7">
   <w.rf>
    <LM>w#w-d1t1154-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m054-d1t1154-8">
   <w.rf>
    <LM>w#w-d1t1154-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m054-d1t1154-6">
   <w.rf>
    <LM>w#w-d1t1154-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1154-9">
   <w.rf>
    <LM>w#w-d1t1154-9</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m054-83-89">
   <w.rf>
    <LM>w#w-83-89</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1146-11">
   <w.rf>
    <LM>w#w-d1t1146-11</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d-m-d1e1149-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1149-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1149-x3">
  <m id="m054-d1t1158-1">
   <w.rf>
    <LM>w#w-d1t1158-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1158-2">
   <w.rf>
    <LM>w#w-d1t1158-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m054-d1t1158-4">
   <w.rf>
    <LM>w#w-d1t1158-4</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m054-d1t1158-3">
   <w.rf>
    <LM>w#w-d1t1158-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1158-5">
   <w.rf>
    <LM>w#w-d1t1158-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m054-d1t1158-6">
   <w.rf>
    <LM>w#w-d1t1158-6</LM>
   </w.rf>
   <form>šatech</form>
   <lemma>šat</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m054-d1t1158-7">
   <w.rf>
    <LM>w#w-d1t1158-7</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m054-d1t1158-8">
   <w.rf>
    <LM>w#w-d1t1158-8</LM>
   </w.rf>
   <form>pavouka</form>
   <lemma>pavouk-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d-id105585-punct">
   <w.rf>
    <LM>w#w-d-id105585-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-d1e1159-x2">
  <m id="m054-d1t1162-2">
   <w.rf>
    <LM>w#w-d1t1162-2</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m054-d1t1162-3">
   <w.rf>
    <LM>w#w-d1t1162-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m054-d1t1162-4">
   <w.rf>
    <LM>w#w-d1t1162-4</LM>
   </w.rf>
   <form>pavouka</form>
   <lemma>pavouk-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m054-d-id105709-punct">
   <w.rf>
    <LM>w#w-d-id105709-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m054-d1t1162-7">
   <w.rf>
    <LM>w#w-d1t1162-7</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m054-d1t1162-8">
   <w.rf>
    <LM>w#w-d1t1162-8</LM>
   </w.rf>
   <form>přinesl</form>
   <lemma>přinést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m054-d1t1162-9">
   <w.rf>
    <LM>w#w-d1t1162-9</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m054-d1e1159-x2-96">
   <w.rf>
    <LM>w#w-d1e1159-x2-96</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m054-109">
  <m id="m054-d1t1168-1">
   <w.rf>
    <LM>w#w-d1t1168-1</LM>
   </w.rf>
   <form>Aha</form>
   <lemma>aha</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m054-d-m-d1e1163-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1163-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
