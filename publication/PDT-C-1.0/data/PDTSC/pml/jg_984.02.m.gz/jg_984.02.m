<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_984.02.w.gz" />
  </references>
 </head>
 <s id="m984-13808_04-386">
  <m id="m984-d1t766-15">
   <w.rf>
    <LM>w#w-d1t766-15</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1e661-x10-973">
   <w.rf>
    <LM>w#w-d1e661-x10-973</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t768-2">
   <w.rf>
    <LM>w#w-d1t768-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t768-3">
   <w.rf>
    <LM>w#w-d1t768-3</LM>
   </w.rf>
   <form>jela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t768-4">
   <w.rf>
    <LM>w#w-d1t768-4</LM>
   </w.rf>
   <form>tramvají</form>
   <lemma>tramvaj</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m984-d1t768-5">
   <w.rf>
    <LM>w#w-d1t768-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t768-7">
   <w.rf>
    <LM>w#w-d1t768-7</LM>
   </w.rf>
   <form>jazykovky</form>
   <lemma>jazykovka_,h</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m984-d-id80509">
   <w.rf>
    <LM>w#w-d-id80509</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t768-12">
   <w.rf>
    <LM>w#w-d1t768-12</LM>
   </w.rf>
   <form>jel</form>
   <lemma>jet-1</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m984-d1t768-13">
   <w.rf>
    <LM>w#w-d1t768-13</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m984-d1t768-14">
   <w.rf>
    <LM>w#w-d1t768-14</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m984-d-id80604">
   <w.rf>
    <LM>w#w-d-id80604</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e661-x11">
  <m id="m984-d1t776-3">
   <w.rf>
    <LM>w#w-d1t776-3</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t776-2">
   <w.rf>
    <LM>w#w-d1t776-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m984-d-id80701">
   <w.rf>
    <LM>w#w-d-id80701</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e661-x11-1034">
   <w.rf>
    <LM>w#w-d1e661-x11-1034</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t776-7">
   <w.rf>
    <LM>w#w-d1t776-7</LM>
   </w.rf>
   <form>Nesmím</form>
   <lemma>smět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m984-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m984-d1t776-6">
   <w.rf>
    <LM>w#w-d1t776-6</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m984-d1t776-8">
   <w.rf>
    <LM>w#w-d1t776-8</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m984-d-id80772">
   <w.rf>
    <LM>w#w-d-id80772</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t776-10">
   <w.rf>
    <LM>w#w-d1t776-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t776-11">
   <w.rf>
    <LM>w#w-d1t776-11</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m984-d1t776-12">
   <w.rf>
    <LM>w#w-d1t776-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t776-13">
   <w.rf>
    <LM>w#w-d1t776-13</LM>
   </w.rf>
   <form>baráku</form>
   <lemma>barák</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m984-d1t776-14">
   <w.rf>
    <LM>w#w-d1t776-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m984-d1t776-15">
   <w.rf>
    <LM>w#w-d1t776-15</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d1t776-16">
   <w.rf>
    <LM>w#w-d1t776-16</LM>
   </w.rf>
   <form>vyslýcháni</form>
   <lemma>vyslýchat</lemma>
   <tag>VsMP----X-API--</tag>
  </m>
  <m id="m984-d1e661-x11-1038">
   <w.rf>
    <LM>w#w-d1e661-x11-1038</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id80962">
   <w.rf>
    <LM>w#w-d-id80962</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1039">
  <m id="m984-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t779-7">
   <w.rf>
    <LM>w#w-d1t779-7</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t779-8">
   <w.rf>
    <LM>w#w-d1t779-8</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m984-d1t779-9">
   <w.rf>
    <LM>w#w-d1t779-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t779-10">
   <w.rf>
    <LM>w#w-d1t779-10</LM>
   </w.rf>
   <form>nedalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m984-d-id81041">
   <w.rf>
    <LM>w#w-d-id81041</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e661-x12">
  <m id="m984-d1t783-6">
   <w.rf>
    <LM>w#w-d1t783-6</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t783-4">
   <w.rf>
    <LM>w#w-d1t783-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t783-5">
   <w.rf>
    <LM>w#w-d1t783-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t785-1">
   <w.rf>
    <LM>w#w-d1t785-1</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1e661-x12-1201">
   <w.rf>
    <LM>w#w-d1e661-x12-1201</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>pozorovala</form>
   <lemma>pozorovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1e661-x12-1203">
   <w.rf>
    <LM>w#w-d1e661-x12-1203</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m984-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t787-5">
   <w.rf>
    <LM>w#w-d1t787-5</LM>
   </w.rf>
   <form>hlídá</form>
   <lemma>hlídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-d1e661-x12-1204">
   <w.rf>
    <LM>w#w-d1e661-x12-1204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1205">
  <m id="m984-d1t789-1">
   <w.rf>
    <LM>w#w-d1t789-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d1t789-2">
   <w.rf>
    <LM>w#w-d1t789-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t789-3">
   <w.rf>
    <LM>w#w-d1t789-3</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m984-d1t789-4">
   <w.rf>
    <LM>w#w-d1t789-4</LM>
   </w.rf>
   <form>chlapů</form>
   <lemma>chlap</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m984-d1t789-5">
   <w.rf>
    <LM>w#w-d1t789-5</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m984-d1t789-6">
   <w.rf>
    <LM>w#w-d1t789-6</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS6-----A---9</tag>
  </m>
  <m id="m984-d1t789-7">
   <w.rf>
    <LM>w#w-d1t789-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t789-8">
   <w.rf>
    <LM>w#w-d1t789-8</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-1205-1242">
   <w.rf>
    <LM>w#w-1205-1242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1243">
  <m id="m984-d1t792-1">
   <w.rf>
    <LM>w#w-d1t792-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t792-2">
   <w.rf>
    <LM>w#w-d1t792-2</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-d1t792-3">
   <w.rf>
    <LM>w#w-d1t792-3</LM>
   </w.rf>
   <form>seděli</form>
   <lemma>sedět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d1t792-4">
   <w.rf>
    <LM>w#w-d1t792-4</LM>
   </w.rf>
   <form>naproti</form>
   <lemma>naproti-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t792-5">
   <w.rf>
    <LM>w#w-d1t792-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t794-1">
   <w.rf>
    <LM>w#w-d1t794-1</LM>
   </w.rf>
   <form>domovníka</form>
   <lemma>domovník</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m984-d1t794-2">
   <w.rf>
    <LM>w#w-d1t794-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-1205-1218">
   <w.rf>
    <LM>w#w-1205-1218</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t794-4">
   <w.rf>
    <LM>w#w-d1t794-4</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m984-d1t794-5">
   <w.rf>
    <LM>w#w-d1t794-5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m984-d1t794-6">
   <w.rf>
    <LM>w#w-d1t794-6</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m984-d1t794-7">
   <w.rf>
    <LM>w#w-d1t794-7</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-1243-398">
   <w.rf>
    <LM>w#w-1243-398</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-399">
  <m id="m984-d1t796-2">
   <w.rf>
    <LM>w#w-d1t796-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t796-6">
   <w.rf>
    <LM>w#w-d1t796-6</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d-id81718">
   <w.rf>
    <LM>w#w-d-id81718</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t796-8">
   <w.rf>
    <LM>w#w-d1t796-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t796-9">
   <w.rf>
    <LM>w#w-d1t796-9</LM>
   </w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m984-d1t796-10">
   <w.rf>
    <LM>w#w-d1t796-10</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m984-d1t796-11">
   <w.rf>
    <LM>w#w-d1t796-11</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m984-d1t796-12">
   <w.rf>
    <LM>w#w-d1t796-12</LM>
   </w.rf>
   <form>odchází</form>
   <lemma>odcházet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-d-id81804">
   <w.rf>
    <LM>w#w-d-id81804</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t796-16">
   <w.rf>
    <LM>w#w-d1t796-16</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m984-d1t796-15">
   <w.rf>
    <LM>w#w-d1t796-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t796-17">
   <w.rf>
    <LM>w#w-d1t796-17</LM>
   </w.rf>
   <form>legitimovat</form>
   <lemma>legitimovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m984-d-id81875">
   <w.rf>
    <LM>w#w-d-id81875</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t800-3">
   <w.rf>
    <LM>w#w-d1t800-3</LM>
   </w.rf>
   <form>vyzpovídali</form>
   <lemma>vyzpovídat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t800-4">
   <w.rf>
    <LM>w#w-d1t800-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m984-1205-1224">
   <w.rf>
    <LM>w#w-1205-1224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1225">
  <m id="m984-d1t811-4">
   <w.rf>
    <LM>w#w-d1t811-4</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t811-2">
   <w.rf>
    <LM>w#w-d1t811-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t811-3">
   <w.rf>
    <LM>w#w-d1t811-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t811-6">
   <w.rf>
    <LM>w#w-d1t811-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t811-7">
   <w.rf>
    <LM>w#w-d1t811-7</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m984-d1t811-5">
   <w.rf>
    <LM>w#w-d1t811-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t811-8">
   <w.rf>
    <LM>w#w-d1t811-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m984-d1t811-9">
   <w.rf>
    <LM>w#w-d1t811-9</LM>
   </w.rf>
   <form>nervy</form>
   <lemma>nerv</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m984-d1t811-10">
   <w.rf>
    <LM>w#w-d1t811-10</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m984-d1t811-11">
   <w.rf>
    <LM>w#w-d1t811-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t811-12">
   <w.rf>
    <LM>w#w-d1t811-12</LM>
   </w.rf>
   <form>koncích</form>
   <lemma>konec</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m984-d-id82297">
   <w.rf>
    <LM>w#w-d-id82297</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e812-x2">
  <m id="m984-d1t817-1">
   <w.rf>
    <LM>w#w-d1t817-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t817-2">
   <w.rf>
    <LM>w#w-d1t817-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m984-d1t817-3">
   <w.rf>
    <LM>w#w-d1t817-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t817-4">
   <w.rf>
    <LM>w#w-d1t817-4</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d-id82433">
   <w.rf>
    <LM>w#w-d-id82433</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e818-x2">
  <m id="m984-d1t827-1">
   <w.rf>
    <LM>w#w-d1t827-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t827-2">
   <w.rf>
    <LM>w#w-d1t827-2</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d1t827-3">
   <w.rf>
    <LM>w#w-d1t827-3</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m984-d-id82571">
   <w.rf>
    <LM>w#w-d-id82571</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e818-x3">
  <m id="m984-d1t829-2">
   <w.rf>
    <LM>w#w-d1t829-2</LM>
   </w.rf>
   <form>Nejhorší</form>
   <lemma>horší</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m984-d1t829-4">
   <w.rf>
    <LM>w#w-d1t829-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t829-5">
   <w.rf>
    <LM>w#w-d1t829-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m984-d1t829-3">
   <w.rf>
    <LM>w#w-d1t829-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d-id82672">
   <w.rf>
    <LM>w#w-d-id82672</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t829-7">
   <w.rf>
    <LM>w#w-d1t829-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t829-8">
   <w.rf>
    <LM>w#w-d1t829-8</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m984-d1t829-9">
   <w.rf>
    <LM>w#w-d1t829-9</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAMP1----3A----</tag>
  </m>
  <m id="m984-d1t829-10">
   <w.rf>
    <LM>w#w-d1t829-10</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m984-d-id82743">
   <w.rf>
    <LM>w#w-d-id82743</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t829-12">
   <w.rf>
    <LM>w#w-d1t829-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t829-14">
   <w.rf>
    <LM>w#w-d1t829-14</LM>
   </w.rf>
   <form>inženýr</form>
   <lemma>inženýr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m984-d1t829-15">
   <w.rf>
    <LM>w#w-d1t829-15</LM>
   </w.rf>
   <form>Rada</form>
   <lemma>Rada_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m984-d-id82814">
   <w.rf>
    <LM>w#w-d-id82814</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t829-18">
   <w.rf>
    <LM>w#w-d1t829-18</LM>
   </w.rf>
   <form>generální</form>
   <lemma>generální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m984-d1t832-1">
   <w.rf>
    <LM>w#w-d1t832-1</LM>
   </w.rf>
   <form>řiditel</form>
   <lemma>řiditel_,h_^(^GC**ředitel)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m984-d1t832-3">
   <w.rf>
    <LM>w#w-d1t832-3</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>důl</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m984-d1e818-x3-415">
   <w.rf>
    <LM>w#w-d1e818-x3-415</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e818-x3-416">
   <w.rf>
    <LM>w#w-d1e818-x3-416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e818-x3-417">
   <w.rf>
    <LM>w#w-d1e818-x3-417</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-418">
  <m id="m984-d1t836-1">
   <w.rf>
    <LM>w#w-d1t836-1</LM>
   </w.rf>
   <form>Dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t836-2">
   <w.rf>
    <LM>w#w-d1t836-2</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m984-d1t836-3">
   <w.rf>
    <LM>w#w-d1t836-3</LM>
   </w.rf>
   <form>tip</form>
   <lemma>tip</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m984-d-id82975">
   <w.rf>
    <LM>w#w-d-id82975</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t836-5">
   <w.rf>
    <LM>w#w-d1t836-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t836-6">
   <w.rf>
    <LM>w#w-d1t836-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m984-d1t836-7">
   <w.rf>
    <LM>w#w-d1t836-7</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m984-d1t836-8">
   <w.rf>
    <LM>w#w-d1t836-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t836-9">
   <w.rf>
    <LM>w#w-d1t836-9</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m984-d1t836-10">
   <w.rf>
    <LM>w#w-d1t836-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t836-11">
   <w.rf>
    <LM>w#w-d1t836-11</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m984-d1t836-12">
   <w.rf>
    <LM>w#w-d1t836-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t838-1">
   <w.rf>
    <LM>w#w-d1t838-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t838-3">
   <w.rf>
    <LM>w#w-d1t838-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m984-d1t838-2">
   <w.rf>
    <LM>w#w-d1t838-2</LM>
   </w.rf>
   <form>1952</form>
   <lemma>1952</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m984-d1t836-13">
   <w.rf>
    <LM>w#w-d1t836-13</LM>
   </w.rf>
   <form>zastřelil</form>
   <lemma>zastřelit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m984-418-427">
   <w.rf>
    <LM>w#w-418-427</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-428">
  <m id="m984-d1t838-4">
   <w.rf>
    <LM>w#w-d1t838-4</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t838-5">
   <w.rf>
    <LM>w#w-d1t838-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m984-d1t838-6">
   <w.rf>
    <LM>w#w-d1t838-6</LM>
   </w.rf>
   <form>nevydržel</form>
   <lemma>vydržet</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m984-d-id83218">
   <w.rf>
    <LM>w#w-d-id83218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e818-x4">
  <m id="m984-d1t842-1">
   <w.rf>
    <LM>w#w-d1t842-1</LM>
   </w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m984-d1t842-2">
   <w.rf>
    <LM>w#w-d1t842-2</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m984-d1t847-1">
   <w.rf>
    <LM>w#w-d1t847-1</LM>
   </w.rf>
   <form>příbuzná</form>
   <lemma>příbuzná-1_^(*3ý-1)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1e818-x4-1617">
   <w.rf>
    <LM>w#w-d1e818-x4-1617</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t849-1">
   <w.rf>
    <LM>w#w-d1t849-1</LM>
   </w.rf>
   <form>lékařka</form>
   <lemma>lékařka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t849-2">
   <w.rf>
    <LM>w#w-d1t849-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t849-3">
   <w.rf>
    <LM>w#w-d1t849-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t849-4">
   <w.rf>
    <LM>w#w-d1t849-4</LM>
   </w.rf>
   <form>dětské</form>
   <lemma>dětský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m984-d1t849-5">
   <w.rf>
    <LM>w#w-d1t849-5</LM>
   </w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-d1t849-6">
   <w.rf>
    <LM>w#w-d1t849-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t849-7">
   <w.rf>
    <LM>w#w-d1t849-7</LM>
   </w.rf>
   <form>Podolí</form>
   <lemma>Podolí_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m984-d-id83415">
   <w.rf>
    <LM>w#w-d-id83415</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t853-1">
   <w.rf>
    <LM>w#w-d1t853-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t853-2">
   <w.rf>
    <LM>w#w-d1t853-2</LM>
   </w.rf>
   <form>Židovka</form>
   <lemma>Židovka_;E</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t853-3">
   <w.rf>
    <LM>w#w-d1t853-3</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d-id83488">
   <w.rf>
    <LM>w#w-d-id83488</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t853-7">
   <w.rf>
    <LM>w#w-d1t853-7</LM>
   </w.rf>
   <form>spáchala</form>
   <lemma>spáchat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t853-8">
   <w.rf>
    <LM>w#w-d1t853-8</LM>
   </w.rf>
   <form>sebevraždu</form>
   <lemma>sebevražda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m984-d-id83559">
   <w.rf>
    <LM>w#w-d-id83559</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t853-12">
   <w.rf>
    <LM>w#w-d1t853-12</LM>
   </w.rf>
   <form>otrávila</form>
   <lemma>otrávit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t853-11">
   <w.rf>
    <LM>w#w-d1t853-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1e818-x4-1619">
   <w.rf>
    <LM>w#w-d1e818-x4-1619</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1620">
  <m id="m984-d1t855-1">
   <w.rf>
    <LM>w#w-d1t855-1</LM>
   </w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m984-d1t855-2">
   <w.rf>
    <LM>w#w-d1t855-2</LM>
   </w.rf>
   <form>kolegyně</form>
   <lemma>kolegyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t862-1">
   <w.rf>
    <LM>w#w-d1t862-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t862-2">
   <w.rf>
    <LM>w#w-d1t862-2</LM>
   </w.rf>
   <form>ministerstva</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m984-1620-1630">
   <w.rf>
    <LM>w#w-1620-1630</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t862-3">
   <w.rf>
    <LM>w#w-d1t862-3</LM>
   </w.rf>
   <form>Slovenka</form>
   <lemma>Slovenka_;E</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d-id83727">
   <w.rf>
    <LM>w#w-d-id83727</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t862-5">
   <w.rf>
    <LM>w#w-d1t862-5</LM>
   </w.rf>
   <form>doktorka</form>
   <lemma>doktorka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t862-6">
   <w.rf>
    <LM>w#w-d1t862-6</LM>
   </w.rf>
   <form>Šarišská</form>
   <lemma>Šarišská_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d-id83760">
   <w.rf>
    <LM>w#w-d-id83760</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t862-9">
   <w.rf>
    <LM>w#w-d1t862-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t862-10">
   <w.rf>
    <LM>w#w-d1t862-10</LM>
   </w.rf>
   <form>oběsila</form>
   <lemma>oběsit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-1620-441">
   <w.rf>
    <LM>w#w-1620-441</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-442">
  <m id="m984-d1t864-2">
   <w.rf>
    <LM>w#w-d1t864-2</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m984-d1t864-3">
   <w.rf>
    <LM>w#w-d1t864-3</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m984-1620-1632">
   <w.rf>
    <LM>w#w-1620-1632</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t866-1">
   <w.rf>
    <LM>w#w-d1t866-1</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t866-2">
   <w.rf>
    <LM>w#w-d1t866-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t866-3">
   <w.rf>
    <LM>w#w-d1t866-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t868-1">
   <w.rf>
    <LM>w#w-d1t868-1</LM>
   </w.rf>
   <form>blízcí</form>
   <lemma>blízký</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m984-d1t868-2">
   <w.rf>
    <LM>w#w-d1t868-2</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m984-d-id83974">
   <w.rf>
    <LM>w#w-d-id83974</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t868-4">
   <w.rf>
    <LM>w#w-d1t868-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t871-2">
   <w.rf>
    <LM>w#w-d1t871-2</LM>
   </w.rf>
   <form>známí</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m984-1620-1633">
   <w.rf>
    <LM>w#w-1620-1633</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t871-5">
   <w.rf>
    <LM>w#w-d1t871-5</LM>
   </w.rf>
   <form>spáchali</form>
   <lemma>spáchat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t871-6">
   <w.rf>
    <LM>w#w-d1t871-6</LM>
   </w.rf>
   <form>sebevraždu</form>
   <lemma>sebevražda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m984-d1t871-7">
   <w.rf>
    <LM>w#w-d1t871-7</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m984-d-id84108">
   <w.rf>
    <LM>w#w-d-id84108</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t871-9">
   <w.rf>
    <LM>w#w-d1t871-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t871-10">
   <w.rf>
    <LM>w#w-d1t871-10</LM>
   </w.rf>
   <form>skočili</form>
   <lemma>skočit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t871-11">
   <w.rf>
    <LM>w#w-d1t871-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t871-12">
   <w.rf>
    <LM>w#w-d1t871-12</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m984-d-id84179">
   <w.rf>
    <LM>w#w-d-id84179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e818-x5">
  <m id="m984-d1t875-5">
   <w.rf>
    <LM>w#w-d1t875-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t875-6">
   <w.rf>
    <LM>w#w-d1t875-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d1t875-7">
   <w.rf>
    <LM>w#w-d1t875-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t875-8">
   <w.rf>
    <LM>w#w-d1t875-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t875-10">
   <w.rf>
    <LM>w#w-d1t875-10</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m984-d1t875-11">
   <w.rf>
    <LM>w#w-d1t875-11</LM>
   </w.rf>
   <form>hrozného</form>
   <lemma>hrozný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m984-d-id84382">
   <w.rf>
    <LM>w#w-d-id84382</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t875-15">
   <w.rf>
    <LM>w#w-d1t875-15</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t875-16">
   <w.rf>
    <LM>w#w-d1t875-16</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t875-17">
   <w.rf>
    <LM>w#w-d1t875-17</LM>
   </w.rf>
   <form>nescházelo</form>
   <lemma>scházet</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m984-d1e818-x5-1697">
   <w.rf>
    <LM>w#w-d1e818-x5-1697</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-1698">
  <m id="m984-d1t877-2">
   <w.rf>
    <LM>w#w-d1t877-2</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-1698-1711">
   <w.rf>
    <LM>w#w-1698-1711</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-1698-1712">
   <w.rf>
    <LM>w#w-1698-1712</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m984-1698-1713">
   <w.rf>
    <LM>w#w-1698-1713</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id84495">
   <w.rf>
    <LM>w#w-d-id84495</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t879-1">
   <w.rf>
    <LM>w#w-d1t879-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m984-d1t879-2">
   <w.rf>
    <LM>w#w-d1t879-2</LM>
   </w.rf>
   <form>čemu</form>
   <lemma>co-1</lemma>
   <tag>PQ--3----------</tag>
  </m>
  <m id="m984-d1t879-3">
   <w.rf>
    <LM>w#w-d1t879-3</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m984-d1t879-4">
   <w.rf>
    <LM>w#w-d1t879-4</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m984-d1t879-5">
   <w.rf>
    <LM>w#w-d1t879-5</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t879-6">
   <w.rf>
    <LM>w#w-d1t879-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-1698-1715">
   <w.rf>
    <LM>w#w-1698-1715</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id84606">
   <w.rf>
    <LM>w#w-d-id84606</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e818-x6">
  <m id="m984-d1t884-1">
   <w.rf>
    <LM>w#w-d1t884-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t886-1">
   <w.rf>
    <LM>w#w-d1t886-1</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t886-2">
   <w.rf>
    <LM>w#w-d1t886-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t886-3">
   <w.rf>
    <LM>w#w-d1t886-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m984-d1t886-5">
   <w.rf>
    <LM>w#w-d1t886-5</LM>
   </w.rf>
   <form>překonala</form>
   <lemma>překonat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d-id84614">
   <w.rf>
    <LM>w#w-d-id84614</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e891-x2">
  <m id="m984-d1t894-1">
   <w.rf>
    <LM>w#w-d1t894-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t894-2">
   <w.rf>
    <LM>w#w-d1t894-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m984-d1t894-3">
   <w.rf>
    <LM>w#w-d1t894-3</LM>
   </w.rf>
   <form>předvolávali</form>
   <lemma>předvolávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d1t894-6">
   <w.rf>
    <LM>w#w-d1t894-6</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t894-4">
   <w.rf>
    <LM>w#w-d1t894-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m984-d1t894-5">
   <w.rf>
    <LM>w#w-d1t894-5</LM>
   </w.rf>
   <form>výslechu</form>
   <lemma>výslech</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m984-d-id84971">
   <w.rf>
    <LM>w#w-d-id84971</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e895-x2">
  <m id="m984-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1e895-x2-454">
   <w.rf>
    <LM>w#w-d1e895-x2-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-455">
  <m id="m984-d1t900-3">
   <w.rf>
    <LM>w#w-d1t900-3</LM>
   </w.rf>
   <form>Dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m984-d1t898-4">
   <w.rf>
    <LM>w#w-d1t898-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t898-5">
   <w.rf>
    <LM>w#w-d1t898-5</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t898-6">
   <w.rf>
    <LM>w#w-d1t898-6</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t898-7">
   <w.rf>
    <LM>w#w-d1t898-7</LM>
   </w.rf>
   <form>několikrát</form>
   <lemma>několikrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m984-d1t898-8">
   <w.rf>
    <LM>w#w-d1t898-8</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d-id85154">
   <w.rf>
    <LM>w#w-d-id85154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t900-1">
   <w.rf>
    <LM>w#w-d1t900-1</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t900-2">
   <w.rf>
    <LM>w#w-d1t900-2</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d-id85218">
   <w.rf>
    <LM>w#w-d-id85218</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-455-456">
   <w.rf>
    <LM>w#w-455-456</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t902-1">
   <w.rf>
    <LM>w#w-d1t902-1</LM>
   </w.rf>
   <form>odvedli</form>
   <lemma>odvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t902-2">
   <w.rf>
    <LM>w#w-d1t902-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t902-3">
   <w.rf>
    <LM>w#w-d1t902-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t904-1">
   <w.rf>
    <LM>w#w-d1t904-1</LM>
   </w.rf>
   <form>Perštýn</form>
   <lemma>Perštýn_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m984-d1t904-6">
   <w.rf>
    <LM>w#w-d1t904-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t904-7">
   <w.rf>
    <LM>w#w-d1t904-7</LM>
   </w.rf>
   <form>výslech</form>
   <lemma>výslech</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m984-d1e895-x2-2015">
   <w.rf>
    <LM>w#w-d1e895-x2-2015</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2016">
  <m id="m984-d1t904-9">
   <w.rf>
    <LM>w#w-d1t904-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t904-10">
   <w.rf>
    <LM>w#w-d1t904-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t909-1">
   <w.rf>
    <LM>w#w-d1t909-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m984-d1t904-12">
   <w.rf>
    <LM>w#w-d1t904-12</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t909-2">
   <w.rf>
    <LM>w#w-d1t909-2</LM>
   </w.rf>
   <form>balila</form>
   <lemma>balit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t913-1">
   <w.rf>
    <LM>w#w-d1t913-1</LM>
   </w.rf>
   <form>zubní</form>
   <lemma>zubní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m984-d1t913-2">
   <w.rf>
    <LM>w#w-d1t913-2</LM>
   </w.rf>
   <form>kartáček</form>
   <lemma>kartáček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m984-d-id85523">
   <w.rf>
    <LM>w#w-d-id85523</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t909-6">
   <w.rf>
    <LM>w#w-d1t909-6</LM>
   </w.rf>
   <form>přemýšlela</form>
   <lemma>přemýšlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t909-5">
   <w.rf>
    <LM>w#w-d1t909-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-2016-2039">
   <w.rf>
    <LM>w#w-2016-2039</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id85642">
   <w.rf>
    <LM>w#w-d-id85642</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t913-4">
   <w.rf>
    <LM>w#w-d1t913-4</LM>
   </w.rf>
   <form>Zůstanu</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m984-d1t913-5">
   <w.rf>
    <LM>w#w-d1t913-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t913-6">
   <w.rf>
    <LM>w#w-d1t913-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t915-1">
   <w.rf>
    <LM>w#w-d1t915-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t915-2">
   <w.rf>
    <LM>w#w-d1t915-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-2016-2042">
   <w.rf>
    <LM>w#w-2016-2042</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-2016-2031">
   <w.rf>
    <LM>w#w-2016-2031</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2032">
  <m id="m984-d1t917-5">
   <w.rf>
    <LM>w#w-d1t917-5</LM>
   </w.rf>
   <form>Celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m984-d1t917-6">
   <w.rf>
    <LM>w#w-d1t917-6</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m984-2032-2046">
   <w.rf>
    <LM>w#w-2032-2046</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t917-7">
   <w.rf>
    <LM>w#w-d1t917-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t917-8">
   <w.rf>
    <LM>w#w-d1t917-8</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d1t917-9">
   <w.rf>
    <LM>w#w-d1t917-9</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t917-10">
   <w.rf>
    <LM>w#w-d1t917-10</LM>
   </w.rf>
   <form>rána</form>
   <lemma>ráno-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m984-d1t917-11">
   <w.rf>
    <LM>w#w-d1t917-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t917-12">
   <w.rf>
    <LM>w#w-d1t917-12</LM>
   </w.rf>
   <form>večera</form>
   <lemma>večer-1</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m984-d-id85926">
   <w.rf>
    <LM>w#w-d-id85926</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t917-14">
   <w.rf>
    <LM>w#w-d1t917-14</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t917-15">
   <w.rf>
    <LM>w#w-d1t917-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t917-16">
   <w.rf>
    <LM>w#w-d1t917-16</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t917-17">
   <w.rf>
    <LM>w#w-d1t917-17</LM>
   </w.rf>
   <form>ptali</form>
   <lemma>ptát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-2032-2052">
   <w.rf>
    <LM>w#w-2032-2052</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2055">
  <m id="m984-d1t919-2">
   <w.rf>
    <LM>w#w-d1t919-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t922-2">
   <w.rf>
    <LM>w#w-d1t922-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t922-3">
   <w.rf>
    <LM>w#w-d1t922-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t922-1">
   <w.rf>
    <LM>w#w-d1t922-1</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-2032-2048">
   <w.rf>
    <LM>w#w-2032-2048</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t922-5">
   <w.rf>
    <LM>w#w-d1t922-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t926-2">
   <w.rf>
    <LM>w#w-d1t926-2</LM>
   </w.rf>
   <form>pobrali</form>
   <lemma>pobrat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t922-6">
   <w.rf>
    <LM>w#w-d1t922-6</LM>
   </w.rf>
   <form>veškerou</form>
   <lemma>veškerý</lemma>
   <tag>PLFS4----------</tag>
  </m>
  <m id="m984-d1t922-7">
   <w.rf>
    <LM>w#w-d1t922-7</LM>
   </w.rf>
   <form>korespondenci</form>
   <lemma>korespondence</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m984-2055-464">
   <w.rf>
    <LM>w#w-2055-464</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t924-3">
   <w.rf>
    <LM>w#w-d1t924-3</LM>
   </w.rf>
   <form>dopisy</form>
   <lemma>dopis</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m984-2032-2050">
   <w.rf>
    <LM>w#w-2032-2050</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t922-8">
   <w.rf>
    <LM>w#w-d1t922-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m984-d1t922-9">
   <w.rf>
    <LM>w#w-d1t922-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t922-10">
   <w.rf>
    <LM>w#w-d1t922-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d-id86319">
   <w.rf>
    <LM>w#w-d-id86319</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t926-1">
   <w.rf>
    <LM>w#w-d1t926-1</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m984-2055-465">
   <w.rf>
    <LM>w#w-2055-465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-466">
  <m id="m984-d1t926-4">
   <w.rf>
    <LM>w#w-d1t926-4</LM>
   </w.rf>
   <form>Ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m984-d1t926-5">
   <w.rf>
    <LM>w#w-d1t926-5</LM>
   </w.rf>
   <form>každému</form>
   <lemma>každý</lemma>
   <tag>AAIS3----1A----</tag>
  </m>
  <m id="m984-d1t926-6">
   <w.rf>
    <LM>w#w-d1t926-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t926-7">
   <w.rf>
    <LM>w#w-d1t926-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t928-1">
   <w.rf>
    <LM>w#w-d1t928-1</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t928-2">
   <w.rf>
    <LM>w#w-d1t928-2</LM>
   </w.rf>
   <form>vyjádřit</form>
   <lemma>vyjádřit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m984-2055-2066">
   <w.rf>
    <LM>w#w-2055-2066</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2067">
  <m id="m984-d1t928-4">
   <w.rf>
    <LM>w#w-d1t928-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t928-5">
   <w.rf>
    <LM>w#w-d1t928-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m984-d1t930-1">
   <w.rf>
    <LM>w#w-d1t930-1</LM>
   </w.rf>
   <form>kolegyně</form>
   <lemma>kolegyně</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m984-d1t930-2">
   <w.rf>
    <LM>w#w-d1t930-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t930-3">
   <w.rf>
    <LM>w#w-d1t930-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t930-4">
   <w.rf>
    <LM>w#w-d1t930-4</LM>
   </w.rf>
   <form>Anglie</form>
   <lemma>Anglie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m984-d-id86589">
   <w.rf>
    <LM>w#w-d-id86589</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t930-8">
   <w.rf>
    <LM>w#w-d1t930-8</LM>
   </w.rf>
   <form>posílaly</form>
   <lemma>posílat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m984-d1t930-7">
   <w.rf>
    <LM>w#w-d1t930-7</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m984-d1t930-9">
   <w.rf>
    <LM>w#w-d1t930-9</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m984-d1t932-1">
   <w.rf>
    <LM>w#w-d1t932-1</LM>
   </w.rf>
   <form>pohledy</form>
   <lemma>pohled</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m984-2067-473">
   <w.rf>
    <LM>w#w-2067-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-474">
  <m id="m984-d1t937-1">
   <w.rf>
    <LM>w#w-d1t937-1</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t937-2">
   <w.rf>
    <LM>w#w-d1t937-2</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AAMS6----1A----</tag>
  </m>
  <m id="m984-d1t937-3">
   <w.rf>
    <LM>w#w-d1t937-3</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d1t937-4">
   <w.rf>
    <LM>w#w-d1t937-4</LM>
   </w.rf>
   <form>vědět</form>
   <lemma>vědět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m984-d-id86806">
   <w.rf>
    <LM>w#w-d-id86806</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t937-6">
   <w.rf>
    <LM>w#w-d1t937-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m984-d1t937-7">
   <w.rf>
    <LM>w#w-d1t937-7</LM>
   </w.rf>
   <form>dělají</form>
   <lemma>dělat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m984-d1t937-8">
   <w.rf>
    <LM>w#w-d1t937-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t937-9">
   <w.rf>
    <LM>w#w-d1t937-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t937-10">
   <w.rf>
    <LM>w#w-d1t937-10</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d-id86892">
   <w.rf>
    <LM>w#w-d-id86892</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e895-x3">
  <m id="m984-d1t943-3">
   <w.rf>
    <LM>w#w-d1t943-3</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1e895-x3-2125">
   <w.rf>
    <LM>w#w-d1e895-x3-2125</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t943-4">
   <w.rf>
    <LM>w#w-d1t943-4</LM>
   </w.rf>
   <form>nevěděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m984-d-id86996">
   <w.rf>
    <LM>w#w-d-id86996</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t945-3">
   <w.rf>
    <LM>w#w-d1t945-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d1t945-4">
   <w.rf>
    <LM>w#w-d1t945-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t945-6">
   <w.rf>
    <LM>w#w-d1t945-6</LM>
   </w.rf>
   <form>úmoru</form>
   <lemma>úmor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m984-d1e895-x3-2127">
   <w.rf>
    <LM>w#w-d1e895-x3-2127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t945-7">
   <w.rf>
    <LM>w#w-d1t945-7</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t945-8">
   <w.rf>
    <LM>w#w-d1t945-8</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m984-d1t945-9">
   <w.rf>
    <LM>w#w-d1t945-9</LM>
   </w.rf>
   <form>samé</form>
   <lemma>samý</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m984-d1t945-10">
   <w.rf>
    <LM>w#w-d1t945-10</LM>
   </w.rf>
   <form>otázky</form>
   <lemma>otázka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m984-d1e895-x3-481">
   <w.rf>
    <LM>w#w-d1e895-x3-481</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-482">
  <m id="m984-d1t945-13">
   <w.rf>
    <LM>w#w-d1t945-13</LM>
   </w.rf>
   <form>Nevěděla</form>
   <lemma>vědět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m984-d1e895-x3-2129">
   <w.rf>
    <LM>w#w-d1e895-x3-2129</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d-id87201">
   <w.rf>
    <LM>w#w-d-id87201</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t945-15">
   <w.rf>
    <LM>w#w-d1t945-15</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m984-d1t945-16">
   <w.rf>
    <LM>w#w-d1t945-16</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t945-17">
   <w.rf>
    <LM>w#w-d1t945-17</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S6--1-------</tag>
  </m>
  <m id="m984-d1t945-18">
   <w.rf>
    <LM>w#w-d1t945-18</LM>
   </w.rf>
   <form>chtějí</form>
   <lemma>chtít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m984-d1e895-x3-2248">
   <w.rf>
    <LM>w#w-d1e895-x3-2248</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t952-3">
   <w.rf>
    <LM>w#w-d1t952-3</LM>
   </w.rf>
   <form>ptala</form>
   <lemma>ptát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t952-1">
   <w.rf>
    <LM>w#w-d1t952-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t952-2">
   <w.rf>
    <LM>w#w-d1t952-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d-id87265">
   <w.rf>
    <LM>w#w-d-id87265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e895-x4">
  <m id="m984-d1e895-x4-2250">
   <w.rf>
    <LM>w#w-d1e895-x4-2250</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d-id87368">
   <w.rf>
    <LM>w#w-d-id87368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e895-x4-491">
   <w.rf>
    <LM>w#w-d1e895-x4-491</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t952-7">
   <w.rf>
    <LM>w#w-d1t952-7</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t952-8">
   <w.rf>
    <LM>w#w-d1t952-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-d1t952-9">
   <w.rf>
    <LM>w#w-d1t952-9</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m984-d1t952-10">
   <w.rf>
    <LM>w#w-d1t952-10</LM>
   </w.rf>
   <form>konkrétní</form>
   <lemma>konkrétní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m984-d1e895-x4-2254">
   <w.rf>
    <LM>w#w-d1e895-x4-2254</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t952-11">
   <w.rf>
    <LM>w#w-d1t952-11</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t952-12">
   <w.rf>
    <LM>w#w-d1t952-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t952-13">
   <w.rf>
    <LM>w#w-d1t952-13</LM>
   </w.rf>
   <form>zeptají</form>
   <lemma>zeptat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m984-d1e895-x4-489">
   <w.rf>
    <LM>w#w-d1e895-x4-489</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-490">
  <m id="m984-d1t954-2">
   <w.rf>
    <LM>w#w-d1t954-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m984-d1t954-3">
   <w.rf>
    <LM>w#w-d1t954-3</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d-id87568">
   <w.rf>
    <LM>w#w-d-id87568</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t954-5">
   <w.rf>
    <LM>w#w-d1t954-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m984-d1t954-6">
   <w.rf>
    <LM>w#w-d1t954-6</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m984-d1t954-7">
   <w.rf>
    <LM>w#w-d1t954-7</LM>
   </w.rf>
   <form>řeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m984-d-id87616">
   <w.rf>
    <LM>w#w-d-id87616</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t956-1">
   <w.rf>
    <LM>w#w-d1t956-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1e895-x4-2255">
   <w.rf>
    <LM>w#w-d1e895-x4-2255</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t956-3">
   <w.rf>
    <LM>w#w-d1t956-3</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m984-d1t956-4">
   <w.rf>
    <LM>w#w-d1t956-4</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP4----------</tag>
  </m>
  <m id="m984-d1t956-5">
   <w.rf>
    <LM>w#w-d1t956-5</LM>
   </w.rf>
   <form>tajnosti</form>
   <lemma>tajnost-1_^(*5ý-1)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m984-d1e895-x4-2257">
   <w.rf>
    <LM>w#w-d1e895-x4-2257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2258">
  <m id="m984-d1t958-2">
   <w.rf>
    <LM>w#w-d1t958-2</LM>
   </w.rf>
   <form>Říkají</form>
   <lemma>říkat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m984-d-id87738">
   <w.rf>
    <LM>w#w-d-id87738</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-2258-2268">
   <w.rf>
    <LM>w#w-2258-2268</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t958-7">
   <w.rf>
    <LM>w#w-d1t958-7</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t958-8">
   <w.rf>
    <LM>w#w-d1t958-8</LM>
   </w.rf>
   <form>povídejte</form>
   <lemma>povídat</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m984-2258-2270">
   <w.rf>
    <LM>w#w-2258-2270</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t958-9">
   <w.rf>
    <LM>w#w-d1t958-9</LM>
   </w.rf>
   <form>povídejte</form>
   <lemma>povídat</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m984-d-id87826">
   <w.rf>
    <LM>w#w-d-id87826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-2258-2271">
   <w.rf>
    <LM>w#w-2258-2271</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e895-x5">
  <m id="m984-d1t961-3">
   <w.rf>
    <LM>w#w-d1t961-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t961-5">
   <w.rf>
    <LM>w#w-d1t961-5</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m984-d-id87834">
   <w.rf>
    <LM>w#w-d-id87834</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e962-x2">
  <m id="m984-d1e962-x2-2308">
   <w.rf>
    <LM>w#w-d1e962-x2-2308</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t965-4">
   <w.rf>
    <LM>w#w-d1t965-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t965-1">
   <w.rf>
    <LM>w#w-d1t965-1</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t965-2">
   <w.rf>
    <LM>w#w-d1t965-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m984-d1t965-3">
   <w.rf>
    <LM>w#w-d1t965-3</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m984-d1e962-x2-2310">
   <w.rf>
    <LM>w#w-d1e962-x2-2310</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x2">
  <m id="m984-d1t973-1">
   <w.rf>
    <LM>w#w-d1t973-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t973-2">
   <w.rf>
    <LM>w#w-d1t973-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t973-3">
   <w.rf>
    <LM>w#w-d1t973-3</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m984-d1e966-x2-2386">
   <w.rf>
    <LM>w#w-d1e966-x2-2386</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t973-5">
   <w.rf>
    <LM>w#w-d1t973-5</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m984-d1e966-x2-512">
   <w.rf>
    <LM>w#w-d1e966-x2-512</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-513">
  <m id="m984-d1t973-7">
   <w.rf>
    <LM>w#w-d1t973-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t973-8">
   <w.rf>
    <LM>w#w-d1t973-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t973-9">
   <w.rf>
    <LM>w#w-d1t973-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t973-10">
   <w.rf>
    <LM>w#w-d1t973-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t973-11">
   <w.rf>
    <LM>w#w-d1t973-11</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t973-12">
   <w.rf>
    <LM>w#w-d1t973-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t973-14">
   <w.rf>
    <LM>w#w-d1t973-14</LM>
   </w.rf>
   <form>brigádě</form>
   <lemma>brigáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-d-id88305">
   <w.rf>
    <LM>w#w-d-id88305</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t975-4">
   <w.rf>
    <LM>w#w-d1t975-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t975-2">
   <w.rf>
    <LM>w#w-d1t975-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t975-3">
   <w.rf>
    <LM>w#w-d1t975-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t975-5">
   <w.rf>
    <LM>w#w-d1t975-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m984-d1t975-6">
   <w.rf>
    <LM>w#w-d1t975-6</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m984-d1t975-7">
   <w.rf>
    <LM>w#w-d1t975-7</LM>
   </w.rf>
   <form>dnů</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m984-513-514">
   <w.rf>
    <LM>w#w-513-514</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t980-4">
   <w.rf>
    <LM>w#w-d1t980-4</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m984-d1t980-5">
   <w.rf>
    <LM>w#w-d1t980-5</LM>
   </w.rf>
   <form>tajný</form>
   <lemma>tajný-1</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m984-d1e966-x2-2393">
   <w.rf>
    <LM>w#w-d1e966-x2-2393</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t980-6">
   <w.rf>
    <LM>w#w-d1t980-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t980-7">
   <w.rf>
    <LM>w#w-d1t980-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t980-8">
   <w.rf>
    <LM>w#w-d1t980-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m984-d1t980-9">
   <w.rf>
    <LM>w#w-d1t980-9</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m984-d1t980-10">
   <w.rf>
    <LM>w#w-d1t980-10</LM>
   </w.rf>
   <form>znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d-id88597">
   <w.rf>
    <LM>w#w-d-id88597</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t980-2">
   <w.rf>
    <LM>w#w-d1t980-2</LM>
   </w.rf>
   <form>najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t982-2">
   <w.rf>
    <LM>w#w-d1t982-2</LM>
   </w.rf>
   <form>zmizel</form>
   <lemma>zmizet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m984-513-515">
   <w.rf>
    <LM>w#w-513-515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-516">
  <m id="m984-d1t984-1">
   <w.rf>
    <LM>w#w-d1t984-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t984-2">
   <w.rf>
    <LM>w#w-d1t984-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m984-d1t984-3">
   <w.rf>
    <LM>w#w-d1t984-3</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m984-d1t984-4">
   <w.rf>
    <LM>w#w-d1t984-4</LM>
   </w.rf>
   <form>nešel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m984-d-id88740">
   <w.rf>
    <LM>w#w-d-id88740</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x4">
  <m id="m984-d1t988-4">
   <w.rf>
    <LM>w#w-d1t988-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t988-3">
   <w.rf>
    <LM>w#w-d1t988-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t988-5">
   <w.rf>
    <LM>w#w-d1t988-5</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m984-d1t988-6">
   <w.rf>
    <LM>w#w-d1t988-6</LM>
   </w.rf>
   <form>šťastná</form>
   <lemma>šťastný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m984-d-id88866">
   <w.rf>
    <LM>w#w-d-id88866</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t988-8">
   <w.rf>
    <LM>w#w-d1t988-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t988-9">
   <w.rf>
    <LM>w#w-d1t988-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t988-11">
   <w.rf>
    <LM>w#w-d1t988-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t988-10">
   <w.rf>
    <LM>w#w-d1t988-10</LM>
   </w.rf>
   <form>konečně</form>
   <lemma>konečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m984-d1t988-12">
   <w.rf>
    <LM>w#w-d1t988-12</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m984-d1e966-x4-521">
   <w.rf>
    <LM>w#w-d1e966-x4-521</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-522">
  <m id="m984-d1t990-1">
   <w.rf>
    <LM>w#w-d1t990-1</LM>
   </w.rf>
   <form>Jenže</form>
   <lemma>jenže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t990-3">
   <w.rf>
    <LM>w#w-d1t990-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t990-4">
   <w.rf>
    <LM>w#w-d1t990-4</LM>
   </w.rf>
   <form>pověřili</form>
   <lemma>pověřit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m984-d1t990-6">
   <w.rf>
    <LM>w#w-d1t990-6</LM>
   </w.rf>
   <form>bezpečnostního</form>
   <lemma>bezpečnostní</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m984-d1e966-x4-2556">
   <w.rf>
    <LM>w#w-d1e966-x4-2556</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t993-1">
   <w.rf>
    <LM>w#w-d1t993-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m984-d1t993-2">
   <w.rf>
    <LM>w#w-d1t993-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m984-d1t993-3">
   <w.rf>
    <LM>w#w-d1t993-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t993-4">
   <w.rf>
    <LM>w#w-d1t993-4</LM>
   </w.rf>
   <form>každém</form>
   <lemma>každý</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m984-d1t993-5">
   <w.rf>
    <LM>w#w-d1t993-5</LM>
   </w.rf>
   <form>podniku</form>
   <lemma>podnik</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m984-d-id89150">
   <w.rf>
    <LM>w#w-d-id89150</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t997-1">
   <w.rf>
    <LM>w#w-d1t997-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m984-d1t997-3">
   <w.rf>
    <LM>w#w-d1t997-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m984-d1t997-4">
   <w.rf>
    <LM>w#w-d1t997-4</LM>
   </w.rf>
   <form>hlídal</form>
   <lemma>hlídat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m984-d-id89254">
   <w.rf>
    <LM>w#w-d-id89254</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x5">
  <m id="m984-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m984-d1t1003-6">
   <w.rf>
    <LM>w#w-d1t1003-6</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1003-7">
   <w.rf>
    <LM>w#w-d1t1003-7</LM>
   </w.rf>
   <form>konkrétně</form>
   <lemma>konkrétně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m984-d-id89398">
   <w.rf>
    <LM>w#w-d-id89398</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e966-x5-2631">
   <w.rf>
    <LM>w#w-d1e966-x5-2631</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t1003-10">
   <w.rf>
    <LM>w#w-d1t1003-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t1003-11">
   <w.rf>
    <LM>w#w-d1t1003-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1003-14">
   <w.rf>
    <LM>w#w-d1t1003-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t1003-16">
   <w.rf>
    <LM>w#w-d1t1003-16</LM>
   </w.rf>
   <form>brigádě</form>
   <lemma>brigáda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-d1t1003-19">
   <w.rf>
    <LM>w#w-d1t1003-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t1003-20">
   <w.rf>
    <LM>w#w-d1t1003-20</LM>
   </w.rf>
   <form>Břevnově</form>
   <lemma>Břevnov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m984-d1t1003-12">
   <w.rf>
    <LM>w#w-d1t1003-12</LM>
   </w.rf>
   <form>skončila</form>
   <lemma>skončit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d-id89565">
   <w.rf>
    <LM>w#w-d-id89565</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1003-24">
   <w.rf>
    <LM>w#w-d1t1003-24</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t1003-23">
   <w.rf>
    <LM>w#w-d1t1003-23</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1003-25">
   <w.rf>
    <LM>w#w-d1t1003-25</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t1003-26">
   <w.rf>
    <LM>w#w-d1t1003-26</LM>
   </w.rf>
   <form>Tesly</form>
   <lemma>Tesla-2_;m_^(podnik,_značka)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m984-d1t1014-3">
   <w.rf>
    <LM>w#w-d1t1014-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t1014-4">
   <w.rf>
    <LM>w#w-d1t1014-4</LM>
   </w.rf>
   <form>Holešovicích</form>
   <lemma>Holešovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m984-d-id89762">
   <w.rf>
    <LM>w#w-d-id89762</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x6">
  <m id="m984-d1e966-x6-2832">
   <w.rf>
    <LM>w#w-d1e966-x6-2832</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t1006-4">
   <w.rf>
    <LM>w#w-d1t1006-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1006-5">
   <w.rf>
    <LM>w#w-d1t1006-5</LM>
   </w.rf>
   <form>nesměla</form>
   <lemma>smět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m984-d1t1006-6">
   <w.rf>
    <LM>w#w-d1t1006-6</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m984-d1t1006-2">
   <w.rf>
    <LM>w#w-d1t1006-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t1006-3">
   <w.rf>
    <LM>w#w-d1t1006-3</LM>
   </w.rf>
   <form>kancelářích</form>
   <lemma>kancelář</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m984-d1e966-x6-2829">
   <w.rf>
    <LM>w#w-d1e966-x6-2829</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1014-8">
   <w.rf>
    <LM>w#w-d1t1014-8</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t1014-7">
   <w.rf>
    <LM>w#w-d1t1014-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1014-6">
   <w.rf>
    <LM>w#w-d1t1014-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t1014-9">
   <w.rf>
    <LM>w#w-d1t1014-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t1014-11">
   <w.rf>
    <LM>w#w-d1t1014-11</LM>
   </w.rf>
   <form>technické</form>
   <lemma>technický</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m984-d1t1014-12">
   <w.rf>
    <LM>w#w-d1t1014-12</LM>
   </w.rf>
   <form>kontroly</form>
   <lemma>kontrola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m984-d-id89991">
   <w.rf>
    <LM>w#w-d-id89991</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1014-14">
   <w.rf>
    <LM>w#w-d1t1014-14</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t1014-15">
   <w.rf>
    <LM>w#w-d1t1014-15</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m984-d1t1016-1">
   <w.rf>
    <LM>w#w-d1t1016-1</LM>
   </w.rf>
   <form>samé</form>
   <lemma>samý</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m984-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>zkrachované</form>
   <lemma>zkrachovaný_^(*2t)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m984-d1t1019-1">
   <w.rf>
    <LM>w#w-d1t1019-1</LM>
   </w.rf>
   <form>existence</form>
   <lemma>existence</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m984-d-id90111">
   <w.rf>
    <LM>w#w-d-id90111</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1019-3">
   <w.rf>
    <LM>w#w-d1t1019-3</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m984-d1t1019-4">
   <w.rf>
    <LM>w#w-d1t1019-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m984-d1t1019-5">
   <w.rf>
    <LM>w#w-d1t1019-5</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m984-d1t1019-6">
   <w.rf>
    <LM>w#w-d1t1019-6</LM>
   </w.rf>
   <form>ministerstev</form>
   <lemma>ministerstvo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m984-d1e966-x6-2838">
   <w.rf>
    <LM>w#w-d1e966-x6-2838</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2839">
  <m id="m984-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t1021-5">
   <w.rf>
    <LM>w#w-d1t1021-5</LM>
   </w.rf>
   <form>tamní</form>
   <lemma>tamní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m984-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-3</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t1021-4">
   <w.rf>
    <LM>w#w-d1t1021-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t1023-1">
   <w.rf>
    <LM>w#w-d1t1023-1</LM>
   </w.rf>
   <form>dělnice</form>
   <lemma>dělnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d-id90317">
   <w.rf>
    <LM>w#w-d-id90317</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1023-3">
   <w.rf>
    <LM>w#w-d1t1023-3</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t1023-4">
   <w.rf>
    <LM>w#w-d1t1023-4</LM>
   </w.rf>
   <form>slušná</form>
   <lemma>slušný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m984-d1t1023-5">
   <w.rf>
    <LM>w#w-d1t1023-5</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-2839-561">
   <w.rf>
    <LM>w#w-2839-561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-562">
  <m id="m984-d1t1029-1">
   <w.rf>
    <LM>w#w-d1t1029-1</LM>
   </w.rf>
   <form>Jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m984-d1t1029-2">
   <w.rf>
    <LM>w#w-d1t1029-2</LM>
   </w.rf>
   <form>dne</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m984-d1t1029-3">
   <w.rf>
    <LM>w#w-d1t1029-3</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m984-d1t1029-4">
   <w.rf>
    <LM>w#w-d1t1029-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m984-d1t1029-5">
   <w.rf>
    <LM>w#w-d1t1029-5</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t1029-6">
   <w.rf>
    <LM>w#w-d1t1029-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t1029-7">
   <w.rf>
    <LM>w#w-d1t1029-7</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-2839-2854">
   <w.rf>
    <LM>w#w-2839-2854</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-2839-2855">
   <w.rf>
    <LM>w#w-2839-2855</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1032-1">
   <w.rf>
    <LM>w#w-d1t1032-1</LM>
   </w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m984-d1t1032-2">
   <w.rf>
    <LM>w#w-d1t1032-2</LM>
   </w.rf>
   <form>Zochovická</form>
   <lemma>Zochovická_;Y</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m984-d-id90574">
   <w.rf>
    <LM>w#w-d-id90574</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1032-4">
   <w.rf>
    <LM>w#w-d1t1032-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m984-d1t1032-5">
   <w.rf>
    <LM>w#w-d1t1032-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m984-d1t1032-6">
   <w.rf>
    <LM>w#w-d1t1032-6</LM>
   </w.rf>
   <form>provedla</form>
   <lemma>provést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-2839-2858">
   <w.rf>
    <LM>w#w-2839-2858</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id90622">
   <w.rf>
    <LM>w#w-d-id90622</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2859">
  <m id="m984-2859-567">
   <w.rf>
    <LM>w#w-2859-567</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-2859-568">
   <w.rf>
    <LM>w#w-2859-568</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1032-12">
   <w.rf>
    <LM>w#w-d1t1032-12</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1032-14">
   <w.rf>
    <LM>w#w-d1t1032-14</LM>
   </w.rf>
   <form>Nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m984-d1t1032-13">
   <w.rf>
    <LM>w#w-d1t1032-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1032-15">
   <w.rf>
    <LM>w#w-d1t1032-15</LM>
   </w.rf>
   <form>neprovedla</form>
   <lemma>provést</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m984-2859-2872">
   <w.rf>
    <LM>w#w-2859-2872</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-2875">
  <m id="m984-d1t1032-17">
   <w.rf>
    <LM>w#w-d1t1032-17</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t1032-18">
   <w.rf>
    <LM>w#w-d1t1032-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m984-d1t1032-19">
   <w.rf>
    <LM>w#w-d1t1032-19</LM>
   </w.rf>
   <form>ptáte</form>
   <lemma>ptát</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m984-d-id90790">
   <w.rf>
    <LM>w#w-d-id90790</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-2859-2871">
   <w.rf>
    <LM>w#w-2859-2871</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x7">
  <m id="m984-d1e966-x7-2923">
   <w.rf>
    <LM>w#w-d1e966-x7-2923</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m984-d1t1036-3">
   <w.rf>
    <LM>w#w-d1t1036-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m984-d1t1036-4">
   <w.rf>
    <LM>w#w-d1t1036-4</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m984-d1t1036-5">
   <w.rf>
    <LM>w#w-d1t1036-5</LM>
   </w.rf>
   <form>bezpečák</form>
   <lemma>bezpečák_,l</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m984-d1t1036-6">
   <w.rf>
    <LM>w#w-d1t1036-6</LM>
   </w.rf>
   <form>Prech</form>
   <lemma>Prech_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m984-d-id90916">
   <w.rf>
    <LM>w#w-d-id90916</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1036-8">
   <w.rf>
    <LM>w#w-d1t1036-8</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m984-d1t1036-9">
   <w.rf>
    <LM>w#w-d1t1036-9</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m984-d1t1036-10">
   <w.rf>
    <LM>w#w-d1t1036-10</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t1038-1">
   <w.rf>
    <LM>w#w-d1t1038-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t1038-2">
   <w.rf>
    <LM>w#w-d1t1038-2</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m984-d1t1038-3">
   <w.rf>
    <LM>w#w-d1t1038-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m984-d1t1038-4">
   <w.rf>
    <LM>w#w-d1t1038-4</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m984-d1t1038-5">
   <w.rf>
    <LM>w#w-d1t1038-5</LM>
   </w.rf>
   <form>podávala</form>
   <lemma>podávat_^(*4at)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t1038-6">
   <w.rf>
    <LM>w#w-d1t1038-6</LM>
   </w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m984-d-id91066">
   <w.rf>
    <LM>w#w-d-id91066</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x8">
  <m id="m984-d1t1042-6">
   <w.rf>
    <LM>w#w-d1t1042-6</LM>
   </w.rf>
   <form>Zamítla</form>
   <lemma>zamítnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m984-d1t1042-3">
   <w.rf>
    <LM>w#w-d1t1042-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1t1042-5">
   <w.rf>
    <LM>w#w-d1t1042-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m984-d-id91192">
   <w.rf>
    <LM>w#w-d-id91192</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1042-8">
   <w.rf>
    <LM>w#w-d1t1042-8</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d1e966-x8-592">
   <w.rf>
    <LM>w#w-d1e966-x8-592</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e966-x8-593">
   <w.rf>
    <LM>w#w-d1e966-x8-593</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1042-9">
   <w.rf>
    <LM>w#w-d1t1042-9</LM>
   </w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m984-d1t1042-10">
   <w.rf>
    <LM>w#w-d1t1042-10</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m984-d1t1042-11">
   <w.rf>
    <LM>w#w-d1t1042-11</LM>
   </w.rf>
   <form>nedělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m984-d1e966-x8-594">
   <w.rf>
    <LM>w#w-d1e966-x8-594</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d-id91250">
   <w.rf>
    <LM>w#w-d-id91250</LM>
   </w.rf>
   <form>'</form>
   <lemma>'</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e966-x7-2925">
   <w.rf>
    <LM>w#w-d1e966-x7-2925</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-d1e966-x9">
  <m id="m984-d1t1047-5">
   <w.rf>
    <LM>w#w-d1t1047-5</LM>
   </w.rf>
   <form>Zjistila</form>
   <lemma>zjistit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m984-d1t1047-4">
   <w.rf>
    <LM>w#w-d1t1047-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m984-d-id91353">
   <w.rf>
    <LM>w#w-d-id91353</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1e966-x9-607">
   <w.rf>
    <LM>w#w-d1e966-x9-607</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m984-d1t1047-7">
   <w.rf>
    <LM>w#w-d1t1047-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m984-d1t1047-8">
   <w.rf>
    <LM>w#w-d1t1047-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m984-d1t1047-9">
   <w.rf>
    <LM>w#w-d1t1047-9</LM>
   </w.rf>
   <form>slušná</form>
   <lemma>slušný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m984-d1t1047-10">
   <w.rf>
    <LM>w#w-d1t1047-10</LM>
   </w.rf>
   <form>ženská</form>
   <lemma>ženská_^(osoba)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1e966-x9-608">
   <w.rf>
    <LM>w#w-d1e966-x9-608</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m984-13808_04-609">
  <m id="m984-d1t1049-1">
   <w.rf>
    <LM>w#w-d1t1049-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m984-d1t1049-2">
   <w.rf>
    <LM>w#w-d1t1049-2</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m984-d1t1049-3">
   <w.rf>
    <LM>w#w-d1t1049-3</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m984-d-id91497">
   <w.rf>
    <LM>w#w-d-id91497</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1049-5">
   <w.rf>
    <LM>w#w-d1t1049-5</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m984-d1t1049-6">
   <w.rf>
    <LM>w#w-d1t1049-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m984-d1t1051-1">
   <w.rf>
    <LM>w#w-d1t1051-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m984-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m984-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m984-d1t1049-7">
   <w.rf>
    <LM>w#w-d1t1049-7</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m984-d1t1049-8">
   <w.rf>
    <LM>w#w-d1t1049-8</LM>
   </w.rf>
   <form>šplhli</form>
   <lemma>šplhnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m984-d1e966-x9-3136">
   <w.rf>
    <LM>w#w-d1e966-x9-3136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m984-d1t1053-1">
   <w.rf>
    <LM>w#w-d1t1053-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m984-d1t1053-2">
   <w.rf>
    <LM>w#w-d1t1053-2</LM>
   </w.rf>
   <form>povýšeni</form>
   <lemma>povýšit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m984-d1t1053-3">
   <w.rf>
    <LM>w#w-d1t1053-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m984-d1t1053-4">
   <w.rf>
    <LM>w#w-d1t1053-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1t1053-5">
   <w.rf>
    <LM>w#w-d1t1053-5</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m984-d1e966-x9-3137">
   <w.rf>
    <LM>w#w-d1e966-x9-3137</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
