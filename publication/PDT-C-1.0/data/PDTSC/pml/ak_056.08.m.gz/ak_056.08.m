<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_056.08.w.gz" />
  </references>
 </head>
 <s id="m056-309">
  <m id="m056-d1t2231-12">
   <w.rf>
    <LM>w#w-d1t2231-12</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2231-13">
   <w.rf>
    <LM>w#w-d1t2231-13</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2231-14">
   <w.rf>
    <LM>w#w-d1t2231-14</LM>
   </w.rf>
   <form>prázdniny</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m056-d-id122054-punct">
   <w.rf>
    <LM>w#w-d-id122054-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2231-16">
   <w.rf>
    <LM>w#w-d1t2231-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2231-17">
   <w.rf>
    <LM>w#w-d1t2231-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2231-18">
   <w.rf>
    <LM>w#w-d1t2231-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2231-20">
   <w.rf>
    <LM>w#w-d1t2231-20</LM>
   </w.rf>
   <form>Huti</form>
   <lemma>Huť_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-309-310">
   <w.rf>
    <LM>w#w-309-310</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-311">
  <m id="m056-d1t2231-24">
   <w.rf>
    <LM>w#w-d1t2231-24</LM>
   </w.rf>
   <form>Bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2231-26">
   <w.rf>
    <LM>w#w-d1t2231-26</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2231-28">
   <w.rf>
    <LM>w#w-d1t2231-28</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-d1t2231-30">
   <w.rf>
    <LM>w#w-d1t2231-30</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2231-32">
   <w.rf>
    <LM>w#w-d1t2231-32</LM>
   </w.rf>
   <form>Lochotíně</form>
   <lemma>Lochotín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m056-311-312">
   <w.rf>
    <LM>w#w-311-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-313">
  <m id="m056-d1t2231-36">
   <w.rf>
    <LM>w#w-d1t2231-36</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2231-37">
   <w.rf>
    <LM>w#w-d1t2231-37</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d-id122316-punct">
   <w.rf>
    <LM>w#w-d-id122316-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2231-39">
   <w.rf>
    <LM>w#w-d1t2231-39</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2231-40">
   <w.rf>
    <LM>w#w-d1t2231-40</LM>
   </w.rf>
   <form>přijede</form>
   <lemma>přijet</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m056-d1t2231-41">
   <w.rf>
    <LM>w#w-d1t2231-41</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t2231-43">
   <w.rf>
    <LM>w#w-d1t2231-43</LM>
   </w.rf>
   <form>Hutě</form>
   <lemma>Huť_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-313-314">
   <w.rf>
    <LM>w#w-313-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-315">
  <m id="m056-d1t2233-2">
   <w.rf>
    <LM>w#w-d1t2233-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2233-1">
   <w.rf>
    <LM>w#w-d1t2233-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2233-3">
   <w.rf>
    <LM>w#w-d1t2233-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2233-4">
   <w.rf>
    <LM>w#w-d1t2233-4</LM>
   </w.rf>
   <form>kurty</form>
   <lemma>kurt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m056-d-id122455-punct">
   <w.rf>
    <LM>w#w-d-id122455-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2233-6">
   <w.rf>
    <LM>w#w-d1t2233-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2233-7">
   <w.rf>
    <LM>w#w-d1t2233-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m056-d1t2233-8">
   <w.rf>
    <LM>w#w-d1t2233-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2233-9">
   <w.rf>
    <LM>w#w-d1t2233-9</LM>
   </w.rf>
   <form>zahraje</form>
   <lemma>zahrát</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m056-d1t2233-10">
   <w.rf>
    <LM>w#w-d1t2233-10</LM>
   </w.rf>
   <form>tenis</form>
   <lemma>tenis</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e2228-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2228-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2238-x2">
  <m id="m056-d1t2241-1">
   <w.rf>
    <LM>w#w-d1t2241-1</LM>
   </w.rf>
   <form>Hlídal</form>
   <lemma>hlídat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t2241-2">
   <w.rf>
    <LM>w#w-d1t2241-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t2241-3">
   <w.rf>
    <LM>w#w-d1t2241-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m056-d1t2241-4">
   <w.rf>
    <LM>w#w-d1t2241-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2241-5">
   <w.rf>
    <LM>w#w-d1t2241-5</LM>
   </w.rf>
   <form>prázdninách</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m056-d-id122698-punct">
   <w.rf>
    <LM>w#w-d-id122698-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2241-7">
   <w.rf>
    <LM>w#w-d1t2241-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2241-8">
   <w.rf>
    <LM>w#w-d1t2241-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t2241-9">
   <w.rf>
    <LM>w#w-d1t2241-9</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m056-d-id122753-punct">
   <w.rf>
    <LM>w#w-d-id122753-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2242-x2">
  <m id="m056-d1t2245-2">
   <w.rf>
    <LM>w#w-d1t2245-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2245-3">
   <w.rf>
    <LM>w#w-d1t2245-3</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d-id122847-punct">
   <w.rf>
    <LM>w#w-d-id122847-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2245-5">
   <w.rf>
    <LM>w#w-d1t2245-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2245-6">
   <w.rf>
    <LM>w#w-d1t2245-6</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1e2242-x2-333">
   <w.rf>
    <LM>w#w-d1e2242-x2-333</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-334">
  <m id="m056-d1t2247-5">
   <w.rf>
    <LM>w#w-d1t2247-5</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-d1t2247-3">
   <w.rf>
    <LM>w#w-d1t2247-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2247-4">
   <w.rf>
    <LM>w#w-d1t2247-4</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2247-1">
   <w.rf>
    <LM>w#w-d1t2247-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2247-2">
   <w.rf>
    <LM>w#w-d1t2247-2</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m056-334-335">
   <w.rf>
    <LM>w#w-334-335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-336">
  <m id="m056-d1t2249-1">
   <w.rf>
    <LM>w#w-d1t2249-1</LM>
   </w.rf>
   <form>Vykládal</form>
   <lemma>vykládat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t2249-2">
   <w.rf>
    <LM>w#w-d1t2249-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2249-3">
   <w.rf>
    <LM>w#w-d1t2249-3</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m056-d1t2249-5">
   <w.rf>
    <LM>w#w-d1t2249-5</LM>
   </w.rf>
   <form>pověsti</form>
   <lemma>pověst</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m056-336-338">
   <w.rf>
    <LM>w#w-336-338</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2249-6">
   <w.rf>
    <LM>w#w-d1t2249-6</LM>
   </w.rf>
   <form>O</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2249-7">
   <w.rf>
    <LM>w#w-d1t2249-7</LM>
   </w.rf>
   <form>Čertovu</form>
   <lemma>čertův_^(*2)</lemma>
   <tag>AUIS6M--------1</tag>
  </m>
  <m id="m056-d1t2259-1">
   <w.rf>
    <LM>w#w-d1t2259-1</LM>
   </w.rf>
   <form>kameni</form>
   <lemma>kámen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m056-d1t2259-2">
   <w.rf>
    <LM>w#w-d1t2259-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2259-3">
   <w.rf>
    <LM>w#w-d1t2259-3</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m056-d-m-d1e2250-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2250-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2263-x2">
  <m id="m056-d1t2282-1">
   <w.rf>
    <LM>w#w-d1t2282-1</LM>
   </w.rf>
   <form>Poučoval</form>
   <lemma>poučovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d1t2274-2">
   <w.rf>
    <LM>w#w-d1t2274-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2274-3">
   <w.rf>
    <LM>w#w-d1t2274-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m056-d-m-d1e2263-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2263-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2283-x2">
  <m id="m056-d1t2286-1">
   <w.rf>
    <LM>w#w-d1t2286-1</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2286-2">
   <w.rf>
    <LM>w#w-d1t2286-2</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m056-d1t2286-3">
   <w.rf>
    <LM>w#w-d1t2286-3</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e2283-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2283-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2287-x2">
  <m id="m056-d1t2290-2">
   <w.rf>
    <LM>w#w-d1t2290-2</LM>
   </w.rf>
   <form>Snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2290-3">
   <w.rf>
    <LM>w#w-d1t2290-3</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1e2287-x2-348">
   <w.rf>
    <LM>w#w-d1e2287-x2-348</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-349">
  <m id="m056-d1t2292-12">
   <w.rf>
    <LM>w#w-d1t2292-12</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-349-350">
   <w.rf>
    <LM>w#w-349-350</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2292-3">
   <w.rf>
    <LM>w#w-d1t2292-3</LM>
   </w.rf>
   <form>pocházím</form>
   <lemma>pocházet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2292-4">
   <w.rf>
    <LM>w#w-d1t2292-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t2292-5">
   <w.rf>
    <LM>w#w-d1t2292-5</LM>
   </w.rf>
   <form>učitelské</form>
   <lemma>učitelský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m056-d1t2292-6">
   <w.rf>
    <LM>w#w-d1t2292-6</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-d1t2292-7">
   <w.rf>
    <LM>w#w-d1t2292-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2292-9">
   <w.rf>
    <LM>w#w-d1t2292-9</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m056-d1t2292-10">
   <w.rf>
    <LM>w#w-d1t2292-10</LM>
   </w.rf>
   <form>poučuju</form>
   <lemma>poučovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-349-352">
   <w.rf>
    <LM>w#w-349-352</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2306-1">
   <w.rf>
    <LM>w#w-d1t2306-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2310-1">
   <w.rf>
    <LM>w#w-d1t2310-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2310-2">
   <w.rf>
    <LM>w#w-d1t2310-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m056-d1t2310-4">
   <w.rf>
    <LM>w#w-d1t2310-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2310-3">
   <w.rf>
    <LM>w#w-d1t2310-3</LM>
   </w.rf>
   <form>poučoval</form>
   <lemma>poučovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-d-m-d1e2303-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2303-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2311-x2">
  <m id="m056-d1t2314-1">
   <w.rf>
    <LM>w#w-d1t2314-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m056-d1t2314-2">
   <w.rf>
    <LM>w#w-d1t2314-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t2314-3">
   <w.rf>
    <LM>w#w-d1t2314-3</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2314-4">
   <w.rf>
    <LM>w#w-d1t2314-4</LM>
   </w.rf>
   <form>vnoučat</form>
   <lemma>vnouče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m056-d-id124181-punct">
   <w.rf>
    <LM>w#w-d-id124181-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2315-x2">
  <m id="m056-d1t2318-1">
   <w.rf>
    <LM>w#w-d1t2318-1</LM>
   </w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m056-d1e2315-x2-360">
   <w.rf>
    <LM>w#w-d1e2315-x2-360</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-361">
  <m id="m056-d1t2322-1">
   <w.rf>
    <LM>w#w-d1t2322-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2322-3">
   <w.rf>
    <LM>w#w-d1t2322-3</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t2322-4">
   <w.rf>
    <LM>w#w-d1t2322-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2322-5">
   <w.rf>
    <LM>w#w-d1t2322-5</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d1t2322-7">
   <w.rf>
    <LM>w#w-d1t2322-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2322-8">
   <w.rf>
    <LM>w#w-d1t2322-8</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m056-d1t2322-9">
   <w.rf>
    <LM>w#w-d1t2322-9</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2322-10">
   <w.rf>
    <LM>w#w-d1t2322-10</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m056-361-364">
   <w.rf>
    <LM>w#w-361-364</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-365">
  <m id="m056-d1t2324-1">
   <w.rf>
    <LM>w#w-d1t2324-1</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m056-d1t2324-2">
   <w.rf>
    <LM>w#w-d1t2324-2</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m056-365-366">
   <w.rf>
    <LM>w#w-365-366</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2324-3">
   <w.rf>
    <LM>w#w-d1t2324-3</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m056-365-367">
   <w.rf>
    <LM>w#w-365-367</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-368">
  <m id="m056-d1t2326-1">
   <w.rf>
    <LM>w#w-d1t2326-1</LM>
   </w.rf>
   <form>Dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m056-d1t2326-2">
   <w.rf>
    <LM>w#w-d1t2326-2</LM>
   </w.rf>
   <form>vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m056-368-369">
   <w.rf>
    <LM>w#w-368-369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-370">
  <m id="m056-d1t2329-11">
   <w.rf>
    <LM>w#w-d1t2329-11</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m056-d1t2329-12">
   <w.rf>
    <LM>w#w-d1t2329-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2329-14">
   <w.rf>
    <LM>w#w-d1t2329-14</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-d1t2329-10">
   <w.rf>
    <LM>w#w-d1t2329-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2329-7">
   <w.rf>
    <LM>w#w-d1t2329-7</LM>
   </w.rf>
   <form>studuje</form>
   <lemma>studovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2329-8">
   <w.rf>
    <LM>w#w-d1t2329-8</LM>
   </w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m056-d1t2329-9">
   <w.rf>
    <LM>w#w-d1t2329-9</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m056-d1t2329-17">
   <w.rf>
    <LM>w#w-d1t2329-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2329-18">
   <w.rf>
    <LM>w#w-d1t2329-18</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2329-19">
   <w.rf>
    <LM>w#w-d1t2329-19</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m056-d1t2329-20">
   <w.rf>
    <LM>w#w-d1t2329-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2329-21">
   <w.rf>
    <LM>w#w-d1t2329-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2329-22">
   <w.rf>
    <LM>w#w-d1t2329-22</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2329-23">
   <w.rf>
    <LM>w#w-d1t2329-23</LM>
   </w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m056-d1t2329-24">
   <w.rf>
    <LM>w#w-d1t2329-24</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-d-m-d1e2315-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2315-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2334-x2">
  <m id="m056-d1t2337-2">
   <w.rf>
    <LM>w#w-d1t2337-2</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m056-d1t2337-3">
   <w.rf>
    <LM>w#w-d1t2337-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t2337-4">
   <w.rf>
    <LM>w#w-d1t2337-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m056-d1t2337-5">
   <w.rf>
    <LM>w#w-d1t2337-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d-id125048-punct">
   <w.rf>
    <LM>w#w-d-id125048-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2338-x2">
  <m id="m056-d1t2341-5">
   <w.rf>
    <LM>w#w-d1t2341-5</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1e2338-x2-376">
   <w.rf>
    <LM>w#w-d1e2338-x2-376</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2343-1">
   <w.rf>
    <LM>w#w-d1t2343-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2343-2">
   <w.rf>
    <LM>w#w-d1t2343-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m056-d1e2338-x2-377">
   <w.rf>
    <LM>w#w-d1e2338-x2-377</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-379">
  <m id="m056-d1t2345-1">
   <w.rf>
    <LM>w#w-d1t2345-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m056-d1t2345-2">
   <w.rf>
    <LM>w#w-d1t2345-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2345-4">
   <w.rf>
    <LM>w#w-d1t2345-4</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-379-386">
   <w.rf>
    <LM>w#w-379-386</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2355-1">
   <w.rf>
    <LM>w#w-d1t2355-1</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t2355-2">
   <w.rf>
    <LM>w#w-d1t2355-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2355-4">
   <w.rf>
    <LM>w#w-d1t2355-4</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t2360-1">
   <w.rf>
    <LM>w#w-d1t2360-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2360-2">
   <w.rf>
    <LM>w#w-d1t2360-2</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t2360-3">
   <w.rf>
    <LM>w#w-d1t2360-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2360-5">
   <w.rf>
    <LM>w#w-d1t2360-5</LM>
   </w.rf>
   <form>Jirka</form>
   <lemma>Jirka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1e2357-x2-395">
   <w.rf>
    <LM>w#w-d1e2357-x2-395</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-397">
  <m id="m056-d1t2366-6">
   <w.rf>
    <LM>w#w-d1t2366-6</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m056-d1t2366-5">
   <w.rf>
    <LM>w#w-d1t2366-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2366-1">
   <w.rf>
    <LM>w#w-d1t2366-1</LM>
   </w.rf>
   <form>svatý</form>
   <lemma>svatý-1</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m056-d1t2366-3">
   <w.rf>
    <LM>w#w-d1t2366-3</LM>
   </w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-397-401">
   <w.rf>
    <LM>w#w-397-401</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2372-x2">
  <m id="m056-d1t2377-1">
   <w.rf>
    <LM>w#w-d1t2377-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2377-2">
   <w.rf>
    <LM>w#w-d1t2377-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t2377-3">
   <w.rf>
    <LM>w#w-d1t2377-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-d1t2377-4">
   <w.rf>
    <LM>w#w-d1t2377-4</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2383-1">
   <w.rf>
    <LM>w#w-d1t2383-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2383-2">
   <w.rf>
    <LM>w#w-d1t2383-2</LM>
   </w.rf>
   <form>nějakém</form>
   <lemma>nějaký</lemma>
   <tag>PZZS6----------</tag>
  </m>
  <m id="m056-d1t2383-3">
   <w.rf>
    <LM>w#w-d1t2383-3</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m056-d-id126003-punct">
   <w.rf>
    <LM>w#w-d-id126003-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2384-x2">
  <m id="m056-d1t2387-2">
   <w.rf>
    <LM>w#w-d1t2387-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1e2384-x2-425">
   <w.rf>
    <LM>w#w-d1e2384-x2-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-426">
  <m id="m056-d1t2387-5">
   <w.rf>
    <LM>w#w-d1t2387-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2387-6">
   <w.rf>
    <LM>w#w-d1t2387-6</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2387-7">
   <w.rf>
    <LM>w#w-d1t2387-7</LM>
   </w.rf>
   <form>autem</form>
   <lemma>auto</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m056-426-427">
   <w.rf>
    <LM>w#w-426-427</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-428">
  <m id="m056-d1t2387-9">
   <w.rf>
    <LM>w#w-d1t2387-9</LM>
   </w.rf>
   <form>Jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2387-10">
   <w.rf>
    <LM>w#w-d1t2387-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2387-11">
   <w.rf>
    <LM>w#w-d1t2387-11</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m056-d1t2387-12">
   <w.rf>
    <LM>w#w-d1t2387-12</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-428-429">
   <w.rf>
    <LM>w#w-428-429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-430">
  <m id="m056-d1t2387-14">
   <w.rf>
    <LM>w#w-d1t2387-14</LM>
   </w.rf>
   <form>Pijeme</form>
   <lemma>pít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2387-16">
   <w.rf>
    <LM>w#w-d1t2387-16</LM>
   </w.rf>
   <form>léčivou</form>
   <lemma>léčivý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m056-d1t2387-15">
   <w.rf>
    <LM>w#w-d1t2387-15</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e2384-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2384-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2388-x3">
  <m id="m056-d1t2397-4">
   <w.rf>
    <LM>w#w-d1t2397-4</LM>
   </w.rf>
   <form>Přineseme</form>
   <lemma>přinést</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m056-d1t2397-2">
   <w.rf>
    <LM>w#w-d1t2397-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m056-d1t2397-3">
   <w.rf>
    <LM>w#w-d1t2397-3</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3------1</tag>
  </m>
  <m id="m056-d1t2401-1">
   <w.rf>
    <LM>w#w-d1t2401-1</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2397-1">
   <w.rf>
    <LM>w#w-d1t2397-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2397-5">
   <w.rf>
    <LM>w#w-d1t2397-5</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d-m-d1e2388-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2388-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2414-x2">
  <m id="m056-d1t2417-1">
   <w.rf>
    <LM>w#w-d1t2417-1</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m056-d1t2409-2">
   <w.rf>
    <LM>w#w-d1t2409-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2417-2">
   <w.rf>
    <LM>w#w-d1t2417-2</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2417-3">
   <w.rf>
    <LM>w#w-d1t2417-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t2417-4">
   <w.rf>
    <LM>w#w-d1t2417-4</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m056-d1t2417-5">
   <w.rf>
    <LM>w#w-d1t2417-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d-id126754-punct">
   <w.rf>
    <LM>w#w-d-id126754-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2418-x2">
  <m id="m056-d1t2421-1">
   <w.rf>
    <LM>w#w-d1t2421-1</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2421-2">
   <w.rf>
    <LM>w#w-d1t2421-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t2421-3">
   <w.rf>
    <LM>w#w-d1t2421-3</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m056-d1t2421-4">
   <w.rf>
    <LM>w#w-d1t2421-4</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-d1e2418-x2-438">
   <w.rf>
    <LM>w#w-d1e2418-x2-438</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-440">
  <m id="m056-d1t2423-4">
   <w.rf>
    <LM>w#w-d1t2423-4</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-d1t2423-2">
   <w.rf>
    <LM>w#w-d1t2423-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2423-3">
   <w.rf>
    <LM>w#w-d1t2423-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2423-1">
   <w.rf>
    <LM>w#w-d1t2423-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2423-7">
   <w.rf>
    <LM>w#w-d1t2423-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2423-8">
   <w.rf>
    <LM>w#w-d1t2423-8</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m056-d1t2423-9">
   <w.rf>
    <LM>w#w-d1t2423-9</LM>
   </w.rf>
   <form>komunistů</form>
   <lemma>komunista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m056-d1t2423-14">
   <w.rf>
    <LM>w#w-d1t2423-14</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m056-d1t2423-15">
   <w.rf>
    <LM>w#w-d1t2423-15</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m056-d1t2423-5">
   <w.rf>
    <LM>w#w-d1t2423-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2423-6">
   <w.rf>
    <LM>w#w-d1t2423-6</LM>
   </w.rf>
   <form>rekreaci</form>
   <lemma>rekreace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-440-441">
   <w.rf>
    <LM>w#w-440-441</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-443">
  <m id="m056-d1t2425-2">
   <w.rf>
    <LM>w#w-d1t2425-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t2425-1">
   <w.rf>
    <LM>w#w-d1t2425-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m056-d1t2427-1">
   <w.rf>
    <LM>w#w-d1t2427-1</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m056-d1t2427-2">
   <w.rf>
    <LM>w#w-d1t2427-2</LM>
   </w.rf>
   <form>léčebná</form>
   <lemma>léčebný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m056-d1t2427-3">
   <w.rf>
    <LM>w#w-d1t2427-3</LM>
   </w.rf>
   <form>procedura</form>
   <lemma>procedura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-443-452">
   <w.rf>
    <LM>w#w-443-452</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-450">
  <m id="m056-d1t2429-6">
   <w.rf>
    <LM>w#w-d1t2429-6</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t2429-3">
   <w.rf>
    <LM>w#w-d1t2429-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t2429-4">
   <w.rf>
    <LM>w#w-d1t2429-4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m056-d1t2429-5">
   <w.rf>
    <LM>w#w-d1t2429-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2429-7">
   <w.rf>
    <LM>w#w-d1t2429-7</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m056-d-id127355-punct">
   <w.rf>
    <LM>w#w-d-id127355-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2429-9">
   <w.rf>
    <LM>w#w-d1t2429-9</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2429-10">
   <w.rf>
    <LM>w#w-d1t2429-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2429-12">
   <w.rf>
    <LM>w#w-d1t2429-12</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2429-11">
   <w.rf>
    <LM>w#w-d1t2429-11</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2429-13">
   <w.rf>
    <LM>w#w-d1t2429-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2429-14">
   <w.rf>
    <LM>w#w-d1t2429-14</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m056-d1t2429-15">
   <w.rf>
    <LM>w#w-d1t2429-15</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m056-450-453">
   <w.rf>
    <LM>w#w-450-453</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-454">
  <m id="m056-d1t2434-2">
   <w.rf>
    <LM>w#w-d1t2434-2</LM>
   </w.rf>
   <form>Projdeme</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m056-d1t2434-1">
   <w.rf>
    <LM>w#w-d1t2434-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m056-d1t2434-4">
   <w.rf>
    <LM>w#w-d1t2434-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m056-d1t2434-5">
   <w.rf>
    <LM>w#w-d1t2434-5</LM>
   </w.rf>
   <form>prameny</form>
   <lemma>pramen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m056-454-455">
   <w.rf>
    <LM>w#w-454-455</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-456">
  <m id="m056-d1t2438-1">
   <w.rf>
    <LM>w#w-d1t2438-1</LM>
   </w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m056-d1t2438-2">
   <w.rf>
    <LM>w#w-d1t2438-2</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2438-3">
   <w.rf>
    <LM>w#w-d1t2438-3</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP6--3-------</tag>
  </m>
  <m id="m056-d1t2438-4">
   <w.rf>
    <LM>w#w-d1t2438-4</LM>
   </w.rf>
   <form>víme</form>
   <lemma>vědět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-456-457">
   <w.rf>
    <LM>w#w-456-457</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-460">
  <m id="m056-d1t2438-10">
   <w.rf>
    <LM>w#w-d1t2438-10</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m056-d1t2438-11">
   <w.rf>
    <LM>w#w-d1t2438-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2438-13">
   <w.rf>
    <LM>w#w-d1t2438-13</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2438-12">
   <w.rf>
    <LM>w#w-d1t2438-12</LM>
   </w.rf>
   <form>přednáška</form>
   <lemma>přednáška</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m056-d-id127775-punct">
   <w.rf>
    <LM>w#w-d-id127775-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2438-23">
   <w.rf>
    <LM>w#w-d1t2438-23</LM>
   </w.rf>
   <form>profesor</form>
   <lemma>profesor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m056-d1t2438-24">
   <w.rf>
    <LM>w#w-d1t2438-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2438-26">
   <w.rf>
    <LM>w#w-d1t2438-26</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2438-27">
   <w.rf>
    <LM>w#w-d1t2438-27</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m056-d1t2438-28">
   <w.rf>
    <LM>w#w-d1t2438-28</LM>
   </w.rf>
   <form>pramenech</form>
   <lemma>pramen</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m056-d1t2438-25">
   <w.rf>
    <LM>w#w-d1t2438-25</LM>
   </w.rf>
   <form>vykládal</form>
   <lemma>vykládat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m056-460-473">
   <w.rf>
    <LM>w#w-460-473</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2438-15">
   <w.rf>
    <LM>w#w-d1t2438-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2438-16">
   <w.rf>
    <LM>w#w-d1t2438-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1t2438-18">
   <w.rf>
    <LM>w#w-d1t2438-18</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-d1t2438-19">
   <w.rf>
    <LM>w#w-d1t2438-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2438-20">
   <w.rf>
    <LM>w#w-d1t2438-20</LM>
   </w.rf>
   <form>přednášce</form>
   <lemma>přednáška</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m056-460-461">
   <w.rf>
    <LM>w#w-460-461</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-478">
  <m id="m056-d1t2438-32">
   <w.rf>
    <LM>w#w-d1t2438-32</LM>
   </w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m056-d1t2438-33">
   <w.rf>
    <LM>w#w-d1t2438-33</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m056-d1t2438-34">
   <w.rf>
    <LM>w#w-d1t2438-34</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m056-d1t2438-35">
   <w.rf>
    <LM>w#w-d1t2438-35</LM>
   </w.rf>
   <form>víme</form>
   <lemma>vědět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d1e2418-x3-474">
   <w.rf>
    <LM>w#w-d1e2418-x3-474</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-476">
  <m id="m056-d1t2438-38">
   <w.rf>
    <LM>w#w-d1t2438-38</LM>
   </w.rf>
   <form>Nechodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m056-d1t2438-39">
   <w.rf>
    <LM>w#w-d1t2438-39</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d-id128138-punct">
   <w.rf>
    <LM>w#w-d-id128138-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2438-40">
   <w.rf>
    <LM>w#w-d1t2438-40</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2438-42">
   <w.rf>
    <LM>w#w-d1t2438-42</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m056-d1t2438-43">
   <w.rf>
    <LM>w#w-d1t2438-43</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2438-44">
   <w.rf>
    <LM>w#w-d1t2438-44</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-d1t2438-45">
   <w.rf>
    <LM>w#w-d1t2438-45</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2438-46">
   <w.rf>
    <LM>w#w-d1t2438-46</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m056-476-489">
   <w.rf>
    <LM>w#w-476-489</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-486">
  <m id="m056-d1t2438-49">
   <w.rf>
    <LM>w#w-d1t2438-49</LM>
   </w.rf>
   <form>Víme</form>
   <lemma>vědět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m056-d-id128264-punct">
   <w.rf>
    <LM>w#w-d-id128264-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2438-51">
   <w.rf>
    <LM>w#w-d1t2438-51</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m056-d1t2438-52">
   <w.rf>
    <LM>w#w-d1t2438-52</LM>
   </w.rf>
   <form>pramen</form>
   <lemma>pramen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m056-d1t2438-53">
   <w.rf>
    <LM>w#w-d1t2438-53</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2438-54">
   <w.rf>
    <LM>w#w-d1t2438-54</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t2438-55">
   <w.rf>
    <LM>w#w-d1t2438-55</LM>
   </w.rf>
   <form>srdce</form>
   <lemma>srdce</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m056-d-id128344-punct">
   <w.rf>
    <LM>w#w-d-id128344-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2438-57">
   <w.rf>
    <LM>w#w-d1t2438-57</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m056-d1t2438-58">
   <w.rf>
    <LM>w#w-d1t2438-58</LM>
   </w.rf>
   <form>ledviny</form>
   <lemma>ledvina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m056-d-m-d1e2418-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2418-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2447-x2">
  <m id="m056-d1t2450-1">
   <w.rf>
    <LM>w#w-d1t2450-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t2450-2">
   <w.rf>
    <LM>w#w-d1t2450-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2450-6">
   <w.rf>
    <LM>w#w-d1t2450-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m056-d1t2450-7">
   <w.rf>
    <LM>w#w-d1t2450-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m056-d1t2450-8">
   <w.rf>
    <LM>w#w-d1t2450-8</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m056-d1t2450-3">
   <w.rf>
    <LM>w#w-d1t2450-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1e2447-x2-131">
   <w.rf>
    <LM>w#w-d1e2447-x2-131</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m056-d1e2447-x2-132">
   <w.rf>
    <LM>w#w-d1e2447-x2-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-143">
  <m id="m056-d1e2447-x2-508">
   <w.rf>
    <LM>w#w-d1e2447-x2-508</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m056-d1e2447-x2-509">
   <w.rf>
    <LM>w#w-d1e2447-x2-509</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2461-1">
   <w.rf>
    <LM>w#w-d1t2461-1</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m056-d1t2461-2">
   <w.rf>
    <LM>w#w-d1t2461-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m056-d1t2461-3">
   <w.rf>
    <LM>w#w-d1t2461-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m056-d1t2461-4">
   <w.rf>
    <LM>w#w-d1t2461-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m056-d1t2461-5">
   <w.rf>
    <LM>w#w-d1t2461-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m056-d1e2447-x2-507">
   <w.rf>
    <LM>w#w-d1e2447-x2-507</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1e2447-x2-510">
   <w.rf>
    <LM>w#w-d1e2447-x2-510</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m056-d-m-d1e2454-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2454-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2454-x2">
  <m id="m056-d1t2459-1">
   <w.rf>
    <LM>w#w-d1t2459-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d-m-d1e2454-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2454-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2462-x2">
  <m id="m056-d1t2465-1">
   <w.rf>
    <LM>w#w-d1t2465-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m056-d1t2465-2">
   <w.rf>
    <LM>w#w-d1t2465-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2465-4">
   <w.rf>
    <LM>w#w-d1t2465-4</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d-id128932-punct">
   <w.rf>
    <LM>w#w-d-id128932-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1e2462-x2-521">
   <w.rf>
    <LM>w#w-d1e2462-x2-521</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m056-d1t2465-6">
   <w.rf>
    <LM>w#w-d1t2465-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2465-7">
   <w.rf>
    <LM>w#w-d1t2465-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2465-8">
   <w.rf>
    <LM>w#w-d1t2465-8</LM>
   </w.rf>
   <form>krásně</form>
   <lemma>krásně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1e2462-x2-522">
   <w.rf>
    <LM>w#w-d1e2462-x2-522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-523">
  <m id="m056-d1t2467-5">
   <w.rf>
    <LM>w#w-d1t2467-5</LM>
   </w.rf>
   <form>Vary</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m056-d1t2467-8">
   <w.rf>
    <LM>w#w-d1t2467-8</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m056-d1t2467-9">
   <w.rf>
    <LM>w#w-d1t2467-9</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m056-523-524">
   <w.rf>
    <LM>w#w-523-524</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-525">
  <m id="m056-d1t2467-13">
   <w.rf>
    <LM>w#w-d1t2467-13</LM>
   </w.rf>
   <form>Vary</form>
   <lemma>Vary_;G_^(Karlovy_Vary)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m056-525-526">
   <w.rf>
    <LM>w#w-525-526</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m056-d1t2467-15">
   <w.rf>
    <LM>w#w-d1t2467-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m056-d1t2467-16">
   <w.rf>
    <LM>w#w-d1t2467-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2467-17">
   <w.rf>
    <LM>w#w-d1t2467-17</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m056-525-527">
   <w.rf>
    <LM>w#w-525-527</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-528">
  <m id="m056-d1t2467-20">
   <w.rf>
    <LM>w#w-d1t2467-20</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2467-19">
   <w.rf>
    <LM>w#w-d1t2467-19</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2467-21">
   <w.rf>
    <LM>w#w-d1t2467-21</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t2467-22">
   <w.rf>
    <LM>w#w-d1t2467-22</LM>
   </w.rf>
   <form>lidu</form>
   <lemma>lid_^(naší_země)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m056-528-529">
   <w.rf>
    <LM>w#w-528-529</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-530">
  <m id="m056-d1t2467-24">
   <w.rf>
    <LM>w#w-d1t2467-24</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2467-26">
   <w.rf>
    <LM>w#w-d1t2467-26</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2469-1">
   <w.rf>
    <LM>w#w-d1t2469-1</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t2469-2">
   <w.rf>
    <LM>w#w-d1t2469-2</LM>
   </w.rf>
   <form>sady</form>
   <lemma>sada</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m056-d1t2469-3">
   <w.rf>
    <LM>w#w-d1t2469-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m056-d1t2471-1">
   <w.rf>
    <LM>w#w-d1t2471-1</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m056-d1t2471-2">
   <w.rf>
    <LM>w#w-d1t2471-2</LM>
   </w.rf>
   <form>zeleně</form>
   <lemma>zeleň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m056-530-531">
   <w.rf>
    <LM>w#w-530-531</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-532">
  <m id="m056-d1t2471-8">
   <w.rf>
    <LM>w#w-d1t2471-8</LM>
   </w.rf>
   <form>Mariánské</form>
   <lemma>mariánský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m056-d1t2471-9">
   <w.rf>
    <LM>w#w-d1t2471-9</LM>
   </w.rf>
   <form>Lázně</form>
   <lemma>lázně</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m056-d1t2471-11">
   <w.rf>
    <LM>w#w-d1t2471-11</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2471-12">
   <w.rf>
    <LM>w#w-d1t2471-12</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m056-532-533">
   <w.rf>
    <LM>w#w-532-533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-535">
  <m id="m056-d1t2473-1">
   <w.rf>
    <LM>w#w-d1t2473-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d1t2473-2">
   <w.rf>
    <LM>w#w-d1t2473-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2473-3">
   <w.rf>
    <LM>w#w-d1t2473-3</LM>
   </w.rf>
   <form>draho</form>
   <lemma>draho</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d-m-d1e2462-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2462-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m056-d1e2474-x2">
  <m id="m056-d1t2479-1">
   <w.rf>
    <LM>w#w-d1t2479-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m056-d1t2479-2">
   <w.rf>
    <LM>w#w-d1t2479-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m056-d1t2479-3">
   <w.rf>
    <LM>w#w-d1t2479-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m056-d1t2485-1">
   <w.rf>
    <LM>w#w-d1t2485-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m056-d1t2485-2">
   <w.rf>
    <LM>w#w-d1t2485-2</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m056-d1t2485-3">
   <w.rf>
    <LM>w#w-d1t2485-3</LM>
   </w.rf>
   <form>líbí</form>
   <lemma>líbit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m056-d-id129811-punct">
   <w.rf>
    <LM>w#w-d-id129811-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
