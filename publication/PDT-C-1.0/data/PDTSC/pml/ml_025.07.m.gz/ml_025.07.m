<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_025.07.w.gz" />
  </references>
 </head>
 <s id="m025-d1e2664-x2">
  <m id="m025-d1t2667-1">
   <w.rf>
    <LM>w#w-d1t2667-1</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2667-2">
   <w.rf>
    <LM>w#w-d1t2667-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m025-d1t2667-3">
   <w.rf>
    <LM>w#w-d1t2667-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2667-4">
   <w.rf>
    <LM>w#w-d1t2667-4</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m025-d1t2667-5">
   <w.rf>
    <LM>w#w-d1t2667-5</LM>
   </w.rf>
   <form>nelákalo</form>
   <lemma>lákat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m025-d-id123304-punct">
   <w.rf>
    <LM>w#w-d-id123304-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2668-x2">
  <m id="m025-d1t2673-1">
   <w.rf>
    <LM>w#w-d1t2673-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1e2668-x2-712">
   <w.rf>
    <LM>w#w-d1e2668-x2-712</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2673-2">
   <w.rf>
    <LM>w#w-d1t2673-2</LM>
   </w.rf>
   <form>nelákalo</form>
   <lemma>lákat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m025-d-m-d1e2668-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2668-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2674-x2">
  <m id="m025-d1t2677-1">
   <w.rf>
    <LM>w#w-d1t2677-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2677-2">
   <w.rf>
    <LM>w#w-d1t2677-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t2677-3">
   <w.rf>
    <LM>w#w-d1t2677-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m025-d1e2674-x2-718">
   <w.rf>
    <LM>w#w-d1e2674-x2-718</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-720">
  <m id="m025-d1t2679-1">
   <w.rf>
    <LM>w#w-d1t2679-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m025-d1t2679-2">
   <w.rf>
    <LM>w#w-d1t2679-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t2679-3">
   <w.rf>
    <LM>w#w-d1t2679-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m025-d1t2679-4">
   <w.rf>
    <LM>w#w-d1t2679-4</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d-id123583-punct">
   <w.rf>
    <LM>w#w-d-id123583-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2679-6">
   <w.rf>
    <LM>w#w-d1t2679-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m025-d1t2679-7">
   <w.rf>
    <LM>w#w-d1t2679-7</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2679-8">
   <w.rf>
    <LM>w#w-d1t2679-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2679-9">
   <w.rf>
    <LM>w#w-d1t2679-9</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m025-d1t2679-10">
   <w.rf>
    <LM>w#w-d1t2679-10</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m025-d-id123669-punct">
   <w.rf>
    <LM>w#w-d-id123669-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2680-x2">
  <m id="m025-d1t2685-2">
   <w.rf>
    <LM>w#w-d1t2685-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m025-d1t2685-3">
   <w.rf>
    <LM>w#w-d1t2685-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2685-5">
   <w.rf>
    <LM>w#w-d1t2685-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t2685-4">
   <w.rf>
    <LM>w#w-d1t2685-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2685-6">
   <w.rf>
    <LM>w#w-d1t2685-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2685-8">
   <w.rf>
    <LM>w#w-d1t2685-8</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m025-d1e2680-x2-728">
   <w.rf>
    <LM>w#w-d1e2680-x2-728</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-730">
  <m id="m025-d1t2687-1">
   <w.rf>
    <LM>w#w-d1t2687-1</LM>
   </w.rf>
   <form>Vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2687-2">
   <w.rf>
    <LM>w#w-d1t2687-2</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-730-732">
   <w.rf>
    <LM>w#w-730-732</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2687-3">
   <w.rf>
    <LM>w#w-d1t2687-3</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m025-d1t2687-4">
   <w.rf>
    <LM>w#w-d1t2687-4</LM>
   </w.rf>
   <form>věc</form>
   <lemma>věc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m025-d1t2687-5">
   <w.rf>
    <LM>w#w-d1t2687-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t2687-6">
   <w.rf>
    <LM>w#w-d1t2687-6</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d-id123959-punct">
   <w.rf>
    <LM>w#w-d-id123959-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2689-1">
   <w.rf>
    <LM>w#w-d1t2689-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2689-2">
   <w.rf>
    <LM>w#w-d1t2689-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2689-3">
   <w.rf>
    <LM>w#w-d1t2689-3</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m025-d1t2691-1">
   <w.rf>
    <LM>w#w-d1t2691-1</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m025-d1t2691-5">
   <w.rf>
    <LM>w#w-d1t2691-5</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2697-1">
   <w.rf>
    <LM>w#w-d1t2697-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2697-2">
   <w.rf>
    <LM>w#w-d1t2697-2</LM>
   </w.rf>
   <form>tmě</form>
   <lemma>tma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2691-3">
   <w.rf>
    <LM>w#w-d1t2691-3</LM>
   </w.rf>
   <form>bobříka</form>
   <lemma>bobřík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m025-d1t2691-4">
   <w.rf>
    <LM>w#w-d1t2691-4</LM>
   </w.rf>
   <form>odvahy</form>
   <lemma>odvaha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2680-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2680-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2692-x2">
  <m id="m025-d1t2711-4">
   <w.rf>
    <LM>w#w-d1t2711-4</LM>
   </w.rf>
   <form>Strašili</form>
   <lemma>strašit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m025-d1t2711-2">
   <w.rf>
    <LM>w#w-d1t2711-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2711-3">
   <w.rf>
    <LM>w#w-d1t2711-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m025-d1t2699-1">
   <w.rf>
    <LM>w#w-d1t2699-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2699-2">
   <w.rf>
    <LM>w#w-d1t2699-2</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m025-d1t2699-3">
   <w.rf>
    <LM>w#w-d1t2699-3</LM>
   </w.rf>
   <form>maskách</form>
   <lemma>maska</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m025-d-id124542-punct">
   <w.rf>
    <LM>w#w-d-id124542-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2709-1">
   <w.rf>
    <LM>w#w-d1t2709-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m025-d1t2709-2">
   <w.rf>
    <LM>w#w-d1t2709-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2709-3">
   <w.rf>
    <LM>w#w-d1t2709-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t2709-5">
   <w.rf>
    <LM>w#w-d1t2709-5</LM>
   </w.rf>
   <form>udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m025-d1e2692-x2-754">
   <w.rf>
    <LM>w#w-d1e2692-x2-754</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2711-7">
   <w.rf>
    <LM>w#w-d1t2711-7</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2711-8">
   <w.rf>
    <LM>w#w-d1t2711-8</LM>
   </w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m025-d1t2711-9">
   <w.rf>
    <LM>w#w-d1t2711-9</LM>
   </w.rf>
   <form>bobříka</form>
   <lemma>bobřík</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m025-d1t2711-10">
   <w.rf>
    <LM>w#w-d1t2711-10</LM>
   </w.rf>
   <form>odvahy</form>
   <lemma>odvaha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2704-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2704-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2714-x2">
  <m id="m025-d1t2719-1">
   <w.rf>
    <LM>w#w-d1t2719-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2719-2">
   <w.rf>
    <LM>w#w-d1t2719-2</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m025-d1t2719-3">
   <w.rf>
    <LM>w#w-d1t2719-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m025-d1t2719-4">
   <w.rf>
    <LM>w#w-d1t2719-4</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m025-d1e2714-x2-758">
   <w.rf>
    <LM>w#w-d1e2714-x2-758</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2720-x2">
  <m id="m025-d1t2723-1">
   <w.rf>
    <LM>w#w-d1t2723-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1e2720-x2-760">
   <w.rf>
    <LM>w#w-d1e2720-x2-760</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2723-2">
   <w.rf>
    <LM>w#w-d1t2723-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m025-d1t2723-3">
   <w.rf>
    <LM>w#w-d1t2723-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2723-4">
   <w.rf>
    <LM>w#w-d1t2723-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m025-d1t2723-6">
   <w.rf>
    <LM>w#w-d1t2723-6</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m025-d1t2723-5">
   <w.rf>
    <LM>w#w-d1t2723-5</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2720-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2720-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2726-x2">
  <m id="m025-d1t2729-1">
   <w.rf>
    <LM>w#w-d1t2729-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m025-d1e2726-x2-484">
   <w.rf>
    <LM>w#w-d1e2726-x2-484</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-486">
  <m id="m025-d1t2729-5">
   <w.rf>
    <LM>w#w-d1t2729-5</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m025-d1t2729-4">
   <w.rf>
    <LM>w#w-d1t2729-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2729-6">
   <w.rf>
    <LM>w#w-d1t2729-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2729-7">
   <w.rf>
    <LM>w#w-d1t2729-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m025-d1t2729-8">
   <w.rf>
    <LM>w#w-d1t2729-8</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m025-d1e2726-x2-768">
   <w.rf>
    <LM>w#w-d1e2726-x2-768</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-770">
  <m id="m025-d1t2729-10">
   <w.rf>
    <LM>w#w-d1t2729-10</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m025-d1t2729-11">
   <w.rf>
    <LM>w#w-d1t2729-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2729-13">
   <w.rf>
    <LM>w#w-d1t2729-13</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2729-12">
   <w.rf>
    <LM>w#w-d1t2729-12</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d-id125137-punct">
   <w.rf>
    <LM>w#w-d-id125137-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2731-x2">
  <m id="m025-d1t2742-4">
   <w.rf>
    <LM>w#w-d1t2742-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2742-3">
   <w.rf>
    <LM>w#w-d1t2742-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2742-5">
   <w.rf>
    <LM>w#w-d1t2742-5</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m025-d1t2742-6">
   <w.rf>
    <LM>w#w-d1t2742-6</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m025-d1t2742-7">
   <w.rf>
    <LM>w#w-d1t2742-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m025-d1e2731-x2-814">
   <w.rf>
    <LM>w#w-d1e2731-x2-814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-812">
  <m id="m025-d1t2749-1">
   <w.rf>
    <LM>w#w-d1t2749-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2749-2">
   <w.rf>
    <LM>w#w-d1t2749-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2751-5">
   <w.rf>
    <LM>w#w-d1t2751-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2751-6">
   <w.rf>
    <LM>w#w-d1t2751-6</LM>
   </w.rf>
   <form>58</form>
   <lemma>58</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m025-d1t2751-7">
   <w.rf>
    <LM>w#w-d1t2751-7</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m025-d1t2749-3">
   <w.rf>
    <LM>w#w-d1t2749-3</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m025-d1t2749-4">
   <w.rf>
    <LM>w#w-d1t2749-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2749-5">
   <w.rf>
    <LM>w#w-d1t2749-5</LM>
   </w.rf>
   <form>ČD</form>
   <lemma>ČD-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m025-d1t2751-1">
   <w.rf>
    <LM>w#w-d1t2751-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2751-3">
   <w.rf>
    <LM>w#w-d1t2751-3</LM>
   </w.rf>
   <form>sociální</form>
   <lemma>sociální</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m025-d1t2751-4">
   <w.rf>
    <LM>w#w-d1t2751-4</LM>
   </w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d-id125684-punct">
   <w.rf>
    <LM>w#w-d-id125684-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2755-1">
   <w.rf>
    <LM>w#w-d1t2755-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2755-2">
   <w.rf>
    <LM>w#w-d1t2755-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2755-3">
   <w.rf>
    <LM>w#w-d1t2755-3</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2755-4">
   <w.rf>
    <LM>w#w-d1t2755-4</LM>
   </w.rf>
   <form>dodělat</form>
   <lemma>dodělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m025-d1t2758-1">
   <w.rf>
    <LM>w#w-d1t2758-1</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m025-d1t2758-2">
   <w.rf>
    <LM>w#w-d1t2758-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m025-d1t2760-1">
   <w.rf>
    <LM>w#w-d1t2760-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2760-2">
   <w.rf>
    <LM>w#w-d1t2760-2</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m025-812-880">
   <w.rf>
    <LM>w#w-812-880</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-881">
  <m id="m025-d1t2762-5">
   <w.rf>
    <LM>w#w-d1t2762-5</LM>
   </w.rf>
   <form>Dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2762-4">
   <w.rf>
    <LM>w#w-d1t2762-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2764-1">
   <w.rf>
    <LM>w#w-d1t2764-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m025-d1t2764-3">
   <w.rf>
    <LM>w#w-d1t2764-3</LM>
   </w.rf>
   <form>Škodovce</form>
   <lemma>Škodovka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2764-5">
   <w.rf>
    <LM>w#w-d1t2764-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2764-6">
   <w.rf>
    <LM>w#w-d1t2764-6</LM>
   </w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m025-d1t2764-7">
   <w.rf>
    <LM>w#w-d1t2764-7</LM>
   </w.rf>
   <form>vlečce</form>
   <lemma>vlečka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1e2731-x2-810">
   <w.rf>
    <LM>w#w-d1e2731-x2-810</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-808">
  <m id="m025-d1t2766-1">
   <w.rf>
    <LM>w#w-d1t2766-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2766-2">
   <w.rf>
    <LM>w#w-d1t2766-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2766-3">
   <w.rf>
    <LM>w#w-d1t2766-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2766-4">
   <w.rf>
    <LM>w#w-d1t2766-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m025-d1t2766-5">
   <w.rf>
    <LM>w#w-d1t2766-5</LM>
   </w.rf>
   <form>vlečka</form>
   <lemma>vlečka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m025-d1t2766-7">
   <w.rf>
    <LM>w#w-d1t2766-7</LM>
   </w.rf>
   <form>Viamont</form>
   <lemma>Viamont_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2731-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2731-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2769-x2">
  <m id="m025-d1t2774-4">
   <w.rf>
    <LM>w#w-d1t2774-4</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1e2769-x2-824">
   <w.rf>
    <LM>w#w-d1e2769-x2-824</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2784-1">
   <w.rf>
    <LM>w#w-d1t2784-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2784-2">
   <w.rf>
    <LM>w#w-d1t2784-2</LM>
   </w.rf>
   <form>mými</form>
   <lemma>můj</lemma>
   <tag>PSXP7-S1-------</tag>
  </m>
  <m id="m025-d1t2784-3">
   <w.rf>
    <LM>w#w-d1t2784-3</LM>
   </w.rf>
   <form>spolupracovníky</form>
   <lemma>spolupracovník</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2779-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2779-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2797-x2">
  <m id="m025-d1t2800-1">
   <w.rf>
    <LM>w#w-d1t2800-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2800-2">
   <w.rf>
    <LM>w#w-d1t2800-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2800-3">
   <w.rf>
    <LM>w#w-d1t2800-3</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m025-d-id126593-punct">
   <w.rf>
    <LM>w#w-d-id126593-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2801-x2">
  <m id="m025-d1t2806-1">
   <w.rf>
    <LM>w#w-d1t2806-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m025-d1t2806-2">
   <w.rf>
    <LM>w#w-d1t2806-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2808-1">
   <w.rf>
    <LM>w#w-d1t2808-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2808-2">
   <w.rf>
    <LM>w#w-d1t2808-2</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m025-d1t2808-3">
   <w.rf>
    <LM>w#w-d1t2808-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2810-2">
   <w.rf>
    <LM>w#w-d1t2810-2</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2810-3">
   <w.rf>
    <LM>w#w-d1t2810-3</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d-m-d1e2801-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2801-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2813-x2">
  <m id="m025-d1t2816-1">
   <w.rf>
    <LM>w#w-d1t2816-1</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2816-2">
   <w.rf>
    <LM>w#w-d1t2816-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t2816-3">
   <w.rf>
    <LM>w#w-d1t2816-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m025-d1t2816-4">
   <w.rf>
    <LM>w#w-d1t2816-4</LM>
   </w.rf>
   <form>klidně</form>
   <lemma>klidně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2816-5">
   <w.rf>
    <LM>w#w-d1t2816-5</LM>
   </w.rf>
   <form>ukázat</form>
   <lemma>ukázat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m025-d-m-d1e2813-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2813-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2817-x2">
  <m id="m025-d1t2822-1">
   <w.rf>
    <LM>w#w-d1t2822-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d-m-d1e2817-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2817-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2825-x2">
  <m id="m025-d1t2830-1">
   <w.rf>
    <LM>w#w-d1t2830-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m025-d1t2830-2">
   <w.rf>
    <LM>w#w-d1t2830-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2830-3">
   <w.rf>
    <LM>w#w-d1t2830-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2830-4">
   <w.rf>
    <LM>w#w-d1t2830-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2830-5">
   <w.rf>
    <LM>w#w-d1t2830-5</LM>
   </w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d-id127185-punct">
   <w.rf>
    <LM>w#w-d-id127185-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2831-x2">
  <m id="m025-d1t2838-1">
   <w.rf>
    <LM>w#w-d1t2838-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2838-2">
   <w.rf>
    <LM>w#w-d1t2838-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2838-3">
   <w.rf>
    <LM>w#w-d1t2838-3</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2838-4">
   <w.rf>
    <LM>w#w-d1t2838-4</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m025-d-id127342-punct">
   <w.rf>
    <LM>w#w-d-id127342-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2838-6">
   <w.rf>
    <LM>w#w-d1t2838-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2838-7">
   <w.rf>
    <LM>w#w-d1t2838-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2838-8">
   <w.rf>
    <LM>w#w-d1t2838-8</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2840-2">
   <w.rf>
    <LM>w#w-d1t2840-2</LM>
   </w.rf>
   <form>dodělat</form>
   <lemma>dodělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m025-d1t2838-10">
   <w.rf>
    <LM>w#w-d1t2838-10</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m025-d1t2838-11">
   <w.rf>
    <LM>w#w-d1t2838-11</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m025-d-id127484-punct">
   <w.rf>
    <LM>w#w-d-id127484-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2842-1">
   <w.rf>
    <LM>w#w-d1t2842-1</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2842-2">
   <w.rf>
    <LM>w#w-d1t2842-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2842-3">
   <w.rf>
    <LM>w#w-d1t2842-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2842-5">
   <w.rf>
    <LM>w#w-d1t2842-5</LM>
   </w.rf>
   <form>nárok</form>
   <lemma>nárok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d1t2842-6">
   <w.rf>
    <LM>w#w-d1t2842-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2842-7">
   <w.rf>
    <LM>w#w-d1t2842-7</LM>
   </w.rf>
   <form>odchod</form>
   <lemma>odchod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d1t2842-8">
   <w.rf>
    <LM>w#w-d1t2842-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2842-9">
   <w.rf>
    <LM>w#w-d1t2842-9</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2831-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2831-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2846-x2">
  <m id="m025-d1t2851-1">
   <w.rf>
    <LM>w#w-d1t2851-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1e2846-x2-838">
   <w.rf>
    <LM>w#w-d1e2846-x2-838</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-840">
  <m id="m025-d1t2851-2">
   <w.rf>
    <LM>w#w-d1t2851-2</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2851-3">
   <w.rf>
    <LM>w#w-d1t2851-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2851-4">
   <w.rf>
    <LM>w#w-d1t2851-4</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m025-d1t2851-5">
   <w.rf>
    <LM>w#w-d1t2851-5</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2851-6">
   <w.rf>
    <LM>w#w-d1t2851-6</LM>
   </w.rf>
   <form>drah</form>
   <lemma>dráha</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m025-d-id127805-punct">
   <w.rf>
    <LM>w#w-d-id127805-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2852-x2">
  <m id="m025-d1t2857-2">
   <w.rf>
    <LM>w#w-d1t2857-2</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2857-3">
   <w.rf>
    <LM>w#w-d1t2857-3</LM>
   </w.rf>
   <form>prvé</form>
   <lemma>prvý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m025-d1t2859-1">
   <w.rf>
    <LM>w#w-d1t2859-1</LM>
   </w.rf>
   <form>funkce</form>
   <lemma>funkce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m025-d-id127940-punct">
   <w.rf>
    <LM>w#w-d-id127940-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2859-3">
   <w.rf>
    <LM>w#w-d1t2859-3</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m025-d1t2859-4">
   <w.rf>
    <LM>w#w-d1t2859-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2859-5">
   <w.rf>
    <LM>w#w-d1t2859-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2859-6">
   <w.rf>
    <LM>w#w-d1t2859-6</LM>
   </w.rf>
   <form>vykonával</form>
   <lemma>vykonávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d-id128010-punct">
   <w.rf>
    <LM>w#w-d-id128010-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1e2852-x2-494">
   <w.rf>
    <LM>w#w-d1e2852-x2-494</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m025-d1t2863-4">
   <w.rf>
    <LM>w#w-d1t2863-4</LM>
   </w.rf>
   <form>prvního</form>
   <lemma>první-1</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m025-d1t2863-5">
   <w.rf>
    <LM>w#w-d1t2863-5</LM>
   </w.rf>
   <form>dubna</form>
   <lemma>duben</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m025-d1t2863-1">
   <w.rf>
    <LM>w#w-d1t2863-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2863-2">
   <w.rf>
    <LM>w#w-d1t2863-2</LM>
   </w.rf>
   <form>čtyřmi</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m025-d1t2863-3">
   <w.rf>
    <LM>w#w-d1t2863-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m025-d1t2863-8">
   <w.rf>
    <LM>w#w-d1t2863-8</LM>
   </w.rf>
   <form>zrušena</form>
   <lemma>zrušit</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m025-d1e2852-x2-898">
   <w.rf>
    <LM>w#w-d1e2852-x2-898</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-899">
  <m id="m025-d1t2868-3">
   <w.rf>
    <LM>w#w-d1t2868-3</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m025-d1t2868-4">
   <w.rf>
    <LM>w#w-d1t2868-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2868-5">
   <w.rf>
    <LM>w#w-d1t2868-5</LM>
   </w.rf>
   <form>povedlo</form>
   <lemma>povést</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m025-d-id128265-punct">
   <w.rf>
    <LM>w#w-d-id128265-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2868-7">
   <w.rf>
    <LM>w#w-d1t2868-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2868-8">
   <w.rf>
    <LM>w#w-d1t2868-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2868-9">
   <w.rf>
    <LM>w#w-d1t2868-9</LM>
   </w.rf>
   <form>odešel</form>
   <lemma>odejít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m025-d1t2868-10">
   <w.rf>
    <LM>w#w-d1t2868-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2868-12">
   <w.rf>
    <LM>w#w-d1t2868-12</LM>
   </w.rf>
   <form>sociální</form>
   <lemma>sociální</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m025-d1t2868-13">
   <w.rf>
    <LM>w#w-d1t2868-13</LM>
   </w.rf>
   <form>program</form>
   <lemma>program-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d-id128382-punct">
   <w.rf>
    <LM>w#w-d-id128382-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2868-15">
   <w.rf>
    <LM>w#w-d1t2868-15</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m025-d1t2868-16">
   <w.rf>
    <LM>w#w-d1t2868-16</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2868-17">
   <w.rf>
    <LM>w#w-d1t2868-17</LM>
   </w.rf>
   <form>navršený</form>
   <lemma>navršený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m025-d1t2872-2">
   <w.rf>
    <LM>w#w-d1t2872-2</LM>
   </w.rf>
   <form>prostřednictvím</form>
   <lemma>prostřednictvím</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2872-3">
   <w.rf>
    <LM>w#w-d1t2872-3</LM>
   </w.rf>
   <form>odborů</form>
   <lemma>odbory_^(odborářská_organizace)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m025-899-900">
   <w.rf>
    <LM>w#w-899-900</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-901">
  <m id="m025-d1t2872-5">
   <w.rf>
    <LM>w#w-d1t2872-5</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2872-6">
   <w.rf>
    <LM>w#w-d1t2872-6</LM>
   </w.rf>
   <form>dohodě</form>
   <lemma>dohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2872-7">
   <w.rf>
    <LM>w#w-d1t2872-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2872-9">
   <w.rf>
    <LM>w#w-d1t2872-9</LM>
   </w.rf>
   <form>Českými</form>
   <lemma>český</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m025-d1t2872-10">
   <w.rf>
    <LM>w#w-d1t2872-10</LM>
   </w.rf>
   <form>drahami</form>
   <lemma>dráha</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m025-d-id128612-punct">
   <w.rf>
    <LM>w#w-d-id128612-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2874-1">
   <w.rf>
    <LM>w#w-d1t2874-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2874-2">
   <w.rf>
    <LM>w#w-d1t2874-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t2874-3">
   <w.rf>
    <LM>w#w-d1t2874-3</LM>
   </w.rf>
   <form>dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m025-d1t2874-4">
   <w.rf>
    <LM>w#w-d1t2874-4</LM>
   </w.rf>
   <form>odstupné</form>
   <lemma>odstupné</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m025-d1e2852-x2-858">
   <w.rf>
    <LM>w#w-d1e2852-x2-858</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2879-4">
   <w.rf>
    <LM>w#w-d1t2879-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2879-5">
   <w.rf>
    <LM>w#w-d1t2879-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t2879-6">
   <w.rf>
    <LM>w#w-d1t2879-6</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2879-7">
   <w.rf>
    <LM>w#w-d1t2879-7</LM>
   </w.rf>
   <form>najít</form>
   <lemma>najít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m025-d1t2881-2">
   <w.rf>
    <LM>w#w-d1t2881-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2881-3">
   <w.rf>
    <LM>w#w-d1t2881-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m025-d1t2881-4">
   <w.rf>
    <LM>w#w-d1t2881-4</LM>
   </w.rf>
   <form>zbylé</form>
   <lemma>zbylý_^(*3ýt)</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m025-d1t2881-5">
   <w.rf>
    <LM>w#w-d1t2881-5</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m025-d1t2881-6">
   <w.rf>
    <LM>w#w-d1t2881-6</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m025-d1t2883-1">
   <w.rf>
    <LM>w#w-d1t2883-1</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m025-d1t2883-2">
   <w.rf>
    <LM>w#w-d1t2883-2</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2852-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2852-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2896-x2">
  <m id="m025-d1t2899-2">
   <w.rf>
    <LM>w#w-d1t2899-2</LM>
   </w.rf>
   <form>Povedlo</form>
   <lemma>povést</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m025-d1t2899-3">
   <w.rf>
    <LM>w#w-d1t2899-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2899-4">
   <w.rf>
    <LM>w#w-d1t2899-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d-id129262-punct">
   <w.rf>
    <LM>w#w-d-id129262-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2899-6">
   <w.rf>
    <LM>w#w-d1t2899-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2899-7">
   <w.rf>
    <LM>w#w-d1t2899-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2899-8">
   <w.rf>
    <LM>w#w-d1t2899-8</LM>
   </w.rf>
   <form>mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2901-1">
   <w.rf>
    <LM>w#w-d1t2901-1</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m025-d1t2901-2">
   <w.rf>
    <LM>w#w-d1t2901-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m025-d1t2901-4">
   <w.rf>
    <LM>w#w-d1t2901-4</LM>
   </w.rf>
   <form>Škodovce</form>
   <lemma>Škodovka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2903-2">
   <w.rf>
    <LM>w#w-d1t2903-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2903-3">
   <w.rf>
    <LM>w#w-d1t2903-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m025-d1t2903-4">
   <w.rf>
    <LM>w#w-d1t2903-4</LM>
   </w.rf>
   <form>místní</form>
   <lemma>místní</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m025-d1t2903-5">
   <w.rf>
    <LM>w#w-d1t2903-5</LM>
   </w.rf>
   <form>vlečce</form>
   <lemma>vlečka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2896-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2896-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2911-x2">
  <m id="m025-d1t2914-1">
   <w.rf>
    <LM>w#w-d1t2914-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m025-d1t2914-2">
   <w.rf>
    <LM>w#w-d1t2914-2</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m025-d1t2914-3">
   <w.rf>
    <LM>w#w-d1t2914-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2914-4">
   <w.rf>
    <LM>w#w-d1t2914-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m025-d1t2914-7">
   <w.rf>
    <LM>w#w-d1t2914-7</LM>
   </w.rf>
   <form>Škodovce</form>
   <lemma>Škodovka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t2914-9">
   <w.rf>
    <LM>w#w-d1t2914-9</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d-id129643-punct">
   <w.rf>
    <LM>w#w-d-id129643-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2915-x2">
  <m id="m025-d1t2926-1">
   <w.rf>
    <LM>w#w-d1t2926-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t2926-2">
   <w.rf>
    <LM>w#w-d1t2926-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2926-3">
   <w.rf>
    <LM>w#w-d1t2926-3</LM>
   </w.rf>
   <form>strojvedoucí</form>
   <lemma>strojvedoucí-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m025-d-id129848-punct">
   <w.rf>
    <LM>w#w-d-id129848-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2926-5">
   <w.rf>
    <LM>w#w-d1t2926-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m025-d1t2926-6">
   <w.rf>
    <LM>w#w-d1t2926-6</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2926-7">
   <w.rf>
    <LM>w#w-d1t2926-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2926-8">
   <w.rf>
    <LM>w#w-d1t2926-8</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m025-d1t2926-9">
   <w.rf>
    <LM>w#w-d1t2926-9</LM>
   </w.rf>
   <form>mašinkou</form>
   <lemma>mašinka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m025-d1e2915-x2-516">
   <w.rf>
    <LM>w#w-d1e2915-x2-516</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2929-1">
   <w.rf>
    <LM>w#w-d1t2929-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m025-d1t2929-2">
   <w.rf>
    <LM>w#w-d1t2929-2</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m025-d1e2915-x2-894">
   <w.rf>
    <LM>w#w-d1e2915-x2-894</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2931-1">
   <w.rf>
    <LM>w#w-d1t2931-1</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m025-d1t2931-2">
   <w.rf>
    <LM>w#w-d1t2931-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2931-4">
   <w.rf>
    <LM>w#w-d1t2931-4</LM>
   </w.rf>
   <form>obsluhovali</form>
   <lemma>obsluhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m025-d1e2915-x2-896">
   <w.rf>
    <LM>w#w-d1e2915-x2-896</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2931-5">
   <w.rf>
    <LM>w#w-d1t2931-5</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m025-d1t2931-6">
   <w.rf>
    <LM>w#w-d1t2931-6</LM>
   </w.rf>
   <form>halách</form>
   <lemma>hala</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m025-d1e2915-x2-919">
   <w.rf>
    <LM>w#w-d1e2915-x2-919</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-920">
  <m id="m025-d1t2935-3">
   <w.rf>
    <LM>w#w-d1t2935-3</LM>
   </w.rf>
   <form>Vyndavali</form>
   <lemma>vyndavat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m025-d1t2935-2">
   <w.rf>
    <LM>w#w-d1t2935-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2935-4">
   <w.rf>
    <LM>w#w-d1t2935-4</LM>
   </w.rf>
   <form>vagony</form>
   <lemma>vagon_,s_^(^DD**vagón)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m025-d1t2935-5">
   <w.rf>
    <LM>w#w-d1t2935-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2935-6">
   <w.rf>
    <LM>w#w-d1t2935-6</LM>
   </w.rf>
   <form>různými</form>
   <lemma>různý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m025-d1t2935-7">
   <w.rf>
    <LM>w#w-d1t2935-7</LM>
   </w.rf>
   <form>výrobky</form>
   <lemma>výrobek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m025-d1t2937-1">
   <w.rf>
    <LM>w#w-d1t2937-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m025-d1t2937-2">
   <w.rf>
    <LM>w#w-d1t2937-2</LM>
   </w.rf>
   <form>horké</form>
   <lemma>horký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m025-d1t2937-3">
   <w.rf>
    <LM>w#w-d1t2937-3</LM>
   </w.rf>
   <form>převozy</form>
   <lemma>převoz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m025-d-id130254-punct">
   <w.rf>
    <LM>w#w-d-id130254-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2937-5">
   <w.rf>
    <LM>w#w-d1t2937-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t2937-6">
   <w.rf>
    <LM>w#w-d1t2937-6</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t2939-3">
   <w.rf>
    <LM>w#w-d1t2939-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2939-4">
   <w.rf>
    <LM>w#w-d1t2939-4</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS2----------</tag>
  </m>
  <m id="m025-d1t2939-5">
   <w.rf>
    <LM>w#w-d1t2939-5</LM>
   </w.rf>
   <form>pece</form>
   <lemma>pec</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m025-d1t2939-6">
   <w.rf>
    <LM>w#w-d1t2939-6</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2942-1">
   <w.rf>
    <LM>w#w-d1t2942-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2942-2">
   <w.rf>
    <LM>w#w-d1t2942-2</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m025-d-id130408-punct">
   <w.rf>
    <LM>w#w-d-id130408-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2942-4">
   <w.rf>
    <LM>w#w-d1t2942-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2942-5">
   <w.rf>
    <LM>w#w-d1t2942-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2942-6">
   <w.rf>
    <LM>w#w-d1t2942-6</LM>
   </w.rf>
   <form>lily</form>
   <lemma>lít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m025-d1t2944-1">
   <w.rf>
    <LM>w#w-d1t2944-1</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m025-d1t2944-2">
   <w.rf>
    <LM>w#w-d1t2944-2</LM>
   </w.rf>
   <form>formy</form>
   <lemma>forma</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m025-d1t2944-3">
   <w.rf>
    <LM>w#w-d1t2944-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m025-d1t2944-4">
   <w.rf>
    <LM>w#w-d1t2944-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d-m-d1e2915-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2915-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2951-x2">
  <m id="m025-d1t2954-1">
   <w.rf>
    <LM>w#w-d1t2954-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2954-2">
   <w.rf>
    <LM>w#w-d1t2954-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2954-3">
   <w.rf>
    <LM>w#w-d1t2954-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m025-d1t2954-4">
   <w.rf>
    <LM>w#w-d1t2954-4</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m025-d1t2954-5">
   <w.rf>
    <LM>w#w-d1t2954-5</LM>
   </w.rf>
   <form>vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d-id130651-punct">
   <w.rf>
    <LM>w#w-d-id130651-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2955-x2">
  <m id="m025-d1t2958-2">
   <w.rf>
    <LM>w#w-d1t2958-2</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2958-3">
   <w.rf>
    <LM>w#w-d1t2958-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m025-d1t2958-4">
   <w.rf>
    <LM>w#w-d1t2958-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m025-d1t2958-5">
   <w.rf>
    <LM>w#w-d1t2958-5</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2958-6">
   <w.rf>
    <LM>w#w-d1t2958-6</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m025-d1e2955-x2-904">
   <w.rf>
    <LM>w#w-d1e2955-x2-904</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2958-7">
   <w.rf>
    <LM>w#w-d1t2958-7</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2960-1">
   <w.rf>
    <LM>w#w-d1t2960-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2960-2">
   <w.rf>
    <LM>w#w-d1t2960-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2960-4">
   <w.rf>
    <LM>w#w-d1t2960-4</LM>
   </w.rf>
   <form>spolupracovníky</form>
   <lemma>spolupracovník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m025-d-id130892-punct">
   <w.rf>
    <LM>w#w-d-id130892-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2960-6">
   <w.rf>
    <LM>w#w-d1t2960-6</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m025-d1t2962-6">
   <w.rf>
    <LM>w#w-d1t2962-6</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t2962-2">
   <w.rf>
    <LM>w#w-d1t2962-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m025-d1t2962-3">
   <w.rf>
    <LM>w#w-d1t2962-3</LM>
   </w.rf>
   <form>mému</form>
   <lemma>můj</lemma>
   <tag>PSZS3-S1-------</tag>
  </m>
  <m id="m025-d1t2962-5">
   <w.rf>
    <LM>w#w-d1t2962-5</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m025-d1t2962-8">
   <w.rf>
    <LM>w#w-d1t2962-8</LM>
   </w.rf>
   <form>dávali</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m025-d1t2964-1">
   <w.rf>
    <LM>w#w-d1t2964-1</LM>
   </w.rf>
   <form>lehčí</form>
   <lemma>lehký</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m025-d1t2964-3">
   <w.rf>
    <LM>w#w-d1t2964-3</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m025-d-id131129-punct">
   <w.rf>
    <LM>w#w-d-id131129-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2964-5">
   <w.rf>
    <LM>w#w-d1t2964-5</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m025-d1t2966-1">
   <w.rf>
    <LM>w#w-d1t2966-1</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m025-d1t2966-2">
   <w.rf>
    <LM>w#w-d1t2966-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2966-3">
   <w.rf>
    <LM>w#w-d1t2966-3</LM>
   </w.rf>
   <form>vykonával</form>
   <lemma>vykonávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2966-4">
   <w.rf>
    <LM>w#w-d1t2966-4</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m025-d-m-d1e2955-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2955-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2970-x2">
  <m id="m025-d1t2973-1">
   <w.rf>
    <LM>w#w-d1t2973-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1e2970-x2-910">
   <w.rf>
    <LM>w#w-d1e2970-x2-910</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-912">
  <m id="m025-d1t2973-3">
   <w.rf>
    <LM>w#w-d1t2973-3</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2973-4">
   <w.rf>
    <LM>w#w-d1t2973-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t2973-6">
   <w.rf>
    <LM>w#w-d1t2973-6</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2973-7">
   <w.rf>
    <LM>w#w-d1t2973-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2973-8">
   <w.rf>
    <LM>w#w-d1t2973-8</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m025-d-id131404-punct">
   <w.rf>
    <LM>w#w-d-id131404-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2974-x2">
  <m id="m025-d1t2979-1">
   <w.rf>
    <LM>w#w-d1t2979-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t2979-2">
   <w.rf>
    <LM>w#w-d1t2979-2</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m025-d1t2979-3">
   <w.rf>
    <LM>w#w-d1t2979-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2979-4">
   <w.rf>
    <LM>w#w-d1t2979-4</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d1t2979-5">
   <w.rf>
    <LM>w#w-d1t2979-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2979-6">
   <w.rf>
    <LM>w#w-d1t2979-6</LM>
   </w.rf>
   <form>loňském</form>
   <lemma>loňský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m025-d1t2979-7">
   <w.rf>
    <LM>w#w-d1t2979-7</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m025-d1e2974-x2-914">
   <w.rf>
    <LM>w#w-d1e2974-x2-914</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2981-2">
   <w.rf>
    <LM>w#w-d1t2981-2</LM>
   </w.rf>
   <form>prvního</form>
   <lemma>první-1</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m025-d1t2981-3">
   <w.rf>
    <LM>w#w-d1t2981-3</LM>
   </w.rf>
   <form>září</form>
   <lemma>září</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m025-d1t2983-1">
   <w.rf>
    <LM>w#w-d1t2983-1</LM>
   </w.rf>
   <form>2007</form>
   <lemma>2007</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m025-d-m-d1e2974-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2974-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2986-x2">
  <m id="m025-d1t2989-1">
   <w.rf>
    <LM>w#w-d1t2989-1</LM>
   </w.rf>
   <form>Stýská</form>
   <lemma>stýskat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t2989-2">
   <w.rf>
    <LM>w#w-d1t2989-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2989-3">
   <w.rf>
    <LM>w#w-d1t2989-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m025-d1t2989-4">
   <w.rf>
    <LM>w#w-d1t2989-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2989-5">
   <w.rf>
    <LM>w#w-d1t2989-5</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m025-d1t2989-6">
   <w.rf>
    <LM>w#w-d1t2989-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2989-7">
   <w.rf>
    <LM>w#w-d1t2989-7</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d-id131857-punct">
   <w.rf>
    <LM>w#w-d-id131857-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e2990-x2">
  <m id="m025-d1t2993-3">
   <w.rf>
    <LM>w#w-d1t2993-3</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2993-4">
   <w.rf>
    <LM>w#w-d1t2993-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d-id131974-punct">
   <w.rf>
    <LM>w#w-d-id131974-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t2993-6">
   <w.rf>
    <LM>w#w-d1t2993-6</LM>
   </w.rf>
   <form>nestýská</form>
   <lemma>stýskat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m025-d1e2990-x2-922">
   <w.rf>
    <LM>w#w-d1e2990-x2-922</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-924">
  <m id="m025-d1t2993-7">
   <w.rf>
    <LM>w#w-d1t2993-7</LM>
   </w.rf>
   <form>Spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t2993-8">
   <w.rf>
    <LM>w#w-d1t2993-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t2993-9">
   <w.rf>
    <LM>w#w-d1t2993-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t2993-10">
   <w.rf>
    <LM>w#w-d1t2993-10</LM>
   </w.rf>
   <form>stýská</form>
   <lemma>stýskat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t2995-1">
   <w.rf>
    <LM>w#w-d1t2995-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t2995-3">
   <w.rf>
    <LM>w#w-d1t2995-3</LM>
   </w.rf>
   <form>kolezích</form>
   <lemma>kolega</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m025-924-931">
   <w.rf>
    <LM>w#w-924-931</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-932">
  <m id="m025-d1t2997-5">
   <w.rf>
    <LM>w#w-d1t2997-5</LM>
   </w.rf>
   <form>Prožil</form>
   <lemma>prožít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m025-d1t2997-2">
   <w.rf>
    <LM>w#w-d1t2997-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t2997-3">
   <w.rf>
    <LM>w#w-d1t2997-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t2997-4">
   <w.rf>
    <LM>w#w-d1t2997-4</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m025-d1t2999-1">
   <w.rf>
    <LM>w#w-d1t2999-1</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m025-d1t2999-2">
   <w.rf>
    <LM>w#w-d1t2999-2</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t2999-3">
   <w.rf>
    <LM>w#w-d1t2999-3</LM>
   </w.rf>
   <form>pěkných</form>
   <lemma>pěkný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m025-d1t2999-4">
   <w.rf>
    <LM>w#w-d1t2999-4</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m025-d-m-d1e2990-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2990-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3000-x2">
  <m id="m025-d1t3005-3">
   <w.rf>
    <LM>w#w-d1t3005-3</LM>
   </w.rf>
   <form>Užíváte</form>
   <lemma>užívat_^(*3t)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t3005-2">
   <w.rf>
    <LM>w#w-d1t3005-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t3005-4">
   <w.rf>
    <LM>w#w-d1t3005-4</LM>
   </w.rf>
   <form>volna</form>
   <lemma>volno-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m025-d-id132392-punct">
   <w.rf>
    <LM>w#w-d-id132392-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3006-x2">
  <m id="m025-d1t3009-1">
   <w.rf>
    <LM>w#w-d1t3009-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1e3006-x2-928">
   <w.rf>
    <LM>w#w-d1e3006-x2-928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t3009-2">
   <w.rf>
    <LM>w#w-d1t3009-2</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t3009-3">
   <w.rf>
    <LM>w#w-d1t3009-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m025-d1t3009-4">
   <w.rf>
    <LM>w#w-d1t3009-4</LM>
   </w.rf>
   <form>užívám</form>
   <lemma>užívat_^(*3t)</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1t3009-5">
   <w.rf>
    <LM>w#w-d1t3009-5</LM>
   </w.rf>
   <form>volna</form>
   <lemma>volno-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m025-d-m-d1e3006-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3006-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3016-x2">
  <m id="m025-d1t3019-1">
   <w.rf>
    <LM>w#w-d1t3019-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t3019-2">
   <w.rf>
    <LM>w#w-d1t3019-2</LM>
   </w.rf>
   <form>kým</form>
   <lemma>kdo</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m025-d1t3019-3">
   <w.rf>
    <LM>w#w-d1t3019-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m025-d1t3019-5">
   <w.rf>
    <LM>w#w-d1t3019-5</LM>
   </w.rf>
   <form>vašich</form>
   <lemma>váš</lemma>
   <tag>PSXP2-P2-------</tag>
  </m>
  <m id="m025-d1t3019-6">
   <w.rf>
    <LM>w#w-d1t3019-6</LM>
   </w.rf>
   <form>kolegů</form>
   <lemma>kolega</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m025-d1t3019-7">
   <w.rf>
    <LM>w#w-d1t3019-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m025-d1t3019-8">
   <w.rf>
    <LM>w#w-d1t3019-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t3019-9">
   <w.rf>
    <LM>w#w-d1t3019-9</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m025-d1t3019-10">
   <w.rf>
    <LM>w#w-d1t3019-10</LM>
   </w.rf>
   <form>přátelil</form>
   <lemma>přátelit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m025-d-id132739-punct">
   <w.rf>
    <LM>w#w-d-id132739-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3020-x2">
  <m id="m025-d1t3027-2">
   <w.rf>
    <LM>w#w-d1t3027-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t3027-5">
   <w.rf>
    <LM>w#w-d1t3027-5</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS6-S1-------</tag>
  </m>
  <m id="m025-d1t3027-3">
   <w.rf>
    <LM>w#w-d1t3027-3</LM>
   </w.rf>
   <form>pravé</form>
   <lemma>pravý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m025-d1t3027-4">
   <w.rf>
    <LM>w#w-d1t3027-4</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d1t3027-6">
   <w.rf>
    <LM>w#w-d1t3027-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t3027-8">
   <w.rf>
    <LM>w#w-d1t3027-8</LM>
   </w.rf>
   <form>Honzík</form>
   <lemma>Honzík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m025-d1t3027-9">
   <w.rf>
    <LM>w#w-d1t3027-9</LM>
   </w.rf>
   <form>Dolejš</form>
   <lemma>Dolejš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m025-d1t3029-1">
   <w.rf>
    <LM>w#w-d1t3029-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m025-d1t3029-3">
   <w.rf>
    <LM>w#w-d1t3029-3</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m025-d1t3029-4">
   <w.rf>
    <LM>w#w-d1t3029-4</LM>
   </w.rf>
   <form>vpravo</form>
   <lemma>vpravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t3029-5">
   <w.rf>
    <LM>w#w-d1t3029-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t3029-7">
   <w.rf>
    <LM>w#w-d1t3029-7</LM>
   </w.rf>
   <form>Pavel</form>
   <lemma>Pavel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m025-d1t3029-8">
   <w.rf>
    <LM>w#w-d1t3029-8</LM>
   </w.rf>
   <form>Bláhů</form>
   <lemma>Bláha_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m025-d1e3020-x2-946">
   <w.rf>
    <LM>w#w-d1e3020-x2-946</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t3029-11">
   <w.rf>
    <LM>w#w-d1t3029-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m025-d1t3029-12">
   <w.rf>
    <LM>w#w-d1t3029-12</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m025-d1t3029-13">
   <w.rf>
    <LM>w#w-d1t3029-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m025-d1t3029-14">
   <w.rf>
    <LM>w#w-d1t3029-14</LM>
   </w.rf>
   <form>scházím</form>
   <lemma>scházet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m025-d1e3020-x2-948">
   <w.rf>
    <LM>w#w-d1e3020-x2-948</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-950">
  <m id="m025-d1t3031-1">
   <w.rf>
    <LM>w#w-d1t3031-1</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t3031-2">
   <w.rf>
    <LM>w#w-d1t3031-2</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m025-d1t3031-3">
   <w.rf>
    <LM>w#w-d1t3031-3</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d1t3034-1">
   <w.rf>
    <LM>w#w-d1t3034-1</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t3036-2">
   <w.rf>
    <LM>w#w-d1t3036-2</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m025-d1t3036-3">
   <w.rf>
    <LM>w#w-d1t3036-3</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m025-d1t3034-4">
   <w.rf>
    <LM>w#w-d1t3034-4</LM>
   </w.rf>
   <form>turnaj</form>
   <lemma>turnaj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m025-d1t3034-5">
   <w.rf>
    <LM>w#w-d1t3034-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t3034-8">
   <w.rf>
    <LM>w#w-d1t3034-8</LM>
   </w.rf>
   <form>bowlingu</form>
   <lemma>bowling</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m025-d-m-d1e3020-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3020-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3051-x2">
  <m id="m025-d1t3054-1">
   <w.rf>
    <LM>w#w-d1t3054-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t3054-2">
   <w.rf>
    <LM>w#w-d1t3054-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m025-d1t3054-3">
   <w.rf>
    <LM>w#w-d1t3054-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m025-d-m-d1e3051-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3051-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3061-x2">
  <m id="m025-d1t3064-1">
   <w.rf>
    <LM>w#w-d1t3064-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m025-d1t3064-2">
   <w.rf>
    <LM>w#w-d1t3064-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m025-d1t3064-3">
   <w.rf>
    <LM>w#w-d1t3064-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1t3064-4">
   <w.rf>
    <LM>w#w-d1t3064-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m025-d1t3064-5">
   <w.rf>
    <LM>w#w-d1t3064-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m025-d1t3064-6">
   <w.rf>
    <LM>w#w-d1t3064-6</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m025-d1t3064-7">
   <w.rf>
    <LM>w#w-d1t3064-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m025-d-id133784-punct">
   <w.rf>
    <LM>w#w-d-id133784-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3065-x2">
  <m id="m025-d1t3068-1">
   <w.rf>
    <LM>w#w-d1t3068-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d-id133861-punct">
   <w.rf>
    <LM>w#w-d-id133861-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m025-d1t3068-3">
   <w.rf>
    <LM>w#w-d1t3068-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m025-d1t3068-4">
   <w.rf>
    <LM>w#w-d1t3068-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m025-d1t3068-6">
   <w.rf>
    <LM>w#w-d1t3068-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m025-d1t3068-5">
   <w.rf>
    <LM>w#w-d1t3068-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m025-d1t3068-7">
   <w.rf>
    <LM>w#w-d1t3068-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m025-d-m-d1e3065-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3065-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m025-d1e3069-x2">
  <m id="m025-d1t3072-2">
   <w.rf>
    <LM>w#w-d1t3072-2</LM>
   </w.rf>
   <form>Jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m025-d1t3072-3">
   <w.rf>
    <LM>w#w-d1t3072-3</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m025-d1e3069-x2-960">
   <w.rf>
    <LM>w#w-d1e3069-x2-960</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
