<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ps_003.02.w.gz" />
  </references>
 </head>
 <s id="m003-d1e618-x2">
  <m id="m003-d1e618-x2-2931">
   <w.rf>
    <LM>w#w-d1e618-x2-2931</LM>
   </w.rf>
   <form>2005</form>
   <lemma>2005</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m003-d-m-d1e618-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e618-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e625-x2">
  <m id="m003-d1t628-1">
   <w.rf>
    <LM>w#w-d1t628-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t628-2">
   <w.rf>
    <LM>w#w-d1t628-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t628-3">
   <w.rf>
    <LM>w#w-d1t628-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m003-d1t628-4">
   <w.rf>
    <LM>w#w-d1t628-4</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m003-d-id75114-punct">
   <w.rf>
    <LM>w#w-d-id75114-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e629-x2">
  <m id="m003-d1t634-1">
   <w.rf>
    <LM>w#w-d1t634-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t634-2">
   <w.rf>
    <LM>w#w-d1t634-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t634-3">
   <w.rf>
    <LM>w#w-d1t634-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t634-4">
   <w.rf>
    <LM>w#w-d1t634-4</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m003-d1t634-6">
   <w.rf>
    <LM>w#w-d1t634-6</LM>
   </w.rf>
   <form>Jiřího</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m003-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1e629-x2-2968">
   <w.rf>
    <LM>w#w-d1e629-x2-2968</LM>
   </w.rf>
   <form>obývacím</form>
   <lemma>obývací_^(*2t)</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m003-d1e629-x2-2969">
   <w.rf>
    <LM>w#w-d1e629-x2-2969</LM>
   </w.rf>
   <form>pokoji</form>
   <lemma>pokoj</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m003-d-m-d1e629-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e629-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e637-x2">
  <m id="m003-d1t640-1">
   <w.rf>
    <LM>w#w-d1t640-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t640-2">
   <w.rf>
    <LM>w#w-d1t640-2</LM>
   </w.rf>
   <form>bydlíte</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t640-3">
   <w.rf>
    <LM>w#w-d1t640-3</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m003-d-id75418-punct">
   <w.rf>
    <LM>w#w-d-id75418-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e641-x2">
  <m id="m003-d1t644-1">
   <w.rf>
    <LM>w#w-d1t644-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m003-d1t644-2">
   <w.rf>
    <LM>w#w-d1t644-2</LM>
   </w.rf>
   <form>bydlím</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d1t644-3">
   <w.rf>
    <LM>w#w-d1t644-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t644-4">
   <w.rf>
    <LM>w#w-d1t644-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m003-d1t644-6">
   <w.rf>
    <LM>w#w-d1t644-6</LM>
   </w.rf>
   <form>Vejprnicích</form>
   <lemma>Vejprnice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m003-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t646-2">
   <w.rf>
    <LM>w#w-d1t646-2</LM>
   </w.rf>
   <form>rodinném</form>
   <lemma>rodinný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m003-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m003-d-m-d1e641-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e641-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e647-x2">
  <m id="m003-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m003-d1t654-4">
   <w.rf>
    <LM>w#w-d1t654-4</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d-id75772-punct">
   <w.rf>
    <LM>w#w-d-id75772-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e655-x2">
  <m id="m003-d1t660-1">
   <w.rf>
    <LM>w#w-d1t660-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m003-d1t660-2">
   <w.rf>
    <LM>w#w-d1t660-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d1t660-3">
   <w.rf>
    <LM>w#w-d1t660-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m003-d1t660-4">
   <w.rf>
    <LM>w#w-d1t660-4</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m003-d1t660-6">
   <w.rf>
    <LM>w#w-d1t660-6</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d1e655-x2-3056">
   <w.rf>
    <LM>w#w-d1e655-x2-3056</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1e655-x2-3057">
   <w.rf>
    <LM>w#w-d1e655-x2-3057</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t660-9">
   <w.rf>
    <LM>w#w-d1t660-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t660-10">
   <w.rf>
    <LM>w#w-d1t660-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m003-d1t660-11">
   <w.rf>
    <LM>w#w-d1t660-11</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m003-d1t660-12">
   <w.rf>
    <LM>w#w-d1t660-12</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m003-d-id76008-punct">
   <w.rf>
    <LM>w#w-d-id76008-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t660-14">
   <w.rf>
    <LM>w#w-d1t660-14</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t660-15">
   <w.rf>
    <LM>w#w-d1t660-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m003-d1t660-16">
   <w.rf>
    <LM>w#w-d1t660-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t660-17">
   <w.rf>
    <LM>w#w-d1t660-17</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t660-18">
   <w.rf>
    <LM>w#w-d1t660-18</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m003-d1t660-19">
   <w.rf>
    <LM>w#w-d1t660-19</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m003-d-m-d1e655-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e655-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e661-x2">
  <m id="m003-d1t664-1">
   <w.rf>
    <LM>w#w-d1t664-1</LM>
   </w.rf>
   <form>Těšíte</form>
   <lemma>těšit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t664-2">
   <w.rf>
    <LM>w#w-d1t664-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t664-3">
   <w.rf>
    <LM>w#w-d1t664-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t664-4">
   <w.rf>
    <LM>w#w-d1t664-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m003-d1t664-5">
   <w.rf>
    <LM>w#w-d1t664-5</LM>
   </w.rf>
   <form>letošní</form>
   <lemma>letošní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m003-d-id76233-punct">
   <w.rf>
    <LM>w#w-d-id76233-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e665-x2">
  <m id="m003-d1t668-1">
   <w.rf>
    <LM>w#w-d1t668-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d-m-d1e665-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e665-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e669-x2">
  <m id="m003-d1t672-1">
   <w.rf>
    <LM>w#w-d1t672-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t672-2">
   <w.rf>
    <LM>w#w-d1t672-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d-id76394-punct">
   <w.rf>
    <LM>w#w-d-id76394-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e673-x2">
  <m id="m003-d1t678-1">
   <w.rf>
    <LM>w#w-d1t678-1</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t678-2">
   <w.rf>
    <LM>w#w-d1t678-2</LM>
   </w.rf>
   <form>odešla</form>
   <lemma>odejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m003-d1t678-3">
   <w.rf>
    <LM>w#w-d1t678-3</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d1t680-1">
   <w.rf>
    <LM>w#w-d1t680-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t680-2">
   <w.rf>
    <LM>w#w-d1t680-2</LM>
   </w.rf>
   <form>zemřela</form>
   <lemma>zemřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m003-d1t680-3">
   <w.rf>
    <LM>w#w-d1t680-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m003-d1t680-4">
   <w.rf>
    <LM>w#w-d1t680-4</LM>
   </w.rf>
   <form>švagrová</form>
   <lemma>švagrová</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d1e673-x2-3139">
   <w.rf>
    <LM>w#w-d1e673-x2-3139</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t687-2">
   <w.rf>
    <LM>w#w-d1t687-2</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m003-d1t687-3">
   <w.rf>
    <LM>w#w-d1t687-3</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m003-d-id76668-punct">
   <w.rf>
    <LM>w#w-d-id76668-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t687-5">
   <w.rf>
    <LM>w#w-d1t687-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t687-7">
   <w.rf>
    <LM>w#w-d1t687-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m003-d1t687-8">
   <w.rf>
    <LM>w#w-d1t687-8</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m003-d1t687-9">
   <w.rf>
    <LM>w#w-d1t687-9</LM>
   </w.rf>
   <form>plná</form>
   <lemma>plný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m003-d1t687-10">
   <w.rf>
    <LM>w#w-d1t687-10</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d-id76764-punct">
   <w.rf>
    <LM>w#w-d-id76764-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t687-12">
   <w.rf>
    <LM>w#w-d1t687-12</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t687-13">
   <w.rf>
    <LM>w#w-d1t687-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t687-15">
   <w.rf>
    <LM>w#w-d1t687-15</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t687-14">
   <w.rf>
    <LM>w#w-d1t687-14</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t687-16">
   <w.rf>
    <LM>w#w-d1t687-16</LM>
   </w.rf>
   <form>zvyklí</form>
   <lemma>zvyklý_^(*2nout)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m003-d-m-d1e673-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e673-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e688-x2">
  <m id="m003-d1t691-1">
   <w.rf>
    <LM>w#w-d1t691-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t691-2">
   <w.rf>
    <LM>w#w-d1t691-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t691-3">
   <w.rf>
    <LM>w#w-d1t691-3</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t691-4">
   <w.rf>
    <LM>w#w-d1t691-4</LM>
   </w.rf>
   <form>slavili</form>
   <lemma>slavit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t691-6">
   <w.rf>
    <LM>w#w-d1t691-6</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d-id76992-punct">
   <w.rf>
    <LM>w#w-d-id76992-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e693-x2">
  <m id="m003-d1t698-1">
   <w.rf>
    <LM>w#w-d1t698-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t698-2">
   <w.rf>
    <LM>w#w-d1t698-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t698-3">
   <w.rf>
    <LM>w#w-d1t698-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t698-4">
   <w.rf>
    <LM>w#w-d1t698-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m003-d1t698-6">
   <w.rf>
    <LM>w#w-d1t698-6</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d1e693-x2-3282">
   <w.rf>
    <LM>w#w-d1e693-x2-3282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t700-1">
   <w.rf>
    <LM>w#w-d1t700-1</LM>
   </w.rf>
   <form>sešli</form>
   <lemma>sejít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m003-d1t700-2">
   <w.rf>
    <LM>w#w-d1t700-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t700-3">
   <w.rf>
    <LM>w#w-d1t700-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t700-4">
   <w.rf>
    <LM>w#w-d1t700-4</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t700-5">
   <w.rf>
    <LM>w#w-d1t700-5</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m003-d1t700-6">
   <w.rf>
    <LM>w#w-d1t700-6</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d1t700-7">
   <w.rf>
    <LM>w#w-d1t700-7</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t700-8">
   <w.rf>
    <LM>w#w-d1t700-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t700-9">
   <w.rf>
    <LM>w#w-d1t700-9</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m003-d1e693-x2-3283">
   <w.rf>
    <LM>w#w-d1e693-x2-3283</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t702-1">
   <w.rf>
    <LM>w#w-d1t702-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t702-6">
   <w.rf>
    <LM>w#w-d1t702-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t702-7">
   <w.rf>
    <LM>w#w-d1t702-7</LM>
   </w.rf>
   <form>rodinném</form>
   <lemma>rodinný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m003-d1t702-8">
   <w.rf>
    <LM>w#w-d1t702-8</LM>
   </w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m003-d1t702-3">
   <w.rf>
    <LM>w#w-d1t702-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t702-4">
   <w.rf>
    <LM>w#w-d1t702-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m003-d1t702-5">
   <w.rf>
    <LM>w#w-d1t702-5</LM>
   </w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m003-d-id77439-punct">
   <w.rf>
    <LM>w#w-d-id77439-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t702-10">
   <w.rf>
    <LM>w#w-d1t702-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t702-11">
   <w.rf>
    <LM>w#w-d1t702-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t702-12">
   <w.rf>
    <LM>w#w-d1t702-12</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t702-13">
   <w.rf>
    <LM>w#w-d1t702-13</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t702-14">
   <w.rf>
    <LM>w#w-d1t702-14</LM>
   </w.rf>
   <form>večeři</form>
   <lemma>večeře</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d1e693-x2-3286">
   <w.rf>
    <LM>w#w-d1e693-x2-3286</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t702-16">
   <w.rf>
    <LM>w#w-d1t702-16</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t702-17">
   <w.rf>
    <LM>w#w-d1t702-17</LM>
   </w.rf>
   <form>večeři</form>
   <lemma>večeře</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m003-d1t702-18">
   <w.rf>
    <LM>w#w-d1t702-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t702-19">
   <w.rf>
    <LM>w#w-d1t702-19</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t702-20">
   <w.rf>
    <LM>w#w-d1t702-20</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m003-d1t702-21">
   <w.rf>
    <LM>w#w-d1t702-21</LM>
   </w.rf>
   <form>stromečku</form>
   <lemma>stromeček</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m003-d1t702-22">
   <w.rf>
    <LM>w#w-d1t702-22</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t702-23">
   <w.rf>
    <LM>w#w-d1t702-23</LM>
   </w.rf>
   <form>rozdávali</form>
   <lemma>rozdávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t702-24">
   <w.rf>
    <LM>w#w-d1t702-24</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m003-d1e693-x2-3287">
   <w.rf>
    <LM>w#w-d1e693-x2-3287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-3288">
  <m id="m003-d1t704-4">
   <w.rf>
    <LM>w#w-d1t704-4</LM>
   </w.rf>
   <form>Dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m003-d1t704-5">
   <w.rf>
    <LM>w#w-d1t704-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t704-6">
   <w.rf>
    <LM>w#w-d1t704-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t704-7">
   <w.rf>
    <LM>w#w-d1t704-7</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t704-8">
   <w.rf>
    <LM>w#w-d1t704-8</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d-id77793-punct">
   <w.rf>
    <LM>w#w-d-id77793-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t704-10">
   <w.rf>
    <LM>w#w-d1t704-10</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t704-11">
   <w.rf>
    <LM>w#w-d1t704-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t704-12">
   <w.rf>
    <LM>w#w-d1t704-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t704-13">
   <w.rf>
    <LM>w#w-d1t704-13</LM>
   </w.rf>
   <form>dívali</form>
   <lemma>dívat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t704-14">
   <w.rf>
    <LM>w#w-d1t704-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t704-15">
   <w.rf>
    <LM>w#w-d1t704-15</LM>
   </w.rf>
   <form>televizi</form>
   <lemma>televize</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d1t704-16">
   <w.rf>
    <LM>w#w-d1t704-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t704-17">
   <w.rf>
    <LM>w#w-d1t704-17</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t704-18">
   <w.rf>
    <LM>w#w-d1t704-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t704-20">
   <w.rf>
    <LM>w#w-d1t704-20</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m003-d1t704-21">
   <w.rf>
    <LM>w#w-d1t704-21</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-3288-3298">
   <w.rf>
    <LM>w#w-3288-3298</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t707-1">
   <w.rf>
    <LM>w#w-d1t707-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t707-2">
   <w.rf>
    <LM>w#w-d1t707-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t707-3">
   <w.rf>
    <LM>w#w-d1t707-3</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t707-4">
   <w.rf>
    <LM>w#w-d1t707-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m003-d-m-d1e693-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e693-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e708-x2">
  <m id="m003-d1t715-2">
   <w.rf>
    <LM>w#w-d1t715-2</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t715-4">
   <w.rf>
    <LM>w#w-d1t715-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t715-5">
   <w.rf>
    <LM>w#w-d1t715-5</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t715-6">
   <w.rf>
    <LM>w#w-d1t715-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t715-7">
   <w.rf>
    <LM>w#w-d1t715-7</LM>
   </w.rf>
   <form>kostela</form>
   <lemma>kostel</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m003-d-id78210-punct">
   <w.rf>
    <LM>w#w-d-id78210-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e716-x2">
  <m id="m003-d1t723-1">
   <w.rf>
    <LM>w#w-d1t723-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t723-2">
   <w.rf>
    <LM>w#w-d1t723-2</LM>
   </w.rf>
   <form>kostela</form>
   <lemma>kostel</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m003-d1e716-x2-3436">
   <w.rf>
    <LM>w#w-d1e716-x2-3436</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t723-4">
   <w.rf>
    <LM>w#w-d1t723-4</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1e716-x2-3437">
   <w.rf>
    <LM>w#w-d1e716-x2-3437</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d-id78344-punct">
   <w.rf>
    <LM>w#w-d-id78344-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t723-6">
   <w.rf>
    <LM>w#w-d1t723-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t723-7">
   <w.rf>
    <LM>w#w-d1t723-7</LM>
   </w.rf>
   <form>chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t723-8">
   <w.rf>
    <LM>w#w-d1t723-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t723-10">
   <w.rf>
    <LM>w#w-d1t723-10</LM>
   </w.rf>
   <form>Štědrý</form>
   <lemma>štědrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m003-d1t723-11">
   <w.rf>
    <LM>w#w-d1t723-11</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m003-d1t723-13">
   <w.rf>
    <LM>w#w-d1t723-13</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t723-14">
   <w.rf>
    <LM>w#w-d1t723-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t723-15">
   <w.rf>
    <LM>w#w-d1t723-15</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m003-d1t723-16">
   <w.rf>
    <LM>w#w-d1t723-16</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m003-d1t723-17">
   <w.rf>
    <LM>w#w-d1t723-17</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m003-d1t723-18">
   <w.rf>
    <LM>w#w-d1t723-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t723-19">
   <w.rf>
    <LM>w#w-d1t723-19</LM>
   </w.rf>
   <form>hřbitov</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m003-d1t725-1">
   <w.rf>
    <LM>w#w-d1t725-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t725-2">
   <w.rf>
    <LM>w#w-d1t725-2</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m003-d1t725-3">
   <w.rf>
    <LM>w#w-d1t725-3</LM>
   </w.rf>
   <form>hřbitova</form>
   <lemma>hřbitov</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m003-d1t727-1">
   <w.rf>
    <LM>w#w-d1t727-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t727-2">
   <w.rf>
    <LM>w#w-d1t727-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t727-3">
   <w.rf>
    <LM>w#w-d1t727-3</LM>
   </w.rf>
   <form>stavívali</form>
   <lemma>stavívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t730-1">
   <w.rf>
    <LM>w#w-d1t730-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t730-2">
   <w.rf>
    <LM>w#w-d1t730-2</LM>
   </w.rf>
   <form>kostele</form>
   <lemma>kostel</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m003-d-id78713-punct">
   <w.rf>
    <LM>w#w-d-id78713-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t730-4">
   <w.rf>
    <LM>w#w-d1t730-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t730-5">
   <w.rf>
    <LM>w#w-d1t730-5</LM>
   </w.rf>
   <form>půlnoční</form>
   <lemma>půlnoční-2_^(mše)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d1t730-6">
   <w.rf>
    <LM>w#w-d1t730-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t730-7">
   <w.rf>
    <LM>w#w-d1t730-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t730-8">
   <w.rf>
    <LM>w#w-d1t730-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m003-d1t730-10">
   <w.rf>
    <LM>w#w-d1t730-10</LM>
   </w.rf>
   <form>odbývá</form>
   <lemma>odbývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t730-12">
   <w.rf>
    <LM>w#w-d1t730-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t730-13">
   <w.rf>
    <LM>w#w-d1t730-13</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m003-d1t730-14">
   <w.rf>
    <LM>w#w-d1t730-14</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m003-d1t730-15">
   <w.rf>
    <LM>w#w-d1t730-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t730-16">
   <w.rf>
    <LM>w#w-d1t730-16</LM>
   </w.rf>
   <form>kostele</form>
   <lemma>kostel</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m003-d-id78895-punct">
   <w.rf>
    <LM>w#w-d-id78895-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t730-18">
   <w.rf>
    <LM>w#w-d1t730-18</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t730-19">
   <w.rf>
    <LM>w#w-d1t730-19</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t730-21">
   <w.rf>
    <LM>w#w-d1t730-21</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t730-22">
   <w.rf>
    <LM>w#w-d1t730-22</LM>
   </w.rf>
   <form>šli</form>
   <lemma>šle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d1t730-23">
   <w.rf>
    <LM>w#w-d1t730-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t730-25">
   <w.rf>
    <LM>w#w-d1t730-25</LM>
   </w.rf>
   <form>půlnoční</form>
   <lemma>půlnoční-2_^(mše)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d-id79021-punct">
   <w.rf>
    <LM>w#w-d-id79021-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t730-27">
   <w.rf>
    <LM>w#w-d1t730-27</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t730-28">
   <w.rf>
    <LM>w#w-d1t730-28</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1e716-x2-3443">
   <w.rf>
    <LM>w#w-d1e716-x2-3443</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t732-1">
   <w.rf>
    <LM>w#w-d1t732-1</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t732-2">
   <w.rf>
    <LM>w#w-d1t732-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m003-d-id79101-punct">
   <w.rf>
    <LM>w#w-d-id79101-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t732-4">
   <w.rf>
    <LM>w#w-d1t732-4</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m003-d1t732-5">
   <w.rf>
    <LM>w#w-d1t732-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m003-d1t732-6">
   <w.rf>
    <LM>w#w-d1t732-6</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m003-d1e716-x2-3445">
   <w.rf>
    <LM>w#w-d1e716-x2-3445</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t732-8">
   <w.rf>
    <LM>w#w-d1t732-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t732-9">
   <w.rf>
    <LM>w#w-d1t732-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t732-10">
   <w.rf>
    <LM>w#w-d1t732-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t732-11">
   <w.rf>
    <LM>w#w-d1t732-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m003-d1t732-12">
   <w.rf>
    <LM>w#w-d1t732-12</LM>
   </w.rf>
   <form>stihli</form>
   <lemma>stihnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m003-d-m-d1e716-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e716-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e733-x2">
  <m id="m003-d1t740-1">
   <w.rf>
    <LM>w#w-d1t740-1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t740-2">
   <w.rf>
    <LM>w#w-d1t740-2</LM>
   </w.rf>
   <form>věřící</form>
   <lemma>věřící_^(*3it)</lemma>
   <tag>AGFS1-----A----</tag>
  </m>
  <m id="m003-d-id79350-punct">
   <w.rf>
    <LM>w#w-d-id79350-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e741-x2">
  <m id="m003-d1t746-1">
   <w.rf>
    <LM>w#w-d1t746-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d-m-d1e741-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e741-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e747-x2">
  <m id="m003-d1t750-1">
   <w.rf>
    <LM>w#w-d1t750-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m003-d1t750-2">
   <w.rf>
    <LM>w#w-d1t750-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t750-3">
   <w.rf>
    <LM>w#w-d1t750-3</LM>
   </w.rf>
   <form>mívali</form>
   <lemma>mívat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t750-4">
   <w.rf>
    <LM>w#w-d1t750-4</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m003-d1t750-5">
   <w.rf>
    <LM>w#w-d1t750-5</LM>
   </w.rf>
   <form>štědrovečerní</form>
   <lemma>štědrovečerní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m003-d1t750-6">
   <w.rf>
    <LM>w#w-d1t750-6</LM>
   </w.rf>
   <form>večeři</form>
   <lemma>večeře</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m003-d-id79575-punct">
   <w.rf>
    <LM>w#w-d-id79575-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e751-x2">
  <m id="m003-d1t756-1">
   <w.rf>
    <LM>w#w-d1t756-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t756-2">
   <w.rf>
    <LM>w#w-d1t756-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m003-d1t756-3">
   <w.rf>
    <LM>w#w-d1t756-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t756-4">
   <w.rf>
    <LM>w#w-d1t756-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t756-5">
   <w.rf>
    <LM>w#w-d1t756-5</LM>
   </w.rf>
   <form>odbývá</form>
   <lemma>odbývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t756-6">
   <w.rf>
    <LM>w#w-d1t756-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t756-7">
   <w.rf>
    <LM>w#w-d1t756-7</LM>
   </w.rf>
   <form>klasika</form>
   <lemma>klasika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d1e751-x2-3507">
   <w.rf>
    <LM>w#w-d1e751-x2-3507</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t756-9">
   <w.rf>
    <LM>w#w-d1t756-9</LM>
   </w.rf>
   <form>rybí</form>
   <lemma>rybí</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m003-d1t756-10">
   <w.rf>
    <LM>w#w-d1t756-10</LM>
   </w.rf>
   <form>polévka</form>
   <lemma>polévka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d-id79794-punct">
   <w.rf>
    <LM>w#w-d-id79794-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t756-12">
   <w.rf>
    <LM>w#w-d1t756-12</LM>
   </w.rf>
   <form>kapr</form>
   <lemma>kapr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m003-d-id79818-punct">
   <w.rf>
    <LM>w#w-d-id79818-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t756-14">
   <w.rf>
    <LM>w#w-d1t756-14</LM>
   </w.rf>
   <form>salát</form>
   <lemma>salát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m003-d1e751-x2-3567">
   <w.rf>
    <LM>w#w-d1e751-x2-3567</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t762-3">
   <w.rf>
    <LM>w#w-d1t762-3</LM>
   </w.rf>
   <form>vánočka</form>
   <lemma>vánočka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d-m-d1e751-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e751-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e757-x3">
  <m id="m003-d1t764-1">
   <w.rf>
    <LM>w#w-d1t764-1</LM>
   </w.rf>
   <form>Kupujete</form>
   <lemma>kupovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t764-2">
   <w.rf>
    <LM>w#w-d1t764-2</LM>
   </w.rf>
   <form>živého</form>
   <lemma>živý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m003-d1t764-3">
   <w.rf>
    <LM>w#w-d1t764-3</LM>
   </w.rf>
   <form>kapra</form>
   <lemma>kapr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m003-d-id80018-punct">
   <w.rf>
    <LM>w#w-d-id80018-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e765-x2">
  <m id="m003-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d-id80095-punct">
   <w.rf>
    <LM>w#w-d-id80095-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t768-3">
   <w.rf>
    <LM>w#w-d1t768-3</LM>
   </w.rf>
   <form>kupujeme</form>
   <lemma>kupovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d-m-d1e765-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e765-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e769-x2">
  <m id="m003-d1t772-1">
   <w.rf>
    <LM>w#w-d1t772-1</LM>
   </w.rf>
   <form>Pečete</form>
   <lemma>péci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t772-2">
   <w.rf>
    <LM>w#w-d1t772-2</LM>
   </w.rf>
   <form>cukroví</form>
   <lemma>cukroví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m003-d-id80204-punct">
   <w.rf>
    <LM>w#w-d-id80204-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e773-x2">
  <m id="m003-d1t776-1">
   <w.rf>
    <LM>w#w-d1t776-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1e773-x2-3608">
   <w.rf>
    <LM>w#w-d1e773-x2-3608</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t778-2">
   <w.rf>
    <LM>w#w-d1t778-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m003-d-m-d1e773-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e773-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e780-x2">
  <m id="m003-d1t783-2">
   <w.rf>
    <LM>w#w-d1t783-2</LM>
   </w.rf>
   <form>Ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m003-d1e780-x2-3619">
   <w.rf>
    <LM>w#w-d1e780-x2-3619</LM>
   </w.rf>
   <form>pečete</form>
   <lemma>péci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d-id80411-punct">
   <w.rf>
    <LM>w#w-d-id80411-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e784-x2">
  <m id="m003-d1t787-1">
   <w.rf>
    <LM>w#w-d1t787-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1e784-x2-3634">
   <w.rf>
    <LM>w#w-d1e784-x2-3634</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m003-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>peču</form>
   <lemma>péci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>cukroví</form>
   <lemma>cukroví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m003-d-m-d1e784-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e784-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e788-x2">
  <m id="m003-d1t795-1">
   <w.rf>
    <LM>w#w-d1t795-1</LM>
   </w.rf>
   <form>Míváte</form>
   <lemma>mívat_^(*3t)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t795-2">
   <w.rf>
    <LM>w#w-d1t795-2</LM>
   </w.rf>
   <form>živý</form>
   <lemma>živý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m003-d1t795-3">
   <w.rf>
    <LM>w#w-d1t795-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t795-4">
   <w.rf>
    <LM>w#w-d1t795-4</LM>
   </w.rf>
   <form>umělý</form>
   <lemma>umělý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m003-d1t795-5">
   <w.rf>
    <LM>w#w-d1t795-5</LM>
   </w.rf>
   <form>stromeček</form>
   <lemma>stromeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m003-d-id80690-punct">
   <w.rf>
    <LM>w#w-d-id80690-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e796-x2">
  <m id="m003-d1t799-1">
   <w.rf>
    <LM>w#w-d1t799-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t799-2">
   <w.rf>
    <LM>w#w-d1t799-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m003-d1t799-3">
   <w.rf>
    <LM>w#w-d1t799-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t799-4">
   <w.rf>
    <LM>w#w-d1t799-4</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t799-5">
   <w.rf>
    <LM>w#w-d1t799-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t799-6">
   <w.rf>
    <LM>w#w-d1t799-6</LM>
   </w.rf>
   <form>živý</form>
   <lemma>živý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m003-d1t799-8">
   <w.rf>
    <LM>w#w-d1t799-8</LM>
   </w.rf>
   <form>smrček</form>
   <lemma>smrček</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m003-d-id80862-punct">
   <w.rf>
    <LM>w#w-d-id80862-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t799-10">
   <w.rf>
    <LM>w#w-d1t799-10</LM>
   </w.rf>
   <form>málokdy</form>
   <lemma>málokdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t799-11">
   <w.rf>
    <LM>w#w-d1t799-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m003-d1t799-12">
   <w.rf>
    <LM>w#w-d1t799-12</LM>
   </w.rf>
   <form>borovička</form>
   <lemma>borovička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m003-d-m-d1e796-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e796-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e800-x2">
  <m id="m003-d1t807-1">
   <w.rf>
    <LM>w#w-d1t807-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m003-d1t807-2">
   <w.rf>
    <LM>w#w-d1t807-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m003-d1t807-3">
   <w.rf>
    <LM>w#w-d1t807-3</LM>
   </w.rf>
   <form>myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m003-d1t807-4">
   <w.rf>
    <LM>w#w-d1t807-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t807-5">
   <w.rf>
    <LM>w#w-d1t807-5</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m003-d1t807-6">
   <w.rf>
    <LM>w#w-d1t807-6</LM>
   </w.rf>
   <form>umělých</form>
   <lemma>umělý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m003-d-id81087-punct">
   <w.rf>
    <LM>w#w-d-id81087-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e808-x2">
  <m id="m003-d1e808-x2-3717">
   <w.rf>
    <LM>w#w-d1e808-x2-3717</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d1e808-x2-3718">
   <w.rf>
    <LM>w#w-d1e808-x2-3718</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m003-d1e808-x2-3720">
   <w.rf>
    <LM>w#w-d1e808-x2-3720</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t811-1">
   <w.rf>
    <LM>w#w-d1t811-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t811-2">
   <w.rf>
    <LM>w#w-d1t811-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1t811-3">
   <w.rf>
    <LM>w#w-d1t811-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m003-d-id81189-punct">
   <w.rf>
    <LM>w#w-d-id81189-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t811-5">
   <w.rf>
    <LM>w#w-d1t811-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t811-6">
   <w.rf>
    <LM>w#w-d1t811-6</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m003-d1t811-7">
   <w.rf>
    <LM>w#w-d1t811-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m003-d1t811-8">
   <w.rf>
    <LM>w#w-d1t811-8</LM>
   </w.rf>
   <form>kouzlo</form>
   <lemma>kouzlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m003-d1t811-11">
   <w.rf>
    <LM>w#w-d1t811-11</LM>
   </w.rf>
   <form>Vánoc</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m003-d-m-d1e808-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e808-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e812-x2">
  <m id="m003-d1t815-1">
   <w.rf>
    <LM>w#w-d1t815-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m003-d1t815-2">
   <w.rf>
    <LM>w#w-d1t815-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m003-d1t815-3">
   <w.rf>
    <LM>w#w-d1t815-3</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d1t815-4">
   <w.rf>
    <LM>w#w-d1t815-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1e812-x2-3744">
   <w.rf>
    <LM>w#w-d1e812-x2-3744</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-3745">
  <m id="m003-d1t817-1">
   <w.rf>
    <LM>w#w-d1t817-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m003-d1t817-2">
   <w.rf>
    <LM>w#w-d1t817-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t817-3">
   <w.rf>
    <LM>w#w-d1t817-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m003-d1t817-4">
   <w.rf>
    <LM>w#w-d1t817-4</LM>
   </w.rf>
   <form>zdobil</form>
   <lemma>zdobit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m003-d1t817-5">
   <w.rf>
    <LM>w#w-d1t817-5</LM>
   </w.rf>
   <form>stromeček</form>
   <lemma>stromeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m003-d-id81516-punct">
   <w.rf>
    <LM>w#w-d-id81516-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e818-x2">
  <m id="m003-d1t823-1">
   <w.rf>
    <LM>w#w-d1t823-1</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t823-2">
   <w.rf>
    <LM>w#w-d1t823-2</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t825-1">
   <w.rf>
    <LM>w#w-d1t825-1</LM>
   </w.rf>
   <form>mužští</form>
   <lemma>mužský-2_^(osoba)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m003-d1e818-x2-3782">
   <w.rf>
    <LM>w#w-d1e818-x2-3782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t827-1">
   <w.rf>
    <LM>w#w-d1t827-1</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m003-d1t827-2">
   <w.rf>
    <LM>w#w-d1t827-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t827-3">
   <w.rf>
    <LM>w#w-d1t827-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m003-d1t827-4">
   <w.rf>
    <LM>w#w-d1t827-4</LM>
   </w.rf>
   <form>maminkou</form>
   <lemma>maminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m003-d1t827-5">
   <w.rf>
    <LM>w#w-d1t827-5</LM>
   </w.rf>
   <form>vařily</form>
   <lemma>vařit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m003-d1t827-6">
   <w.rf>
    <LM>w#w-d1t827-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t827-7">
   <w.rf>
    <LM>w#w-d1t827-7</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m003-d1t827-8">
   <w.rf>
    <LM>w#w-d1t827-8</LM>
   </w.rf>
   <form>zdobili</form>
   <lemma>zdobit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t827-9">
   <w.rf>
    <LM>w#w-d1t827-9</LM>
   </w.rf>
   <form>stromeček</form>
   <lemma>stromeček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m003-d-m-d1e818-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e818-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e828-x2">
  <m id="m003-d1t831-2">
   <w.rf>
    <LM>w#w-d1t831-2</LM>
   </w.rf>
   <form>Vrátíme</form>
   <lemma>vrátit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m003-d1t831-3">
   <w.rf>
    <LM>w#w-d1t831-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t831-4">
   <w.rf>
    <LM>w#w-d1t831-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m003-d1t831-5">
   <w.rf>
    <LM>w#w-d1t831-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m003-d-m-d1e828-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e828-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e838-x2">
  <m id="m003-d1t841-1">
   <w.rf>
    <LM>w#w-d1t841-1</LM>
   </w.rf>
   <form>Čí</form>
   <lemma>čí</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m003-d1t841-2">
   <w.rf>
    <LM>w#w-d1t841-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t841-3">
   <w.rf>
    <LM>w#w-d1t841-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t841-4">
   <w.rf>
    <LM>w#w-d1t841-4</LM>
   </w.rf>
   <form>pes</form>
   <lemma>pes_^(zvíře)</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m003-d-id82083-punct">
   <w.rf>
    <LM>w#w-d-id82083-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e843-x2">
  <m id="m003-d1t846-1">
   <w.rf>
    <LM>w#w-d1t846-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t846-2">
   <w.rf>
    <LM>w#w-d1t846-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t846-4">
   <w.rf>
    <LM>w#w-d1t846-4</LM>
   </w.rf>
   <form>Romanův</form>
   <lemma>Romanův_;Y_^(*2)_(*2o)_(*2us-1)</lemma>
   <tag>AUMS1M---------</tag>
  </m>
  <m id="m003-d1t846-6">
   <w.rf>
    <LM>w#w-d1t846-6</LM>
   </w.rf>
   <form>rotvajler</form>
   <lemma>rotvajler</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m003-d-m-d1e843-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e843-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e847-x2">
  <m id="m003-d1t850-1">
   <w.rf>
    <LM>w#w-d1t850-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m003-d1t850-2">
   <w.rf>
    <LM>w#w-d1t850-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t850-3">
   <w.rf>
    <LM>w#w-d1t850-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t850-4">
   <w.rf>
    <LM>w#w-d1t850-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t850-5">
   <w.rf>
    <LM>w#w-d1t850-5</LM>
   </w.rf>
   <form>rasu</form>
   <lemma>rasa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d-id82354-punct">
   <w.rf>
    <LM>w#w-d-id82354-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e851-x2">
  <m id="m003-d1t854-1">
   <w.rf>
    <LM>w#w-d1t854-1</LM>
   </w.rf>
   <form>Rotvajler</form>
   <lemma>rotvajler</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m003-d-m-d1e851-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e851-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e855-x2">
  <m id="m003-d1t858-1">
   <w.rf>
    <LM>w#w-d1t858-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t858-2">
   <w.rf>
    <LM>w#w-d1t858-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t858-3">
   <w.rf>
    <LM>w#w-d1t858-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m003-d1t858-4">
   <w.rf>
    <LM>w#w-d1t858-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m003-d1t858-5">
   <w.rf>
    <LM>w#w-d1t858-5</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m003-d1t858-6">
   <w.rf>
    <LM>w#w-d1t858-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t858-7">
   <w.rf>
    <LM>w#w-d1t858-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m003-d1t858-8">
   <w.rf>
    <LM>w#w-d1t858-8</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m003-d-id82602-punct">
   <w.rf>
    <LM>w#w-d-id82602-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e859-x2">
  <m id="m003-d1t864-1">
   <w.rf>
    <LM>w#w-d1t864-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m003-d-id82688-punct">
   <w.rf>
    <LM>w#w-d-id82688-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t864-3">
   <w.rf>
    <LM>w#w-d1t864-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t864-4">
   <w.rf>
    <LM>w#w-d1t864-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m003-d1e859-x2-3891">
   <w.rf>
    <LM>w#w-d1e859-x2-3891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t864-6">
   <w.rf>
    <LM>w#w-d1t864-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t864-7">
   <w.rf>
    <LM>w#w-d1t864-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d-id82767-punct">
   <w.rf>
    <LM>w#w-d-id82767-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t864-9">
   <w.rf>
    <LM>w#w-d1t864-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m003-d1t864-10">
   <w.rf>
    <LM>w#w-d1t864-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t864-11">
   <w.rf>
    <LM>w#w-d1t864-11</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1t864-12">
   <w.rf>
    <LM>w#w-d1t864-12</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m003-d-m-d1e859-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e859-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e865-x2">
  <m id="m003-d1t872-1">
   <w.rf>
    <LM>w#w-d1t872-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m003-d1t872-2">
   <w.rf>
    <LM>w#w-d1t872-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t872-3">
   <w.rf>
    <LM>w#w-d1t872-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m003-d1t872-4">
   <w.rf>
    <LM>w#w-d1t872-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m003-d1t872-5">
   <w.rf>
    <LM>w#w-d1t872-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m003-d-m-d1e865-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e865-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e873-x2">
  <m id="m003-d1t876-1">
   <w.rf>
    <LM>w#w-d1t876-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d-m-d1e873-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e873-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e877-x2">
  <m id="m003-d1t880-1">
   <w.rf>
    <LM>w#w-d1t880-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m003-d1t880-2">
   <w.rf>
    <LM>w#w-d1t880-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t880-3">
   <w.rf>
    <LM>w#w-d1t880-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m003-d1t880-4">
   <w.rf>
    <LM>w#w-d1t880-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m003-d1t880-5">
   <w.rf>
    <LM>w#w-d1t880-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m003-d-id83184-punct">
   <w.rf>
    <LM>w#w-d-id83184-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e881-x2">
  <m id="m003-d1t888-1">
   <w.rf>
    <LM>w#w-d1t888-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t888-2">
   <w.rf>
    <LM>w#w-d1t888-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1t888-3">
   <w.rf>
    <LM>w#w-d1t888-3</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHP1-P1-------</tag>
  </m>
  <m id="m003-d1t888-4">
   <w.rf>
    <LM>w#w-d1t888-4</LM>
   </w.rf>
   <form>štěňátka</form>
   <lemma>štěňátko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m003-d-id83326-punct">
   <w.rf>
    <LM>w#w-d-id83326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t888-6">
   <w.rf>
    <LM>w#w-d1t888-6</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4NP1----------</tag>
  </m>
  <m id="m003-d1t888-7">
   <w.rf>
    <LM>w#w-d1t888-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m003-d1t888-8">
   <w.rf>
    <LM>w#w-d1t888-8</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t888-9">
   <w.rf>
    <LM>w#w-d1t888-9</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m003-d-m-d1e881-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e881-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e889-x2">
  <m id="m003-d1t892-1">
   <w.rf>
    <LM>w#w-d1t892-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m003-d1t892-2">
   <w.rf>
    <LM>w#w-d1t892-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t892-4">
   <w.rf>
    <LM>w#w-d1t892-4</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m003-d1t892-5">
   <w.rf>
    <LM>w#w-d1t892-5</LM>
   </w.rf>
   <form>štěňátka</form>
   <lemma>štěňátko</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m003-d-m-d1e889-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e889-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e893-x2">
  <m id="m003-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1e893-x2-3987">
   <w.rf>
    <LM>w#w-d1e893-x2-3987</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t904-1">
   <w.rf>
    <LM>w#w-d1t904-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t904-2">
   <w.rf>
    <LM>w#w-d1t904-2</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t904-3">
   <w.rf>
    <LM>w#w-d1t904-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t904-4">
   <w.rf>
    <LM>w#w-d1t904-4</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS4----------</tag>
  </m>
  <m id="m003-d1e893-x2-3988">
   <w.rf>
    <LM>w#w-d1e893-x2-3988</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1e893-x2-3989">
   <w.rf>
    <LM>w#w-d1e893-x2-3989</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m003-d1t907-1">
   <w.rf>
    <LM>w#w-d1t907-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t907-2">
   <w.rf>
    <LM>w#w-d1t907-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m003-d1t907-3">
   <w.rf>
    <LM>w#w-d1t907-3</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m003-d-m-d1e893-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e893-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e909-x2">
  <m id="m003-d1t912-1">
   <w.rf>
    <LM>w#w-d1t912-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m003-d1t912-2">
   <w.rf>
    <LM>w#w-d1t912-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m003-d1t912-3">
   <w.rf>
    <LM>w#w-d1t912-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m003-d1t912-4">
   <w.rf>
    <LM>w#w-d1t912-4</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m003-d1t912-5">
   <w.rf>
    <LM>w#w-d1t912-5</LM>
   </w.rf>
   <form>ostatními</form>
   <lemma>ostatní</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m003-d-id83885-punct">
   <w.rf>
    <LM>w#w-d-id83885-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e913-x2">
  <m id="m003-d1t918-1">
   <w.rf>
    <LM>w#w-d1t918-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDNP1----------</tag>
  </m>
  <m id="m003-d1t918-2">
   <w.rf>
    <LM>w#w-d1t918-2</LM>
   </w.rf>
   <form>ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m003-d1t918-3">
   <w.rf>
    <LM>w#w-d1t918-3</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m003-d1t918-4">
   <w.rf>
    <LM>w#w-d1t918-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t918-5">
   <w.rf>
    <LM>w#w-d1t918-5</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m003-d-id84033-punct">
   <w.rf>
    <LM>w#w-d-id84033-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t918-7">
   <w.rf>
    <LM>w#w-d1t918-7</LM>
   </w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m003-d1t918-8">
   <w.rf>
    <LM>w#w-d1t918-8</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t918-9">
   <w.rf>
    <LM>w#w-d1t918-9</LM>
   </w.rf>
   <form>jinam</form>
   <lemma>jinam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1e913-x2-4038">
   <w.rf>
    <LM>w#w-d1e913-x2-4038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t920-3">
   <w.rf>
    <LM>w#w-d1t920-3</LM>
   </w.rf>
   <form>všechna</form>
   <lemma>všechen</lemma>
   <tag>PLNP1----------</tag>
  </m>
  <m id="m003-d1t920-4">
   <w.rf>
    <LM>w#w-d1t920-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m003-d1t920-5">
   <w.rf>
    <LM>w#w-d1t920-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t920-6">
   <w.rf>
    <LM>w#w-d1t920-6</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d-m-d1e913-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e913-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e921-x2">
  <m id="m003-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m003-d1t924-2">
   <w.rf>
    <LM>w#w-d1t924-2</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d-id84289-punct">
   <w.rf>
    <LM>w#w-d-id84289-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m003-d1e925-x2">
  <m id="m003-d1t930-2">
   <w.rf>
    <LM>w#w-d1t930-2</LM>
   </w.rf>
   <form>Jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m003-d1t930-3">
   <w.rf>
    <LM>w#w-d1t930-3</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m003-d1t930-4">
   <w.rf>
    <LM>w#w-d1t930-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t930-6">
   <w.rf>
    <LM>w#w-d1t930-6</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m003-d1e925-x2-4143">
   <w.rf>
    <LM>w#w-d1e925-x2-4143</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t932-1">
   <w.rf>
    <LM>w#w-d1t932-1</LM>
   </w.rf>
   <form>jedno</form>
   <lemma>jeden`1</lemma>
   <tag>CnNS1----------</tag>
  </m>
  <m id="m003-d1t932-2">
   <w.rf>
    <LM>w#w-d1t932-2</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m003-d1t934-1">
   <w.rf>
    <LM>w#w-d1t934-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t934-3">
   <w.rf>
    <LM>w#w-d1t934-3</LM>
   </w.rf>
   <form>Chlumčan</form>
   <lemma>Chlumčany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m003-d1e925-x2-4144">
   <w.rf>
    <LM>w#w-d1e925-x2-4144</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t936-3">
   <w.rf>
    <LM>w#w-d1t936-3</LM>
   </w.rf>
   <form>Staňkova</form>
   <lemma>Staňkov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m003-d1e925-x2-4145">
   <w.rf>
    <LM>w#w-d1e925-x2-4145</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t941-1">
   <w.rf>
    <LM>w#w-d1t941-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m003-d1t941-2">
   <w.rf>
    <LM>w#w-d1t941-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t941-3">
   <w.rf>
    <LM>w#w-d1t941-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m003-d1t941-4">
   <w.rf>
    <LM>w#w-d1t941-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m003-d-id84688-punct">
   <w.rf>
    <LM>w#w-d-id84688-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t941-6">
   <w.rf>
    <LM>w#w-d1t941-6</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t941-8">
   <w.rf>
    <LM>w#w-d1t941-8</LM>
   </w.rf>
   <form>všechna</form>
   <lemma>všechen</lemma>
   <tag>PLNP1----------</tag>
  </m>
  <m id="m003-d1t941-7">
   <w.rf>
    <LM>w#w-d1t941-7</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m003-d1e925-x2-4257">
   <w.rf>
    <LM>w#w-d1e925-x2-4257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m003-d1t955-8">
   <w.rf>
    <LM>w#w-d1t955-8</LM>
   </w.rf>
   <form>rozdali</form>
   <lemma>rozdat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m003-d1t955-6">
   <w.rf>
    <LM>w#w-d1t955-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m003-d1t955-7">
   <w.rf>
    <LM>w#w-d1t955-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m003-d1t955-5">
   <w.rf>
    <LM>w#w-d1t955-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m003-d1t955-1">
   <w.rf>
    <LM>w#w-d1t955-1</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m003-d1t955-3">
   <w.rf>
    <LM>w#w-d1t955-3</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m003-d-m-d1e925-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e925-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
