<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_036.03.w.gz" />
  </references>
 </head>
 <s id="m036-d1e723-x2">
  <m id="m036-d1t726-1">
   <w.rf>
    <LM>w#w-d1t726-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t726-2">
   <w.rf>
    <LM>w#w-d1t726-2</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t726-3">
   <w.rf>
    <LM>w#w-d1t726-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t726-4">
   <w.rf>
    <LM>w#w-d1t726-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m036-d-id76673-punct">
   <w.rf>
    <LM>w#w-d-id76673-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e727-x2">
  <m id="m036-d1t730-2">
   <w.rf>
    <LM>w#w-d1t730-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t730-4">
   <w.rf>
    <LM>w#w-d1t730-4</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m036-d-id76799-punct">
   <w.rf>
    <LM>w#w-d-id76799-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t730-8">
   <w.rf>
    <LM>w#w-d1t730-8</LM>
   </w.rf>
   <form>Rakousku</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m036-d-id76841-punct">
   <w.rf>
    <LM>w#w-d-id76841-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t730-12">
   <w.rf>
    <LM>w#w-d1t730-12</LM>
   </w.rf>
   <form>Francii</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m036-d-id76892-punct">
   <w.rf>
    <LM>w#w-d-id76892-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t732-4">
   <w.rf>
    <LM>w#w-d1t732-4</LM>
   </w.rf>
   <form>Chorvatsku</form>
   <lemma>Chorvatsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m036-d-id76934-punct">
   <w.rf>
    <LM>w#w-d-id76934-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t732-7">
   <w.rf>
    <LM>w#w-d1t732-7</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m036-d1t732-8">
   <w.rf>
    <LM>w#w-d1t732-8</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m036-d1e727-x2-362">
   <w.rf>
    <LM>w#w-d1e727-x2-362</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t732-9">
   <w.rf>
    <LM>w#w-d1t732-9</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t732-10">
   <w.rf>
    <LM>w#w-d1t732-10</LM>
   </w.rf>
   <form>všude</form>
   <lemma>všude</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d-id77004-punct">
   <w.rf>
    <LM>w#w-d-id77004-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t732-12">
   <w.rf>
    <LM>w#w-d1t732-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t732-13">
   <w.rf>
    <LM>w#w-d1t732-13</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t732-15">
   <w.rf>
    <LM>w#w-d1t732-15</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m036-d-m-d1e727-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e727-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e733-x2">
  <m id="m036-d1t736-1">
   <w.rf>
    <LM>w#w-d1t736-1</LM>
   </w.rf>
   <form>Baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t736-2">
   <w.rf>
    <LM>w#w-d1t736-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m036-d1t736-3">
   <w.rf>
    <LM>w#w-d1t736-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d-id77170-punct">
   <w.rf>
    <LM>w#w-d-id77170-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e737-x2">
  <m id="m036-d1t742-1">
   <w.rf>
    <LM>w#w-d1t742-1</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d-id77256-punct">
   <w.rf>
    <LM>w#w-d-id77256-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t744-1">
   <w.rf>
    <LM>w#w-d1t744-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t744-2">
   <w.rf>
    <LM>w#w-d1t744-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t744-3">
   <w.rf>
    <LM>w#w-d1t744-3</LM>
   </w.rf>
   <form>dobrá</form>
   <lemma>dobrý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m036-d1t744-4">
   <w.rf>
    <LM>w#w-d1t744-4</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m036-d1e737-x2-19">
   <w.rf>
    <LM>w#w-d1e737-x2-19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-20">
  <m id="m036-d1t744-7">
   <w.rf>
    <LM>w#w-d1t744-7</LM>
   </w.rf>
   <form>Jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t744-8">
   <w.rf>
    <LM>w#w-d1t744-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t744-9">
   <w.rf>
    <LM>w#w-d1t744-9</LM>
   </w.rf>
   <form>řidič</form>
   <lemma>řidič</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m036-d1t744-10">
   <w.rf>
    <LM>w#w-d1t744-10</LM>
   </w.rf>
   <form>autobusu</form>
   <lemma>autobus</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m036-d1t744-11">
   <w.rf>
    <LM>w#w-d1t744-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t744-13">
   <w.rf>
    <LM>w#w-d1t744-13</LM>
   </w.rf>
   <form>vozí</form>
   <lemma>vozit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t744-14">
   <w.rf>
    <LM>w#w-d1t744-14</LM>
   </w.rf>
   <form>turisty</form>
   <lemma>turista</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m036-d-m-d1e737-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e737-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e745-x2">
  <m id="m036-d1t748-1">
   <w.rf>
    <LM>w#w-d1t748-1</LM>
   </w.rf>
   <form>Vypráví</form>
   <lemma>vyprávět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t748-2">
   <w.rf>
    <LM>w#w-d1t748-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m036-d1t748-3">
   <w.rf>
    <LM>w#w-d1t748-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m036-d1t748-4">
   <w.rf>
    <LM>w#w-d1t748-4</LM>
   </w.rf>
   <form>historky</form>
   <lemma>historka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m036-d1t748-5">
   <w.rf>
    <LM>w#w-d1t748-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m036-d1t748-6">
   <w.rf>
    <LM>w#w-d1t748-6</LM>
   </w.rf>
   <form>cest</form>
   <lemma>cesta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m036-d-id77623-punct">
   <w.rf>
    <LM>w#w-d-id77623-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e749-x2">
  <m id="m036-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>Vypráví</form>
   <lemma>vyprávět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1e749-x2-32">
   <w.rf>
    <LM>w#w-d1e749-x2-32</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-31">
  <m id="m036-d1t752-7">
   <w.rf>
    <LM>w#w-d1t752-7</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>zabloudil</form>
   <lemma>zabloudit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m036-d-id77795-punct">
   <w.rf>
    <LM>w#w-d-id77795-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t752-10">
   <w.rf>
    <LM>w#w-d1t752-10</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m036-d1t752-11">
   <w.rf>
    <LM>w#w-d1t752-11</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m036-d1t752-12">
   <w.rf>
    <LM>w#w-d1t752-12</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m036-d1t752-14">
   <w.rf>
    <LM>w#w-d1t752-14</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t752-15">
   <w.rf>
    <LM>w#w-d1t752-15</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m036-d1t752-13">
   <w.rf>
    <LM>w#w-d1t752-13</LM>
   </w.rf>
   <form>provedl</form>
   <lemma>provést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m036-d-id77896-punct">
   <w.rf>
    <LM>w#w-d-id77896-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t752-17">
   <w.rf>
    <LM>w#w-d1t752-17</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t752-18">
   <w.rf>
    <LM>w#w-d1t752-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m036-d1t752-19">
   <w.rf>
    <LM>w#w-d1t752-19</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t752-20">
   <w.rf>
    <LM>w#w-d1t752-20</LM>
   </w.rf>
   <form>zastavit</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m036-d-id77967-punct">
   <w.rf>
    <LM>w#w-d-id77967-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t752-22">
   <w.rf>
    <LM>w#w-d1t752-22</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t752-23">
   <w.rf>
    <LM>w#w-d1t752-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m036-d1t752-24">
   <w.rf>
    <LM>w#w-d1t752-24</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m036-d1t752-25">
   <w.rf>
    <LM>w#w-d1t752-25</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m036-d1t752-26">
   <w.rf>
    <LM>w#w-d1t752-26</LM>
   </w.rf>
   <form>chovají</form>
   <lemma>chovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t754-1">
   <w.rf>
    <LM>w#w-d1t754-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t754-2">
   <w.rf>
    <LM>w#w-d1t754-2</LM>
   </w.rf>
   <form>zahraničí</form>
   <lemma>zahraničí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m036-d-id78079-punct">
   <w.rf>
    <LM>w#w-d-id78079-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t754-4">
   <w.rf>
    <LM>w#w-d1t754-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t754-5">
   <w.rf>
    <LM>w#w-d1t754-5</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t754-6">
   <w.rf>
    <LM>w#w-d1t754-6</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m036-d1t754-8">
   <w.rf>
    <LM>w#w-d1t754-8</LM>
   </w.rf>
   <form>Čechy</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m036-d-id78168-punct">
   <w.rf>
    <LM>w#w-d-id78168-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t754-11">
   <w.rf>
    <LM>w#w-d1t754-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t754-12">
   <w.rf>
    <LM>w#w-d1t754-12</LM>
   </w.rf>
   <form>různě</form>
   <lemma>různě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-m-d1e749-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e749-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e755-x2">
  <m id="m036-d1t758-1">
   <w.rf>
    <LM>w#w-d1t758-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t758-2">
   <w.rf>
    <LM>w#w-d1t758-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t758-3">
   <w.rf>
    <LM>w#w-d1t758-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m036-d1e755-x2-42">
   <w.rf>
    <LM>w#w-d1e755-x2-42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-43">
  <m id="m036-d1t760-4">
   <w.rf>
    <LM>w#w-d1t760-4</LM>
   </w.rf>
   <form>Povězte</form>
   <lemma>povědět</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m036-d1t760-2">
   <w.rf>
    <LM>w#w-d1t760-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m036-d1t760-3">
   <w.rf>
    <LM>w#w-d1t760-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m036-d-m-d1e755-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e755-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e762-x2">
  <m id="m036-d1t765-1">
   <w.rf>
    <LM>w#w-d1t765-1</LM>
   </w.rf>
   <form>Například</form>
   <lemma>například</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1t765-3">
   <w.rf>
    <LM>w#w-d1t765-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t765-5">
   <w.rf>
    <LM>w#w-d1t765-5</LM>
   </w.rf>
   <form>Francouzi</form>
   <lemma>Francouz_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m036-d-id78510-punct">
   <w.rf>
    <LM>w#w-d-id78510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t765-8">
   <w.rf>
    <LM>w#w-d1t765-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t765-9">
   <w.rf>
    <LM>w#w-d1t765-9</LM>
   </w.rf>
   <form>promluvíte</form>
   <lemma>promluvit</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m036-d1t765-10">
   <w.rf>
    <LM>w#w-d1t765-10</LM>
   </w.rf>
   <form>česky</form>
   <lemma>česky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-id78565-punct">
   <w.rf>
    <LM>w#w-d-id78565-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t765-12">
   <w.rf>
    <LM>w#w-d1t765-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1t765-13">
   <w.rf>
    <LM>w#w-d1t765-13</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m036-d1t765-15">
   <w.rf>
    <LM>w#w-d1t765-15</LM>
   </w.rf>
   <form>nemají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m036-d1t765-14">
   <w.rf>
    <LM>w#w-d1t765-14</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m036-d1e762-x2-55">
   <w.rf>
    <LM>w#w-d1e762-x2-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-56">
  <m id="m036-d1t765-17">
   <w.rf>
    <LM>w#w-d1t765-17</LM>
   </w.rf>
   <form>Uznávají</form>
   <lemma>uznávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t765-18">
   <w.rf>
    <LM>w#w-d1t765-18</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t765-19">
   <w.rf>
    <LM>w#w-d1t765-19</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m036-d-id78692-punct">
   <w.rf>
    <LM>w#w-d-id78692-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t765-21">
   <w.rf>
    <LM>w#w-d1t765-21</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m036-d1t765-22">
   <w.rf>
    <LM>w#w-d1t765-22</LM>
   </w.rf>
   <form>mluví</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t765-23">
   <w.rf>
    <LM>w#w-d1t765-23</LM>
   </w.rf>
   <form>francouzsky</form>
   <lemma>francouzsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-56-57">
   <w.rf>
    <LM>w#w-56-57</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-58">
  <m id="m036-d1t765-26">
   <w.rf>
    <LM>w#w-d1t765-26</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m036-d1t765-28">
   <w.rf>
    <LM>w#w-d1t765-28</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t765-29">
   <w.rf>
    <LM>w#w-d1t765-29</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t765-30">
   <w.rf>
    <LM>w#w-d1t765-30</LM>
   </w.rf>
   <form>nabubřelí</form>
   <lemma>nabubřelý_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m036-d-id78835-punct">
   <w.rf>
    <LM>w#w-d-id78835-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t765-32">
   <w.rf>
    <LM>w#w-d1t765-32</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t765-33">
   <w.rf>
    <LM>w#w-d1t765-33</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t765-34">
   <w.rf>
    <LM>w#w-d1t765-34</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d-m-d1e762-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e762-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e766-x2">
  <m id="m036-d1t771-2">
   <w.rf>
    <LM>w#w-d1t771-2</LM>
   </w.rf>
   <form>Chorvati</form>
   <lemma>Chorvat_;E</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m036-d1t771-4">
   <w.rf>
    <LM>w#w-d1t771-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t771-5">
   <w.rf>
    <LM>w#w-d1t771-5</LM>
   </w.rf>
   <form>vstřícní</form>
   <lemma>vstřícný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m036-d1e766-x2-63">
   <w.rf>
    <LM>w#w-d1e766-x2-63</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t779-1">
   <w.rf>
    <LM>w#w-d1t779-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t779-3">
   <w.rf>
    <LM>w#w-d1t779-3</LM>
   </w.rf>
   <form>zlodějíčkové</form>
   <lemma>zlodějíček</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m036-d-m-d1e776-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e776-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e780-x2">
  <m id="m036-d1t787-1">
   <w.rf>
    <LM>w#w-d1t787-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m036-d1t787-2">
   <w.rf>
    <LM>w#w-d1t787-2</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t787-3">
   <w.rf>
    <LM>w#w-d1t787-3</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m036-d1t787-4">
   <w.rf>
    <LM>w#w-d1t787-4</LM>
   </w.rf>
   <form>nehodu</form>
   <lemma>nehoda_^(př._automobilová,_cokoliv_nepříjemného)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m036-d-id79268-punct">
   <w.rf>
    <LM>w#w-d-id79268-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e788-x2">
  <m id="m036-d1t791-1">
   <w.rf>
    <LM>w#w-d1t791-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d-id79345-punct">
   <w.rf>
    <LM>w#w-d-id79345-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t791-3">
   <w.rf>
    <LM>w#w-d1t791-3</LM>
   </w.rf>
   <form>zaplať</form>
   <lemma>zaplatit</lemma>
   <tag>Vi-S---3--A-P-4</tag>
  </m>
  <m id="m036-d1t791-4">
   <w.rf>
    <LM>w#w-d1t791-4</LM>
   </w.rf>
   <form>pánbůh</form>
   <lemma>pánbůh</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m036-d1t791-5">
   <w.rf>
    <LM>w#w-d1t791-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d-m-d1e788-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e788-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e792-x2">
  <m id="m036-d1t795-1">
   <w.rf>
    <LM>w#w-d1t795-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t795-2">
   <w.rf>
    <LM>w#w-d1t795-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t795-3">
   <w.rf>
    <LM>w#w-d1t795-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-m-d1e792-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e792-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e796-x2">
  <m id="m036-d1t801-4">
   <w.rf>
    <LM>w#w-d1t801-4</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1e796-x2-68">
   <w.rf>
    <LM>w#w-d1e796-x2-68</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t801-2">
   <w.rf>
    <LM>w#w-d1t801-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t801-1">
   <w.rf>
    <LM>w#w-d1t801-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t801-3">
   <w.rf>
    <LM>w#w-d1t801-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1e796-x2-69">
   <w.rf>
    <LM>w#w-d1e796-x2-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-70">
  <m id="m036-d1t801-6">
   <w.rf>
    <LM>w#w-d1t801-6</LM>
   </w.rf>
   <form>Doufejme</form>
   <lemma>doufat</lemma>
   <tag>Vi-P---1--A-I--</tag>
  </m>
  <m id="m036-d-id79648-punct">
   <w.rf>
    <LM>w#w-d-id79648-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t801-8">
   <w.rf>
    <LM>w#w-d1t801-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t801-9">
   <w.rf>
    <LM>w#w-d1t801-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t801-10">
   <w.rf>
    <LM>w#w-d1t801-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t801-11">
   <w.rf>
    <LM>w#w-d1t801-11</LM>
   </w.rf>
   <form>zůstane</form>
   <lemma>zůstat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m036-d-m-d1e796-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e796-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e802-x2">
  <m id="m036-d1t805-1">
   <w.rf>
    <LM>w#w-d1t805-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m036-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>synové</form>
   <lemma>syn</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m036-d1t805-2">
   <w.rf>
    <LM>w#w-d1t805-2</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m036-d-id79833-punct">
   <w.rf>
    <LM>w#w-d-id79833-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e806-x2">
  <m id="m036-d1t811-1">
   <w.rf>
    <LM>w#w-d1t811-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t811-3">
   <w.rf>
    <LM>w#w-d1t811-3</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m036-d1t813-1">
   <w.rf>
    <LM>w#w-d1t813-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t813-3">
   <w.rf>
    <LM>w#w-d1t813-3</LM>
   </w.rf>
   <form>Lochotíně</form>
   <lemma>Lochotín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m036-d-m-d1e806-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e806-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e814-x2">
  <m id="m036-d1t819-1">
   <w.rf>
    <LM>w#w-d1t819-1</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m036-d1t819-2">
   <w.rf>
    <LM>w#w-d1t819-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m036-d1t819-3">
   <w.rf>
    <LM>w#w-d1t819-3</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-m-d1e814-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e814-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e814-x3">
  <m id="m036-d1t821-1">
   <w.rf>
    <LM>w#w-d1t821-1</LM>
   </w.rf>
   <form>Vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m036-d1t821-2">
   <w.rf>
    <LM>w#w-d1t821-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m036-d1t821-3">
   <w.rf>
    <LM>w#w-d1t821-3</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-id80148-punct">
   <w.rf>
    <LM>w#w-d-id80148-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e822-x2">
  <m id="m036-d1t825-1">
   <w.rf>
    <LM>w#w-d1t825-1</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1t825-2">
   <w.rf>
    <LM>w#w-d1t825-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d-id80280-punct">
   <w.rf>
    <LM>w#w-d-id80280-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t825-7">
   <w.rf>
    <LM>w#w-d1t825-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t825-8">
   <w.rf>
    <LM>w#w-d1t825-8</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t825-9">
   <w.rf>
    <LM>w#w-d1t825-9</LM>
   </w.rf>
   <form>pracovně</form>
   <lemma>pracovně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t825-10">
   <w.rf>
    <LM>w#w-d1t825-10</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t825-11">
   <w.rf>
    <LM>w#w-d1t825-11</LM>
   </w.rf>
   <form>vytížení</form>
   <lemma>vytížený_^(*3it)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m036-d1e822-x2-82">
   <w.rf>
    <LM>w#w-d1e822-x2-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-83">
  <m id="m036-d1t825-13">
   <w.rf>
    <LM>w#w-d1t825-13</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t825-14">
   <w.rf>
    <LM>w#w-d1t825-14</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m036-d1t825-15">
   <w.rf>
    <LM>w#w-d1t825-15</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m036-d-id80422-punct">
   <w.rf>
    <LM>w#w-d-id80422-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t825-17">
   <w.rf>
    <LM>w#w-d1t825-17</LM>
   </w.rf>
   <form>tuším</form>
   <lemma>tušit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m036-d1t825-18">
   <w.rf>
    <LM>w#w-d1t825-18</LM>
   </w.rf>
   <form>průšvih</form>
   <lemma>průšvih</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m036-d-m-d1e822-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e822-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e827-x2">
  <m id="m036-d1t834-1">
   <w.rf>
    <LM>w#w-d1t834-1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t834-2">
   <w.rf>
    <LM>w#w-d1t834-2</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t834-3">
   <w.rf>
    <LM>w#w-d1t834-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t834-4">
   <w.rf>
    <LM>w#w-d1t834-4</LM>
   </w.rf>
   <form>cestách</form>
   <lemma>cesta</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m036-d-id80601-punct">
   <w.rf>
    <LM>w#w-d-id80601-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e835-x2">
  <m id="m036-d1t838-1">
   <w.rf>
    <LM>w#w-d1t838-1</LM>
   </w.rf>
   <form>Dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d-m-d1e835-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e835-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e839-x2">
  <m id="m036-d1t842-1">
   <w.rf>
    <LM>w#w-d1t842-1</LM>
   </w.rf>
   <form>Váže</form>
   <lemma>vázat</lemma>
   <tag>VB-S---3P-AAI-1</tag>
  </m>
  <m id="m036-d1t842-2">
   <w.rf>
    <LM>w#w-d1t842-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m036-d1t842-3">
   <w.rf>
    <LM>w#w-d1t842-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t842-4">
   <w.rf>
    <LM>w#w-d1t842-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m036-d1t842-5">
   <w.rf>
    <LM>w#w-d1t842-5</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m036-d1t842-6">
   <w.rf>
    <LM>w#w-d1t842-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m036-d1t842-7">
   <w.rf>
    <LM>w#w-d1t842-7</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m036-d1t842-8">
   <w.rf>
    <LM>w#w-d1t842-8</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m036-d-id80849-punct">
   <w.rf>
    <LM>w#w-d-id80849-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e843-x2">
  <m id="m036-d1t846-1">
   <w.rf>
    <LM>w#w-d1t846-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m036-d1t846-7">
   <w.rf>
    <LM>w#w-d1t846-7</LM>
   </w.rf>
   <form>zajímavého</form>
   <lemma>zajímavý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m036-d1t846-2">
   <w.rf>
    <LM>w#w-d1t846-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m036-d1t846-3">
   <w.rf>
    <LM>w#w-d1t846-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m036-d1t846-4">
   <w.rf>
    <LM>w#w-d1t846-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m036-d1t846-5">
   <w.rf>
    <LM>w#w-d1t846-5</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3-------</tag>
  </m>
  <m id="m036-d1t846-8">
   <w.rf>
    <LM>w#w-d1t846-8</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m036-d1t846-6">
   <w.rf>
    <LM>w#w-d1t846-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t846-9">
   <w.rf>
    <LM>w#w-d1t846-9</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m036-d-id81030-punct">
   <w.rf>
    <LM>w#w-d-id81030-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-93">
  <m id="m036-d1t850-3">
   <w.rf>
    <LM>w#w-d1t850-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m036-d1t850-2">
   <w.rf>
    <LM>w#w-d1t850-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t850-4">
   <w.rf>
    <LM>w#w-d1t850-4</LM>
   </w.rf>
   <form>chudá</form>
   <lemma>chudý-1</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m036-d1t850-5">
   <w.rf>
    <LM>w#w-d1t850-5</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m036-d-id81141-punct">
   <w.rf>
    <LM>w#w-d-id81141-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t850-7">
   <w.rf>
    <LM>w#w-d1t850-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t850-8">
   <w.rf>
    <LM>w#w-d1t850-8</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m036-d1t850-9">
   <w.rf>
    <LM>w#w-d1t850-9</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m036-d1t850-10">
   <w.rf>
    <LM>w#w-d1t850-10</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m036-d1t850-12">
   <w.rf>
    <LM>w#w-d1t850-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t850-13">
   <w.rf>
    <LM>w#w-d1t850-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t850-14">
   <w.rf>
    <LM>w#w-d1t850-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t850-15">
   <w.rf>
    <LM>w#w-d1t850-15</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m036-93-101">
   <w.rf>
    <LM>w#w-93-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-102">
  <m id="m036-d1t852-1">
   <w.rf>
    <LM>w#w-d1t852-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t852-2">
   <w.rf>
    <LM>w#w-d1t852-2</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m036-d1t852-3">
   <w.rf>
    <LM>w#w-d1t852-3</LM>
   </w.rf>
   <form>starostí</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m036-d-id81333-punct">
   <w.rf>
    <LM>w#w-d-id81333-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t852-5">
   <w.rf>
    <LM>w#w-d1t852-5</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m036-d1t852-6">
   <w.rf>
    <LM>w#w-d1t852-6</LM>
   </w.rf>
   <form>sháňky</form>
   <lemma>sháňka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m036-d1t852-7">
   <w.rf>
    <LM>w#w-d1t852-7</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m036-d1t852-8">
   <w.rf>
    <LM>w#w-d1t852-8</LM>
   </w.rf>
   <form>penězích</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m036-d-id81404-punct">
   <w.rf>
    <LM>w#w-d-id81404-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t852-10">
   <w.rf>
    <LM>w#w-d1t852-10</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m036-d1t852-12">
   <w.rf>
    <LM>w#w-d1t852-12</LM>
   </w.rf>
   <form>nepracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m036-d1t852-11">
   <w.rf>
    <LM>w#w-d1t852-11</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t852-13">
   <w.rf>
    <LM>w#w-d1t852-13</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t852-14">
   <w.rf>
    <LM>w#w-d1t852-14</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-102-107">
   <w.rf>
    <LM>w#w-102-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-108">
  <m id="m036-d1t854-1">
   <w.rf>
    <LM>w#w-d1t854-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t854-2">
   <w.rf>
    <LM>w#w-d1t854-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t854-3">
   <w.rf>
    <LM>w#w-d1t854-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m036-d1t854-4">
   <w.rf>
    <LM>w#w-d1t854-4</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m036-108-110">
   <w.rf>
    <LM>w#w-108-110</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t854-5">
   <w.rf>
    <LM>w#w-d1t854-5</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t854-6">
   <w.rf>
    <LM>w#w-d1t854-6</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m036-d1t854-7">
   <w.rf>
    <LM>w#w-d1t854-7</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m036-d-id81609-punct">
   <w.rf>
    <LM>w#w-d-id81609-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t854-9">
   <w.rf>
    <LM>w#w-d1t854-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t854-10">
   <w.rf>
    <LM>w#w-d1t854-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t854-11">
   <w.rf>
    <LM>w#w-d1t854-11</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m036-108-111">
   <w.rf>
    <LM>w#w-108-111</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t854-12">
   <w.rf>
    <LM>w#w-d1t854-12</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t854-13">
   <w.rf>
    <LM>w#w-d1t854-13</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m036-d1t854-14">
   <w.rf>
    <LM>w#w-d1t854-14</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m036-d-m-d1e843-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e843-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e855-x2">
  <m id="m036-d1t858-1">
   <w.rf>
    <LM>w#w-d1t858-1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m036-d1t858-2">
   <w.rf>
    <LM>w#w-d1t858-2</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t858-3">
   <w.rf>
    <LM>w#w-d1t858-3</LM>
   </w.rf>
   <form>zvědavá</form>
   <lemma>zvědavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m036-d1e855-x2-113">
   <w.rf>
    <LM>w#w-d1e855-x2-113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-114">
  <m id="m036-d1t860-1">
   <w.rf>
    <LM>w#w-d1t860-1</LM>
   </w.rf>
   <form>Zajímá</form>
   <lemma>zajímat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t860-2">
   <w.rf>
    <LM>w#w-d1t860-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m036-114-115">
   <w.rf>
    <LM>w#w-114-115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t860-3">
   <w.rf>
    <LM>w#w-d1t860-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t860-4">
   <w.rf>
    <LM>w#w-d1t860-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t860-5">
   <w.rf>
    <LM>w#w-d1t860-5</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t860-6">
   <w.rf>
    <LM>w#w-d1t860-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d-id81919-punct">
   <w.rf>
    <LM>w#w-d-id81919-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e861-x2">
  <m id="m036-d1t868-1">
   <w.rf>
    <LM>w#w-d1t868-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t868-2">
   <w.rf>
    <LM>w#w-d1t868-2</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1e861-x2-411">
   <w.rf>
    <LM>w#w-d1e861-x2-411</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-412">
  <m id="m036-d1t876-1">
   <w.rf>
    <LM>w#w-d1t876-1</LM>
   </w.rf>
   <form>Dědeček</form>
   <lemma>dědeček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m036-d1t876-2">
   <w.rf>
    <LM>w#w-d1t876-2</LM>
   </w.rf>
   <form>přinesl</form>
   <lemma>přinést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m036-d1t876-3">
   <w.rf>
    <LM>w#w-d1t876-3</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m036-d1t876-4">
   <w.rf>
    <LM>w#w-d1t876-4</LM>
   </w.rf>
   <form>škopky</form>
   <lemma>škopek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m036-d-id82151-punct">
   <w.rf>
    <LM>w#w-d-id82151-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t878-1">
   <w.rf>
    <LM>w#w-d1t878-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t878-2">
   <w.rf>
    <LM>w#w-d1t878-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m036-d1t878-3">
   <w.rf>
    <LM>w#w-d1t878-3</LM>
   </w.rf>
   <form>neprali</form>
   <lemma>prát</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m036-d-id82215-punct">
   <w.rf>
    <LM>w#w-d-id82215-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t878-5">
   <w.rf>
    <LM>w#w-d1t878-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t878-6">
   <w.rf>
    <LM>w#w-d1t878-6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m036-d1t878-7">
   <w.rf>
    <LM>w#w-d1t878-7</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m036-d1t878-8">
   <w.rf>
    <LM>w#w-d1t878-8</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m036-d1t878-9">
   <w.rf>
    <LM>w#w-d1t878-9</LM>
   </w.rf>
   <form>škopík</form>
   <lemma>škopík</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m036-d-m-d1e873-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e873-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e881-x2">
  <m id="m036-d1t886-1">
   <w.rf>
    <LM>w#w-d1t886-1</LM>
   </w.rf>
   <form>Natočil</form>
   <lemma>natočit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m036-d1e881-x2-43">
   <w.rf>
    <LM>w#w-d1e881-x2-43</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m036-d1t886-2">
   <w.rf>
    <LM>w#w-d1t886-2</LM>
   </w.rf>
   <form>teplou</form>
   <lemma>teplý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m036-d1t886-3">
   <w.rf>
    <LM>w#w-d1t886-3</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m036-d1t894-1">
   <w.rf>
    <LM>w#w-d1t894-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t894-2">
   <w.rf>
    <LM>w#w-d1t894-2</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m036-d1t894-3">
   <w.rf>
    <LM>w#w-d1t894-3</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m036-d1t894-4">
   <w.rf>
    <LM>w#w-d1t894-4</LM>
   </w.rf>
   <form>vydržely</form>
   <lemma>vydržet</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m036-d1t894-5">
   <w.rf>
    <LM>w#w-d1t894-5</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m036-d1t894-6">
   <w.rf>
    <LM>w#w-d1t894-6</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-2</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m036-d1e891-x2-127">
   <w.rf>
    <LM>w#w-d1e891-x2-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-128">
  <m id="m036-d1t894-8">
   <w.rf>
    <LM>w#w-d1t894-8</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t894-9">
   <w.rf>
    <LM>w#w-d1t894-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t894-10">
   <w.rf>
    <LM>w#w-d1t894-10</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m036-d1t894-11">
   <w.rf>
    <LM>w#w-d1t894-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t894-12">
   <w.rf>
    <LM>w#w-d1t894-12</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m036-d1t894-13">
   <w.rf>
    <LM>w#w-d1t894-13</LM>
   </w.rf>
   <form>nestačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m036-128-129">
   <w.rf>
    <LM>w#w-128-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-130">
  <m id="m036-d1t894-15">
   <w.rf>
    <LM>w#w-d1t894-15</LM>
   </w.rf>
   <form>Dnešní</form>
   <lemma>dnešní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m036-d1t894-16">
   <w.rf>
    <LM>w#w-d1t894-16</LM>
   </w.rf>
   <form>akvaparky</form>
   <lemma>akvapark</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m036-d1t894-17">
   <w.rf>
    <LM>w#w-d1t894-17</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m036-d1t894-18">
   <w.rf>
    <LM>w#w-d1t894-18</LM>
   </w.rf>
   <form>vybavené</form>
   <lemma>vybavený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m036-d1t894-19">
   <w.rf>
    <LM>w#w-d1t894-19</LM>
   </w.rf>
   <form>skluzavkou</form>
   <lemma>skluzavka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m036-d1t894-21">
   <w.rf>
    <LM>w#w-d1t894-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t896-1">
   <w.rf>
    <LM>w#w-d1t896-1</LM>
   </w.rf>
   <form>všemi</form>
   <lemma>všechen</lemma>
   <tag>PLXP7----------</tag>
  </m>
  <m id="m036-d1t896-2">
   <w.rf>
    <LM>w#w-d1t896-2</LM>
   </w.rf>
   <form>možnými</form>
   <lemma>možný</lemma>
   <tag>AANP7----1A----</tag>
  </m>
  <m id="m036-d1t896-3">
   <w.rf>
    <LM>w#w-d1t896-3</LM>
   </w.rf>
   <form>lákadly</form>
   <lemma>lákadlo</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m036-130-131">
   <w.rf>
    <LM>w#w-130-131</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-132">
  <m id="m036-d1t896-9">
   <w.rf>
    <LM>w#w-d1t896-9</LM>
   </w.rf>
   <form>Domek</form>
   <lemma>domek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m036-d1t896-10">
   <w.rf>
    <LM>w#w-d1t896-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t896-11">
   <w.rf>
    <LM>w#w-d1t896-11</LM>
   </w.rf>
   <form>vzdušnou</form>
   <lemma>vzdušný</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m036-d1t896-12">
   <w.rf>
    <LM>w#w-d1t896-12</LM>
   </w.rf>
   <form>čarou</form>
   <lemma>čára_^(linie)</lemma>
   <tag>NNFS7-----A---1</tag>
  </m>
  <m id="m036-d1t896-13">
   <w.rf>
    <LM>w#w-d1t896-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1t896-14">
   <w.rf>
    <LM>w#w-d1t896-14</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m036-d1t896-15">
   <w.rf>
    <LM>w#w-d1t896-15</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m036-d1t896-16">
   <w.rf>
    <LM>w#w-d1t896-16</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m036-d1t896-17">
   <w.rf>
    <LM>w#w-d1t896-17</LM>
   </w.rf>
   <form>Boleveckého</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m036-d1t896-18">
   <w.rf>
    <LM>w#w-d1t896-18</LM>
   </w.rf>
   <form>rybníka</form>
   <lemma>rybník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m036-d-id83058-punct">
   <w.rf>
    <LM>w#w-d-id83058-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-132-136">
   <w.rf>
    <LM>w#w-132-136</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t896-26">
   <w.rf>
    <LM>w#w-d1t896-26</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t896-22">
   <w.rf>
    <LM>w#w-d1t896-22</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m036-d1t896-23">
   <w.rf>
    <LM>w#w-d1t896-23</LM>
   </w.rf>
   <form>příležitost</form>
   <lemma>příležitost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m036-d1t896-24">
   <w.rf>
    <LM>w#w-d1t896-24</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m036-d1t896-25">
   <w.rf>
    <LM>w#w-d1t896-25</LM>
   </w.rf>
   <form>koupání</form>
   <lemma>koupání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m036-d-id83176-punct">
   <w.rf>
    <LM>w#w-d-id83176-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t896-28">
   <w.rf>
    <LM>w#w-d1t896-28</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t896-29">
   <w.rf>
    <LM>w#w-d1t896-29</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m036-d1t896-30">
   <w.rf>
    <LM>w#w-d1t896-30</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t896-31">
   <w.rf>
    <LM>w#w-d1t896-31</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m036-d1t896-32">
   <w.rf>
    <LM>w#w-d1t896-32</LM>
   </w.rf>
   <form>soukromí</form>
   <lemma>soukromí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m036-d1t896-33">
   <w.rf>
    <LM>w#w-d1t896-33</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t896-34">
   <w.rf>
    <LM>w#w-d1t896-34</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d-m-d1e891-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e891-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e897-x2">
  <m id="m036-d1t900-1">
   <w.rf>
    <LM>w#w-d1t900-1</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m036-d1t900-2">
   <w.rf>
    <LM>w#w-d1t900-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m036-d1t900-3">
   <w.rf>
    <LM>w#w-d1t900-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d1t900-4">
   <w.rf>
    <LM>w#w-d1t900-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d-id83401-punct">
   <w.rf>
    <LM>w#w-d-id83401-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e901-x2">
  <m id="m036-d1t906-1">
   <w.rf>
    <LM>w#w-d1t906-1</LM>
   </w.rf>
   <form>Chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m036-d1e901-x2-147">
   <w.rf>
    <LM>w#w-d1e901-x2-147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-148">
  <m id="m036-d1t906-3">
   <w.rf>
    <LM>w#w-d1t906-3</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m036-d1t906-4">
   <w.rf>
    <LM>w#w-d1t906-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m036-d1t906-5">
   <w.rf>
    <LM>w#w-d1t906-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t906-6">
   <w.rf>
    <LM>w#w-d1t906-6</LM>
   </w.rf>
   <form>vyrostli</form>
   <lemma>vyrůst</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m036-148-149">
   <w.rf>
    <LM>w#w-148-149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-150">
  <m id="m036-d1t906-9">
   <w.rf>
    <LM>w#w-d1t906-9</LM>
   </w.rf>
   <form>Pocházím</form>
   <lemma>pocházet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m036-d1t906-10">
   <w.rf>
    <LM>w#w-d1t906-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m036-d1t906-12">
   <w.rf>
    <LM>w#w-d1t906-12</LM>
   </w.rf>
   <form>Bílé</form>
   <lemma>bílý_;o</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m036-d1t906-13">
   <w.rf>
    <LM>w#w-d1t906-13</LM>
   </w.rf>
   <form>Hory</form>
   <lemma>hora</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m036-d-id83656-punct">
   <w.rf>
    <LM>w#w-d-id83656-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t906-16">
   <w.rf>
    <LM>w#w-d1t906-16</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m036-d1t906-17">
   <w.rf>
    <LM>w#w-d1t906-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t906-22">
   <w.rf>
    <LM>w#w-d1t906-22</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m036-d1t906-23">
   <w.rf>
    <LM>w#w-d1t906-23</LM>
   </w.rf>
   <form>Boleveckým</form>
   <lemma>bolevecký</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m036-d1t906-24">
   <w.rf>
    <LM>w#w-d1t906-24</LM>
   </w.rf>
   <form>rybníkem</form>
   <lemma>rybník</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m036-d-id83804-punct">
   <w.rf>
    <LM>w#w-d-id83804-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t906-26">
   <w.rf>
    <LM>w#w-d1t906-26</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t906-27">
   <w.rf>
    <LM>w#w-d1t906-27</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m036-d1t906-28">
   <w.rf>
    <LM>w#w-d1t906-28</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m036-d-id83859-punct">
   <w.rf>
    <LM>w#w-d-id83859-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t908-1">
   <w.rf>
    <LM>w#w-d1t908-1</LM>
   </w.rf>
   <form>zima</form>
   <lemma>zima-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m036-d-id83893-punct">
   <w.rf>
    <LM>w#w-d-id83893-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t908-3">
   <w.rf>
    <LM>w#w-d1t908-3</LM>
   </w.rf>
   <form>léto</form>
   <lemma>léto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m036-d-id83917-punct">
   <w.rf>
    <LM>w#w-d-id83917-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t908-5">
   <w.rf>
    <LM>w#w-d1t908-5</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m036-150-472">
   <w.rf>
    <LM>w#w-150-472</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t908-6">
   <w.rf>
    <LM>w#w-d1t908-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m036-d1t908-7">
   <w.rf>
    <LM>w#w-d1t908-7</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m036-d-m-d1e901-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e901-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e910-x2">
  <m id="m036-d1t913-2">
   <w.rf>
    <LM>w#w-d1t913-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t913-3">
   <w.rf>
    <LM>w#w-d1t913-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t913-1">
   <w.rf>
    <LM>w#w-d1t913-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t913-4">
   <w.rf>
    <LM>w#w-d1t913-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t913-5">
   <w.rf>
    <LM>w#w-d1t913-5</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m036-d-m-d1e910-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e910-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e914-x2">
  <m id="m036-d1t919-2">
   <w.rf>
    <LM>w#w-d1t919-2</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-3">
   <w.rf>
    <LM>w#w-d1t919-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-4">
   <w.rf>
    <LM>w#w-d1t919-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-5">
   <w.rf>
    <LM>w#w-d1t919-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m036-d-id84235-punct">
   <w.rf>
    <LM>w#w-d-id84235-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t919-7">
   <w.rf>
    <LM>w#w-d1t919-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-8">
   <w.rf>
    <LM>w#w-d1t919-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m036-d1t919-9">
   <w.rf>
    <LM>w#w-d1t919-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-10">
   <w.rf>
    <LM>w#w-d1t919-10</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t919-11">
   <w.rf>
    <LM>w#w-d1t919-11</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m036-d1e914-x2-167">
   <w.rf>
    <LM>w#w-d1e914-x2-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-168">
  <m id="m036-d1t921-1">
   <w.rf>
    <LM>w#w-d1t921-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t921-2">
   <w.rf>
    <LM>w#w-d1t921-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t921-3">
   <w.rf>
    <LM>w#w-d1t921-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m036-d1t921-4">
   <w.rf>
    <LM>w#w-d1t921-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t921-5">
   <w.rf>
    <LM>w#w-d1t921-5</LM>
   </w.rf>
   <form>přírodní</form>
   <lemma>přírodní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m036-168-169">
   <w.rf>
    <LM>w#w-168-169</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t921-6">
   <w.rf>
    <LM>w#w-d1t921-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m036-d1t921-7">
   <w.rf>
    <LM>w#w-d1t921-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t921-8">
   <w.rf>
    <LM>w#w-d1t921-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-168-170">
   <w.rf>
    <LM>w#w-168-170</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-171">
  <m id="m036-d1t921-10">
   <w.rf>
    <LM>w#w-d1t921-10</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m036-d1t921-11">
   <w.rf>
    <LM>w#w-d1t921-11</LM>
   </w.rf>
   <form>našich</form>
   <lemma>náš</lemma>
   <tag>PSXP2-P1-------</tag>
  </m>
  <m id="m036-d1t921-12">
   <w.rf>
    <LM>w#w-d1t921-12</LM>
   </w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m036-d1t921-13">
   <w.rf>
    <LM>w#w-d1t921-13</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m036-d1t921-14">
   <w.rf>
    <LM>w#w-d1t921-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m036-d1t921-15">
   <w.rf>
    <LM>w#w-d1t921-15</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m036-d1t921-16">
   <w.rf>
    <LM>w#w-d1t921-16</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m036-d1t921-17">
   <w.rf>
    <LM>w#w-d1t921-17</LM>
   </w.rf>
   <form>lákadel</form>
   <lemma>lákadlo</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m036-d-id84593-punct">
   <w.rf>
    <LM>w#w-d-id84593-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t923-1">
   <w.rf>
    <LM>w#w-d1t923-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t923-2">
   <w.rf>
    <LM>w#w-d1t923-2</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m036-d1t923-3">
   <w.rf>
    <LM>w#w-d1t923-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m036-d1t923-4">
   <w.rf>
    <LM>w#w-d1t923-4</LM>
   </w.rf>
   <form>čistější</form>
   <lemma>čistý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m036-d-id84673-punct">
   <w.rf>
    <LM>w#w-d-id84673-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m036-d1t923-6">
   <w.rf>
    <LM>w#w-d1t923-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t923-7">
   <w.rf>
    <LM>w#w-d1t923-7</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m036-d1t923-8">
   <w.rf>
    <LM>w#w-d1t923-8</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m036-d1t923-10">
   <w.rf>
    <LM>w#w-d1t923-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m036-d1t925-1">
   <w.rf>
    <LM>w#w-d1t925-1</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m036-d1t925-2">
   <w.rf>
    <LM>w#w-d1t925-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m036-d1t925-3">
   <w.rf>
    <LM>w#w-d1t925-3</LM>
   </w.rf>
   <form>připomínalo</form>
   <lemma>připomínat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m036-d1t925-4">
   <w.rf>
    <LM>w#w-d1t925-4</LM>
   </w.rf>
   <form>přírodu</form>
   <lemma>příroda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m036-d-m-d1e914-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e914-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-d1e926-x2">
  <m id="m036-d1t931-1">
   <w.rf>
    <LM>w#w-d1t931-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m036-d1e926-x2-172">
   <w.rf>
    <LM>w#w-d1e926-x2-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m036-173">
  <m id="m036-d1t933-3">
   <w.rf>
    <LM>w#w-d1t933-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m036-d1t933-2">
   <w.rf>
    <LM>w#w-d1t933-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m036-d1t933-4">
   <w.rf>
    <LM>w#w-d1t933-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m036-d1t933-5">
   <w.rf>
    <LM>w#w-d1t933-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m036-d1t933-6">
   <w.rf>
    <LM>w#w-d1t933-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m036-d-m-d1e926-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e926-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
