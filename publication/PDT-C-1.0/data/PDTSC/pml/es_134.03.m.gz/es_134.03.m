<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_134.03.w.gz" />
  </references>
 </head>
 <s id="m134-472">
  <m id="m134-d1t367-22">
   <w.rf>
    <LM>w#w-d1t367-22</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t367-23">
   <w.rf>
    <LM>w#w-d1t367-23</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t367-21">
   <w.rf>
    <LM>w#w-d1t367-21</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t367-24">
   <w.rf>
    <LM>w#w-d1t367-24</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m134-d1t367-26">
   <w.rf>
    <LM>w#w-d1t367-26</LM>
   </w.rf>
   <form>malých</form>
   <lemma>malý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m134-d1t367-25">
   <w.rf>
    <LM>w#w-d1t367-25</LM>
   </w.rf>
   <form>dětiček</form>
   <lemma>dětičky</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m134-d1t367-27">
   <w.rf>
    <LM>w#w-d1t367-27</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t367-29">
   <w.rf>
    <LM>w#w-d1t367-29</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t367-30">
   <w.rf>
    <LM>w#w-d1t367-30</LM>
   </w.rf>
   <form>pomazlení</form>
   <lemma>pomazlení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d1t367-28">
   <w.rf>
    <LM>w#w-d1t367-28</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m134-d-id90510-punct">
   <w.rf>
    <LM>w#w-d-id90510-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t367-32">
   <w.rf>
    <LM>w#w-d1t367-32</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t367-33">
   <w.rf>
    <LM>w#w-d1t367-33</LM>
   </w.rf>
   <form>holt</form>
   <lemma>holt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t367-34">
   <w.rf>
    <LM>w#w-d1t367-34</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t367-35">
   <w.rf>
    <LM>w#w-d1t367-35</LM>
   </w.rf>
   <form>nastoupit</form>
   <lemma>nastoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d1t367-36">
   <w.rf>
    <LM>w#w-d1t367-36</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t367-37">
   <w.rf>
    <LM>w#w-d1t367-37</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t367-38">
   <w.rf>
    <LM>w#w-d1t367-38</LM>
   </w.rf>
   <form>zdravotnice</form>
   <lemma>zdravotnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-m-d1e336-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e336-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e368-x2">
  <m id="m134-d1t371-1">
   <w.rf>
    <LM>w#w-d1t371-1</LM>
   </w.rf>
   <form>Ošetřovala</form>
   <lemma>ošetřovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t371-2">
   <w.rf>
    <LM>w#w-d1t371-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t371-3">
   <w.rf>
    <LM>w#w-d1t371-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t371-4">
   <w.rf>
    <LM>w#w-d1t371-4</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m134-d1t371-5">
   <w.rf>
    <LM>w#w-d1t371-5</LM>
   </w.rf>
   <form>vážné</form>
   <lemma>vážný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m134-d1t371-6">
   <w.rf>
    <LM>w#w-d1t371-6</LM>
   </w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d-id90773-punct">
   <w.rf>
    <LM>w#w-d-id90773-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e372-x2">
  <m id="m134-d1t375-1">
   <w.rf>
    <LM>w#w-d1t375-1</LM>
   </w.rf>
   <form>Žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS4----------</tag>
  </m>
  <m id="m134-d1t375-2">
   <w.rf>
    <LM>w#w-d1t375-2</LM>
   </w.rf>
   <form>vážné</form>
   <lemma>vážný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m134-d1t375-3">
   <w.rf>
    <LM>w#w-d1t375-3</LM>
   </w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d1t375-4">
   <w.rf>
    <LM>w#w-d1t375-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t375-5">
   <w.rf>
    <LM>w#w-d1t375-5</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDNP4----------</tag>
  </m>
  <m id="m134-d1t375-6">
   <w.rf>
    <LM>w#w-d1t375-6</LM>
   </w.rf>
   <form>léta</form>
   <lemma>léta</lemma>
   <tag>NNNP4-----A---2</tag>
  </m>
  <m id="m134-d-id90928-punct">
   <w.rf>
    <LM>w#w-d-id90928-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t375-8">
   <w.rf>
    <LM>w#w-d1t375-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t375-9">
   <w.rf>
    <LM>w#w-d1t375-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t375-10">
   <w.rf>
    <LM>w#w-d1t375-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t375-11">
   <w.rf>
    <LM>w#w-d1t375-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t375-12">
   <w.rf>
    <LM>w#w-d1t375-12</LM>
   </w.rf>
   <form>táboře</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m134-d-id91014-punct">
   <w.rf>
    <LM>w#w-d-id91014-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t375-14">
   <w.rf>
    <LM>w#w-d1t375-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t375-15">
   <w.rf>
    <LM>w#w-d1t375-15</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t375-16">
   <w.rf>
    <LM>w#w-d1t375-16</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m134-d1e372-x2-354">
   <w.rf>
    <LM>w#w-d1e372-x2-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-335">
  <m id="m134-d1t377-1">
   <w.rf>
    <LM>w#w-d1t377-1</LM>
   </w.rf>
   <form>Pakliže</form>
   <lemma>pakliže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t377-5">
   <w.rf>
    <LM>w#w-d1t377-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t377-6">
   <w.rf>
    <LM>w#w-d1t377-6</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d-id91164-punct">
   <w.rf>
    <LM>w#w-d-id91164-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t377-8">
   <w.rf>
    <LM>w#w-d1t377-8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4NS1----------</tag>
  </m>
  <m id="m134-d1t377-9">
   <w.rf>
    <LM>w#w-d1t377-9</LM>
   </w.rf>
   <form>mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t377-11">
   <w.rf>
    <LM>w#w-d1t377-11</LM>
   </w.rf>
   <form>bolesti</form>
   <lemma>bolest</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d1t377-12">
   <w.rf>
    <LM>w#w-d1t377-12</LM>
   </w.rf>
   <form>břicha</form>
   <lemma>břicho</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-d1t377-13">
   <w.rf>
    <LM>w#w-d1t377-13</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t377-14">
   <w.rf>
    <LM>w#w-d1t377-14</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m134-d1t377-15">
   <w.rf>
    <LM>w#w-d1t377-15</LM>
   </w.rf>
   <form>bolesti</form>
   <lemma>bolest</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d1t377-16">
   <w.rf>
    <LM>w#w-d1t377-16</LM>
   </w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-d-id91313-punct">
   <w.rf>
    <LM>w#w-d-id91313-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t377-18">
   <w.rf>
    <LM>w#w-d1t377-18</LM>
   </w.rf>
   <form>okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t377-19">
   <w.rf>
    <LM>w#w-d1t377-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-335-483">
   <w.rf>
    <LM>w#w-335-483</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PENS4--3-------</tag>
  </m>
  <m id="m134-d1t377-20">
   <w.rf>
    <LM>w#w-d1t377-20</LM>
   </w.rf>
   <form>odvážela</form>
   <lemma>odvážet_^(něco_někam_např._autem)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t377-21">
   <w.rf>
    <LM>w#w-d1t377-21</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t377-22">
   <w.rf>
    <LM>w#w-d1t377-22</LM>
   </w.rf>
   <form>odborné</form>
   <lemma>odborný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m134-d1t377-23">
   <w.rf>
    <LM>w#w-d1t377-23</LM>
   </w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-d1t377-24">
   <w.rf>
    <LM>w#w-d1t377-24</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t377-25">
   <w.rf>
    <LM>w#w-d1t377-25</LM>
   </w.rf>
   <form>lékařům</form>
   <lemma>lékař</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m134-335-359">
   <w.rf>
    <LM>w#w-335-359</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-336">
  <m id="m134-d1t379-1">
   <w.rf>
    <LM>w#w-d1t379-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-336-367">
   <w.rf>
    <LM>w#w-336-367</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t379-2">
   <w.rf>
    <LM>w#w-d1t379-2</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t379-5">
   <w.rf>
    <LM>w#w-d1t379-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t379-7">
   <w.rf>
    <LM>w#w-d1t379-7</LM>
   </w.rf>
   <form>Tatranské</form>
   <lemma>tatranský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m134-d1t379-8">
   <w.rf>
    <LM>w#w-d1t379-8</LM>
   </w.rf>
   <form>Lomnici</form>
   <lemma>Lomnice_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t379-11">
   <w.rf>
    <LM>w#w-d1t379-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t379-12">
   <w.rf>
    <LM>w#w-d1t379-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t379-13">
   <w.rf>
    <LM>w#w-d1t379-13</LM>
   </w.rf>
   <form>zlomenina</form>
   <lemma>zlomenina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-336-368">
   <w.rf>
    <LM>w#w-336-368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t381-2">
   <w.rf>
    <LM>w#w-d1t381-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t381-8">
   <w.rf>
    <LM>w#w-d1t381-8</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m134-d1t381-9">
   <w.rf>
    <LM>w#w-d1t381-9</LM>
   </w.rf>
   <form>nohu</form>
   <lemma>noha</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t381-4">
   <w.rf>
    <LM>w#w-d1t381-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t381-6">
   <w.rf>
    <LM>w#w-d1t381-6</LM>
   </w.rf>
   <form>okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t381-7">
   <w.rf>
    <LM>w#w-d1t381-7</LM>
   </w.rf>
   <form>zafixovala</form>
   <lemma>zafixovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d-id91815-punct">
   <w.rf>
    <LM>w#w-d-id91815-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t381-11">
   <w.rf>
    <LM>w#w-d1t381-11</LM>
   </w.rf>
   <form>odvezlo</form>
   <lemma>odvézt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m134-d1t381-12">
   <w.rf>
    <LM>w#w-d1t381-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t381-13">
   <w.rf>
    <LM>w#w-d1t381-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t381-14">
   <w.rf>
    <LM>w#w-d1t381-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t381-15">
   <w.rf>
    <LM>w#w-d1t381-15</LM>
   </w.rf>
   <form>rentgen</form>
   <lemma>rentgen</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-336-491">
   <w.rf>
    <LM>w#w-336-491</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-492">
  <m id="m134-d1t381-21">
   <w.rf>
    <LM>w#w-d1t381-21</LM>
   </w.rf>
   <form>Odborné</form>
   <lemma>odborný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-d1t381-22">
   <w.rf>
    <LM>w#w-d1t381-22</LM>
   </w.rf>
   <form>ošetření</form>
   <lemma>ošetření_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-d1t381-24">
   <w.rf>
    <LM>w#w-d1t381-24</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t381-25">
   <w.rf>
    <LM>w#w-d1t381-25</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t381-26">
   <w.rf>
    <LM>w#w-d1t381-26</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t381-27">
   <w.rf>
    <LM>w#w-d1t381-27</LM>
   </w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t381-28">
   <w.rf>
    <LM>w#w-d1t381-28</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t381-29">
   <w.rf>
    <LM>w#w-d1t381-29</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m134-d1t381-30">
   <w.rf>
    <LM>w#w-d1t381-30</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t381-31">
   <w.rf>
    <LM>w#w-d1t381-31</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m134-d1t381-32">
   <w.rf>
    <LM>w#w-d1t381-32</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t381-33">
   <w.rf>
    <LM>w#w-d1t381-33</LM>
   </w.rf>
   <form>problému</form>
   <lemma>problém</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d-m-d1e372-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e372-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e382-x2">
  <m id="m134-d1t385-1">
   <w.rf>
    <LM>w#w-d1t385-1</LM>
   </w.rf>
   <form>Bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t385-2">
   <w.rf>
    <LM>w#w-d1t385-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t385-3">
   <w.rf>
    <LM>w#w-d1t385-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t385-4">
   <w.rf>
    <LM>w#w-d1t385-4</LM>
   </w.rf>
   <form>stanu</form>
   <lemma>stan</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d-id92282-punct">
   <w.rf>
    <LM>w#w-d-id92282-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e386-x2">
  <m id="m134-d1t389-1">
   <w.rf>
    <LM>w#w-d1t389-1</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1e386-x2-391">
   <w.rf>
    <LM>w#w-d1e386-x2-391</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-390">
  <m id="m134-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>Bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t391-4">
   <w.rf>
    <LM>w#w-d1t391-4</LM>
   </w.rf>
   <form>stanu</form>
   <lemma>stan</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d-id92437-punct">
   <w.rf>
    <LM>w#w-d-id92437-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t391-6">
   <w.rf>
    <LM>w#w-d1t391-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t391-7">
   <w.rf>
    <LM>w#w-d1t391-7</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t391-8">
   <w.rf>
    <LM>w#w-d1t391-8</LM>
   </w.rf>
   <form>nejde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d-m-d1e386-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e386-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e392-x2">
  <m id="m134-d1t399-1">
   <w.rf>
    <LM>w#w-d1t399-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m134-d1t399-2">
   <w.rf>
    <LM>w#w-d1t399-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t399-3">
   <w.rf>
    <LM>w#w-d1t399-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t399-4">
   <w.rf>
    <LM>w#w-d1t399-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m134-d1t399-5">
   <w.rf>
    <LM>w#w-d1t399-5</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d-id92646-punct">
   <w.rf>
    <LM>w#w-d-id92646-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e400-x2">
  <m id="m134-d1t403-2">
   <w.rf>
    <LM>w#w-d1t403-2</LM>
   </w.rf>
   <form>Tadyto</form>
   <lemma>tadyten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t403-4">
   <w.rf>
    <LM>w#w-d1t403-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t403-5">
   <w.rf>
    <LM>w#w-d1t403-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t403-7">
   <w.rf>
    <LM>w#w-d1t403-7</LM>
   </w.rf>
   <form>Náchoda</form>
   <lemma>Náchod_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d-id92818-punct">
   <w.rf>
    <LM>w#w-d-id92818-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t403-10">
   <w.rf>
    <LM>w#w-d1t403-10</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t403-11">
   <w.rf>
    <LM>w#w-d1t403-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t403-13">
   <w.rf>
    <LM>w#w-d1t403-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t403-14">
   <w.rf>
    <LM>w#w-d1t403-14</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t403-15">
   <w.rf>
    <LM>w#w-d1t403-15</LM>
   </w.rf>
   <form>žákyňka</form>
   <lemma>žákyňka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1e400-x2-421">
   <w.rf>
    <LM>w#w-d1e400-x2-421</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t405-1">
   <w.rf>
    <LM>w#w-d1t405-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m134-d1t405-2">
   <w.rf>
    <LM>w#w-d1t405-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t405-3">
   <w.rf>
    <LM>w#w-d1t405-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t405-4">
   <w.rf>
    <LM>w#w-d1t405-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t405-5">
   <w.rf>
    <LM>w#w-d1t405-5</LM>
   </w.rf>
   <form>prvního</form>
   <lemma>první-1</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m134-d1t405-6">
   <w.rf>
    <LM>w#w-d1t405-6</LM>
   </w.rf>
   <form>máje</form>
   <lemma>máj-1_^(měsíc)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d1t407-15">
   <w.rf>
    <LM>w#w-d1t407-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t407-17">
   <w.rf>
    <LM>w#w-d1t407-17</LM>
   </w.rf>
   <form>Náchodě</form>
   <lemma>Náchod_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t407-19">
   <w.rf>
    <LM>w#w-d1t407-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t407-20">
   <w.rf>
    <LM>w#w-d1t407-20</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-409-414">
   <w.rf>
    <LM>w#w-409-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-408">
  <m id="m134-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t409-2">
   <w.rf>
    <LM>w#w-d1t409-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t409-4">
   <w.rf>
    <LM>w#w-d1t409-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m134-d-id93405-punct">
   <w.rf>
    <LM>w#w-d-id93405-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t409-6">
   <w.rf>
    <LM>w#w-d1t409-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m134-d1t409-8">
   <w.rf>
    <LM>w#w-d1t409-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t409-7">
   <w.rf>
    <LM>w#w-d1t409-7</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t409-10">
   <w.rf>
    <LM>w#w-d1t409-10</LM>
   </w.rf>
   <form>schovává</form>
   <lemma>schovávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-408-425">
   <w.rf>
    <LM>w#w-408-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-407">
  <m id="m134-d1t409-15">
   <w.rf>
    <LM>w#w-d1t409-15</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t409-13">
   <w.rf>
    <LM>w#w-d1t409-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t409-14">
   <w.rf>
    <LM>w#w-d1t409-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t409-16">
   <w.rf>
    <LM>w#w-d1t409-16</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t409-17">
   <w.rf>
    <LM>w#w-d1t409-17</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t409-18">
   <w.rf>
    <LM>w#w-d1t409-18</LM>
   </w.rf>
   <form>nechtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m134-d1t409-19">
   <w.rf>
    <LM>w#w-d1t409-19</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t409-20">
   <w.rf>
    <LM>w#w-d1t409-20</LM>
   </w.rf>
   <form>předvádět</form>
   <lemma>předvádět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t409-21">
   <w.rf>
    <LM>w#w-d1t409-21</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t409-22">
   <w.rf>
    <LM>w#w-d1t409-22</LM>
   </w.rf>
   <form>ukazovat</form>
   <lemma>ukazovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d-id93671-punct">
   <w.rf>
    <LM>w#w-d-id93671-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t409-24">
   <w.rf>
    <LM>w#w-d1t409-24</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t409-25">
   <w.rf>
    <LM>w#w-d1t409-25</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t409-26">
   <w.rf>
    <LM>w#w-d1t409-26</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t409-27">
   <w.rf>
    <LM>w#w-d1t409-27</LM>
   </w.rf>
   <form>lvice</form>
   <lemma>lvice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t409-28">
   <w.rf>
    <LM>w#w-d1t409-28</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t409-29">
   <w.rf>
    <LM>w#w-d1t409-29</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t409-30">
   <w.rf>
    <LM>w#w-d1t409-30</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d1t409-31">
   <w.rf>
    <LM>w#w-d1t409-31</LM>
   </w.rf>
   <form>dělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t409-32">
   <w.rf>
    <LM>w#w-d1t409-32</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t409-33">
   <w.rf>
    <LM>w#w-d1t409-33</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-407-428">
   <w.rf>
    <LM>w#w-407-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e400-x3">
  <m id="m134-d1t414-3">
   <w.rf>
    <LM>w#w-d1t414-3</LM>
   </w.rf>
   <form>Ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t414-2">
   <w.rf>
    <LM>w#w-d1t414-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t414-4">
   <w.rf>
    <LM>w#w-d1t414-4</LM>
   </w.rf>
   <form>bavím</form>
   <lemma>bavit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t414-5">
   <w.rf>
    <LM>w#w-d1t414-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t414-6">
   <w.rf>
    <LM>w#w-d1t414-6</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d-id93952-punct">
   <w.rf>
    <LM>w#w-d-id93952-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t414-8">
   <w.rf>
    <LM>w#w-d1t414-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t414-9">
   <w.rf>
    <LM>w#w-d1t414-9</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m134-d1t414-11">
   <w.rf>
    <LM>w#w-d1t414-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t414-12">
   <w.rf>
    <LM>w#w-d1t414-12</LM>
   </w.rf>
   <form>předváděla</form>
   <lemma>předvádět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d-id94039-punct">
   <w.rf>
    <LM>w#w-d-id94039-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t414-14">
   <w.rf>
    <LM>w#w-d1t414-14</LM>
   </w.rf>
   <form>ukazovala</form>
   <lemma>ukazovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1e400-x3-452">
   <w.rf>
    <LM>w#w-d1e400-x3-452</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-451">
  <m id="m134-d1t414-17">
   <w.rf>
    <LM>w#w-d1t414-17</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t414-18">
   <w.rf>
    <LM>w#w-d1t414-18</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t414-19">
   <w.rf>
    <LM>w#w-d1t414-19</LM>
   </w.rf>
   <form>veselá</form>
   <lemma>veselý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d-id94134-punct">
   <w.rf>
    <LM>w#w-d-id94134-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t414-21">
   <w.rf>
    <LM>w#w-d1t414-21</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t414-22">
   <w.rf>
    <LM>w#w-d1t414-22</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t414-23">
   <w.rf>
    <LM>w#w-d1t414-23</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t414-24">
   <w.rf>
    <LM>w#w-d1t414-24</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m134-d1t414-25">
   <w.rf>
    <LM>w#w-d1t414-25</LM>
   </w.rf>
   <form>veselé</form>
   <lemma>veselý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m134-d1t414-26">
   <w.rf>
    <LM>w#w-d1t414-26</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-451-455">
   <w.rf>
    <LM>w#w-451-455</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t416-1">
   <w.rf>
    <LM>w#w-d1t416-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t416-2">
   <w.rf>
    <LM>w#w-d1t416-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t416-3">
   <w.rf>
    <LM>w#w-d1t416-3</LM>
   </w.rf>
   <form>bavím</form>
   <lemma>bavit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-451-454">
   <w.rf>
    <LM>w#w-451-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-453">
  <m id="m134-d1t416-6">
   <w.rf>
    <LM>w#w-d1t416-6</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHP1-S1-------</tag>
  </m>
  <m id="m134-d1t416-7">
   <w.rf>
    <LM>w#w-d1t416-7</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-d1t416-8">
   <w.rf>
    <LM>w#w-d1t416-8</LM>
   </w.rf>
   <form>řikají</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-453-461">
   <w.rf>
    <LM>w#w-453-461</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-453-462">
   <w.rf>
    <LM>w#w-453-462</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t416-10">
   <w.rf>
    <LM>w#w-d1t416-10</LM>
   </w.rf>
   <form>Mami</form>
   <lemma>mami_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m134-d-id94400-punct">
   <w.rf>
    <LM>w#w-d-id94400-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t416-12">
   <w.rf>
    <LM>w#w-d1t416-12</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ty</lemma>
   <tag>PP-S1--2-------</tag>
  </m>
  <m id="m134-d1t416-13">
   <w.rf>
    <LM>w#w-d1t416-13</LM>
   </w.rf>
   <form>jsi</form>
   <lemma>být</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m134-d1t416-14">
   <w.rf>
    <LM>w#w-d1t416-14</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d-id94455-punct">
   <w.rf>
    <LM>w#w-d-id94455-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t416-16">
   <w.rf>
    <LM>w#w-d1t416-16</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m134-d1t416-17">
   <w.rf>
    <LM>w#w-d1t416-17</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t416-18">
   <w.rf>
    <LM>w#w-d1t416-18</LM>
   </w.rf>
   <form>přijdeš</form>
   <lemma>přijít</lemma>
   <tag>VB-S---2P-AAP--</tag>
  </m>
  <m id="m134-d1t416-19">
   <w.rf>
    <LM>w#w-d1t416-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t416-20">
   <w.rf>
    <LM>w#w-d1t416-20</LM>
   </w.rf>
   <form>musíš</form>
   <lemma>muset</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m134-d1t416-21">
   <w.rf>
    <LM>w#w-d1t416-21</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t416-22">
   <w.rf>
    <LM>w#w-d1t416-22</LM>
   </w.rf>
   <form>středem</form>
   <lemma>střed</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m134-d1t416-23">
   <w.rf>
    <LM>w#w-d1t416-23</LM>
   </w.rf>
   <form>pozornosti</form>
   <lemma>pozornost-1_^(*5ý-1)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-453-529">
   <w.rf>
    <LM>w#w-453-529</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-453-132">
   <w.rf>
    <LM>w#w-453-132</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-531">
  <m id="m134-d1t416-25">
   <w.rf>
    <LM>w#w-d1t416-25</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t416-26">
   <w.rf>
    <LM>w#w-d1t416-26</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t416-27">
   <w.rf>
    <LM>w#w-d1t416-27</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t416-28">
   <w.rf>
    <LM>w#w-d1t416-28</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t416-29">
   <w.rf>
    <LM>w#w-d1t416-29</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m134-d1t416-30">
   <w.rf>
    <LM>w#w-d1t416-30</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d1t416-31">
   <w.rf>
    <LM>w#w-d1t416-31</LM>
   </w.rf>
   <form>nevinně</form>
   <lemma>vinně-1_^(*3ý-1)_(*3ý-2)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m134-d-id94705-punct">
   <w.rf>
    <LM>w#w-d-id94705-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t416-33">
   <w.rf>
    <LM>w#w-d1t416-33</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t416-34">
   <w.rf>
    <LM>w#w-d1t416-34</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t416-35">
   <w.rf>
    <LM>w#w-d1t416-35</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d1t416-36">
   <w.rf>
    <LM>w#w-d1t416-36</LM>
   </w.rf>
   <form>fakt</form>
   <lemma>fakt-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t416-37">
   <w.rf>
    <LM>w#w-d1t416-37</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t416-38">
   <w.rf>
    <LM>w#w-d1t416-38</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m134-d-m-d1e400-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e400-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e429-x2">
  <m id="m134-d1t432-1">
   <w.rf>
    <LM>w#w-d1t432-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m134-d1t432-2">
   <w.rf>
    <LM>w#w-d1t432-2</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m134-d1t432-3">
   <w.rf>
    <LM>w#w-d1t432-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t432-4">
   <w.rf>
    <LM>w#w-d1t432-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t432-5">
   <w.rf>
    <LM>w#w-d1t432-5</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t432-6">
   <w.rf>
    <LM>w#w-d1t432-6</LM>
   </w.rf>
   <form>studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d-id95036-punct">
   <w.rf>
    <LM>w#w-d-id95036-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e433-x2">
  <m id="m134-d1t436-1">
   <w.rf>
    <LM>w#w-d1t436-1</LM>
   </w.rf>
   <form>Čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m134-d1t436-2">
   <w.rf>
    <LM>w#w-d1t436-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1e433-x2-466">
   <w.rf>
    <LM>w#w-d1e433-x2-466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-465">
  <m id="m134-d1t438-1">
   <w.rf>
    <LM>w#w-d1t438-1</LM>
   </w.rf>
   <form>Čtyřletá</form>
   <lemma>čtyřletý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t438-3">
   <w.rf>
    <LM>w#w-d1t438-3</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-465-468">
   <w.rf>
    <LM>w#w-465-468</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t438-4">
   <w.rf>
    <LM>w#w-d1t438-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t438-5">
   <w.rf>
    <LM>w#w-d1t438-5</LM>
   </w.rf>
   <form>maturitou</form>
   <lemma>maturita</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m134-d-m-d1e433-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e433-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e439-x2">
  <m id="m134-d1t442-1">
   <w.rf>
    <LM>w#w-d1t442-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t442-2">
   <w.rf>
    <LM>w#w-d1t442-2</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t442-3">
   <w.rf>
    <LM>w#w-d1t442-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t442-4">
   <w.rf>
    <LM>w#w-d1t442-4</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t442-5">
   <w.rf>
    <LM>w#w-d1t442-5</LM>
   </w.rf>
   <form>praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id95346-punct">
   <w.rf>
    <LM>w#w-d-id95346-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e444-x2">
  <m id="m134-d1t447-1">
   <w.rf>
    <LM>w#w-d1t447-1</LM>
   </w.rf>
   <form>Praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t447-2">
   <w.rf>
    <LM>w#w-d1t447-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t447-4">
   <w.rf>
    <LM>w#w-d1t447-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t447-6">
   <w.rf>
    <LM>w#w-d1t447-6</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m134-d1t447-7">
   <w.rf>
    <LM>w#w-d1t447-7</LM>
   </w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d-id95548-punct">
   <w.rf>
    <LM>w#w-d-id95548-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t447-11">
   <w.rf>
    <LM>w#w-d1t447-11</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m134-d1e444-x2-537">
   <w.rf>
    <LM>w#w-d1e444-x2-537</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t447-12">
   <w.rf>
    <LM>w#w-d1t447-12</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m134-d1t447-13">
   <w.rf>
    <LM>w#w-d1t447-13</LM>
   </w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-d1t447-14">
   <w.rf>
    <LM>w#w-d1t447-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t447-15">
   <w.rf>
    <LM>w#w-d1t447-15</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m134-d1t447-16">
   <w.rf>
    <LM>w#w-d1t447-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t447-17">
   <w.rf>
    <LM>w#w-d1t447-17</LM>
   </w.rf>
   <form>praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d-m-d1e444-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e444-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e448-x2">
  <m id="m134-d1t451-1">
   <w.rf>
    <LM>w#w-d1t451-1</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d1t451-2">
   <w.rf>
    <LM>w#w-d1t451-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m134-d1t451-3">
   <w.rf>
    <LM>w#w-d1t451-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t451-4">
   <w.rf>
    <LM>w#w-d1t451-4</LM>
   </w.rf>
   <form>počátku</form>
   <lemma>počátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m134-d1t451-5">
   <w.rf>
    <LM>w#w-d1t451-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t451-6">
   <w.rf>
    <LM>w#w-d1t451-6</LM>
   </w.rf>
   <form>nemocnici</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t451-7">
   <w.rf>
    <LM>w#w-d1t451-7</LM>
   </w.rf>
   <form>zle</form>
   <lemma>zle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m134-d-id95827-punct">
   <w.rf>
    <LM>w#w-d-id95827-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e452-x2">
  <m id="m134-d1t455-1">
   <w.rf>
    <LM>w#w-d1t455-1</LM>
   </w.rf>
   <form>Nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m134-d-id95904-punct">
   <w.rf>
    <LM>w#w-d-id95904-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t455-3">
   <w.rf>
    <LM>w#w-d1t455-3</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t455-4">
   <w.rf>
    <LM>w#w-d1t455-4</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t455-5">
   <w.rf>
    <LM>w#w-d1t455-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t455-6">
   <w.rf>
    <LM>w#w-d1t455-6</LM>
   </w.rf>
   <form>zdravotnice</form>
   <lemma>zdravotnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1e452-x2-543">
   <w.rf>
    <LM>w#w-d1e452-x2-543</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-544">
  <m id="m134-d1t455-12">
   <w.rf>
    <LM>w#w-d1t455-12</LM>
   </w.rf>
   <form>Docházela</form>
   <lemma>docházet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t455-9">
   <w.rf>
    <LM>w#w-d1t455-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t455-10">
   <w.rf>
    <LM>w#w-d1t455-10</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t455-11">
   <w.rf>
    <LM>w#w-d1t455-11</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m134-d-id96061-punct">
   <w.rf>
    <LM>w#w-d-id96061-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t455-14">
   <w.rf>
    <LM>w#w-d1t455-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t455-15">
   <w.rf>
    <LM>w#w-d1t455-15</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t455-16">
   <w.rf>
    <LM>w#w-d1t455-16</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m134-d1t455-17">
   <w.rf>
    <LM>w#w-d1t455-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t455-18">
   <w.rf>
    <LM>w#w-d1t455-18</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m134-d1t455-19">
   <w.rf>
    <LM>w#w-d1t455-19</LM>
   </w.rf>
   <form>problém</form>
   <lemma>problém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m134-d1e452-x2-479">
   <w.rf>
    <LM>w#w-d1e452-x2-479</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-478">
  <m id="m134-d1t457-5">
   <w.rf>
    <LM>w#w-d1t457-5</LM>
   </w.rf>
   <form>Problém</form>
   <lemma>problém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m134-d1t457-4">
   <w.rf>
    <LM>w#w-d1t457-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m134-d-id96249-punct">
   <w.rf>
    <LM>w#w-d-id96249-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t457-7">
   <w.rf>
    <LM>w#w-d1t457-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t457-8">
   <w.rf>
    <LM>w#w-d1t457-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t457-9">
   <w.rf>
    <LM>w#w-d1t457-9</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t457-10">
   <w.rf>
    <LM>w#w-d1t457-10</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t457-11">
   <w.rf>
    <LM>w#w-d1t457-11</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-12">
   <w.rf>
    <LM>w#w-d1t457-12</LM>
   </w.rf>
   <form>svoje</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP4----------</tag>
  </m>
  <m id="m134-d1t457-13">
   <w.rf>
    <LM>w#w-d1t457-13</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-478-434">
   <w.rf>
    <LM>w#w-478-434</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t457-15">
   <w.rf>
    <LM>w#w-d1t457-15</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-16">
   <w.rf>
    <LM>w#w-d1t457-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t457-17">
   <w.rf>
    <LM>w#w-d1t457-17</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t457-18">
   <w.rf>
    <LM>w#w-d1t457-18</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m134-d1t457-19">
   <w.rf>
    <LM>w#w-d1t457-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t457-20">
   <w.rf>
    <LM>w#w-d1t457-20</LM>
   </w.rf>
   <form>vyšetření</form>
   <lemma>vyšetření_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m134-478-435">
   <w.rf>
    <LM>w#w-478-435</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-433">
  <m id="m134-d1t457-22">
   <w.rf>
    <LM>w#w-d1t457-22</LM>
   </w.rf>
   <form>Viděla</form>
   <lemma>vidět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-23">
   <w.rf>
    <LM>w#w-d1t457-23</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t457-24">
   <w.rf>
    <LM>w#w-d1t457-24</LM>
   </w.rf>
   <form>sestřičky</form>
   <lemma>sestřička</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-492-497">
   <w.rf>
    <LM>w#w-492-497</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t457-25">
   <w.rf>
    <LM>w#w-d1t457-25</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t457-28">
   <w.rf>
    <LM>w#w-d1t457-28</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m134-d1t457-27">
   <w.rf>
    <LM>w#w-d1t457-27</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t457-29">
   <w.rf>
    <LM>w#w-d1t457-29</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-30">
   <w.rf>
    <LM>w#w-d1t457-30</LM>
   </w.rf>
   <form>brát</form>
   <lemma>brát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t457-31">
   <w.rf>
    <LM>w#w-d1t457-31</LM>
   </w.rf>
   <form>krev</form>
   <lemma>krev</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t457-32">
   <w.rf>
    <LM>w#w-d1t457-32</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t457-33">
   <w.rf>
    <LM>w#w-d1t457-33</LM>
   </w.rf>
   <form>sedimentaci</form>
   <lemma>sedimentace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t457-34">
   <w.rf>
    <LM>w#w-d1t457-34</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t457-35">
   <w.rf>
    <LM>w#w-d1t457-35</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-36">
   <w.rf>
    <LM>w#w-d1t457-36</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t457-38">
   <w.rf>
    <LM>w#w-d1t457-38</LM>
   </w.rf>
   <form>nemehla</form>
   <lemma>nemehlo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m134-d1t457-39">
   <w.rf>
    <LM>w#w-d1t457-39</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t457-40">
   <w.rf>
    <LM>w#w-d1t457-40</LM>
   </w.rf>
   <form>ubližovaly</form>
   <lemma>ubližovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-41">
   <w.rf>
    <LM>w#w-d1t457-41</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m134-d1t457-42">
   <w.rf>
    <LM>w#w-d1t457-42</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t457-43">
   <w.rf>
    <LM>w#w-d1t457-43</LM>
   </w.rf>
   <form>píchaly</form>
   <lemma>píchat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-44">
   <w.rf>
    <LM>w#w-d1t457-44</LM>
   </w.rf>
   <form>injekce</form>
   <lemma>injekce</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-492-498">
   <w.rf>
    <LM>w#w-492-498</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-495">
  <m id="m134-d1t457-47">
   <w.rf>
    <LM>w#w-d1t457-47</LM>
   </w.rf>
   <form>Tyhlety</form>
   <lemma>tenhleten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m134-d1t457-49">
   <w.rf>
    <LM>w#w-d1t457-49</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d1t457-50">
   <w.rf>
    <LM>w#w-d1t457-50</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t457-52">
   <w.rf>
    <LM>w#w-d1t457-52</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP3----------</tag>
  </m>
  <m id="m134-d1t457-53">
   <w.rf>
    <LM>w#w-d1t457-53</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m134-d1t457-54">
   <w.rf>
    <LM>w#w-d1t457-54</LM>
   </w.rf>
   <form>radši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m134-d1t457-55">
   <w.rf>
    <LM>w#w-d1t457-55</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t457-56">
   <w.rf>
    <LM>w#w-d1t457-56</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m134-d1t457-57">
   <w.rf>
    <LM>w#w-d1t457-57</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t457-58">
   <w.rf>
    <LM>w#w-d1t457-58</LM>
   </w.rf>
   <form>ony</form>
   <lemma>on-1</lemma>
   <tag>PEFP1--3-------</tag>
  </m>
  <m id="m134-d1t457-59">
   <w.rf>
    <LM>w#w-d1t457-59</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m134-d1t457-60">
   <w.rf>
    <LM>w#w-d1t457-60</LM>
   </w.rf>
   <form>ode</form>
   <lemma>od-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m134-d1t457-61">
   <w.rf>
    <LM>w#w-d1t457-61</LM>
   </w.rf>
   <form>mne</form>
   <lemma>já</lemma>
   <tag>PP-S2--1-------</tag>
  </m>
  <m id="m134-d1t457-62">
   <w.rf>
    <LM>w#w-d1t457-62</LM>
   </w.rf>
   <form>braly</form>
   <lemma>brát</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-495-500">
   <w.rf>
    <LM>w#w-495-500</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-491">
  <m id="m134-d1t459-1">
   <w.rf>
    <LM>w#w-d1t459-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t459-2">
   <w.rf>
    <LM>w#w-d1t459-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m134-d1t459-4">
   <w.rf>
    <LM>w#w-d1t459-4</LM>
   </w.rf>
   <form>nemocnice</form>
   <lemma>nemocnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t459-5">
   <w.rf>
    <LM>w#w-d1t459-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t459-6">
   <w.rf>
    <LM>w#w-d1t459-6</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m134-d1t459-7">
   <w.rf>
    <LM>w#w-d1t459-7</LM>
   </w.rf>
   <form>nepáchla</form>
   <lemma>páchnout</lemma>
   <tag>VpQW----R-NAI-1</tag>
  </m>
  <m id="m134-491-506">
   <w.rf>
    <LM>w#w-491-506</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t459-8">
   <w.rf>
    <LM>w#w-d1t459-8</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t459-9">
   <w.rf>
    <LM>w#w-d1t459-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t459-10">
   <w.rf>
    <LM>w#w-d1t459-10</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t459-11">
   <w.rf>
    <LM>w#w-d1t459-11</LM>
   </w.rf>
   <form>voněla</form>
   <lemma>vonět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-491-507">
   <w.rf>
    <LM>w#w-491-507</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-505">
  <m id="m134-d1t461-4">
   <w.rf>
    <LM>w#w-d1t461-4</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t461-5">
   <w.rf>
    <LM>w#w-d1t461-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t461-6">
   <w.rf>
    <LM>w#w-d1t461-6</LM>
   </w.rf>
   <form>znova</form>
   <lemma>znova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t461-7">
   <w.rf>
    <LM>w#w-d1t461-7</LM>
   </w.rf>
   <form>narodím</form>
   <lemma>narodit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m134-d-id97430-punct">
   <w.rf>
    <LM>w#w-d-id97430-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t461-9">
   <w.rf>
    <LM>w#w-d1t461-9</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m134-d1t461-10">
   <w.rf>
    <LM>w#w-d1t461-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t461-12">
   <w.rf>
    <LM>w#w-d1t461-12</LM>
   </w.rf>
   <form>rozhodně</form>
   <lemma>rozhodně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t461-11">
   <w.rf>
    <LM>w#w-d1t461-11</LM>
   </w.rf>
   <form>stane</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m134-d-id97501-punct">
   <w.rf>
    <LM>w#w-d-id97501-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t461-14">
   <w.rf>
    <LM>w#w-d1t461-14</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t461-15">
   <w.rf>
    <LM>w#w-d1t461-15</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m134-d1t461-16">
   <w.rf>
    <LM>w#w-d1t461-16</LM>
   </w.rf>
   <form>věřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t461-17">
   <w.rf>
    <LM>w#w-d1t461-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t461-18">
   <w.rf>
    <LM>w#w-d1t461-18</LM>
   </w.rf>
   <form>reinkarnaci</form>
   <lemma>reinkarnace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id97587-punct">
   <w.rf>
    <LM>w#w-d-id97587-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t461-20">
   <w.rf>
    <LM>w#w-d1t461-20</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t461-21">
   <w.rf>
    <LM>w#w-d1t461-21</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m134-d1t461-22">
   <w.rf>
    <LM>w#w-d1t461-22</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m134-d1t461-23">
   <w.rf>
    <LM>w#w-d1t461-23</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t461-24">
   <w.rf>
    <LM>w#w-d1t461-24</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m134-d1t461-25">
   <w.rf>
    <LM>w#w-d1t461-25</LM>
   </w.rf>
   <form>zdravotnice</form>
   <lemma>zdravotnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-505-557">
   <w.rf>
    <LM>w#w-505-557</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-561">
  <m id="m134-d1t461-27">
   <w.rf>
    <LM>w#w-d1t461-27</LM>
   </w.rf>
   <form>Nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m134-d1t461-28">
   <w.rf>
    <LM>w#w-d1t461-28</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m134-d1t461-29">
   <w.rf>
    <LM>w#w-d1t461-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t461-30">
   <w.rf>
    <LM>w#w-d1t461-30</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d1t461-31">
   <w.rf>
    <LM>w#w-d1t461-31</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d-m-d1e452-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e452-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e462-x2">
  <m id="m134-d1t469-1">
   <w.rf>
    <LM>w#w-d1t469-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m134-d1t469-2">
   <w.rf>
    <LM>w#w-d1t469-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m134-d1t469-3">
   <w.rf>
    <LM>w#w-d1t469-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m134-d1t469-4">
   <w.rf>
    <LM>w#w-d1t469-4</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t469-5">
   <w.rf>
    <LM>w#w-d1t469-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t469-6">
   <w.rf>
    <LM>w#w-d1t469-6</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1t469-7">
   <w.rf>
    <LM>w#w-d1t469-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t469-8">
   <w.rf>
    <LM>w#w-d1t469-8</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d-id97976-punct">
   <w.rf>
    <LM>w#w-d-id97976-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e470-x2">
  <m id="m134-d1t473-3">
   <w.rf>
    <LM>w#w-d1t473-3</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t473-4">
   <w.rf>
    <LM>w#w-d1t473-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t473-6">
   <w.rf>
    <LM>w#w-d1t473-6</LM>
   </w.rf>
   <form>organizaci</form>
   <lemma>organizace</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t473-7">
   <w.rf>
    <LM>w#w-d1t473-7</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m134-d1t473-8">
   <w.rf>
    <LM>w#w-d1t473-8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m134-d1t473-9">
   <w.rf>
    <LM>w#w-d1t473-9</LM>
   </w.rf>
   <form>zdravotnictví</form>
   <lemma>zdravotnictví</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m134-d-id98178-punct">
   <w.rf>
    <LM>w#w-d-id98178-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t473-11">
   <w.rf>
    <LM>w#w-d1t473-11</LM>
   </w.rf>
   <form>internu</form>
   <lemma>interna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id98202-punct">
   <w.rf>
    <LM>w#w-d-id98202-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t473-13">
   <w.rf>
    <LM>w#w-d1t473-13</LM>
   </w.rf>
   <form>chirurgii</form>
   <lemma>chirurgie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d-id98226-punct">
   <w.rf>
    <LM>w#w-d-id98226-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t473-15">
   <w.rf>
    <LM>w#w-d1t473-15</LM>
   </w.rf>
   <form>hygienu</form>
   <lemma>hygiena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1e470-x2-13">
   <w.rf>
    <LM>w#w-d1e470-x2-13</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t475-1">
   <w.rf>
    <LM>w#w-d1t475-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t475-2">
   <w.rf>
    <LM>w#w-d1t475-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t475-4">
   <w.rf>
    <LM>w#w-d1t475-4</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m134-d1t475-5">
   <w.rf>
    <LM>w#w-d1t475-5</LM>
   </w.rf>
   <form>nejzákladnější</form>
   <lemma>základní</lemma>
   <tag>AAIP1----3A----</tag>
  </m>
  <m id="m134-d1t475-6">
   <w.rf>
    <LM>w#w-d1t475-6</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m134-d1t475-7">
   <w.rf>
    <LM>w#w-d1t475-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t475-8">
   <w.rf>
    <LM>w#w-d1t475-8</LM>
   </w.rf>
   <form>zdrávce</form>
   <lemma>zdrávka_,h_^(zdravotní_škola)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-d1e470-x2-568">
   <w.rf>
    <LM>w#w-d1e470-x2-568</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-1">
   <w.rf>
    <LM>w#w-d1t477-1</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-2_^(mat._operace;_1_plus_1,_též_plus_dva_stupně)</lemma>
   <tag>J*-------------</tag>
  </m>
  <m id="m134-d1t477-2">
   <w.rf>
    <LM>w#w-d1t477-2</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP4----------</tag>
  </m>
  <m id="m134-d1e470-x2-14">
   <w.rf>
    <LM>w#w-d1e470-x2-14</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t477-3">
   <w.rf>
    <LM>w#w-d1t477-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t477-4">
   <w.rf>
    <LM>w#w-d1t477-4</LM>
   </w.rf>
   <form>čeština</form>
   <lemma>čeština</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id98468-punct">
   <w.rf>
    <LM>w#w-d-id98468-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-6">
   <w.rf>
    <LM>w#w-d1t477-6</LM>
   </w.rf>
   <form>matematika</form>
   <lemma>matematika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1e470-x2-16">
   <w.rf>
    <LM>w#w-d1e470-x2-16</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-15">
  <m id="m134-d1t477-9">
   <w.rf>
    <LM>w#w-d1t477-9</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t477-10">
   <w.rf>
    <LM>w#w-d1t477-10</LM>
   </w.rf>
   <form>prvních</form>
   <lemma>první-1</lemma>
   <tag>CrIP6----------</tag>
  </m>
  <m id="m134-d1t477-11">
   <w.rf>
    <LM>w#w-d1t477-11</LM>
   </w.rf>
   <form>ročnících</form>
   <lemma>ročník</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m134-d1t477-12">
   <w.rf>
    <LM>w#w-d1t477-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t477-13">
   <w.rf>
    <LM>w#w-d1t477-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t477-14">
   <w.rf>
    <LM>w#w-d1t477-14</LM>
   </w.rf>
   <form>fyzika</form>
   <lemma>fyzika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id98609-punct">
   <w.rf>
    <LM>w#w-d-id98609-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-16">
   <w.rf>
    <LM>w#w-d1t477-16</LM>
   </w.rf>
   <form>chemie</form>
   <lemma>chemie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id98634-punct">
   <w.rf>
    <LM>w#w-d-id98634-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-21">
   <w.rf>
    <LM>w#w-d1t477-21</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m134-15-26">
   <w.rf>
    <LM>w#w-15-26</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-22">
   <w.rf>
    <LM>w#w-d1t477-22</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m134-d1t477-23">
   <w.rf>
    <LM>w#w-d1t477-23</LM>
   </w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m134-15-27">
   <w.rf>
    <LM>w#w-15-27</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-25">
   <w.rf>
    <LM>w#w-d1t477-25</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t477-26">
   <w.rf>
    <LM>w#w-d1t477-26</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t477-27">
   <w.rf>
    <LM>w#w-d1t477-27</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t477-28">
   <w.rf>
    <LM>w#w-d1t477-28</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m134-d1t477-29">
   <w.rf>
    <LM>w#w-d1t477-29</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m134-d1t477-30">
   <w.rf>
    <LM>w#w-d1t477-30</LM>
   </w.rf>
   <form>odborné</form>
   <lemma>odborný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m134-d1t477-31">
   <w.rf>
    <LM>w#w-d1t477-31</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m134-d-id98859-punct">
   <w.rf>
    <LM>w#w-d-id98859-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-33">
   <w.rf>
    <LM>w#w-d1t477-33</LM>
   </w.rf>
   <form>oční</form>
   <lemma>oční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-d-id98899-punct">
   <w.rf>
    <LM>w#w-d-id98899-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t477-36">
   <w.rf>
    <LM>w#w-d1t477-36</LM>
   </w.rf>
   <form>anatomie</form>
   <lemma>anatomie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t477-37">
   <w.rf>
    <LM>w#w-d1t477-37</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t477-41">
   <w.rf>
    <LM>w#w-d1t477-41</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP1----------</tag>
  </m>
  <m id="m134-d1t477-38">
   <w.rf>
    <LM>w#w-d1t477-38</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m134-d1t477-40">
   <w.rf>
    <LM>w#w-d1t477-40</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-15-29">
   <w.rf>
    <LM>w#w-15-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-28">
  <m id="m134-d1t479-2">
   <w.rf>
    <LM>w#w-d1t479-2</LM>
   </w.rf>
   <form>Oční</form>
   <lemma>oční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m134-d-id99047-punct">
   <w.rf>
    <LM>w#w-d-id99047-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t479-4">
   <w.rf>
    <LM>w#w-d1t479-4</LM>
   </w.rf>
   <form>ušní</form>
   <lemma>ušní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m134-d1t479-5">
   <w.rf>
    <LM>w#w-d1t479-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t479-8">
   <w.rf>
    <LM>w#w-d1t479-8</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m134-d1t479-6">
   <w.rf>
    <LM>w#w-d1t479-6</LM>
   </w.rf>
   <form>tyhle</form>
   <lemma>tenhle</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m134-d1t479-9">
   <w.rf>
    <LM>w#w-d1t479-9</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t479-12">
   <w.rf>
    <LM>w#w-d1t479-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t479-14">
   <w.rf>
    <LM>w#w-d1t479-14</LM>
   </w.rf>
   <form>probíraly</form>
   <lemma>probírat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d-id99220-punct">
   <w.rf>
    <LM>w#w-d-id99220-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t479-16">
   <w.rf>
    <LM>w#w-d1t479-16</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t479-17">
   <w.rf>
    <LM>w#w-d1t479-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t479-18">
   <w.rf>
    <LM>w#w-d1t479-18</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t481-1">
   <w.rf>
    <LM>w#w-d1t481-1</LM>
   </w.rf>
   <form>zdravotní</form>
   <lemma>zdravotní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m134-d1t481-6">
   <w.rf>
    <LM>w#w-d1t481-6</LM>
   </w.rf>
   <form>všeobecným</form>
   <lemma>všeobecný</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m134-d1t481-4">
   <w.rf>
    <LM>w#w-d1t481-4</LM>
   </w.rf>
   <form>zaměřením</form>
   <lemma>zaměření_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m134-28-49">
   <w.rf>
    <LM>w#w-28-49</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-48">
  <m id="m134-d1t484-4">
   <w.rf>
    <LM>w#w-d1t484-4</LM>
   </w.rf>
   <form>Zvlášť</form>
   <lemma>zvlášť-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t484-5">
   <w.rf>
    <LM>w#w-d1t484-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t484-6">
   <w.rf>
    <LM>w#w-d1t484-6</LM>
   </w.rf>
   <form>učily</form>
   <lemma>učit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t484-7">
   <w.rf>
    <LM>w#w-d1t484-7</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-d-id99494-punct">
   <w.rf>
    <LM>w#w-d-id99494-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-9">
   <w.rf>
    <LM>w#w-d1t484-9</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m134-d1t484-10">
   <w.rf>
    <LM>w#w-d1t484-10</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t484-11">
   <w.rf>
    <LM>w#w-d1t484-11</LM>
   </w.rf>
   <form>porodní</form>
   <lemma>porodní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m134-d1t484-12">
   <w.rf>
    <LM>w#w-d1t484-12</LM>
   </w.rf>
   <form>asistentky</form>
   <lemma>asistentka_^(*2)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-d1t484-13">
   <w.rf>
    <LM>w#w-d1t484-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t484-14">
   <w.rf>
    <LM>w#w-d1t484-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t484-15">
   <w.rf>
    <LM>w#w-d1t484-15</LM>
   </w.rf>
   <form>gynekologii</form>
   <lemma>gynekologie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-48-589">
   <w.rf>
    <LM>w#w-48-589</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-590">
  <m id="m134-d1t484-22">
   <w.rf>
    <LM>w#w-d1t484-22</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t484-23">
   <w.rf>
    <LM>w#w-d1t484-23</LM>
   </w.rf>
   <form>interna</form>
   <lemma>interna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id99722-punct">
   <w.rf>
    <LM>w#w-d-id99722-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-25">
   <w.rf>
    <LM>w#w-d1t484-25</LM>
   </w.rf>
   <form>chirurgie</form>
   <lemma>chirurgie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id99746-punct">
   <w.rf>
    <LM>w#w-d-id99746-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-27">
   <w.rf>
    <LM>w#w-d1t484-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m134-d1t484-28">
   <w.rf>
    <LM>w#w-d1t484-28</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t484-29">
   <w.rf>
    <LM>w#w-d1t484-29</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t484-30">
   <w.rf>
    <LM>w#w-d1t484-30</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m134-48-66">
   <w.rf>
    <LM>w#w-48-66</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-48-68">
   <w.rf>
    <LM>w#w-48-68</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t484-32">
   <w.rf>
    <LM>w#w-d1t484-32</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t484-34">
   <w.rf>
    <LM>w#w-d1t484-34</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m134-d1t484-35">
   <w.rf>
    <LM>w#w-d1t484-35</LM>
   </w.rf>
   <form>1957</form>
   <lemma>1957</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t484-37">
   <w.rf>
    <LM>w#w-d1t484-37</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-1_^(2_až_3)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t484-38">
   <w.rf>
    <LM>w#w-d1t484-38</LM>
   </w.rf>
   <form>1961</form>
   <lemma>1961</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d-id99942-punct">
   <w.rf>
    <LM>w#w-d-id99942-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-44">
   <w.rf>
    <LM>w#w-d1t484-44</LM>
   </w.rf>
   <form>všeobecného</form>
   <lemma>všeobecný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m134-d1t484-45">
   <w.rf>
    <LM>w#w-d1t484-45</LM>
   </w.rf>
   <form>zaměření</form>
   <lemma>zaměření_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m134-48-67">
   <w.rf>
    <LM>w#w-48-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-64">
  <m id="m134-d1t484-47">
   <w.rf>
    <LM>w#w-d1t484-47</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t484-48">
   <w.rf>
    <LM>w#w-d1t484-48</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t484-49">
   <w.rf>
    <LM>w#w-d1t484-49</LM>
   </w.rf>
   <form>interna</form>
   <lemma>interna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id100099-punct">
   <w.rf>
    <LM>w#w-d-id100099-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-51">
   <w.rf>
    <LM>w#w-d1t484-51</LM>
   </w.rf>
   <form>chirurgie</form>
   <lemma>chirurgie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d-id100123-punct">
   <w.rf>
    <LM>w#w-d-id100123-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-53">
   <w.rf>
    <LM>w#w-d1t484-53</LM>
   </w.rf>
   <form>oční</form>
   <lemma>oční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-d-id100147-punct">
   <w.rf>
    <LM>w#w-d-id100147-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t484-55">
   <w.rf>
    <LM>w#w-d1t484-55</LM>
   </w.rf>
   <form>ušní</form>
   <lemma>ušní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m134-64-73">
   <w.rf>
    <LM>w#w-64-73</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-65">
  <m id="m134-d1t486-5">
   <w.rf>
    <LM>w#w-d1t486-5</LM>
   </w.rf>
   <form>Neurologie</form>
   <lemma>neurologie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-65-596">
   <w.rf>
    <LM>w#w-65-596</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-597">
  <m id="m134-d1t486-7">
   <w.rf>
    <LM>w#w-d1t486-7</LM>
   </w.rf>
   <form>Ortopedie</form>
   <lemma>ortopedie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t486-8">
   <w.rf>
    <LM>w#w-d1t486-8</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t486-11">
   <w.rf>
    <LM>w#w-d1t486-11</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m134-d1t486-12">
   <w.rf>
    <LM>w#w-d1t486-12</LM>
   </w.rf>
   <form>samostatná</form>
   <lemma>samostatný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-d1t486-13">
   <w.rf>
    <LM>w#w-d1t486-13</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t486-14">
   <w.rf>
    <LM>w#w-d1t486-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t486-15">
   <w.rf>
    <LM>w#w-d1t486-15</LM>
   </w.rf>
   <form>pozdějších</form>
   <lemma>pozdější</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m134-d1t486-16">
   <w.rf>
    <LM>w#w-d1t486-16</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m134-65-84">
   <w.rf>
    <LM>w#w-65-84</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-83">
  <m id="m134-d1t488-1">
   <w.rf>
    <LM>w#w-d1t488-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t488-3">
   <w.rf>
    <LM>w#w-d1t488-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t488-4">
   <w.rf>
    <LM>w#w-d1t488-4</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t488-5">
   <w.rf>
    <LM>w#w-d1t488-5</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d1t488-6">
   <w.rf>
    <LM>w#w-d1t488-6</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t488-7">
   <w.rf>
    <LM>w#w-d1t488-7</LM>
   </w.rf>
   <form>rehabilitační</form>
   <lemma>rehabilitační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m134-83-109">
   <w.rf>
    <LM>w#w-83-109</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-83-110">
   <w.rf>
    <LM>w#w-83-110</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t488-11">
   <w.rf>
    <LM>w#w-d1t488-11</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t488-9">
   <w.rf>
    <LM>w#w-d1t488-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t488-10">
   <w.rf>
    <LM>w#w-d1t488-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t488-12">
   <w.rf>
    <LM>w#w-d1t488-12</LM>
   </w.rf>
   <form>vyučit</form>
   <lemma>vyučit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m134-d-id100631-punct">
   <w.rf>
    <LM>w#w-d-id100631-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t488-14">
   <w.rf>
    <LM>w#w-d1t488-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t488-15">
   <w.rf>
    <LM>w#w-d1t488-15</LM>
   </w.rf>
   <form>rehabilitace</form>
   <lemma>rehabilitace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t488-16">
   <w.rf>
    <LM>w#w-d1t488-16</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t488-17">
   <w.rf>
    <LM>w#w-d1t488-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t488-19">
   <w.rf>
    <LM>w#w-d1t488-19</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t488-20">
   <w.rf>
    <LM>w#w-d1t488-20</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t488-21">
   <w.rf>
    <LM>w#w-d1t488-21</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t488-22">
   <w.rf>
    <LM>w#w-d1t488-22</LM>
   </w.rf>
   <form>ocasu</form>
   <lemma>ocas</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m134-83-605">
   <w.rf>
    <LM>w#w-83-605</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-606">
  <m id="m134-d1t488-24">
   <w.rf>
    <LM>w#w-d1t488-24</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t488-25">
   <w.rf>
    <LM>w#w-d1t488-25</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t488-26">
   <w.rf>
    <LM>w#w-d1t488-26</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t488-27">
   <w.rf>
    <LM>w#w-d1t488-27</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m134-d1t488-28">
   <w.rf>
    <LM>w#w-d1t488-28</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m134-d1t488-29">
   <w.rf>
    <LM>w#w-d1t488-29</LM>
   </w.rf>
   <form>rehabilitace</form>
   <lemma>rehabilitace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-83-136">
   <w.rf>
    <LM>w#w-83-136</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t488-31">
   <w.rf>
    <LM>w#w-d1t488-31</LM>
   </w.rf>
   <form>psychoterapie</form>
   <lemma>psychoterapie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m134-d1t488-32">
   <w.rf>
    <LM>w#w-d1t488-32</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t488-33">
   <w.rf>
    <LM>w#w-d1t488-33</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDNP1----------</tag>
  </m>
  <m id="m134-d1t488-39">
   <w.rf>
    <LM>w#w-d1t488-39</LM>
   </w.rf>
   <form>odborná</form>
   <lemma>odborný</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m134-d1t488-42">
   <w.rf>
    <LM>w#w-d1t488-42</LM>
   </w.rf>
   <form>zaměření</form>
   <lemma>zaměření_^(*3it)</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m134-d1t488-46">
   <w.rf>
    <LM>w#w-d1t488-46</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m134-d1t488-49">
   <w.rf>
    <LM>w#w-d1t488-49</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t488-50">
   <w.rf>
    <LM>w#w-d1t488-50</LM>
   </w.rf>
   <form>něčem</form>
   <lemma>něco</lemma>
   <tag>PK--6----------</tag>
  </m>
  <m id="m134-d1t488-51">
   <w.rf>
    <LM>w#w-d1t488-51</LM>
   </w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m134-83-111">
   <w.rf>
    <LM>w#w-83-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-88">
  <m id="m134-d1t490-2">
   <w.rf>
    <LM>w#w-d1t490-2</LM>
   </w.rf>
   <form>Jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t490-3">
   <w.rf>
    <LM>w#w-d1t490-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t490-4">
   <w.rf>
    <LM>w#w-d1t490-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m134-d1t490-5">
   <w.rf>
    <LM>w#w-d1t490-5</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t490-6">
   <w.rf>
    <LM>w#w-d1t490-6</LM>
   </w.rf>
   <form>66</form>
   <lemma>66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t490-7">
   <w.rf>
    <LM>w#w-d1t490-7</LM>
   </w.rf>
   <form>roků</form>
   <lemma>rok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m134-88-112">
   <w.rf>
    <LM>w#w-88-112</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-89">
  <m id="m134-d1t492-1">
   <w.rf>
    <LM>w#w-d1t492-1</LM>
   </w.rf>
   <form>Masírovala</form>
   <lemma>masírovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t492-2">
   <w.rf>
    <LM>w#w-d1t492-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t492-6">
   <w.rf>
    <LM>w#w-d1t492-6</LM>
   </w.rf>
   <form>drahoušky</form>
   <lemma>drahoušek</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t492-4">
   <w.rf>
    <LM>w#w-d1t492-4</LM>
   </w.rf>
   <form>domově</form>
   <lemma>domov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m134-d1t492-5">
   <w.rf>
    <LM>w#w-d1t492-5</LM>
   </w.rf>
   <form>důchodců</form>
   <lemma>důchodce</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m134-d1t492-7">
   <w.rf>
    <LM>w#w-d1t492-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m134-d1t492-8">
   <w.rf>
    <LM>w#w-d1t492-8</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t492-9">
   <w.rf>
    <LM>w#w-d1t492-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t492-10">
   <w.rf>
    <LM>w#w-d1t492-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m134-d1t492-13">
   <w.rf>
    <LM>w#w-d1t492-13</LM>
   </w.rf>
   <form>poničila</form>
   <lemma>poničit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t492-12">
   <w.rf>
    <LM>w#w-d1t492-12</LM>
   </w.rf>
   <form>šlachy</form>
   <lemma>šlacha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m134-d-id101588-punct">
   <w.rf>
    <LM>w#w-d-id101588-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t492-17">
   <w.rf>
    <LM>w#w-d1t492-17</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t492-18">
   <w.rf>
    <LM>w#w-d1t492-18</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m134-d1t492-19">
   <w.rf>
    <LM>w#w-d1t492-19</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m134-d1t492-20">
   <w.rf>
    <LM>w#w-d1t492-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t492-21">
   <w.rf>
    <LM>w#w-d1t492-21</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t492-22">
   <w.rf>
    <LM>w#w-d1t492-22</LM>
   </w.rf>
   <form>zaměřila</form>
   <lemma>zaměřit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m134-d1t492-23">
   <w.rf>
    <LM>w#w-d1t492-23</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m134-d1t492-24">
   <w.rf>
    <LM>w#w-d1t492-24</LM>
   </w.rf>
   <form>psychoterapii</form>
   <lemma>psychoterapie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-89-115">
   <w.rf>
    <LM>w#w-89-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-98">
  <m id="m134-d1t492-26">
   <w.rf>
    <LM>w#w-d1t492-26</LM>
   </w.rf>
   <form>Doufám</form>
   <lemma>doufat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d-id101752-punct">
   <w.rf>
    <LM>w#w-d-id101752-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t492-28">
   <w.rf>
    <LM>w#w-d1t492-28</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t492-29">
   <w.rf>
    <LM>w#w-d1t492-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m134-d1t492-30">
   <w.rf>
    <LM>w#w-d1t492-30</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m134-d1t492-31">
   <w.rf>
    <LM>w#w-d1t492-31</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m134-d1t492-32">
   <w.rf>
    <LM>w#w-d1t492-32</LM>
   </w.rf>
   <form>podaří</form>
   <lemma>podařit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m134-d-id101838-punct">
   <w.rf>
    <LM>w#w-d-id101838-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t492-34">
   <w.rf>
    <LM>w#w-d1t492-34</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t492-35">
   <w.rf>
    <LM>w#w-d1t492-35</LM>
   </w.rf>
   <form>66</form>
   <lemma>66</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m134-d1t492-36">
   <w.rf>
    <LM>w#w-d1t492-36</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m134-d1t492-37">
   <w.rf>
    <LM>w#w-d1t492-37</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m134-d1t492-38">
   <w.rf>
    <LM>w#w-d1t492-38</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS1----------</tag>
  </m>
  <m id="m134-d1t492-39">
   <w.rf>
    <LM>w#w-d1t492-39</LM>
   </w.rf>
   <form>stáří</form>
   <lemma>stáří</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m134-98-124">
   <w.rf>
    <LM>w#w-98-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-99">
  <m id="m134-d1t494-2">
   <w.rf>
    <LM>w#w-d1t494-2</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t494-3">
   <w.rf>
    <LM>w#w-d1t494-3</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m134-d1t494-4">
   <w.rf>
    <LM>w#w-d1t494-4</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m134-d1t494-5">
   <w.rf>
    <LM>w#w-d1t494-5</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m134-d1t494-6">
   <w.rf>
    <LM>w#w-d1t494-6</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m134-99-613">
   <w.rf>
    <LM>w#w-99-613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-614">
  <m id="m134-d1t494-9">
   <w.rf>
    <LM>w#w-d1t494-9</LM>
   </w.rf>
   <form>Věřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-99-127">
   <w.rf>
    <LM>w#w-99-127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t494-10">
   <w.rf>
    <LM>w#w-d1t494-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t494-12">
   <w.rf>
    <LM>w#w-d1t494-12</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m134-d1t494-13">
   <w.rf>
    <LM>w#w-d1t494-13</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m134-d1t494-14">
   <w.rf>
    <LM>w#w-d1t494-14</LM>
   </w.rf>
   <form>dojde</form>
   <lemma>dojít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m134-d-id102166-punct">
   <w.rf>
    <LM>w#w-d-id102166-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m134-d1t494-16">
   <w.rf>
    <LM>w#w-d1t494-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m134-d1t494-18">
   <w.rf>
    <LM>w#w-d1t494-18</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m134-d1t494-19">
   <w.rf>
    <LM>w#w-d1t494-19</LM>
   </w.rf>
   <form>psychoterapii</form>
   <lemma>psychoterapie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1t494-20">
   <w.rf>
    <LM>w#w-d1t494-20</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t494-21">
   <w.rf>
    <LM>w#w-d1t494-21</LM>
   </w.rf>
   <form>budu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m134-d1t494-22">
   <w.rf>
    <LM>w#w-d1t494-22</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m134-d-m-d1e470-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e470-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e495-x2">
  <m id="m134-d1t498-1">
   <w.rf>
    <LM>w#w-d1t498-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m134-d1t498-2">
   <w.rf>
    <LM>w#w-d1t498-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d-id102383-punct">
   <w.rf>
    <LM>w#w-d-id102383-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-d1e499-x2">
  <m id="m134-d1t502-1">
   <w.rf>
    <LM>w#w-d1t502-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t502-2">
   <w.rf>
    <LM>w#w-d1t502-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m134-d1t502-3">
   <w.rf>
    <LM>w#w-d1t502-3</LM>
   </w.rf>
   <form>píchala</form>
   <lemma>píchat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m134-d1t502-4">
   <w.rf>
    <LM>w#w-d1t502-4</LM>
   </w.rf>
   <form>injekci</form>
   <lemma>injekce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m134-d1e499-x2-140">
   <w.rf>
    <LM>w#w-d1e499-x2-140</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m134-139">
  <m id="m134-d1t504-6">
   <w.rf>
    <LM>w#w-d1t504-6</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m134-d1t504-5">
   <w.rf>
    <LM>w#w-d1t504-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m134-d1t504-7">
   <w.rf>
    <LM>w#w-d1t504-7</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m134-d1t504-8">
   <w.rf>
    <LM>w#w-d1t504-8</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m134-d1t506-1">
   <w.rf>
    <LM>w#w-d1t506-1</LM>
   </w.rf>
   <form>čepce</form>
   <lemma>čepec</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m134-d1t506-2">
   <w.rf>
    <LM>w#w-d1t506-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m134-d1t506-3">
   <w.rf>
    <LM>w#w-d1t506-3</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m134-139-190">
   <w.rf>
    <LM>w#w-139-190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
