<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ps_101.09.w.gz" />
  </references>
 </head>
 <s id="m101-278">
  <m id="m101-d1t1482-19">
   <w.rf>
    <LM>w#w-d1t1482-19</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1482-20">
   <w.rf>
    <LM>w#w-d1t1482-20</LM>
   </w.rf>
   <form>snažíme</form>
   <lemma>snažit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1482-21">
   <w.rf>
    <LM>w#w-d1t1482-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d-id148314-punct">
   <w.rf>
    <LM>w#w-d-id148314-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1482-23">
   <w.rf>
    <LM>w#w-d1t1482-23</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m101-d1t1482-26">
   <w.rf>
    <LM>w#w-d1t1482-26</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1482-24">
   <w.rf>
    <LM>w#w-d1t1482-24</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m101-d1t1482-25">
   <w.rf>
    <LM>w#w-d1t1482-25</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d1t1482-27">
   <w.rf>
    <LM>w#w-d1t1482-27</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1482-28">
   <w.rf>
    <LM>w#w-d1t1482-28</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m101-d1t1484-2">
   <w.rf>
    <LM>w#w-d1t1484-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1484-3">
   <w.rf>
    <LM>w#w-d1t1484-3</LM>
   </w.rf>
   <form>podmínky</form>
   <lemma>podmínka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-d-id148486-punct">
   <w.rf>
    <LM>w#w-d-id148486-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1484-5">
   <w.rf>
    <LM>w#w-d1t1484-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1484-6">
   <w.rf>
    <LM>w#w-d1t1484-6</LM>
   </w.rf>
   <form>volíme</form>
   <lemma>volit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1484-7">
   <w.rf>
    <LM>w#w-d1t1484-7</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1484-10">
   <w.rf>
    <LM>w#w-d1t1484-10</LM>
   </w.rf>
   <form>lacinější</form>
   <lemma>laciný</lemma>
   <tag>AAIP4----2A----</tag>
  </m>
  <m id="m101-d1t1484-11">
   <w.rf>
    <LM>w#w-d1t1484-11</LM>
   </w.rf>
   <form>zájezdy</form>
   <lemma>zájezd</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m101-d-id148604-punct">
   <w.rf>
    <LM>w#w-d-id148604-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1484-13">
   <w.rf>
    <LM>w#w-d1t1484-13</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m101-d1t1484-14">
   <w.rf>
    <LM>w#w-d1t1484-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1484-15">
   <w.rf>
    <LM>w#w-d1t1484-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m101-d1t1484-16">
   <w.rf>
    <LM>w#w-d1t1484-16</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1484-17">
   <w.rf>
    <LM>w#w-d1t1484-17</LM>
   </w.rf>
   <form>dovolit</form>
   <lemma>dovolit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-251-260">
   <w.rf>
    <LM>w#w-251-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-263">
  <m id="m101-d1t1484-19">
   <w.rf>
    <LM>w#w-d1t1484-19</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1484-20">
   <w.rf>
    <LM>w#w-d1t1484-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1484-21">
   <w.rf>
    <LM>w#w-d1t1484-21</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m101-d1t1484-22">
   <w.rf>
    <LM>w#w-d1t1484-22</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1484-23">
   <w.rf>
    <LM>w#w-d1t1484-23</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m101-d-id148776-punct">
   <w.rf>
    <LM>w#w-d-id148776-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1484-25">
   <w.rf>
    <LM>w#w-d1t1484-25</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1484-28">
   <w.rf>
    <LM>w#w-d1t1484-28</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1484-27">
   <w.rf>
    <LM>w#w-d1t1484-27</LM>
   </w.rf>
   <form>příjmy</form>
   <lemma>příjem</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m101-d1t1484-29">
   <w.rf>
    <LM>w#w-d1t1484-29</LM>
   </w.rf>
   <form>nižší</form>
   <lemma>nízký</lemma>
   <tag>AAIP1----2A----</tag>
  </m>
  <m id="m101-d1t1484-30">
   <w.rf>
    <LM>w#w-d1t1484-30</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1484-31">
   <w.rf>
    <LM>w#w-d1t1484-31</LM>
   </w.rf>
   <form>dříve</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m101-d-m-d1e1475-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1475-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1485-x2">
  <m id="m101-d1t1488-1">
   <w.rf>
    <LM>w#w-d1t1488-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m101-d1t1488-2">
   <w.rf>
    <LM>w#w-d1t1488-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m101-d1t1488-3">
   <w.rf>
    <LM>w#w-d1t1488-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1488-5">
   <w.rf>
    <LM>w#w-d1t1488-5</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-d1t1488-7">
   <w.rf>
    <LM>w#w-d1t1488-7</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m101-d1t1488-8">
   <w.rf>
    <LM>w#w-d1t1488-8</LM>
   </w.rf>
   <form>zaujalo</form>
   <lemma>zaujmout_^(upoutat_pozornost)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m101-d-id149058-punct">
   <w.rf>
    <LM>w#w-d-id149058-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1489-x2">
  <m id="m101-d1t1492-3">
   <w.rf>
    <LM>w#w-d1t1492-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1492-5">
   <w.rf>
    <LM>w#w-d1t1492-5</LM>
   </w.rf>
   <form>Řecku</form>
   <lemma>Řecko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-d1t1492-7">
   <w.rf>
    <LM>w#w-d1t1492-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1492-8">
   <w.rf>
    <LM>w#w-d1t1492-8</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1492-9">
   <w.rf>
    <LM>w#w-d1t1492-9</LM>
   </w.rf>
   <form>zajímavá</form>
   <lemma>zajímavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-d1t1492-11">
   <w.rf>
    <LM>w#w-d1t1492-11</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-d1t1492-12">
   <w.rf>
    <LM>w#w-d1t1492-12</LM>
   </w.rf>
   <form>řecká</form>
   <lemma>řecký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-d1t1492-13">
   <w.rf>
    <LM>w#w-d1t1492-13</LM>
   </w.rf>
   <form>kultura</form>
   <lemma>kultura</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m101-d1e1489-x2-305">
   <w.rf>
    <LM>w#w-d1e1489-x2-305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-306">
  <m id="m101-d1t1494-1">
   <w.rf>
    <LM>w#w-d1t1494-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1494-2">
   <w.rf>
    <LM>w#w-d1t1494-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1494-3">
   <w.rf>
    <LM>w#w-d1t1494-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1494-5">
   <w.rf>
    <LM>w#w-d1t1494-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1494-4">
   <w.rf>
    <LM>w#w-d1t1494-4</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-d1t1494-6">
   <w.rf>
    <LM>w#w-d1t1494-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1494-8">
   <w.rf>
    <LM>w#w-d1t1494-8</LM>
   </w.rf>
   <form>Akropoli</form>
   <lemma>Akropole_;G_,s_^(^DD**Akropolis-1)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d1t1494-10">
   <w.rf>
    <LM>w#w-d1t1494-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1494-12">
   <w.rf>
    <LM>w#w-d1t1494-12</LM>
   </w.rf>
   <form>Aténách</form>
   <lemma>Atény_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m101-306-312">
   <w.rf>
    <LM>w#w-306-312</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1496-1">
   <w.rf>
    <LM>w#w-d1t1496-1</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1496-2">
   <w.rf>
    <LM>w#w-d1t1496-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1496-3">
   <w.rf>
    <LM>w#w-d1t1496-3</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m101-d1t1496-4">
   <w.rf>
    <LM>w#w-d1t1496-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1496-5">
   <w.rf>
    <LM>w#w-d1t1496-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m101-d1t1496-6">
   <w.rf>
    <LM>w#w-d1t1496-6</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m101-306-313">
   <w.rf>
    <LM>w#w-306-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-315">
  <m id="m101-d1t1500-1">
   <w.rf>
    <LM>w#w-d1t1500-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1500-2">
   <w.rf>
    <LM>w#w-d1t1500-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1500-4">
   <w.rf>
    <LM>w#w-d1t1500-4</LM>
   </w.rf>
   <form>návrat</form>
   <lemma>návrat</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d1t1500-5">
   <w.rf>
    <LM>w#w-d1t1500-5</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m101-d1t1500-6">
   <w.rf>
    <LM>w#w-d1t1500-6</LM>
   </w.rf>
   <form>kořenům</form>
   <lemma>kořen-1</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m101-d1t1500-7">
   <w.rf>
    <LM>w#w-d1t1500-7</LM>
   </w.rf>
   <form>evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m101-d1t1500-8">
   <w.rf>
    <LM>w#w-d1t1500-8</LM>
   </w.rf>
   <form>kultury</form>
   <lemma>kultura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1489-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1489-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1501-x2">
  <m id="m101-d1t1504-1">
   <w.rf>
    <LM>w#w-d1t1504-1</LM>
   </w.rf>
   <form>Chutnala</form>
   <lemma>chutnat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m101-d1t1504-2">
   <w.rf>
    <LM>w#w-d1t1504-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m101-d1t1504-3">
   <w.rf>
    <LM>w#w-d1t1504-3</LM>
   </w.rf>
   <form>tamější</form>
   <lemma>tamější</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-d1t1504-4">
   <w.rf>
    <LM>w#w-d1t1504-4</LM>
   </w.rf>
   <form>kuchyně</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m101-d-id149894-punct">
   <w.rf>
    <LM>w#w-d-id149894-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1506-x2">
  <m id="m101-d1t1509-2">
   <w.rf>
    <LM>w#w-d1t1509-2</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m101-d1t1509-3">
   <w.rf>
    <LM>w#w-d1t1509-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1509-4">
   <w.rf>
    <LM>w#w-d1t1509-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m101-d1t1509-5">
   <w.rf>
    <LM>w#w-d1t1509-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1509-6">
   <w.rf>
    <LM>w#w-d1t1509-6</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1509-7">
   <w.rf>
    <LM>w#w-d1t1509-7</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m101-d-id150063-punct">
   <w.rf>
    <LM>w#w-d-id150063-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1e1506-x2-330">
   <w.rf>
    <LM>w#w-d1e1506-x2-330</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1509-9">
   <w.rf>
    <LM>w#w-d1t1509-9</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1509-11">
   <w.rf>
    <LM>w#w-d1t1509-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1509-12">
   <w.rf>
    <LM>w#w-d1t1509-12</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1509-13">
   <w.rf>
    <LM>w#w-d1t1509-13</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1509-10">
   <w.rf>
    <LM>w#w-d1t1509-10</LM>
   </w.rf>
   <form>došli</form>
   <lemma>dojít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m101-d1e1506-x2-325">
   <w.rf>
    <LM>w#w-d1e1506-x2-325</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-326">
  <m id="m101-d1t1511-2">
   <w.rf>
    <LM>w#w-d1t1511-2</LM>
   </w.rf>
   <form>Spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1511-3">
   <w.rf>
    <LM>w#w-d1t1511-3</LM>
   </w.rf>
   <form>mohu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m101-d1t1511-4">
   <w.rf>
    <LM>w#w-d1t1511-4</LM>
   </w.rf>
   <form>potvrdit</form>
   <lemma>potvrdit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-d-id150227-punct">
   <w.rf>
    <LM>w#w-d-id150227-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1511-6">
   <w.rf>
    <LM>w#w-d1t1511-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1511-7">
   <w.rf>
    <LM>w#w-d1t1511-7</LM>
   </w.rf>
   <form>řecké</form>
   <lemma>řecký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1511-8">
   <w.rf>
    <LM>w#w-d1t1511-8</LM>
   </w.rf>
   <form>víno</form>
   <lemma>víno</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d1t1511-9">
   <w.rf>
    <LM>w#w-d1t1511-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1511-10">
   <w.rf>
    <LM>w#w-d1t1511-10</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-326-327">
   <w.rf>
    <LM>w#w-326-327</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1515-1">
   <w.rf>
    <LM>w#w-d1t1515-1</LM>
   </w.rf>
   <form>případně</form>
   <lemma>případně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1515-3">
   <w.rf>
    <LM>w#w-d1t1515-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1517-2">
   <w.rf>
    <LM>w#w-d1t1517-2</LM>
   </w.rf>
   <form>pálenka</form>
   <lemma>pálenka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m101-d-id150424-punct">
   <w.rf>
    <LM>w#w-d-id150424-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1517-4">
   <w.rf>
    <LM>w#w-d1t1517-4</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m101-d1t1517-6">
   <w.rf>
    <LM>w#w-d1t1517-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1517-7">
   <w.rf>
    <LM>w#w-d1t1517-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1517-8">
   <w.rf>
    <LM>w#w-d1t1517-8</LM>
   </w.rf>
   <form>dostupná</form>
   <lemma>dostupný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-326-328">
   <w.rf>
    <LM>w#w-326-328</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-329">
  <m id="m101-d1t1520-5">
   <w.rf>
    <LM>w#w-d1t1520-5</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1520-4">
   <w.rf>
    <LM>w#w-d1t1520-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1520-6">
   <w.rf>
    <LM>w#w-d1t1520-6</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d-id150611-punct">
   <w.rf>
    <LM>w#w-d-id150611-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1520-8">
   <w.rf>
    <LM>w#w-d1t1520-8</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1520-9">
   <w.rf>
    <LM>w#w-d1t1520-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1520-10">
   <w.rf>
    <LM>w#w-d1t1520-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1520-11">
   <w.rf>
    <LM>w#w-d1t1520-11</LM>
   </w.rf>
   <form>vařili</form>
   <lemma>vařit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1520-12">
   <w.rf>
    <LM>w#w-d1t1520-12</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m101-329-338">
   <w.rf>
    <LM>w#w-329-338</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-339">
  <m id="m101-d1t1520-14">
   <w.rf>
    <LM>w#w-d1t1520-14</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1520-15">
   <w.rf>
    <LM>w#w-d1t1520-15</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d-id150737-punct">
   <w.rf>
    <LM>w#w-d-id150737-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-339-342">
   <w.rf>
    <LM>w#w-339-342</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1522-2">
   <w.rf>
    <LM>w#w-d1t1522-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1522-1">
   <w.rf>
    <LM>w#w-d1t1522-1</LM>
   </w.rf>
   <form>jedli</form>
   <lemma>jíst</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1522-3">
   <w.rf>
    <LM>w#w-d1t1522-3</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1522-5">
   <w.rf>
    <LM>w#w-d1t1522-5</LM>
   </w.rf>
   <form>klasickou</form>
   <lemma>klasický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m101-d1t1522-6">
   <w.rf>
    <LM>w#w-d1t1522-6</LM>
   </w.rf>
   <form>českou</form>
   <lemma>český</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m101-d1t1522-7">
   <w.rf>
    <LM>w#w-d1t1522-7</LM>
   </w.rf>
   <form>stravu</form>
   <lemma>strava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d1t1522-8">
   <w.rf>
    <LM>w#w-d1t1522-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1522-9">
   <w.rf>
    <LM>w#w-d1t1522-9</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1506-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1506-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1523-x2">
  <m id="m101-d1t1530-1">
   <w.rf>
    <LM>w#w-d1t1530-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m101-d1e1523-x2-345">
   <w.rf>
    <LM>w#w-d1e1523-x2-345</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-346">
  <m id="m101-d1t1532-1">
   <w.rf>
    <LM>w#w-d1t1532-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m101-d1t1532-2">
   <w.rf>
    <LM>w#w-d1t1532-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1532-3">
   <w.rf>
    <LM>w#w-d1t1532-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1532-4">
   <w.rf>
    <LM>w#w-d1t1532-4</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m101-d1t1532-5">
   <w.rf>
    <LM>w#w-d1t1532-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-346-347">
   <w.rf>
    <LM>w#w-346-347</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-348">
  <m id="m101-d1t1534-1">
   <w.rf>
    <LM>w#w-d1t1534-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1534-2">
   <w.rf>
    <LM>w#w-d1t1534-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1534-3">
   <w.rf>
    <LM>w#w-d1t1534-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m101-d1t1534-4">
   <w.rf>
    <LM>w#w-d1t1534-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1523-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1523-x2-punct-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1535-x2">
  <m id="m101-d1t1538-3">
   <w.rf>
    <LM>w#w-d1t1538-3</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1538-4">
   <w.rf>
    <LM>w#w-d1t1538-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1544-1">
   <w.rf>
    <LM>w#w-d1t1544-1</LM>
   </w.rf>
   <form>chrám</form>
   <lemma>chrám</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d-id151327-punct">
   <w.rf>
    <LM>w#w-d-id151327-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1544-3">
   <w.rf>
    <LM>w#w-d1t1544-3</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m101-d1t1544-4">
   <w.rf>
    <LM>w#w-d1t1544-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1544-5">
   <w.rf>
    <LM>w#w-d1t1544-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1544-7">
   <w.rf>
    <LM>w#w-d1t1544-7</LM>
   </w.rf>
   <form>Rudém</form>
   <lemma>rudý_;o</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m101-d1t1544-8">
   <w.rf>
    <LM>w#w-d1t1544-8</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-d1t1544-10">
   <w.rf>
    <LM>w#w-d1t1544-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1544-12">
   <w.rf>
    <LM>w#w-d1t1544-12</LM>
   </w.rf>
   <form>Moskvě</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d1e1535-x2-366">
   <w.rf>
    <LM>w#w-d1e1535-x2-366</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-367">
  <m id="m101-d1t1544-15">
   <w.rf>
    <LM>w#w-d1t1544-15</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m101-d-id151503-punct">
   <w.rf>
    <LM>w#w-d-id151503-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1544-17">
   <w.rf>
    <LM>w#w-d1t1544-17</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1544-18">
   <w.rf>
    <LM>w#w-d1t1544-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1544-19">
   <w.rf>
    <LM>w#w-d1t1544-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1544-20">
   <w.rf>
    <LM>w#w-d1t1544-20</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d1t1544-21">
   <w.rf>
    <LM>w#w-d1t1544-21</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m101-d1t1544-22">
   <w.rf>
    <LM>w#w-d1t1544-22</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d-id151605-punct">
   <w.rf>
    <LM>w#w-d-id151605-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1544-24">
   <w.rf>
    <LM>w#w-d1t1544-24</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1544-25">
   <w.rf>
    <LM>w#w-d1t1544-25</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1544-26">
   <w.rf>
    <LM>w#w-d1t1544-26</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1544-27">
   <w.rf>
    <LM>w#w-d1t1544-27</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1544-29">
   <w.rf>
    <LM>w#w-d1t1544-29</LM>
   </w.rf>
   <form>Rudé</form>
   <lemma>rudý_;o</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1544-30">
   <w.rf>
    <LM>w#w-d1t1544-30</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-367-382">
   <w.rf>
    <LM>w#w-367-382</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-383">
  <m id="m101-d1t1549-1">
   <w.rf>
    <LM>w#w-d1t1549-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1546-2">
   <w.rf>
    <LM>w#w-d1t1546-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1546-3">
   <w.rf>
    <LM>w#w-d1t1546-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1546-1">
   <w.rf>
    <LM>w#w-d1t1546-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1546-4">
   <w.rf>
    <LM>w#w-d1t1546-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m101-d1t1546-5">
   <w.rf>
    <LM>w#w-d1t1546-5</LM>
   </w.rf>
   <form>manželkou</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m101-d1t1549-2">
   <w.rf>
    <LM>w#w-d1t1549-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1549-4">
   <w.rf>
    <LM>w#w-d1t1549-4</LM>
   </w.rf>
   <form>Sovětském</form>
   <lemma>sovětský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m101-d1t1549-5">
   <w.rf>
    <LM>w#w-d1t1549-5</LM>
   </w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d1t1549-7">
   <w.rf>
    <LM>w#w-d1t1549-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1549-8">
   <w.rf>
    <LM>w#w-d1t1549-8</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-383-393">
   <w.rf>
    <LM>w#w-383-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-394">
  <m id="m101-d1t1551-1">
   <w.rf>
    <LM>w#w-d1t1551-1</LM>
   </w.rf>
   <form>Bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1551-2">
   <w.rf>
    <LM>w#w-d1t1551-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1551-3">
   <w.rf>
    <LM>w#w-d1t1551-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m101-d1t1551-4">
   <w.rf>
    <LM>w#w-d1t1551-4</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d-id152014-punct">
   <w.rf>
    <LM>w#w-d-id152014-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1551-7">
   <w.rf>
    <LM>w#w-d1t1551-7</LM>
   </w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1551-8">
   <w.rf>
    <LM>w#w-d1t1551-8</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d-id152069-punct">
   <w.rf>
    <LM>w#w-d-id152069-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1553-1">
   <w.rf>
    <LM>w#w-d1t1553-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1553-3">
   <w.rf>
    <LM>w#w-d1t1553-3</LM>
   </w.rf>
   <form>Moskvě</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d-id152142-punct">
   <w.rf>
    <LM>w#w-d-id152142-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1553-6">
   <w.rf>
    <LM>w#w-d1t1553-6</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1553-7">
   <w.rf>
    <LM>w#w-d1t1553-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1553-8">
   <w.rf>
    <LM>w#w-d1t1553-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1553-9">
   <w.rf>
    <LM>w#w-d1t1553-9</LM>
   </w.rf>
   <form>snímek</form>
   <lemma>snímek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d1t1553-10">
   <w.rf>
    <LM>w#w-d1t1553-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1553-11">
   <w.rf>
    <LM>w#w-d1t1553-11</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m101-d1t1553-12">
   <w.rf>
    <LM>w#w-d1t1553-12</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-394-401">
   <w.rf>
    <LM>w#w-394-401</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1535-x3">
  <m id="m101-d1t1555-3">
   <w.rf>
    <LM>w#w-d1t1555-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1555-4">
   <w.rf>
    <LM>w#w-d1t1555-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1555-6">
   <w.rf>
    <LM>w#w-d1t1555-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1555-5">
   <w.rf>
    <LM>w#w-d1t1555-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1555-7">
   <w.rf>
    <LM>w#w-d1t1555-7</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d1t1555-8">
   <w.rf>
    <LM>w#w-d1t1555-8</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1555-10">
   <w.rf>
    <LM>w#w-d1t1555-10</LM>
   </w.rf>
   <form>Kaspického</form>
   <lemma>kaspický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m101-d1t1555-11">
   <w.rf>
    <LM>w#w-d1t1555-11</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m101-d-id152447-punct">
   <w.rf>
    <LM>w#w-d-id152447-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1555-14">
   <w.rf>
    <LM>w#w-d1t1555-14</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1555-15">
   <w.rf>
    <LM>w#w-d1t1555-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1555-16">
   <w.rf>
    <LM>w#w-d1t1555-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1555-18">
   <w.rf>
    <LM>w#w-d1t1555-18</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m101-d1t1555-19">
   <w.rf>
    <LM>w#w-d1t1555-19</LM>
   </w.rf>
   <form>vnitrostátní</form>
   <lemma>vnitrostátní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m101-d1t1555-20">
   <w.rf>
    <LM>w#w-d1t1555-20</LM>
   </w.rf>
   <form>linkou</form>
   <lemma>linka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m101-d-id152564-punct">
   <w.rf>
    <LM>w#w-d-id152564-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1555-22">
   <w.rf>
    <LM>w#w-d1t1555-22</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1555-23">
   <w.rf>
    <LM>w#w-d1t1555-23</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1555-24">
   <w.rf>
    <LM>w#w-d1t1555-24</LM>
   </w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m101-d1e1535-x3-414">
   <w.rf>
    <LM>w#w-d1e1535-x3-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-415">
  <m id="m101-d1t1557-1">
   <w.rf>
    <LM>w#w-d1t1557-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1557-2">
   <w.rf>
    <LM>w#w-d1t1557-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1557-4">
   <w.rf>
    <LM>w#w-d1t1557-4</LM>
   </w.rf>
   <form>ubytováni</form>
   <lemma>ubytovat</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m101-d1t1557-5">
   <w.rf>
    <LM>w#w-d1t1557-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1557-7">
   <w.rf>
    <LM>w#w-d1t1557-7</LM>
   </w.rf>
   <form>Machačkale</form>
   <lemma>Machačkala_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d-id152745-punct">
   <w.rf>
    <LM>w#w-d-id152745-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1557-10">
   <w.rf>
    <LM>w#w-d1t1557-10</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m101-d1t1557-11">
   <w.rf>
    <LM>w#w-d1t1557-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1557-12">
   <w.rf>
    <LM>w#w-d1t1557-12</LM>
   </w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1557-13">
   <w.rf>
    <LM>w#w-d1t1557-13</LM>
   </w.rf>
   <form>město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d1t1557-15">
   <w.rf>
    <LM>w#w-d1t1557-15</LM>
   </w.rf>
   <form>Dagestánské</form>
   <lemma>dagestánský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m101-d1t1557-18">
   <w.rf>
    <LM>w#w-d1t1557-18</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-415-425">
   <w.rf>
    <LM>w#w-415-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-426">
  <m id="m101-d1t1566-1">
   <w.rf>
    <LM>w#w-d1t1566-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1566-2">
   <w.rf>
    <LM>w#w-d1t1566-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1566-3">
   <w.rf>
    <LM>w#w-d1t1566-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1566-5">
   <w.rf>
    <LM>w#w-d1t1566-5</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1566-6">
   <w.rf>
    <LM>w#w-d1t1566-6</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d1t1566-8">
   <w.rf>
    <LM>w#w-d1t1566-8</LM>
   </w.rf>
   <form>určitých</form>
   <lemma>určitý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m101-d1t1566-9">
   <w.rf>
    <LM>w#w-d1t1566-9</LM>
   </w.rf>
   <form>výletů</form>
   <lemma>výlet</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m101-d1t1566-11">
   <w.rf>
    <LM>w#w-d1t1566-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1566-12">
   <w.rf>
    <LM>w#w-d1t1566-12</LM>
   </w.rf>
   <form>okolí</form>
   <lemma>okolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-426-430">
   <w.rf>
    <LM>w#w-426-430</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-432">
  <m id="m101-d1t1568-1">
   <w.rf>
    <LM>w#w-d1t1568-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m101-d1t1568-2">
   <w.rf>
    <LM>w#w-d1t1568-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1568-4">
   <w.rf>
    <LM>w#w-d1t1568-4</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1568-5">
   <w.rf>
    <LM>w#w-d1t1568-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m101-d1t1568-6">
   <w.rf>
    <LM>w#w-d1t1568-6</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1568-7">
   <w.rf>
    <LM>w#w-d1t1568-7</LM>
   </w.rf>
   <form>zajímavá</form>
   <lemma>zajímavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m101-d1t1568-8">
   <w.rf>
    <LM>w#w-d1t1568-8</LM>
   </w.rf>
   <form>zkušenost</form>
   <lemma>zkušenost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m101-d-id153292-punct">
   <w.rf>
    <LM>w#w-d-id153292-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1568-10">
   <w.rf>
    <LM>w#w-d1t1568-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1568-11">
   <w.rf>
    <LM>w#w-d1t1568-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1568-12">
   <w.rf>
    <LM>w#w-d1t1568-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1568-13">
   <w.rf>
    <LM>w#w-d1t1568-13</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1568-14">
   <w.rf>
    <LM>w#w-d1t1568-14</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m101-d1t1568-15">
   <w.rf>
    <LM>w#w-d1t1568-15</LM>
   </w.rf>
   <form>svět</form>
   <lemma>svět</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-432-447">
   <w.rf>
    <LM>w#w-432-447</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1535-x4">
  <m id="m101-d1t1568-17">
   <w.rf>
    <LM>w#w-d1t1568-17</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1568-18">
   <w.rf>
    <LM>w#w-d1t1568-18</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1568-19">
   <w.rf>
    <LM>w#w-d1t1568-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1568-23">
   <w.rf>
    <LM>w#w-d1t1568-23</LM>
   </w.rf>
   <form>Kavkaz</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d-id153513-punct">
   <w.rf>
    <LM>w#w-d-id153513-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1570-1">
   <w.rf>
    <LM>w#w-d1t1570-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1570-2">
   <w.rf>
    <LM>w#w-d1t1570-2</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d1t1570-3">
   <w.rf>
    <LM>w#w-d1t1570-3</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1570-4">
   <w.rf>
    <LM>w#w-d1t1570-4</LM>
   </w.rf>
   <form>holé</form>
   <lemma>holý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m101-d1t1570-5">
   <w.rf>
    <LM>w#w-d1t1570-5</LM>
   </w.rf>
   <form>vršky</form>
   <lemma>vršek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m101-d-id153615-punct">
   <w.rf>
    <LM>w#w-d-id153615-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1570-7">
   <w.rf>
    <LM>w#w-d1t1570-7</LM>
   </w.rf>
   <form>kamenité</form>
   <lemma>kamenitý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m101-d-id153639-punct">
   <w.rf>
    <LM>w#w-d-id153639-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1570-9">
   <w.rf>
    <LM>w#w-d1t1570-9</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1570-10">
   <w.rf>
    <LM>w#w-d1t1570-10</LM>
   </w.rf>
   <form>teplo</form>
   <lemma>teplo-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d-id153679-punct">
   <w.rf>
    <LM>w#w-d-id153679-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1570-12">
   <w.rf>
    <LM>w#w-d1t1570-12</LM>
   </w.rf>
   <form>palčivé</form>
   <lemma>palčivý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1570-13">
   <w.rf>
    <LM>w#w-d1t1570-13</LM>
   </w.rf>
   <form>sluníčko</form>
   <lemma>sluníčko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d1t1572-2">
   <w.rf>
    <LM>w#w-d1t1572-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1572-4">
   <w.rf>
    <LM>w#w-d1t1572-4</LM>
   </w.rf>
   <form>osvěžení</form>
   <lemma>osvěžení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-d1t1572-5">
   <w.rf>
    <LM>w#w-d1t1572-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1572-8">
   <w.rf>
    <LM>w#w-d1t1572-8</LM>
   </w.rf>
   <form>Kaspického</form>
   <lemma>kaspický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m101-d1t1572-9">
   <w.rf>
    <LM>w#w-d1t1572-9</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1535-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1535-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1573-x2">
  <m id="m101-d1t1576-1">
   <w.rf>
    <LM>w#w-d1t1576-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m101-d1t1576-2">
   <w.rf>
    <LM>w#w-d1t1576-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m101-d1t1576-3">
   <w.rf>
    <LM>w#w-d1t1576-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m101-d1t1576-4">
   <w.rf>
    <LM>w#w-d1t1576-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1576-6">
   <w.rf>
    <LM>w#w-d1t1576-6</LM>
   </w.rf>
   <form>Rusku</form>
   <lemma>Rusko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-d1t1576-8">
   <w.rf>
    <LM>w#w-d1t1576-8</LM>
   </w.rf>
   <form>navštívili</form>
   <lemma>navštívit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m101-d-id154048-punct">
   <w.rf>
    <LM>w#w-d-id154048-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1577-x2">
  <m id="m101-d1t1580-4">
   <w.rf>
    <LM>w#w-d1t1580-4</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1580-7">
   <w.rf>
    <LM>w#w-d1t1580-7</LM>
   </w.rf>
   <form>Kaspického</form>
   <lemma>kaspický</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m101-d1t1580-8">
   <w.rf>
    <LM>w#w-d1t1580-8</LM>
   </w.rf>
   <form>jezera</form>
   <lemma>jezero</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m101-d1t1580-10">
   <w.rf>
    <LM>w#w-d1t1580-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1580-11">
   <w.rf>
    <LM>w#w-d1t1580-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1580-12">
   <w.rf>
    <LM>w#w-d1t1580-12</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1580-13">
   <w.rf>
    <LM>w#w-d1t1580-13</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-d1t1580-14">
   <w.rf>
    <LM>w#w-d1t1580-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1580-16">
   <w.rf>
    <LM>w#w-d1t1580-16</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m101-d1t1580-17">
   <w.rf>
    <LM>w#w-d1t1580-17</LM>
   </w.rf>
   <form>přehradě</form>
   <lemma>přehrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d-id154359-punct">
   <w.rf>
    <LM>w#w-d-id154359-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1580-19">
   <w.rf>
    <LM>w#w-d1t1580-19</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m101-d1t1580-20">
   <w.rf>
    <LM>w#w-d1t1580-20</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m101-d1t1580-21">
   <w.rf>
    <LM>w#w-d1t1580-21</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1580-22">
   <w.rf>
    <LM>w#w-d1t1580-22</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1580-24">
   <w.rf>
    <LM>w#w-d1t1580-24</LM>
   </w.rf>
   <form>kamenitých</form>
   <lemma>kamenitý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m101-d1t1580-25">
   <w.rf>
    <LM>w#w-d1t1580-25</LM>
   </w.rf>
   <form>kopců</form>
   <lemma>kopec</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m101-d1e1577-x2-472">
   <w.rf>
    <LM>w#w-d1e1577-x2-472</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-473">
  <m id="m101-d1t1582-1">
   <w.rf>
    <LM>w#w-d1t1582-1</LM>
   </w.rf>
   <form>Viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1582-2">
   <w.rf>
    <LM>w#w-d1t1582-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1582-3">
   <w.rf>
    <LM>w#w-d1t1582-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1582-4">
   <w.rf>
    <LM>w#w-d1t1582-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1582-5">
   <w.rf>
    <LM>w#w-d1t1582-5</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m101-d1t1582-7">
   <w.rf>
    <LM>w#w-d1t1582-7</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1582-8">
   <w.rf>
    <LM>w#w-d1t1582-8</LM>
   </w.rf>
   <form>starou</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m101-d1t1582-9">
   <w.rf>
    <LM>w#w-d1t1582-9</LM>
   </w.rf>
   <form>pevnost</form>
   <lemma>pevnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d-id154632-punct">
   <w.rf>
    <LM>w#w-d-id154632-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1582-15">
   <w.rf>
    <LM>w#w-d1t1582-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1582-16">
   <w.rf>
    <LM>w#w-d1t1582-16</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m101-d1t1582-12">
   <w.rf>
    <LM>w#w-d1t1582-12</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1582-13">
   <w.rf>
    <LM>w#w-d1t1582-13</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1582-14">
   <w.rf>
    <LM>w#w-d1t1582-14</LM>
   </w.rf>
   <form>nevzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m101-473-482">
   <w.rf>
    <LM>w#w-473-482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-483">
  <m id="m101-d1t1584-3">
   <w.rf>
    <LM>w#w-d1t1584-3</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1584-2">
   <w.rf>
    <LM>w#w-d1t1584-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1584-1">
   <w.rf>
    <LM>w#w-d1t1584-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1584-7">
   <w.rf>
    <LM>w#w-d1t1584-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1584-10">
   <w.rf>
    <LM>w#w-d1t1584-10</LM>
   </w.rf>
   <form>Machačkaly</form>
   <lemma>Machačkala_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-d1t1584-4">
   <w.rf>
    <LM>w#w-d1t1584-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1584-5">
   <w.rf>
    <LM>w#w-d1t1584-5</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m101-d1t1584-6">
   <w.rf>
    <LM>w#w-d1t1584-6</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m101-483-485">
   <w.rf>
    <LM>w#w-483-485</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-486">
  <m id="m101-d1t1586-1">
   <w.rf>
    <LM>w#w-d1t1586-1</LM>
   </w.rf>
   <form>Prohlédli</form>
   <lemma>prohlédnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m101-d1t1586-2">
   <w.rf>
    <LM>w#w-d1t1586-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1586-3">
   <w.rf>
    <LM>w#w-d1t1586-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1586-4">
   <w.rf>
    <LM>w#w-d1t1586-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1586-6">
   <w.rf>
    <LM>w#w-d1t1586-6</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m101-d1t1586-8">
   <w.rf>
    <LM>w#w-d1t1586-8</LM>
   </w.rf>
   <form>Machačkalu</form>
   <lemma>Machačkala_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d-id155057-punct">
   <w.rf>
    <LM>w#w-d-id155057-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1586-11">
   <w.rf>
    <LM>w#w-d1t1586-11</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1586-12">
   <w.rf>
    <LM>w#w-d1t1586-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1586-13">
   <w.rf>
    <LM>w#w-d1t1586-13</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1586-15">
   <w.rf>
    <LM>w#w-d1t1586-15</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1586-16">
   <w.rf>
    <LM>w#w-d1t1586-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1586-17">
   <w.rf>
    <LM>w#w-d1t1586-17</LM>
   </w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m101-d-id155174-punct">
   <w.rf>
    <LM>w#w-d-id155174-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1586-19">
   <w.rf>
    <LM>w#w-d1t1586-19</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1586-22">
   <w.rf>
    <LM>w#w-d1t1586-22</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1586-23">
   <w.rf>
    <LM>w#w-d1t1586-23</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m101-d1t1586-24">
   <w.rf>
    <LM>w#w-d1t1586-24</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1586-25">
   <w.rf>
    <LM>w#w-d1t1586-25</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m101-d1t1586-26">
   <w.rf>
    <LM>w#w-d1t1586-26</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m101-486-509">
   <w.rf>
    <LM>w#w-486-509</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1577-x3">
  <m id="m101-d1t1588-1">
   <w.rf>
    <LM>w#w-d1t1588-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1588-4">
   <w.rf>
    <LM>w#w-d1t1588-4</LM>
   </w.rf>
   <form>Moskvě</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d1t1588-8">
   <w.rf>
    <LM>w#w-d1t1588-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1588-10">
   <w.rf>
    <LM>w#w-d1t1588-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1588-9">
   <w.rf>
    <LM>w#w-d1t1588-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1588-11">
   <w.rf>
    <LM>w#w-d1t1588-11</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-d1t1588-12">
   <w.rf>
    <LM>w#w-d1t1588-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1588-14">
   <w.rf>
    <LM>w#w-d1t1588-14</LM>
   </w.rf>
   <form>Kremlu</form>
   <lemma>Kreml_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d1e1577-x3-520">
   <w.rf>
    <LM>w#w-d1e1577-x3-520</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-521">
  <m id="m101-d1t1595-1">
   <w.rf>
    <LM>w#w-d1t1595-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1595-2">
   <w.rf>
    <LM>w#w-d1t1595-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1595-3">
   <w.rf>
    <LM>w#w-d1t1595-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1595-4">
   <w.rf>
    <LM>w#w-d1t1595-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1595-5">
   <w.rf>
    <LM>w#w-d1t1595-5</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d1t1595-6">
   <w.rf>
    <LM>w#w-d1t1595-6</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1595-8">
   <w.rf>
    <LM>w#w-d1t1595-8</LM>
   </w.rf>
   <form>Moskvu</form>
   <lemma>Moskva_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d-id155755-punct">
   <w.rf>
    <LM>w#w-d-id155755-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1597-1">
   <w.rf>
    <LM>w#w-d1t1597-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1597-3">
   <w.rf>
    <LM>w#w-d1t1597-3</LM>
   </w.rf>
   <form>Jaroslavli</form>
   <lemma>Jaroslavl_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-521-528">
   <w.rf>
    <LM>w#w-521-528</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-529">
  <m id="m101-d1t1597-5">
   <w.rf>
    <LM>w#w-d1t1597-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1597-6">
   <w.rf>
    <LM>w#w-d1t1597-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1597-7">
   <w.rf>
    <LM>w#w-d1t1597-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1597-8">
   <w.rf>
    <LM>w#w-d1t1597-8</LM>
   </w.rf>
   <form>prohlédli</form>
   <lemma>prohlédnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m101-d1t1597-12">
   <w.rf>
    <LM>w#w-d1t1597-12</LM>
   </w.rf>
   <form>pravoslavné</form>
   <lemma>pravoslavný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m101-d1t1597-13">
   <w.rf>
    <LM>w#w-d1t1597-13</LM>
   </w.rf>
   <form>kostely</form>
   <lemma>kostel</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m101-d-id155976-punct">
   <w.rf>
    <LM>w#w-d-id155976-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1597-15">
   <w.rf>
    <LM>w#w-d1t1597-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1597-16">
   <w.rf>
    <LM>w#w-d1t1597-16</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1597-17">
   <w.rf>
    <LM>w#w-d1t1597-17</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1597-18">
   <w.rf>
    <LM>w#w-d1t1597-18</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1597-19">
   <w.rf>
    <LM>w#w-d1t1597-19</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-529-533">
   <w.rf>
    <LM>w#w-529-533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-534">
  <m id="m101-d1t1599-1">
   <w.rf>
    <LM>w#w-d1t1599-1</LM>
   </w.rf>
   <form>Slyšeli</form>
   <lemma>slyšet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1599-2">
   <w.rf>
    <LM>w#w-d1t1599-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1599-3">
   <w.rf>
    <LM>w#w-d1t1599-3</LM>
   </w.rf>
   <form>zpěv</form>
   <lemma>zpěv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d1t1599-5">
   <w.rf>
    <LM>w#w-d1t1599-5</LM>
   </w.rf>
   <form>věřících</form>
   <lemma>věřící-1</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m101-d1t1599-7">
   <w.rf>
    <LM>w#w-d1t1599-7</LM>
   </w.rf>
   <form>pravoslavné</form>
   <lemma>pravoslavný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m101-d1t1599-8">
   <w.rf>
    <LM>w#w-d1t1599-8</LM>
   </w.rf>
   <form>církve</form>
   <lemma>církev</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-534-535">
   <w.rf>
    <LM>w#w-534-535</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-536">
  <m id="m101-d1t1601-1">
   <w.rf>
    <LM>w#w-d1t1601-1</LM>
   </w.rf>
   <form>Viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1601-2">
   <w.rf>
    <LM>w#w-d1t1601-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1601-3">
   <w.rf>
    <LM>w#w-d1t1601-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m101-d1t1601-4">
   <w.rf>
    <LM>w#w-d1t1601-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1601-5">
   <w.rf>
    <LM>w#w-d1t1601-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1601-6">
   <w.rf>
    <LM>w#w-d1t1601-6</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1601-7">
   <w.rf>
    <LM>w#w-d1t1601-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1601-8">
   <w.rf>
    <LM>w#w-d1t1601-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m101-d1t1601-9">
   <w.rf>
    <LM>w#w-d1t1601-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d-m-d1e1577-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1577-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1602-x2">
  <m id="m101-d1t1605-1">
   <w.rf>
    <LM>w#w-d1t1605-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1605-2">
   <w.rf>
    <LM>w#w-d1t1605-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1605-3">
   <w.rf>
    <LM>w#w-d1t1605-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m101-d1t1605-4">
   <w.rf>
    <LM>w#w-d1t1605-4</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m101-d1t1605-5">
   <w.rf>
    <LM>w#w-d1t1605-5</LM>
   </w.rf>
   <form>vycestovat</form>
   <lemma>vycestovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-d-id156488-punct">
   <w.rf>
    <LM>w#w-d-id156488-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1606-x2">
  <m id="m101-d1t1611-2">
   <w.rf>
    <LM>w#w-d1t1611-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1611-3">
   <w.rf>
    <LM>w#w-d1t1611-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1615-1">
   <w.rf>
    <LM>w#w-d1t1615-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1615-2">
   <w.rf>
    <LM>w#w-d1t1615-2</LM>
   </w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d1t1615-3">
   <w.rf>
    <LM>w#w-d1t1615-3</LM>
   </w.rf>
   <form>rekreace</form>
   <lemma>rekreace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m101-d-id156676-punct">
   <w.rf>
    <LM>w#w-d-id156676-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1615-5">
   <w.rf>
    <LM>w#w-d1t1615-5</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m101-d1t1617-1">
   <w.rf>
    <LM>w#w-d1t1617-1</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1620-1">
   <w.rf>
    <LM>w#w-d1t1620-1</LM>
   </w.rf>
   <form>pořádalo</form>
   <lemma>pořádat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1620-3">
   <w.rf>
    <LM>w#w-d1t1620-3</LM>
   </w.rf>
   <form>ROH</form>
   <lemma>ROH_;m_^(Revoluční_odborové_hnutí)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m101-d1e1606-x2-550">
   <w.rf>
    <LM>w#w-d1e1606-x2-550</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-551">
  <m id="m101-d1t1622-1">
   <w.rf>
    <LM>w#w-d1t1622-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1622-3">
   <w.rf>
    <LM>w#w-d1t1622-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d1t1622-5">
   <w.rf>
    <LM>w#w-d1t1622-5</LM>
   </w.rf>
   <form>Revoluční</form>
   <lemma>revoluční</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1622-6">
   <w.rf>
    <LM>w#w-d1t1622-6</LM>
   </w.rf>
   <form>odborové</form>
   <lemma>odborový</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d1t1622-7">
   <w.rf>
    <LM>w#w-d1t1622-7</LM>
   </w.rf>
   <form>hnutí</form>
   <lemma>hnutí_^(*3out)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m101-551-563">
   <w.rf>
    <LM>w#w-551-563</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-564">
  <m id="m101-d1t1622-10">
   <w.rf>
    <LM>w#w-d1t1622-10</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1622-11">
   <w.rf>
    <LM>w#w-d1t1622-11</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m101-d1t1622-12">
   <w.rf>
    <LM>w#w-d1t1622-12</LM>
   </w.rf>
   <form>odborový</form>
   <lemma>odborový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m101-d1t1622-13">
   <w.rf>
    <LM>w#w-d1t1622-13</LM>
   </w.rf>
   <form>svaz</form>
   <lemma>svaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d1t1622-14">
   <w.rf>
    <LM>w#w-d1t1622-14</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1622-15">
   <w.rf>
    <LM>w#w-d1t1622-15</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1622-16">
   <w.rf>
    <LM>w#w-d1t1622-16</LM>
   </w.rf>
   <form>neexistoval</form>
   <lemma>existovat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m101-564-586">
   <w.rf>
    <LM>w#w-564-586</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-587">
  <m id="m101-d1t1624-2">
   <w.rf>
    <LM>w#w-d1t1624-2</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1624-3">
   <w.rf>
    <LM>w#w-d1t1624-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1624-7">
   <w.rf>
    <LM>w#w-d1t1624-7</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1624-5">
   <w.rf>
    <LM>w#w-d1t1624-5</LM>
   </w.rf>
   <form>výměnné</form>
   <lemma>výměnný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m101-d1t1624-6">
   <w.rf>
    <LM>w#w-d1t1624-6</LM>
   </w.rf>
   <form>rekreace</form>
   <lemma>rekreace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m101-587-596">
   <w.rf>
    <LM>w#w-587-596</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-597">
  <m id="m101-d1t1624-9">
   <w.rf>
    <LM>w#w-d1t1624-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1624-10">
   <w.rf>
    <LM>w#w-d1t1624-10</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m101-d-id157187-punct">
   <w.rf>
    <LM>w#w-d-id157187-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1624-12">
   <w.rf>
    <LM>w#w-d1t1624-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1624-13">
   <w.rf>
    <LM>w#w-d1t1624-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m101-d1t1624-14">
   <w.rf>
    <LM>w#w-d1t1624-14</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m101-d1t1624-15">
   <w.rf>
    <LM>w#w-d1t1624-15</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1624-16">
   <w.rf>
    <LM>w#w-d1t1624-16</LM>
   </w.rf>
   <form>turisti</form>
   <lemma>turista</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m101-d1t1624-17">
   <w.rf>
    <LM>w#w-d1t1624-17</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1624-23">
   <w.rf>
    <LM>w#w-d1t1624-23</LM>
   </w.rf>
   <form>bývalého</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m101-d1t1624-20">
   <w.rf>
    <LM>w#w-d1t1624-20</LM>
   </w.rf>
   <form>Sovětského</form>
   <lemma>sovětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m101-d1t1624-21">
   <w.rf>
    <LM>w#w-d1t1624-21</LM>
   </w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m101-597-606">
   <w.rf>
    <LM>w#w-597-606</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1626-1">
   <w.rf>
    <LM>w#w-d1t1626-1</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m101-d1t1626-2">
   <w.rf>
    <LM>w#w-d1t1626-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1626-3">
   <w.rf>
    <LM>w#w-d1t1626-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1626-4">
   <w.rf>
    <LM>w#w-d1t1626-4</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m101-d1t1626-5">
   <w.rf>
    <LM>w#w-d1t1626-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1626-7">
   <w.rf>
    <LM>w#w-d1t1626-7</LM>
   </w.rf>
   <form>Sovětského</form>
   <lemma>sovětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m101-d1t1626-8">
   <w.rf>
    <LM>w#w-d1t1626-8</LM>
   </w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m101-597-607">
   <w.rf>
    <LM>w#w-597-607</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-608">
  <m id="m101-d1t1626-11">
   <w.rf>
    <LM>w#w-d1t1626-11</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m101-d1t1626-12">
   <w.rf>
    <LM>w#w-d1t1626-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m101-d1t1626-14">
   <w.rf>
    <LM>w#w-d1t1626-14</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m101-d1t1626-15">
   <w.rf>
    <LM>w#w-d1t1626-15</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m101-d1t1626-17">
   <w.rf>
    <LM>w#w-d1t1626-17</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m101-d-id157628-punct">
   <w.rf>
    <LM>w#w-d-id157628-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1628-1">
   <w.rf>
    <LM>w#w-d1t1628-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m101-d1t1628-2">
   <w.rf>
    <LM>w#w-d1t1628-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1628-3">
   <w.rf>
    <LM>w#w-d1t1628-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1628-4">
   <w.rf>
    <LM>w#w-d1t1628-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1628-5">
   <w.rf>
    <LM>w#w-d1t1628-5</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m101-d1t1628-6">
   <w.rf>
    <LM>w#w-d1t1628-6</LM>
   </w.rf>
   <form>uskutečnit</form>
   <lemma>uskutečnit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-608-620">
   <w.rf>
    <LM>w#w-608-620</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1606-x3">
  <m id="m101-d1t1630-3">
   <w.rf>
    <LM>w#w-d1t1630-3</LM>
   </w.rf>
   <form>Vzpomínáme</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m101-d1t1630-4">
   <w.rf>
    <LM>w#w-d1t1630-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1630-5">
   <w.rf>
    <LM>w#w-d1t1630-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m101-d1t1630-7">
   <w.rf>
    <LM>w#w-d1t1630-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1630-8">
   <w.rf>
    <LM>w#w-d1t1630-8</LM>
   </w.rf>
   <form>dobrém</form>
   <lemma>dobrý</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m101-d1e1606-x3-624">
   <w.rf>
    <LM>w#w-d1e1606-x3-624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-625">
  <m id="m101-d1t1630-10">
   <w.rf>
    <LM>w#w-d1t1630-10</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1630-11">
   <w.rf>
    <LM>w#w-d1t1630-11</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m101-d1t1630-12">
   <w.rf>
    <LM>w#w-d1t1630-12</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m101-d1t1630-21">
   <w.rf>
    <LM>w#w-d1t1630-21</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d1t1630-20">
   <w.rf>
    <LM>w#w-d1t1630-20</LM>
   </w.rf>
   <form>pořádaný</form>
   <lemma>pořádaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m101-d1t1630-16">
   <w.rf>
    <LM>w#w-d1t1630-16</LM>
   </w.rf>
   <form>speciálně</form>
   <lemma>speciálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1630-17">
   <w.rf>
    <LM>w#w-d1t1630-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1630-18">
   <w.rf>
    <LM>w#w-d1t1630-18</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m101-d1t1630-19">
   <w.rf>
    <LM>w#w-d1t1630-19</LM>
   </w.rf>
   <form>rozsahu</form>
   <lemma>rozsah</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m101-d1t1630-24">
   <w.rf>
    <LM>w#w-d1t1630-24</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m101-d1t1630-25">
   <w.rf>
    <LM>w#w-d1t1630-25</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1630-26">
   <w.rf>
    <LM>w#w-d1t1630-26</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1630-27">
   <w.rf>
    <LM>w#w-d1t1630-27</LM>
   </w.rf>
   <form>peněz</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m101-625-629">
   <w.rf>
    <LM>w#w-625-629</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-631">
  <m id="m101-d1t1630-29">
   <w.rf>
    <LM>w#w-d1t1630-29</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1630-30">
   <w.rf>
    <LM>w#w-d1t1630-30</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m101-d1t1630-31">
   <w.rf>
    <LM>w#w-d1t1630-31</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m101-d1t1630-32">
   <w.rf>
    <LM>w#w-d1t1630-32</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m101-d1t1630-33">
   <w.rf>
    <LM>w#w-d1t1630-33</LM>
   </w.rf>
   <form>nemohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m101-d1t1630-34">
   <w.rf>
    <LM>w#w-d1t1630-34</LM>
   </w.rf>
   <form>dovolit</form>
   <lemma>dovolit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m101-631-634">
   <w.rf>
    <LM>w#w-631-634</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1633-1">
   <w.rf>
    <LM>w#w-d1t1633-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m101-d1t1633-2">
   <w.rf>
    <LM>w#w-d1t1633-2</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m101-d1t1633-3">
   <w.rf>
    <LM>w#w-d1t1633-3</LM>
   </w.rf>
   <form>cesty</form>
   <lemma>cesta</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m101-d1t1633-4">
   <w.rf>
    <LM>w#w-d1t1633-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m101-d1t1633-5">
   <w.rf>
    <LM>w#w-d1t1633-5</LM>
   </w.rf>
   <form>letecky</form>
   <lemma>letecky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1633-7">
   <w.rf>
    <LM>w#w-d1t1633-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m101-d1t1635-1">
   <w.rf>
    <LM>w#w-d1t1635-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m101-d1t1635-2">
   <w.rf>
    <LM>w#w-d1t1635-2</LM>
   </w.rf>
   <form>veškerým</form>
   <lemma>veškerý</lemma>
   <tag>PLZS7----------</tag>
  </m>
  <m id="m101-d1t1635-3">
   <w.rf>
    <LM>w#w-d1t1635-3</LM>
   </w.rf>
   <form>zaopatřením</form>
   <lemma>zaopatření_^(*3it)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m101-d-id158459-punct">
   <w.rf>
    <LM>w#w-d-id158459-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m101-d1t1637-1">
   <w.rf>
    <LM>w#w-d1t1637-1</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m101-d1t1637-2">
   <w.rf>
    <LM>w#w-d1t1637-2</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1637-6">
   <w.rf>
    <LM>w#w-d1t1637-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1637-7">
   <w.rf>
    <LM>w#w-d1t1637-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m101-d1t1637-4">
   <w.rf>
    <LM>w#w-d1t1637-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m101-d1t1637-5">
   <w.rf>
    <LM>w#w-d1t1637-5</LM>
   </w.rf>
   <form>podstatě</form>
   <lemma>podstata</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m101-d1t1637-9">
   <w.rf>
    <LM>w#w-d1t1637-9</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m101-d1t1637-10">
   <w.rf>
    <LM>w#w-d1t1637-10</LM>
   </w.rf>
   <form>únosné</form>
   <lemma>únosný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m101-d-m-d1e1606-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1606-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1638-x2">
  <m id="m101-d1t1641-1">
   <w.rf>
    <LM>w#w-d1t1641-1</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m101-d1t1641-2">
   <w.rf>
    <LM>w#w-d1t1641-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m101-d1t1641-3">
   <w.rf>
    <LM>w#w-d1t1641-3</LM>
   </w.rf>
   <form>vypršel</form>
   <lemma>vypršet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m101-d1t1641-4">
   <w.rf>
    <LM>w#w-d1t1641-4</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1638-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1638-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1642-x2">
  <m id="m101-d1t1645-1">
   <w.rf>
    <LM>w#w-d1t1645-1</LM>
   </w.rf>
   <form>Nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m101-d1t1645-2">
   <w.rf>
    <LM>w#w-d1t1645-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1645-3">
   <w.rf>
    <LM>w#w-d1t1645-3</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m101-d1t1645-4">
   <w.rf>
    <LM>w#w-d1t1645-4</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m101-d1e1642-x2-636">
   <w.rf>
    <LM>w#w-d1e1642-x2-636</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-637">
  <m id="m101-d1t1645-6">
   <w.rf>
    <LM>w#w-d1t1645-6</LM>
   </w.rf>
   <form>Mějte</form>
   <lemma>mít</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m101-d1t1645-7">
   <w.rf>
    <LM>w#w-d1t1645-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1645-8">
   <w.rf>
    <LM>w#w-d1t1645-8</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d-m-d1e1642-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1642-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1646-x2">
  <m id="m101-d1t1649-1">
   <w.rf>
    <LM>w#w-d1t1649-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m101-d1t1649-2">
   <w.rf>
    <LM>w#w-d1t1649-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m101-d1t1649-3">
   <w.rf>
    <LM>w#w-d1t1649-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1649-4">
   <w.rf>
    <LM>w#w-d1t1649-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSIS4-P2-------</tag>
  </m>
  <m id="m101-d1t1649-5">
   <w.rf>
    <LM>w#w-d1t1649-5</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m101-d1e1646-x2-639">
   <w.rf>
    <LM>w#w-d1e1646-x2-639</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-640">
  <m id="m101-d1t1651-1">
   <w.rf>
    <LM>w#w-d1t1651-1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m101-d1t1651-2">
   <w.rf>
    <LM>w#w-d1t1651-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m101-d1t1651-3">
   <w.rf>
    <LM>w#w-d1t1651-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m101-d1t1651-4">
   <w.rf>
    <LM>w#w-d1t1651-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m101-d1t1651-5">
   <w.rf>
    <LM>w#w-d1t1651-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m101-d1t1651-6">
   <w.rf>
    <LM>w#w-d1t1651-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m101-d1t1651-7">
   <w.rf>
    <LM>w#w-d1t1651-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m101-d-m-d1e1646-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1646-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1652-x2">
  <m id="m101-d1t1655-1">
   <w.rf>
    <LM>w#w-d1t1655-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m101-d-m-d1e1652-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1652-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m101-d1e1657-x2">
  <m id="m101-d1t1660-1">
   <w.rf>
    <LM>w#w-d1t1660-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m101-d1t1660-2">
   <w.rf>
    <LM>w#w-d1t1660-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m101-d-m-d1e1657-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1657-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
