<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jv_105.13.w.gz" />
  </references>
 </head>
 <s id="m105-d1e2826-x2">
  <m id="m105-d1t2831-2">
   <w.rf>
    <LM>w#w-d1t2831-2</LM>
   </w.rf>
   <form>Tyhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m105-d1t2831-3">
   <w.rf>
    <LM>w#w-d1t2831-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m105-d1t2831-5">
   <w.rf>
    <LM>w#w-d1t2831-5</LM>
   </w.rf>
   <form>neznám</form>
   <lemma>znát</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m105-d1e2826-x2-326">
   <w.rf>
    <LM>w#w-d1e2826-x2-326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-337">
  <m id="m105-d1t2831-20">
   <w.rf>
    <LM>w#w-d1t2831-20</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2831-19">
   <w.rf>
    <LM>w#w-d1t2831-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m105-d1t2831-21">
   <w.rf>
    <LM>w#w-d1t2831-21</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2831-23">
   <w.rf>
    <LM>w#w-d1t2831-23</LM>
   </w.rf>
   <form>Gábinka</form>
   <lemma>Gábinka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d-m-d1e2826-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2826-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2826-x3">
  <m id="m105-d1t2833-1">
   <w.rf>
    <LM>w#w-d1t2833-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2833-2">
   <w.rf>
    <LM>w#w-d1t2833-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m105-d1t2833-3">
   <w.rf>
    <LM>w#w-d1t2833-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2833-4">
   <w.rf>
    <LM>w#w-d1t2833-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m105-d1t2833-5">
   <w.rf>
    <LM>w#w-d1t2833-5</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m105-d-id166097-punct">
   <w.rf>
    <LM>w#w-d-id166097-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2834-x2">
  <m id="m105-d1t2837-7">
   <w.rf>
    <LM>w#w-d1t2837-7</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m105-d1t2837-5">
   <w.rf>
    <LM>w#w-d1t2837-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2837-6">
   <w.rf>
    <LM>w#w-d1t2837-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2837-8">
   <w.rf>
    <LM>w#w-d1t2837-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m105-d1t2837-9">
   <w.rf>
    <LM>w#w-d1t2837-9</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m105-d1e2834-x2-366">
   <w.rf>
    <LM>w#w-d1e2834-x2-366</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-368">
  <m id="m105-d1t2843-1">
   <w.rf>
    <LM>w#w-d1t2843-1</LM>
   </w.rf>
   <form>Šila</form>
   <lemma>šít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2841-3">
   <w.rf>
    <LM>w#w-d1t2841-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2841-4">
   <w.rf>
    <LM>w#w-d1t2841-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m105-d1t2843-3">
   <w.rf>
    <LM>w#w-d1t2843-3</LM>
   </w.rf>
   <form>sukýnku</form>
   <lemma>sukýnka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m105-d1t2843-4">
   <w.rf>
    <LM>w#w-d1t2843-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m105-d1t2843-6">
   <w.rf>
    <LM>w#w-d1t2843-6</LM>
   </w.rf>
   <form>šátečkem</form>
   <lemma>šáteček</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m105-368-369">
   <w.rf>
    <LM>w#w-368-369</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-370">
  <m id="m105-d1t2845-5">
   <w.rf>
    <LM>w#w-d1t2845-5</LM>
   </w.rf>
   <form>Koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m105-d1t2845-3">
   <w.rf>
    <LM>w#w-d1t2845-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2845-4">
   <w.rf>
    <LM>w#w-d1t2845-4</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2845-1">
   <w.rf>
    <LM>w#w-d1t2845-1</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2845-2">
   <w.rf>
    <LM>w#w-d1t2845-2</LM>
   </w.rf>
   <form>blůzičku</form>
   <lemma>blůzička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m105-370-371">
   <w.rf>
    <LM>w#w-370-371</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-372">
  <m id="m105-d1t2852-8">
   <w.rf>
    <LM>w#w-d1t2852-8</LM>
   </w.rf>
   <form>Gábinka</form>
   <lemma>Gábinka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t2852-2">
   <w.rf>
    <LM>w#w-d1t2852-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2852-3">
   <w.rf>
    <LM>w#w-d1t2852-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m105-d1t2852-4">
   <w.rf>
    <LM>w#w-d1t2852-4</LM>
   </w.rf>
   <form>buchta</form>
   <lemma>buchta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d-id166840-punct">
   <w.rf>
    <LM>w#w-d-id166840-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2854-2">
   <w.rf>
    <LM>w#w-d1t2854-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m105-d1t2854-4">
   <w.rf>
    <LM>w#w-d1t2854-4</LM>
   </w.rf>
   <form>hrozný</form>
   <lemma>hrozný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m105-d1t2854-5">
   <w.rf>
    <LM>w#w-d1t2854-5</LM>
   </w.rf>
   <form>mazel</form>
   <lemma>mazel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m105-372-373">
   <w.rf>
    <LM>w#w-372-373</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-374">
  <m id="m105-d1t2856-2">
   <w.rf>
    <LM>w#w-d1t2856-2</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m105-d1t2856-3">
   <w.rf>
    <LM>w#w-d1t2856-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-d1t2856-4">
   <w.rf>
    <LM>w#w-d1t2856-4</LM>
   </w.rf>
   <form>cpala</form>
   <lemma>cpát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2858-1">
   <w.rf>
    <LM>w#w-d1t2858-1</LM>
   </w.rf>
   <form>jídlem</form>
   <lemma>jídlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m105-d-id167003-punct">
   <w.rf>
    <LM>w#w-d-id167003-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2861-1">
   <w.rf>
    <LM>w#w-d1t2861-1</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m105-d1t2861-2">
   <w.rf>
    <LM>w#w-d1t2861-2</LM>
   </w.rf>
   <form>sladkým</form>
   <lemma>sladký</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m105-374-375">
   <w.rf>
    <LM>w#w-374-375</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-376">
  <m id="m105-d1t2865-1">
   <w.rf>
    <LM>w#w-d1t2865-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2865-2">
   <w.rf>
    <LM>w#w-d1t2865-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2865-3">
   <w.rf>
    <LM>w#w-d1t2865-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2865-4">
   <w.rf>
    <LM>w#w-d1t2865-4</LM>
   </w.rf>
   <form>nevypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m105-376-393">
   <w.rf>
    <LM>w#w-376-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-399">
  <m id="m105-d1t2865-7">
   <w.rf>
    <LM>w#w-d1t2865-7</LM>
   </w.rf>
   <form>Přeci</form>
   <lemma>přeci-2_,h_^(^GC**přece-2)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2865-8">
   <w.rf>
    <LM>w#w-d1t2865-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2865-10">
   <w.rf>
    <LM>w#w-d1t2865-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2865-9">
   <w.rf>
    <LM>w#w-d1t2865-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2867-1">
   <w.rf>
    <LM>w#w-d1t2867-1</LM>
   </w.rf>
   <form>dospělá</form>
   <lemma>dospělý_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-399-400">
   <w.rf>
    <LM>w#w-399-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2834-x3">
  <m id="m105-d1t2867-6">
   <w.rf>
    <LM>w#w-d1t2867-6</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2867-7">
   <w.rf>
    <LM>w#w-d1t2867-7</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m105-d1t2867-8">
   <w.rf>
    <LM>w#w-d1t2867-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m105-d1t2867-9">
   <w.rf>
    <LM>w#w-d1t2867-9</LM>
   </w.rf>
   <form>22</form>
   <lemma>22</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m105-d1e2834-x3-419">
   <w.rf>
    <LM>w#w-d1e2834-x3-419</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-420">
  <m id="m105-d1t2869-4">
   <w.rf>
    <LM>w#w-d1t2869-4</LM>
   </w.rf>
   <form>Chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2869-5">
   <w.rf>
    <LM>w#w-d1t2869-5</LM>
   </w.rf>
   <form>vypadat</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m105-420-421">
   <w.rf>
    <LM>w#w-420-421</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-422">
  <m id="m105-d1t2869-10">
   <w.rf>
    <LM>w#w-d1t2869-10</LM>
   </w.rf>
   <form>Chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2869-11">
   <w.rf>
    <LM>w#w-d1t2869-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-d1t2869-12">
   <w.rf>
    <LM>w#w-d1t2869-12</LM>
   </w.rf>
   <form>líbit</form>
   <lemma>líbit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m105-d-m-d1e2834-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2834-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2870-x2">
  <m id="m105-d1t2873-1">
   <w.rf>
    <LM>w#w-d1t2873-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m105-d1e2870-x2-425">
   <w.rf>
    <LM>w#w-d1e2870-x2-425</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-427">
  <m id="m105-d1t2873-3">
   <w.rf>
    <LM>w#w-d1t2873-3</LM>
   </w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-d1t2873-4">
   <w.rf>
    <LM>w#w-d1t2873-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d-m-d1e2870-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2870-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2874-x2">
  <m id="m105-d1t2877-1">
   <w.rf>
    <LM>w#w-d1t2877-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d-m-d1e2874-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2874-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2880-x2">
  <m id="m105-d1t2885-1">
   <w.rf>
    <LM>w#w-d1t2885-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2885-2">
   <w.rf>
    <LM>w#w-d1t2885-2</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-d1t2885-3">
   <w.rf>
    <LM>w#w-d1t2885-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2885-4">
   <w.rf>
    <LM>w#w-d1t2885-4</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m105-d1t2885-5">
   <w.rf>
    <LM>w#w-d1t2885-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d-id167872-punct">
   <w.rf>
    <LM>w#w-d-id167872-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-449">
  <m id="m105-d1t2895-5">
   <w.rf>
    <LM>w#w-d1t2895-5</LM>
   </w.rf>
   <form>Jakoubkovi</form>
   <lemma>Jakoubek_;Y</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m105-d1t2895-2">
   <w.rf>
    <LM>w#w-d1t2895-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m105-d1t2895-3">
   <w.rf>
    <LM>w#w-d1t2895-3</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m105-449-450">
   <w.rf>
    <LM>w#w-449-450</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m105-d1t2895-7">
   <w.rf>
    <LM>w#w-d1t2895-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2895-8">
   <w.rf>
    <LM>w#w-d1t2895-8</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m105-d-id168142-punct">
   <w.rf>
    <LM>w#w-d-id168142-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2895-11">
   <w.rf>
    <LM>w#w-d1t2895-11</LM>
   </w.rf>
   <form>Martě</form>
   <lemma>Marta_;Y</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m105-d1t2895-13">
   <w.rf>
    <LM>w#w-d1t2895-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2895-14">
   <w.rf>
    <LM>w#w-d1t2895-14</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m105-449-451">
   <w.rf>
    <LM>w#w-449-451</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2895-15">
   <w.rf>
    <LM>w#w-d1t2895-15</LM>
   </w.rf>
   <form>jedenáct</form>
   <lemma>jedenáct`11</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m105-449-452">
   <w.rf>
    <LM>w#w-449-452</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-453">
  <m id="m105-d1t2899-1">
   <w.rf>
    <LM>w#w-d1t2899-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m105-d1t2899-2">
   <w.rf>
    <LM>w#w-d1t2899-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2899-3">
   <w.rf>
    <LM>w#w-d1t2899-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2899-4">
   <w.rf>
    <LM>w#w-d1t2899-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2899-5">
   <w.rf>
    <LM>w#w-d1t2899-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m105-453-454">
   <w.rf>
    <LM>w#w-453-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-455">
  <m id="m105-d1t2904-3">
   <w.rf>
    <LM>w#w-d1t2904-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m105-d1t2904-4">
   <w.rf>
    <LM>w#w-d1t2904-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2904-5">
   <w.rf>
    <LM>w#w-d1t2904-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2904-6">
   <w.rf>
    <LM>w#w-d1t2904-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2904-7">
   <w.rf>
    <LM>w#w-d1t2904-7</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m105-455-456">
   <w.rf>
    <LM>w#w-455-456</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-457">
  <m id="m105-d1t2904-9">
   <w.rf>
    <LM>w#w-d1t2904-9</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2904-10">
   <w.rf>
    <LM>w#w-d1t2904-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2904-11">
   <w.rf>
    <LM>w#w-d1t2904-11</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-457-458">
   <w.rf>
    <LM>w#w-457-458</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-459">
  <m id="m105-d1t2906-4">
   <w.rf>
    <LM>w#w-d1t2906-4</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2906-5">
   <w.rf>
    <LM>w#w-d1t2906-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2906-6">
   <w.rf>
    <LM>w#w-d1t2906-6</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m105-d1t2906-7">
   <w.rf>
    <LM>w#w-d1t2906-7</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2906-8">
   <w.rf>
    <LM>w#w-d1t2906-8</LM>
   </w.rf>
   <form>udělaný</form>
   <lemma>udělaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m105-d1t2906-10">
   <w.rf>
    <LM>w#w-d1t2906-10</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m105-459-460">
   <w.rf>
    <LM>w#w-459-460</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2890-x3">
  <m id="m105-d1t2910-7">
   <w.rf>
    <LM>w#w-d1t2910-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m105-d1t2910-8">
   <w.rf>
    <LM>w#w-d1t2910-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2910-9">
   <w.rf>
    <LM>w#w-d1t2910-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2910-10">
   <w.rf>
    <LM>w#w-d1t2910-10</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m105-d1t2910-11">
   <w.rf>
    <LM>w#w-d1t2910-11</LM>
   </w.rf>
   <form>rozbalení</form>
   <lemma>rozbalení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m105-d1t2910-12">
   <w.rf>
    <LM>w#w-d1t2910-12</LM>
   </w.rf>
   <form>dárků</form>
   <lemma>dárek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m105-d1e2890-x3-488">
   <w.rf>
    <LM>w#w-d1e2890-x3-488</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-490">
  <m id="m105-d1t2912-1">
   <w.rf>
    <LM>w#w-d1t2912-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2912-4">
   <w.rf>
    <LM>w#w-d1t2912-4</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m105-d1t2912-6">
   <w.rf>
    <LM>w#w-d1t2912-6</LM>
   </w.rf>
   <form>stromem</form>
   <lemma>strom</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m105-d1t2912-3">
   <w.rf>
    <LM>w#w-d1t2912-3</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m105-490-491">
   <w.rf>
    <LM>w#w-490-491</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-492">
  <m id="m105-d1t2914-2">
   <w.rf>
    <LM>w#w-d1t2914-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t2914-3">
   <w.rf>
    <LM>w#w-d1t2914-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2914-4">
   <w.rf>
    <LM>w#w-d1t2914-4</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m105-d1t2914-7">
   <w.rf>
    <LM>w#w-d1t2914-7</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-d1t2914-8">
   <w.rf>
    <LM>w#w-d1t2914-8</LM>
   </w.rf>
   <form>hromada</form>
   <lemma>hromada_^(písku;_také_valná_h.)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-492-493">
   <w.rf>
    <LM>w#w-492-493</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-494">
  <m id="m105-d1t2917-4">
   <w.rf>
    <LM>w#w-d1t2917-4</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2917-3">
   <w.rf>
    <LM>w#w-d1t2917-3</LM>
   </w.rf>
   <form>sedíme</form>
   <lemma>sedět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2917-8">
   <w.rf>
    <LM>w#w-d1t2917-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m105-d1t2917-9">
   <w.rf>
    <LM>w#w-d1t2917-9</LM>
   </w.rf>
   <form>gauči</form>
   <lemma>gauč</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m105-494-508">
   <w.rf>
    <LM>w#w-494-508</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-509">
  <m id="m105-d1t2921-2">
   <w.rf>
    <LM>w#w-d1t2921-2</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m105-d1t2921-3">
   <w.rf>
    <LM>w#w-d1t2921-3</LM>
   </w.rf>
   <form>četly</form>
   <lemma>číst</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m105-d1t2925-3">
   <w.rf>
    <LM>w#w-d1t2925-3</LM>
   </w.rf>
   <form>jména</form>
   <lemma>jméno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m105-509-511">
   <w.rf>
    <LM>w#w-509-511</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2925-9">
   <w.rf>
    <LM>w#w-d1t2925-9</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m105-d1t2925-10">
   <w.rf>
    <LM>w#w-d1t2925-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2925-11">
   <w.rf>
    <LM>w#w-d1t2925-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m105-d1t2925-12">
   <w.rf>
    <LM>w#w-d1t2925-12</LM>
   </w.rf>
   <form>uměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m105-509-512">
   <w.rf>
    <LM>w#w-509-512</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2927-1">
   <w.rf>
    <LM>w#w-d1t2927-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m105-d1t2927-2">
   <w.rf>
    <LM>w#w-d1t2927-2</LM>
   </w.rf>
   <form>rozdávaly</form>
   <lemma>rozdávat_^(*4at)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m105-494-506">
   <w.rf>
    <LM>w#w-494-506</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-507">
  <m id="m105-d1t2927-6">
   <w.rf>
    <LM>w#w-d1t2927-6</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2927-5">
   <w.rf>
    <LM>w#w-d1t2927-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2930-1">
   <w.rf>
    <LM>w#w-d1t2930-1</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m105-d-id169993-punct">
   <w.rf>
    <LM>w#w-d-id169993-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2930-3">
   <w.rf>
    <LM>w#w-d1t2930-3</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m105-d1t2930-4">
   <w.rf>
    <LM>w#w-d1t2930-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m105-d1t2930-5">
   <w.rf>
    <LM>w#w-d1t2930-5</LM>
   </w.rf>
   <form>rozbalí</form>
   <lemma>rozbalit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m105-507-513">
   <w.rf>
    <LM>w#w-507-513</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-514">
  <m id="m105-d1t2930-8">
   <w.rf>
    <LM>w#w-d1t2930-8</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2930-9">
   <w.rf>
    <LM>w#w-d1t2930-9</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m105-d1t2930-10">
   <w.rf>
    <LM>w#w-d1t2930-10</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m105-514-515">
   <w.rf>
    <LM>w#w-514-515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2936-x2">
  <m id="m105-d1t2941-1">
   <w.rf>
    <LM>w#w-d1t2941-1</LM>
   </w.rf>
   <form>No</form>
   <lemma>no</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2941-3">
   <w.rf>
    <LM>w#w-d1t2941-3</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d-id170263-punct">
   <w.rf>
    <LM>w#w-d-id170263-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2941-5">
   <w.rf>
    <LM>w#w-d1t2941-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2941-6">
   <w.rf>
    <LM>w#w-d1t2941-6</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m105-d1t2941-7">
   <w.rf>
    <LM>w#w-d1t2941-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m105-d1t2941-8">
   <w.rf>
    <LM>w#w-d1t2941-8</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2941-9">
   <w.rf>
    <LM>w#w-d1t2941-9</LM>
   </w.rf>
   <form>sluší</form>
   <lemma>slušet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d-m-d1e2936-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2936-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2936-x4">
  <m id="m105-d1t2965-1">
   <w.rf>
    <LM>w#w-d1t2965-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m105-d1t2965-2">
   <w.rf>
    <LM>w#w-d1t2965-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m105-d1t2965-4">
   <w.rf>
    <LM>w#w-d1t2965-4</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m105-d-id170505-punct">
   <w.rf>
    <LM>w#w-d-id170505-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e2966-x2">
  <m id="m105-d1t2973-2">
   <w.rf>
    <LM>w#w-d1t2973-2</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m105-d1t2973-4">
   <w.rf>
    <LM>w#w-d1t2973-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2973-5">
   <w.rf>
    <LM>w#w-d1t2973-5</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2973-7">
   <w.rf>
    <LM>w#w-d1t2973-7</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2973-6">
   <w.rf>
    <LM>w#w-d1t2973-6</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m105-d1e2966-x2-547">
   <w.rf>
    <LM>w#w-d1e2966-x2-547</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-548">
  <m id="m105-d1t2975-2">
   <w.rf>
    <LM>w#w-d1t2975-2</LM>
   </w.rf>
   <form>Zvlášť</form>
   <lemma>zvlášť-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2975-3">
   <w.rf>
    <LM>w#w-d1t2975-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d-id170799-punct">
   <w.rf>
    <LM>w#w-d-id170799-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2975-5">
   <w.rf>
    <LM>w#w-d1t2975-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m105-d1t2975-7">
   <w.rf>
    <LM>w#w-d1t2975-7</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2975-6">
   <w.rf>
    <LM>w#w-d1t2975-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2975-9">
   <w.rf>
    <LM>w#w-d1t2975-9</LM>
   </w.rf>
   <form>vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m105-548-549">
   <w.rf>
    <LM>w#w-548-549</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-550">
  <m id="m105-d1t2984-3">
   <w.rf>
    <LM>w#w-d1t2984-3</LM>
   </w.rf>
   <form>Peklo</form>
   <lemma>péci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m105-d1t2984-2">
   <w.rf>
    <LM>w#w-d1t2984-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-550-551">
   <w.rf>
    <LM>w#w-550-551</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-552">
  <m id="m105-d1t2984-7">
   <w.rf>
    <LM>w#w-d1t2984-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2984-8">
   <w.rf>
    <LM>w#w-d1t2984-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m105-d1t2984-9">
   <w.rf>
    <LM>w#w-d1t2984-9</LM>
   </w.rf>
   <form>cukroví</form>
   <lemma>cukroví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m105-d-id171148-punct">
   <w.rf>
    <LM>w#w-d-id171148-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2984-11">
   <w.rf>
    <LM>w#w-d1t2984-11</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m105-d1t2984-12">
   <w.rf>
    <LM>w#w-d1t2984-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-d1t2984-13">
   <w.rf>
    <LM>w#w-d1t2984-13</LM>
   </w.rf>
   <form>peklo</form>
   <lemma>péci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m105-552-553">
   <w.rf>
    <LM>w#w-552-553</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-555">
  <m id="m105-d1t2988-3">
   <w.rf>
    <LM>w#w-d1t2988-3</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2988-2">
   <w.rf>
    <LM>w#w-d1t2988-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2988-4">
   <w.rf>
    <LM>w#w-d1t2988-4</LM>
   </w.rf>
   <form>napekla</form>
   <lemma>napéci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-d1t2988-5">
   <w.rf>
    <LM>w#w-d1t2988-5</LM>
   </w.rf>
   <form>takového</form>
   <lemma>takový</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m105-d1t2988-6">
   <w.rf>
    <LM>w#w-d1t2988-6</LM>
   </w.rf>
   <form>cukroví</form>
   <lemma>cukroví</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m105-d-id171321-punct">
   <w.rf>
    <LM>w#w-d-id171321-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t2990-1">
   <w.rf>
    <LM>w#w-d1t2990-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m105-d1t2990-2">
   <w.rf>
    <LM>w#w-d1t2990-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2990-3">
   <w.rf>
    <LM>w#w-d1t2990-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m105-d1t2990-4">
   <w.rf>
    <LM>w#w-d1t2990-4</LM>
   </w.rf>
   <form>jedla</form>
   <lemma>jíst</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t2990-5">
   <w.rf>
    <LM>w#w-d1t2990-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t2990-6">
   <w.rf>
    <LM>w#w-d1t2990-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m105-d1t2990-7">
   <w.rf>
    <LM>w#w-d1t2990-7</LM>
   </w.rf>
   <form>únoru</form>
   <lemma>únor</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m105-555-556">
   <w.rf>
    <LM>w#w-555-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-558">
  <m id="m105-d1t2995-1">
   <w.rf>
    <LM>w#w-d1t2995-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1t2997-1">
   <w.rf>
    <LM>w#w-d1t2997-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m105-d1t2997-2">
   <w.rf>
    <LM>w#w-d1t2997-2</LM>
   </w.rf>
   <form>krabic</form>
   <lemma>krabice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m105-558-559">
   <w.rf>
    <LM>w#w-558-559</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-560">
  <m id="m105-d1t2997-6">
   <w.rf>
    <LM>w#w-d1t2997-6</LM>
   </w.rf>
   <form>Dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-560-713">
   <w.rf>
    <LM>w#w-560-713</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t2997-5">
   <w.rf>
    <LM>w#w-d1t2997-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m105-d1t2997-7">
   <w.rf>
    <LM>w#w-d1t2997-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m105-d1t2997-9">
   <w.rf>
    <LM>w#w-d1t2997-9</LM>
   </w.rf>
   <form>balkon</form>
   <lemma>balkon_,s_^(^DD**balkón)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m105-560-561">
   <w.rf>
    <LM>w#w-560-561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3000-x2">
  <m id="m105-d1t3003-1">
   <w.rf>
    <LM>w#w-d1t3003-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m105-d-m-d1e3000-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3000-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3008-x2">
  <m id="m105-d1t3015-4">
   <w.rf>
    <LM>w#w-d1t3015-4</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m105-d1t3015-5">
   <w.rf>
    <LM>w#w-d1t3015-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m105-d1t3015-11">
   <w.rf>
    <LM>w#w-d1t3015-11</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m105-d1t3015-12">
   <w.rf>
    <LM>w#w-d1t3015-12</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3015-8">
   <w.rf>
    <LM>w#w-d1t3015-8</LM>
   </w.rf>
   <form>Renatka</form>
   <lemma>Renatka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3015-14">
   <w.rf>
    <LM>w#w-d1t3015-14</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m105-d1t3015-15">
   <w.rf>
    <LM>w#w-d1t3015-15</LM>
   </w.rf>
   <form>promoci</form>
   <lemma>promoce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m105-d1e3008-x2-599">
   <w.rf>
    <LM>w#w-d1e3008-x2-599</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-600">
  <m id="m105-d1t3015-19">
   <w.rf>
    <LM>w#w-d1t3015-19</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t3015-18">
   <w.rf>
    <LM>w#w-d1t3015-18</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t3015-20">
   <w.rf>
    <LM>w#w-d1t3015-20</LM>
   </w.rf>
   <form>promoci</form>
   <lemma>promoce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m105-d-m-d1e3008-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3008-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3008-x3">
  <m id="m105-d1t3019-1">
   <w.rf>
    <LM>w#w-d1t3019-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m105-d1t3019-2">
   <w.rf>
    <LM>w#w-d1t3019-2</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m105-d1t3019-3">
   <w.rf>
    <LM>w#w-d1t3019-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3019-4">
   <w.rf>
    <LM>w#w-d1t3019-4</LM>
   </w.rf>
   <form>vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-d-id172308-punct">
   <w.rf>
    <LM>w#w-d-id172308-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3020-x2">
  <m id="m105-d1t3025-1">
   <w.rf>
    <LM>w#w-d1t3025-1</LM>
   </w.rf>
   <form>Inženýrka</form>
   <lemma>inženýrka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3025-2">
   <w.rf>
    <LM>w#w-d1t3025-2</LM>
   </w.rf>
   <form>ekonomie</form>
   <lemma>ekonomie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m105-d-m-d1e3020-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3020-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3026-x2">
  <m id="m105-d1t3031-2">
   <w.rf>
    <LM>w#w-d1t3031-2</LM>
   </w.rf>
   <form>Dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-d1t3031-3">
   <w.rf>
    <LM>w#w-d1t3031-3</LM>
   </w.rf>
   <form>červený</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m105-d1t3031-4">
   <w.rf>
    <LM>w#w-d1t3031-4</LM>
   </w.rf>
   <form>diplom</form>
   <lemma>diplom</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m105-d1e3026-x2-604">
   <w.rf>
    <LM>w#w-d1e3026-x2-604</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-605">
  <m id="m105-d1t3031-8">
   <w.rf>
    <LM>w#w-d1t3031-8</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t3031-7">
   <w.rf>
    <LM>w#w-d1t3031-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t3031-9">
   <w.rf>
    <LM>w#w-d1t3031-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m105-d1t3031-10">
   <w.rf>
    <LM>w#w-d1t3031-10</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m105-d1t3031-11">
   <w.rf>
    <LM>w#w-d1t3031-11</LM>
   </w.rf>
   <form>hrdá</form>
   <lemma>hrdý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-d-m-d1e3026-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3026-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3026-x4">
  <m id="m105-d1t3046-1">
   <w.rf>
    <LM>w#w-d1t3046-1</LM>
   </w.rf>
   <form>Studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t3046-2">
   <w.rf>
    <LM>w#w-d1t3046-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m105-d1t3046-3">
   <w.rf>
    <LM>w#w-d1t3046-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d-id172783-punct">
   <w.rf>
    <LM>w#w-d-id172783-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-d1e3047-x2">
  <m id="m105-d1t3052-3">
   <w.rf>
    <LM>w#w-d1t3052-3</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m105-d1e3047-x2-619">
   <w.rf>
    <LM>w#w-d1e3047-x2-619</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-620">
  <m id="m105-d1t3052-5">
   <w.rf>
    <LM>w#w-d1t3052-5</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m105-d1t3052-6">
   <w.rf>
    <LM>w#w-d1t3052-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t3052-8">
   <w.rf>
    <LM>w#w-d1t3052-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-d1t3052-9">
   <w.rf>
    <LM>w#w-d1t3052-9</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-d1t3052-10">
   <w.rf>
    <LM>w#w-d1t3052-10</LM>
   </w.rf>
   <form>vyučila</form>
   <lemma>vyučit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-620-621">
   <w.rf>
    <LM>w#w-620-621</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-622">
  <m id="m105-d1t3054-20">
   <w.rf>
    <LM>w#w-d1t3054-20</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m105-d1t3054-21">
   <w.rf>
    <LM>w#w-d1t3054-21</LM>
   </w.rf>
   <form>mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m105-d1t3056-1">
   <w.rf>
    <LM>w#w-d1t3056-1</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3054-3">
   <w.rf>
    <LM>w#w-d1t3054-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t3054-4">
   <w.rf>
    <LM>w#w-d1t3054-4</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d-id173080-punct">
   <w.rf>
    <LM>w#w-d-id173080-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t3054-6">
   <w.rf>
    <LM>w#w-d1t3054-6</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m105-d1t3054-7">
   <w.rf>
    <LM>w#w-d1t3054-7</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m105-d1t3054-8">
   <w.rf>
    <LM>w#w-d1t3054-8</LM>
   </w.rf>
   <form>vydělávat</form>
   <lemma>vydělávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m105-d1t3054-9">
   <w.rf>
    <LM>w#w-d1t3054-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m105-d1t3054-10">
   <w.rf>
    <LM>w#w-d1t3054-10</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m105-d1t3054-11">
   <w.rf>
    <LM>w#w-d1t3054-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m105-d1t3054-12">
   <w.rf>
    <LM>w#w-d1t3054-12</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m105-d1t3054-13">
   <w.rf>
    <LM>w#w-d1t3054-13</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m105-d1t3054-18">
   <w.rf>
    <LM>w#w-d1t3054-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m105-d1t3054-19">
   <w.rf>
    <LM>w#w-d1t3054-19</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--4----------</tag>
  </m>
  <m id="m105-622-624">
   <w.rf>
    <LM>w#w-622-624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m105-625">
  <m id="m105-d1t3058-4">
   <w.rf>
    <LM>w#w-d1t3058-4</LM>
   </w.rf>
   <form>Maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m105-d1t3061-2">
   <w.rf>
    <LM>w#w-d1t3061-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m105-d1t3061-3">
   <w.rf>
    <LM>w#w-d1t3061-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m105-d1t3061-4">
   <w.rf>
    <LM>w#w-d1t3061-4</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m105-d-id173471-punct">
   <w.rf>
    <LM>w#w-d-id173471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-d1t3063-1">
   <w.rf>
    <LM>w#w-d1t3063-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m105-d1t3063-2">
   <w.rf>
    <LM>w#w-d1t3063-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-d1t3063-3">
   <w.rf>
    <LM>w#w-d1t3063-3</LM>
   </w.rf>
   <form>nestudovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m105-625-766">
   <w.rf>
    <LM>w#w-625-766</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m105-625-767">
   <w.rf>
    <LM>w#w-625-767</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m105-625-768">
   <w.rf>
    <LM>w#w-625-768</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m105-625-769">
   <w.rf>
    <LM>w#w-625-769</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m105-625-770">
   <w.rf>
    <LM>w#w-625-770</LM>
   </w.rf>
   <form>vyučila</form>
   <lemma>vyučit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m105-625-626">
   <w.rf>
    <LM>w#w-625-626</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
