<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_773.02.w.gz" />
  </references>
 </head>
 <s id="m773-26127_03-d1e492-x4">
  <m id="m773-d1t525-2">
   <w.rf>
    <LM>w#w-d1t525-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t525-3">
   <w.rf>
    <LM>w#w-d1t525-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d1t525-4">
   <w.rf>
    <LM>w#w-d1t525-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t525-5">
   <w.rf>
    <LM>w#w-d1t525-5</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m773-d1t525-6">
   <w.rf>
    <LM>w#w-d1t525-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m773-d-id73769">
   <w.rf>
    <LM>w#w-d-id73769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t525-8">
   <w.rf>
    <LM>w#w-d1t525-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t525-9">
   <w.rf>
    <LM>w#w-d1t525-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t525-10">
   <w.rf>
    <LM>w#w-d1t525-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t525-13">
   <w.rf>
    <LM>w#w-d1t525-13</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t525-11">
   <w.rf>
    <LM>w#w-d1t525-11</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t525-12">
   <w.rf>
    <LM>w#w-d1t525-12</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m773-d1t525-14">
   <w.rf>
    <LM>w#w-d1t525-14</LM>
   </w.rf>
   <form>nevybaví</form>
   <lemma>vybavit</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m773-d-id73902">
   <w.rf>
    <LM>w#w-d-id73902</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e526-x2">
  <m id="m773-d1t531-1">
   <w.rf>
    <LM>w#w-d1t531-1</LM>
   </w.rf>
   <form>Doteď</form>
   <lemma>doteď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t531-3">
   <w.rf>
    <LM>w#w-d1t531-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t531-4">
   <w.rf>
    <LM>w#w-d1t531-4</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m773-d1t531-6">
   <w.rf>
    <LM>w#w-d1t531-6</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t531-7">
   <w.rf>
    <LM>w#w-d1t531-7</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t531-8">
   <w.rf>
    <LM>w#w-d1t531-8</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m773-d1e526-x2-768">
   <w.rf>
    <LM>w#w-d1e526-x2-768</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t531-9">
   <w.rf>
    <LM>w#w-d1t531-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t531-10">
   <w.rf>
    <LM>w#w-d1t531-10</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t531-11">
   <w.rf>
    <LM>w#w-d1t531-11</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t531-13">
   <w.rf>
    <LM>w#w-d1t531-13</LM>
   </w.rf>
   <form>světlejší</form>
   <lemma>světlý</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m773-d1t531-14">
   <w.rf>
    <LM>w#w-d1t531-14</LM>
   </w.rf>
   <form>stránky</form>
   <lemma>stránka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1e526-x2-2049">
   <w.rf>
    <LM>w#w-d1e526-x2-2049</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2050">
  <m id="m773-d1t533-1">
   <w.rf>
    <LM>w#w-d1t533-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t533-2">
   <w.rf>
    <LM>w#w-d1t533-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t533-3">
   <w.rf>
    <LM>w#w-d1t533-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t533-4">
   <w.rf>
    <LM>w#w-d1t533-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m773-d1e526-x2-769">
   <w.rf>
    <LM>w#w-d1e526-x2-769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t533-5">
   <w.rf>
    <LM>w#w-d1t533-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t533-6">
   <w.rf>
    <LM>w#w-d1t533-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m773-d1t533-7">
   <w.rf>
    <LM>w#w-d1t533-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t533-8">
   <w.rf>
    <LM>w#w-d1t533-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t533-9">
   <w.rf>
    <LM>w#w-d1t533-9</LM>
   </w.rf>
   <form>snažila</form>
   <lemma>snažit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t533-10">
   <w.rf>
    <LM>w#w-d1t533-10</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m773-d1t533-11">
   <w.rf>
    <LM>w#w-d1t533-11</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1t533-12">
   <w.rf>
    <LM>w#w-d1t533-12</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1e526-x2-772">
   <w.rf>
    <LM>w#w-d1e526-x2-772</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t533-13">
   <w.rf>
    <LM>w#w-d1t533-13</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t533-14">
   <w.rf>
    <LM>w#w-d1t533-14</LM>
   </w.rf>
   <form>čem</form>
   <lemma>co-1</lemma>
   <tag>PQ--6----------</tag>
  </m>
  <m id="m773-d1t533-15">
   <w.rf>
    <LM>w#w-d1t533-15</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t533-16">
   <w.rf>
    <LM>w#w-d1t533-16</LM>
   </w.rf>
   <form>nevyprávěla</form>
   <lemma>vyprávět</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m773-d1e526-x2-773">
   <w.rf>
    <LM>w#w-d1e526-x2-773</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t533-17">
   <w.rf>
    <LM>w#w-d1t533-17</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m773-d1t533-18">
   <w.rf>
    <LM>w#w-d1t533-18</LM>
   </w.rf>
   <form>ošklivého</form>
   <lemma>ošklivý</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m773-d-id74290">
   <w.rf>
    <LM>w#w-d-id74290</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e534-x2">
  <m id="m773-d1t541-3">
   <w.rf>
    <LM>w#w-d1t541-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t541-4">
   <w.rf>
    <LM>w#w-d1t541-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t541-5">
   <w.rf>
    <LM>w#w-d1t541-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t541-6">
   <w.rf>
    <LM>w#w-d1t541-6</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d-id74458">
   <w.rf>
    <LM>w#w-d-id74458</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t541-8">
   <w.rf>
    <LM>w#w-d1t541-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t541-9">
   <w.rf>
    <LM>w#w-d1t541-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t541-10">
   <w.rf>
    <LM>w#w-d1t541-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t541-12">
   <w.rf>
    <LM>w#w-d1t541-12</LM>
   </w.rf>
   <form>listopadu</form>
   <lemma>listopad</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1e534-x2-836">
   <w.rf>
    <LM>w#w-d1e534-x2-836</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-827">
  <m id="m773-d1t541-14">
   <w.rf>
    <LM>w#w-d1t541-14</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t541-15">
   <w.rf>
    <LM>w#w-d1t541-15</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t541-21">
   <w.rf>
    <LM>w#w-d1t541-21</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t541-22">
   <w.rf>
    <LM>w#w-d1t541-22</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m773-d1t541-17">
   <w.rf>
    <LM>w#w-d1t541-17</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m773-d1t541-18">
   <w.rf>
    <LM>w#w-d1t541-18</LM>
   </w.rf>
   <form>nejhlubší</form>
   <lemma>hluboký</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m773-827-840">
   <w.rf>
    <LM>w#w-827-840</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t541-23">
   <w.rf>
    <LM>w#w-d1t541-23</LM>
   </w.rf>
   <form>nejhroznější</form>
   <lemma>hrozný</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m773-d1t541-19">
   <w.rf>
    <LM>w#w-d1t541-19</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d-id74701">
   <w.rf>
    <LM>w#w-d-id74701</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e534-x3">
  <m id="m773-d1t550-1">
   <w.rf>
    <LM>w#w-d1t550-1</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t550-2">
   <w.rf>
    <LM>w#w-d1t550-2</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t550-3">
   <w.rf>
    <LM>w#w-d1t550-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t550-4">
   <w.rf>
    <LM>w#w-d1t550-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t554-1">
   <w.rf>
    <LM>w#w-d1t554-1</LM>
   </w.rf>
   <form>utekli</form>
   <lemma>utéci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1t554-2">
   <w.rf>
    <LM>w#w-d1t554-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t554-4">
   <w.rf>
    <LM>w#w-d1t554-4</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d1t554-5">
   <w.rf>
    <LM>w#w-d1t554-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t554-6">
   <w.rf>
    <LM>w#w-d1t554-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t554-7">
   <w.rf>
    <LM>w#w-d1t554-7</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m773-d1t554-8">
   <w.rf>
    <LM>w#w-d1t554-8</LM>
   </w.rf>
   <form>karantény</form>
   <lemma>karanténa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d1e534-x3-894">
   <w.rf>
    <LM>w#w-d1e534-x3-894</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t554-11">
   <w.rf>
    <LM>w#w-d1t554-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t554-12">
   <w.rf>
    <LM>w#w-d1t554-12</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t554-13">
   <w.rf>
    <LM>w#w-d1t554-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t554-16">
   <w.rf>
    <LM>w#w-d1t554-16</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t554-15">
   <w.rf>
    <LM>w#w-d1t554-15</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m773-d-id75108">
   <w.rf>
    <LM>w#w-d-id75108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e555-x2">
  <m id="m773-d1t560-1">
   <w.rf>
    <LM>w#w-d1t560-1</LM>
   </w.rf>
   <form>Jasně</form>
   <lemma>jasně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e555-x2-944">
   <w.rf>
    <LM>w#w-d1e555-x2-944</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t560-2">
   <w.rf>
    <LM>w#w-d1t560-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t560-9">
   <w.rf>
    <LM>w#w-d1t560-9</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t560-10">
   <w.rf>
    <LM>w#w-d1t560-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t560-3">
   <w.rf>
    <LM>w#w-d1t560-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t560-4">
   <w.rf>
    <LM>w#w-d1t560-4</LM>
   </w.rf>
   <form>průběhu</form>
   <lemma>průběh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d1t560-5">
   <w.rf>
    <LM>w#w-d1t560-5</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m773-d1t560-6">
   <w.rf>
    <LM>w#w-d1t560-6</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP2----------</tag>
  </m>
  <m id="m773-d1t560-7">
   <w.rf>
    <LM>w#w-d1t560-7</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m773-d1t560-11">
   <w.rf>
    <LM>w#w-d1t560-11</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m773-d1t560-12">
   <w.rf>
    <LM>w#w-d1t560-12</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m773-d-id75288">
   <w.rf>
    <LM>w#w-d-id75288</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t562-1">
   <w.rf>
    <LM>w#w-d1t562-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t562-2">
   <w.rf>
    <LM>w#w-d1t562-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m773-d1t562-3">
   <w.rf>
    <LM>w#w-d1t562-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t562-4">
   <w.rf>
    <LM>w#w-d1t562-4</LM>
   </w.rf>
   <form>snažíte</form>
   <lemma>snažit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t562-5">
   <w.rf>
    <LM>w#w-d1t562-5</LM>
   </w.rf>
   <form>zapomenout</form>
   <lemma>zapomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1e555-x2-931">
   <w.rf>
    <LM>w#w-d1e555-x2-931</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t562-6">
   <w.rf>
    <LM>w#w-d1t562-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m773-d1t562-7">
   <w.rf>
    <LM>w#w-d1t562-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t562-8">
   <w.rf>
    <LM>w#w-d1t562-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t564-1">
   <w.rf>
    <LM>w#w-d1t564-1</LM>
   </w.rf>
   <form>zakázala</form>
   <lemma>zakázat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d1t564-2">
   <w.rf>
    <LM>w#w-d1t564-2</LM>
   </w.rf>
   <form>povídat</form>
   <lemma>povídat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1e555-x2-940">
   <w.rf>
    <LM>w#w-d1e555-x2-940</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-933">
  <m id="m773-d1t564-3">
   <w.rf>
    <LM>w#w-d1t564-3</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t564-4">
   <w.rf>
    <LM>w#w-d1t564-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t564-5">
   <w.rf>
    <LM>w#w-d1t564-5</LM>
   </w.rf>
   <form>můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t564-6">
   <w.rf>
    <LM>w#w-d1t564-6</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m773-d-id75451">
   <w.rf>
    <LM>w#w-d-id75451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e565-x2">
  <m id="m773-d1t568-3">
   <w.rf>
    <LM>w#w-d1t568-3</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t568-2">
   <w.rf>
    <LM>w#w-d1t568-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id75562">
   <w.rf>
    <LM>w#w-d-id75562</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e565-x3">
  <m id="m773-d1t570-1">
   <w.rf>
    <LM>w#w-d1t570-1</LM>
   </w.rf>
   <form>Opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t570-2">
   <w.rf>
    <LM>w#w-d1t570-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-d-id75618">
   <w.rf>
    <LM>w#w-d-id75618</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e571-x2">
  <m id="m773-d1t574-1">
   <w.rf>
    <LM>w#w-d1t574-1</LM>
   </w.rf>
   <form>Nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m773-d1t574-2">
   <w.rf>
    <LM>w#w-d1t574-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m773-d1t574-4">
   <w.rf>
    <LM>w#w-d1t574-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t574-3">
   <w.rf>
    <LM>w#w-d1t574-3</LM>
   </w.rf>
   <form>neublížil</form>
   <lemma>ublížit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m773-d-id75731">
   <w.rf>
    <LM>w#w-d-id75731</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e575-x2">
  <m id="m773-d1t582-2">
   <w.rf>
    <LM>w#w-d1t582-2</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t582-3">
   <w.rf>
    <LM>w#w-d1t582-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t582-4">
   <w.rf>
    <LM>w#w-d1t582-4</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m773-d1t582-5">
   <w.rf>
    <LM>w#w-d1t582-5</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t582-7">
   <w.rf>
    <LM>w#w-d1t582-7</LM>
   </w.rf>
   <form>druhým</form>
   <lemma>druhý`2</lemma>
   <tag>CrMP3----------</tag>
  </m>
  <m id="m773-d-id75922">
   <w.rf>
    <LM>w#w-d-id75922</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e575-x3">
  <m id="m773-d1t586-1">
   <w.rf>
    <LM>w#w-d1t586-1</LM>
   </w.rf>
   <form>Nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m773-d1t586-3">
   <w.rf>
    <LM>w#w-d1t586-3</LM>
   </w.rf>
   <form>zařvání</form>
   <lemma>zařvání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m773-d1t586-4">
   <w.rf>
    <LM>w#w-d1t586-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t586-6">
   <w.rf>
    <LM>w#w-d1t586-6</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1t586-7">
   <w.rf>
    <LM>w#w-d1t586-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t586-8">
   <w.rf>
    <LM>w#w-d1t586-8</LM>
   </w.rf>
   <form>zažily</form>
   <lemma>zažít</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m773-d-id76079">
   <w.rf>
    <LM>w#w-d-id76079</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t586-10">
   <w.rf>
    <LM>w#w-d1t586-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t586-11">
   <w.rf>
    <LM>w#w-d1t586-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t586-12">
   <w.rf>
    <LM>w#w-d1t586-12</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t586-13">
   <w.rf>
    <LM>w#w-d1t586-13</LM>
   </w.rf>
   <form>šly</form>
   <lemma>jít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t593-1">
   <w.rf>
    <LM>w#w-d1t593-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t593-3">
   <w.rf>
    <LM>w#w-d1t593-3</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d1t593-5">
   <w.rf>
    <LM>w#w-d1t593-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t593-7">
   <w.rf>
    <LM>w#w-d1t593-7</LM>
   </w.rf>
   <form>pole</form>
   <lemma>pole</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m773-d1t593-8">
   <w.rf>
    <LM>w#w-d1t593-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t593-11">
   <w.rf>
    <LM>w#w-d1t593-11</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t593-10">
   <w.rf>
    <LM>w#w-d1t593-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t593-12">
   <w.rf>
    <LM>w#w-d1t593-12</LM>
   </w.rf>
   <form>okurky</form>
   <lemma>okurka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1t593-13">
   <w.rf>
    <LM>w#w-d1t593-13</LM>
   </w.rf>
   <form>zastrčené</form>
   <lemma>zastrčený_^(*3it)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m773-d1t593-14">
   <w.rf>
    <LM>w#w-d1t593-14</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t597-1">
   <w.rf>
    <LM>w#w-d1t597-1</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>výstřihem</form>
   <lemma>výstřih</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m773-d1e575-x3-2079">
   <w.rf>
    <LM>w#w-d1e575-x3-2079</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2080">
  <m id="m773-d1t597-7">
   <w.rf>
    <LM>w#w-d1t597-7</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t597-8">
   <w.rf>
    <LM>w#w-d1t597-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t599-1">
   <w.rf>
    <LM>w#w-d1t599-1</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1t599-2">
   <w.rf>
    <LM>w#w-d1t599-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t599-3">
   <w.rf>
    <LM>w#w-d1t599-3</LM>
   </w.rf>
   <form>motorce</form>
   <lemma>motorka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m773-d1t599-4">
   <w.rf>
    <LM>w#w-d1t599-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t599-7">
   <w.rf>
    <LM>w#w-d1t599-7</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m773-d1t599-6">
   <w.rf>
    <LM>w#w-d1t599-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t599-8">
   <w.rf>
    <LM>w#w-d1t599-8</LM>
   </w.rf>
   <form>mluvit</form>
   <lemma>mluvit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1t599-9">
   <w.rf>
    <LM>w#w-d1t599-9</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t599-10">
   <w.rf>
    <LM>w#w-d1t599-10</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m773-d-id76675">
   <w.rf>
    <LM>w#w-d-id76675</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t599-12">
   <w.rf>
    <LM>w#w-d1t599-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t599-13">
   <w.rf>
    <LM>w#w-d1t599-13</LM>
   </w.rf>
   <form>udělají</form>
   <lemma>udělat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m773-d1t599-14">
   <w.rf>
    <LM>w#w-d1t599-14</LM>
   </w.rf>
   <form>prohlídku</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-2080-2081">
   <w.rf>
    <LM>w#w-2080-2081</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2082">
  <m id="m773-d1t602-3">
   <w.rf>
    <LM>w#w-d1t602-3</LM>
   </w.rf>
   <form>Pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t602-5">
   <w.rf>
    <LM>w#w-d1t602-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t602-6">
   <w.rf>
    <LM>w#w-d1t602-6</LM>
   </w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m773-d1t602-7">
   <w.rf>
    <LM>w#w-d1t602-7</LM>
   </w.rf>
   <form>hrozný</form>
   <lemma>hrozný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m773-d1t602-8">
   <w.rf>
    <LM>w#w-d1t602-8</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d1e575-x3-973">
   <w.rf>
    <LM>w#w-d1e575-x3-973</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1144">
  <m id="m773-d1t604-4">
   <w.rf>
    <LM>w#w-d1t604-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m773-d1t604-6">
   <w.rf>
    <LM>w#w-d1t604-6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m773-d1t606-2">
   <w.rf>
    <LM>w#w-d1t606-2</LM>
   </w.rf>
   <form>okurky</form>
   <lemma>okurka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1t608-1">
   <w.rf>
    <LM>w#w-d1t608-1</LM>
   </w.rf>
   <form>odhazuje</form>
   <lemma>odhazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d-id77038">
   <w.rf>
    <LM>w#w-d-id77038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t608-3">
   <w.rf>
    <LM>w#w-d1t608-3</LM>
   </w.rf>
   <form>vyhazuje</form>
   <lemma>vyhazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-1144-2087">
   <w.rf>
    <LM>w#w-1144-2087</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2088">
  <m id="m773-d1t610-2">
   <w.rf>
    <LM>w#w-d1t610-2</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m773-d1t610-3">
   <w.rf>
    <LM>w#w-d1t610-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>přistižen</form>
   <lemma>přistihnout</lemma>
   <tag>VsYS----X-APP-1</tag>
  </m>
  <m id="m773-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t615-3">
   <w.rf>
    <LM>w#w-d1t615-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m773-d-id77197">
   <w.rf>
    <LM>w#w-d-id77197</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t615-5">
   <w.rf>
    <LM>w#w-d1t615-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t615-6">
   <w.rf>
    <LM>w#w-d1t615-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t615-7">
   <w.rf>
    <LM>w#w-d1t615-7</LM>
   </w.rf>
   <form>odhazuje</form>
   <lemma>odhazovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d-id77246">
   <w.rf>
    <LM>w#w-d-id77246</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t617-1">
   <w.rf>
    <LM>w#w-d1t617-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>vystoupit</form>
   <lemma>vystoupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1t617-4">
   <w.rf>
    <LM>w#w-d1t617-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t617-5">
   <w.rf>
    <LM>w#w-d1t617-5</LM>
   </w.rf>
   <form>řady</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d1t617-6">
   <w.rf>
    <LM>w#w-d1t617-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t619-1">
   <w.rf>
    <LM>w#w-d1t619-1</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m773-d1t619-2">
   <w.rf>
    <LM>w#w-d1t619-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t619-3">
   <w.rf>
    <LM>w#w-d1t619-3</LM>
   </w.rf>
   <form>pochodovaly</form>
   <lemma>pochodovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t619-4">
   <w.rf>
    <LM>w#w-d1t619-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-1257-1393">
   <w.rf>
    <LM>w#w-1257-1393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1394">
  <m id="m773-d1t619-6">
   <w.rf>
    <LM>w#w-d1t619-6</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t619-7">
   <w.rf>
    <LM>w#w-d1t619-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t619-8">
   <w.rf>
    <LM>w#w-d1t619-8</LM>
   </w.rf>
   <form>slyšet</form>
   <lemma>slyšet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1t619-9">
   <w.rf>
    <LM>w#w-d1t619-9</LM>
   </w.rf>
   <form>střelba</form>
   <lemma>střelba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-1257-1283">
   <w.rf>
    <LM>w#w-1257-1283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1272">
  <m id="m773-d1t621-1">
   <w.rf>
    <LM>w#w-d1t621-1</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t621-2">
   <w.rf>
    <LM>w#w-d1t621-2</LM>
   </w.rf>
   <form>stříleli</form>
   <lemma>střílet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m773-d1t621-3">
   <w.rf>
    <LM>w#w-d1t621-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t621-4">
   <w.rf>
    <LM>w#w-d1t621-4</LM>
   </w.rf>
   <form>vzduchu</form>
   <lemma>vzduch</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d1t621-5">
   <w.rf>
    <LM>w#w-d1t621-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t621-6">
   <w.rf>
    <LM>w#w-d1t621-6</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t621-7">
   <w.rf>
    <LM>w#w-d1t621-7</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t621-8">
   <w.rf>
    <LM>w#w-d1t621-8</LM>
   </w.rf>
   <form>zastřelili</form>
   <lemma>zastřelit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1t621-9">
   <w.rf>
    <LM>w#w-d1t621-9</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m773-d1t621-10">
   <w.rf>
    <LM>w#w-d1t621-10</LM>
   </w.rf>
   <form>člověka</form>
   <lemma>člověk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m773-d1t621-11">
   <w.rf>
    <LM>w#w-d1t621-11</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t621-12">
   <w.rf>
    <LM>w#w-d1t621-12</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d-id77702">
   <w.rf>
    <LM>w#w-d-id77702</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t623-1">
   <w.rf>
    <LM>w#w-d1t623-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t623-5">
   <w.rf>
    <LM>w#w-d1t623-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t623-2">
   <w.rf>
    <LM>w#w-d1t623-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t623-3">
   <w.rf>
    <LM>w#w-d1t623-3</LM>
   </w.rf>
   <form>hladu</form>
   <lemma>hlad</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d1t623-6">
   <w.rf>
    <LM>w#w-d1t623-6</LM>
   </w.rf>
   <form>vzal</form>
   <lemma>vzít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m773-d1t623-4">
   <w.rf>
    <LM>w#w-d1t623-4</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t623-8">
   <w.rf>
    <LM>w#w-d1t623-8</LM>
   </w.rf>
   <form>okurku</form>
   <lemma>okurka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id77837">
   <w.rf>
    <LM>w#w-d-id77837</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e625-x2">
  <m id="m773-d1t628-1">
   <w.rf>
    <LM>w#w-d1t628-1</LM>
   </w.rf>
   <form>Vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m773-d1t630-1">
   <w.rf>
    <LM>w#w-d1t630-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1e625-x2-1494">
   <w.rf>
    <LM>w#w-d1e625-x2-1494</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t630-2">
   <w.rf>
    <LM>w#w-d1t630-2</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m773-d1e625-x2-1495">
   <w.rf>
    <LM>w#w-d1e625-x2-1495</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t632-1">
   <w.rf>
    <LM>w#w-d1t632-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t632-2">
   <w.rf>
    <LM>w#w-d1t632-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m773-d1t632-3">
   <w.rf>
    <LM>w#w-d1t632-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m773-d1t632-4">
   <w.rf>
    <LM>w#w-d1t632-4</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m773-d1t632-5">
   <w.rf>
    <LM>w#w-d1t632-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t632-6">
   <w.rf>
    <LM>w#w-d1t632-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d-id78023">
   <w.rf>
    <LM>w#w-d-id78023</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t632-8">
   <w.rf>
    <LM>w#w-d1t632-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t632-9">
   <w.rf>
    <LM>w#w-d1t632-9</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t632-10">
   <w.rf>
    <LM>w#w-d1t632-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t632-11">
   <w.rf>
    <LM>w#w-d1t632-11</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m773-d1t632-12">
   <w.rf>
    <LM>w#w-d1t632-12</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d-id77887">
   <w.rf>
    <LM>w#w-d-id77887</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e633-x2">
  <m id="m773-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e633-x2-1526">
   <w.rf>
    <LM>w#w-d1e633-x2-1526</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t636-2">
   <w.rf>
    <LM>w#w-d1t636-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m773-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t636-5">
   <w.rf>
    <LM>w#w-d1t636-5</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1e633-x2-1527">
   <w.rf>
    <LM>w#w-d1e633-x2-1527</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1528">
  <m id="m773-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>Přiznám</form>
   <lemma>přiznat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m773-d1t636-7">
   <w.rf>
    <LM>w#w-d1t636-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d-id78256">
   <w.rf>
    <LM>w#w-d-id78256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t636-10">
   <w.rf>
    <LM>w#w-d1t636-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t636-12">
   <w.rf>
    <LM>w#w-d1t636-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t636-13">
   <w.rf>
    <LM>w#w-d1t636-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t636-14">
   <w.rf>
    <LM>w#w-d1t636-14</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-1528-1594">
   <w.rf>
    <LM>w#w-1528-1594</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1587">
  <m id="m773-d1t640-2">
   <w.rf>
    <LM>w#w-d1t640-2</LM>
   </w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m773-d1t640-1">
   <w.rf>
    <LM>w#w-d1t640-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t640-3">
   <w.rf>
    <LM>w#w-d1t640-3</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d-id78377">
   <w.rf>
    <LM>w#w-d-id78377</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-48"></s>
 <s id="m773-26127_03-d1e647-x2">
  <m id="m773-d1t650-3">
   <w.rf>
    <LM>w#w-d1t650-3</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t650-4">
   <w.rf>
    <LM>w#w-d1t650-4</LM>
   </w.rf>
   <form>poli</form>
   <lemma>pole</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m773-d1t650-6">
   <w.rf>
    <LM>w#w-d1t650-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t650-7">
   <w.rf>
    <LM>w#w-d1t650-7</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t650-5">
   <w.rf>
    <LM>w#w-d1t650-5</LM>
   </w.rf>
   <form>sníst</form>
   <lemma>sníst</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1e647-x2-1191">
   <w.rf>
    <LM>w#w-d1e647-x2-1191</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e651-x2">
  <m id="m773-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e651-x2-110">
   <w.rf>
    <LM>w#w-d1e651-x2-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-103">
  <m id="m773-d1t656-1">
   <w.rf>
    <LM>w#w-d1t656-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t656-2">
   <w.rf>
    <LM>w#w-d1t656-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d-id78823">
   <w.rf>
    <LM>w#w-d-id78823</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t656-6">
   <w.rf>
    <LM>w#w-d1t656-6</LM>
   </w.rf>
   <form>pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t656-7">
   <w.rf>
    <LM>w#w-d1t656-7</LM>
   </w.rf>
   <form>Kuřavý</form>
   <lemma>Kuřavý_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t658-3">
   <w.rf>
    <LM>w#w-d1t658-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t658-4">
   <w.rf>
    <LM>w#w-d1t658-4</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t658-5">
   <w.rf>
    <LM>w#w-d1t658-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t658-6">
   <w.rf>
    <LM>w#w-d1t658-6</LM>
   </w.rf>
   <form>Němec</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d-id78975">
   <w.rf>
    <LM>w#w-d-id78975</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t658-8">
   <w.rf>
    <LM>w#w-d1t658-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t658-11">
   <w.rf>
    <LM>w#w-d1t658-11</LM>
   </w.rf>
   <form>lidovější</form>
   <lemma>lidový</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m773-103-2111">
   <w.rf>
    <LM>w#w-103-2111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2112">
  <m id="m773-d1t667-7">
   <w.rf>
    <LM>w#w-d1t667-7</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t667-4">
   <w.rf>
    <LM>w#w-d1t667-4</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t667-8">
   <w.rf>
    <LM>w#w-d1t667-8</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-221-240">
   <w.rf>
    <LM>w#w-221-240</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-221-241">
   <w.rf>
    <LM>w#w-221-241</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t667-10">
   <w.rf>
    <LM>w#w-d1t667-10</LM>
   </w.rf>
   <form>Vezměte</form>
   <lemma>vzít</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m773-d1t667-11">
   <w.rf>
    <LM>w#w-d1t667-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-221-243">
   <w.rf>
    <LM>w#w-221-243</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t667-12">
   <w.rf>
    <LM>w#w-d1t667-12</LM>
   </w.rf>
   <form>najezte</form>
   <lemma>najíst</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m773-d1t667-13">
   <w.rf>
    <LM>w#w-d1t667-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t667-14">
   <w.rf>
    <LM>w#w-d1t667-14</LM>
   </w.rf>
   <form>trochu</form>
   <lemma>trochu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-221-244">
   <w.rf>
    <LM>w#w-221-244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-221-245">
   <w.rf>
    <LM>w#w-221-245</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-246">
  <m id="m773-d1t667-16">
   <w.rf>
    <LM>w#w-d1t667-16</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t671-1">
   <w.rf>
    <LM>w#w-d1t671-1</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t671-2">
   <w.rf>
    <LM>w#w-d1t671-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t671-3">
   <w.rf>
    <LM>w#w-d1t671-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m773-d1t671-5">
   <w.rf>
    <LM>w#w-d1t671-5</LM>
   </w.rf>
   <form>nesnědly</form>
   <lemma>sníst</lemma>
   <tag>VpTP----R-NAP--</tag>
  </m>
  <m id="m773-d-id79442">
   <w.rf>
    <LM>w#w-d-id79442</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t671-7">
   <w.rf>
    <LM>w#w-d1t671-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t671-9">
   <w.rf>
    <LM>w#w-d1t671-9</LM>
   </w.rf>
   <form>žaludek</form>
   <lemma>žaludek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t671-10">
   <w.rf>
    <LM>w#w-d1t671-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t671-11">
   <w.rf>
    <LM>w#w-d1t671-11</LM>
   </w.rf>
   <form>nepobral</form>
   <lemma>pobrat</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m773-d-id79528">
   <w.rf>
    <LM>w#w-d-id79528</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t671-13">
   <w.rf>
    <LM>w#w-d1t671-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t671-14">
   <w.rf>
    <LM>w#w-d1t671-14</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d-id79568">
   <w.rf>
    <LM>w#w-d-id79568</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-685">
  <m id="m773-d1t683-1">
   <w.rf>
    <LM>w#w-d1t683-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-685-693">
   <w.rf>
    <LM>w#w-685-693</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e672-x2">
  <m id="m773-d1t683-3">
   <w.rf>
    <LM>w#w-d1t683-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t683-4">
   <w.rf>
    <LM>w#w-d1t683-4</LM>
   </w.rf>
   <form>ubíhala</form>
   <lemma>ubíhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t683-5">
   <w.rf>
    <LM>w#w-d1t683-5</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1e672-x2-697">
   <w.rf>
    <LM>w#w-d1e672-x2-697</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t683-6">
   <w.rf>
    <LM>w#w-d1t683-6</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m773-d1t683-7">
   <w.rf>
    <LM>w#w-d1t683-7</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m773-d1t683-8">
   <w.rf>
    <LM>w#w-d1t683-8</LM>
   </w.rf>
   <form>1944</form>
   <lemma>1944</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m773-d-id79761">
   <w.rf>
    <LM>w#w-d-id79761</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t686-1">
   <w.rf>
    <LM>w#w-d1t686-1</LM>
   </w.rf>
   <form>neztrácely</form>
   <lemma>ztrácet</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m773-d1t686-2">
   <w.rf>
    <LM>w#w-d1t686-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t686-3">
   <w.rf>
    <LM>w#w-d1t686-3</LM>
   </w.rf>
   <form>naději</form>
   <lemma>naděje</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m773-d-id79805">
   <w.rf>
    <LM>w#w-d-id79805</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-702">
  <m id="m773-d1t686-5">
   <w.rf>
    <LM>w#w-d1t686-5</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m773-d1t686-6">
   <w.rf>
    <LM>w#w-d1t686-6</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m773-d1t686-7">
   <w.rf>
    <LM>w#w-d1t686-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t686-9">
   <w.rf>
    <LM>w#w-d1t686-9</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m773-d1t686-10">
   <w.rf>
    <LM>w#w-d1t686-10</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m773-d1t686-8">
   <w.rf>
    <LM>w#w-d1t686-8</LM>
   </w.rf>
   <form>povídaly</form>
   <lemma>povídat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d-id79874">
   <w.rf>
    <LM>w#w-d-id79874</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e691-x2">
  <m id="m773-d1t698-1">
   <w.rf>
    <LM>w#w-d1t698-1</LM>
   </w.rf>
   <form>Budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m773-d1t698-2">
   <w.rf>
    <LM>w#w-d1t698-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t698-3">
   <w.rf>
    <LM>w#w-d1t698-3</LM>
   </w.rf>
   <form>divit</form>
   <lemma>divit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id80052">
   <w.rf>
    <LM>w#w-d-id80052</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t698-5">
   <w.rf>
    <LM>w#w-d1t698-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t698-12">
   <w.rf>
    <LM>w#w-d1t698-12</LM>
   </w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1t698-10">
   <w.rf>
    <LM>w#w-d1t698-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t698-11">
   <w.rf>
    <LM>w#w-d1t698-11</LM>
   </w.rf>
   <form>venku</form>
   <lemma>venku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t698-7">
   <w.rf>
    <LM>w#w-d1t698-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t698-8">
   <w.rf>
    <LM>w#w-d1t698-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t698-9">
   <w.rf>
    <LM>w#w-d1t698-9</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t698-13">
   <w.rf>
    <LM>w#w-d1t698-13</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t698-14">
   <w.rf>
    <LM>w#w-d1t698-14</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m773-d-id80215">
   <w.rf>
    <LM>w#w-d-id80215</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t698-16">
   <w.rf>
    <LM>w#w-d1t698-16</LM>
   </w.rf>
   <form>nežli</form>
   <lemma>nežli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t698-17">
   <w.rf>
    <LM>w#w-d1t698-17</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m773-d1t698-18">
   <w.rf>
    <LM>w#w-d1t698-18</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t698-19">
   <w.rf>
    <LM>w#w-d1t698-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t698-20">
   <w.rf>
    <LM>w#w-d1t698-20</LM>
   </w.rf>
   <form>Čechách</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m773-d1e691-x2-2132">
   <w.rf>
    <LM>w#w-d1e691-x2-2132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2133">
  <m id="m773-d1t705-2">
   <w.rf>
    <LM>w#w-d1t705-2</LM>
   </w.rf>
   <form>Muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m773-d1t705-1">
   <w.rf>
    <LM>w#w-d1t705-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t705-3">
   <w.rf>
    <LM>w#w-d1t705-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1t705-4">
   <w.rf>
    <LM>w#w-d1t705-4</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m773-d1t705-7">
   <w.rf>
    <LM>w#w-d1t705-7</LM>
   </w.rf>
   <form>podzemní</form>
   <lemma>podzemní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m773-d1t705-8">
   <w.rf>
    <LM>w#w-d1t705-8</LM>
   </w.rf>
   <form>hnutí</form>
   <lemma>hnutí_^(*3out)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m773-d1e691-x2-1023">
   <w.rf>
    <LM>w#w-d1e691-x2-1023</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-967">
  <m id="m773-d1t711-9">
   <w.rf>
    <LM>w#w-d1t711-9</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t711-10">
   <w.rf>
    <LM>w#w-d1t711-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t711-11">
   <w.rf>
    <LM>w#w-d1t711-11</LM>
   </w.rf>
   <form>teta</form>
   <lemma>teta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1t711-12">
   <w.rf>
    <LM>w#w-d1t711-12</LM>
   </w.rf>
   <form>Malva</form>
   <lemma>Malva_;Y_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d-id80712">
   <w.rf>
    <LM>w#w-d-id80712</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t711-14">
   <w.rf>
    <LM>w#w-d1t711-14</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t711-15">
   <w.rf>
    <LM>w#w-d1t711-15</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t711-16">
   <w.rf>
    <LM>w#w-d1t711-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t711-17">
   <w.rf>
    <LM>w#w-d1t711-17</LM>
   </w.rf>
   <form>transportu</form>
   <lemma>transport</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d-id80776">
   <w.rf>
    <LM>w#w-d-id80776</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t711-20">
   <w.rf>
    <LM>w#w-d1t711-20</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t711-21">
   <w.rf>
    <LM>w#w-d1t711-21</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d-id80831">
   <w.rf>
    <LM>w#w-d-id80831</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-967-978">
   <w.rf>
    <LM>w#w-967-978</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t713-1">
   <w.rf>
    <LM>w#w-d1t713-1</LM>
   </w.rf>
   <form>Neplač</form>
   <lemma>plakat</lemma>
   <tag>Vi-S---2--N-I--</tag>
  </m>
  <m id="m773-967-980">
   <w.rf>
    <LM>w#w-967-980</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t713-2">
   <w.rf>
    <LM>w#w-d1t713-2</LM>
   </w.rf>
   <form>Aličko</form>
   <lemma>Alička_;Y</lemma>
   <tag>NNFS5-----A----</tag>
  </m>
  <m id="m773-967-2163">
   <w.rf>
    <LM>w#w-967-2163</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2164">
  <m id="m773-d1t713-4">
   <w.rf>
    <LM>w#w-d1t713-4</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t713-5">
   <w.rf>
    <LM>w#w-d1t713-5</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m773-d1t713-6">
   <w.rf>
    <LM>w#w-d1t713-6</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-d1t713-7">
   <w.rf>
    <LM>w#w-d1t713-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t713-8">
   <w.rf>
    <LM>w#w-d1t713-8</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t713-9">
   <w.rf>
    <LM>w#w-d1t713-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t713-10">
   <w.rf>
    <LM>w#w-d1t713-10</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m773-967-982">
   <w.rf>
    <LM>w#w-967-982</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t713-11">
   <w.rf>
    <LM>w#w-d1t713-11</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t713-12">
   <w.rf>
    <LM>w#w-d1t713-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t713-13">
   <w.rf>
    <LM>w#w-d1t713-13</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t713-14">
   <w.rf>
    <LM>w#w-d1t713-14</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m773-d1t713-15">
   <w.rf>
    <LM>w#w-d1t713-15</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m773-d-id81075">
   <w.rf>
    <LM>w#w-d-id81075</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t715-1">
   <w.rf>
    <LM>w#w-d1t715-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t715-2">
   <w.rf>
    <LM>w#w-d1t715-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t715-3">
   <w.rf>
    <LM>w#w-d1t715-3</LM>
   </w.rf>
   <form>sejdeme</form>
   <lemma>sejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m773-d1t715-4">
   <w.rf>
    <LM>w#w-d1t715-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t715-5">
   <w.rf>
    <LM>w#w-d1t715-5</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m773-967-983">
   <w.rf>
    <LM>w#w-967-983</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d-id81170">
   <w.rf>
    <LM>w#w-d-id81170</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-955">
  <m id="m773-d1t715-8">
   <w.rf>
    <LM>w#w-d1t715-8</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t715-9">
   <w.rf>
    <LM>w#w-d1t715-9</LM>
   </w.rf>
   <form>hrozná</form>
   <lemma>hrozný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m773-d1t715-10">
   <w.rf>
    <LM>w#w-d1t715-10</LM>
   </w.rf>
   <form>optimistka</form>
   <lemma>optimistka_^(*2a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1t718-1">
   <w.rf>
    <LM>w#w-d1t718-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t718-4">
   <w.rf>
    <LM>w#w-d1t718-4</LM>
   </w.rf>
   <form>udržovala</form>
   <lemma>udržovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t718-3">
   <w.rf>
    <LM>w#w-d1t718-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m773-d1t720-5">
   <w.rf>
    <LM>w#w-d1t720-5</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m773-d1t720-6">
   <w.rf>
    <LM>w#w-d1t720-6</LM>
   </w.rf>
   <form>optimismem</form>
   <lemma>optimismus_,s_^(^DD**optimizmus)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m773-d1t720-1">
   <w.rf>
    <LM>w#w-d1t720-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t720-2">
   <w.rf>
    <LM>w#w-d1t720-2</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m773-d-id81437">
   <w.rf>
    <LM>w#w-d-id81437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e691-x4">
  <m id="m773-d1t728-3">
   <w.rf>
    <LM>w#w-d1t728-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t728-4">
   <w.rf>
    <LM>w#w-d1t728-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t728-5">
   <w.rf>
    <LM>w#w-d1t728-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t728-7">
   <w.rf>
    <LM>w#w-d1t728-7</LM>
   </w.rf>
   <form>musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t728-8">
   <w.rf>
    <LM>w#w-d1t728-8</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t728-9">
   <w.rf>
    <LM>w#w-d1t728-9</LM>
   </w.rf>
   <form>rozloučit</form>
   <lemma>rozloučit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1e691-x4-1234">
   <w.rf>
    <LM>w#w-d1e691-x4-1234</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t731-2">
   <w.rf>
    <LM>w#w-d1t731-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t731-3">
   <w.rf>
    <LM>w#w-d1t731-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t731-4">
   <w.rf>
    <LM>w#w-d1t731-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t731-5">
   <w.rf>
    <LM>w#w-d1t731-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t731-6">
   <w.rf>
    <LM>w#w-d1t731-6</LM>
   </w.rf>
   <form>navzájem</form>
   <lemma>navzájem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t731-7">
   <w.rf>
    <LM>w#w-d1t731-7</LM>
   </w.rf>
   <form>povzbuzovaly</form>
   <lemma>povzbuzovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t731-9">
   <w.rf>
    <LM>w#w-d1t731-9</LM>
   </w.rf>
   <form>písničkami</form>
   <lemma>písnička</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m773-d1e691-x4-1237">
   <w.rf>
    <LM>w#w-d1e691-x4-1237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1238">
  <m id="m773-d1t733-3">
   <w.rf>
    <LM>w#w-d1t733-3</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t733-4">
   <w.rf>
    <LM>w#w-d1t733-4</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-1238-1247">
   <w.rf>
    <LM>w#w-1238-1247</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t733-2">
   <w.rf>
    <LM>w#w-d1t733-2</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t733-5">
   <w.rf>
    <LM>w#w-d1t733-5</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t733-6">
   <w.rf>
    <LM>w#w-d1t733-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m773-d1t733-7">
   <w.rf>
    <LM>w#w-d1t733-7</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t733-9">
   <w.rf>
    <LM>w#w-d1t733-9</LM>
   </w.rf>
   <form>Nora</form>
   <lemma>Nora-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t733-10">
   <w.rf>
    <LM>w#w-d1t733-10</LM>
   </w.rf>
   <form>Frýd</form>
   <lemma>Frýd_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t733-11">
   <w.rf>
    <LM>w#w-d1t733-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t733-12">
   <w.rf>
    <LM>w#w-d1t733-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t733-13">
   <w.rf>
    <LM>w#w-d1t733-13</LM>
   </w.rf>
   <form>jiní</form>
   <lemma>jiný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m773-1238-1252">
   <w.rf>
    <LM>w#w-1238-1252</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t733-14">
   <w.rf>
    <LM>w#w-d1t733-14</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDMP4----------</tag>
  </m>
  <m id="m773-d1t733-15">
   <w.rf>
    <LM>w#w-d1t733-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t733-17">
   <w.rf>
    <LM>w#w-d1t733-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t733-18">
   <w.rf>
    <LM>w#w-d1t733-18</LM>
   </w.rf>
   <form>nepamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m773-1238-2173">
   <w.rf>
    <LM>w#w-1238-2173</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2174">
  <m id="m773-1238-1254">
   <w.rf>
    <LM>w#w-1238-1254</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t737-4">
   <w.rf>
    <LM>w#w-d1t737-4</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t737-3">
   <w.rf>
    <LM>w#w-d1t737-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d-id82135">
   <w.rf>
    <LM>w#w-d-id82135</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t737-6">
   <w.rf>
    <LM>w#w-d1t737-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t737-8">
   <w.rf>
    <LM>w#w-d1t737-8</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t737-9">
   <w.rf>
    <LM>w#w-d1t737-9</LM>
   </w.rf>
   <form>rozštěp</form>
   <lemma>rozštěp</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m773-d-id82206">
   <w.rf>
    <LM>w#w-d-id82206</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e691-x6">
  <m id="m773-d1t752-5">
   <w.rf>
    <LM>w#w-d1t752-5</LM>
   </w.rf>
   <form>Pamatovala</form>
   <lemma>pamatovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m773-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m773-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m773-d1t752-6">
   <w.rf>
    <LM>w#w-d1t752-6</LM>
   </w.rf>
   <form>víceméně</form>
   <lemma>víceméně</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t752-7">
   <w.rf>
    <LM>w#w-d1t752-7</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m773-d1t752-9">
   <w.rf>
    <LM>w#w-d1t752-9</LM>
   </w.rf>
   <form>rozštěpu</form>
   <lemma>rozštěp</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m773-d1t752-10">
   <w.rf>
    <LM>w#w-d1t752-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t752-11">
   <w.rf>
    <LM>w#w-d1t752-11</LM>
   </w.rf>
   <form>teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t752-12">
   <w.rf>
    <LM>w#w-d1t752-12</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m773-d1t752-13">
   <w.rf>
    <LM>w#w-d1t752-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m773-d1t752-14">
   <w.rf>
    <LM>w#w-d1t752-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t752-15">
   <w.rf>
    <LM>w#w-d1t752-15</LM>
   </w.rf>
   <form>dozvěděla</form>
   <lemma>dozvědět</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d-id82544">
   <w.rf>
    <LM>w#w-d-id82544</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t752-17">
   <w.rf>
    <LM>w#w-d1t752-17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t752-18">
   <w.rf>
    <LM>w#w-d1t752-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t752-19">
   <w.rf>
    <LM>w#w-d1t752-19</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t752-20">
   <w.rf>
    <LM>w#w-d1t752-20</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m773-d1t754-1">
   <w.rf>
    <LM>w#w-d1t754-1</LM>
   </w.rf>
   <form>spisovatel</form>
   <lemma>spisovatel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t754-2">
   <w.rf>
    <LM>w#w-d1t754-2</LM>
   </w.rf>
   <form>Nora</form>
   <lemma>Nora-2_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d1t754-3">
   <w.rf>
    <LM>w#w-d1t754-3</LM>
   </w.rf>
   <form>Frýd</form>
   <lemma>Frýd_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m773-d-id82670">
   <w.rf>
    <LM>w#w-d-id82670</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e758-x2">
  <m id="m773-d1t763-1">
   <w.rf>
    <LM>w#w-d1t763-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t763-2">
   <w.rf>
    <LM>w#w-d1t763-2</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m773-d1t763-3">
   <w.rf>
    <LM>w#w-d1t763-3</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t763-4">
   <w.rf>
    <LM>w#w-d1t763-4</LM>
   </w.rf>
   <form>ošklivá</form>
   <lemma>ošklivý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m773-d1t763-5">
   <w.rf>
    <LM>w#w-d1t763-5</LM>
   </w.rf>
   <form>zima</form>
   <lemma>zima-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d1t763-7">
   <w.rf>
    <LM>w#w-d1t763-7</LM>
   </w.rf>
   <form>1944</form>
   <lemma>1944</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m773-d1e758-x2-1405">
   <w.rf>
    <LM>w#w-d1e758-x2-1405</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t765-2">
   <w.rf>
    <LM>w#w-d1t765-2</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m773-d1e758-x2-1414">
   <w.rf>
    <LM>w#w-d1e758-x2-1414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1407">
  <m id="m773-d1t765-4">
   <w.rf>
    <LM>w#w-d1t765-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m773-d1t765-5">
   <w.rf>
    <LM>w#w-d1t765-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t765-6">
   <w.rf>
    <LM>w#w-d1t765-6</LM>
   </w.rf>
   <form>mrazy</form>
   <lemma>mráz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m773-d-id82904">
   <w.rf>
    <LM>w#w-d-id82904</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e768-x2">
  <m id="m773-d1t773-1">
   <w.rf>
    <LM>w#w-d1t773-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1e768-x2-1450">
   <w.rf>
    <LM>w#w-d1e768-x2-1450</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t773-2">
   <w.rf>
    <LM>w#w-d1t773-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m773-d1t782-2">
   <w.rf>
    <LM>w#w-d1t782-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t782-3">
   <w.rf>
    <LM>w#w-d1t782-3</LM>
   </w.rf>
   <form>mrazy</form>
   <lemma>mráz</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m773-d1e768-x2-1451">
   <w.rf>
    <LM>w#w-d1e768-x2-1451</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t782-4">
   <w.rf>
    <LM>w#w-d1t782-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t788-1">
   <w.rf>
    <LM>w#w-d1t788-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t788-2">
   <w.rf>
    <LM>w#w-d1t788-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t788-3">
   <w.rf>
    <LM>w#w-d1t788-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m773-d1t788-4">
   <w.rf>
    <LM>w#w-d1t788-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1e768-x2-2215">
   <w.rf>
    <LM>w#w-d1e768-x2-2215</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1e768-x2-2216">
   <w.rf>
    <LM>w#w-d1e768-x2-2216</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m773-d1e768-x2-2217">
   <w.rf>
    <LM>w#w-d1e768-x2-2217</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m773-d1t788-6">
   <w.rf>
    <LM>w#w-d1t788-6</LM>
   </w.rf>
   <form>vypadlo</form>
   <lemma>vypadnout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m773-d1t788-7">
   <w.rf>
    <LM>w#w-d1t788-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t788-8">
   <w.rf>
    <LM>w#w-d1t788-8</LM>
   </w.rf>
   <form>paměti</form>
   <lemma>paměť</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m773-d-id82954">
   <w.rf>
    <LM>w#w-d-id82954</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e791-x2">
  <m id="m773-d1t798-3">
   <w.rf>
    <LM>w#w-d1t798-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t798-4">
   <w.rf>
    <LM>w#w-d1t798-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1e791-x2-33">
   <w.rf>
    <LM>w#w-d1e791-x2-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t798-5">
   <w.rf>
    <LM>w#w-d1t798-5</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m773-d1t798-7">
   <w.rf>
    <LM>w#w-d1t798-7</LM>
   </w.rf>
   <form>trošičku</form>
   <lemma>trošičku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t798-6">
   <w.rf>
    <LM>w#w-d1t798-6</LM>
   </w.rf>
   <form>blížit</form>
   <lemma>blížit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id83294">
   <w.rf>
    <LM>w#w-d-id83294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e791-x3">
  <m id="m773-d1t813-1">
   <w.rf>
    <LM>w#w-d1t813-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t813-2">
   <w.rf>
    <LM>w#w-d1t813-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1t813-4">
   <w.rf>
    <LM>w#w-d1t813-4</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m773-d1t813-5">
   <w.rf>
    <LM>w#w-d1t813-5</LM>
   </w.rf>
   <form>projevovat</form>
   <lemma>projevovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d1e791-x3-2006">
   <w.rf>
    <LM>w#w-d1e791-x3-2006</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t813-6">
   <w.rf>
    <LM>w#w-d1t813-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t813-7">
   <w.rf>
    <LM>w#w-d1t813-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m773-d1e791-x3-1974">
   <w.rf>
    <LM>w#w-d1e791-x3-1974</LM>
   </w.rf>
   <form>vrací</form>
   <lemma>vracet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m773-d1e791-x3-1975">
   <w.rf>
    <LM>w#w-d1e791-x3-1975</LM>
   </w.rf>
   <form>naděje</form>
   <lemma>naděje</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m773-d-id83413">
   <w.rf>
    <LM>w#w-d-id83413</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-d1e826-x2">
  <m id="m773-d1t831-3">
   <w.rf>
    <LM>w#w-d1t831-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m773-d1t831-4">
   <w.rf>
    <LM>w#w-d1t831-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m773-d1t831-5">
   <w.rf>
    <LM>w#w-d1t831-5</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m773-d1t831-7">
   <w.rf>
    <LM>w#w-d1t831-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t831-8">
   <w.rf>
    <LM>w#w-d1t831-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t831-9">
   <w.rf>
    <LM>w#w-d1t831-9</LM>
   </w.rf>
   <form>dostávaly</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t831-11">
   <w.rf>
    <LM>w#w-d1t831-11</LM>
   </w.rf>
   <form>zprávy</form>
   <lemma>zpráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m773-d1e826-x2-1714">
   <w.rf>
    <LM>w#w-d1e826-x2-1714</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t831-12">
   <w.rf>
    <LM>w#w-d1t831-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t831-13">
   <w.rf>
    <LM>w#w-d1t831-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t831-14">
   <w.rf>
    <LM>w#w-d1t831-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m773-d1t831-15">
   <w.rf>
    <LM>w#w-d1t831-15</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t831-16">
   <w.rf>
    <LM>w#w-d1t831-16</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m773-d1t831-17">
   <w.rf>
    <LM>w#w-d1t831-17</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-d1t831-18">
   <w.rf>
    <LM>w#w-d1t831-18</LM>
   </w.rf>
   <form>trvat</form>
   <lemma>trvat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m773-d-id83941">
   <w.rf>
    <LM>w#w-d-id83941</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t835-1">
   <w.rf>
    <LM>w#w-d1t835-1</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t835-2">
   <w.rf>
    <LM>w#w-d1t835-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t835-3">
   <w.rf>
    <LM>w#w-d1t835-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m773-d1t835-4">
   <w.rf>
    <LM>w#w-d1t835-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m773-d1t835-5">
   <w.rf>
    <LM>w#w-d1t835-5</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m773-d1t835-6">
   <w.rf>
    <LM>w#w-d1t835-6</LM>
   </w.rf>
   <form>vypozorovat</form>
   <lemma>vypozorovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m773-d1t835-7">
   <w.rf>
    <LM>w#w-d1t835-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t835-8">
   <w.rf>
    <LM>w#w-d1t835-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m773-d1t835-9">
   <w.rf>
    <LM>w#w-d1t835-9</LM>
   </w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m773-d1t837-1">
   <w.rf>
    <LM>w#w-d1t837-1</LM>
   </w.rf>
   <form>gestapáků</form>
   <lemma>gestapák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m773-d1e826-x2-1718">
   <w.rf>
    <LM>w#w-d1e826-x2-1718</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1719">
  <m id="m773-d1t842-1">
   <w.rf>
    <LM>w#w-d1t842-1</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-1719-1727">
   <w.rf>
    <LM>w#w-1719-1727</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t842-2">
   <w.rf>
    <LM>w#w-d1t842-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t842-3">
   <w.rf>
    <LM>w#w-d1t842-3</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m773-1719-1736">
   <w.rf>
    <LM>w#w-1719-1736</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-1729">
  <m id="m773-d1t842-4">
   <w.rf>
    <LM>w#w-d1t842-4</LM>
   </w.rf>
   <form>Některý</form>
   <lemma>některý</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m773-d1t842-5">
   <w.rf>
    <LM>w#w-d1t842-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t842-7">
   <w.rf>
    <LM>w#w-d1t842-7</LM>
   </w.rf>
   <form>horší</form>
   <lemma>horší</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m773-d1t844-1">
   <w.rf>
    <LM>w#w-d1t844-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t844-2">
   <w.rf>
    <LM>w#w-d1t844-2</LM>
   </w.rf>
   <form>některý</form>
   <lemma>některý</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m773-d1t844-3">
   <w.rf>
    <LM>w#w-d1t844-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t844-5">
   <w.rf>
    <LM>w#w-d1t844-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m773-d1t844-4">
   <w.rf>
    <LM>w#w-d1t844-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t844-7">
   <w.rf>
    <LM>w#w-d1t844-7</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m773-1729-2243">
   <w.rf>
    <LM>w#w-1729-2243</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m773-26127_03-2244">
  <m id="m773-d1t844-8">
   <w.rf>
    <LM>w#w-d1t844-8</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t844-9">
   <w.rf>
    <LM>w#w-d1t844-9</LM>
   </w.rf>
   <form>kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-1729-1837">
   <w.rf>
    <LM>w#w-1729-1837</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d-id84539">
   <w.rf>
    <LM>w#w-d-id84539</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t844-13">
   <w.rf>
    <LM>w#w-d1t844-13</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m773-d1t846-1">
   <w.rf>
    <LM>w#w-d1t846-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t846-2">
   <w.rf>
    <LM>w#w-d1t846-2</LM>
   </w.rf>
   <form>řekly</form>
   <lemma>říci</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m773-d-id84604">
   <w.rf>
    <LM>w#w-d-id84604</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m773-d1t846-4">
   <w.rf>
    <LM>w#w-d1t846-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m773-d1t846-5">
   <w.rf>
    <LM>w#w-d1t846-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m773-d1t846-6">
   <w.rf>
    <LM>w#w-d1t846-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m773-d1t846-7">
   <w.rf>
    <LM>w#w-d1t846-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m773-d1t846-8">
   <w.rf>
    <LM>w#w-d1t846-8</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m773-d1t848-1">
   <w.rf>
    <LM>w#w-d1t848-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m773-d1t848-2">
   <w.rf>
    <LM>w#w-d1t848-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m773-d1t848-3">
   <w.rf>
    <LM>w#w-d1t848-3</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m773-2244-2245">
   <w.rf>
    <LM>w#w-2244-2245</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
