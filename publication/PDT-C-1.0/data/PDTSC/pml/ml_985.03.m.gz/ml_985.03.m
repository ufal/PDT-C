<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_985.03.w.gz" />
  </references>
 </head>
 <s id="m985-13808_05-160">
  <m id="m985-d1t1218-1">
   <w.rf>
    <LM>w#w-d1t1218-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1218-2">
   <w.rf>
    <LM>w#w-d1t1218-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-160-171">
   <w.rf>
    <LM>w#w-160-171</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-160-172">
   <w.rf>
    <LM>w#w-160-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d-id90524">
   <w.rf>
    <LM>w#w-d-id90524</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1219-x2">
  <m id="m985-d1t1222-1">
   <w.rf>
    <LM>w#w-d1t1222-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m985-d1t1222-2">
   <w.rf>
    <LM>w#w-d1t1222-2</LM>
   </w.rf>
   <form>vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d-id90825">
   <w.rf>
    <LM>w#w-d-id90825</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-814">
  <m id="m985-814-819">
   <w.rf>
    <LM>w#w-814-819</LM>
   </w.rf>
   <form>Panáček</form>
   <lemma>Panáček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-814-827">
   <w.rf>
    <LM>w#w-814-827</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-814-820">
   <w.rf>
    <LM>w#w-814-820</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4MS4----------</tag>
  </m>
  <m id="m985-814-821">
   <w.rf>
    <LM>w#w-814-821</LM>
   </w.rf>
   <form>porazí</form>
   <lemma>porazit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m985-814-822">
   <w.rf>
    <LM>w#w-814-822</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-814-828">
   <w.rf>
    <LM>w#w-814-828</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m985-814-824">
   <w.rf>
    <LM>w#w-814-824</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m985-814-823">
   <w.rf>
    <LM>w#w-814-823</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-814-825">
   <w.rf>
    <LM>w#w-814-825</LM>
   </w.rf>
   <form>postaví</form>
   <lemma>postavit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m985-814-826">
   <w.rf>
    <LM>w#w-814-826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1235-x3">
  <m id="m985-d1t1244-1">
   <w.rf>
    <LM>w#w-d1t1244-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1246-3">
   <w.rf>
    <LM>w#w-d1t1246-3</LM>
   </w.rf>
   <form>nátury</form>
   <lemma>nátura</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1t1246-4">
   <w.rf>
    <LM>w#w-d1t1246-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1254-2">
   <w.rf>
    <LM>w#w-d1t1254-2</LM>
   </w.rf>
   <form>optimista</form>
   <lemma>optimista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1e1235-x3-968">
   <w.rf>
    <LM>w#w-d1e1235-x3-968</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1254-3">
   <w.rf>
    <LM>w#w-d1t1254-3</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d-id91056">
   <w.rf>
    <LM>w#w-d-id91056</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-953">
  <m id="m985-d1t1254-5">
   <w.rf>
    <LM>w#w-d1t1254-5</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1254-6">
   <w.rf>
    <LM>w#w-d1t1254-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1254-7">
   <w.rf>
    <LM>w#w-d1t1254-7</LM>
   </w.rf>
   <form>doufám</form>
   <lemma>doufat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-953-977">
   <w.rf>
    <LM>w#w-953-977</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-978">
  <m id="m985-d1t1256-4">
   <w.rf>
    <LM>w#w-d1t1256-4</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m985-d1t1256-5">
   <w.rf>
    <LM>w#w-d1t1256-5</LM>
   </w.rf>
   <form>životní</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m985-d1t1256-6">
   <w.rf>
    <LM>w#w-d1t1256-6</LM>
   </w.rf>
   <form>moto</form>
   <lemma>moto-1_,s_^(heslo)_(^DD**motto-1)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m985-d1t1256-8">
   <w.rf>
    <LM>w#w-d1t1256-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1258-1">
   <w.rf>
    <LM>w#w-d1t1258-1</LM>
   </w.rf>
   <form>posledním</form>
   <lemma>poslední</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m985-d1t1258-2">
   <w.rf>
    <LM>w#w-d1t1258-2</LM>
   </w.rf>
   <form>desítiletí</form>
   <lemma>desítiletí_,s_^(^DD**desetiletí)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m985-953-976">
   <w.rf>
    <LM>w#w-953-976</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1258-4">
   <w.rf>
    <LM>w#w-d1t1258-4</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1258-3">
   <w.rf>
    <LM>w#w-d1t1258-3</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m985-d1t1258-5">
   <w.rf>
    <LM>w#w-d1t1258-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m985-d-id91678">
   <w.rf>
    <LM>w#w-d-id91678</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1258-7">
   <w.rf>
    <LM>w#w-d1t1258-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-978-1804">
   <w.rf>
    <LM>w#w-978-1804</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-978-989">
   <w.rf>
    <LM>w#w-978-989</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1267-1">
   <w.rf>
    <LM>w#w-d1t1267-1</LM>
   </w.rf>
   <form>Nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-978-993">
   <w.rf>
    <LM>w#w-978-993</LM>
   </w.rf>
   <form>nezačni</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>Vi-S---2--N-P--</tag>
  </m>
  <m id="m985-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>přestávat</form>
   <lemma>přestávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m985-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1269-4">
   <w.rf>
    <LM>w#w-d1t1269-4</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1269-5">
   <w.rf>
    <LM>w#w-d1t1269-5</LM>
   </w.rf>
   <form>nepřestaň</form>
   <lemma>přestat</lemma>
   <tag>Vi-S---2--N-P--</tag>
  </m>
  <m id="m985-d1t1269-6">
   <w.rf>
    <LM>w#w-d1t1269-6</LM>
   </w.rf>
   <form>začínat</form>
   <lemma>začínat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m985-d-id91862">
   <w.rf>
    <LM>w#w-d-id91862</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-978-990">
   <w.rf>
    <LM>w#w-978-990</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1247-x3">
  <m id="m985-d1t1271-1">
   <w.rf>
    <LM>w#w-d1t1271-1</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d-id91902">
   <w.rf>
    <LM>w#w-d-id91902</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1e1247-x3-1098">
   <w.rf>
    <LM>w#w-d1e1247-x3-1098</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m985-d1t1274-4">
   <w.rf>
    <LM>w#w-d1t1274-4</LM>
   </w.rf>
   <form>začínám</form>
   <lemma>začínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1274-5">
   <w.rf>
    <LM>w#w-d1t1274-5</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d-id91997">
   <w.rf>
    <LM>w#w-d-id91997</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1247-x4">
  <m id="m985-d1t1278-5">
   <w.rf>
    <LM>w#w-d1t1278-5</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1278-4">
   <w.rf>
    <LM>w#w-d1t1278-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1278-3">
   <w.rf>
    <LM>w#w-d1t1278-3</LM>
   </w.rf>
   <form>nepřestala</form>
   <lemma>přestat</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m985-d-id92100">
   <w.rf>
    <LM>w#w-d-id92100</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1278-7">
   <w.rf>
    <LM>w#w-d1t1278-7</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1278-8">
   <w.rf>
    <LM>w#w-d1t1278-8</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m985-d1e1247-x4-1104">
   <w.rf>
    <LM>w#w-d1e1247-x4-1104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1280-1">
   <w.rf>
    <LM>w#w-d1t1280-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1280-2">
   <w.rf>
    <LM>w#w-d1t1280-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1280-3">
   <w.rf>
    <LM>w#w-d1t1280-3</LM>
   </w.rf>
   <form>půjde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m985-d1t1280-4">
   <w.rf>
    <LM>w#w-d1t1280-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1e1247-x4-1462">
   <w.rf>
    <LM>w#w-d1e1247-x4-1462</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1463">
  <m id="m985-d1t1282-1">
   <w.rf>
    <LM>w#w-d1t1282-1</LM>
   </w.rf>
   <form>Jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1282-2">
   <w.rf>
    <LM>w#w-d1t1282-2</LM>
   </w.rf>
   <form>pánbůh</form>
   <lemma>pánbůh</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1t1282-4">
   <w.rf>
    <LM>w#w-d1t1282-4</LM>
   </w.rf>
   <form>zdraví</form>
   <lemma>zdraví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m985-d1t1282-5">
   <w.rf>
    <LM>w#w-d1t1282-5</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m985-d-id92315">
   <w.rf>
    <LM>w#w-d-id92315</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1284-1">
   <w.rf>
    <LM>w#w-d1t1284-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m985-d1t1284-2">
   <w.rf>
    <LM>w#w-d1t1284-2</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1284-6">
   <w.rf>
    <LM>w#w-d1t1284-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m985-d1t1284-8">
   <w.rf>
    <LM>w#w-d1t1284-8</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1284-3">
   <w.rf>
    <LM>w#w-d1t1284-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1284-4">
   <w.rf>
    <LM>w#w-d1t1284-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m985-d1t1284-5">
   <w.rf>
    <LM>w#w-d1t1284-5</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m985-d1t1284-9">
   <w.rf>
    <LM>w#w-d1t1284-9</LM>
   </w.rf>
   <form>poklepu</form>
   <lemma>poklepat</lemma>
   <tag>VB-S---1P-AAP-1</tag>
  </m>
  <m id="m985-d1t1284-10">
   <w.rf>
    <LM>w#w-d1t1284-10</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m985-d-id92488">
   <w.rf>
    <LM>w#w-d-id92488</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1247-x5">
  <m id="m985-d1t1289-1">
   <w.rf>
    <LM>w#w-d1t1289-1</LM>
   </w.rf>
   <form>Ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m985-d1t1289-2">
   <w.rf>
    <LM>w#w-d1t1289-2</LM>
   </w.rf>
   <form>cestuju</form>
   <lemma>cestovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1e1247-x5-1822">
   <w.rf>
    <LM>w#w-d1e1247-x5-1822</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1823">
  <m id="m985-d1t1295-1">
   <w.rf>
    <LM>w#w-d1t1295-1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1295-2">
   <w.rf>
    <LM>w#w-d1t1295-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1295-4">
   <w.rf>
    <LM>w#w-d1t1295-4</LM>
   </w.rf>
   <form>situaci</form>
   <lemma>situace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-d-id92665">
   <w.rf>
    <LM>w#w-d-id92665</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1295-6">
   <w.rf>
    <LM>w#w-d1t1295-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1297-2">
   <w.rf>
    <LM>w#w-d1t1297-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m985-d1t1295-7">
   <w.rf>
    <LM>w#w-d1t1295-7</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1297-1">
   <w.rf>
    <LM>w#w-d1t1297-1</LM>
   </w.rf>
   <form>zvát</form>
   <lemma>zvát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m985-d1t1297-4">
   <w.rf>
    <LM>w#w-d1t1297-4</LM>
   </w.rf>
   <form>zdejší</form>
   <lemma>zdejší</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m985-d1t1297-3">
   <w.rf>
    <LM>w#w-d1t1297-3</LM>
   </w.rf>
   <form>přátele</form>
   <lemma>přítel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m985-d-id92769">
   <w.rf>
    <LM>w#w-d-id92769</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1297-6">
   <w.rf>
    <LM>w#w-d1t1297-6</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m985-d1t1300-1">
   <w.rf>
    <LM>w#w-d1t1300-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1300-2">
   <w.rf>
    <LM>w#w-d1t1300-2</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m985-d1t1297-7">
   <w.rf>
    <LM>w#w-d1t1297-7</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m985-d1t1300-4">
   <w.rf>
    <LM>w#w-d1t1300-4</LM>
   </w.rf>
   <form>nejsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m985-d1t1300-3">
   <w.rf>
    <LM>w#w-d1t1300-3</LM>
   </w.rf>
   <form>finančně</form>
   <lemma>finančně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1300-5">
   <w.rf>
    <LM>w#w-d1t1300-5</LM>
   </w.rf>
   <form>natolik</form>
   <lemma>natolik</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1308-1">
   <w.rf>
    <LM>w#w-d1t1308-1</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d-id92986">
   <w.rf>
    <LM>w#w-d-id92986</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1308-5">
   <w.rf>
    <LM>w#w-d1t1308-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1308-6">
   <w.rf>
    <LM>w#w-d1t1308-6</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m985-d1t1308-7">
   <w.rf>
    <LM>w#w-d1t1308-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m985-d1t1308-8">
   <w.rf>
    <LM>w#w-d1t1308-8</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1308-9">
   <w.rf>
    <LM>w#w-d1t1308-9</LM>
   </w.rf>
   <form>dovolit</form>
   <lemma>dovolit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m985-d1t1308-10">
   <w.rf>
    <LM>w#w-d1t1308-10</LM>
   </w.rf>
   <form>cesty</form>
   <lemma>cesta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m985-d1t1308-11">
   <w.rf>
    <LM>w#w-d1t1308-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1308-12">
   <w.rf>
    <LM>w#w-d1t1308-12</LM>
   </w.rf>
   <form>zahraničí</form>
   <lemma>zahraničí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m985-d-id93118">
   <w.rf>
    <LM>w#w-d-id93118</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1313-1">
   <w.rf>
    <LM>w#w-d1t1313-1</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m985-d1t1313-2">
   <w.rf>
    <LM>w#w-d1t1313-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1315-1">
   <w.rf>
    <LM>w#w-d1t1315-1</LM>
   </w.rf>
   <form>odsud</form>
   <lemma>odsud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1315-2">
   <w.rf>
    <LM>w#w-d1t1315-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1315-3">
   <w.rf>
    <LM>w#w-d1t1315-3</LM>
   </w.rf>
   <form>nákladné</form>
   <lemma>nákladný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m985-d1e1247-x5-1792">
   <w.rf>
    <LM>w#w-d1e1247-x5-1792</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1770">
  <m id="m985-d1t1317-3">
   <w.rf>
    <LM>w#w-d1t1317-3</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1317-9">
   <w.rf>
    <LM>w#w-d1t1317-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1317-5">
   <w.rf>
    <LM>w#w-d1t1317-5</LM>
   </w.rf>
   <form>vzdálenější</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAFS4----2A----</tag>
  </m>
  <m id="m985-d1t1317-6">
   <w.rf>
    <LM>w#w-d1t1317-6</LM>
   </w.rf>
   <form>příbuznou</form>
   <lemma>příbuzná-1_^(*3ý-1)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m985-d1t1317-7">
   <w.rf>
    <LM>w#w-d1t1317-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1317-8">
   <w.rf>
    <LM>w#w-d1t1317-8</LM>
   </w.rf>
   <form>Slovensku</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m985-d-id93388">
   <w.rf>
    <LM>w#w-d-id93388</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1317-11">
   <w.rf>
    <LM>w#w-d1t1317-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1317-12">
   <w.rf>
    <LM>w#w-d1t1317-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1317-16">
   <w.rf>
    <LM>w#w-d1t1317-16</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-d1t1317-13">
   <w.rf>
    <LM>w#w-d1t1317-13</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1317-14">
   <w.rf>
    <LM>w#w-d1t1317-14</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m985-d1t1317-15">
   <w.rf>
    <LM>w#w-d1t1317-15</LM>
   </w.rf>
   <form>bratrance</form>
   <lemma>bratranec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m985-1770-1829">
   <w.rf>
    <LM>w#w-1770-1829</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1830">
  <m id="m985-d1t1319-2">
   <w.rf>
    <LM>w#w-d1t1319-2</LM>
   </w.rf>
   <form>Bratranec</form>
   <lemma>bratranec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1t1319-3">
   <w.rf>
    <LM>w#w-d1t1319-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1319-4">
   <w.rf>
    <LM>w#w-d1t1319-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1319-5">
   <w.rf>
    <LM>w#w-d1t1319-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1319-6">
   <w.rf>
    <LM>w#w-d1t1319-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1319-7">
   <w.rf>
    <LM>w#w-d1t1319-7</LM>
   </w.rf>
   <form>smrti</form>
   <lemma>smrt</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-1830-1831">
   <w.rf>
    <LM>w#w-1830-1831</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1832">
  <m id="m985-d1t1319-9">
   <w.rf>
    <LM>w#w-d1t1319-9</LM>
   </w.rf>
   <form>Zvu</form>
   <lemma>zvát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1319-8">
   <w.rf>
    <LM>w#w-d1t1319-8</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m985-d1t1319-10">
   <w.rf>
    <LM>w#w-d1t1319-10</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m985-d1t1319-11">
   <w.rf>
    <LM>w#w-d1t1319-11</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m985-d1t1319-13">
   <w.rf>
    <LM>w#w-d1t1319-13</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1319-14">
   <w.rf>
    <LM>w#w-d1t1319-14</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m985-d1t1319-15">
   <w.rf>
    <LM>w#w-d1t1319-15</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m985-1770-2035">
   <w.rf>
    <LM>w#w-1770-2035</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1321-1">
   <w.rf>
    <LM>w#w-d1t1321-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1321-3">
   <w.rf>
    <LM>w#w-d1t1321-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1321-2">
   <w.rf>
    <LM>w#w-d1t1321-2</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m985-d1t1321-4">
   <w.rf>
    <LM>w#w-d1t1321-4</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1321-5">
   <w.rf>
    <LM>w#w-d1t1321-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m985-d1t1321-6">
   <w.rf>
    <LM>w#w-d1t1321-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1323-3">
   <w.rf>
    <LM>w#w-d1t1323-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1323-6">
   <w.rf>
    <LM>w#w-d1t1323-6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m985-d1t1323-8">
   <w.rf>
    <LM>w#w-d1t1323-8</LM>
   </w.rf>
   <form>střední</form>
   <lemma>střední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m985-d1t1323-9">
   <w.rf>
    <LM>w#w-d1t1323-9</LM>
   </w.rf>
   <form>Evropě</form>
   <lemma>Evropa_;G_;Y</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-d1t1323-2">
   <w.rf>
    <LM>w#w-d1t1323-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1323-1">
   <w.rf>
    <LM>w#w-d1t1323-1</LM>
   </w.rf>
   <form>holt</form>
   <lemma>holt_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1323-10">
   <w.rf>
    <LM>w#w-d1t1323-10</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1323-12">
   <w.rf>
    <LM>w#w-d1t1323-12</LM>
   </w.rf>
   <form>moří</form>
   <lemma>moře</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m985-1770-2039">
   <w.rf>
    <LM>w#w-1770-2039</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1990">
  <m id="m985-d1t1326-1">
   <w.rf>
    <LM>w#w-d1t1326-1</LM>
   </w.rf>
   <form>Žiju</form>
   <lemma>žít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1326-2">
   <w.rf>
    <LM>w#w-d1t1326-2</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1326-3">
   <w.rf>
    <LM>w#w-d1t1326-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1326-4">
   <w.rf>
    <LM>w#w-d1t1326-4</LM>
   </w.rf>
   <form>jezera</form>
   <lemma>jezero</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m985-1990-2068">
   <w.rf>
    <LM>w#w-1990-2068</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1326-5">
   <w.rf>
    <LM>w#w-d1t1326-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1328-1">
   <w.rf>
    <LM>w#w-d1t1328-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1328-2">
   <w.rf>
    <LM>w#w-d1t1328-2</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m985-d1t1328-3">
   <w.rf>
    <LM>w#w-d1t1328-3</LM>
   </w.rf>
   <form>nenahradí</form>
   <lemma>nahradit</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m985-d-id94156">
   <w.rf>
    <LM>w#w-d-id94156</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1247-x8">
  <m id="m985-d1t1334-3">
   <w.rf>
    <LM>w#w-d1t1334-3</LM>
   </w.rf>
   <form>Každým</form>
   <lemma>každý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m985-d1t1334-4">
   <w.rf>
    <LM>w#w-d1t1334-4</LM>
   </w.rf>
   <form>rokem</form>
   <lemma>rok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m985-d1e1247-x8-2212">
   <w.rf>
    <LM>w#w-d1e1247-x8-2212</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1e1247-x8-2213">
   <w.rf>
    <LM>w#w-d1e1247-x8-2213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-2214">
  <m id="m985-d1t1334-5">
   <w.rf>
    <LM>w#w-d1t1334-5</LM>
   </w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1334-6">
   <w.rf>
    <LM>w#w-d1t1334-6</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1334-7">
   <w.rf>
    <LM>w#w-d1t1334-7</LM>
   </w.rf>
   <form>naplánovanou</form>
   <lemma>naplánovaný_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m985-d1t1334-8">
   <w.rf>
    <LM>w#w-d1t1334-8</LM>
   </w.rf>
   <form>Mallorku</form>
   <lemma>Mallorka_;G_,s_^(^DD**Mallorca)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m985-d-id94322">
   <w.rf>
    <LM>w#w-d-id94322</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1336-7">
   <w.rf>
    <LM>w#w-d1t1336-7</LM>
   </w.rf>
   <form>vloni</form>
   <lemma>vloni_,s_^(^DD**loni)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1336-8">
   <w.rf>
    <LM>w#w-d1t1336-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1336-9">
   <w.rf>
    <LM>w#w-d1t1336-9</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1336-10">
   <w.rf>
    <LM>w#w-d1t1336-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1336-11">
   <w.rf>
    <LM>w#w-d1t1336-11</LM>
   </w.rf>
   <form>Maltě</form>
   <lemma>malta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-2214-1844">
   <w.rf>
    <LM>w#w-2214-1844</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1845">
  <m id="m985-d1t1341-1">
   <w.rf>
    <LM>w#w-d1t1341-1</LM>
   </w.rf>
   <form>Předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1341-3">
   <w.rf>
    <LM>w#w-d1t1341-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1341-4">
   <w.rf>
    <LM>w#w-d1t1341-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1341-5">
   <w.rf>
    <LM>w#w-d1t1341-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1341-6">
   <w.rf>
    <LM>w#w-d1t1341-6</LM>
   </w.rf>
   <form>Ejlatu</form>
   <lemma>Ejlat_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m985-d-id94663">
   <w.rf>
    <LM>w#w-d-id94663</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1341-8">
   <w.rf>
    <LM>w#w-d1t1341-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1341-9">
   <w.rf>
    <LM>w#w-d1t1341-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1341-10">
   <w.rf>
    <LM>w#w-d1t1341-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m985-d1t1341-11">
   <w.rf>
    <LM>w#w-d1t1341-11</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1341-13">
   <w.rf>
    <LM>w#w-d1t1341-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1341-12">
   <w.rf>
    <LM>w#w-d1t1341-12</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m985-d1t1341-14">
   <w.rf>
    <LM>w#w-d1t1341-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1341-15">
   <w.rf>
    <LM>w#w-d1t1341-15</LM>
   </w.rf>
   <form>Jordánska</form>
   <lemma>Jordánsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m985-2214-2228">
   <w.rf>
    <LM>w#w-2214-2228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-2229">
  <m id="m985-d1t1343-1">
   <w.rf>
    <LM>w#w-d1t1343-1</LM>
   </w.rf>
   <form>Víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d-id94796">
   <w.rf>
    <LM>w#w-d-id94796</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1343-2">
   <w.rf>
    <LM>w#w-d1t1343-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m985-d1t1343-3">
   <w.rf>
    <LM>w#w-d1t1343-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1347-3">
   <w.rf>
    <LM>w#w-d1t1347-3</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1345-1">
   <w.rf>
    <LM>w#w-d1t1345-1</LM>
   </w.rf>
   <form>zvědavá</form>
   <lemma>zvědavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1349-1">
   <w.rf>
    <LM>w#w-d1t1349-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1349-2">
   <w.rf>
    <LM>w#w-d1t1349-2</LM>
   </w.rf>
   <form>zvídavá</form>
   <lemma>zvídavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1349-3">
   <w.rf>
    <LM>w#w-d1t1349-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1349-4">
   <w.rf>
    <LM>w#w-d1t1349-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1352-1">
   <w.rf>
    <LM>w#w-d1t1352-1</LM>
   </w.rf>
   <form>Jordánsku</form>
   <lemma>Jordánsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m985-d1t1352-2">
   <w.rf>
    <LM>w#w-d1t1352-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1358-1">
   <w.rf>
    <LM>w#w-d1t1358-1</LM>
   </w.rf>
   <form>zajímavý</form>
   <lemma>zajímavý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m985-d1t1362-2">
   <w.rf>
    <LM>w#w-d1t1362-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>2000</form>
   <lemma>2000</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1t1362-4">
   <w.rf>
    <LM>w#w-d1t1362-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m985-d1t1365-1">
   <w.rf>
    <LM>w#w-d1t1365-1</LM>
   </w.rf>
   <form>starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m985-d1t1365-2">
   <w.rf>
    <LM>w#w-d1t1365-2</LM>
   </w.rf>
   <form>chrám</form>
   <lemma>chrám</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m985-d1t1365-3">
   <w.rf>
    <LM>w#w-d1t1365-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1365-5">
   <w.rf>
    <LM>w#w-d1t1365-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1365-6">
   <w.rf>
    <LM>w#w-d1t1365-6</LM>
   </w.rf>
   <form>údolí</form>
   <lemma>údolí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m985-d-id95326">
   <w.rf>
    <LM>w#w-d-id95326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1247-x9">
  <m id="m985-d1t1373-4">
   <w.rf>
    <LM>w#w-d1t1373-4</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m985-d1t1373-7">
   <w.rf>
    <LM>w#w-d1t1373-7</LM>
   </w.rf>
   <form>Rudé</form>
   <lemma>rudý_;o</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m985-d1t1373-8">
   <w.rf>
    <LM>w#w-d1t1373-8</LM>
   </w.rf>
   <form>město</form>
   <lemma>město</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m985-d1e1247-x9-2429">
   <w.rf>
    <LM>w#w-d1e1247-x9-2429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-2430">
  <m id="m985-d1t1380-2">
   <w.rf>
    <LM>w#w-d1t1380-2</LM>
   </w.rf>
   <form>Teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1380-4">
   <w.rf>
    <LM>w#w-d1t1380-4</LM>
   </w.rf>
   <form>předloni</form>
   <lemma>předloni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1380-1">
   <w.rf>
    <LM>w#w-d1t1380-1</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1380-5">
   <w.rf>
    <LM>w#w-d1t1380-5</LM>
   </w.rf>
   <form>otevřeny</form>
   <lemma>otevřít</lemma>
   <tag>VsTP----X-APP--</tag>
  </m>
  <m id="m985-d1t1380-6">
   <w.rf>
    <LM>w#w-d1t1380-6</LM>
   </w.rf>
   <form>hranice</form>
   <lemma>hranice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m985-d1t1380-7">
   <w.rf>
    <LM>w#w-d1t1380-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1380-8">
   <w.rf>
    <LM>w#w-d1t1380-8</LM>
   </w.rf>
   <form>Izraele</form>
   <lemma>Izrael_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m985-d1t1380-9">
   <w.rf>
    <LM>w#w-d1t1380-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1382-2">
   <w.rf>
    <LM>w#w-d1t1382-2</LM>
   </w.rf>
   <form>Jordánska</form>
   <lemma>Jordánsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m985-d-id95724">
   <w.rf>
    <LM>w#w-d-id95724</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1382-4">
   <w.rf>
    <LM>w#w-d1t1382-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1382-5">
   <w.rf>
    <LM>w#w-d1t1382-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1382-6">
   <w.rf>
    <LM>w#w-d1t1382-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m985-d1t1382-7">
   <w.rf>
    <LM>w#w-d1t1382-7</LM>
   </w.rf>
   <form>využila</form>
   <lemma>využít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m985-d1t1382-8">
   <w.rf>
    <LM>w#w-d1t1382-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1382-9">
   <w.rf>
    <LM>w#w-d1t1382-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d1t1382-10">
   <w.rf>
    <LM>w#w-d1t1382-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1384-1">
   <w.rf>
    <LM>w#w-d1t1384-1</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1384-2">
   <w.rf>
    <LM>w#w-d1t1384-2</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m985-2430-2450">
   <w.rf>
    <LM>w#w-2430-2450</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-2451">
  <m id="m985-d1t1388-5">
   <w.rf>
    <LM>w#w-d1t1388-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1388-6">
   <w.rf>
    <LM>w#w-d1t1388-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1388-9">
   <w.rf>
    <LM>w#w-d1t1388-9</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m985-d1t1388-10">
   <w.rf>
    <LM>w#w-d1t1388-10</LM>
   </w.rf>
   <form>hedvábná</form>
   <lemma>hedvábný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1388-11">
   <w.rf>
    <LM>w#w-d1t1388-11</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-2451-1863">
   <w.rf>
    <LM>w#w-2451-1863</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1388-12">
   <w.rf>
    <LM>w#w-d1t1388-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1388-13">
   <w.rf>
    <LM>w#w-d1t1388-13</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1388-14">
   <w.rf>
    <LM>w#w-d1t1388-14</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d1t1388-15">
   <w.rf>
    <LM>w#w-d1t1388-15</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1388-16">
   <w.rf>
    <LM>w#w-d1t1388-16</LM>
   </w.rf>
   <form>film</form>
   <lemma>film</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m985-d1t1395-1">
   <w.rf>
    <LM>w#w-d1t1395-1</LM>
   </w.rf>
   <form>Lawrence</form>
   <lemma>Lawrence-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1t1395-2">
   <w.rf>
    <LM>w#w-d1t1395-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1395-3">
   <w.rf>
    <LM>w#w-d1t1395-3</LM>
   </w.rf>
   <form>Arábie</form>
   <lemma>Arábie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-2451-2524">
   <w.rf>
    <LM>w#w-2451-2524</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1395-5">
   <w.rf>
    <LM>w#w-d1t1395-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m985-d1t1395-6">
   <w.rf>
    <LM>w#w-d1t1395-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1395-7">
   <w.rf>
    <LM>w#w-d1t1395-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m985-d1t1395-8">
   <w.rf>
    <LM>w#w-d1t1395-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1395-9">
   <w.rf>
    <LM>w#w-d1t1395-9</LM>
   </w.rf>
   <form>filmovalo</form>
   <lemma>filmovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d-id96353">
   <w.rf>
    <LM>w#w-d-id96353</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1400-x2">
  <m id="m985-d1t1403-3">
   <w.rf>
    <LM>w#w-d1t1403-3</LM>
   </w.rf>
   <form>Přeju</form>
   <lemma>přát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1403-2">
   <w.rf>
    <LM>w#w-d1t1403-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m985-d-id96476">
   <w.rf>
    <LM>w#w-d-id96476</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1403-5">
   <w.rf>
    <LM>w#w-d1t1403-5</LM>
   </w.rf>
   <form>abyste</form>
   <lemma>aby</lemma>
   <tag>J,-----------e-</tag>
  </m>
  <m id="m985-d1t1405-2">
   <w.rf>
    <LM>w#w-d1t1405-2</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1405-3">
   <w.rf>
    <LM>w#w-d1t1405-3</LM>
   </w.rf>
   <form>absolvovat</form>
   <lemma>absolvovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m985-d1t1403-6">
   <w.rf>
    <LM>w#w-d1t1403-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1403-7">
   <w.rf>
    <LM>w#w-d1t1403-7</LM>
   </w.rf>
   <form>mnoho</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m985-d1t1405-1">
   <w.rf>
    <LM>w#w-d1t1405-1</LM>
   </w.rf>
   <form>cest</form>
   <lemma>cesta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m985-d1t1405-4">
   <w.rf>
    <LM>w#w-d1t1405-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1411-1">
   <w.rf>
    <LM>w#w-d1t1411-1</LM>
   </w.rf>
   <form>abyste</form>
   <lemma>aby</lemma>
   <tag>J,-----------e-</tag>
  </m>
  <m id="m985-d1t1411-5">
   <w.rf>
    <LM>w#w-d1t1411-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1411-2">
   <w.rf>
    <LM>w#w-d1t1411-2</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1411-6">
   <w.rf>
    <LM>w#w-d1t1411-6</LM>
   </w.rf>
   <form>živa</form>
   <lemma>živý</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m985-d1t1411-7">
   <w.rf>
    <LM>w#w-d1t1411-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1411-8">
   <w.rf>
    <LM>w#w-d1t1411-8</LM>
   </w.rf>
   <form>zdráva</form>
   <lemma>zdravý</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m985-d1t1411-9">
   <w.rf>
    <LM>w#w-d1t1411-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1e1400-x2-2626">
   <w.rf>
    <LM>w#w-d1e1400-x2-2626</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1411-10">
   <w.rf>
    <LM>w#w-d1t1411-10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1413-1">
   <w.rf>
    <LM>w#w-d1t1413-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d1t1413-2">
   <w.rf>
    <LM>w#w-d1t1413-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d-id96837">
   <w.rf>
    <LM>w#w-d-id96837</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1406-x3">
  <m id="m985-d1t1413-6">
   <w.rf>
    <LM>w#w-d1t1413-6</LM>
   </w.rf>
   <form>Zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1413-5">
   <w.rf>
    <LM>w#w-d1t1413-5</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m985-d1t1413-7">
   <w.rf>
    <LM>w#w-d1t1413-7</LM>
   </w.rf>
   <form>děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d-id96908">
   <w.rf>
    <LM>w#w-d-id96908</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1406-x5">
  <m id="m985-d1t1417-1">
   <w.rf>
    <LM>w#w-d1t1417-1</LM>
   </w.rf>
   <form>Děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m985-d-id96926">
   <w.rf>
    <LM>w#w-d-id96926</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1426-x2">
  <m id="m985-d1t1429-1">
   <w.rf>
    <LM>w#w-d1t1429-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1429-2">
   <w.rf>
    <LM>w#w-d1t1429-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1429-3">
   <w.rf>
    <LM>w#w-d1t1429-3</LM>
   </w.rf>
   <form>legitimace</form>
   <lemma>legitimace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-d1e1426-x2-1885">
   <w.rf>
    <LM>w#w-d1e1426-x2-1885</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1886">
  <m id="m985-d1t1429-5">
   <w.rf>
    <LM>w#w-d1t1429-5</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1429-6">
   <w.rf>
    <LM>w#w-d1t1429-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1429-7">
   <w.rf>
    <LM>w#w-d1t1429-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1429-8">
   <w.rf>
    <LM>w#w-d1t1429-8</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1429-9">
   <w.rf>
    <LM>w#w-d1t1429-9</LM>
   </w.rf>
   <form>propuštěny</form>
   <lemma>propustit</lemma>
   <tag>VsTP----X-APP--</tag>
  </m>
  <m id="m985-d1t1431-1">
   <w.rf>
    <LM>w#w-d1t1431-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1431-2">
   <w.rf>
    <LM>w#w-d1t1431-2</LM>
   </w.rf>
   <form>britské</form>
   <lemma>britský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m985-d1t1431-3">
   <w.rf>
    <LM>w#w-d1t1431-3</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1e1426-x2-65">
   <w.rf>
    <LM>w#w-d1e1426-x2-65</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1431-4">
   <w.rf>
    <LM>w#w-d1t1431-4</LM>
   </w.rf>
   <form>převzala</form>
   <lemma>převzít_^(př._od_někoho_věc,_zodpovědnost...)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m985-d1t1431-5">
   <w.rf>
    <LM>w#w-d1t1431-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m985-d1t1431-6">
   <w.rf>
    <LM>w#w-d1t1431-6</LM>
   </w.rf>
   <form>československá</form>
   <lemma>československý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1431-7">
   <w.rf>
    <LM>w#w-d1t1431-7</LM>
   </w.rf>
   <form>vojenská</form>
   <lemma>vojenský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1431-8">
   <w.rf>
    <LM>w#w-d1t1431-8</LM>
   </w.rf>
   <form>mise</form>
   <lemma>mise</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-d-id97365">
   <w.rf>
    <LM>w#w-d-id97365</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1431-10">
   <w.rf>
    <LM>w#w-d1t1431-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1431-11">
   <w.rf>
    <LM>w#w-d1t1431-11</LM>
   </w.rf>
   <form>dostávali</form>
   <lemma>dostávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1431-12">
   <w.rf>
    <LM>w#w-d1t1431-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1431-13">
   <w.rf>
    <LM>w#w-d1t1431-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1431-14">
   <w.rf>
    <LM>w#w-d1t1431-14</LM>
   </w.rf>
   <form>tyhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m985-d1t1437-1">
   <w.rf>
    <LM>w#w-d1t1437-1</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m985-d1t1437-2">
   <w.rf>
    <LM>w#w-d1t1437-2</LM>
   </w.rf>
   <form>legitimace</form>
   <lemma>legitimace</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m985-1886-1908">
   <w.rf>
    <LM>w#w-1886-1908</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-1886-1887">
   <w.rf>
    <LM>w#w-1886-1887</LM>
   </w.rf>
   <form>Allied</form>
   <lemma>Allied-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1e1426-x2-70">
   <w.rf>
    <LM>w#w-d1e1426-x2-70</LM>
   </w.rf>
   <form>Forces</form>
   <lemma>Forces-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-1886-1909">
   <w.rf>
    <LM>w#w-1886-1909</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1435-1">
   <w.rf>
    <LM>w#w-d1t1435-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1e1426-x2-75">
   <w.rf>
    <LM>w#w-d1e1426-x2-75</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1435-2">
   <w.rf>
    <LM>w#w-d1t1435-2</LM>
   </w.rf>
   <form>spojenecké</form>
   <lemma>spojenecký</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m985-d1t1435-3">
   <w.rf>
    <LM>w#w-d1t1435-3</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1e1426-x2-76">
   <w.rf>
    <LM>w#w-d1e1426-x2-76</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d-id97515">
   <w.rf>
    <LM>w#w-d-id97515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x2">
  <m id="m985-d1t1451-1">
   <w.rf>
    <LM>w#w-d1t1451-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1451-2">
   <w.rf>
    <LM>w#w-d1t1451-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1451-3">
   <w.rf>
    <LM>w#w-d1t1451-3</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m985-d1t1451-4">
   <w.rf>
    <LM>w#w-d1t1451-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1451-5">
   <w.rf>
    <LM>w#w-d1t1451-5</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m985-d1t1451-6">
   <w.rf>
    <LM>w#w-d1t1451-6</LM>
   </w.rf>
   <form>fotografií</form>
   <lemma>fotografie</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m985-d1t1453-1">
   <w.rf>
    <LM>w#w-d1t1453-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1453-2">
   <w.rf>
    <LM>w#w-d1t1453-2</LM>
   </w.rf>
   <form>vojny</form>
   <lemma>vojna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1t1453-3">
   <w.rf>
    <LM>w#w-d1t1453-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1453-4">
   <w.rf>
    <LM>w#w-d1t1453-4</LM>
   </w.rf>
   <form>Káhiře</form>
   <lemma>Káhira_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-d-id97878">
   <w.rf>
    <LM>w#w-d-id97878</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1e1444-x2-1920">
   <w.rf>
    <LM>w#w-d1e1444-x2-1920</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d1e1444-x2-1921">
   <w.rf>
    <LM>w#w-d1e1444-x2-1921</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1e1444-x2-128">
   <w.rf>
    <LM>w#w-d1e1444-x2-128</LM>
   </w.rf>
   <form>bráno</form>
   <lemma>brát</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m985-d1e1444-x2-1922">
   <w.rf>
    <LM>w#w-d1e1444-x2-1922</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m985-d1t1458-1">
   <w.rf>
    <LM>w#w-d1t1458-1</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1t1458-3">
   <w.rf>
    <LM>w#w-d1t1458-3</LM>
   </w.rf>
   <form>krátce</form>
   <lemma>krátce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1458-4">
   <w.rf>
    <LM>w#w-d1t1458-4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m985-d1t1458-5">
   <w.rf>
    <LM>w#w-d1t1458-5</LM>
   </w.rf>
   <form>demobilizací</form>
   <lemma>demobilizace</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m985-d-id97982">
   <w.rf>
    <LM>w#w-d-id97982</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x3">
  <m id="m985-d1t1464-1">
   <w.rf>
    <LM>w#w-d1t1464-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1464-2">
   <w.rf>
    <LM>w#w-d1t1464-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1464-3">
   <w.rf>
    <LM>w#w-d1t1464-3</LM>
   </w.rf>
   <form>propouštěcí</form>
   <lemma>propouštěcí</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m985-d1t1464-4">
   <w.rf>
    <LM>w#w-d1t1464-4</LM>
   </w.rf>
   <form>list</form>
   <lemma>list</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m985-d1t1464-5">
   <w.rf>
    <LM>w#w-d1t1464-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1464-6">
   <w.rf>
    <LM>w#w-d1t1464-6</LM>
   </w.rf>
   <form>britské</form>
   <lemma>britský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m985-d1t1464-7">
   <w.rf>
    <LM>w#w-d1t1464-7</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1t1468-1">
   <w.rf>
    <LM>w#w-d1t1468-1</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m985-d1t1468-2">
   <w.rf>
    <LM>w#w-d1t1468-2</LM>
   </w.rf>
   <form>důstojníky</form>
   <lemma>důstojník</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m985-d-id98190">
   <w.rf>
    <LM>w#w-d-id98190</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x5">
  <m id="m985-d1t1479-1">
   <w.rf>
    <LM>w#w-d1t1479-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1479-2">
   <w.rf>
    <LM>w#w-d1t1479-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1479-3">
   <w.rf>
    <LM>w#w-d1t1479-3</LM>
   </w.rf>
   <form>záběry</form>
   <lemma>záběr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m985-d1t1479-4">
   <w.rf>
    <LM>w#w-d1t1479-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1479-5">
   <w.rf>
    <LM>w#w-d1t1479-5</LM>
   </w.rf>
   <form>důstojnického</form>
   <lemma>důstojnický</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m985-d1t1479-6">
   <w.rf>
    <LM>w#w-d1t1479-6</LM>
   </w.rf>
   <form>kurzu</form>
   <lemma>kurz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m985-d-id98329">
   <w.rf>
    <LM>w#w-d-id98329</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1479-12">
   <w.rf>
    <LM>w#w-d1t1479-12</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m985-d1t1479-13">
   <w.rf>
    <LM>w#w-d1t1479-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1481-1">
   <w.rf>
    <LM>w#w-d1t1481-1</LM>
   </w.rf>
   <form>absolvovali</form>
   <lemma>absolvovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m985-d1t1488-1">
   <w.rf>
    <LM>w#w-d1t1488-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1488-2">
   <w.rf>
    <LM>w#w-d1t1488-2</LM>
   </w.rf>
   <form>Sarafandu</form>
   <lemma>Sarafand_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m985-d1t1488-4">
   <w.rf>
    <LM>w#w-d1t1488-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1488-5">
   <w.rf>
    <LM>w#w-d1t1488-5</LM>
   </w.rf>
   <form>nynějším</form>
   <lemma>nynější</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m985-d1t1488-6">
   <w.rf>
    <LM>w#w-d1t1488-6</LM>
   </w.rf>
   <form>Izraeli</form>
   <lemma>Izrael_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m985-d-id98564">
   <w.rf>
    <LM>w#w-d-id98564</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x7">
  <m id="m985-d1e1444-x7-1954">
   <w.rf>
    <LM>w#w-d1e1444-x7-1954</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1e1444-x7-1955">
   <w.rf>
    <LM>w#w-d1e1444-x7-1955</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1499-1">
   <w.rf>
    <LM>w#w-d1t1499-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1499-2">
   <w.rf>
    <LM>w#w-d1t1499-2</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-d1t1499-3">
   <w.rf>
    <LM>w#w-d1t1499-3</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1499-4">
   <w.rf>
    <LM>w#w-d1t1499-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1499-5">
   <w.rf>
    <LM>w#w-d1t1499-5</LM>
   </w.rf>
   <form>Středním</form>
   <lemma>střední</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m985-d1t1499-6">
   <w.rf>
    <LM>w#w-d1t1499-6</LM>
   </w.rf>
   <form>východě</form>
   <lemma>východ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m985-d-id98723">
   <w.rf>
    <LM>w#w-d-id98723</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x8">
  <m id="m985-d1t1505-1">
   <w.rf>
    <LM>w#w-d1t1505-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1505-2">
   <w.rf>
    <LM>w#w-d1t1505-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1505-3">
   <w.rf>
    <LM>w#w-d1t1505-3</LM>
   </w.rf>
   <form>Éreat</form>
   <lemma>Éreat_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m985-d1e1444-x8-381">
   <w.rf>
    <LM>w#w-d1e1444-x8-381</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1505-4">
   <w.rf>
    <LM>w#w-d1t1505-4</LM>
   </w.rf>
   <form>jmenovalo</form>
   <lemma>jmenovat</lemma>
   <tag>VpNS----R-AAB--</tag>
  </m>
  <m id="m985-d1t1505-5">
   <w.rf>
    <LM>w#w-d1t1505-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m985-d1t1505-6">
   <w.rf>
    <LM>w#w-d1t1505-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1e1444-x8-1959">
   <w.rf>
    <LM>w#w-d1e1444-x8-1959</LM>
   </w.rf>
   <form>canal</form>
   <lemma>canal-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1e1444-x8-1960">
   <w.rf>
    <LM>w#w-d1e1444-x8-1960</LM>
   </w.rf>
   <form>zone</form>
   <lemma>zone-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1e1444-x8-383">
   <w.rf>
    <LM>w#w-d1e1444-x8-383</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1507-1">
   <w.rf>
    <LM>w#w-d1t1507-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1507-2">
   <w.rf>
    <LM>w#w-d1t1507-2</LM>
   </w.rf>
   <form>znamenalo</form>
   <lemma>znamenat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d1t1507-3">
   <w.rf>
    <LM>w#w-d1t1507-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1e1444-x8-240">
   <w.rf>
    <LM>w#w-d1e1444-x8-240</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1507-4">
   <w.rf>
    <LM>w#w-d1t1507-4</LM>
   </w.rf>
   <form>Suezského</form>
   <lemma>suezský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m985-d1t1507-5">
   <w.rf>
    <LM>w#w-d1t1507-5</LM>
   </w.rf>
   <form>kanálu</form>
   <lemma>kanál</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m985-d1e1444-x8-241">
   <w.rf>
    <LM>w#w-d1e1444-x8-241</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1507-6">
   <w.rf>
    <LM>w#w-d1t1507-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1507-7">
   <w.rf>
    <LM>w#w-d1t1507-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1e1444-x8-243">
   <w.rf>
    <LM>w#w-d1e1444-x8-243</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1507-8">
   <w.rf>
    <LM>w#w-d1t1507-8</LM>
   </w.rf>
   <form>sladkovodní</form>
   <lemma>sladkovodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m985-d1t1507-9">
   <w.rf>
    <LM>w#w-d1t1507-9</LM>
   </w.rf>
   <form>kanál</form>
   <lemma>kanál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m985-d1e1444-x8-244">
   <w.rf>
    <LM>w#w-d1e1444-x8-244</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1e1444-x8-1961">
   <w.rf>
    <LM>w#w-d1e1444-x8-1961</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-1962">
  <m id="m985-d1t1510-2">
   <w.rf>
    <LM>w#w-d1t1510-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-1962-1963">
   <w.rf>
    <LM>w#w-1962-1963</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1514-1">
   <w.rf>
    <LM>w#w-d1t1514-1</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m985-d1t1514-2">
   <w.rf>
    <LM>w#w-d1t1514-2</LM>
   </w.rf>
   <form>Ismailie</form>
   <lemma>Ismailia_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-1962-1964">
   <w.rf>
    <LM>w#w-1962-1964</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1510-3">
   <w.rf>
    <LM>w#w-d1t1510-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m985-d1t1510-4">
   <w.rf>
    <LM>w#w-d1t1510-4</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m985-d1t1510-5">
   <w.rf>
    <LM>w#w-d1t1510-5</LM>
   </w.rf>
   <form>tábor</form>
   <lemma>tábor-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m985-d-id99101">
   <w.rf>
    <LM>w#w-d-id99101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1444-x10">
  <m id="m985-d1t1523-1">
   <w.rf>
    <LM>w#w-d1t1523-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1523-2">
   <w.rf>
    <LM>w#w-d1t1523-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1527-1">
   <w.rf>
    <LM>w#w-d1t1527-1</LM>
   </w.rf>
   <form>dodávali</form>
   <lemma>dodávat_^(*4at)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1527-4">
   <w.rf>
    <LM>w#w-d1t1527-4</LM>
   </w.rf>
   <form>vozy</form>
   <lemma>vůz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m985-d1t1527-5">
   <w.rf>
    <LM>w#w-d1t1527-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m985-d1t1527-6">
   <w.rf>
    <LM>w#w-d1t1527-6</LM>
   </w.rf>
   <form>fronty</form>
   <lemma>fronta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m985-d1e1444-x10-490">
   <w.rf>
    <LM>w#w-d1e1444-x10-490</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1529-1">
   <w.rf>
    <LM>w#w-d1t1529-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1529-2">
   <w.rf>
    <LM>w#w-d1t1529-2</LM>
   </w.rf>
   <form>postupovala</form>
   <lemma>postupovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1529-3">
   <w.rf>
    <LM>w#w-d1t1529-3</LM>
   </w.rf>
   <form>fronta</form>
   <lemma>fronta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-d1t1529-4">
   <w.rf>
    <LM>w#w-d1t1529-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m985-d1t1529-5">
   <w.rf>
    <LM>w#w-d1t1529-5</LM>
   </w.rf>
   <form>západ</form>
   <lemma>západ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m985-d1e1444-x10-1968">
   <w.rf>
    <LM>w#w-d1e1444-x10-1968</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1531-1">
   <w.rf>
    <LM>w#w-d1t1531-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1531-2">
   <w.rf>
    <LM>w#w-d1t1531-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1531-3">
   <w.rf>
    <LM>w#w-d1t1531-3</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m985-d1t1531-6">
   <w.rf>
    <LM>w#w-d1t1531-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1531-7">
   <w.rf>
    <LM>w#w-d1t1531-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m985-d1t1531-4">
   <w.rf>
    <LM>w#w-d1t1531-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1531-5">
   <w.rf>
    <LM>w#w-d1t1531-5</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1533-1">
   <w.rf>
    <LM>w#w-d1t1533-1</LM>
   </w.rf>
   <form>angažovali</form>
   <lemma>angažovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m985-d1t1533-2">
   <w.rf>
    <LM>w#w-d1t1533-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1533-3">
   <w.rf>
    <LM>w#w-d1t1533-3</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m985-d1t1533-5">
   <w.rf>
    <LM>w#w-d1t1533-5</LM>
   </w.rf>
   <form>akcích</form>
   <lemma>akce</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m985-d1e1444-x10-515">
   <w.rf>
    <LM>w#w-d1e1444-x10-515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-503_2">
  <m id="m985-d1t1533-6">
   <w.rf>
    <LM>w#w-d1t1533-6</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m985-d1t1533-7">
   <w.rf>
    <LM>w#w-d1t1533-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m985-d1t1533-8">
   <w.rf>
    <LM>w#w-d1t1533-8</LM>
   </w.rf>
   <form>Benghází</form>
   <lemma>Benghází_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m985-d-id99714">
   <w.rf>
    <LM>w#w-d-id99714</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1538-1">
   <w.rf>
    <LM>w#w-d1t1538-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1538-2">
   <w.rf>
    <LM>w#w-d1t1538-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m985-d1t1540-1">
   <w.rf>
    <LM>w#w-d1t1540-1</LM>
   </w.rf>
   <form>transportovali</form>
   <lemma>transportovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m985-d1t1540-2">
   <w.rf>
    <LM>w#w-d1t1540-2</LM>
   </w.rf>
   <form>jed</form>
   <lemma>jed</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m985-d1t1542-1">
   <w.rf>
    <LM>w#w-d1t1542-1</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1542-2">
   <w.rf>
    <LM>w#w-d1t1542-2</LM>
   </w.rf>
   <form>sedmého</form>
   <lemma>sedmý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m985-d1t1542-3">
   <w.rf>
    <LM>w#w-d1t1542-3</LM>
   </w.rf>
   <form>května</form>
   <lemma>květen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m985-d1t1542-4">
   <w.rf>
    <LM>w#w-d1t1542-4</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1e1444-x10-496">
   <w.rf>
    <LM>w#w-d1e1444-x10-496</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1542-6">
   <w.rf>
    <LM>w#w-d1t1542-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1542-7">
   <w.rf>
    <LM>w#w-d1t1542-7</LM>
   </w.rf>
   <form>skončila</form>
   <lemma>skončit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m985-d1t1542-8">
   <w.rf>
    <LM>w#w-d1t1542-8</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m985-d-id99946">
   <w.rf>
    <LM>w#w-d-id99946</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1544-x2">
  <m id="m985-d1t1547-1">
   <w.rf>
    <LM>w#w-d1t1547-1</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d-id99995">
   <w.rf>
    <LM>w#w-d-id99995</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1548-x2">
  <m id="m985-d1t1555-1">
   <w.rf>
    <LM>w#w-d1t1555-1</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1e1548-x2-1978">
   <w.rf>
    <LM>w#w-d1e1548-x2-1978</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1555-2">
   <w.rf>
    <LM>w#w-d1t1555-2</LM>
   </w.rf>
   <form>Africa</form>
   <lemma>Africa-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1t1555-3">
   <w.rf>
    <LM>w#w-d1t1555-3</LM>
   </w.rf>
   <form>Star</form>
   <lemma>Star-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d-id100147">
   <w.rf>
    <LM>w#w-d-id100147</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1557-1">
   <w.rf>
    <LM>w#w-d1t1557-1</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1557-2">
   <w.rf>
    <LM>w#w-d1t1557-2</LM>
   </w.rf>
   <form>Defence</form>
   <lemma>Defence-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1t1557-3">
   <w.rf>
    <LM>w#w-d1t1557-3</LM>
   </w.rf>
   <form>Medal</form>
   <lemma>Medal-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m985-d1t1559-1">
   <w.rf>
    <LM>w#w-d1t1559-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1559-2">
   <w.rf>
    <LM>w#w-d1t1559-2</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m985-d1t1559-3">
   <w.rf>
    <LM>w#w-d1t1559-3</LM>
   </w.rf>
   <form>vpravo</form>
   <lemma>vpravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m985-d1t1559-4">
   <w.rf>
    <LM>w#w-d1t1559-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1564-1">
   <w.rf>
    <LM>w#w-d1t1564-1</LM>
   </w.rf>
   <form>1939</form>
   <lemma>1939</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1e1548-x2-1980">
   <w.rf>
    <LM>w#w-d1e1548-x2-1980</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1564-3">
   <w.rf>
    <LM>w#w-d1t1564-3</LM>
   </w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1e1548-x2-1979">
   <w.rf>
    <LM>w#w-d1e1548-x2-1979</LM>
   </w.rf>
   <form>Star</form>
   <lemma>star-1</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m985-d-id100387">
   <w.rf>
    <LM>w#w-d-id100387</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1573-x2">
  <m id="m985-d1t1576-1">
   <w.rf>
    <LM>w#w-d1t1576-1</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m985-d-id100511">
   <w.rf>
    <LM>w#w-d-id100511</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1577-x2">
  <m id="m985-d1t1582-2">
   <w.rf>
    <LM>w#w-d1t1582-2</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m985-d-id100583">
   <w.rf>
    <LM>w#w-d-id100583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1583-x2">
  <m id="m985-d1t1590-1">
   <w.rf>
    <LM>w#w-d1t1590-1</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m985-d1t1590-2">
   <w.rf>
    <LM>w#w-d1t1590-2</LM>
   </w.rf>
   <form>vyznamenání</form>
   <lemma>vyznamenání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m985-d1t1592-1">
   <w.rf>
    <LM>w#w-d1t1592-1</LM>
   </w.rf>
   <form>Československé</form>
   <lemma>československý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m985-d1t1592-2">
   <w.rf>
    <LM>w#w-d1t1592-2</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m985-d1t1592-3">
   <w.rf>
    <LM>w#w-d1t1592-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d1t1592-4">
   <w.rf>
    <LM>w#w-d1t1592-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m985-d1t1592-5">
   <w.rf>
    <LM>w#w-d1t1592-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m985-d1t1592-6">
   <w.rf>
    <LM>w#w-d1t1592-6</LM>
   </w.rf>
   <form>1947</form>
   <lemma>1947</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1e1583-x2-752">
   <w.rf>
    <LM>w#w-d1e1583-x2-752</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-753">
  <m id="m985-d1t1592-8">
   <w.rf>
    <LM>w#w-d1t1592-8</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m985-d1t1592-9">
   <w.rf>
    <LM>w#w-d1t1592-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m985-d1t1592-10">
   <w.rf>
    <LM>w#w-d1t1592-10</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m985-d-id100894">
   <w.rf>
    <LM>w#w-d-id100894</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-d1e1604-x2">
  <m id="m985-d1t1609-1">
   <w.rf>
    <LM>w#w-d1t1609-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m985-d1t1609-2">
   <w.rf>
    <LM>w#w-d1t1609-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m985-d1t1609-3">
   <w.rf>
    <LM>w#w-d1t1609-3</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1t1609-4">
   <w.rf>
    <LM>w#w-d1t1609-4</LM>
   </w.rf>
   <form>Míša</form>
   <lemma>Míša-1_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m985-d1e1604-x2-802">
   <w.rf>
    <LM>w#w-d1e1604-x2-802</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m985-13808_05-803">
  <m id="m985-d1t1611-1">
   <w.rf>
    <LM>w#w-d1t1611-1</LM>
   </w.rf>
   <form>Zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m985-d-id101146">
   <w.rf>
    <LM>w#w-d-id101146</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m985-d1t1611-3">
   <w.rf>
    <LM>w#w-d1t1611-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m985-d1t1611-4">
   <w.rf>
    <LM>w#w-d1t1611-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m985-d1t1611-5">
   <w.rf>
    <LM>w#w-d1t1611-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m985-d1t1611-6">
   <w.rf>
    <LM>w#w-d1t1611-6</LM>
   </w.rf>
   <form>37</form>
   <lemma>37</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m985-d1t1611-8">
   <w.rf>
    <LM>w#w-d1t1611-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m985-d-id101234">
   <w.rf>
    <LM>w#w-d-id101234</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
