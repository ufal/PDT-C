<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_140.06.w.gz" />
  </references>
 </head>
 <s id="m140-73">
  <m id="m140-d1t1101-11">
   <w.rf>
    <LM>w#w-d1t1101-11</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m140-d1t1101-12">
   <w.rf>
    <LM>w#w-d1t1101-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1101-13">
   <w.rf>
    <LM>w#w-d1t1101-13</LM>
   </w.rf>
   <form>zaměstnanci</form>
   <lemma>zaměstnanec</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m140-d1t1101-14">
   <w.rf>
    <LM>w#w-d1t1101-14</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1101-15">
   <w.rf>
    <LM>w#w-d1t1101-15</LM>
   </w.rf>
   <form>využívané</form>
   <lemma>využívaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m140-d-m-d1e1070-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1070-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1102-x2">
  <m id="m140-d1t1105-1">
   <w.rf>
    <LM>w#w-d1t1105-1</LM>
   </w.rf>
   <form>Lyžujete</form>
   <lemma>lyžovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t1105-2">
   <w.rf>
    <LM>w#w-d1t1105-2</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m140-d-id99656-punct">
   <w.rf>
    <LM>w#w-d-id99656-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1106-x2">
  <m id="m140-d1t1111-1">
   <w.rf>
    <LM>w#w-d1t1111-1</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1e1106-x2-88">
   <w.rf>
    <LM>w#w-d1e1106-x2-88</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-89">
  <m id="m140-d1t1111-2">
   <w.rf>
    <LM>w#w-d1t1111-2</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1111-3">
   <w.rf>
    <LM>w#w-d1t1111-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1115-3">
   <w.rf>
    <LM>w#w-d1t1115-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1113-1">
   <w.rf>
    <LM>w#w-d1t1113-1</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m140-89-90">
   <w.rf>
    <LM>w#w-89-90</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1113-2">
   <w.rf>
    <LM>w#w-d1t1113-2</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m140-d1t1113-3">
   <w.rf>
    <LM>w#w-d1t1113-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m140-d1t1115-1">
   <w.rf>
    <LM>w#w-d1t1115-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1115-2">
   <w.rf>
    <LM>w#w-d1t1115-2</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m140-d1t1115-4">
   <w.rf>
    <LM>w#w-d1t1115-4</LM>
   </w.rf>
   <form>nestoupl</form>
   <lemma>stoupnout</lemma>
   <tag>VpYS----R-NAP-1</tag>
  </m>
  <m id="m140-89-91">
   <w.rf>
    <LM>w#w-89-91</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-93">
  <m id="m140-d1t1115-7">
   <w.rf>
    <LM>w#w-d1t1115-7</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-93-96">
   <w.rf>
    <LM>w#w-93-96</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1115-8">
   <w.rf>
    <LM>w#w-d1t1115-8</LM>
   </w.rf>
   <form>rády</form>
   <lemma>rád-1</lemma>
   <tag>ACTP------A----</tag>
  </m>
  <m id="m140-93-94">
   <w.rf>
    <LM>w#w-93-94</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-95">
  <m id="m140-d1t1115-12">
   <w.rf>
    <LM>w#w-d1t1115-12</LM>
   </w.rf>
   <form>Naučily</form>
   <lemma>naučit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m140-d1t1115-11">
   <w.rf>
    <LM>w#w-d1t1115-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-95-97">
   <w.rf>
    <LM>w#w-95-97</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-98">
  <m id="m140-d1t1115-16">
   <w.rf>
    <LM>w#w-d1t1115-16</LM>
   </w.rf>
   <form>Jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1115-17">
   <w.rf>
    <LM>w#w-d1t1115-17</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1115-18">
   <w.rf>
    <LM>w#w-d1t1115-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1115-20">
   <w.rf>
    <LM>w#w-d1t1115-20</LM>
   </w.rf>
   <form>Rakouska</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m140-d-id100175-punct">
   <w.rf>
    <LM>w#w-d-id100175-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1115-23">
   <w.rf>
    <LM>w#w-d1t1115-23</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1115-25">
   <w.rf>
    <LM>w#w-d1t1115-25</LM>
   </w.rf>
   <form>Francie</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m140-98-99">
   <w.rf>
    <LM>w#w-98-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-100">
  <m id="m140-d1t1117-3">
   <w.rf>
    <LM>w#w-d1t1117-3</LM>
   </w.rf>
   <form>Lyžování</form>
   <lemma>lyžování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m140-d1t1117-2">
   <w.rf>
    <LM>w#w-d1t1117-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m140-d1t1117-1">
   <w.rf>
    <LM>w#w-d1t1117-1</LM>
   </w.rf>
   <form>baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-100-101">
   <w.rf>
    <LM>w#w-100-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-103">
  <m id="m140-d1t1126-4">
   <w.rf>
    <LM>w#w-d1t1126-4</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1126-3">
   <w.rf>
    <LM>w#w-d1t1126-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1126-1">
   <w.rf>
    <LM>w#w-d1t1126-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1126-2">
   <w.rf>
    <LM>w#w-d1t1126-2</LM>
   </w.rf>
   <form>závodil</form>
   <lemma>závodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t1126-6">
   <w.rf>
    <LM>w#w-d1t1126-6</LM>
   </w.rf>
   <form>Sokolovský</form>
   <lemma>sokolovský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m140-d1t1126-7">
   <w.rf>
    <LM>w#w-d1t1126-7</LM>
   </w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d1t1126-9">
   <w.rf>
    <LM>w#w-d1t1126-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1126-10">
   <w.rf>
    <LM>w#w-d1t1126-10</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m140-103-104">
   <w.rf>
    <LM>w#w-103-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-105">
  <m id="m140-d1t1126-12">
   <w.rf>
    <LM>w#w-d1t1126-12</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1126-14">
   <w.rf>
    <LM>w#w-d1t1126-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1126-18">
   <w.rf>
    <LM>w#w-d1t1126-18</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m140-d1t1126-19">
   <w.rf>
    <LM>w#w-d1t1126-19</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t1126-15">
   <w.rf>
    <LM>w#w-d1t1126-15</LM>
   </w.rf>
   <form>vyhráli</form>
   <lemma>vyhrát</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m140-d1t1126-16">
   <w.rf>
    <LM>w#w-d1t1126-16</LM>
   </w.rf>
   <form>okresní</form>
   <lemma>okresní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m140-d1t1126-17">
   <w.rf>
    <LM>w#w-d1t1126-17</LM>
   </w.rf>
   <form>přebor</form>
   <lemma>přebor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-105-106">
   <w.rf>
    <LM>w#w-105-106</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-107">
  <m id="m140-d1t1128-3">
   <w.rf>
    <LM>w#w-d1t1128-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1128-4">
   <w.rf>
    <LM>w#w-d1t1128-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1128-5">
   <w.rf>
    <LM>w#w-d1t1128-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1128-6">
   <w.rf>
    <LM>w#w-d1t1128-6</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m140-d1t1128-2">
   <w.rf>
    <LM>w#w-d1t1128-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1128-7">
   <w.rf>
    <LM>w#w-d1t1128-7</LM>
   </w.rf>
   <form>dávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-107-108">
   <w.rf>
    <LM>w#w-107-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-109">
  <m id="m140-d1t1128-9">
   <w.rf>
    <LM>w#w-d1t1128-9</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1128-10">
   <w.rf>
    <LM>w#w-d1t1128-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1128-11">
   <w.rf>
    <LM>w#w-d1t1128-11</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m140-d1t1128-12">
   <w.rf>
    <LM>w#w-d1t1128-12</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d-m-d1e1106-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1106-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1129-x2">
  <m id="m140-d1t1132-1">
   <w.rf>
    <LM>w#w-d1t1132-1</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t1132-2">
   <w.rf>
    <LM>w#w-d1t1132-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1132-3">
   <w.rf>
    <LM>w#w-d1t1132-3</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m140-d1t1132-4">
   <w.rf>
    <LM>w#w-d1t1132-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1132-5">
   <w.rf>
    <LM>w#w-d1t1132-5</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d-id100932-punct">
   <w.rf>
    <LM>w#w-d-id100932-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1133-x2">
  <m id="m140-d1t1136-1">
   <w.rf>
    <LM>w#w-d1t1136-1</LM>
   </w.rf>
   <form>Nejezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m140-d1t1136-2">
   <w.rf>
    <LM>w#w-d1t1136-2</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1e1133-x2-127">
   <w.rf>
    <LM>w#w-d1e1133-x2-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-128">
  <m id="m140-d1t1136-4">
   <w.rf>
    <LM>w#w-d1t1136-4</LM>
   </w.rf>
   <form>Jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1136-5">
   <w.rf>
    <LM>w#w-d1t1136-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-128-129">
   <w.rf>
    <LM>w#w-128-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-130">
  <m id="m140-d1t1140-1">
   <w.rf>
    <LM>w#w-d1t1140-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1140-2">
   <w.rf>
    <LM>w#w-d1t1140-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m140-d1t1140-3">
   <w.rf>
    <LM>w#w-d1t1140-3</LM>
   </w.rf>
   <form>75</form>
   <lemma>75</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m140-130-131">
   <w.rf>
    <LM>w#w-130-131</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-132">
  <m id="m140-d1t1140-7">
   <w.rf>
    <LM>w#w-d1t1140-7</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m140-d1t1140-8">
   <w.rf>
    <LM>w#w-d1t1140-8</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m140-d1t1140-9">
   <w.rf>
    <LM>w#w-d1t1140-9</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1140-10">
   <w.rf>
    <LM>w#w-d1t1140-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1140-11">
   <w.rf>
    <LM>w#w-d1t1140-11</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m140-d1t1140-12">
   <w.rf>
    <LM>w#w-d1t1140-12</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-132-242">
   <w.rf>
    <LM>w#w-132-242</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1149-x2">
  <m id="m140-d1t1152-2">
   <w.rf>
    <LM>w#w-d1t1152-2</LM>
   </w.rf>
   <form>Vypadáte</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t1152-1">
   <w.rf>
    <LM>w#w-d1t1152-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1152-3">
   <w.rf>
    <LM>w#w-d1t1152-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d-m-d1e1149-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1149-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1153-x2">
  <m id="m140-d1t1162-1">
   <w.rf>
    <LM>w#w-d1t1162-1</LM>
   </w.rf>
   <form>Snažím</form>
   <lemma>snažit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1162-2">
   <w.rf>
    <LM>w#w-d1t1162-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1e1153-x2-140">
   <w.rf>
    <LM>w#w-d1e1153-x2-140</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-142">
  <m id="m140-d1t1167-1">
   <w.rf>
    <LM>w#w-d1t1167-1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1167-2">
   <w.rf>
    <LM>w#w-d1t1167-2</LM>
   </w.rf>
   <form>stále</form>
   <lemma>stále_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t1167-3">
   <w.rf>
    <LM>w#w-d1t1167-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1167-4">
   <w.rf>
    <LM>w#w-d1t1167-4</LM>
   </w.rf>
   <form>pohybu</form>
   <lemma>pohyb</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m140-142-143">
   <w.rf>
    <LM>w#w-142-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-145">
  <m id="m140-145-146">
   <w.rf>
    <LM>w#w-145-146</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1167-6">
   <w.rf>
    <LM>w#w-d1t1167-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1167-7">
   <w.rf>
    <LM>w#w-d1t1167-7</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m140-145-148">
   <w.rf>
    <LM>w#w-145-148</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-145-149">
   <w.rf>
    <LM>w#w-145-149</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1167-8">
   <w.rf>
    <LM>w#w-d1t1167-8</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m140-d1t1167-9">
   <w.rf>
    <LM>w#w-d1t1167-9</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1167-10">
   <w.rf>
    <LM>w#w-d1t1167-10</LM>
   </w.rf>
   <form>žádný</form>
   <lemma>žádný</lemma>
   <tag>PWIS4----------</tag>
  </m>
  <m id="m140-d1t1167-11">
   <w.rf>
    <LM>w#w-d1t1167-11</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-145-150">
   <w.rf>
    <LM>w#w-145-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-151">
  <m id="m140-d1t1169-1">
   <w.rf>
    <LM>w#w-d1t1169-1</LM>
   </w.rf>
   <form>Něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m140-d1t1169-2">
   <w.rf>
    <LM>w#w-d1t1169-2</LM>
   </w.rf>
   <form>zaberou</form>
   <lemma>zabrat_^([zabavit]_něco_někomu)</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m140-d1t1169-3">
   <w.rf>
    <LM>w#w-d1t1169-3</LM>
   </w.rf>
   <form>ryby</form>
   <lemma>ryba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-d-id101770-punct">
   <w.rf>
    <LM>w#w-d-id101770-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1169-5">
   <w.rf>
    <LM>w#w-d1t1169-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m140-d1t1169-6">
   <w.rf>
    <LM>w#w-d1t1169-6</LM>
   </w.rf>
   <form>houby</form>
   <lemma>houba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-d1t1169-7">
   <w.rf>
    <LM>w#w-d1t1169-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1169-8">
   <w.rf>
    <LM>w#w-d1t1169-8</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t1169-10">
   <w.rf>
    <LM>w#w-d1t1169-10</LM>
   </w.rf>
   <form>zahrádka</form>
   <lemma>zahrádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t1169-11">
   <w.rf>
    <LM>w#w-d1t1169-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1169-12">
   <w.rf>
    <LM>w#w-d1t1169-12</LM>
   </w.rf>
   <form>chata</form>
   <lemma>chata</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-151-152">
   <w.rf>
    <LM>w#w-151-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-153">
  <m id="m140-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>Pomáhám</form>
   <lemma>pomáhat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1171-2">
   <w.rf>
    <LM>w#w-d1t1171-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1171-3">
   <w.rf>
    <LM>w#w-d1t1171-3</LM>
   </w.rf>
   <form>synovi</form>
   <lemma>syn</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m140-d1t1171-4">
   <w.rf>
    <LM>w#w-d1t1171-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1171-5">
   <w.rf>
    <LM>w#w-d1t1171-5</LM>
   </w.rf>
   <form>chalupě</form>
   <lemma>chalupa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t1171-6">
   <w.rf>
    <LM>w#w-d1t1171-6</LM>
   </w.rf>
   <form>rekonstruovat</form>
   <lemma>rekonstruovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m140-d-id102014-punct">
   <w.rf>
    <LM>w#w-d-id102014-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1171-8">
   <w.rf>
    <LM>w#w-d1t1171-8</LM>
   </w.rf>
   <form>budovat</form>
   <lemma>budovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m140-d1t1171-9">
   <w.rf>
    <LM>w#w-d1t1171-9</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d-m-d1e1153-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1153-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1172-x2">
  <m id="m140-d1t1175-1">
   <w.rf>
    <LM>w#w-d1t1175-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m140-d1t1175-2">
   <w.rf>
    <LM>w#w-d1t1175-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1175-3">
   <w.rf>
    <LM>w#w-d1t1175-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m140-d1t1175-5">
   <w.rf>
    <LM>w#w-d1t1175-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d-id102184-punct">
   <w.rf>
    <LM>w#w-d-id102184-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1176-x2">
  <m id="m140-d1t1183-1">
   <w.rf>
    <LM>w#w-d1t1183-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1183-2">
   <w.rf>
    <LM>w#w-d1t1183-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1183-3">
   <w.rf>
    <LM>w#w-d1t1183-3</LM>
   </w.rf>
   <form>rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1183-4">
   <w.rf>
    <LM>w#w-d1t1183-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t1183-5">
   <w.rf>
    <LM>w#w-d1t1183-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1183-7">
   <w.rf>
    <LM>w#w-d1t1183-7</LM>
   </w.rf>
   <form>Vánoc</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m140-d1t1183-9">
   <w.rf>
    <LM>w#w-d1t1183-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1183-11">
   <w.rf>
    <LM>w#w-d1t1183-11</LM>
   </w.rf>
   <form>Hronova</form>
   <lemma>Hronov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-d-id102422-punct">
   <w.rf>
    <LM>w#w-d-id102422-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1183-14">
   <w.rf>
    <LM>w#w-d1t1183-14</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1183-15">
   <w.rf>
    <LM>w#w-d1t1183-15</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1183-16">
   <w.rf>
    <LM>w#w-d1t1183-16</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-166-167">
   <w.rf>
    <LM>w#w-166-167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-168">
  <m id="m140-d1t1185-1">
   <w.rf>
    <LM>w#w-d1t1185-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1185-3">
   <w.rf>
    <LM>w#w-d1t1185-3</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m140-d1t1185-5">
   <w.rf>
    <LM>w#w-d1t1185-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1185-7">
   <w.rf>
    <LM>w#w-d1t1185-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1185-6">
   <w.rf>
    <LM>w#w-d1t1185-6</LM>
   </w.rf>
   <form>obvykle</form>
   <lemma>obvykle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t1185-8">
   <w.rf>
    <LM>w#w-d1t1185-8</LM>
   </w.rf>
   <form>scházeli</form>
   <lemma>scházet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-168-194">
   <w.rf>
    <LM>w#w-168-194</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-195">
  <m id="m140-d1t1185-12">
   <w.rf>
    <LM>w#w-d1t1185-12</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-195-196">
   <w.rf>
    <LM>w#w-195-196</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-195-197">
   <w.rf>
    <LM>w#w-195-197</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d-id102683-punct">
   <w.rf>
    <LM>w#w-d-id102683-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1185-13">
   <w.rf>
    <LM>w#w-d1t1185-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1185-16">
   <w.rf>
    <LM>w#w-d1t1185-16</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t1185-17">
   <w.rf>
    <LM>w#w-d1t1185-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t1185-14">
   <w.rf>
    <LM>w#w-d1t1185-14</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t1185-18">
   <w.rf>
    <LM>w#w-d1t1185-18</LM>
   </w.rf>
   <form>živá</form>
   <lemma>živý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-195-198">
   <w.rf>
    <LM>w#w-195-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-199">
  <m id="m140-d1t1185-21">
   <w.rf>
    <LM>w#w-d1t1185-21</LM>
   </w.rf>
   <form>Příbuzenstvo</form>
   <lemma>příbuzenstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m140-d1t1185-20">
   <w.rf>
    <LM>w#w-d1t1185-20</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1185-24">
   <w.rf>
    <LM>w#w-d1t1185-24</LM>
   </w.rf>
   <form>drželo</form>
   <lemma>držet</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m140-d1t1185-26">
   <w.rf>
    <LM>w#w-d1t1185-26</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d-m-d1e1176-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1176-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1186-x2">
  <m id="m140-d1t1189-1">
   <w.rf>
    <LM>w#w-d1t1189-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1189-2">
   <w.rf>
    <LM>w#w-d1t1189-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1189-3">
   <w.rf>
    <LM>w#w-d1t1189-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1189-4">
   <w.rf>
    <LM>w#w-d1t1189-4</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m140-d1t1189-5">
   <w.rf>
    <LM>w#w-d1t1189-5</LM>
   </w.rf>
   <form>slaví</form>
   <lemma>slavit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1189-7">
   <w.rf>
    <LM>w#w-d1t1189-7</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-d-id103019-punct">
   <w.rf>
    <LM>w#w-d-id103019-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1190-x2">
  <m id="m140-d1t1193-3">
   <w.rf>
    <LM>w#w-d1t1193-3</LM>
   </w.rf>
   <form>Tradičně</form>
   <lemma>tradičně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1e1190-x2-218">
   <w.rf>
    <LM>w#w-d1e1190-x2-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-220">
  <m id="m140-d1t1197-1">
   <w.rf>
    <LM>w#w-d1t1197-1</LM>
   </w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1197-2">
   <w.rf>
    <LM>w#w-d1t1197-2</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m140-d1t1197-4">
   <w.rf>
    <LM>w#w-d1t1197-4</LM>
   </w.rf>
   <form>normální</form>
   <lemma>normální</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1197-3">
   <w.rf>
    <LM>w#w-d1t1197-3</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1197-5">
   <w.rf>
    <LM>w#w-d1t1197-5</LM>
   </w.rf>
   <form>výzdoba</form>
   <lemma>výzdoba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-220-221">
   <w.rf>
    <LM>w#w-220-221</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-226">
  <m id="m140-d1t1201-1">
   <w.rf>
    <LM>w#w-d1t1201-1</LM>
   </w.rf>
   <form>Musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1201-2">
   <w.rf>
    <LM>w#w-d1t1201-2</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m140-d1t1201-5">
   <w.rf>
    <LM>w#w-d1t1201-5</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1201-4">
   <w.rf>
    <LM>w#w-d1t1201-4</LM>
   </w.rf>
   <form>smažený</form>
   <lemma>smažený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m140-d1t1201-3">
   <w.rf>
    <LM>w#w-d1t1201-3</LM>
   </w.rf>
   <form>kapr</form>
   <lemma>kapr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-226-227">
   <w.rf>
    <LM>w#w-226-227</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1201-7">
   <w.rf>
    <LM>w#w-d1t1201-7</LM>
   </w.rf>
   <form>štrúdl</form>
   <lemma>štrúdl_,h</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m140-226-228">
   <w.rf>
    <LM>w#w-226-228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-230">
  <m id="m140-d1t1204-11">
   <w.rf>
    <LM>w#w-d1t1204-11</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1204-12">
   <w.rf>
    <LM>w#w-d1t1204-12</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1t1204-13">
   <w.rf>
    <LM>w#w-d1t1204-13</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t1204-15">
   <w.rf>
    <LM>w#w-d1t1204-15</LM>
   </w.rf>
   <form>Vánoci</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP7-----A---1</tag>
  </m>
  <m id="m140-d1t1204-17">
   <w.rf>
    <LM>w#w-d1t1204-17</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1204-20">
   <w.rf>
    <LM>w#w-d1t1204-20</LM>
   </w.rf>
   <form>pracujeme</form>
   <lemma>pracovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-230-231">
   <w.rf>
    <LM>w#w-230-231</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-232">
  <m id="m140-d1t1206-5">
   <w.rf>
    <LM>w#w-d1t1206-5</LM>
   </w.rf>
   <form>Manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t1206-4">
   <w.rf>
    <LM>w#w-d1t1206-4</LM>
   </w.rf>
   <form>zdědila</form>
   <lemma>zdědit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m140-d1t1206-1">
   <w.rf>
    <LM>w#w-d1t1206-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1206-2">
   <w.rf>
    <LM>w#w-d1t1206-2</LM>
   </w.rf>
   <form>praprababičce</form>
   <lemma>praprababička</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t1208-1">
   <w.rf>
    <LM>w#w-d1t1208-1</LM>
   </w.rf>
   <form>smažící</form>
   <lemma>smažící_^(*3it)</lemma>
   <tag>AGFS4-----A----</tag>
  </m>
  <m id="m140-d1t1208-2">
   <w.rf>
    <LM>w#w-d1t1208-2</LM>
   </w.rf>
   <form>formu</form>
   <lemma>forma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-232-233">
   <w.rf>
    <LM>w#w-232-233</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-234">
  <m id="m140-d1t1210-4">
   <w.rf>
    <LM>w#w-d1t1210-4</LM>
   </w.rf>
   <form>Smažíme</form>
   <lemma>smažit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1210-6">
   <w.rf>
    <LM>w#w-d1t1210-6</LM>
   </w.rf>
   <form>takzvaná</form>
   <lemma>takzvaný</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m140-d1t1210-7">
   <w.rf>
    <LM>w#w-d1t1210-7</LM>
   </w.rf>
   <form>vosí</form>
   <lemma>vosí</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m140-d1t1210-8">
   <w.rf>
    <LM>w#w-d1t1210-8</LM>
   </w.rf>
   <form>hnízda</form>
   <lemma>hnízdo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m140-234-235">
   <w.rf>
    <LM>w#w-234-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-236">
  <m id="m140-d1t1210-10">
   <w.rf>
    <LM>w#w-d1t1210-10</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1210-11">
   <w.rf>
    <LM>w#w-d1t1210-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1210-12">
   <w.rf>
    <LM>w#w-d1t1210-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1210-13">
   <w.rf>
    <LM>w#w-d1t1210-13</LM>
   </w.rf>
   <form>vaflového</form>
   <lemma>vaflový</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m140-d1t1210-14">
   <w.rf>
    <LM>w#w-d1t1210-14</LM>
   </w.rf>
   <form>těsta</form>
   <lemma>těsto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m140-d1t1212-1">
   <w.rf>
    <LM>w#w-d1t1212-1</LM>
   </w.rf>
   <form>usmažená</form>
   <lemma>usmažený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1212-3">
   <w.rf>
    <LM>w#w-d1t1212-3</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1212-4">
   <w.rf>
    <LM>w#w-d1t1212-4</LM>
   </w.rf>
   <form>hvězda</form>
   <lemma>hvězda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-238-239">
   <w.rf>
    <LM>w#w-238-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-240">
  <m id="m140-d1t1217-1">
   <w.rf>
    <LM>w#w-d1t1217-1</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m140-d1t1219-1">
   <w.rf>
    <LM>w#w-d1t1219-1</LM>
   </w.rf>
   <form>vyrábíme</form>
   <lemma>vyrábět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1219-2">
   <w.rf>
    <LM>w#w-d1t1219-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1219-3">
   <w.rf>
    <LM>w#w-d1t1219-3</LM>
   </w.rf>
   <form>dodáváme</form>
   <lemma>dodávat_^(*4at)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1219-4">
   <w.rf>
    <LM>w#w-d1t1219-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1219-5">
   <w.rf>
    <LM>w#w-d1t1219-5</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m140-d1t1219-6">
   <w.rf>
    <LM>w#w-d1t1219-6</LM>
   </w.rf>
   <form>výstavu</form>
   <lemma>výstava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d1t1219-7">
   <w.rf>
    <LM>w#w-d1t1219-7</LM>
   </w.rf>
   <form>Bonsaje</form>
   <lemma>bonsaj-1</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-d-id104196-punct">
   <w.rf>
    <LM>w#w-d-id104196-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1219-9">
   <w.rf>
    <LM>w#w-d1t1219-9</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m140-d1t1219-14">
   <w.rf>
    <LM>w#w-d1t1219-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1219-11">
   <w.rf>
    <LM>w#w-d1t1219-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1219-12">
   <w.rf>
    <LM>w#w-d1t1219-12</LM>
   </w.rf>
   <form>posledním</form>
   <lemma>poslední</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m140-d1t1219-13">
   <w.rf>
    <LM>w#w-d1t1219-13</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1t1219-15">
   <w.rf>
    <LM>w#w-d1t1219-15</LM>
   </w.rf>
   <form>koná</form>
   <lemma>konat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1219-16">
   <w.rf>
    <LM>w#w-d1t1219-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1219-18">
   <w.rf>
    <LM>w#w-d1t1219-18</LM>
   </w.rf>
   <form>Betlémské</form>
   <lemma>betlémský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m140-d1t1219-19">
   <w.rf>
    <LM>w#w-d1t1219-19</LM>
   </w.rf>
   <form>kapli</form>
   <lemma>kaple</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-258-259">
   <w.rf>
    <LM>w#w-258-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-260">
  <m id="m140-d1t1221-5">
   <w.rf>
    <LM>w#w-d1t1221-5</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t1221-6">
   <w.rf>
    <LM>w#w-d1t1221-6</LM>
   </w.rf>
   <form>betlémy</form>
   <lemma>betlém</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m140-d1t1221-3">
   <w.rf>
    <LM>w#w-d1t1221-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m140-d1t1221-4">
   <w.rf>
    <LM>w#w-d1t1221-4</LM>
   </w.rf>
   <form>vystavují</form>
   <lemma>vystavovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1223-1">
   <w.rf>
    <LM>w#w-d1t1223-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1223-2">
   <w.rf>
    <LM>w#w-d1t1223-2</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1223-3">
   <w.rf>
    <LM>w#w-d1t1223-3</LM>
   </w.rf>
   <form>prodávají</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m140-260-267">
   <w.rf>
    <LM>w#w-260-267</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-268">
  <m id="m140-d1t1223-5">
   <w.rf>
    <LM>w#w-d1t1223-5</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t1223-7">
   <w.rf>
    <LM>w#w-d1t1223-7</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1t1223-8">
   <w.rf>
    <LM>w#w-d1t1223-8</LM>
   </w.rf>
   <form>prosince</form>
   <lemma>prosinec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-d1t1227-1">
   <w.rf>
    <LM>w#w-d1t1227-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1227-2">
   <w.rf>
    <LM>w#w-d1t1227-2</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m140-d1t1227-3">
   <w.rf>
    <LM>w#w-d1t1227-3</LM>
   </w.rf>
   <form>vaflí</form>
   <lemma>vafle</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m140-d1t1227-4">
   <w.rf>
    <LM>w#w-d1t1227-4</LM>
   </w.rf>
   <form>usmaží</form>
   <lemma>usmažit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m140-d1t1230-1">
   <w.rf>
    <LM>w#w-d1t1230-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1230-2">
   <w.rf>
    <LM>w#w-d1t1230-2</LM>
   </w.rf>
   <form>800</form>
   <lemma>800</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m140-268-271">
   <w.rf>
    <LM>w#w-268-271</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1230-4">
   <w.rf>
    <LM>w#w-d1t1230-4</LM>
   </w.rf>
   <form>některý</form>
   <lemma>některý</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m140-d1t1230-5">
   <w.rf>
    <LM>w#w-d1t1230-5</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d1t1230-6">
   <w.rf>
    <LM>w#w-d1t1230-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1230-7">
   <w.rf>
    <LM>w#w-d1t1230-7</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>1200</form>
   <lemma>1200</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m140-d1t1230-9">
   <w.rf>
    <LM>w#w-d1t1230-9</LM>
   </w.rf>
   <form>kusů</form>
   <lemma>kus</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m140-268-272">
   <w.rf>
    <LM>w#w-268-272</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-276">
  <m id="m140-d1t1230-14">
   <w.rf>
    <LM>w#w-d1t1230-14</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1230-12">
   <w.rf>
    <LM>w#w-d1t1230-12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t1230-13">
   <w.rf>
    <LM>w#w-d1t1230-13</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m140-d1t1230-15">
   <w.rf>
    <LM>w#w-d1t1230-15</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t1230-16">
   <w.rf>
    <LM>w#w-d1t1230-16</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-276-277">
   <w.rf>
    <LM>w#w-276-277</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-279">
  <m id="m140-d1t1234-3">
   <w.rf>
    <LM>w#w-d1t1234-3</LM>
   </w.rf>
   <form>Prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1234-1">
   <w.rf>
    <LM>w#w-d1t1234-1</LM>
   </w.rf>
   <form>ob</form>
   <lemma>ob-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1234-2">
   <w.rf>
    <LM>w#w-d1t1234-2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d1t1234-4">
   <w.rf>
    <LM>w#w-d1t1234-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t1234-5">
   <w.rf>
    <LM>w#w-d1t1234-5</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m140-d1t1234-6">
   <w.rf>
    <LM>w#w-d1t1234-6</LM>
   </w.rf>
   <form>výrobky</form>
   <lemma>výrobek</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m140-d1t1234-7">
   <w.rf>
    <LM>w#w-d1t1234-7</LM>
   </w.rf>
   <form>jezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1234-8">
   <w.rf>
    <LM>w#w-d1t1234-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1234-9">
   <w.rf>
    <LM>w#w-d1t1234-9</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m140-d1t1234-10">
   <w.rf>
    <LM>w#w-d1t1234-10</LM>
   </w.rf>
   <form>výstavu</form>
   <lemma>výstava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-279-280">
   <w.rf>
    <LM>w#w-279-280</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-282">
  <m id="m140-d1t1234-12">
   <w.rf>
    <LM>w#w-d1t1234-12</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1234-13">
   <w.rf>
    <LM>w#w-d1t1234-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1234-14">
   <w.rf>
    <LM>w#w-d1t1234-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1234-15">
   <w.rf>
    <LM>w#w-d1t1234-15</LM>
   </w.rf>
   <form>dává</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1234-16">
   <w.rf>
    <LM>w#w-d1t1234-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1234-17">
   <w.rf>
    <LM>w#w-d1t1234-17</LM>
   </w.rf>
   <form>prodeje</form>
   <lemma>prodej_^(akt_prodeje_zboží)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-282-283">
   <w.rf>
    <LM>w#w-282-283</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1190-x4">
  <m id="m140-d1t1236-1">
   <w.rf>
    <LM>w#w-d1t1236-1</LM>
   </w.rf>
   <form>Také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1236-2">
   <w.rf>
    <LM>w#w-d1t1236-2</LM>
   </w.rf>
   <form>vyrábím</form>
   <lemma>vyrábět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1236-3">
   <w.rf>
    <LM>w#w-d1t1236-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1236-4">
   <w.rf>
    <LM>w#w-d1t1236-4</LM>
   </w.rf>
   <form>včelího</form>
   <lemma>včelí</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m140-d1t1236-5">
   <w.rf>
    <LM>w#w-d1t1236-5</LM>
   </w.rf>
   <form>vosku</form>
   <lemma>vosk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-d1t1238-1">
   <w.rf>
    <LM>w#w-d1t1238-1</LM>
   </w.rf>
   <form>voskové</form>
   <lemma>voskový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m140-d1t1238-2">
   <w.rf>
    <LM>w#w-d1t1238-2</LM>
   </w.rf>
   <form>svíčky</form>
   <lemma>svíčka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m140-d1e1190-x4-290">
   <w.rf>
    <LM>w#w-d1e1190-x4-290</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-291">
  <m id="m140-d1t1238-5">
   <w.rf>
    <LM>w#w-d1t1238-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1238-6">
   <w.rf>
    <LM>w#w-d1t1238-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1238-7">
   <w.rf>
    <LM>w#w-d1t1238-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t1238-9">
   <w.rf>
    <LM>w#w-d1t1238-9</LM>
   </w.rf>
   <form>mezistěn</form>
   <lemma>mezistěna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m140-291-292">
   <w.rf>
    <LM>w#w-291-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-293">
  <m id="m140-d1t1238-12">
   <w.rf>
    <LM>w#w-d1t1238-12</LM>
   </w.rf>
   <form>Svíčky</form>
   <lemma>svíčka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m140-d1t1238-13">
   <w.rf>
    <LM>w#w-d1t1238-13</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1238-14">
   <w.rf>
    <LM>w#w-d1t1238-14</LM>
   </w.rf>
   <form>voňavé</form>
   <lemma>voňavý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m140-293-294">
   <w.rf>
    <LM>w#w-293-294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-295">
  <m id="m140-d1t1238-16">
   <w.rf>
    <LM>w#w-d1t1238-16</LM>
   </w.rf>
   <form>Zdobíme</form>
   <lemma>zdobit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1238-17">
   <w.rf>
    <LM>w#w-d1t1238-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m140-d1t1238-18">
   <w.rf>
    <LM>w#w-d1t1238-18</LM>
   </w.rf>
   <form>větvičkou</form>
   <lemma>větvička</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m140-d1t1238-19">
   <w.rf>
    <LM>w#w-d1t1238-19</LM>
   </w.rf>
   <form>zeravu</form>
   <lemma>zerav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-297-300">
   <w.rf>
    <LM>w#w-297-300</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t1238-21">
   <w.rf>
    <LM>w#w-d1t1238-21</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t1238-22">
   <w.rf>
    <LM>w#w-d1t1238-22</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t1238-25">
   <w.rf>
    <LM>w#w-d1t1238-25</LM>
   </w.rf>
   <form>ozdobný</form>
   <lemma>ozdobný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m140-d1t1238-24">
   <w.rf>
    <LM>w#w-d1t1238-24</LM>
   </w.rf>
   <form>jehličnan</form>
   <lemma>jehličnan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m140-299-301">
   <w.rf>
    <LM>w#w-299-301</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-299-302">
   <w.rf>
    <LM>w#w-299-302</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1240-2">
   <w.rf>
    <LM>w#w-d1t1240-2</LM>
   </w.rf>
   <form>červenou</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m140-d1t1240-1">
   <w.rf>
    <LM>w#w-d1t1240-1</LM>
   </w.rf>
   <form>barevnou</form>
   <lemma>barevný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m140-d1t1240-3">
   <w.rf>
    <LM>w#w-d1t1240-3</LM>
   </w.rf>
   <form>stužku</form>
   <lemma>stužka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-299-303">
   <w.rf>
    <LM>w#w-299-303</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-304">
  <m id="m140-d1t1240-6">
   <w.rf>
    <LM>w#w-d1t1240-6</LM>
   </w.rf>
   <form>Vyrábíme</form>
   <lemma>vyrábět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1240-7">
   <w.rf>
    <LM>w#w-d1t1240-7</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1240-8">
   <w.rf>
    <LM>w#w-d1t1240-8</LM>
   </w.rf>
   <form>mnoho</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m140-d1t1240-10">
   <w.rf>
    <LM>w#w-d1t1240-10</LM>
   </w.rf>
   <form>vánočních</form>
   <lemma>vánoční</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m140-d1t1240-11">
   <w.rf>
    <LM>w#w-d1t1240-11</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m140-304-306">
   <w.rf>
    <LM>w#w-304-306</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-308">
  <m id="m140-d1t1243-1">
   <w.rf>
    <LM>w#w-d1t1243-1</LM>
   </w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t1243-2">
   <w.rf>
    <LM>w#w-d1t1243-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t1243-3">
   <w.rf>
    <LM>w#w-d1t1243-3</LM>
   </w.rf>
   <form>přátele</form>
   <lemma>přítel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m140-308-309">
   <w.rf>
    <LM>w#w-308-309</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-310">
  <m id="m140-d1t1243-9">
   <w.rf>
    <LM>w#w-d1t1243-9</LM>
   </w.rf>
   <form>Bavíme</form>
   <lemma>bavit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t1243-8">
   <w.rf>
    <LM>w#w-d1t1243-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t1243-7">
   <w.rf>
    <LM>w#w-d1t1243-7</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m140-310-311">
   <w.rf>
    <LM>w#w-310-311</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t1243-10">
   <w.rf>
    <LM>w#w-d1t1243-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t1243-14">
   <w.rf>
    <LM>w#w-d1t1243-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m140-d1t1243-12">
   <w.rf>
    <LM>w#w-d1t1243-12</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m140-d1t1243-13">
   <w.rf>
    <LM>w#w-d1t1243-13</LM>
   </w.rf>
   <form>málo</form>
   <lemma>málo-3_^(málo_důsledný)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t1243-15">
   <w.rf>
    <LM>w#w-d1t1243-15</LM>
   </w.rf>
   <form>vyděláme</form>
   <lemma>vydělat_^(kůže;peníze)</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m140-d-m-d1e1190-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1190-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e1244-x2">
  <m id="m140-d1t1247-1">
   <w.rf>
    <LM>w#w-d1t1247-1</LM>
   </w.rf>
   <form>Dodržujete</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t1247-2">
   <w.rf>
    <LM>w#w-d1t1247-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m140-d1t1247-3">
   <w.rf>
    <LM>w#w-d1t1247-3</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m140-d1t1247-4">
   <w.rf>
    <LM>w#w-d1t1247-4</LM>
   </w.rf>
   <form>zvyky</form>
   <lemma>zvyk</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m140-d-id106230-punct">
   <w.rf>
    <LM>w#w-d-id106230-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
