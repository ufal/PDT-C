<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_127.11.w.gz" />
  </references>
 </head>
 <s id="m127-d1e2354-x2">
  <m id="m127-d1t2359-16">
   <w.rf>
    <LM>w#w-d1t2359-16</LM>
   </w.rf>
   <form>Chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2359-17">
   <w.rf>
    <LM>w#w-d1t2359-17</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m127-d1t2359-19">
   <w.rf>
    <LM>w#w-d1t2359-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2359-21">
   <w.rf>
    <LM>w#w-d1t2359-21</LM>
   </w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-d1t2359-22">
   <w.rf>
    <LM>w#w-d1t2359-22</LM>
   </w.rf>
   <form>Zéland</form>
   <lemma>Zéland_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1e2354-x2-76">
   <w.rf>
    <LM>w#w-d1e2354-x2-76</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2359-9">
   <w.rf>
    <LM>w#w-d1t2359-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2359-10">
   <w.rf>
    <LM>w#w-d1t2359-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2359-11">
   <w.rf>
    <LM>w#w-d1t2359-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2359-13">
   <w.rf>
    <LM>w#w-d1t2359-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2359-12">
   <w.rf>
    <LM>w#w-d1t2359-12</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2359-14">
   <w.rf>
    <LM>w#w-d1t2359-14</LM>
   </w.rf>
   <form>nedostaneme</form>
   <lemma>dostat</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m127-d-id186487-punct">
   <w.rf>
    <LM>w#w-d-id186487-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2361-2">
   <w.rf>
    <LM>w#w-d1t2361-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2361-3">
   <w.rf>
    <LM>w#w-d1t2361-3</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m127-d1t2361-5">
   <w.rf>
    <LM>w#w-d1t2361-5</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2361-6">
   <w.rf>
    <LM>w#w-d1t2361-6</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2361-7">
   <w.rf>
    <LM>w#w-d1t2361-7</LM>
   </w.rf>
   <form>vyhrát</form>
   <lemma>vyhrát</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-d1t2361-8">
   <w.rf>
    <LM>w#w-d1t2361-8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m127-d1t2361-9">
   <w.rf>
    <LM>w#w-d1t2361-9</LM>
   </w.rf>
   <form>Sportce</form>
   <lemma>Sportka_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1e2354-x2-77">
   <w.rf>
    <LM>w#w-d1e2354-x2-77</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-62">
  <m id="m127-d1t2363-1">
   <w.rf>
    <LM>w#w-d1t2363-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2363-3">
   <w.rf>
    <LM>w#w-d1t2363-3</LM>
   </w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-d1t2363-4">
   <w.rf>
    <LM>w#w-d1t2363-4</LM>
   </w.rf>
   <form>Zéland</form>
   <lemma>Zéland_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2363-6">
   <w.rf>
    <LM>w#w-d1t2363-6</LM>
   </w.rf>
   <form>nemůžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m127-d1t2363-7">
   <w.rf>
    <LM>w#w-d1t2363-7</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2363-8">
   <w.rf>
    <LM>w#w-d1t2363-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2363-9">
   <w.rf>
    <LM>w#w-d1t2363-9</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m127-d1t2363-10">
   <w.rf>
    <LM>w#w-d1t2363-10</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m127-d-id186953-punct">
   <w.rf>
    <LM>w#w-d-id186953-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2363-12">
   <w.rf>
    <LM>w#w-d1t2363-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2363-14">
   <w.rf>
    <LM>w#w-d1t2363-14</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2363-13">
   <w.rf>
    <LM>w#w-d1t2363-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-62-109">
   <w.rf>
    <LM>w#w-62-109</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2363-16">
   <w.rf>
    <LM>w#w-d1t2363-16</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2363-17">
   <w.rf>
    <LM>w#w-d1t2363-17</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-62-125">
   <w.rf>
    <LM>w#w-62-125</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2363-18">
   <w.rf>
    <LM>w#w-d1t2363-18</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2363-18-sw1">
   <w.rf>
    <LM>w#w-d1t2363-18</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2363-18-sw2">
   <w.rf>
    <LM>w#w-d1t2363-18</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>li</form>
   <lemma>li-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2363-19">
   <w.rf>
    <LM>w#w-d1t2363-19</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m127-d1t2363-20">
   <w.rf>
    <LM>w#w-d1t2363-20</LM>
   </w.rf>
   <form>neděl</form>
   <lemma>neděle</lemma>
   <tag>NNFP2-----A---1</tag>
  </m>
  <m id="m127-62-469">
   <w.rf>
    <LM>w#w-62-469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-470">
  <m id="m127-d1t2365-6">
   <w.rf>
    <LM>w#w-d1t2365-6</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2365-5">
   <w.rf>
    <LM>w#w-d1t2365-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2365-7">
   <w.rf>
    <LM>w#w-d1t2365-7</LM>
   </w.rf>
   <form>nejdál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m127-d-id187212-punct">
   <w.rf>
    <LM>w#w-d-id187212-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2365-9">
   <w.rf>
    <LM>w#w-d1t2365-9</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2365-10">
   <w.rf>
    <LM>w#w-d1t2365-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2365-11">
   <w.rf>
    <LM>w#w-d1t2365-11</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t2365-12">
   <w.rf>
    <LM>w#w-d1t2365-12</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2365-13">
   <w.rf>
    <LM>w#w-d1t2365-13</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-d1t2365-14">
   <w.rf>
    <LM>w#w-d1t2365-14</LM>
   </w.rf>
   <form>dojet</form>
   <lemma>dojet</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-62-127">
   <w.rf>
    <LM>w#w-62-127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2368-1">
   <w.rf>
    <LM>w#w-d1t2368-1</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m127-d1t2368-2">
   <w.rf>
    <LM>w#w-d1t2368-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2368-3">
   <w.rf>
    <LM>w#w-d1t2368-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2368-5">
   <w.rf>
    <LM>w#w-d1t2368-5</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2368-4">
   <w.rf>
    <LM>w#w-d1t2368-4</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m127-d1t2370-1">
   <w.rf>
    <LM>w#w-d1t2370-1</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2370-2">
   <w.rf>
    <LM>w#w-d1t2370-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2370-4">
   <w.rf>
    <LM>w#w-d1t2370-4</LM>
   </w.rf>
   <form>Nový</form>
   <lemma>nový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-d1t2370-5">
   <w.rf>
    <LM>w#w-d1t2370-5</LM>
   </w.rf>
   <form>Zéland</form>
   <lemma>Zéland_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-62-128">
   <w.rf>
    <LM>w#w-62-128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-108">
  <m id="m127-d1t2372-1">
   <w.rf>
    <LM>w#w-d1t2372-1</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m127-108-133">
   <w.rf>
    <LM>w#w-108-133</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2372-2">
   <w.rf>
    <LM>w#w-d1t2372-2</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m127-d1t2372-3">
   <w.rf>
    <LM>w#w-d1t2372-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2372-4">
   <w.rf>
    <LM>w#w-d1t2372-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d-id187597-punct">
   <w.rf>
    <LM>w#w-d-id187597-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2374-2">
   <w.rf>
    <LM>w#w-d1t2374-2</LM>
   </w.rf>
   <form>říkají</form>
   <lemma>říkat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d-id187645-punct">
   <w.rf>
    <LM>w#w-d-id187645-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2374-4">
   <w.rf>
    <LM>w#w-d1t2374-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2374-5">
   <w.rf>
    <LM>w#w-d1t2374-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2374-6">
   <w.rf>
    <LM>w#w-d1t2374-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2374-7">
   <w.rf>
    <LM>w#w-d1t2374-7</LM>
   </w.rf>
   <form>neskutečná</form>
   <lemma>skutečný</lemma>
   <tag>AAFS1----1N----</tag>
  </m>
  <m id="m127-d1t2374-8">
   <w.rf>
    <LM>w#w-d1t2374-8</LM>
   </w.rf>
   <form>nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1t2376-1">
   <w.rf>
    <LM>w#w-d1t2376-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2376-2">
   <w.rf>
    <LM>w#w-d1t2376-2</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2376-3">
   <w.rf>
    <LM>w#w-d1t2376-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2376-4">
   <w.rf>
    <LM>w#w-d1t2376-4</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m127-d1t2376-5">
   <w.rf>
    <LM>w#w-d1t2376-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2376-6">
   <w.rf>
    <LM>w#w-d1t2376-6</LM>
   </w.rf>
   <form>nechce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m127-d1t2376-7">
   <w.rf>
    <LM>w#w-d1t2376-7</LM>
   </w.rf>
   <form>nazpátek</form>
   <lemma>nazpátek</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-108-134">
   <w.rf>
    <LM>w#w-108-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-107">
  <m id="m127-d1t2381-2">
   <w.rf>
    <LM>w#w-d1t2381-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2381-3">
   <w.rf>
    <LM>w#w-d1t2381-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2381-1">
   <w.rf>
    <LM>w#w-d1t2381-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2381-5">
   <w.rf>
    <LM>w#w-d1t2381-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2381-6">
   <w.rf>
    <LM>w#w-d1t2381-6</LM>
   </w.rf>
   <form>oblasti</form>
   <lemma>oblast</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1t2381-7">
   <w.rf>
    <LM>w#w-d1t2381-7</LM>
   </w.rf>
   <form>snů</form>
   <lemma>sen-1</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-107-143">
   <w.rf>
    <LM>w#w-107-143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-142">
  <m id="m127-d1t2383-1">
   <w.rf>
    <LM>w#w-d1t2383-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2383-8">
   <w.rf>
    <LM>w#w-d1t2383-8</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m127-d1t2383-10">
   <w.rf>
    <LM>w#w-d1t2383-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m127-d1t2383-11">
   <w.rf>
    <LM>w#w-d1t2383-11</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2383-12">
   <w.rf>
    <LM>w#w-d1t2383-12</LM>
   </w.rf>
   <form>prohlédnout</form>
   <lemma>prohlédnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-d1t2383-6">
   <w.rf>
    <LM>w#w-d1t2383-6</LM>
   </w.rf>
   <form>Korsiku</form>
   <lemma>Korsika_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d1t2383-13">
   <w.rf>
    <LM>w#w-d1t2383-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2385-1">
   <w.rf>
    <LM>w#w-d1t2385-1</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2385-2">
   <w.rf>
    <LM>w#w-d1t2385-2</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m127-d1t2385-4">
   <w.rf>
    <LM>w#w-d1t2385-4</LM>
   </w.rf>
   <form>najít</form>
   <lemma>najít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m127-d1t2385-5">
   <w.rf>
    <LM>w#w-d1t2385-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m127-d1t2385-7">
   <w.rf>
    <LM>w#w-d1t2385-7</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2385-8">
   <w.rf>
    <LM>w#w-d1t2385-8</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m127-d1t2385-9">
   <w.rf>
    <LM>w#w-d1t2385-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2385-10">
   <w.rf>
    <LM>w#w-d1t2385-10</LM>
   </w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m127-142-482">
   <w.rf>
    <LM>w#w-142-482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-483">
  <m id="m127-d1t2385-12">
   <w.rf>
    <LM>w#w-d1t2385-12</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2385-13">
   <w.rf>
    <LM>w#w-d1t2385-13</LM>
   </w.rf>
   <form>nesmí</form>
   <lemma>smět</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m127-d1t2385-14">
   <w.rf>
    <LM>w#w-d1t2385-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2385-15">
   <w.rf>
    <LM>w#w-d1t2385-15</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2385-16">
   <w.rf>
    <LM>w#w-d1t2385-16</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2385-18">
   <w.rf>
    <LM>w#w-d1t2385-18</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2385-19">
   <w.rf>
    <LM>w#w-d1t2385-19</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2385-20">
   <w.rf>
    <LM>w#w-d1t2385-20</LM>
   </w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m127-d-id188508-punct">
   <w.rf>
    <LM>w#w-d-id188508-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2385-25">
   <w.rf>
    <LM>w#w-d1t2385-25</LM>
   </w.rf>
   <form>nemůžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m127-d1t2385-26">
   <w.rf>
    <LM>w#w-d1t2385-26</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2387-1">
   <w.rf>
    <LM>w#w-d1t2387-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2387-2">
   <w.rf>
    <LM>w#w-d1t2387-2</LM>
   </w.rf>
   <form>kopce</form>
   <lemma>kopec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-d1t2387-3">
   <w.rf>
    <LM>w#w-d1t2387-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2387-4">
   <w.rf>
    <LM>w#w-d1t2387-4</LM>
   </w.rf>
   <form>kopce</form>
   <lemma>kopec</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-142-152">
   <w.rf>
    <LM>w#w-142-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-151">
  <m id="m127-d1t2387-6">
   <w.rf>
    <LM>w#w-d1t2387-6</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2387-8">
   <w.rf>
    <LM>w#w-d1t2387-8</LM>
   </w.rf>
   <form>vybíráme</form>
   <lemma>vybírat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2387-9">
   <w.rf>
    <LM>w#w-d1t2387-9</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2354-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2354-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2388-x2">
  <m id="m127-d1t2391-1">
   <w.rf>
    <LM>w#w-d1t2391-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m127-d1e2388-x2-157">
   <w.rf>
    <LM>w#w-d1e2388-x2-157</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-156">
  <m id="m127-d1t2393-1">
   <w.rf>
    <LM>w#w-d1t2393-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m127-d1t2393-2">
   <w.rf>
    <LM>w#w-d1t2393-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2393-3">
   <w.rf>
    <LM>w#w-d1t2393-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2393-4">
   <w.rf>
    <LM>w#w-d1t2393-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m127-d1t2393-5">
   <w.rf>
    <LM>w#w-d1t2393-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d-id188897-punct">
   <w.rf>
    <LM>w#w-d-id188897-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2394-x2">
  <m id="m127-d1t2401-1">
   <w.rf>
    <LM>w#w-d1t2401-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2401-2">
   <w.rf>
    <LM>w#w-d1t2401-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2405-2">
   <w.rf>
    <LM>w#w-d1t2405-2</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2405-4">
   <w.rf>
    <LM>w#w-d1t2405-4</LM>
   </w.rf>
   <form>Hradce</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m127-d-id189023-punct">
   <w.rf>
    <LM>w#w-d-id189023-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2394-x2-171">
   <w.rf>
    <LM>w#w-d1e2394-x2-171</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2401-11">
   <w.rf>
    <LM>w#w-d1t2401-11</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2401-12">
   <w.rf>
    <LM>w#w-d1t2401-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2401-13">
   <w.rf>
    <LM>w#w-d1t2401-13</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m127-d1t2401-6">
   <w.rf>
    <LM>w#w-d1t2401-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2401-8">
   <w.rf>
    <LM>w#w-d1t2401-8</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m127-d1t2401-9">
   <w.rf>
    <LM>w#w-d1t2401-9</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1e2394-x2-173">
   <w.rf>
    <LM>w#w-d1e2394-x2-173</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d-id189186-punct">
   <w.rf>
    <LM>w#w-d-id189186-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2403-4">
   <w.rf>
    <LM>w#w-d1t2403-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2403-5">
   <w.rf>
    <LM>w#w-d1t2403-5</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m127-d1t2403-7">
   <w.rf>
    <LM>w#w-d1t2403-7</LM>
   </w.rf>
   <form>Hradečáky</form>
   <lemma>Hradečák_;E_,h</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m127-d-id189315-punct">
   <w.rf>
    <LM>w#w-d-id189315-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2403-10">
   <w.rf>
    <LM>w#w-d1t2403-10</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2403-11">
   <w.rf>
    <LM>w#w-d1t2403-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2403-12">
   <w.rf>
    <LM>w#w-d1t2403-12</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m127-d1t2403-13">
   <w.rf>
    <LM>w#w-d1t2403-13</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1e2394-x2-178">
   <w.rf>
    <LM>w#w-d1e2394-x2-178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-177">
  <m id="m127-d1t2405-8">
   <w.rf>
    <LM>w#w-d1t2405-8</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2405-7">
   <w.rf>
    <LM>w#w-d1t2405-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2405-10">
   <w.rf>
    <LM>w#w-d1t2405-10</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m127-d1t2405-11">
   <w.rf>
    <LM>w#w-d1t2405-11</LM>
   </w.rf>
   <form>parky</form>
   <lemma>parka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m127-d1t2405-12">
   <w.rf>
    <LM>w#w-d1t2405-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2405-13">
   <w.rf>
    <LM>w#w-d1t2405-13</LM>
   </w.rf>
   <form>lesoparky</form>
   <lemma>lesopark</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m127-d1t2405-14">
   <w.rf>
    <LM>w#w-d1t2405-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2405-15">
   <w.rf>
    <LM>w#w-d1t2405-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2405-20">
   <w.rf>
    <LM>w#w-d1t2405-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2405-21">
   <w.rf>
    <LM>w#w-d1t2405-21</LM>
   </w.rf>
   <form>udělá</form>
   <lemma>udělat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t2405-22">
   <w.rf>
    <LM>w#w-d1t2405-22</LM>
   </w.rf>
   <form>60</form>
   <lemma>60</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-177-179">
   <w.rf>
    <LM>w#w-177-179</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2405-23">
   <w.rf>
    <LM>w#w-d1t2405-23</LM>
   </w.rf>
   <form>70</form>
   <lemma>70</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-d1t2405-24">
   <w.rf>
    <LM>w#w-d1t2405-24</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-d1t2405-25">
   <w.rf>
    <LM>w#w-d1t2405-25</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2405-26">
   <w.rf>
    <LM>w#w-d1t2405-26</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m127-177-287">
   <w.rf>
    <LM>w#w-177-287</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2405-27">
   <w.rf>
    <LM>w#w-d1t2405-27</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2405-28">
   <w.rf>
    <LM>w#w-d1t2405-28</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2405-29">
   <w.rf>
    <LM>w#w-d1t2405-29</LM>
   </w.rf>
   <form>fikne</form>
   <lemma>fiknout</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-177-181">
   <w.rf>
    <LM>w#w-177-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-180">
  <m id="m127-d1t2410-25">
   <w.rf>
    <LM>w#w-d1t2410-25</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2410-23">
   <w.rf>
    <LM>w#w-d1t2410-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2410-24">
   <w.rf>
    <LM>w#w-d1t2410-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-180-508">
   <w.rf>
    <LM>w#w-180-508</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2410-7">
   <w.rf>
    <LM>w#w-d1t2410-7</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-180-509">
   <w.rf>
    <LM>w#w-180-509</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2410-8">
   <w.rf>
    <LM>w#w-d1t2410-8</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2410-20">
   <w.rf>
    <LM>w#w-d1t2410-20</LM>
   </w.rf>
   <form>loni</form>
   <lemma>loni</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2410-21">
   <w.rf>
    <LM>w#w-d1t2410-21</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2410-22">
   <w.rf>
    <LM>w#w-d1t2410-22</LM>
   </w.rf>
   <form>podzim</form>
   <lemma>podzim</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-180-192">
   <w.rf>
    <LM>w#w-180-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-191">
  <m id="m127-d1t2410-28">
   <w.rf>
    <LM>w#w-d1t2410-28</LM>
   </w.rf>
   <form>Vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m127-d1t2410-26">
   <w.rf>
    <LM>w#w-d1t2410-26</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2410-27">
   <w.rf>
    <LM>w#w-d1t2410-27</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2410-29">
   <w.rf>
    <LM>w#w-d1t2410-29</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2410-32">
   <w.rf>
    <LM>w#w-d1t2410-32</LM>
   </w.rf>
   <form>Jeseníků</form>
   <lemma>Jeseník_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-191-193">
   <w.rf>
    <LM>w#w-191-193</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2410-38">
   <w.rf>
    <LM>w#w-d1t2410-38</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2410-36">
   <w.rf>
    <LM>w#w-d1t2410-36</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2410-37">
   <w.rf>
    <LM>w#w-d1t2410-37</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2412-1">
   <w.rf>
    <LM>w#w-d1t2412-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2412-3">
   <w.rf>
    <LM>w#w-d1t2412-3</LM>
   </w.rf>
   <form>Hradci</form>
   <lemma>Hradec-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-d1t2412-5">
   <w.rf>
    <LM>w#w-d1t2412-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2412-6">
   <w.rf>
    <LM>w#w-d1t2412-6</LM>
   </w.rf>
   <form>kolech</form>
   <lemma>kolo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2394-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2394-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2413-x2">
  <m id="m127-d1t2418-1">
   <w.rf>
    <LM>w#w-d1t2418-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2418-2">
   <w.rf>
    <LM>w#w-d1t2418-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2418-3">
   <w.rf>
    <LM>w#w-d1t2418-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m127-d-m-d1e2413-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2413-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2413-x3">
  <m id="m127-d1t2420-1">
   <w.rf>
    <LM>w#w-d1t2420-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4NS4----------</tag>
  </m>
  <m id="m127-d1t2420-2">
   <w.rf>
    <LM>w#w-d1t2420-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2420-3">
   <w.rf>
    <LM>w#w-d1t2420-3</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m127-d-id190660-punct">
   <w.rf>
    <LM>w#w-d-id190660-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2421-x2">
  <m id="m127-d1t2426-2">
   <w.rf>
    <LM>w#w-d1t2426-2</LM>
   </w.rf>
   <form>Author</form>
   <lemma>Author_;m</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2426-4">
   <w.rf>
    <LM>w#w-d1t2426-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2426-5">
   <w.rf>
    <LM>w#w-d1t2426-5</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1t2426-6">
   <w.rf>
    <LM>w#w-d1t2426-6</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2426-13">
   <w.rf>
    <LM>w#w-d1t2426-13</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m127-d1t2426-14">
   <w.rf>
    <LM>w#w-d1t2426-14</LM>
   </w.rf>
   <form>divnou</form>
   <lemma>divný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m127-d1t2426-15">
   <w.rf>
    <LM>w#w-d1t2426-15</LM>
   </w.rf>
   <form>značku</form>
   <lemma>značka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-id190811-punct">
   <w.rf>
    <LM>w#w-d-id190811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2426-8">
   <w.rf>
    <LM>w#w-d1t2426-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m127-d1t2426-9">
   <w.rf>
    <LM>w#w-d1t2426-9</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m127-d1t2426-10">
   <w.rf>
    <LM>w#w-d1t2426-10</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m127-d1e2421-x2-539">
   <w.rf>
    <LM>w#w-d1e2421-x2-539</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-540">
  <m id="m127-d1t2426-20">
   <w.rf>
    <LM>w#w-d1t2426-20</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2426-19">
   <w.rf>
    <LM>w#w-d1t2426-19</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2426-22">
   <w.rf>
    <LM>w#w-d1t2426-22</LM>
   </w.rf>
   <form>Favorita</form>
   <lemma>Favorit_;m_^(vozidlo)</lemma>
   <tag>NNIS4-----A---1</tag>
  </m>
  <m id="m127-d-id191041-punct">
   <w.rf>
    <LM>w#w-d-id191041-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1e2421-x2-17">
   <w.rf>
    <LM>w#w-d1e2421-x2-17</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2428-1">
   <w.rf>
    <LM>w#w-d1t2428-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2428-2">
   <w.rf>
    <LM>w#w-d1t2428-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2428-3">
   <w.rf>
    <LM>w#w-d1t2428-3</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m127-d1t2428-4">
   <w.rf>
    <LM>w#w-d1t2428-4</LM>
   </w.rf>
   <form>dámské</form>
   <lemma>dámský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m127-d-id191121-punct">
   <w.rf>
    <LM>w#w-d-id191121-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2428-8">
   <w.rf>
    <LM>w#w-d1t2428-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2428-9">
   <w.rf>
    <LM>w#w-d1t2428-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2428-10">
   <w.rf>
    <LM>w#w-d1t2428-10</LM>
   </w.rf>
   <form>koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m127-d1t2428-12">
   <w.rf>
    <LM>w#w-d1t2428-12</LM>
   </w.rf>
   <form>dámské</form>
   <lemma>dámský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m127-d1t2428-11">
   <w.rf>
    <LM>w#w-d1t2428-11</LM>
   </w.rf>
   <form>horské</form>
   <lemma>horský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m127-d1e2421-x2-18">
   <w.rf>
    <LM>w#w-d1e2421-x2-18</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m127-d1e2421-x2-19">
   <w.rf>
    <LM>w#w-d1e2421-x2-19</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2429-x3">
  <m id="m127-d1t2436-1">
   <w.rf>
    <LM>w#w-d1t2436-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m127-d1t2436-2">
   <w.rf>
    <LM>w#w-d1t2436-2</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m127-d1t2436-3">
   <w.rf>
    <LM>w#w-d1t2436-3</LM>
   </w.rf>
   <form>obvykle</form>
   <lemma>obvykle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2436-4">
   <w.rf>
    <LM>w#w-d1t2436-4</LM>
   </w.rf>
   <form>ujedete</form>
   <lemma>ujet</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m127-d-id191412-punct">
   <w.rf>
    <LM>w#w-d-id191412-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2437-x2">
  <m id="m127-d1t2440-3">
   <w.rf>
    <LM>w#w-d1t2440-3</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m127-d1t2440-4">
   <w.rf>
    <LM>w#w-d1t2440-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2440-5">
   <w.rf>
    <LM>w#w-d1t2440-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m127-d-id191544-punct">
   <w.rf>
    <LM>w#w-d-id191544-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2440-7">
   <w.rf>
    <LM>w#w-d1t2440-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2440-8">
   <w.rf>
    <LM>w#w-d1t2440-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2440-9">
   <w.rf>
    <LM>w#w-d1t2440-9</LM>
   </w.rf>
   <form>jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2440-10">
   <w.rf>
    <LM>w#w-d1t2440-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2440-11">
   <w.rf>
    <LM>w#w-d1t2440-11</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m127-d-id191631-punct">
   <w.rf>
    <LM>w#w-d-id191631-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2440-14">
   <w.rf>
    <LM>w#w-d1t2440-14</LM>
   </w.rf>
   <form>neujedeme</form>
   <lemma>ujet</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m127-d1e2437-x2-121">
   <w.rf>
    <LM>w#w-d1e2437-x2-121</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2440-15">
   <w.rf>
    <LM>w#w-d1t2440-15</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2440-16">
   <w.rf>
    <LM>w#w-d1t2440-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2440-18">
   <w.rf>
    <LM>w#w-d1t2440-18</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1e2437-x2-122">
   <w.rf>
    <LM>w#w-d1e2437-x2-122</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2440-20">
   <w.rf>
    <LM>w#w-d1t2440-20</LM>
   </w.rf>
   <form>méně</form>
   <lemma>méně</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m127-d1t2440-22">
   <w.rf>
    <LM>w#w-d1t2440-22</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2440-23">
   <w.rf>
    <LM>w#w-d1t2440-23</LM>
   </w.rf>
   <form>30</form>
   <lemma>30</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-d1t2440-24">
   <w.rf>
    <LM>w#w-d1t2440-24</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-d-id191805-punct">
   <w.rf>
    <LM>w#w-d-id191805-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2440-26">
   <w.rf>
    <LM>w#w-d1t2440-26</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2440-27">
   <w.rf>
    <LM>w#w-d1t2440-27</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2440-28">
   <w.rf>
    <LM>w#w-d1t2440-28</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2440-29">
   <w.rf>
    <LM>w#w-d1t2440-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2440-30">
   <w.rf>
    <LM>w#w-d1t2440-30</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2440-32">
   <w.rf>
    <LM>w#w-d1t2440-32</LM>
   </w.rf>
   <form>50</form>
   <lemma>50</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m127-d1t2440-33">
   <w.rf>
    <LM>w#w-d1t2440-33</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-d1e2437-x2-123">
   <w.rf>
    <LM>w#w-d1e2437-x2-123</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-63">
  <m id="m127-d1t2442-2">
   <w.rf>
    <LM>w#w-d1t2442-2</LM>
   </w.rf>
   <form>Jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2442-5">
   <w.rf>
    <LM>w#w-d1t2442-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2442-6">
   <w.rf>
    <LM>w#w-d1t2442-6</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m127-d1t2442-3">
   <w.rf>
    <LM>w#w-d1t2442-3</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2442-4">
   <w.rf>
    <LM>w#w-d1t2442-4</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d-id192040-punct">
   <w.rf>
    <LM>w#w-d-id192040-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2442-8">
   <w.rf>
    <LM>w#w-d1t2442-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2442-9">
   <w.rf>
    <LM>w#w-d1t2442-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2442-10">
   <w.rf>
    <LM>w#w-d1t2442-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2442-12">
   <w.rf>
    <LM>w#w-d1t2442-12</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d-id192128-punct">
   <w.rf>
    <LM>w#w-d-id192128-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2442-15">
   <w.rf>
    <LM>w#w-d1t2442-15</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2442-16">
   <w.rf>
    <LM>w#w-d1t2442-16</LM>
   </w.rf>
   <form>bydlíme</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2442-17">
   <w.rf>
    <LM>w#w-d1t2442-17</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2442-19">
   <w.rf>
    <LM>w#w-d1t2442-19</LM>
   </w.rf>
   <form>Stromovky</form>
   <lemma>Stromovka_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-63-562">
   <w.rf>
    <LM>w#w-63-562</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-563">
  <m id="m127-d1t2444-1">
   <w.rf>
    <LM>w#w-d1t2444-1</LM>
   </w.rf>
   <form>Dvakrát</form>
   <lemma>dvakrát`2</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m127-d1t2444-2">
   <w.rf>
    <LM>w#w-d1t2444-2</LM>
   </w.rf>
   <form>šlápnem</form>
   <lemma>šlápnout</lemma>
   <tag>VB-P---1P-AAP-6</tag>
  </m>
  <m id="m127-563-564">
   <w.rf>
    <LM>w#w-563-564</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2444-7">
   <w.rf>
    <LM>w#w-d1t2444-7</LM>
   </w.rf>
   <form>vyjedeme</form>
   <lemma>vyjet</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m127-d1t2444-5">
   <w.rf>
    <LM>w#w-d1t2444-5</LM>
   </w.rf>
   <form>Stromovkou</form>
   <lemma>Stromovka_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-d1t2444-8">
   <w.rf>
    <LM>w#w-d1t2444-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2444-9">
   <w.rf>
    <LM>w#w-d1t2444-9</LM>
   </w.rf>
   <form>jedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2444-10">
   <w.rf>
    <LM>w#w-d1t2444-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2444-12">
   <w.rf>
    <LM>w#w-d1t2444-12</LM>
   </w.rf>
   <form>Klecan</form>
   <lemma>Klecany_;G</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m127-63-147">
   <w.rf>
    <LM>w#w-63-147</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-63-148">
   <w.rf>
    <LM>w#w-63-148</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-63-149">
   <w.rf>
    <LM>w#w-63-149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-146">
  <m id="m127-d1t2444-17">
   <w.rf>
    <LM>w#w-d1t2444-17</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2444-18">
   <w.rf>
    <LM>w#w-d1t2444-18</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2444-20">
   <w.rf>
    <LM>w#w-d1t2444-20</LM>
   </w.rf>
   <form>nádherné</form>
   <lemma>nádherný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m127-d1t2444-19">
   <w.rf>
    <LM>w#w-d1t2444-19</LM>
   </w.rf>
   <form>cyklostezky</form>
   <lemma>cyklostezka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m127-63-139">
   <w.rf>
    <LM>w#w-63-139</LM>
   </w.rf>
   <form>skrz</form>
   <lemma>skrz-2</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2446-3">
   <w.rf>
    <LM>w#w-d1t2446-3</LM>
   </w.rf>
   <form>Karlín</form>
   <lemma>Karlín_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2446-5">
   <w.rf>
    <LM>w#w-d1t2446-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2446-6">
   <w.rf>
    <LM>w#w-d1t2446-6</LM>
   </w.rf>
   <form>okolo</form>
   <lemma>okolo-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2446-8">
   <w.rf>
    <LM>w#w-d1t2446-8</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-146-150">
   <w.rf>
    <LM>w#w-146-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-89">
  <m id="m127-d1t2451-4">
   <w.rf>
    <LM>w#w-d1t2451-4</LM>
   </w.rf>
   <form>Kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m127-d1t2451-2">
   <w.rf>
    <LM>w#w-d1t2451-2</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2451-3">
   <w.rf>
    <LM>w#w-d1t2451-3</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m127-d-m-d1e2437-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2437-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2453-x2">
  <m id="m127-d1t2456-1">
   <w.rf>
    <LM>w#w-d1t2456-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m127-d1e2453-x2-158">
   <w.rf>
    <LM>w#w-d1e2453-x2-158</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-157">
  <m id="m127-d1t2456-3">
   <w.rf>
    <LM>w#w-d1t2456-3</LM>
   </w.rf>
   <form>Poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m127-d1t2456-4">
   <w.rf>
    <LM>w#w-d1t2456-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2453-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2453-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-179">
  <m id="m127-d1t2464-4">
   <w.rf>
    <LM>w#w-d1t2464-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2464-5">
   <w.rf>
    <LM>w#w-d1t2464-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2464-6">
   <w.rf>
    <LM>w#w-d1t2464-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2464-7">
   <w.rf>
    <LM>w#w-d1t2464-7</LM>
   </w.rf>
   <form>loňska</form>
   <lemma>loňsko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m127-d-id193065-punct">
   <w.rf>
    <LM>w#w-d-id193065-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2464-9">
   <w.rf>
    <LM>w#w-d1t2464-9</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2464-11">
   <w.rf>
    <LM>w#w-d1t2464-11</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2464-12">
   <w.rf>
    <LM>w#w-d1t2464-12</LM>
   </w.rf>
   <form>novou</form>
   <lemma>nový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m127-d1t2464-13">
   <w.rf>
    <LM>w#w-d1t2464-13</LM>
   </w.rf>
   <form>přilbu</form>
   <lemma>přilba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-179-578">
   <w.rf>
    <LM>w#w-179-578</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-579">
  <m id="m127-d1t2464-17">
   <w.rf>
    <LM>w#w-d1t2464-17</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2464-18">
   <w.rf>
    <LM>w#w-d1t2464-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2464-19">
   <w.rf>
    <LM>w#w-d1t2464-19</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2464-22">
   <w.rf>
    <LM>w#w-d1t2464-22</LM>
   </w.rf>
   <form>Alp</form>
   <lemma>Alpy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m127-d-id193286-punct">
   <w.rf>
    <LM>w#w-d-id193286-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2466-1">
   <w.rf>
    <LM>w#w-d1t2466-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2466-2">
   <w.rf>
    <LM>w#w-d1t2466-2</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2466-3">
   <w.rf>
    <LM>w#w-d1t2466-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2466-5">
   <w.rf>
    <LM>w#w-d1t2466-5</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS7-P1-------</tag>
  </m>
  <m id="m127-d1t2466-6">
   <w.rf>
    <LM>w#w-d1t2466-6</LM>
   </w.rf>
   <form>partou</form>
   <lemma>parta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m127-579-580">
   <w.rf>
    <LM>w#w-579-580</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-581">
  <m id="m127-d1t2468-5">
   <w.rf>
    <LM>w#w-d1t2468-5</LM>
   </w.rf>
   <form>Sjíždíme</form>
   <lemma>sjíždět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2468-4">
   <w.rf>
    <LM>w#w-d1t2468-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2468-1">
   <w.rf>
    <LM>w#w-d1t2468-1</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m127-d1t2468-2">
   <w.rf>
    <LM>w#w-d1t2468-2</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m127-d1t2468-3">
   <w.rf>
    <LM>w#w-d1t2468-3</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m127-179-180">
   <w.rf>
    <LM>w#w-179-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-169">
  <m id="m127-d1t2473-7">
   <w.rf>
    <LM>w#w-d1t2473-7</LM>
   </w.rf>
   <form>Lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2473-2">
   <w.rf>
    <LM>w#w-d1t2473-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2473-5">
   <w.rf>
    <LM>w#w-d1t2473-5</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2473-6">
   <w.rf>
    <LM>w#w-d1t2473-6</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m127-d1t2473-3">
   <w.rf>
    <LM>w#w-d1t2473-3</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m127-d1t2473-4">
   <w.rf>
    <LM>w#w-d1t2473-4</LM>
   </w.rf>
   <form>sen</form>
   <lemma>sen-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d1t2473-8">
   <w.rf>
    <LM>w#w-d1t2473-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2473-9">
   <w.rf>
    <LM>w#w-d1t2473-9</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2473-10">
   <w.rf>
    <LM>w#w-d1t2473-10</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-169-182">
   <w.rf>
    <LM>w#w-169-182</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d-id193701-punct">
   <w.rf>
    <LM>w#w-d-id193701-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2473-12">
   <w.rf>
    <LM>w#w-d1t2473-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2473-13">
   <w.rf>
    <LM>w#w-d1t2473-13</LM>
   </w.rf>
   <form>jedete</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2473-14">
   <w.rf>
    <LM>w#w-d1t2473-14</LM>
   </w.rf>
   <form>autem</form>
   <lemma>auto</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m127-d1t2473-15">
   <w.rf>
    <LM>w#w-d1t2473-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2473-16">
   <w.rf>
    <LM>w#w-d1t2473-16</LM>
   </w.rf>
   <form>lyžemi</form>
   <lemma>lyže</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m127-169-184">
   <w.rf>
    <LM>w#w-169-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-183">
  <m id="m127-d1t2473-23">
   <w.rf>
    <LM>w#w-d1t2473-23</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2473-24">
   <w.rf>
    <LM>w#w-d1t2473-24</LM>
   </w.rf>
   <form>revoluci</form>
   <lemma>revoluce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m127-d1t2473-19">
   <w.rf>
    <LM>w#w-d1t2473-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2473-20">
   <w.rf>
    <LM>w#w-d1t2473-20</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m127-d1t2473-21">
   <w.rf>
    <LM>w#w-d1t2473-21</LM>
   </w.rf>
   <form>splnil</form>
   <lemma>splnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m127-d1t2473-18">
   <w.rf>
    <LM>w#w-d1t2473-18</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2473-22">
   <w.rf>
    <LM>w#w-d1t2473-22</LM>
   </w.rf>
   <form>sen</form>
   <lemma>sen-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d-id193910-punct">
   <w.rf>
    <LM>w#w-d-id193910-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2473-26">
   <w.rf>
    <LM>w#w-d1t2473-26</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2473-27">
   <w.rf>
    <LM>w#w-d1t2473-27</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2473-28">
   <w.rf>
    <LM>w#w-d1t2473-28</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2473-29">
   <w.rf>
    <LM>w#w-d1t2473-29</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2475-1">
   <w.rf>
    <LM>w#w-d1t2475-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2475-2">
   <w.rf>
    <LM>w#w-d1t2475-2</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m127-d1t2475-3">
   <w.rf>
    <LM>w#w-d1t2475-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2475-4">
   <w.rf>
    <LM>w#w-d1t2475-4</LM>
   </w.rf>
   <form>ledovci</form>
   <lemma>ledovec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m127-183-586">
   <w.rf>
    <LM>w#w-183-586</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-587">
  <m id="m127-d1t2475-6">
   <w.rf>
    <LM>w#w-d1t2475-6</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2475-7">
   <w.rf>
    <LM>w#w-d1t2475-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2475-9">
   <w.rf>
    <LM>w#w-d1t2475-9</LM>
   </w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m127-d1t2475-10">
   <w.rf>
    <LM>w#w-d1t2475-10</LM>
   </w.rf>
   <form>autem</form>
   <lemma>auto</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m127-d1t2475-12">
   <w.rf>
    <LM>w#w-d1t2475-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2475-13">
   <w.rf>
    <LM>w#w-d1t2475-13</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m127-d1e2457-x3-198">
   <w.rf>
    <LM>w#w-d1e2457-x3-198</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-197">
  <m id="m127-d1t2477-1">
   <w.rf>
    <LM>w#w-d1t2477-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2477-2">
   <w.rf>
    <LM>w#w-d1t2477-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2477-3">
   <w.rf>
    <LM>w#w-d1t2477-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2477-5">
   <w.rf>
    <LM>w#w-d1t2477-5</LM>
   </w.rf>
   <form>dětský</form>
   <lemma>dětský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m127-d1t2477-6">
   <w.rf>
    <LM>w#w-d1t2477-6</LM>
   </w.rf>
   <form>sen</form>
   <lemma>sen-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d-id194295-punct">
   <w.rf>
    <LM>w#w-d-id194295-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2477-8">
   <w.rf>
    <LM>w#w-d1t2477-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2479-1">
   <w.rf>
    <LM>w#w-d1t2479-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2479-2">
   <w.rf>
    <LM>w#w-d1t2479-2</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m127-d1t2479-3">
   <w.rf>
    <LM>w#w-d1t2479-3</LM>
   </w.rf>
   <form>pojedu</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m127-d1t2479-4">
   <w.rf>
    <LM>w#w-d1t2479-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2479-5">
   <w.rf>
    <LM>w#w-d1t2479-5</LM>
   </w.rf>
   <form>lyžemi</form>
   <lemma>lyže</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m127-197-205">
   <w.rf>
    <LM>w#w-197-205</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2479-7">
   <w.rf>
    <LM>w#w-d1t2479-7</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m127-d1t2479-8">
   <w.rf>
    <LM>w#w-d1t2479-8</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-197-602">
   <w.rf>
    <LM>w#w-197-602</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-603">
  <m id="m127-d1t2479-15">
   <w.rf>
    <LM>w#w-d1t2479-15</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2479-16">
   <w.rf>
    <LM>w#w-d1t2479-16</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2479-17">
   <w.rf>
    <LM>w#w-d1t2479-17</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m127-d1t2479-18">
   <w.rf>
    <LM>w#w-d1t2479-18</LM>
   </w.rf>
   <form>zamilovaný</form>
   <lemma>zamilovaný_^(*2t)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m127-d1t2479-19">
   <w.rf>
    <LM>w#w-d1t2479-19</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-197-207">
   <w.rf>
    <LM>w#w-197-207</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2479-20">
   <w.rf>
    <LM>w#w-d1t2479-20</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2457-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2457-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2480-x3">
  <m id="m127-d1t2487-1">
   <w.rf>
    <LM>w#w-d1t2487-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2487-2">
   <w.rf>
    <LM>w#w-d1t2487-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m127-d1t2487-3">
   <w.rf>
    <LM>w#w-d1t2487-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2487-4">
   <w.rf>
    <LM>w#w-d1t2487-4</LM>
   </w.rf>
   <form>naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m127-d1t2487-5">
   <w.rf>
    <LM>w#w-d1t2487-5</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d-id194847-punct">
   <w.rf>
    <LM>w#w-d-id194847-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2488-x2">
  <m id="m127-d1t2491-1">
   <w.rf>
    <LM>w#w-d1t2491-1</LM>
   </w.rf>
   <form>Naučil</form>
   <lemma>naučit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m127-d1t2491-2">
   <w.rf>
    <LM>w#w-d1t2491-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2491-3">
   <w.rf>
    <LM>w#w-d1t2491-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2491-4">
   <w.rf>
    <LM>w#w-d1t2491-4</LM>
   </w.rf>
   <form>lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m127-d1t2493-3">
   <w.rf>
    <LM>w#w-d1t2493-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2493-4">
   <w.rf>
    <LM>w#w-d1t2493-4</LM>
   </w.rf>
   <form>učení</form>
   <lemma>učení_^(*3it)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m127-d1e2488-x2-607">
   <w.rf>
    <LM>w#w-d1e2488-x2-607</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-608">
  <m id="m127-d1t2493-6">
   <w.rf>
    <LM>w#w-d1t2493-6</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m127-d1t2493-5">
   <w.rf>
    <LM>w#w-d1t2493-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2497-3">
   <w.rf>
    <LM>w#w-d1t2497-3</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2497-1">
   <w.rf>
    <LM>w#w-d1t2497-1</LM>
   </w.rf>
   <form>vynikající</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGMP4-----A----</tag>
  </m>
  <m id="m127-d1t2497-4">
   <w.rf>
    <LM>w#w-d1t2497-4</LM>
   </w.rf>
   <form>lyžařské</form>
   <lemma>lyžařský</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m127-d1t2497-2">
   <w.rf>
    <LM>w#w-d1t2497-2</LM>
   </w.rf>
   <form>instruktory</form>
   <lemma>instruktor</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m127-d-id195139-punct">
   <w.rf>
    <LM>w#w-d-id195139-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2497-6">
   <w.rf>
    <LM>w#w-d1t2497-6</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m127-d1t2497-7">
   <w.rf>
    <LM>w#w-d1t2497-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m127-d1t2497-8">
   <w.rf>
    <LM>w#w-d1t2497-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m127-d1t2497-9">
   <w.rf>
    <LM>w#w-d1t2497-9</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m127-d1t2497-10">
   <w.rf>
    <LM>w#w-d1t2497-10</LM>
   </w.rf>
   <form>přivedli</form>
   <lemma>přivést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m127-608-609">
   <w.rf>
    <LM>w#w-608-609</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-611">
  <m id="m127-d1t2497-12">
   <w.rf>
    <LM>w#w-d1t2497-12</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2497-13">
   <w.rf>
    <LM>w#w-d1t2497-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2497-14">
   <w.rf>
    <LM>w#w-d1t2497-14</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m127-d1t2497-15">
   <w.rf>
    <LM>w#w-d1t2497-15</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d-id195303-punct">
   <w.rf>
    <LM>w#w-d-id195303-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2497-17">
   <w.rf>
    <LM>w#w-d1t2497-17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2497-18">
   <w.rf>
    <LM>w#w-d1t2497-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2497-19">
   <w.rf>
    <LM>w#w-d1t2497-19</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m127-d1t2499-1">
   <w.rf>
    <LM>w#w-d1t2499-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m127-d1t2499-2">
   <w.rf>
    <LM>w#w-d1t2499-2</LM>
   </w.rf>
   <form>celoživotní</form>
   <lemma>celoživotní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m127-d1t2499-3">
   <w.rf>
    <LM>w#w-d1t2499-3</LM>
   </w.rf>
   <form>sport</form>
   <lemma>sport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d1e2488-x2-224">
   <w.rf>
    <LM>w#w-d1e2488-x2-224</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-223">
  <m id="m127-d1t2499-5">
   <w.rf>
    <LM>w#w-d1t2499-5</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2499-6">
   <w.rf>
    <LM>w#w-d1t2499-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2499-7">
   <w.rf>
    <LM>w#w-d1t2499-7</LM>
   </w.rf>
   <form>toužil</form>
   <lemma>toužit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2499-8">
   <w.rf>
    <LM>w#w-d1t2499-8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2502-2">
   <w.rf>
    <LM>w#w-d1t2502-2</LM>
   </w.rf>
   <form>lyžích</form>
   <lemma>lyže</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m127-d1t2499-10">
   <w.rf>
    <LM>w#w-d1t2499-10</LM>
   </w.rf>
   <form>Völkl</form>
   <lemma>Völkl-2_;m</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d-id195549-punct">
   <w.rf>
    <LM>w#w-d-id195549-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2502-4">
   <w.rf>
    <LM>w#w-d1t2502-4</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2504-1">
   <w.rf>
    <LM>w#w-d1t2504-1</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2504-2">
   <w.rf>
    <LM>w#w-d1t2504-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2504-3">
   <w.rf>
    <LM>w#w-d1t2504-3</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m127-d1t2504-4">
   <w.rf>
    <LM>w#w-d1t2504-4</LM>
   </w.rf>
   <form>kolena</form>
   <lemma>koleno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m127-d1t2504-5">
   <w.rf>
    <LM>w#w-d1t2504-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2504-6">
   <w.rf>
    <LM>w#w-d1t2504-6</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2504-7">
   <w.rf>
    <LM>w#w-d1t2504-7</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFP4----------</tag>
  </m>
  <m id="m127-d1t2504-9">
   <w.rf>
    <LM>w#w-d1t2504-9</LM>
   </w.rf>
   <form>Völkl</form>
   <lemma>Völkl-2_;m</lemma>
   <tag>NNIXX-----A----</tag>
  </m>
  <m id="m127-223-258">
   <w.rf>
    <LM>w#w-223-258</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2510-1">
   <w.rf>
    <LM>w#w-d1t2510-1</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2510-2">
   <w.rf>
    <LM>w#w-d1t2510-2</LM>
   </w.rf>
   <form>kvalitní</form>
   <lemma>kvalitní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m127-d1t2510-3">
   <w.rf>
    <LM>w#w-d1t2510-3</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m127-223-259">
   <w.rf>
    <LM>w#w-223-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-225">
  <m id="m127-d1t2512-1">
   <w.rf>
    <LM>w#w-d1t2512-1</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2512-2">
   <w.rf>
    <LM>w#w-d1t2512-2</LM>
   </w.rf>
   <form>loňska</form>
   <lemma>loňsko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m127-225-262">
   <w.rf>
    <LM>w#w-225-262</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2512-3">
   <w.rf>
    <LM>w#w-d1t2512-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2512-4">
   <w.rf>
    <LM>w#w-d1t2512-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m127-d1t2512-5">
   <w.rf>
    <LM>w#w-d1t2512-5</LM>
   </w.rf>
   <form>přilbu</form>
   <lemma>přilba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-id195906-punct">
   <w.rf>
    <LM>w#w-d-id195906-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2515-1">
   <w.rf>
    <LM>w#w-d1t2515-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2515-2">
   <w.rf>
    <LM>w#w-d1t2515-2</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2515-4">
   <w.rf>
    <LM>w#w-d1t2515-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2515-5">
   <w.rf>
    <LM>w#w-d1t2515-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2515-7">
   <w.rf>
    <LM>w#w-d1t2515-7</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2515-8">
   <w.rf>
    <LM>w#w-d1t2515-8</LM>
   </w.rf>
   <form>ošemetný</form>
   <lemma>ošemetný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m127-d1t2515-9">
   <w.rf>
    <LM>w#w-d1t2515-9</LM>
   </w.rf>
   <form>pád</form>
   <lemma>pád</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d1t2515-10">
   <w.rf>
    <LM>w#w-d1t2515-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2515-11">
   <w.rf>
    <LM>w#w-d1t2515-11</LM>
   </w.rf>
   <form>bouchl</form>
   <lemma>bouchnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m127-d1t2515-12">
   <w.rf>
    <LM>w#w-d1t2515-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d1t2515-13">
   <w.rf>
    <LM>w#w-d1t2515-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2515-14">
   <w.rf>
    <LM>w#w-d1t2515-14</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m127-d1t2515-15">
   <w.rf>
    <LM>w#w-d1t2515-15</LM>
   </w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m127-225-264">
   <w.rf>
    <LM>w#w-225-264</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-263">
  <m id="m127-d1t2515-18">
   <w.rf>
    <LM>w#w-d1t2515-18</LM>
   </w.rf>
   <form>Nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m127-d1t2515-19">
   <w.rf>
    <LM>w#w-d1t2515-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2515-20">
   <w.rf>
    <LM>w#w-d1t2515-20</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m127-d-id196234-punct">
   <w.rf>
    <LM>w#w-d-id196234-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2515-22">
   <w.rf>
    <LM>w#w-d1t2515-22</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2517-1">
   <w.rf>
    <LM>w#w-d1t2517-1</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2517-2">
   <w.rf>
    <LM>w#w-d1t2517-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2517-3">
   <w.rf>
    <LM>w#w-d1t2517-3</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m127-d1t2517-4">
   <w.rf>
    <LM>w#w-d1t2517-4</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m127-d1t2517-5">
   <w.rf>
    <LM>w#w-d1t2517-5</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m127-d1t2517-6">
   <w.rf>
    <LM>w#w-d1t2517-6</LM>
   </w.rf>
   <form>parta</form>
   <lemma>parta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m127-d1t2517-7">
   <w.rf>
    <LM>w#w-d1t2517-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m127-d1t2517-8">
   <w.rf>
    <LM>w#w-d1t2517-8</LM>
   </w.rf>
   <form>přilbách</form>
   <lemma>přilba</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2488-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2488-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2518-x2">
  <m id="m127-d1t2521-1">
   <w.rf>
    <LM>w#w-d1t2521-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m127-d1t2521-2">
   <w.rf>
    <LM>w#w-d1t2521-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m127-d1t2521-3">
   <w.rf>
    <LM>w#w-d1t2521-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2521-4">
   <w.rf>
    <LM>w#w-d1t2521-4</LM>
   </w.rf>
   <form>rozhovor</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2518-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2518-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2522-x2">
  <m id="m127-d1t2525-1">
   <w.rf>
    <LM>w#w-d1t2525-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m127-d-m-d1e2522-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2522-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2526-x2">
  <m id="m127-d1t2529-1">
   <w.rf>
    <LM>w#w-d1t2529-1</LM>
   </w.rf>
   <form>Velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1t2529-2">
   <w.rf>
    <LM>w#w-d1t2529-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m127-d1t2529-3">
   <w.rf>
    <LM>w#w-d1t2529-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m127-d1t2529-4">
   <w.rf>
    <LM>w#w-d1t2529-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m127-d1t2529-5">
   <w.rf>
    <LM>w#w-d1t2529-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m127-d1t2529-6">
   <w.rf>
    <LM>w#w-d1t2529-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m127-d1t2529-7">
   <w.rf>
    <LM>w#w-d1t2529-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m127-d-m-d1e2526-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2526-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2530-x2">
  <m id="m127-d1t2533-1">
   <w.rf>
    <LM>w#w-d1t2533-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m127-d1t2533-2">
   <w.rf>
    <LM>w#w-d1t2533-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m127-d1e2530-x2-273">
   <w.rf>
    <LM>w#w-d1e2530-x2-273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-272">
  <m id="m127-d1t2537-8">
   <w.rf>
    <LM>w#w-d1t2537-8</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2537-9">
   <w.rf>
    <LM>w#w-d1t2537-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2537-10">
   <w.rf>
    <LM>w#w-d1t2537-10</LM>
   </w.rf>
   <form>příjemné</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m127-272-274">
   <w.rf>
    <LM>w#w-272-274</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m127-d1t2537-1">
   <w.rf>
    <LM>w#w-d1t2537-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m127-d1t2537-2">
   <w.rf>
    <LM>w#w-d1t2537-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m127-d1t2537-3">
   <w.rf>
    <LM>w#w-d1t2537-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m127-d1t2537-4">
   <w.rf>
    <LM>w#w-d1t2537-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m127-d1t2537-5">
   <w.rf>
    <LM>w#w-d1t2537-5</LM>
   </w.rf>
   <form>stroj</form>
   <lemma>stroj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2530-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2530-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2538-x2">
  <m id="m127-d1e2538-x2-623">
   <w.rf>
    <LM>w#w-d1e2538-x2-623</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2543-1">
   <w.rf>
    <LM>w#w-d1t2543-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2538-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2538-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m127-d1e2538-x3">
  <m id="m127-d1e2538-x3-624">
   <w.rf>
    <LM>w#w-d1e2538-x3-624</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m127-d1t2545-1">
   <w.rf>
    <LM>w#w-d1t2545-1</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m127-d-m-d1e2538-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2538-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
