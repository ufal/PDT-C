<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ju_027.09.w.gz" />
  </references>
 </head>
 <s id="m027-448">
  <m id="m027-d1t2452-9">
   <w.rf>
    <LM>w#w-d1t2452-9</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2452-10">
   <w.rf>
    <LM>w#w-d1t2452-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2452-11">
   <w.rf>
    <LM>w#w-d1t2452-11</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2452-12">
   <w.rf>
    <LM>w#w-d1t2452-12</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m027-d1t2452-16">
   <w.rf>
    <LM>w#w-d1t2452-16</LM>
   </w.rf>
   <form>rozdíl</form>
   <lemma>rozdíl</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1t2452-14">
   <w.rf>
    <LM>w#w-d1t2452-14</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m027-d1t2452-15">
   <w.rf>
    <LM>w#w-d1t2452-15</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m027-d-id151080-punct">
   <w.rf>
    <LM>w#w-d-id151080-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2454-1">
   <w.rf>
    <LM>w#w-d1t2454-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2454-2">
   <w.rf>
    <LM>w#w-d1t2454-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2454-3">
   <w.rf>
    <LM>w#w-d1t2454-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2454-4">
   <w.rf>
    <LM>w#w-d1t2454-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2454-5">
   <w.rf>
    <LM>w#w-d1t2454-5</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m027-d1t2454-6">
   <w.rf>
    <LM>w#w-d1t2454-6</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d-id151206-punct">
   <w.rf>
    <LM>w#w-d-id151206-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2454-8">
   <w.rf>
    <LM>w#w-d1t2454-8</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2454-9">
   <w.rf>
    <LM>w#w-d1t2454-9</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2454-12">
   <w.rf>
    <LM>w#w-d1t2454-12</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2454-11">
   <w.rf>
    <LM>w#w-d1t2454-11</LM>
   </w.rf>
   <form>vyváděli</form>
   <lemma>vyvádět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-448-449">
   <w.rf>
    <LM>w#w-448-449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-450">
  <m id="m027-d1t2454-15">
   <w.rf>
    <LM>w#w-d1t2454-15</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2454-16">
   <w.rf>
    <LM>w#w-d1t2454-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2454-14">
   <w.rf>
    <LM>w#w-d1t2454-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2454-18">
   <w.rf>
    <LM>w#w-d1t2454-18</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t2454-17">
   <w.rf>
    <LM>w#w-d1t2454-17</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m027-d1t2454-19">
   <w.rf>
    <LM>w#w-d1t2454-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2454-21">
   <w.rf>
    <LM>w#w-d1t2454-21</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2454-23">
   <w.rf>
    <LM>w#w-d1t2454-23</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m027-d1t2454-22">
   <w.rf>
    <LM>w#w-d1t2454-22</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-450-451">
   <w.rf>
    <LM>w#w-450-451</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-452">
  <m id="m027-d1t2456-1">
   <w.rf>
    <LM>w#w-d1t2456-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2456-2">
   <w.rf>
    <LM>w#w-d1t2456-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m027-d1t2456-3">
   <w.rf>
    <LM>w#w-d1t2456-3</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2456-4">
   <w.rf>
    <LM>w#w-d1t2456-4</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m027-d1t2456-5">
   <w.rf>
    <LM>w#w-d1t2456-5</LM>
   </w.rf>
   <form>lumpárny</form>
   <lemma>lumpárna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d1t2459-1">
   <w.rf>
    <LM>w#w-d1t2459-1</LM>
   </w.rf>
   <form>neprováděli</form>
   <lemma>provádět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m027-d-m-d1e2432-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2432-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2460-x2">
  <m id="m027-d1t2465-3">
   <w.rf>
    <LM>w#w-d1t2465-3</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m027-d1t2465-1">
   <w.rf>
    <LM>w#w-d1t2465-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2465-2">
   <w.rf>
    <LM>w#w-d1t2465-2</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e2460-x2-464">
   <w.rf>
    <LM>w#w-d1e2460-x2-464</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e2460-x2-465">
   <w.rf>
    <LM>w#w-d1e2460-x2-465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d-m-d1e2460-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2460-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2460-x3">
  <m id="m027-d1t2467-1">
   <w.rf>
    <LM>w#w-d1t2467-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2467-2">
   <w.rf>
    <LM>w#w-d1t2467-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2467-3">
   <w.rf>
    <LM>w#w-d1t2467-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-d-id151724-punct">
   <w.rf>
    <LM>w#w-d-id151724-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2468-x2">
  <m id="m027-d1t2471-1">
   <w.rf>
    <LM>w#w-d1t2471-1</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m027-d1t2471-2">
   <w.rf>
    <LM>w#w-d1t2471-2</LM>
   </w.rf>
   <form>klidní</form>
   <lemma>klidný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d1t2471-3">
   <w.rf>
    <LM>w#w-d1t2471-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2471-6">
   <w.rf>
    <LM>w#w-d1t2471-6</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d1e2468-x2-480">
   <w.rf>
    <LM>w#w-d1e2468-x2-480</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-481">
  <m id="m027-d1t2471-9">
   <w.rf>
    <LM>w#w-d1t2471-9</LM>
   </w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m027-d1t2471-10">
   <w.rf>
    <LM>w#w-d1t2471-10</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m027-d1t2471-11">
   <w.rf>
    <LM>w#w-d1t2471-11</LM>
   </w.rf>
   <form>klukoviny</form>
   <lemma>klukovina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-481-482">
   <w.rf>
    <LM>w#w-481-482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-481-483">
   <w.rf>
    <LM>w#w-481-483</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-481-484">
   <w.rf>
    <LM>w#w-481-484</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-485">
  <m id="m027-d1t2471-16">
   <w.rf>
    <LM>w#w-d1t2471-16</LM>
   </w.rf>
   <form>Třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t2471-14">
   <w.rf>
    <LM>w#w-d1t2471-14</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2471-13">
   <w.rf>
    <LM>w#w-d1t2471-13</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2471-15">
   <w.rf>
    <LM>w#w-d1t2471-15</LM>
   </w.rf>
   <form>fotbal</form>
   <lemma>fotbal</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t2471-17">
   <w.rf>
    <LM>w#w-d1t2471-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2471-18">
   <w.rf>
    <LM>w#w-d1t2471-18</LM>
   </w.rf>
   <form>předsíni</form>
   <lemma>předsíň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-485-494">
   <w.rf>
    <LM>w#w-485-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-495">
  <m id="m027-d1t2471-20">
   <w.rf>
    <LM>w#w-d1t2471-20</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2471-21">
   <w.rf>
    <LM>w#w-d1t2471-21</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2471-22">
   <w.rf>
    <LM>w#w-d1t2471-22</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2471-23">
   <w.rf>
    <LM>w#w-d1t2471-23</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m027-d1t2471-24">
   <w.rf>
    <LM>w#w-d1t2471-24</LM>
   </w.rf>
   <form>obložení</form>
   <lemma>obložení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d-id152131-punct">
   <w.rf>
    <LM>w#w-d-id152131-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2473-1">
   <w.rf>
    <LM>w#w-d1t2473-1</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2487-1">
   <w.rf>
    <LM>w#w-d1t2487-1</LM>
   </w.rf>
   <form>nezničili</form>
   <lemma>zničit</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m027-d1t2487-2">
   <w.rf>
    <LM>w#w-d1t2487-2</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m027-d1t2487-3">
   <w.rf>
    <LM>w#w-d1t2487-3</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-485-493">
   <w.rf>
    <LM>w#w-485-493</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2484-x2">
  <m id="m027-d1t2487-8">
   <w.rf>
    <LM>w#w-d1t2487-8</LM>
   </w.rf>
   <form>Kopali</form>
   <lemma>kopat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2487-7">
   <w.rf>
    <LM>w#w-d1t2487-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m027-d1e2484-x2-496">
   <w.rf>
    <LM>w#w-d1e2484-x2-496</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2487-11">
   <w.rf>
    <LM>w#w-d1t2487-11</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2487-10">
   <w.rf>
    <LM>w#w-d1t2487-10</LM>
   </w.rf>
   <form>všelijaké</form>
   <lemma>všelijaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m027-d1t2487-12">
   <w.rf>
    <LM>w#w-d1t2487-12</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m027-d1t2487-13">
   <w.rf>
    <LM>w#w-d1t2487-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2487-14">
   <w.rf>
    <LM>w#w-d1t2487-14</LM>
   </w.rf>
   <form>sportovali</form>
   <lemma>sportovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d-id152541-punct">
   <w.rf>
    <LM>w#w-d-id152541-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2489-1">
   <w.rf>
    <LM>w#w-d1t2489-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2489-2">
   <w.rf>
    <LM>w#w-d1t2489-2</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2489-3">
   <w.rf>
    <LM>w#w-d1t2489-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2489-4">
   <w.rf>
    <LM>w#w-d1t2489-4</LM>
   </w.rf>
   <form>hodní</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d-id152636-punct">
   <w.rf>
    <LM>w#w-d-id152636-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2489-7">
   <w.rf>
    <LM>w#w-d1t2489-7</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2489-8">
   <w.rf>
    <LM>w#w-d1t2489-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2489-9">
   <w.rf>
    <LM>w#w-d1t2489-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2489-10">
   <w.rf>
    <LM>w#w-d1t2489-10</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m027-d1t2489-11">
   <w.rf>
    <LM>w#w-d1t2489-11</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e2484-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2484-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2500-x2">
  <m id="m027-d1t2505-1">
   <w.rf>
    <LM>w#w-d1t2505-1</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2505-2">
   <w.rf>
    <LM>w#w-d1t2505-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m027-d1t2505-3">
   <w.rf>
    <LM>w#w-d1t2505-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m027-d1t2505-4">
   <w.rf>
    <LM>w#w-d1t2505-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t2505-5">
   <w.rf>
    <LM>w#w-d1t2505-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m027-d1t2505-6">
   <w.rf>
    <LM>w#w-d1t2505-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2505-7">
   <w.rf>
    <LM>w#w-d1t2505-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m027-d1t2505-8">
   <w.rf>
    <LM>w#w-d1t2505-8</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m027-d-id153035-punct">
   <w.rf>
    <LM>w#w-d-id153035-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2508-x2">
  <m id="m027-d1t2511-2">
   <w.rf>
    <LM>w#w-d1t2511-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2511-3">
   <w.rf>
    <LM>w#w-d1t2511-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2511-4">
   <w.rf>
    <LM>w#w-d1t2511-4</LM>
   </w.rf>
   <form>nejhezčí</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m027-d1t2511-5">
   <w.rf>
    <LM>w#w-d1t2511-5</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2511-6">
   <w.rf>
    <LM>w#w-d1t2511-6</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m027-d1t2511-7">
   <w.rf>
    <LM>w#w-d1t2511-7</LM>
   </w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-d1e2508-x2-192">
   <w.rf>
    <LM>w#w-d1e2508-x2-192</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-194">
  <m id="m027-d1t2511-9">
   <w.rf>
    <LM>w#w-d1t2511-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2511-10">
   <w.rf>
    <LM>w#w-d1t2511-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2511-11">
   <w.rf>
    <LM>w#w-d1t2511-11</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-d1t2511-12">
   <w.rf>
    <LM>w#w-d1t2511-12</LM>
   </w.rf>
   <form>malé</form>
   <lemma>malý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m027-d-id153312-punct">
   <w.rf>
    <LM>w#w-d-id153312-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2511-15">
   <w.rf>
    <LM>w#w-d1t2511-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2511-16">
   <w.rf>
    <LM>w#w-d1t2511-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2511-17">
   <w.rf>
    <LM>w#w-d1t2511-17</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2511-18">
   <w.rf>
    <LM>w#w-d1t2511-18</LM>
   </w.rf>
   <form>mámu</form>
   <lemma>máma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1t2511-19">
   <w.rf>
    <LM>w#w-d1t2511-19</LM>
   </w.rf>
   <form>nejhezčí</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m027-d1t2511-20">
   <w.rf>
    <LM>w#w-d1t2511-20</LM>
   </w.rf>
   <form>část</form>
   <lemma>část</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2511-21">
   <w.rf>
    <LM>w#w-d1t2511-21</LM>
   </w.rf>
   <form>života</form>
   <lemma>život</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e2508-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2508-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2518-x2">
  <m id="m027-d1t2521-1">
   <w.rf>
    <LM>w#w-d1t2521-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t2521-2">
   <w.rf>
    <LM>w#w-d1t2521-2</LM>
   </w.rf>
   <form>věřím</form>
   <lemma>věřit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e2518-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2518-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2522-x2">
  <m id="m027-d1t2525-1">
   <w.rf>
    <LM>w#w-d1t2525-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d-m-d1e2522-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2522-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2526-x2">
  <m id="m027-d1t2531-3">
   <w.rf>
    <LM>w#w-d1t2531-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m027-d1t2531-2">
   <w.rf>
    <LM>w#w-d1t2531-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2531-4">
   <w.rf>
    <LM>w#w-d1t2531-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2531-5">
   <w.rf>
    <LM>w#w-d1t2531-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m027-d1t2531-6">
   <w.rf>
    <LM>w#w-d1t2531-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-m-d1e2526-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2526-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2526-x3">
  <m id="m027-d1t2533-1">
   <w.rf>
    <LM>w#w-d1t2533-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d-id153765-punct">
   <w.rf>
    <LM>w#w-d-id153765-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2533-3">
   <w.rf>
    <LM>w#w-d1t2533-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2533-4">
   <w.rf>
    <LM>w#w-d1t2533-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2533-5">
   <w.rf>
    <LM>w#w-d1t2533-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2533-6">
   <w.rf>
    <LM>w#w-d1t2533-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t2533-7">
   <w.rf>
    <LM>w#w-d1t2533-7</LM>
   </w.rf>
   <form>dívám</form>
   <lemma>dívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m027-d-m-d1e2526-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2526-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2534-x2">
  <m id="m027-d1t2537-2">
   <w.rf>
    <LM>w#w-d1t2537-2</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d-m-d1e2534-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2534-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2538-x3">
  <m id="m027-d1t2545-1">
   <w.rf>
    <LM>w#w-d1t2545-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m027-d1t2545-2">
   <w.rf>
    <LM>w#w-d1t2545-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2545-3">
   <w.rf>
    <LM>w#w-d1t2545-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2545-4">
   <w.rf>
    <LM>w#w-d1t2545-4</LM>
   </w.rf>
   <form>zač</form>
   <lemma>co-1</lemma>
   <tag>PQ--4--------z-</tag>
  </m>
  <m id="m027-d-id154060-punct">
   <w.rf>
    <LM>w#w-d-id154060-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2546-x2">
  <m id="m027-d1t2549-1">
   <w.rf>
    <LM>w#w-d1t2549-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2549-2">
   <w.rf>
    <LM>w#w-d1t2549-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2549-4">
   <w.rf>
    <LM>w#w-d1t2549-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d-id154183-punct">
   <w.rf>
    <LM>w#w-d-id154183-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2549-6">
   <w.rf>
    <LM>w#w-d1t2549-6</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2549-8">
   <w.rf>
    <LM>w#w-d1t2549-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2549-7">
   <w.rf>
    <LM>w#w-d1t2549-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2551-2">
   <w.rf>
    <LM>w#w-d1t2551-2</LM>
   </w.rf>
   <form>Honzíka</form>
   <lemma>Honzík_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m027-d1t2551-4">
   <w.rf>
    <LM>w#w-d1t2551-4</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m027-d1e2546-x2-127">
   <w.rf>
    <LM>w#w-d1e2546-x2-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-248_2">
  <m id="m027-d1t2551-8">
   <w.rf>
    <LM>w#w-d1t2551-8</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2551-7">
   <w.rf>
    <LM>w#w-d1t2551-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2551-9">
   <w.rf>
    <LM>w#w-d1t2551-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2551-10">
   <w.rf>
    <LM>w#w-d1t2551-10</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t2553-1">
   <w.rf>
    <LM>w#w-d1t2553-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2553-3">
   <w.rf>
    <LM>w#w-d1t2553-3</LM>
   </w.rf>
   <form>Jugoslávii</form>
   <lemma>Jugoslávie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id154433-punct">
   <w.rf>
    <LM>w#w-d-id154433-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2553-6">
   <w.rf>
    <LM>w#w-d1t2553-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2553-7">
   <w.rf>
    <LM>w#w-d1t2553-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2553-8">
   <w.rf>
    <LM>w#w-d1t2553-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2553-9">
   <w.rf>
    <LM>w#w-d1t2553-9</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d1t2553-10">
   <w.rf>
    <LM>w#w-d1t2553-10</LM>
   </w.rf>
   <form>1972</form>
   <lemma>1972</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m027-248_2-306">
   <w.rf>
    <LM>w#w-248_2-306</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-308_2">
  <m id="m027-d1t2555-1">
   <w.rf>
    <LM>w#w-d1t2555-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2555-2">
   <w.rf>
    <LM>w#w-d1t2555-2</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2555-3">
   <w.rf>
    <LM>w#w-d1t2555-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2555-5">
   <w.rf>
    <LM>w#w-d1t2555-5</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t2555-7">
   <w.rf>
    <LM>w#w-d1t2555-7</LM>
   </w.rf>
   <form>Pavlík</form>
   <lemma>Pavlík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t2561-1">
   <w.rf>
    <LM>w#w-d1t2561-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2561-2">
   <w.rf>
    <LM>w#w-d1t2561-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2561-3">
   <w.rf>
    <LM>w#w-d1t2561-3</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m027-d-id154787-punct">
   <w.rf>
    <LM>w#w-d-id154787-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2561-5">
   <w.rf>
    <LM>w#w-d1t2561-5</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t2561-6">
   <w.rf>
    <LM>w#w-d1t2561-6</LM>
   </w.rf>
   <form>holčička</form>
   <lemma>holčička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-308_2-310">
   <w.rf>
    <LM>w#w-308_2-310</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2569-1">
   <w.rf>
    <LM>w#w-d1t2569-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2569-2">
   <w.rf>
    <LM>w#w-d1t2569-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2569-4">
   <w.rf>
    <LM>w#w-d1t2569-4</LM>
   </w.rf>
   <form>Evička</form>
   <lemma>Evička_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2569-5">
   <w.rf>
    <LM>w#w-d1t2569-5</LM>
   </w.rf>
   <form>Šampalíková</form>
   <lemma>Šampalíková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-308_2-312_2">
   <w.rf>
    <LM>w#w-308_2-312_2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2566-x2">
  <m id="m027-d1t2571-2">
   <w.rf>
    <LM>w#w-d1t2571-2</LM>
   </w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2571-4">
   <w.rf>
    <LM>w#w-d1t2571-4</LM>
   </w.rf>
   <form>Šampalíková</form>
   <lemma>Šampalíková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2569-9">
   <w.rf>
    <LM>w#w-d1t2569-9</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2569-10">
   <w.rf>
    <LM>w#w-d1t2569-10</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m027-d1t2569-11">
   <w.rf>
    <LM>w#w-d1t2569-11</LM>
   </w.rf>
   <form>kolegyně</form>
   <lemma>kolegyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2571-14">
   <w.rf>
    <LM>w#w-d1t2571-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2571-15">
   <w.rf>
    <LM>w#w-d1t2571-15</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1e2566-x2-412">
   <w.rf>
    <LM>w#w-d1e2566-x2-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-414_1">
  <m id="m027-d1t2573-1">
   <w.rf>
    <LM>w#w-d1t2573-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2573-2">
   <w.rf>
    <LM>w#w-d1t2573-2</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m027-d1t2573-3">
   <w.rf>
    <LM>w#w-d1t2573-3</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-m-d1e2566-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2566-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2574-x3">
  <m id="m027-d1t2581-1">
   <w.rf>
    <LM>w#w-d1t2581-1</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDMP1---------6</tag>
  </m>
  <m id="m027-d1t2581-2">
   <w.rf>
    <LM>w#w-d1t2581-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2581-3">
   <w.rf>
    <LM>w#w-d1t2581-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2581-4">
   <w.rf>
    <LM>w#w-d1t2581-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2581-5">
   <w.rf>
    <LM>w#w-d1t2581-5</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m027-d-id155478-punct">
   <w.rf>
    <LM>w#w-d-id155478-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2582-x2">
  <m id="m027-d1t2585-1">
   <w.rf>
    <LM>w#w-d1t2585-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t2585-2">
   <w.rf>
    <LM>w#w-d1t2585-2</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t2585-3">
   <w.rf>
    <LM>w#w-d1t2585-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m027-d1t2585-4">
   <w.rf>
    <LM>w#w-d1t2585-4</LM>
   </w.rf>
   <form>fotí</form>
   <lemma>fotit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m027-d1e2582-x2-460">
   <w.rf>
    <LM>w#w-d1e2582-x2-460</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-462">
  <m id="m027-d1t2585-7">
   <w.rf>
    <LM>w#w-d1t2585-7</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2585-6">
   <w.rf>
    <LM>w#w-d1t2585-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2585-8">
   <w.rf>
    <LM>w#w-d1t2585-8</LM>
   </w.rf>
   <form>naši</form>
   <lemma>náš</lemma>
   <tag>PSMP1-P1-------</tag>
  </m>
  <m id="m027-d1t2585-9">
   <w.rf>
    <LM>w#w-d1t2585-9</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d-id155679-punct">
   <w.rf>
    <LM>w#w-d-id155679-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2585-11">
   <w.rf>
    <LM>w#w-d1t2585-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2585-12">
   <w.rf>
    <LM>w#w-d1t2585-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2585-14">
   <w.rf>
    <LM>w#w-d1t2585-14</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2585-15">
   <w.rf>
    <LM>w#w-d1t2585-15</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2585-16">
   <w.rf>
    <LM>w#w-d1t2585-16</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m027-d1t2585-17">
   <w.rf>
    <LM>w#w-d1t2585-17</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m027-d1t2585-13">
   <w.rf>
    <LM>w#w-d1t2585-13</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2587-1">
   <w.rf>
    <LM>w#w-d1t2587-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2587-3">
   <w.rf>
    <LM>w#w-d1t2587-3</LM>
   </w.rf>
   <form>Jugoslávii</form>
   <lemma>Jugoslávie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-462-472">
   <w.rf>
    <LM>w#w-462-472</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-482">
  <m id="m027-d1t2585-19">
   <w.rf>
    <LM>w#w-d1t2585-19</LM>
   </w.rf>
   <form>Evička</form>
   <lemma>Evička_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2585-21">
   <w.rf>
    <LM>w#w-d1t2585-21</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2585-22">
   <w.rf>
    <LM>w#w-d1t2585-22</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t2585-23">
   <w.rf>
    <LM>w#w-d1t2585-23</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2585-24">
   <w.rf>
    <LM>w#w-d1t2585-24</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m027-d1t2585-26">
   <w.rf>
    <LM>w#w-d1t2585-26</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2585-27">
   <w.rf>
    <LM>w#w-d1t2585-27</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2585-28">
   <w.rf>
    <LM>w#w-d1t2585-28</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m027-d1t2585-25">
   <w.rf>
    <LM>w#w-d1t2585-25</LM>
   </w.rf>
   <form>měsíce</form>
   <lemma>měsíc</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m027-d1t2585-29">
   <w.rf>
    <LM>w#w-d1t2585-29</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m027-d1t2585-31">
   <w.rf>
    <LM>w#w-d1t2585-31</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2585-33">
   <w.rf>
    <LM>w#w-d1t2585-33</LM>
   </w.rf>
   <form>Pavlík</form>
   <lemma>Pavlík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-462-478">
   <w.rf>
    <LM>w#w-462-478</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-466_2">
  <m id="m027-d1t2587-7">
   <w.rf>
    <LM>w#w-d1t2587-7</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-466-468_2">
   <w.rf>
    <LM>w#w-466-468_2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2587-8">
   <w.rf>
    <LM>w#w-d1t2587-8</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2589-1">
   <w.rf>
    <LM>w#w-d1t2589-1</LM>
   </w.rf>
   <form>dobrodružná</form>
   <lemma>dobrodružný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d1t2589-2">
   <w.rf>
    <LM>w#w-d1t2589-2</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-462-464">
   <w.rf>
    <LM>w#w-462-464</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2589-3">
   <w.rf>
    <LM>w#w-d1t2589-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2589-4">
   <w.rf>
    <LM>w#w-d1t2589-4</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m027-d1t2589-5">
   <w.rf>
    <LM>w#w-d1t2589-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2589-6">
   <w.rf>
    <LM>w#w-d1t2589-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2589-7">
   <w.rf>
    <LM>w#w-d1t2589-7</LM>
   </w.rf>
   <form>vydali</form>
   <lemma>vydat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t2589-8">
   <w.rf>
    <LM>w#w-d1t2589-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2589-9">
   <w.rf>
    <LM>w#w-d1t2589-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t2589-10">
   <w.rf>
    <LM>w#w-d1t2589-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2589-11">
   <w.rf>
    <LM>w#w-d1t2589-11</LM>
   </w.rf>
   <form>kufrem</form>
   <lemma>kufr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d-id156365-punct">
   <w.rf>
    <LM>w#w-d-id156365-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2591-1">
   <w.rf>
    <LM>w#w-d1t2591-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2591-2">
   <w.rf>
    <LM>w#w-d1t2591-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2591-3">
   <w.rf>
    <LM>w#w-d1t2591-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2591-4">
   <w.rf>
    <LM>w#w-d1t2591-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e2582-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2582-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2592-x3">
  <m id="m027-d1t2601-5">
   <w.rf>
    <LM>w#w-d1t2601-5</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t2601-6">
   <w.rf>
    <LM>w#w-d1t2601-6</LM>
   </w.rf>
   <form>dovolená</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2601-2">
   <w.rf>
    <LM>w#w-d1t2601-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2601-3">
   <w.rf>
    <LM>w#w-d1t2601-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2601-1">
   <w.rf>
    <LM>w#w-d1t2601-1</LM>
   </w.rf>
   <form>povedla</form>
   <lemma>povést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m027-d-m-d1e2592-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2592-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2603-x2">
  <m id="m027-d1t2606-4">
   <w.rf>
    <LM>w#w-d1t2606-4</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2606-5">
   <w.rf>
    <LM>w#w-d1t2606-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2606-6">
   <w.rf>
    <LM>w#w-d1t2606-6</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1t2606-7">
   <w.rf>
    <LM>w#w-d1t2606-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2606-8">
   <w.rf>
    <LM>w#w-d1t2606-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2606-9">
   <w.rf>
    <LM>w#w-d1t2606-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2606-10">
   <w.rf>
    <LM>w#w-d1t2606-10</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m027-d1e2603-x2-494">
   <w.rf>
    <LM>w#w-d1e2603-x2-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-496_1">
  <m id="m027-d1t2608-3">
   <w.rf>
    <LM>w#w-d1t2608-3</LM>
   </w.rf>
   <form>Biograd</form>
   <lemma>Biograd_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1t2608-4">
   <w.rf>
    <LM>w#w-d1t2608-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2608-5">
   <w.rf>
    <LM>w#w-d1t2608-5</LM>
   </w.rf>
   <form>moru</form>
   <lemma>moru-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m027-d1t2608-7">
   <w.rf>
    <LM>w#w-d1t2608-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2608-9">
   <w.rf>
    <LM>w#w-d1t2608-9</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m027-d1t2608-11">
   <w.rf>
    <LM>w#w-d1t2608-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2608-12">
   <w.rf>
    <LM>w#w-d1t2608-12</LM>
   </w.rf>
   <form>letovisko</form>
   <lemma>letovisko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m027-496_1-238">
   <w.rf>
    <LM>w#w-496_1-238</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-239">
  <m id="m027-d1t2610-1">
   <w.rf>
    <LM>w#w-d1t2610-1</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2610-2">
   <w.rf>
    <LM>w#w-d1t2610-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2610-3">
   <w.rf>
    <LM>w#w-d1t2610-3</LM>
   </w.rf>
   <form>dovolená</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2610-4">
   <w.rf>
    <LM>w#w-d1t2610-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2610-5">
   <w.rf>
    <LM>w#w-d1t2610-5</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m027-d-m-d1e2603-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2603-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2611-x2">
  <m id="m027-d1t2614-1">
   <w.rf>
    <LM>w#w-d1t2614-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m027-d1t2614-2">
   <w.rf>
    <LM>w#w-d1t2614-2</LM>
   </w.rf>
   <form>vyprávějte</form>
   <lemma>vyprávět</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m027-d-m-d1e2611-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2611-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2617-x2">
  <m id="m027-d1t2620-6">
   <w.rf>
    <LM>w#w-d1t2620-6</LM>
   </w.rf>
   <form>Mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m027-d1t2620-5">
   <w.rf>
    <LM>w#w-d1t2620-5</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m027-d1t2620-7">
   <w.rf>
    <LM>w#w-d1t2620-7</LM>
   </w.rf>
   <form>vyprávět</form>
   <lemma>vyprávět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d-id157319-punct">
   <w.rf>
    <LM>w#w-d-id157319-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1e2617-x2-66">
   <w.rf>
    <LM>w#w-d1e2617-x2-66</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2620-10">
   <w.rf>
    <LM>w#w-d1t2620-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2620-9">
   <w.rf>
    <LM>w#w-d1t2620-9</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2620-11">
   <w.rf>
    <LM>w#w-d1t2620-11</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1e2617-x2-68">
   <w.rf>
    <LM>w#w-d1e2617-x2-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-70_2">
  <m id="m027-d1t2622-5">
   <w.rf>
    <LM>w#w-d1t2622-5</LM>
   </w.rf>
   <form>Pracovaly</form>
   <lemma>pracovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2622-3">
   <w.rf>
    <LM>w#w-d1t2622-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2622-4">
   <w.rf>
    <LM>w#w-d1t2622-4</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2622-6">
   <w.rf>
    <LM>w#w-d1t2622-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2622-7">
   <w.rf>
    <LM>w#w-d1t2622-7</LM>
   </w.rf>
   <form>bance</form>
   <lemma>banka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id157487-punct">
   <w.rf>
    <LM>w#w-d-id157487-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2622-9">
   <w.rf>
    <LM>w#w-d1t2622-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2624-1">
   <w.rf>
    <LM>w#w-d1t2624-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t2624-2">
   <w.rf>
    <LM>w#w-d1t2624-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2624-3">
   <w.rf>
    <LM>w#w-d1t2624-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-70_2-80">
   <w.rf>
    <LM>w#w-70_2-80</LM>
   </w.rf>
   <form>různí</form>
   <lemma>různý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m027-d1t2624-4">
   <w.rf>
    <LM>w#w-d1t2624-4</LM>
   </w.rf>
   <form>klienti</form>
   <lemma>klient</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-70_2-82">
   <w.rf>
    <LM>w#w-70_2-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-72_3">
  <m id="m027-d1t2626-1">
   <w.rf>
    <LM>w#w-d1t2626-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2626-2">
   <w.rf>
    <LM>w#w-d1t2626-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2626-3">
   <w.rf>
    <LM>w#w-d1t2626-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2626-4">
   <w.rf>
    <LM>w#w-d1t2626-4</LM>
   </w.rf>
   <form>podnik</form>
   <lemma>podnik</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m027-d1t2626-6">
   <w.rf>
    <LM>w#w-d1t2626-6</LM>
   </w.rf>
   <form>Západočeské</form>
   <lemma>západočeský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m027-d1t2626-7">
   <w.rf>
    <LM>w#w-d1t2626-7</LM>
   </w.rf>
   <form>papírny</form>
   <lemma>papírna</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m027-72_3-76_2">
   <w.rf>
    <LM>w#w-72_3-76_2</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-78_3">
  <m id="m027-d1t2626-10">
   <w.rf>
    <LM>w#w-d1t2626-10</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m027-d1t2626-11">
   <w.rf>
    <LM>w#w-d1t2626-11</LM>
   </w.rf>
   <form>pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-72-74_2">
   <w.rf>
    <LM>w#w-72-74_2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2626-13">
   <w.rf>
    <LM>w#w-d1t2626-13</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m027-d1t2626-14">
   <w.rf>
    <LM>w#w-d1t2626-14</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t2626-15">
   <w.rf>
    <LM>w#w-d1t2626-15</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2626-19">
   <w.rf>
    <LM>w#w-d1t2626-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2626-20">
   <w.rf>
    <LM>w#w-d1t2626-20</LM>
   </w.rf>
   <form>banky</form>
   <lemma>banka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t2626-18">
   <w.rf>
    <LM>w#w-d1t2626-18</LM>
   </w.rf>
   <form>pracovně</form>
   <lemma>pracovně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t2626-16">
   <w.rf>
    <LM>w#w-d1t2626-16</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d-id157868-punct">
   <w.rf>
    <LM>w#w-d-id157868-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2631-2">
   <w.rf>
    <LM>w#w-d1t2631-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2631-4">
   <w.rf>
    <LM>w#w-d1t2631-4</LM>
   </w.rf>
   <form>slíbil</form>
   <lemma>slíbit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-d-id157963-punct">
   <w.rf>
    <LM>w#w-d-id157963-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2631-6">
   <w.rf>
    <LM>w#w-d1t2631-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2631-7">
   <w.rf>
    <LM>w#w-d1t2631-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2633-2">
   <w.rf>
    <LM>w#w-d1t2633-2</LM>
   </w.rf>
   <form>pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d1t2633-5">
   <w.rf>
    <LM>w#w-d1t2633-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2633-7">
   <w.rf>
    <LM>w#w-d1t2633-7</LM>
   </w.rf>
   <form>papíren</form>
   <lemma>papírna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d1t2633-8">
   <w.rf>
    <LM>w#w-d1t2633-8</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-78_3-84">
   <w.rf>
    <LM>w#w-78_3-84</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2617-x3">
  <m id="m027-d1t2635-1">
   <w.rf>
    <LM>w#w-d1t2635-1</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2635-2">
   <w.rf>
    <LM>w#w-d1t2635-2</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m027-d1t2635-3">
   <w.rf>
    <LM>w#w-d1t2635-3</LM>
   </w.rf>
   <form>družbu</form>
   <lemma>družba-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1e2617-x3-256">
   <w.rf>
    <LM>w#w-d1e2617-x3-256</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-258">
  <m id="m027-d1t2635-11">
   <w.rf>
    <LM>w#w-d1t2635-11</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m027-d1t2635-12">
   <w.rf>
    <LM>w#w-d1t2635-12</LM>
   </w.rf>
   <form>papírna</form>
   <lemma>papírna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-d1t2635-13">
   <w.rf>
    <LM>w#w-d1t2635-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2635-16">
   <w.rf>
    <LM>w#w-d1t2635-16</LM>
   </w.rf>
   <form>Jugoslávii</form>
   <lemma>Jugoslávie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t2635-5">
   <w.rf>
    <LM>w#w-d1t2635-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2635-4">
   <w.rf>
    <LM>w#w-d1t2635-4</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m027-d1t2635-7">
   <w.rf>
    <LM>w#w-d1t2635-7</LM>
   </w.rf>
   <form>Maglai</form>
   <lemma>Maglai_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m027-258-260">
   <w.rf>
    <LM>w#w-258-260</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2635-18">
   <w.rf>
    <LM>w#w-d1t2635-18</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2635-19">
   <w.rf>
    <LM>w#w-d1t2635-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m027-d1t2635-21">
   <w.rf>
    <LM>w#w-d1t2635-21</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2635-23">
   <w.rf>
    <LM>w#w-d1t2635-23</LM>
   </w.rf>
   <form>horách</form>
   <lemma>hora</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m027-d1t2637-1">
   <w.rf>
    <LM>w#w-d1t2637-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2637-3">
   <w.rf>
    <LM>w#w-d1t2637-3</LM>
   </w.rf>
   <form>říčky</form>
   <lemma>říčka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d1t2637-5">
   <w.rf>
    <LM>w#w-d1t2637-5</LM>
   </w.rf>
   <form>Neretvy</form>
   <lemma>Neretva_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d-m-d1e2617-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2617-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2648-x2">
  <m id="m027-d1t2651-2">
   <w.rf>
    <LM>w#w-d1t2651-2</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2653-2">
   <w.rf>
    <LM>w#w-d1t2653-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m027-d1t2653-3">
   <w.rf>
    <LM>w#w-d1t2653-3</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m027-d1t2653-4">
   <w.rf>
    <LM>w#w-d1t2653-4</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m027-d1t2653-6">
   <w.rf>
    <LM>w#w-d1t2653-6</LM>
   </w.rf>
   <form>družbu</form>
   <lemma>družba-2</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d-id158811-punct">
   <w.rf>
    <LM>w#w-d-id158811-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2653-8">
   <w.rf>
    <LM>w#w-d1t2653-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2655-2">
   <w.rf>
    <LM>w#w-d1t2655-2</LM>
   </w.rf>
   <form>Jugoslávci</form>
   <lemma>Jugoslávec_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d1t2655-4">
   <w.rf>
    <LM>w#w-d1t2655-4</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2655-5">
   <w.rf>
    <LM>w#w-d1t2655-5</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2657-1">
   <w.rf>
    <LM>w#w-d1t2657-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2657-2">
   <w.rf>
    <LM>w#w-d1t2657-2</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m027-d1e2648-x2-320">
   <w.rf>
    <LM>w#w-d1e2648-x2-320</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2657-5">
   <w.rf>
    <LM>w#w-d1t2657-5</LM>
   </w.rf>
   <form>pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d1t2657-6">
   <w.rf>
    <LM>w#w-d1t2657-6</LM>
   </w.rf>
   <form>papíren</form>
   <lemma>papírna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d1e2648-x2-322">
   <w.rf>
    <LM>w#w-d1e2648-x2-322</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2657-7">
   <w.rf>
    <LM>w#w-d1t2657-7</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m027-d1t2657-8">
   <w.rf>
    <LM>w#w-d1t2657-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1e2648-x2-324">
   <w.rf>
    <LM>w#w-d1e2648-x2-324</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-326_1">
  <m id="m027-d1t2657-10">
   <w.rf>
    <LM>w#w-d1t2657-10</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2662-2">
   <w.rf>
    <LM>w#w-d1t2662-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2662-5">
   <w.rf>
    <LM>w#w-d1t2662-5</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2662-6">
   <w.rf>
    <LM>w#w-d1t2662-6</LM>
   </w.rf>
   <form>domluví</form>
   <lemma>domluvit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m027-326_1-368">
   <w.rf>
    <LM>w#w-326_1-368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2657-11">
   <w.rf>
    <LM>w#w-d1t2657-11</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m027-d1t2657-13">
   <w.rf>
    <LM>w#w-d1t2657-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2657-16">
   <w.rf>
    <LM>w#w-d1t2657-16</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m027-d1t2657-17">
   <w.rf>
    <LM>w#w-d1t2657-17</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m027-d1t2657-14">
   <w.rf>
    <LM>w#w-d1t2657-14</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2657-18">
   <w.rf>
    <LM>w#w-d1t2657-18</LM>
   </w.rf>
   <form>přidat</form>
   <lemma>přidat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m027-326_1-370">
   <w.rf>
    <LM>w#w-326_1-370</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-372">
  <m id="m027-d1t2662-8">
   <w.rf>
    <LM>w#w-d1t2662-8</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2662-9">
   <w.rf>
    <LM>w#w-d1t2662-9</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m027-d1t2662-10">
   <w.rf>
    <LM>w#w-d1t2662-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m027-d1t2662-12">
   <w.rf>
    <LM>w#w-d1t2662-12</LM>
   </w.rf>
   <form>domluvil</form>
   <lemma>domluvit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m027-372-412">
   <w.rf>
    <LM>w#w-372-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-414_2">
  <m id="m027-d1t2662-17">
   <w.rf>
    <LM>w#w-d1t2662-17</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2662-16">
   <w.rf>
    <LM>w#w-d1t2662-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2662-18">
   <w.rf>
    <LM>w#w-d1t2662-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2662-20">
   <w.rf>
    <LM>w#w-d1t2662-20</LM>
   </w.rf>
   <form>hlásit</form>
   <lemma>hlásit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t2664-1">
   <w.rf>
    <LM>w#w-d1t2664-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2664-2">
   <w.rf>
    <LM>w#w-d1t2664-2</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m027-d1t2664-3">
   <w.rf>
    <LM>w#w-d1t2664-3</LM>
   </w.rf>
   <form>pána</form>
   <lemma>pán</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m027-d1t2664-5">
   <w.rf>
    <LM>w#w-d1t2664-5</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m027-d1t2664-6">
   <w.rf>
    <LM>w#w-d1t2664-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2668-2">
   <w.rf>
    <LM>w#w-d1t2668-2</LM>
   </w.rf>
   <form>Biogradu</form>
   <lemma>Biograd_;G</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m027-d1t2668-3">
   <w.rf>
    <LM>w#w-d1t2668-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2668-4">
   <w.rf>
    <LM>w#w-d1t2668-4</LM>
   </w.rf>
   <form>moru</form>
   <lemma>moru-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m027-414_2-416">
   <w.rf>
    <LM>w#w-414_2-416</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2648-x3">
  <m id="m027-d1t2672-8">
   <w.rf>
    <LM>w#w-d1t2672-8</LM>
   </w.rf>
   <form>Oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m027-d1t2672-9">
   <w.rf>
    <LM>w#w-d1t2672-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2672-10">
   <w.rf>
    <LM>w#w-d1t2672-10</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2672-12">
   <w.rf>
    <LM>w#w-d1t2672-12</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d-id159918-punct">
   <w.rf>
    <LM>w#w-d-id159918-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2672-1">
   <w.rf>
    <LM>w#w-d1t2672-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2672-2">
   <w.rf>
    <LM>w#w-d1t2672-2</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m027-d1t2672-3">
   <w.rf>
    <LM>w#w-d1t2672-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2672-5">
   <w.rf>
    <LM>w#w-d1t2672-5</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2672-6">
   <w.rf>
    <LM>w#w-d1t2672-6</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1t2672-7">
   <w.rf>
    <LM>w#w-d1t2672-7</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m027-d1e2648-x3-422">
   <w.rf>
    <LM>w#w-d1e2648-x3-422</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2672-19">
   <w.rf>
    <LM>w#w-d1t2672-19</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2672-21">
   <w.rf>
    <LM>w#w-d1t2672-21</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m027-d1t2672-20">
   <w.rf>
    <LM>w#w-d1t2672-20</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t2672-22">
   <w.rf>
    <LM>w#w-d1t2672-22</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2677-1">
   <w.rf>
    <LM>w#w-d1t2677-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2677-2">
   <w.rf>
    <LM>w#w-d1t2677-2</LM>
   </w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d1t2677-3">
   <w.rf>
    <LM>w#w-d1t2677-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2677-4">
   <w.rf>
    <LM>w#w-d1t2677-4</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2677-7">
   <w.rf>
    <LM>w#w-d1t2677-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m027-d1t2677-8">
   <w.rf>
    <LM>w#w-d1t2677-8</LM>
   </w.rf>
   <form>vlak</form>
   <lemma>vlak</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m027-d1t2677-6">
   <w.rf>
    <LM>w#w-d1t2677-6</LM>
   </w.rf>
   <form>slevu</form>
   <lemma>sleva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-d1e2648-x3-424">
   <w.rf>
    <LM>w#w-d1e2648-x3-424</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-420">
  <m id="m027-d1t2677-11">
   <w.rf>
    <LM>w#w-d1t2677-11</LM>
   </w.rf>
   <form>Pan</form>
   <lemma>pan</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t2677-13">
   <w.rf>
    <LM>w#w-d1t2677-13</LM>
   </w.rf>
   <form>Šampalík</form>
   <lemma>Šampalík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d-id160282-punct">
   <w.rf>
    <LM>w#w-d-id160282-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2677-16">
   <w.rf>
    <LM>w#w-d1t2677-16</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m027-d1t2679-2">
   <w.rf>
    <LM>w#w-d1t2679-2</LM>
   </w.rf>
   <form>Milady</form>
   <lemma>Milada_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m027-d-id160348-punct">
   <w.rf>
    <LM>w#w-d-id160348-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2681-1">
   <w.rf>
    <LM>w#w-d1t2681-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2681-2">
   <w.rf>
    <LM>w#w-d1t2681-2</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2681-3">
   <w.rf>
    <LM>w#w-d1t2681-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2681-4">
   <w.rf>
    <LM>w#w-d1t2681-4</LM>
   </w.rf>
   <form>dráze</form>
   <lemma>dráha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m027-d-id160459-punct">
   <w.rf>
    <LM>w#w-d-id160459-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2681-6">
   <w.rf>
    <LM>w#w-d1t2681-6</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m027-d1t2681-8">
   <w.rf>
    <LM>w#w-d1t2681-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2681-9">
   <w.rf>
    <LM>w#w-d1t2681-9</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2681-10">
   <w.rf>
    <LM>w#w-d1t2681-10</LM>
   </w.rf>
   <form>slevu</form>
   <lemma>sleva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m027-420-430">
   <w.rf>
    <LM>w#w-420-430</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2681-16">
   <w.rf>
    <LM>w#w-d1t2681-16</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2681-15">
   <w.rf>
    <LM>w#w-d1t2681-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2681-17">
   <w.rf>
    <LM>w#w-d1t2681-17</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-420-428">
   <w.rf>
    <LM>w#w-420-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2648-x4">
  <m id="m027-d1t2688-2">
   <w.rf>
    <LM>w#w-d1t2688-2</LM>
   </w.rf>
   <form>Přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t2688-1">
   <w.rf>
    <LM>w#w-d1t2688-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2688-3">
   <w.rf>
    <LM>w#w-d1t2688-3</LM>
   </w.rf>
   <form>vlakem</form>
   <lemma>vlak</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1t2688-4">
   <w.rf>
    <LM>w#w-d1t2688-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2688-5">
   <w.rf>
    <LM>w#w-d1t2688-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m027-d1t2688-7">
   <w.rf>
    <LM>w#w-d1t2688-7</LM>
   </w.rf>
   <form>Splitu</form>
   <lemma>Split_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-d1t2688-9">
   <w.rf>
    <LM>w#w-d1t2688-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2688-10">
   <w.rf>
    <LM>w#w-d1t2688-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2688-11">
   <w.rf>
    <LM>w#w-d1t2688-11</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2688-12">
   <w.rf>
    <LM>w#w-d1t2688-12</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-d1t2688-13">
   <w.rf>
    <LM>w#w-d1t2688-13</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m027-d1e2648-x4-494">
   <w.rf>
    <LM>w#w-d1e2648-x4-494</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-496_2">
  <m id="m027-d1t2690-2">
   <w.rf>
    <LM>w#w-d1t2690-2</LM>
   </w.rf>
   <form>Přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t2690-3">
   <w.rf>
    <LM>w#w-d1t2690-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2690-4">
   <w.rf>
    <LM>w#w-d1t2690-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2690-8">
   <w.rf>
    <LM>w#w-d1t2690-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2690-9">
   <w.rf>
    <LM>w#w-d1t2690-9</LM>
   </w.rf>
   <form>nočních</form>
   <lemma>noční</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m027-d1t2690-10">
   <w.rf>
    <LM>w#w-d1t2690-10</LM>
   </w.rf>
   <form>hodinách</form>
   <lemma>hodina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m027-d1t2690-11">
   <w.rf>
    <LM>w#w-d1t2690-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m027-d1t2690-15">
   <w.rf>
    <LM>w#w-d1t2690-15</LM>
   </w.rf>
   <form>vydali</form>
   <lemma>vydat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m027-d1t2690-13">
   <w.rf>
    <LM>w#w-d1t2690-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2690-14">
   <w.rf>
    <LM>w#w-d1t2690-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2690-16">
   <w.rf>
    <LM>w#w-d1t2690-16</LM>
   </w.rf>
   <form>pěšky</form>
   <lemma>pěšky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2692-1">
   <w.rf>
    <LM>w#w-d1t2692-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2692-3">
   <w.rf>
    <LM>w#w-d1t2692-3</LM>
   </w.rf>
   <form>Biogradu</form>
   <lemma>Biograd_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m027-496_2-498">
   <w.rf>
    <LM>w#w-496_2-498</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-500">
  <m id="m027-d1t2694-2">
   <w.rf>
    <LM>w#w-d1t2694-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2694-3">
   <w.rf>
    <LM>w#w-d1t2694-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m027-d1t2694-5">
   <w.rf>
    <LM>w#w-d1t2694-5</LM>
   </w.rf>
   <form>hledali</form>
   <lemma>hledat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2694-12">
   <w.rf>
    <LM>w#w-d1t2694-12</LM>
   </w.rf>
   <form>Odmaraliště</form>
   <lemma>Odmaraliště_;m</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-d-id161562-punct">
   <w.rf>
    <LM>w#w-d-id161562-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-d1t2698-2">
   <w.rf>
    <LM>w#w-d1t2698-2</LM>
   </w.rf>
   <form>centrum</form>
   <lemma>centrum</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m027-500-84">
   <w.rf>
    <LM>w#w-500-84</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m027-500-82">
   <w.rf>
    <LM>w#w-500-82</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m027-d1t2696-2">
   <w.rf>
    <LM>w#w-d1t2696-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m027-d1t2696-3">
   <w.rf>
    <LM>w#w-d1t2696-3</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m027-d1t2696-4">
   <w.rf>
    <LM>w#w-d1t2696-4</LM>
   </w.rf>
   <form>jíst</form>
   <lemma>jíst</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m027-500-86">
   <w.rf>
    <LM>w#w-500-86</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m027-d1e2648-x5">
  <m id="m027-d1t2698-4">
   <w.rf>
    <LM>w#w-d1t2698-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m027-d1t2698-5">
   <w.rf>
    <LM>w#w-d1t2698-5</LM>
   </w.rf>
   <form>domcích</form>
   <lemma>domek</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m027-d1t2698-6">
   <w.rf>
    <LM>w#w-d1t2698-6</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m027-d1t2701-2">
   <w.rf>
    <LM>w#w-d1t2701-2</LM>
   </w.rf>
   <form>pracovníci</form>
   <lemma>pracovník</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m027-d1t2701-3">
   <w.rf>
    <LM>w#w-d1t2701-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m027-d1t2701-5">
   <w.rf>
    <LM>w#w-d1t2701-5</LM>
   </w.rf>
   <form>papíren</form>
   <lemma>papírna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m027-d1e2648-x5-194">
   <w.rf>
    <LM>w#w-d1e2648-x5-194</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
