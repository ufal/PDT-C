<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_973.00.w.gz" />
  </references>
 </head>
 <s id="m973-26797_03-id57881-x1">
  <m id="m973-id58345-1">
   <w.rf>
    <LM>w#w-id58345-1</LM>
   </w.rf>
   <form>Skončili</form>
   <lemma>skončit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id58345-2">
   <w.rf>
    <LM>w#w-id58345-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id58345-3">
   <w.rf>
    <LM>w#w-id58345-3</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m973-d-id54971">
   <w.rf>
    <LM>w#w-d-id54971</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58345-4">
   <w.rf>
    <LM>w#w-id58345-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id58345-6">
   <w.rf>
    <LM>w#w-id58345-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id58345-7">
   <w.rf>
    <LM>w#w-id58345-7</LM>
   </w.rf>
   <form>vyhláška</form>
   <lemma>vyhláška</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-d-id55042">
   <w.rf>
    <LM>w#w-d-id55042</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58345-8">
   <w.rf>
    <LM>w#w-id58345-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id58345-9">
   <w.rf>
    <LM>w#w-id58345-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58345-10">
   <w.rf>
    <LM>w#w-id58345-10</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m973-id58345-11">
   <w.rf>
    <LM>w#w-id58345-11</LM>
   </w.rf>
   <form>hlásit</form>
   <lemma>hlásit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-d-id55107">
   <w.rf>
    <LM>w#w-d-id55107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id57881-x1-75">
   <w.rf>
    <LM>w#w-id57881-x1-75</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id57881-x1-76">
   <w.rf>
    <LM>w#w-id57881-x1-76</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58349-x1">
  <m id="m973-id58349-x1-527">
   <w.rf>
    <LM>w#w-id58349-x1-527</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58349-x1-528">
   <w.rf>
    <LM>w#w-id58349-x1-528</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58349-x1-529">
   <w.rf>
    <LM>w#w-id58349-x1-529</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58365-1">
   <w.rf>
    <LM>w#w-id58365-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m973-id58365-2">
   <w.rf>
    <LM>w#w-id58365-2</LM>
   </w.rf>
   <form>registraci</form>
   <lemma>registrace</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m973-d-id55148">
   <w.rf>
    <LM>w#w-d-id55148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58367-x1">
  <m id="m973-id58388-1">
   <w.rf>
    <LM>w#w-id58388-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58388-2">
   <w.rf>
    <LM>w#w-id58388-2</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id58388-3">
   <w.rf>
    <LM>w#w-id58388-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-d-id55322">
   <w.rf>
    <LM>w#w-d-id55322</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58367-x2">
  <m id="m973-id58401-1">
   <w.rf>
    <LM>w#w-id58401-1</LM>
   </w.rf>
   <form>Všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m973-id58367-x2-6782">
   <w.rf>
    <LM>w#w-id58367-x2-6782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58401-2">
   <w.rf>
    <LM>w#w-id58401-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id58401-3">
   <w.rf>
    <LM>w#w-id58401-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58367-x2-299">
   <w.rf>
    <LM>w#w-id58367-x2-299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58367-x2-300">
   <w.rf>
    <LM>w#w-id58367-x2-300</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58367-x2-298">
   <w.rf>
    <LM>w#w-id58367-x2-298</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-293">
  <m id="m973-id58415-1">
   <w.rf>
    <LM>w#w-id58415-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-293-539">
   <w.rf>
    <LM>w#w-293-539</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58415-3">
   <w.rf>
    <LM>w#w-id58415-3</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m973-293-993">
   <w.rf>
    <LM>w#w-293-993</LM>
   </w.rf>
   <form>občané</form>
   <lemma>občan</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m973-293-995">
   <w.rf>
    <LM>w#w-293-995</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58452-2">
   <w.rf>
    <LM>w#w-id58452-2</LM>
   </w.rf>
   <form>emigranti</form>
   <lemma>emigrant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m973-id58452-3">
   <w.rf>
    <LM>w#w-id58452-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id58452-4">
   <w.rf>
    <LM>w#w-id58452-4</LM>
   </w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m973-id58452-5">
   <w.rf>
    <LM>w#w-id58452-5</LM>
   </w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m973-293-996">
   <w.rf>
    <LM>w#w-293-996</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58457-1">
   <w.rf>
    <LM>w#w-id58457-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58457-2">
   <w.rf>
    <LM>w#w-id58457-2</LM>
   </w.rf>
   <form>maji</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI-7</tag>
  </m>
  <m id="m973-id58457-4">
   <w.rf>
    <LM>w#w-id58457-4</LM>
   </w.rf>
   <form>hlásit</form>
   <lemma>hlásit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-id58457-5">
   <w.rf>
    <LM>w#w-id58457-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58457-6">
   <w.rf>
    <LM>w#w-id58457-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id58457-7">
   <w.rf>
    <LM>w#w-id58457-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58457-9">
   <w.rf>
    <LM>w#w-id58457-9</LM>
   </w.rf>
   <form>řečeno</form>
   <lemma>říci</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m973-id58457-11">
   <w.rf>
    <LM>w#w-id58457-11</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58457-10">
   <w.rf>
    <LM>w#w-id58457-10</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-293-998">
   <w.rf>
    <LM>w#w-293-998</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1279">
  <m id="m973-id58485-3">
   <w.rf>
    <LM>w#w-id58485-3</LM>
   </w.rf>
   <form>Náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m973-id58485-4">
   <w.rf>
    <LM>w#w-id58485-4</LM>
   </w.rf>
   <form>objekt</form>
   <lemma>objekt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-d-id55928">
   <w.rf>
    <LM>w#w-d-id55928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58485-5">
   <w.rf>
    <LM>w#w-id58485-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58485-6">
   <w.rf>
    <LM>w#w-id58485-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id58485-7">
   <w.rf>
    <LM>w#w-id58485-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id58485-8">
   <w.rf>
    <LM>w#w-id58485-8</LM>
   </w.rf>
   <form>ubytovaní</form>
   <lemma>ubytovaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m973-1279-1286">
   <w.rf>
    <LM>w#w-1279-1286</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58495-1">
   <w.rf>
    <LM>w#w-id58495-1</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58495-2">
   <w.rf>
    <LM>w#w-id58495-2</LM>
   </w.rf>
   <form>vyhrazenu</form>
   <lemma>vyhradit</lemma>
   <tag>VsFS4---X-APP--</tag>
  </m>
  <m id="m973-id58495-3">
   <w.rf>
    <LM>w#w-id58495-3</LM>
   </w.rf>
   <form>určitou</form>
   <lemma>určitý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m973-id58495-4">
   <w.rf>
    <LM>w#w-id58495-4</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-d-id56070">
   <w.rf>
    <LM>w#w-d-id56070</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58505-1">
   <w.rf>
    <LM>w#w-id58505-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58505-2">
   <w.rf>
    <LM>w#w-id58505-2</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58505-9">
   <w.rf>
    <LM>w#w-id58505-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id58505-6">
   <w.rf>
    <LM>w#w-id58505-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id58505-8">
   <w.rf>
    <LM>w#w-id58505-8</LM>
   </w.rf>
   <form>půlhodinách</form>
   <lemma>půlhodina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m973-1279-1293">
   <w.rf>
    <LM>w#w-1279-1293</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id58515-1">
   <w.rf>
    <LM>w#w-id58515-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-1279-1294">
   <w.rf>
    <LM>w#w-1279-1294</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id58505-3">
   <w.rf>
    <LM>w#w-id58505-3</LM>
   </w.rf>
   <form>jednotlivě</form>
   <lemma>jednotlivě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58515-2">
   <w.rf>
    <LM>w#w-id58515-2</LM>
   </w.rf>
   <form>dostavit</form>
   <lemma>dostavit_^(se,na_dané_místo)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id58524-1">
   <w.rf>
    <LM>w#w-id58524-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id58524-6">
   <w.rf>
    <LM>w#w-id58524-6</LM>
   </w.rf>
   <form>milici</form>
   <lemma>milice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-1279-539">
   <w.rf>
    <LM>w#w-1279-539</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-540">
  <m id="m973-540-541">
   <w.rf>
    <LM>w#w-540-541</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58524-4">
   <w.rf>
    <LM>w#w-id58524-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id58524-5">
   <w.rf>
    <LM>w#w-id58524-5</LM>
   </w.rf>
   <form>řikali</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-1279-1296">
   <w.rf>
    <LM>w#w-1279-1296</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58534-1">
   <w.rf>
    <LM>w#w-id58534-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id58534-2">
   <w.rf>
    <LM>w#w-id58534-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58534-3">
   <w.rf>
    <LM>w#w-id58534-3</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id58534-4">
   <w.rf>
    <LM>w#w-id58534-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58534-5">
   <w.rf>
    <LM>w#w-id58534-5</LM>
   </w.rf>
   <form>tehdejší</form>
   <lemma>tehdejší</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id58543-1">
   <w.rf>
    <LM>w#w-id58543-1</LM>
   </w.rf>
   <form>NKVD</form>
   <lemma>NKVD-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m973-1279-1350">
   <w.rf>
    <LM>w#w-1279-1350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1344">
  <m id="m973-id58543-5">
   <w.rf>
    <LM>w#w-id58543-5</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58543-6">
   <w.rf>
    <LM>w#w-id58543-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-1279-1301">
   <w.rf>
    <LM>w#w-1279-1301</LM>
   </w.rf>
   <form>nástupkyně</form>
   <lemma>nástupkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id58553-1">
   <w.rf>
    <LM>w#w-id58553-1</LM>
   </w.rf>
   <form>původní</form>
   <lemma>původní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m973-1279-1302">
   <w.rf>
    <LM>w#w-1279-1302</LM>
   </w.rf>
   <form>Čeky</form>
   <lemma>Čeka_;m</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m973-id58562-1">
   <w.rf>
    <LM>w#w-id58562-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58562-2">
   <w.rf>
    <LM>w#w-id58562-2</LM>
   </w.rf>
   <form>předchůdkyně</form>
   <lemma>předchůdkyně_^(*4ce)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id58562-3">
   <w.rf>
    <LM>w#w-id58562-3</LM>
   </w.rf>
   <form>KGB</form>
   <lemma>KGB_;m_^(Sov._státní_tajná_bezpečnost)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m973-1279-1309">
   <w.rf>
    <LM>w#w-1279-1309</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58562-7">
   <w.rf>
    <LM>w#w-id58562-7</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m973-id58562-8">
   <w.rf>
    <LM>w#w-id58562-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id58562-9">
   <w.rf>
    <LM>w#w-id58562-9</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id58562-10">
   <w.rf>
    <LM>w#w-id58562-10</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-1279-1308">
   <w.rf>
    <LM>w#w-1279-1308</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1310">
  <m id="m973-id58582-1">
   <w.rf>
    <LM>w#w-id58582-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id58582-2">
   <w.rf>
    <LM>w#w-id58582-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58582-3">
   <w.rf>
    <LM>w#w-id58582-3</LM>
   </w.rf>
   <form>víceméně</form>
   <lemma>víceméně</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58582-4">
   <w.rf>
    <LM>w#w-id58582-4</LM>
   </w.rf>
   <form>tajná</form>
   <lemma>tajný-1</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id58582-5">
   <w.rf>
    <LM>w#w-id58582-5</LM>
   </w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-1310-1343">
   <w.rf>
    <LM>w#w-1310-1343</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58582-8">
   <w.rf>
    <LM>w#w-id58582-8</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m973-id58582-7">
   <w.rf>
    <LM>w#w-id58582-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58582-9">
   <w.rf>
    <LM>w#w-id58582-9</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m973-d-id55635">
   <w.rf>
    <LM>w#w-d-id55635</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-1310-1826">
   <w.rf>
    <LM>w#w-1310-1826</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58618-1">
   <w.rf>
    <LM>w#w-id58618-1</LM>
   </w.rf>
   <form>státní</form>
   <lemma>státní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id58618-2">
   <w.rf>
    <LM>w#w-id58618-2</LM>
   </w.rf>
   <form>policie</form>
   <lemma>policie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-1310-1828">
   <w.rf>
    <LM>w#w-1310-1828</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1878">
  <m id="m973-id58627-2">
   <w.rf>
    <LM>w#w-id58627-2</LM>
   </w.rf>
   <form>Zapomněl</form>
   <lemma>zapomenout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id58627-1">
   <w.rf>
    <LM>w#w-id58627-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id58627-3">
   <w.rf>
    <LM>w#w-id58627-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m973-1878-545">
   <w.rf>
    <LM>w#w-1878-545</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-1878-546">
   <w.rf>
    <LM>w#w-1878-546</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-1878-547">
   <w.rf>
    <LM>w#w-1878-547</LM>
   </w.rf>
   <form>mezitím</form>
   <lemma>mezitím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-1878-548">
   <w.rf>
    <LM>w#w-1878-548</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-1878-549">
   <w.rf>
    <LM>w#w-1878-549</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-1878-550">
   <w.rf>
    <LM>w#w-1878-550</LM>
   </w.rf>
   <form>GPU</form>
   <lemma>GPU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m973-1878-1885">
   <w.rf>
    <LM>w#w-1878-1885</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1873">
  <m id="m973-1873-1887">
   <w.rf>
    <LM>w#w-1873-1887</LM>
   </w.rf>
   <form>GPU</form>
   <lemma>GPU-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m973-id58641-4">
   <w.rf>
    <LM>w#w-id58641-4</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58641-5">
   <w.rf>
    <LM>w#w-id58641-5</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-d-id57009">
   <w.rf>
    <LM>w#w-d-id57009</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1790">
  <m id="m973-1790-1806">
   <w.rf>
    <LM>w#w-1790-1806</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-1790-1807">
   <w.rf>
    <LM>w#w-1790-1807</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m973-1790-1808">
   <w.rf>
    <LM>w#w-1790-1808</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-1790-1817">
   <w.rf>
    <LM>w#w-1790-1817</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m973-1790-1810">
   <w.rf>
    <LM>w#w-1790-1810</LM>
   </w.rf>
   <form>organizace</form>
   <lemma>organizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m973-d-id57332">
   <w.rf>
    <LM>w#w-d-id57332</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1853">
  <m id="m973-id58641-8">
   <w.rf>
    <LM>w#w-id58641-8</LM>
   </w.rf>
   <form>Přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58641-9">
   <w.rf>
    <LM>w#w-id58641-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-1853-1858">
   <w.rf>
    <LM>w#w-1853-1858</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58641-10">
   <w.rf>
    <LM>w#w-id58641-10</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-1853-5094">
   <w.rf>
    <LM>w#w-1853-5094</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58671-x1">
  <m id="m973-id58696-2">
   <w.rf>
    <LM>w#w-id58696-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58696-3">
   <w.rf>
    <LM>w#w-id58696-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58696-4">
   <w.rf>
    <LM>w#w-id58696-4</LM>
   </w.rf>
   <form>týkalo</form>
   <lemma>týkat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id58705-1">
   <w.rf>
    <LM>w#w-id58705-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id58714-1">
   <w.rf>
    <LM>w#w-id58714-1</LM>
   </w.rf>
   <form>občanů</form>
   <lemma>občan</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-id58714-2">
   <w.rf>
    <LM>w#w-id58714-2</LM>
   </w.rf>
   <form>generálního</form>
   <lemma>generální</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m973-id58714-3">
   <w.rf>
    <LM>w#w-id58714-3</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>gouvernementu</form>
   <lemma>gouvernement</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id58671-x1-112">
   <w.rf>
    <LM>w#w-id58671-x1-112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58714-4">
   <w.rf>
    <LM>w#w-id58714-4</LM>
   </w.rf>
   <form>neboli</form>
   <lemma>neboli</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58714-6">
   <w.rf>
    <LM>w#w-id58714-6</LM>
   </w.rf>
   <form>Poláků</form>
   <lemma>Polák_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-id58671-x1-6811">
   <w.rf>
    <LM>w#w-id58671-x1-6811</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58714-7">
   <w.rf>
    <LM>w#w-id58714-7</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m973-id58714-8">
   <w.rf>
    <LM>w#w-id58714-8</LM>
   </w.rf>
   <form>utekli</form>
   <lemma>utéci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id58671-x1-2134">
   <w.rf>
    <LM>w#w-id58671-x1-2134</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id58671-x1-2135">
   <w.rf>
    <LM>w#w-id58671-x1-2135</LM>
   </w.rf>
   <form>západ</form>
   <lemma>západ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-d-id57404">
   <w.rf>
    <LM>w#w-d-id57404</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x1">
  <m id="m973-id58742-3">
   <w.rf>
    <LM>w#w-id58742-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id58742-2">
   <w.rf>
    <LM>w#w-id58742-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m973-id58742-4">
   <w.rf>
    <LM>w#w-id58742-4</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m973-id58742-5">
   <w.rf>
    <LM>w#w-id58742-5</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-d-id57793">
   <w.rf>
    <LM>w#w-d-id57793</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58742-6">
   <w.rf>
    <LM>w#w-id58742-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id58752-3">
   <w.rf>
    <LM>w#w-id58752-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58752-4">
   <w.rf>
    <LM>w#w-id58752-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58752-5">
   <w.rf>
    <LM>w#w-id58752-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id58752-6">
   <w.rf>
    <LM>w#w-id58752-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id58752-7">
   <w.rf>
    <LM>w#w-id58752-7</LM>
   </w.rf>
   <form>nezajímal</form>
   <lemma>zajímat</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-id58727-x1-555">
   <w.rf>
    <LM>w#w-id58727-x1-555</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-556">
  <m id="m973-id58762-4">
   <w.rf>
    <LM>w#w-id58762-4</LM>
   </w.rf>
   <form>Zajímal</form>
   <lemma>zajímat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-556-557">
   <w.rf>
    <LM>w#w-556-557</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58762-2">
   <w.rf>
    <LM>w#w-id58762-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58762-3">
   <w.rf>
    <LM>w#w-id58762-3</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58762-5">
   <w.rf>
    <LM>w#w-id58762-5</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id58762-7">
   <w.rf>
    <LM>w#w-id58762-7</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-d-id58047">
   <w.rf>
    <LM>w#w-d-id58047</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58762-8">
   <w.rf>
    <LM>w#w-id58762-8</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58762-9">
   <w.rf>
    <LM>w#w-id58762-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58762-10">
   <w.rf>
    <LM>w#w-id58762-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58762-12">
   <w.rf>
    <LM>w#w-id58762-12</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58762-13">
   <w.rf>
    <LM>w#w-id58762-13</LM>
   </w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id58762-14">
   <w.rf>
    <LM>w#w-id58762-14</LM>
   </w.rf>
   <form>sám</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m973-d-id58167">
   <w.rf>
    <LM>w#w-d-id58167</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x2">
  <m id="m973-id58727-x2-563">
   <w.rf>
    <LM>w#w-id58727-x2-563</LM>
   </w.rf>
   <form>Chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id58727-x2-564">
   <w.rf>
    <LM>w#w-id58727-x2-564</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58777-3">
   <w.rf>
    <LM>w#w-id58777-3</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m973-id58727-x2-390">
   <w.rf>
    <LM>w#w-id58727-x2-390</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id58777-4">
   <w.rf>
    <LM>w#w-id58777-4</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m973-id58777-5">
   <w.rf>
    <LM>w#w-id58777-5</LM>
   </w.rf>
   <form>přivezl</form>
   <lemma>přivézt</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id58727-x2-392">
   <w.rf>
    <LM>w#w-id58727-x2-392</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id58777-7">
   <w.rf>
    <LM>w#w-id58777-7</LM>
   </w.rf>
   <form>doklady</form>
   <lemma>doklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m973-id58777-8">
   <w.rf>
    <LM>w#w-id58777-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58777-9">
   <w.rf>
    <LM>w#w-id58777-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58777-10">
   <w.rf>
    <LM>w#w-id58777-10</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58777-11">
   <w.rf>
    <LM>w#w-id58777-11</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x2-565">
   <w.rf>
    <LM>w#w-id58727-x2-565</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58777-13">
   <w.rf>
    <LM>w#w-id58777-13</LM>
   </w.rf>
   <form>neměl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-id58727-x2-566">
   <w.rf>
    <LM>w#w-id58727-x2-566</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58777-14">
   <w.rf>
    <LM>w#w-id58777-14</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id58777-15">
   <w.rf>
    <LM>w#w-id58777-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m973-d-id58437">
   <w.rf>
    <LM>w#w-d-id58437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-397">
  <m id="m973-397-573">
   <w.rf>
    <LM>w#w-397-573</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id58787-3">
   <w.rf>
    <LM>w#w-id58787-3</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-397-6854">
   <w.rf>
    <LM>w#w-397-6854</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58787-4">
   <w.rf>
    <LM>w#w-id58787-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m973-id58787-5">
   <w.rf>
    <LM>w#w-id58787-5</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id58787-6">
   <w.rf>
    <LM>w#w-id58787-6</LM>
   </w.rf>
   <form>doklady</form>
   <lemma>doklad</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m973-397-448">
   <w.rf>
    <LM>w#w-397-448</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-397-452">
   <w.rf>
    <LM>w#w-397-452</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58787-7">
   <w.rf>
    <LM>w#w-id58787-7</LM>
   </w.rf>
   <form>pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58797-1">
   <w.rf>
    <LM>w#w-id58797-1</LM>
   </w.rf>
   <form>probíhalo</form>
   <lemma>probíhat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id58797-2">
   <w.rf>
    <LM>w#w-id58797-2</LM>
   </w.rf>
   <form>rychleji</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m973-id58797-3">
   <w.rf>
    <LM>w#w-id58797-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58806-1">
   <w.rf>
    <LM>w#w-id58806-1</LM>
   </w.rf>
   <form>bez</form>
   <lemma>bez-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id58806-2">
   <w.rf>
    <LM>w#w-id58806-2</LM>
   </w.rf>
   <form>problémů</form>
   <lemma>problém</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m973-d-id58661">
   <w.rf>
    <LM>w#w-d-id58661</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58816-1">
   <w.rf>
    <LM>w#w-id58816-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58816-2">
   <w.rf>
    <LM>w#w-id58816-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m973-id58816-3">
   <w.rf>
    <LM>w#w-id58816-3</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m973-id58816-4">
   <w.rf>
    <LM>w#w-id58816-4</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m973-id58816-5">
   <w.rf>
    <LM>w#w-id58816-5</LM>
   </w.rf>
   <form>problém</form>
   <lemma>problém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id58816-6">
   <w.rf>
    <LM>w#w-id58816-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-d-id58787">
   <w.rf>
    <LM>w#w-d-id58787</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x3">
  <m id="m973-id58830-1">
   <w.rf>
    <LM>w#w-id58830-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id58830-2">
   <w.rf>
    <LM>w#w-id58830-2</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id58830-3">
   <w.rf>
    <LM>w#w-id58830-3</LM>
   </w.rf>
   <form>věřit</form>
   <lemma>věřit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-d-id58875">
   <w.rf>
    <LM>w#w-d-id58875</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58830-4">
   <w.rf>
    <LM>w#w-id58830-4</LM>
   </w.rf>
   <form>nemuseli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m973-id58830-5">
   <w.rf>
    <LM>w#w-id58830-5</LM>
   </w.rf>
   <form>věřit</form>
   <lemma>věřit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-d-id58915">
   <w.rf>
    <LM>w#w-d-id58915</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x4">
  <m id="m973-id58844-2">
   <w.rf>
    <LM>w#w-id58844-2</LM>
   </w.rf>
   <form>Nejprve</form>
   <lemma>nejprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58854-4">
   <w.rf>
    <LM>w#w-id58854-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m973-id58854-2">
   <w.rf>
    <LM>w#w-id58854-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58854-3">
   <w.rf>
    <LM>w#w-id58854-3</LM>
   </w.rf>
   <form>vyslýchal</form>
   <lemma>vyslýchat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58854-5">
   <w.rf>
    <LM>w#w-id58854-5</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m973-id58854-6">
   <w.rf>
    <LM>w#w-id58854-6</LM>
   </w.rf>
   <form>major</form>
   <lemma>major</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-d-id59097">
   <w.rf>
    <LM>w#w-d-id59097</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x5">
  <m id="m973-id58868-1">
   <w.rf>
    <LM>w#w-id58868-1</LM>
   </w.rf>
   <form>Tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m973-id58868-2">
   <w.rf>
    <LM>w#w-id58868-2</LM>
   </w.rf>
   <form>hodnost</form>
   <lemma>hodnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-id58868-3">
   <w.rf>
    <LM>w#w-id58868-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58868-4">
   <w.rf>
    <LM>w#w-id58868-4</LM>
   </w.rf>
   <form>znal</form>
   <lemma>znát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-d-id59200">
   <w.rf>
    <LM>w#w-d-id59200</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58868-5">
   <w.rf>
    <LM>w#w-id58868-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id58868-6">
   <w.rf>
    <LM>w#w-id58868-6</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m973-id58868-7">
   <w.rf>
    <LM>w#w-id58868-7</LM>
   </w.rf>
   <form>označil</form>
   <lemma>označit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id58727-x5-1243">
   <w.rf>
    <LM>w#w-id58727-x5-1243</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58868-9">
   <w.rf>
    <LM>w#w-id58868-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58868-10">
   <w.rf>
    <LM>w#w-id58868-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id58868-11">
   <w.rf>
    <LM>w#w-id58868-11</LM>
   </w.rf>
   <form>uniformě</form>
   <lemma>uniforma</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id58727-x5-1244">
   <w.rf>
    <LM>w#w-id58727-x5-1244</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1245">
  <m id="m973-id58883-3">
   <w.rf>
    <LM>w#w-id58883-3</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58883-2">
   <w.rf>
    <LM>w#w-id58883-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58883-4">
   <w.rf>
    <LM>w#w-id58883-4</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58883-5">
   <w.rf>
    <LM>w#w-id58883-5</LM>
   </w.rf>
   <form>hendikep</form>
   <lemma>hendikep</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-1245-1252">
   <w.rf>
    <LM>w#w-1245-1252</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58883-6">
   <w.rf>
    <LM>w#w-id58883-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id58883-7">
   <w.rf>
    <LM>w#w-id58883-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58883-8">
   <w.rf>
    <LM>w#w-id58883-8</LM>
   </w.rf>
   <form>neuměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-id58883-9">
   <w.rf>
    <LM>w#w-id58883-9</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58883-10">
   <w.rf>
    <LM>w#w-id58883-10</LM>
   </w.rf>
   <form>rusky</form>
   <lemma>rusky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58883-11">
   <w.rf>
    <LM>w#w-id58883-11</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58883-12">
   <w.rf>
    <LM>w#w-id58883-12</LM>
   </w.rf>
   <form>ukrajinsky</form>
   <lemma>ukrajinsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58883-13">
   <w.rf>
    <LM>w#w-id58883-13</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58883-14">
   <w.rf>
    <LM>w#w-id58883-14</LM>
   </w.rf>
   <form>polsky</form>
   <lemma>polsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58883-16">
   <w.rf>
    <LM>w#w-id58883-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58883-17">
   <w.rf>
    <LM>w#w-id58883-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id58883-18">
   <w.rf>
    <LM>w#w-id58883-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id58883-19">
   <w.rf>
    <LM>w#w-id58883-19</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m973-id58883-20">
   <w.rf>
    <LM>w#w-id58883-20</LM>
   </w.rf>
   <form>hatmatilka</form>
   <lemma>hatmatilka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-1245-592">
   <w.rf>
    <LM>w#w-1245-592</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-593">
  <m id="m973-id58894-4">
   <w.rf>
    <LM>w#w-id58894-4</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58894-5">
   <w.rf>
    <LM>w#w-id58894-5</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id58894-6">
   <w.rf>
    <LM>w#w-id58894-6</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m973-id58904-2">
   <w.rf>
    <LM>w#w-id58904-2</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m973-id58904-3">
   <w.rf>
    <LM>w#w-id58904-3</LM>
   </w.rf>
   <form>dvoustránkových</form>
   <lemma>dvoustránkový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m973-id58904-4">
   <w.rf>
    <LM>w#w-id58904-4</LM>
   </w.rf>
   <form>dotazníků</form>
   <lemma>dotazník</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m973-d-id59868">
   <w.rf>
    <LM>w#w-d-id59868</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-1257">
  <m id="m973-id58914-3">
   <w.rf>
    <LM>w#w-id58914-3</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id58914-4">
   <w.rf>
    <LM>w#w-id58914-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58914-5">
   <w.rf>
    <LM>w#w-id58914-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m973-id58914-6">
   <w.rf>
    <LM>w#w-id58914-6</LM>
   </w.rf>
   <form>rozuměl</form>
   <lemma>rozumět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58923-1">
   <w.rf>
    <LM>w#w-id58923-1</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id58923-2">
   <w.rf>
    <LM>w#w-id58923-2</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58923-3">
   <w.rf>
    <LM>w#w-id58923-3</LM>
   </w.rf>
   <form>příjmení</form>
   <lemma>příjmení</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id58923-4">
   <w.rf>
    <LM>w#w-id58923-4</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58933-1">
   <w.rf>
    <LM>w#w-id58933-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58933-2">
   <w.rf>
    <LM>w#w-id58933-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58933-3">
   <w.rf>
    <LM>w#w-id58933-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58933-4">
   <w.rf>
    <LM>w#w-id58933-4</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id58933-5">
   <w.rf>
    <LM>w#w-id58933-5</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58933-6">
   <w.rf>
    <LM>w#w-id58933-6</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58933-7">
   <w.rf>
    <LM>w#w-id58933-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58933-8">
   <w.rf>
    <LM>w#w-id58933-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58933-9">
   <w.rf>
    <LM>w#w-id58933-9</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-d-id60185">
   <w.rf>
    <LM>w#w-d-id60185</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58933-11">
   <w.rf>
    <LM>w#w-id58933-11</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-id58933-14">
   <w.rf>
    <LM>w#w-id58933-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-1257-4543">
   <w.rf>
    <LM>w#w-1257-4543</LM>
   </w.rf>
   <form>otázky</form>
   <lemma>otázka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-id58933-15">
   <w.rf>
    <LM>w#w-id58933-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id58933-16">
   <w.rf>
    <LM>w#w-id58933-16</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m973-id58933-17">
   <w.rf>
    <LM>w#w-id58933-17</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58933-18">
   <w.rf>
    <LM>w#w-id58933-18</LM>
   </w.rf>
   <form>sourozence</form>
   <lemma>sourozenec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m973-id58943-1">
   <w.rf>
    <LM>w#w-id58943-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58943-2">
   <w.rf>
    <LM>w#w-id58943-2</LM>
   </w.rf>
   <form>příbuzenstvo</form>
   <lemma>příbuzenstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id58943-4">
   <w.rf>
    <LM>w#w-id58943-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id58943-5">
   <w.rf>
    <LM>w#w-id58943-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58943-6">
   <w.rf>
    <LM>w#w-id58943-6</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-d-id60437">
   <w.rf>
    <LM>w#w-d-id60437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-4537">
  <m id="m973-id58963-1">
   <w.rf>
    <LM>w#w-id58963-1</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m973-id58972-1">
   <w.rf>
    <LM>w#w-id58972-1</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id58972-2">
   <w.rf>
    <LM>w#w-id58972-2</LM>
   </w.rf>
   <form>nastala</form>
   <lemma>nastat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m973-id58972-3">
   <w.rf>
    <LM>w#w-id58972-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id58972-4">
   <w.rf>
    <LM>w#w-id58972-4</LM>
   </w.rf>
   <form>okamžiku</form>
   <lemma>okamžik</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-d-id60652">
   <w.rf>
    <LM>w#w-d-id60652</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58991-1">
   <w.rf>
    <LM>w#w-id58991-1</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58991-2">
   <w.rf>
    <LM>w#w-id58991-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id58991-3">
   <w.rf>
    <LM>w#w-id58991-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id58991-4">
   <w.rf>
    <LM>w#w-id58991-4</LM>
   </w.rf>
   <form>směju</form>
   <lemma>smát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-d-id60740">
   <w.rf>
    <LM>w#w-d-id60740</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58991-6">
   <w.rf>
    <LM>w#w-id58991-6</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id58991-7">
   <w.rf>
    <LM>w#w-id58991-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59000-1">
   <w.rf>
    <LM>w#w-id59000-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59000-2">
   <w.rf>
    <LM>w#w-id59000-2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id59000-3">
   <w.rf>
    <LM>w#w-id59000-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id59000-4">
   <w.rf>
    <LM>w#w-id59000-4</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59000-5">
   <w.rf>
    <LM>w#w-id59000-5</LM>
   </w.rf>
   <form>nesmál</form>
   <lemma>smát</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-d-id60869">
   <w.rf>
    <LM>w#w-d-id60869</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59024-1">
   <w.rf>
    <LM>w#w-id59024-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59024-2">
   <w.rf>
    <LM>w#w-id59024-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59024-3">
   <w.rf>
    <LM>w#w-id59024-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m973-id59024-4">
   <w.rf>
    <LM>w#w-id59024-4</LM>
   </w.rf>
   <form>ptal</form>
   <lemma>ptát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59042-1">
   <w.rf>
    <LM>w#w-id59042-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59042-2">
   <w.rf>
    <LM>w#w-id59042-2</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id59042-3">
   <w.rf>
    <LM>w#w-id59042-3</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m973-id59042-4">
   <w.rf>
    <LM>w#w-id59042-4</LM>
   </w.rf>
   <form>otce</form>
   <lemma>otec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m973-d-id61132">
   <w.rf>
    <LM>w#w-d-id61132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x7">
  <m id="m973-id59075-1">
   <w.rf>
    <LM>w#w-id59075-1</LM>
   </w.rf>
   <form>Neuměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-id59066-3">
   <w.rf>
    <LM>w#w-id59066-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59075-2">
   <w.rf>
    <LM>w#w-id59075-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m973-id59075-3">
   <w.rf>
    <LM>w#w-id59075-3</LM>
   </w.rf>
   <form>rusky</form>
   <lemma>rusky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id59075-4">
   <w.rf>
    <LM>w#w-id59075-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59075-5">
   <w.rf>
    <LM>w#w-id59075-5</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-d-id61315">
   <w.rf>
    <LM>w#w-d-id61315</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59075-6">
   <w.rf>
    <LM>w#w-id59075-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59075-7">
   <w.rf>
    <LM>w#w-id59075-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59075-8">
   <w.rf>
    <LM>w#w-id59075-8</LM>
   </w.rf>
   <form>obchodní</form>
   <lemma>obchodní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m973-id59075-9">
   <w.rf>
    <LM>w#w-id59075-9</LM>
   </w.rf>
   <form>cestující</form>
   <lemma>cestující-2</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-id58727-x7-621">
   <w.rf>
    <LM>w#w-id58727-x7-621</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-622">
  <m id="m973-id59085-7">
   <w.rf>
    <LM>w#w-id59085-7</LM>
   </w.rf>
   <form>Pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59085-4">
   <w.rf>
    <LM>w#w-id59085-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59085-5">
   <w.rf>
    <LM>w#w-id59085-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id59085-6">
   <w.rf>
    <LM>w#w-id59085-6</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59085-9">
   <w.rf>
    <LM>w#w-id59085-9</LM>
   </w.rf>
   <form>obratem</form>
   <lemma>obrat-1_^(z_prodeje_zboží)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m973-d-id61537">
   <w.rf>
    <LM>w#w-d-id61537</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59085-10">
   <w.rf>
    <LM>w#w-id59085-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59085-11">
   <w.rf>
    <LM>w#w-id59085-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59085-12">
   <w.rf>
    <LM>w#w-id59085-12</LM>
   </w.rf>
   <form>povídal</form>
   <lemma>povídat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-622-628">
   <w.rf>
    <LM>w#w-622-628</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-622-629">
   <w.rf>
    <LM>w#w-622-629</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x7-5975">
   <w.rf>
    <LM>w#w-id58727-x7-5975</LM>
   </w.rf>
   <form>Otěc</form>
   <lemma>Otěc-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id58727-x7-5976">
   <w.rf>
    <LM>w#w-id58727-x7-5976</LM>
   </w.rf>
   <form>jechal</form>
   <lemma>jechat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id58727-x7-5977">
   <w.rf>
    <LM>w#w-id58727-x7-5977</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id58727-x7-5978">
   <w.rf>
    <LM>w#w-id58727-x7-5978</LM>
   </w.rf>
   <form>tovarom</form>
   <lemma>tovar</lemma>
   <tag>NNIS7-----A---6</tag>
  </m>
  <m id="m973-d-id61610">
   <w.rf>
    <LM>w#w-d-id61610</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-622-630">
   <w.rf>
    <LM>w#w-622-630</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x8">
  <m id="m973-id59118-2">
   <w.rf>
    <LM>w#w-id59118-2</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m973-id59118-3">
   <w.rf>
    <LM>w#w-id59118-3</LM>
   </w.rf>
   <form>major</form>
   <lemma>major</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-id59118-4">
   <w.rf>
    <LM>w#w-id59118-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59118-5">
   <w.rf>
    <LM>w#w-id59118-5</LM>
   </w.rf>
   <form>zamyslil</form>
   <lemma>zamyslit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59118-6">
   <w.rf>
    <LM>w#w-id59118-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59118-7">
   <w.rf>
    <LM>w#w-id59118-7</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id58727-x8-634">
   <w.rf>
    <LM>w#w-id58727-x8-634</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x8-635">
   <w.rf>
    <LM>w#w-id58727-x8-635</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x8-5983">
   <w.rf>
    <LM>w#w-id58727-x8-5983</LM>
   </w.rf>
   <form>Izvozčikom</form>
   <lemma>Izvozčikom-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id58727-x8-5984">
   <w.rf>
    <LM>w#w-id58727-x8-5984</LM>
   </w.rf>
   <form>rabotal</form>
   <lemma>rabotal-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id58727-x8-636">
   <w.rf>
    <LM>w#w-id58727-x8-636</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x8-637">
   <w.rf>
    <LM>w#w-id58727-x8-637</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-638">
  <m id="m973-id59133-6">
   <w.rf>
    <LM>w#w-id59133-6</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59133-5">
   <w.rf>
    <LM>w#w-id59133-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id58727-x8-1069">
   <w.rf>
    <LM>w#w-id58727-x8-1069</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x8-1070">
   <w.rf>
    <LM>w#w-id58727-x8-1070</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59133-7">
   <w.rf>
    <LM>w#w-id59133-7</LM>
   </w.rf>
   <form>Da</form>
   <lemma>Da-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-d-id61885">
   <w.rf>
    <LM>w#w-d-id61885</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x8-1071">
   <w.rf>
    <LM>w#w-id58727-x8-1071</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x9">
  <m id="m973-id59147-1">
   <w.rf>
    <LM>w#w-id59147-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59147-2">
   <w.rf>
    <LM>w#w-id59147-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59147-3">
   <w.rf>
    <LM>w#w-id59147-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59147-4">
   <w.rf>
    <LM>w#w-id59147-4</LM>
   </w.rf>
   <form>krásný</form>
   <lemma>krásný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m973-id59147-5">
   <w.rf>
    <LM>w#w-id59147-5</LM>
   </w.rf>
   <form>třídní</form>
   <lemma>třídní-1</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m973-id59147-6">
   <w.rf>
    <LM>w#w-id59147-6</LM>
   </w.rf>
   <form>původ</form>
   <lemma>původ</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-d-id62011">
   <w.rf>
    <LM>w#w-d-id62011</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59147-7">
   <w.rf>
    <LM>w#w-id59147-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59147-8">
   <w.rf>
    <LM>w#w-id59147-8</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-id59147-9">
   <w.rf>
    <LM>w#w-id59147-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59147-10">
   <w.rf>
    <LM>w#w-id59147-10</LM>
   </w.rf>
   <form>prohlášen</form>
   <lemma>prohlásit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m973-id59147-11">
   <w.rf>
    <LM>w#w-id59147-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59147-12">
   <w.rf>
    <LM>w#w-id59147-12</LM>
   </w.rf>
   <form>kočího</form>
   <lemma>kočí-1</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m973-id58727-x9-6502">
   <w.rf>
    <LM>w#w-id58727-x9-6502</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59158-1">
   <w.rf>
    <LM>w#w-id59158-1</LM>
   </w.rf>
   <form>čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59158-5">
   <w.rf>
    <LM>w#w-id59158-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59158-3">
   <w.rf>
    <LM>w#w-id59158-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59158-2">
   <w.rf>
    <LM>w#w-id59158-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id59158-4">
   <w.rf>
    <LM>w#w-id59158-4</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59158-6">
   <w.rf>
    <LM>w#w-id59158-6</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m973-6496-6501">
   <w.rf>
    <LM>w#w-6496-6501</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-6496">
  <m id="m973-id59168-3">
   <w.rf>
    <LM>w#w-id59168-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59168-4">
   <w.rf>
    <LM>w#w-id59168-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m973-id59168-5">
   <w.rf>
    <LM>w#w-id59168-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m973-id59168-6">
   <w.rf>
    <LM>w#w-id59168-6</LM>
   </w.rf>
   <form>všeho</form>
   <lemma>všechen</lemma>
   <tag>PLZS2----------</tag>
  </m>
  <m id="m973-id59168-7">
   <w.rf>
    <LM>w#w-id59168-7</LM>
   </w.rf>
   <form>vyzpovídal</form>
   <lemma>vyzpovídat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-6496-6505">
   <w.rf>
    <LM>w#w-6496-6505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59177-1">
   <w.rf>
    <LM>w#w-id59177-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id59177-2">
   <w.rf>
    <LM>w#w-id59177-2</LM>
   </w.rf>
   <form>přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m973-id59177-3">
   <w.rf>
    <LM>w#w-id59177-3</LM>
   </w.rf>
   <form>teprve</form>
   <lemma>teprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59177-4">
   <w.rf>
    <LM>w#w-id59177-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id59177-5">
   <w.rf>
    <LM>w#w-id59177-5</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m973-6496-647">
   <w.rf>
    <LM>w#w-6496-647</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-648">
  <m id="m973-id59187-2">
   <w.rf>
    <LM>w#w-id59187-2</LM>
   </w.rf>
   <form>Povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-6496-1166">
   <w.rf>
    <LM>w#w-6496-1166</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-6496-6509">
   <w.rf>
    <LM>w#w-6496-6509</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59187-3">
   <w.rf>
    <LM>w#w-id59187-3</LM>
   </w.rf>
   <form>Zůstaňte</form>
   <lemma>zůstat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m973-id59187-4">
   <w.rf>
    <LM>w#w-id59187-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59187-5">
   <w.rf>
    <LM>w#w-id59187-5</LM>
   </w.rf>
   <form>sedět</form>
   <lemma>sedět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-6496-6510">
   <w.rf>
    <LM>w#w-6496-6510</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59197-1">
   <w.rf>
    <LM>w#w-id59197-1</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m973-id59197-2">
   <w.rf>
    <LM>w#w-id59197-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59206-1">
   <w.rf>
    <LM>w#w-id59206-1</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59206-2">
   <w.rf>
    <LM>w#w-id59206-2</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m973-id59206-3">
   <w.rf>
    <LM>w#w-id59206-3</LM>
   </w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m973-id59206-4">
   <w.rf>
    <LM>w#w-id59206-4</LM>
   </w.rf>
   <form>vrátím</form>
   <lemma>vrátit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m973-d-id62682">
   <w.rf>
    <LM>w#w-d-id62682</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-6496-6511">
   <w.rf>
    <LM>w#w-6496-6511</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x11">
  <m id="m973-id59234-3">
   <w.rf>
    <LM>w#w-id59234-3</LM>
   </w.rf>
   <form>Skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id59234-2">
   <w.rf>
    <LM>w#w-id59234-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59234-4">
   <w.rf>
    <LM>w#w-id59234-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id59234-5">
   <w.rf>
    <LM>w#w-id59234-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59234-6">
   <w.rf>
    <LM>w#w-id59234-6</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m973-id58727-x11-7322">
   <w.rf>
    <LM>w#w-id58727-x11-7322</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59234-7">
   <w.rf>
    <LM>w#w-id59234-7</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m973-id59234-8">
   <w.rf>
    <LM>w#w-id59234-8</LM>
   </w.rf>
   <form>minut</form>
   <lemma>minuta</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m973-id59234-9">
   <w.rf>
    <LM>w#w-id59234-9</LM>
   </w.rf>
   <form>vrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59244-1">
   <w.rf>
    <LM>w#w-id59244-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59244-2">
   <w.rf>
    <LM>w#w-id59244-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59244-3">
   <w.rf>
    <LM>w#w-id59244-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59244-5">
   <w.rf>
    <LM>w#w-id59244-5</LM>
   </w.rf>
   <form>mapě</form>
   <lemma>mapa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id59244-6">
   <w.rf>
    <LM>w#w-id59244-6</LM>
   </w.rf>
   <form>kus</form>
   <lemma>kus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id59244-8">
   <w.rf>
    <LM>w#w-id59244-8</LM>
   </w.rf>
   <form>popsaného</form>
   <lemma>popsaný_^(*2t)</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m973-id59244-7">
   <w.rf>
    <LM>w#w-id59244-7</LM>
   </w.rf>
   <form>papíru</form>
   <lemma>papír</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id58727-x11-655">
   <w.rf>
    <LM>w#w-id58727-x11-655</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-656">
  <m id="m973-id59254-2">
   <w.rf>
    <LM>w#w-id59254-2</LM>
   </w.rf>
   <form>Sedl</form>
   <lemma>sednout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m973-id59254-3">
   <w.rf>
    <LM>w#w-id59254-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id59254-4">
   <w.rf>
    <LM>w#w-id59254-4</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m973-id59254-5">
   <w.rf>
    <LM>w#w-id59254-5</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id59264-1">
   <w.rf>
    <LM>w#w-id59264-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59264-2">
   <w.rf>
    <LM>w#w-id59264-2</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id58727-x11-1236">
   <w.rf>
    <LM>w#w-id58727-x11-1236</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x11-7325">
   <w.rf>
    <LM>w#w-id58727-x11-7325</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59273-2">
   <w.rf>
    <LM>w#w-id59273-2</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m973-id59273-3">
   <w.rf>
    <LM>w#w-id59273-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id59283-3">
   <w.rf>
    <LM>w#w-id59283-3</LM>
   </w.rf>
   <form>žil</form>
   <lemma>žít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59283-4">
   <w.rf>
    <LM>w#w-id59283-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59283-5">
   <w.rf>
    <LM>w#w-id59283-5</LM>
   </w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-d-id63348">
   <w.rf>
    <LM>w#w-d-id63348</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x11-7328">
   <w.rf>
    <LM>w#w-id58727-x11-7328</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id58727-x12">
  <m id="m973-id59297-2">
   <w.rf>
    <LM>w#w-id59297-2</LM>
   </w.rf>
   <form>Povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id58727-x12-1268">
   <w.rf>
    <LM>w#w-id58727-x12-1268</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-d-id63589">
   <w.rf>
    <LM>w#w-d-id63589</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59297-5">
   <w.rf>
    <LM>w#w-id59297-5</LM>
   </w.rf>
   <form>Řekněte</form>
   <lemma>říci</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m973-id59297-4">
   <w.rf>
    <LM>w#w-id59297-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id58727-x12-7599">
   <w.rf>
    <LM>w#w-id58727-x12-7599</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59306-1">
   <w.rf>
    <LM>w#w-id59306-1</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id59306-2">
   <w.rf>
    <LM>w#w-id59306-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59306-3">
   <w.rf>
    <LM>w#w-id59306-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59306-4">
   <w.rf>
    <LM>w#w-id59306-4</LM>
   </w.rf>
   <form>Prostějově</form>
   <lemma>Prostějov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-id59316-1">
   <w.rf>
    <LM>w#w-id59316-1</LM>
   </w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m973-id59316-2">
   <w.rf>
    <LM>w#w-id59316-2</LM>
   </w.rf>
   <form>fotografický</form>
   <lemma>fotografický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m973-id59316-3">
   <w.rf>
    <LM>w#w-id59316-3</LM>
   </w.rf>
   <form>závod</form>
   <lemma>závod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id58727-x12-660">
   <w.rf>
    <LM>w#w-id58727-x12-660</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id58727-x12-7601">
   <w.rf>
    <LM>w#w-id58727-x12-7601</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59319-x1">
  <m id="m973-id59334-2">
   <w.rf>
    <LM>w#w-id59334-2</LM>
   </w.rf>
   <form>Tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id59334-3">
   <w.rf>
    <LM>w#w-id59334-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id59334-4">
   <w.rf>
    <LM>w#w-id59334-4</LM>
   </w.rf>
   <form>rozuměl</form>
   <lemma>rozumět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-d-id63884">
   <w.rf>
    <LM>w#w-d-id63884</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x1">
  <m id="m973-id59362-2">
   <w.rf>
    <LM>w#w-id59362-2</LM>
   </w.rf>
   <form>Tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id59362-3">
   <w.rf>
    <LM>w#w-id59362-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59362-4">
   <w.rf>
    <LM>w#w-id59362-4</LM>
   </w.rf>
   <form>rozuměl</form>
   <lemma>rozumět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59337-x1-8181">
   <w.rf>
    <LM>w#w-id59337-x1-8181</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59371-1">
   <w.rf>
    <LM>w#w-id59371-1</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-d-id64040">
   <w.rf>
    <LM>w#w-d-id64040</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x2">
  <m id="m973-id59376-2">
   <w.rf>
    <LM>w#w-id59376-2</LM>
   </w.rf>
   <form>Tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m973-id59376-3">
   <w.rf>
    <LM>w#w-id59376-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59376-4">
   <w.rf>
    <LM>w#w-id59376-4</LM>
   </w.rf>
   <form>rozuměl</form>
   <lemma>rozumět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59337-x2-8528">
   <w.rf>
    <LM>w#w-id59337-x2-8528</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59376-5">
   <w.rf>
    <LM>w#w-id59376-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59385-2">
   <w.rf>
    <LM>w#w-id59385-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59385-3">
   <w.rf>
    <LM>w#w-id59385-3</LM>
   </w.rf>
   <form>rozuměl</form>
   <lemma>rozumět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59337-x2-1337">
   <w.rf>
    <LM>w#w-id59337-x2-1337</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59385-4">
   <w.rf>
    <LM>w#w-id59385-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59385-5">
   <w.rf>
    <LM>w#w-id59385-5</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m973-id59385-6">
   <w.rf>
    <LM>w#w-id59385-6</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59385-7">
   <w.rf>
    <LM>w#w-id59385-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59385-8">
   <w.rf>
    <LM>w#w-id59385-8</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m973-id59337-x2-679">
   <w.rf>
    <LM>w#w-id59337-x2-679</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-680">
  <m id="m973-id59385-11">
   <w.rf>
    <LM>w#w-id59385-11</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59385-13">
   <w.rf>
    <LM>w#w-id59385-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59385-14">
   <w.rf>
    <LM>w#w-id59385-14</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59385-15">
   <w.rf>
    <LM>w#w-id59385-15</LM>
   </w.rf>
   <form>mluvit</form>
   <lemma>mluvit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-id59385-12">
   <w.rf>
    <LM>w#w-id59385-12</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m973-id59337-x2-8534">
   <w.rf>
    <LM>w#w-id59337-x2-8534</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59385-16">
   <w.rf>
    <LM>w#w-id59385-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id59385-17">
   <w.rf>
    <LM>w#w-id59385-17</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id59385-18">
   <w.rf>
    <LM>w#w-id59385-18</LM>
   </w.rf>
   <form>horší</form>
   <lemma>horší</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m973-d-id64396">
   <w.rf>
    <LM>w#w-d-id64396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x3">
  <m id="m973-id59401-5">
   <w.rf>
    <LM>w#w-id59401-5</LM>
   </w.rf>
   <form>Řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59401-3">
   <w.rf>
    <LM>w#w-id59401-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59401-4">
   <w.rf>
    <LM>w#w-id59401-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m973-id59401-7">
   <w.rf>
    <LM>w#w-id59401-7</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id59401-8">
   <w.rf>
    <LM>w#w-id59401-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m973-id59401-9">
   <w.rf>
    <LM>w#w-id59401-9</LM>
   </w.rf>
   <form>firmy</form>
   <lemma>firma</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m973-id59337-x3-8905">
   <w.rf>
    <LM>w#w-id59337-x3-8905</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59401-10">
   <w.rf>
    <LM>w#w-id59401-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59401-11">
   <w.rf>
    <LM>w#w-id59401-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id59401-12">
   <w.rf>
    <LM>w#w-id59401-12</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m973-id59401-13">
   <w.rf>
    <LM>w#w-id59401-13</LM>
   </w.rf>
   <form>Ševčík</form>
   <lemma>Ševčík_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-id59337-x3-8907">
   <w.rf>
    <LM>w#w-id59337-x3-8907</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59411-1">
   <w.rf>
    <LM>w#w-id59411-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59411-2">
   <w.rf>
    <LM>w#w-id59411-2</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id59337-x3-1372">
   <w.rf>
    <LM>w#w-id59337-x3-1372</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x3-8908">
   <w.rf>
    <LM>w#w-id59337-x3-8908</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59411-3">
   <w.rf>
    <LM>w#w-id59411-3</LM>
   </w.rf>
   <form>Chorošo</form>
   <lemma>Chorošo-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-d-id64690">
   <w.rf>
    <LM>w#w-d-id64690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x4">
  <m id="m973-id59425-2">
   <w.rf>
    <LM>w#w-id59425-2</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id59425-3">
   <w.rf>
    <LM>w#w-id59425-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59435-1">
   <w.rf>
    <LM>w#w-id59435-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59435-2">
   <w.rf>
    <LM>w#w-id59435-2</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m973-id59435-3">
   <w.rf>
    <LM>w#w-id59435-3</LM>
   </w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AANS4----3A----</tag>
  </m>
  <m id="m973-id59435-4">
   <w.rf>
    <LM>w#w-id59435-4</LM>
   </w.rf>
   <form>knihkupectví</form>
   <lemma>knihkupectví</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-d-id64840">
   <w.rf>
    <LM>w#w-d-id64840</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x4-9294">
   <w.rf>
    <LM>w#w-id59337-x4-9294</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x5">
  <m id="m973-id59440-3">
   <w.rf>
    <LM>w#w-id59440-3</LM>
   </w.rf>
   <form>Povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59337-x5-1479">
   <w.rf>
    <LM>w#w-id59337-x5-1479</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x5-514">
   <w.rf>
    <LM>w#w-id59337-x5-514</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59440-4">
   <w.rf>
    <LM>w#w-id59440-4</LM>
   </w.rf>
   <form>Buček</form>
   <lemma>Buček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m973-d-id64926">
   <w.rf>
    <LM>w#w-d-id64926</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x5-515">
   <w.rf>
    <LM>w#w-id59337-x5-515</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x7">
  <m id="m973-id59477-2">
   <w.rf>
    <LM>w#w-id59477-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59477-3">
   <w.rf>
    <LM>w#w-id59477-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59477-4">
   <w.rf>
    <LM>w#w-id59477-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m973-id59477-5">
   <w.rf>
    <LM>w#w-id59477-5</LM>
   </w.rf>
   <form>ptá</form>
   <lemma>ptát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-d-id65078">
   <w.rf>
    <LM>w#w-d-id65078</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59486-2">
   <w.rf>
    <LM>w#w-id59486-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59486-3">
   <w.rf>
    <LM>w#w-id59486-3</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m973-id59486-4">
   <w.rf>
    <LM>w#w-id59486-4</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id59486-5">
   <w.rf>
    <LM>w#w-id59486-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59486-6">
   <w.rf>
    <LM>w#w-id59486-6</LM>
   </w.rf>
   <form>soud</form>
   <lemma>soud</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-d-id65182">
   <w.rf>
    <LM>w#w-d-id65182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x8">
  <m id="m973-id59492-3">
   <w.rf>
    <LM>w#w-id59492-3</LM>
   </w.rf>
   <form>Povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59337-x8-1538">
   <w.rf>
    <LM>w#w-id59337-x8-1538</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x8-716">
   <w.rf>
    <LM>w#w-id59337-x8-716</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59492-4">
   <w.rf>
    <LM>w#w-id59492-4</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59492-6">
   <w.rf>
    <LM>w#w-id59492-6</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id59492-7">
   <w.rf>
    <LM>w#w-id59492-7</LM>
   </w.rf>
   <form>Havlíčkova</form>
   <lemma>Havlíčkův_;Y_^(*3ek)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m973-d-id65315">
   <w.rf>
    <LM>w#w-d-id65315</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59492-8">
   <w.rf>
    <LM>w#w-id59492-8</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59492-10">
   <w.rf>
    <LM>w#w-id59492-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59492-11">
   <w.rf>
    <LM>w#w-id59492-11</LM>
   </w.rf>
   <form>bydlel</form>
   <lemma>bydlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-d-id65372">
   <w.rf>
    <LM>w#w-d-id65372</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x8-724">
   <w.rf>
    <LM>w#w-id59337-x8-724</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x9">
  <m id="m973-id59506-2">
   <w.rf>
    <LM>w#w-id59506-2</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m973-id59506-4">
   <w.rf>
    <LM>w#w-id59506-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59506-5">
   <w.rf>
    <LM>w#w-id59506-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id59506-6">
   <w.rf>
    <LM>w#w-id59506-6</LM>
   </w.rf>
   <form>prokádrovaný</form>
   <lemma>prokádrovaný_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m973-id59337-x9-700">
   <w.rf>
    <LM>w#w-id59337-x9-700</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-701">
  <m id="m973-id59506-8">
   <w.rf>
    <LM>w#w-id59506-8</LM>
   </w.rf>
   <form>Pravděpodobně</form>
   <lemma>pravděpodobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id59506-9">
   <w.rf>
    <LM>w#w-id59506-9</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m973-id59506-11">
   <w.rf>
    <LM>w#w-id59506-11</LM>
   </w.rf>
   <form>stačilo</form>
   <lemma>stačit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-d-id65569">
   <w.rf>
    <LM>w#w-d-id65569</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59517-1">
   <w.rf>
    <LM>w#w-id59517-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59517-2">
   <w.rf>
    <LM>w#w-id59517-2</LM>
   </w.rf>
   <form>nejsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m973-id59517-3">
   <w.rf>
    <LM>w#w-id59517-3</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m973-id59337-x9-944">
   <w.rf>
    <LM>w#w-id59337-x9-944</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59517-4">
   <w.rf>
    <LM>w#w-id59517-4</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id59517-5">
   <w.rf>
    <LM>w#w-id59517-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id59517-6">
   <w.rf>
    <LM>w#w-id59517-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59517-7">
   <w.rf>
    <LM>w#w-id59517-7</LM>
   </w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m973-id59517-8">
   <w.rf>
    <LM>w#w-id59517-8</LM>
   </w.rf>
   <form>vydává</form>
   <lemma>vydávat_^(*4at)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id59337-x9-945">
   <w.rf>
    <LM>w#w-id59337-x9-945</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-946">
  <m id="m973-id59517-13">
   <w.rf>
    <LM>w#w-id59517-13</LM>
   </w.rf>
   <form>Chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-946-960">
   <w.rf>
    <LM>w#w-946-960</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59517-15">
   <w.rf>
    <LM>w#w-id59517-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59517-17">
   <w.rf>
    <LM>w#w-id59517-17</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id59517-18">
   <w.rf>
    <LM>w#w-id59517-18</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id59517-19">
   <w.rf>
    <LM>w#w-id59517-19</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-946-706">
   <w.rf>
    <LM>w#w-946-706</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-707">
  <m id="m973-id59528-2">
   <w.rf>
    <LM>w#w-id59528-2</LM>
   </w.rf>
   <form>Skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id59528-3">
   <w.rf>
    <LM>w#w-id59528-3</LM>
   </w.rf>
   <form>rozhovor</form>
   <lemma>rozhovor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id59528-4">
   <w.rf>
    <LM>w#w-id59528-4</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m973-d-id65956">
   <w.rf>
    <LM>w#w-d-id65956</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59537-1">
   <w.rf>
    <LM>w#w-id59537-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59537-2">
   <w.rf>
    <LM>w#w-id59537-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id59537-3">
   <w.rf>
    <LM>w#w-id59537-3</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-d-id66021">
   <w.rf>
    <LM>w#w-d-id66021</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59537-4">
   <w.rf>
    <LM>w#w-id59537-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59537-5">
   <w.rf>
    <LM>w#w-id59537-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id59537-6">
   <w.rf>
    <LM>w#w-id59537-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id59537-7">
   <w.rf>
    <LM>w#w-id59537-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id59537-8">
   <w.rf>
    <LM>w#w-id59537-8</LM>
   </w.rf>
   <form>pořádku</form>
   <lemma>pořádek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-id59537-9">
   <w.rf>
    <LM>w#w-id59537-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59537-10">
   <w.rf>
    <LM>w#w-id59537-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id59537-11">
   <w.rf>
    <LM>w#w-id59537-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id59547-1">
   <w.rf>
    <LM>w#w-id59547-1</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59547-2">
   <w.rf>
    <LM>w#w-id59547-2</LM>
   </w.rf>
   <form>zažádat</form>
   <lemma>zažádat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id59556-1">
   <w.rf>
    <LM>w#w-id59556-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59556-2">
   <w.rf>
    <LM>w#w-id59556-2</LM>
   </w.rf>
   <form>povolení</form>
   <lemma>povolení_^(*3it)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id59556-3">
   <w.rf>
    <LM>w#w-id59556-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m973-id59556-4">
   <w.rf>
    <LM>w#w-id59556-4</LM>
   </w.rf>
   <form>pobytu</form>
   <lemma>pobyt_^(př._místo_pobytu)</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m973-d-id66257">
   <w.rf>
    <LM>w#w-d-id66257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id59337-x10">
  <m id="m973-id59580-4">
   <w.rf>
    <LM>w#w-id59580-4</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59589-1">
   <w.rf>
    <LM>w#w-id59589-1</LM>
   </w.rf>
   <form>povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59337-x10-1704">
   <w.rf>
    <LM>w#w-id59337-x10-1704</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x10-1355">
   <w.rf>
    <LM>w#w-id59337-x10-1355</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59589-2">
   <w.rf>
    <LM>w#w-id59589-2</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59589-3">
   <w.rf>
    <LM>w#w-id59589-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id59589-4">
   <w.rf>
    <LM>w#w-id59589-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id59589-5">
   <w.rf>
    <LM>w#w-id59589-5</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id59337-x10-1356">
   <w.rf>
    <LM>w#w-id59337-x10-1356</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x10-1357">
   <w.rf>
    <LM>w#w-id59337-x10-1357</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-710">
  <m id="m973-id59589-7">
   <w.rf>
    <LM>w#w-id59589-7</LM>
   </w.rf>
   <form>Prý</form>
   <lemma>prý</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id59337-x10-1705">
   <w.rf>
    <LM>w#w-id59337-x10-1705</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x10-1360">
   <w.rf>
    <LM>w#w-id59337-x10-1360</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59589-8">
   <w.rf>
    <LM>w#w-id59589-8</LM>
   </w.rf>
   <form>Přijďte</form>
   <lemma>přijít</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m973-id59589-9">
   <w.rf>
    <LM>w#w-id59589-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id59589-10">
   <w.rf>
    <LM>w#w-id59589-10</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id59589-11">
   <w.rf>
    <LM>w#w-id59589-11</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m973-id59589-12">
   <w.rf>
    <LM>w#w-id59589-12</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m973-id59600-1">
   <w.rf>
    <LM>w#w-id59600-1</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59600-2">
   <w.rf>
    <LM>w#w-id59600-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59600-3">
   <w.rf>
    <LM>w#w-id59600-3</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m973-id59600-4">
   <w.rf>
    <LM>w#w-id59600-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id59600-5">
   <w.rf>
    <LM>w#w-id59600-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id59600-6">
   <w.rf>
    <LM>w#w-id59600-6</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id59600-7">
   <w.rf>
    <LM>w#w-id59600-7</LM>
   </w.rf>
   <form>vyplníte</form>
   <lemma>vyplnit</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m973-id59600-8">
   <w.rf>
    <LM>w#w-id59600-8</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m973-id59600-9">
   <w.rf>
    <LM>w#w-id59600-9</LM>
   </w.rf>
   <form>žádost</form>
   <lemma>žádost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-id59337-x10-1366">
   <w.rf>
    <LM>w#w-id59337-x10-1366</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id59337-x10-1365">
   <w.rf>
    <LM>w#w-id59337-x10-1365</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
