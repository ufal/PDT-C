<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_010.03.w.gz" />
  </references>
 </head>
 <s id="m010-4062">
  <m id="m010-d1t1172-3">
   <w.rf>
    <LM>w#w-d1t1172-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-d1t1172-2">
   <w.rf>
    <LM>w#w-d1t1172-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1172-4">
   <w.rf>
    <LM>w#w-d1t1172-4</LM>
   </w.rf>
   <form>44</form>
   <lemma>44</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m010-d1t1172-6">
   <w.rf>
    <LM>w#w-d1t1172-6</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m010-d-id87804">
   <w.rf>
    <LM>w#w-d-id87804</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1172-8">
   <w.rf>
    <LM>w#w-d1t1172-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1172-9">
   <w.rf>
    <LM>w#w-d1t1172-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1172-10">
   <w.rf>
    <LM>w#w-d1t1172-10</LM>
   </w.rf>
   <form>vyšli</form>
   <lemma>vyjít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m010-d1t1172-11">
   <w.rf>
    <LM>w#w-d1t1172-11</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m010-d1t1172-12">
   <w.rf>
    <LM>w#w-d1t1172-12</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-4062-3815">
   <w.rf>
    <LM>w#w-4062-3815</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-3816">
  <m id="m010-d1t1175-2">
   <w.rf>
    <LM>w#w-d1t1175-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m010-d1t1175-5">
   <w.rf>
    <LM>w#w-d1t1175-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m010-d1t1175-3">
   <w.rf>
    <LM>w#w-d1t1175-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1175-7">
   <w.rf>
    <LM>w#w-d1t1175-7</LM>
   </w.rf>
   <form>nedovedu</form>
   <lemma>dovést</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m010-d1t1185-1">
   <w.rf>
    <LM>w#w-d1t1185-1</LM>
   </w.rf>
   <form>uvědomit</form>
   <lemma>uvědomit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m010-d-id88093">
   <w.rf>
    <LM>w#w-d-id88093</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1186-x2">
  <m id="m010-d1t1191-2">
   <w.rf>
    <LM>w#w-d1t1191-2</LM>
   </w.rf>
   <form>Scházeli</form>
   <lemma>scházet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1191-3">
   <w.rf>
    <LM>w#w-d1t1191-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1e1186-x2-3897">
   <w.rf>
    <LM>w#w-d1e1186-x2-3897</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1191-4">
   <w.rf>
    <LM>w#w-d1t1191-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1191-5">
   <w.rf>
    <LM>w#w-d1t1191-5</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m010-d1t1191-6">
   <w.rf>
    <LM>w#w-d1t1191-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m010-d1e1186-x2-4540">
   <w.rf>
    <LM>w#w-d1e1186-x2-4540</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1193-1">
   <w.rf>
    <LM>w#w-d1t1193-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1193-2">
   <w.rf>
    <LM>w#w-d1t1193-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1193-3">
   <w.rf>
    <LM>w#w-d1t1193-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1193-4">
   <w.rf>
    <LM>w#w-d1t1193-4</LM>
   </w.rf>
   <form>zkracovalo</form>
   <lemma>zkracovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-d1t1193-5">
   <w.rf>
    <LM>w#w-d1t1193-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m010-d1t1193-6">
   <w.rf>
    <LM>w#w-d1t1193-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m010-d1t1193-7">
   <w.rf>
    <LM>w#w-d1t1193-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m010-d1e1186-x2-4979">
   <w.rf>
    <LM>w#w-d1e1186-x2-4979</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-4980">
  <m id="m010-d1t1193-9">
   <w.rf>
    <LM>w#w-d1t1193-9</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d-id88435">
   <w.rf>
    <LM>w#w-d-id88435</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1193-11">
   <w.rf>
    <LM>w#w-d1t1193-11</LM>
   </w.rf>
   <form>čím</form>
   <lemma>čí</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m010-d1t1193-12">
   <w.rf>
    <LM>w#w-d1t1193-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1193-13">
   <w.rf>
    <LM>w#w-d1t1193-13</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m010-d-id88491">
   <w.rf>
    <LM>w#w-d-id88491</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1195-1">
   <w.rf>
    <LM>w#w-d1t1195-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1195-2">
   <w.rf>
    <LM>w#w-d1t1195-2</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1197-1">
   <w.rf>
    <LM>w#w-d1t1197-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1197-2">
   <w.rf>
    <LM>w#w-d1t1197-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m010-d-id88610">
   <w.rf>
    <LM>w#w-d-id88610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1197-4">
   <w.rf>
    <LM>w#w-d1t1197-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1197-5">
   <w.rf>
    <LM>w#w-d1t1197-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1197-6">
   <w.rf>
    <LM>w#w-d1t1197-6</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1197-7">
   <w.rf>
    <LM>w#w-d1t1197-7</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m010-d1t1197-8">
   <w.rf>
    <LM>w#w-d1t1197-8</LM>
   </w.rf>
   <form>zemřelo</form>
   <lemma>zemřít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m010-4980-4038">
   <w.rf>
    <LM>w#w-4980-4038</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-4039">
  <m id="m010-d1t1200-1">
   <w.rf>
    <LM>w#w-d1t1200-1</LM>
   </w.rf>
   <form>Zmenšuje</form>
   <lemma>zmenšovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1200-2">
   <w.rf>
    <LM>w#w-d1t1200-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1200-3">
   <w.rf>
    <LM>w#w-d1t1200-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-4039-4047">
   <w.rf>
    <LM>w#w-4039-4047</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-4980-4031">
   <w.rf>
    <LM>w#w-4980-4031</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-4980-4032">
   <w.rf>
    <LM>w#w-4980-4032</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d-id88825">
   <w.rf>
    <LM>w#w-d-id88825</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-4980-4033">
   <w.rf>
    <LM>w#w-4980-4033</LM>
   </w.rf>
   <form>rozhodli</form>
   <lemma>rozhodnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m010-4980-4037">
   <w.rf>
    <LM>w#w-4980-4037</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-4980-4034">
   <w.rf>
    <LM>w#w-4980-4034</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-4980-4035">
   <w.rf>
    <LM>w#w-4980-4035</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-4039-4053">
   <w.rf>
    <LM>w#w-4039-4053</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m010-4039-4054">
   <w.rf>
    <LM>w#w-4039-4054</LM>
   </w.rf>
   <form>scházet</form>
   <lemma>scházet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m010-4039-4057">
   <w.rf>
    <LM>w#w-4039-4057</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-4039-4058">
   <w.rf>
    <LM>w#w-4039-4058</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-4980-4036">
   <w.rf>
    <LM>w#w-4980-4036</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1201-x3">
  <m id="m010-d1t1208-1">
   <w.rf>
    <LM>w#w-d1t1208-1</LM>
   </w.rf>
   <form>Scházíte</form>
   <lemma>scházet</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m010-d1t1208-2">
   <w.rf>
    <LM>w#w-d1t1208-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1208-3">
   <w.rf>
    <LM>w#w-d1t1208-3</LM>
   </w.rf>
   <form>vždy</form>
   <lemma>vždy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1208-4">
   <w.rf>
    <LM>w#w-d1t1208-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1208-5">
   <w.rf>
    <LM>w#w-d1t1208-5</LM>
   </w.rf>
   <form>stejném</form>
   <lemma>stejný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m010-d1t1208-6">
   <w.rf>
    <LM>w#w-d1t1208-6</LM>
   </w.rf>
   <form>místě</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m010-d-id89038">
   <w.rf>
    <LM>w#w-d-id89038</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1209-x2">
  <m id="m010-d1t1212-1">
   <w.rf>
    <LM>w#w-d1t1212-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d-id89115">
   <w.rf>
    <LM>w#w-d-id89115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1212-3">
   <w.rf>
    <LM>w#w-d1t1212-3</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1212-4">
   <w.rf>
    <LM>w#w-d1t1212-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1212-5">
   <w.rf>
    <LM>w#w-d1t1212-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1212-6">
   <w.rf>
    <LM>w#w-d1t1212-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1212-9">
   <w.rf>
    <LM>w#w-d1t1212-9</LM>
   </w.rf>
   <form>Mýtě</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m010-d-id89084">
   <w.rf>
    <LM>w#w-d-id89084</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1215-x2">
  <m id="m010-d1t1222-1">
   <w.rf>
    <LM>w#w-d1t1222-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1222-2">
   <w.rf>
    <LM>w#w-d1t1222-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m010-d1t1222-3">
   <w.rf>
    <LM>w#w-d1t1222-3</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m010-d-id89436">
   <w.rf>
    <LM>w#w-d-id89436</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5091">
  <m id="m010-d1t1220-4">
   <w.rf>
    <LM>w#w-d1t1220-4</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-5091-5103">
   <w.rf>
    <LM>w#w-5091-5103</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1220-5">
   <w.rf>
    <LM>w#w-d1t1220-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1220-6">
   <w.rf>
    <LM>w#w-d1t1220-6</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m010-d1t1228-2">
   <w.rf>
    <LM>w#w-d1t1228-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1228-3">
   <w.rf>
    <LM>w#w-d1t1228-3</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m010-d-id89482">
   <w.rf>
    <LM>w#w-d-id89482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1229-x2">
  <m id="m010-d1t1232-1">
   <w.rf>
    <LM>w#w-d1t1232-1</LM>
   </w.rf>
   <form>Jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1232-2">
   <w.rf>
    <LM>w#w-d1t1232-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1232-3">
   <w.rf>
    <LM>w#w-d1t1232-3</LM>
   </w.rf>
   <form>klábosíte</form>
   <lemma>klábosit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m010-d1t1232-4">
   <w.rf>
    <LM>w#w-d1t1232-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1232-5">
   <w.rf>
    <LM>w#w-d1t1232-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m010-d1t1232-6">
   <w.rf>
    <LM>w#w-d1t1232-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1232-7">
   <w.rf>
    <LM>w#w-d1t1232-7</LM>
   </w.rf>
   <form>zazpíváte</form>
   <lemma>zazpívat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m010-d-id89707">
   <w.rf>
    <LM>w#w-d-id89707</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1233-x2">
  <m id="m010-d1t1236-2">
   <w.rf>
    <LM>w#w-d1t1236-2</LM>
   </w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m010-d1t1236-3">
   <w.rf>
    <LM>w#w-d1t1236-3</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m010-d-id89808">
   <w.rf>
    <LM>w#w-d-id89808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1236-5">
   <w.rf>
    <LM>w#w-d1t1236-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1236-6">
   <w.rf>
    <LM>w#w-d1t1236-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1236-7">
   <w.rf>
    <LM>w#w-d1t1236-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1236-8">
   <w.rf>
    <LM>w#w-d1t1236-8</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m010-d-id89873">
   <w.rf>
    <LM>w#w-d-id89873</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1236-11">
   <w.rf>
    <LM>w#w-d1t1236-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1236-12">
   <w.rf>
    <LM>w#w-d1t1236-12</LM>
   </w.rf>
   <form>zpívali</form>
   <lemma>zpívat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1238-1">
   <w.rf>
    <LM>w#w-d1t1238-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1238-2">
   <w.rf>
    <LM>w#w-d1t1238-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1238-3">
   <w.rf>
    <LM>w#w-d1t1238-3</LM>
   </w.rf>
   <form>tancovalo</form>
   <lemma>tancovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-d1e1233-x2-5252">
   <w.rf>
    <LM>w#w-d1e1233-x2-5252</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5253">
  <m id="m010-d1t1240-2">
   <w.rf>
    <LM>w#w-d1t1240-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-d1t1240-3">
   <w.rf>
    <LM>w#w-d1t1240-3</LM>
   </w.rf>
   <form>veselo</form>
   <lemma>veselo-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m010-d-id90047">
   <w.rf>
    <LM>w#w-d-id90047</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1240-5">
   <w.rf>
    <LM>w#w-d1t1240-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1240-6">
   <w.rf>
    <LM>w#w-d1t1240-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1240-7">
   <w.rf>
    <LM>w#w-d1t1240-7</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m010-5253-5263">
   <w.rf>
    <LM>w#w-5253-5263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5264">
  <m id="m010-d1t1240-11">
   <w.rf>
    <LM>w#w-d1t1240-11</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>čí</lemma>
   <tag>P4ZS7----------</tag>
  </m>
  <m id="m010-d1t1240-12">
   <w.rf>
    <LM>w#w-d1t1240-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1240-13">
   <w.rf>
    <LM>w#w-d1t1240-13</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1240-14">
   <w.rf>
    <LM>w#w-d1t1240-14</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m010-d1t1240-15">
   <w.rf>
    <LM>w#w-d1t1240-15</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1240-16">
   <w.rf>
    <LM>w#w-d1t1240-16</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m010-d-id90229">
   <w.rf>
    <LM>w#w-d-id90229</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1244-1">
   <w.rf>
    <LM>w#w-d1t1244-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1244-2">
   <w.rf>
    <LM>w#w-d1t1244-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1244-3">
   <w.rf>
    <LM>w#w-d1t1244-3</LM>
   </w.rf>
   <form>upadalo</form>
   <lemma>upadat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-5264-5273">
   <w.rf>
    <LM>w#w-5264-5273</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5274">
  <m id="m010-d1t1244-5">
   <w.rf>
    <LM>w#w-d1t1244-5</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1244-6">
   <w.rf>
    <LM>w#w-d1t1244-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1244-7">
   <w.rf>
    <LM>w#w-d1t1244-7</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1247-1">
   <w.rf>
    <LM>w#w-d1t1247-1</LM>
   </w.rf>
   <form>sedíme</form>
   <lemma>sedět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-5274-5282">
   <w.rf>
    <LM>w#w-5274-5282</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1247-2">
   <w.rf>
    <LM>w#w-d1t1247-2</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1247-3">
   <w.rf>
    <LM>w#w-d1t1247-3</LM>
   </w.rf>
   <form>zpíváme</form>
   <lemma>zpívat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d-id90413">
   <w.rf>
    <LM>w#w-d-id90413</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1247-5">
   <w.rf>
    <LM>w#w-d1t1247-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1247-6">
   <w.rf>
    <LM>w#w-d1t1247-6</LM>
   </w.rf>
   <form>zpíváme</form>
   <lemma>zpívat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1247-7">
   <w.rf>
    <LM>w#w-d1t1247-7</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m010-5274-5283">
   <w.rf>
    <LM>w#w-5274-5283</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1249-2">
   <w.rf>
    <LM>w#w-d1t1249-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1249-3">
   <w.rf>
    <LM>w#w-d1t1249-3</LM>
   </w.rf>
   <form>povídáme</form>
   <lemma>povídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1249-4">
   <w.rf>
    <LM>w#w-d1t1249-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m010-d-id89753">
   <w.rf>
    <LM>w#w-d-id89753</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1250-x2">
  <m id="m010-d1t1253-1">
   <w.rf>
    <LM>w#w-d1t1253-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m010-d1t1253-2">
   <w.rf>
    <LM>w#w-d1t1253-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1253-3">
   <w.rf>
    <LM>w#w-d1t1253-3</LM>
   </w.rf>
   <form>vašich</form>
   <lemma>váš</lemma>
   <tag>PSXP2-P2-------</tag>
  </m>
  <m id="m010-d1t1253-4">
   <w.rf>
    <LM>w#w-d1t1253-4</LM>
   </w.rf>
   <form>nejbližších</form>
   <lemma>blízký</lemma>
   <tag>AAMP2----3A----</tag>
  </m>
  <m id="m010-d1t1253-5">
   <w.rf>
    <LM>w#w-d1t1253-5</LM>
   </w.rf>
   <form>spolužáků</form>
   <lemma>spolužák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m010-d1t1253-6">
   <w.rf>
    <LM>w#w-d1t1253-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1253-7">
   <w.rf>
    <LM>w#w-d1t1253-7</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m010-d1t1253-8">
   <w.rf>
    <LM>w#w-d1t1253-8</LM>
   </w.rf>
   <form>nejbližší</form>
   <lemma>blízký</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m010-d-id90703">
   <w.rf>
    <LM>w#w-d-id90703</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1255-x2">
  <m id="m010-d1t1260-5">
   <w.rf>
    <LM>w#w-d1t1260-5</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d1t1260-6">
   <w.rf>
    <LM>w#w-d1t1260-6</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m010-d1e1255-x2-5385">
   <w.rf>
    <LM>w#w-d1e1255-x2-5385</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m010-d1e1255-x2-5386">
   <w.rf>
    <LM>w#w-d1e1255-x2-5386</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m010-d1e1255-x2-5387">
   <w.rf>
    <LM>w#w-d1e1255-x2-5387</LM>
   </w.rf>
   <form>tmavými</form>
   <lemma>tmavý</lemma>
   <tag>AAIP7----1A----</tag>
  </m>
  <m id="m010-d1t1260-10">
   <w.rf>
    <LM>w#w-d1t1260-10</LM>
   </w.rf>
   <form>vlasy</form>
   <lemma>vlas</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m010-d1t1262-1">
   <w.rf>
    <LM>w#w-d1t1262-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1260-8">
   <w.rf>
    <LM>w#w-d1t1260-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m010-d1t1260-9">
   <w.rf>
    <LM>w#w-d1t1260-9</LM>
   </w.rf>
   <form>tmavých</form>
   <lemma>tmavý</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m010-d1t1262-2">
   <w.rf>
    <LM>w#w-d1t1262-2</LM>
   </w.rf>
   <form>šatech</form>
   <lemma>šat</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m010-d1t1264-3">
   <w.rf>
    <LM>w#w-d1t1264-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1264-4">
   <w.rf>
    <LM>w#w-d1t1264-4</LM>
   </w.rf>
   <form>kamarádka</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1t1266-1">
   <w.rf>
    <LM>w#w-d1t1266-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1266-2">
   <w.rf>
    <LM>w#w-d1t1266-2</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1266-3">
   <w.rf>
    <LM>w#w-d1t1266-3</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3-------</tag>
  </m>
  <m id="m010-d1e1255-x2-5389">
   <w.rf>
    <LM>w#w-d1e1255-x2-5389</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d-id91103">
   <w.rf>
    <LM>w#w-d-id91103</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1269-1">
   <w.rf>
    <LM>w#w-d1t1269-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m010-d1t1269-4">
   <w.rf>
    <LM>w#w-d1t1269-4</LM>
   </w.rf>
   <form>kabelku</form>
   <lemma>kabelka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m010-d-id91183">
   <w.rf>
    <LM>w#w-d-id91183</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1269-8">
   <w.rf>
    <LM>w#w-d1t1269-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1e1255-x2-5390">
   <w.rf>
    <LM>w#w-d1e1255-x2-5390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5391">
  <m id="m010-d1t1269-10">
   <w.rf>
    <LM>w#w-d1t1269-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1269-11">
   <w.rf>
    <LM>w#w-d1t1269-11</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1269-12">
   <w.rf>
    <LM>w#w-d1t1269-12</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m010-d1t1269-13">
   <w.rf>
    <LM>w#w-d1t1269-13</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m010-d1t1269-15">
   <w.rf>
    <LM>w#w-d1t1269-15</LM>
   </w.rf>
   <form>nejmilejší</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m010-d1t1271-1">
   <w.rf>
    <LM>w#w-d1t1271-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1271-2">
   <w.rf>
    <LM>w#w-d1t1271-2</LM>
   </w.rf>
   <form>nejbližší</form>
   <lemma>blízký</lemma>
   <tag>AAFP1----3A----</tag>
  </m>
  <m id="m010-d1t1271-3">
   <w.rf>
    <LM>w#w-d1t1271-3</LM>
   </w.rf>
   <form>kamarádky</form>
   <lemma>kamarádka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m010-d-id90749">
   <w.rf>
    <LM>w#w-d-id90749</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1272-x3">
  <m id="m010-d1t1279-1">
   <w.rf>
    <LM>w#w-d1t1279-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1279-2">
   <w.rf>
    <LM>w#w-d1t1279-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1279-3">
   <w.rf>
    <LM>w#w-d1t1279-3</LM>
   </w.rf>
   <form>jmenují</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---3P-AAB--</tag>
  </m>
  <m id="m010-d-id91523">
   <w.rf>
    <LM>w#w-d-id91523</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1280-x2">
  <m id="m010-d1t1283-2">
   <w.rf>
    <LM>w#w-d1t1283-2</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d1t1283-3">
   <w.rf>
    <LM>w#w-d1t1283-3</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m010-d1t1283-4">
   <w.rf>
    <LM>w#w-d1t1283-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1283-6">
   <w.rf>
    <LM>w#w-d1t1283-6</LM>
   </w.rf>
   <form>Elvíra</form>
   <lemma>Elvíra_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1t1285-1">
   <w.rf>
    <LM>w#w-d1t1285-1</LM>
   </w.rf>
   <form>Kratochvílová</form>
   <lemma>Kratochvílová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1t1285-4">
   <w.rf>
    <LM>w#w-d1t1285-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m010-d1t1285-5">
   <w.rf>
    <LM>w#w-d1t1285-5</LM>
   </w.rf>
   <form>svobodna</form>
   <lemma>svobodný</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m010-d1t1287-1">
   <w.rf>
    <LM>w#w-d1t1287-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1287-2">
   <w.rf>
    <LM>w#w-d1t1287-2</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d1t1287-3">
   <w.rf>
    <LM>w#w-d1t1287-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1287-5">
   <w.rf>
    <LM>w#w-d1t1287-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Jarmila</form>
   <lemma>Jarmila_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1t1287-6">
   <w.rf>
    <LM>w#w-d1t1287-6</LM>
   </w.rf>
   <form>Baslová</form>
   <lemma>Baslová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d-id91569">
   <w.rf>
    <LM>w#w-d-id91569</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1288-x2">
  <m id="m010-d1t1295-3">
   <w.rf>
    <LM>w#w-d1t1295-3</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1295-2">
   <w.rf>
    <LM>w#w-d1t1295-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m010-d1t1295-4">
   <w.rf>
    <LM>w#w-d1t1295-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1303-1">
   <w.rf>
    <LM>w#w-d1t1303-1</LM>
   </w.rf>
   <form>jména</form>
   <lemma>jméno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m010-d1t1303-2">
   <w.rf>
    <LM>w#w-d1t1303-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m010-d1t1305-1">
   <w.rf>
    <LM>w#w-d1t1305-1</LM>
   </w.rf>
   <form>svobodna</form>
   <lemma>svobodný</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m010-d-id92030">
   <w.rf>
    <LM>w#w-d-id92030</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1308-x2">
  <m id="m010-d1t1311-1">
   <w.rf>
    <LM>w#w-d1t1311-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m010-d1t1311-2">
   <w.rf>
    <LM>w#w-d1t1311-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1311-3">
   <w.rf>
    <LM>w#w-d1t1311-3</LM>
   </w.rf>
   <form>dělají</form>
   <lemma>dělat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1311-4">
   <w.rf>
    <LM>w#w-d1t1311-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1311-5">
   <w.rf>
    <LM>w#w-d1t1311-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1311-6">
   <w.rf>
    <LM>w#w-d1t1311-6</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m010-d-id92243">
   <w.rf>
    <LM>w#w-d-id92243</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1312-x2">
  <m id="m010-d1t1317-2">
   <w.rf>
    <LM>w#w-d1t1317-2</LM>
   </w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m010-d1t1317-1">
   <w.rf>
    <LM>w#w-d1t1317-1</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m010-d1t1317-3">
   <w.rf>
    <LM>w#w-d1t1317-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1317-5">
   <w.rf>
    <LM>w#w-d1t1317-5</LM>
   </w.rf>
   <form>Mýtě</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m010-d1t1317-8">
   <w.rf>
    <LM>w#w-d1t1317-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1317-9">
   <w.rf>
    <LM>w#w-d1t1317-9</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1317-10">
   <w.rf>
    <LM>w#w-d1t1317-10</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m010-d1t1317-11">
   <w.rf>
    <LM>w#w-d1t1317-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1317-12">
   <w.rf>
    <LM>w#w-d1t1317-12</LM>
   </w.rf>
   <form>důchodu</form>
   <lemma>důchod</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m010-d-id92289">
   <w.rf>
    <LM>w#w-d-id92289</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1324-x2">
  <m id="m010-d1t1327-1">
   <w.rf>
    <LM>w#w-d1t1327-1</LM>
   </w.rf>
   <form>Ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m010-d1t1327-2">
   <w.rf>
    <LM>w#w-d1t1327-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1327-3">
   <w.rf>
    <LM>w#w-d1t1327-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1327-4">
   <w.rf>
    <LM>w#w-d1t1327-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1327-6">
   <w.rf>
    <LM>w#w-d1t1327-6</LM>
   </w.rf>
   <form>Mýta</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m010-d-id92614">
   <w.rf>
    <LM>w#w-d-id92614</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1328-x2">
  <m id="m010-d1t1331-1">
   <w.rf>
    <LM>w#w-d1t1331-1</LM>
   </w.rf>
   <form>Ostatní</form>
   <lemma>ostatní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m010-d1t1331-2">
   <w.rf>
    <LM>w#w-d1t1331-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1e1328-x2-4585">
   <w.rf>
    <LM>w#w-d1e1328-x2-4585</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-4586">
  <m id="m010-d1t1331-7">
   <w.rf>
    <LM>w#w-d1t1331-7</LM>
   </w.rf>
   <form>Některá</form>
   <lemma>některý</lemma>
   <tag>PZNP1----------</tag>
  </m>
  <m id="m010-d1t1331-9">
   <w.rf>
    <LM>w#w-d1t1331-9</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m010-d1t1333-1">
   <w.rf>
    <LM>w#w-d1t1333-1</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1333-2">
   <w.rf>
    <LM>w#w-d1t1333-2</LM>
   </w.rf>
   <form>Mýtská</form>
   <lemma>mýtský</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m010-d-id92835">
   <w.rf>
    <LM>w#w-d-id92835</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1333-4">
   <w.rf>
    <LM>w#w-d1t1333-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1335-3">
   <w.rf>
    <LM>w#w-d1t1335-3</LM>
   </w.rf>
   <form>chodilo</form>
   <lemma>chodit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m010-d1t1335-2">
   <w.rf>
    <LM>w#w-d1t1335-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1335-1">
   <w.rf>
    <LM>w#w-d1t1335-1</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m010-d1t1335-4">
   <w.rf>
    <LM>w#w-d1t1335-4</LM>
   </w.rf>
   <form>děvčat</form>
   <lemma>děvče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m010-d1t1335-5">
   <w.rf>
    <LM>w#w-d1t1335-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1335-6">
   <w.rf>
    <LM>w#w-d1t1335-6</LM>
   </w.rf>
   <form>okolních</form>
   <lemma>okolní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m010-d1t1335-7">
   <w.rf>
    <LM>w#w-d1t1335-7</LM>
   </w.rf>
   <form>vesnic</form>
   <lemma>vesnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m010-4586-4594">
   <w.rf>
    <LM>w#w-4586-4594</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-4595">
  <m id="m010-d1t1337-4">
   <w.rf>
    <LM>w#w-d1t1337-4</LM>
   </w.rf>
   <form>Říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1337-2">
   <w.rf>
    <LM>w#w-d1t1337-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-4595-4606">
   <w.rf>
    <LM>w#w-4595-4606</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m010-d1t1337-5">
   <w.rf>
    <LM>w#w-d1t1337-5</LM>
   </w.rf>
   <form>přespolní</form>
   <lemma>přespolní</lemma>
   <tag>AANP1----1A----</tag>
  </m>
  <m id="m010-d-id93058">
   <w.rf>
    <LM>w#w-d-id93058</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1337-8">
   <w.rf>
    <LM>w#w-d1t1337-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1343-1">
   <w.rf>
    <LM>w#w-d1t1343-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1343-3">
   <w.rf>
    <LM>w#w-d1t1343-3</LM>
   </w.rf>
   <form>Mýtě</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m010-d1e1328-x2-5776">
   <w.rf>
    <LM>w#w-d1e1328-x2-5776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1e1328-x2-5777">
   <w.rf>
    <LM>w#w-d1e1328-x2-5777</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d-id93139">
   <w.rf>
    <LM>w#w-d-id93139</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1338-x3">
  <m id="m010-d1t1345-1">
   <w.rf>
    <LM>w#w-d1t1345-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1345-2">
   <w.rf>
    <LM>w#w-d1t1345-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m010-d1t1345-3">
   <w.rf>
    <LM>w#w-d1t1345-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1345-4">
   <w.rf>
    <LM>w#w-d1t1345-4</LM>
   </w.rf>
   <form>dívčí</form>
   <lemma>dívčí</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m010-d1t1345-5">
   <w.rf>
    <LM>w#w-d1t1345-5</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d-id93277">
   <w.rf>
    <LM>w#w-d-id93277</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1346-x2">
  <m id="m010-d1t1349-1">
   <w.rf>
    <LM>w#w-d1t1349-1</LM>
   </w.rf>
   <form>Nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m010-d-id93354">
   <w.rf>
    <LM>w#w-d-id93354</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1349-3">
   <w.rf>
    <LM>w#w-d1t1349-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1349-4">
   <w.rf>
    <LM>w#w-d1t1349-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m010-d1t1349-5">
   <w.rf>
    <LM>w#w-d1t1349-5</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m010-d1t1349-6">
   <w.rf>
    <LM>w#w-d1t1349-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1349-7">
   <w.rf>
    <LM>w#w-d1t1349-7</LM>
   </w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m010-d1e1346-x2-5874">
   <w.rf>
    <LM>w#w-d1e1346-x2-5874</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1349-8">
   <w.rf>
    <LM>w#w-d1t1349-8</LM>
   </w.rf>
   <form>jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1349-9">
   <w.rf>
    <LM>w#w-d1t1349-9</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m010-d1t1349-10">
   <w.rf>
    <LM>w#w-d1t1349-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1349-11">
   <w.rf>
    <LM>w#w-d1t1349-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1349-12">
   <w.rf>
    <LM>w#w-d1t1349-12</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m010-d1t1349-13">
   <w.rf>
    <LM>w#w-d1t1349-13</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m010-d1e1346-x2-5878">
   <w.rf>
    <LM>w#w-d1e1346-x2-5878</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5879">
  <m id="m010-d1t1351-1">
   <w.rf>
    <LM>w#w-d1t1351-1</LM>
   </w.rf>
   <form>Mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m010-d1t1349-16">
   <w.rf>
    <LM>w#w-d1t1349-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1351-2">
   <w.rf>
    <LM>w#w-d1t1351-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m010-d1t1351-3">
   <w.rf>
    <LM>w#w-d1t1351-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1351-4">
   <w.rf>
    <LM>w#w-d1t1351-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1351-5">
   <w.rf>
    <LM>w#w-d1t1351-5</LM>
   </w.rf>
   <form>přiložit</form>
   <lemma>přiložit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m010-5879-5888">
   <w.rf>
    <LM>w#w-5879-5888</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5889">
  <m id="m010-d1t1357-2">
   <w.rf>
    <LM>w#w-d1t1357-2</LM>
   </w.rf>
   <form>Dokud</form>
   <lemma>dokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1357-3">
   <w.rf>
    <LM>w#w-d1t1357-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1357-4">
   <w.rf>
    <LM>w#w-d1t1357-4</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1357-5">
   <w.rf>
    <LM>w#w-d1t1357-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1357-6">
   <w.rf>
    <LM>w#w-d1t1357-6</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m010-d1t1357-7">
   <w.rf>
    <LM>w#w-d1t1357-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d-id93838">
   <w.rf>
    <LM>w#w-d-id93838</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1360-1">
   <w.rf>
    <LM>w#w-d1t1360-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1360-2">
   <w.rf>
    <LM>w#w-d1t1360-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1360-3">
   <w.rf>
    <LM>w#w-d1t1360-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1360-4">
   <w.rf>
    <LM>w#w-d1t1360-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m010-d1t1360-5">
   <w.rf>
    <LM>w#w-d1t1360-5</LM>
   </w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m010-d1t1360-6">
   <w.rf>
    <LM>w#w-d1t1360-6</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d-id93323">
   <w.rf>
    <LM>w#w-d-id93323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1363-x2">
  <m id="m010-d1t1368-1">
   <w.rf>
    <LM>w#w-d1t1368-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1368-2">
   <w.rf>
    <LM>w#w-d1t1368-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1368-3">
   <w.rf>
    <LM>w#w-d1t1368-3</LM>
   </w.rf>
   <form>přestoupili</form>
   <lemma>přestoupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m010-d1t1368-4">
   <w.rf>
    <LM>w#w-d1t1368-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1368-5">
   <w.rf>
    <LM>w#w-d1t1368-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1368-6">
   <w.rf>
    <LM>w#w-d1t1368-6</LM>
   </w.rf>
   <form>měšťanské</form>
   <lemma>měšťanský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m010-d1t1368-7">
   <w.rf>
    <LM>w#w-d1t1368-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d-id94139">
   <w.rf>
    <LM>w#w-d-id94139</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1378-1">
   <w.rf>
    <LM>w#w-d1t1378-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1378-2">
   <w.rf>
    <LM>w#w-d1t1378-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1378-3">
   <w.rf>
    <LM>w#w-d1t1378-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1378-5">
   <w.rf>
    <LM>w#w-d1t1378-5</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m010-d1t1378-6">
   <w.rf>
    <LM>w#w-d1t1378-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1378-7">
   <w.rf>
    <LM>w#w-d1t1378-7</LM>
   </w.rf>
   <form>chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m010-d1t1378-8">
   <w.rf>
    <LM>w#w-d1t1378-8</LM>
   </w.rf>
   <form>zvlášť</form>
   <lemma>zvlášť-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-6070-6102">
   <w.rf>
    <LM>w#w-6070-6102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-6070">
  <m id="m010-d1t1380-2">
   <w.rf>
    <LM>w#w-d1t1380-2</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-6070-6108">
   <w.rf>
    <LM>w#w-6070-6108</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1380-4">
   <w.rf>
    <LM>w#w-d1t1380-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m010-d1t1380-5">
   <w.rf>
    <LM>w#w-d1t1380-5</LM>
   </w.rf>
   <form>měšťanky</form>
   <lemma>měšťanka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d1t1380-7">
   <w.rf>
    <LM>w#w-d1t1380-7</LM>
   </w.rf>
   <form>chodily</form>
   <lemma>chodit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1382-2">
   <w.rf>
    <LM>w#w-d1t1382-2</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m010-d1t1382-3">
   <w.rf>
    <LM>w#w-d1t1382-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1382-5">
   <w.rf>
    <LM>w#w-d1t1382-5</LM>
   </w.rf>
   <form>okolních</form>
   <lemma>okolní</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m010-d1t1382-6">
   <w.rf>
    <LM>w#w-d1t1382-6</LM>
   </w.rf>
   <form>vesnic</form>
   <lemma>vesnice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m010-d-id94550">
   <w.rf>
    <LM>w#w-d-id94550</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1384-1">
   <w.rf>
    <LM>w#w-d1t1384-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1384-2">
   <w.rf>
    <LM>w#w-d1t1384-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1384-3">
   <w.rf>
    <LM>w#w-d1t1384-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1384-4">
   <w.rf>
    <LM>w#w-d1t1384-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1387-1">
   <w.rf>
    <LM>w#w-d1t1387-1</LM>
   </w.rf>
   <form>jednotřídku</form>
   <lemma>jednotřídka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m010-d-id94670">
   <w.rf>
    <LM>w#w-d-id94670</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1387-3">
   <w.rf>
    <LM>w#w-d1t1387-3</LM>
   </w.rf>
   <form>obecnou</form>
   <lemma>obecný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m010-d1t1387-4">
   <w.rf>
    <LM>w#w-d1t1387-4</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m010-d-id94203">
   <w.rf>
    <LM>w#w-d-id94203</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1388-x2">
  <m id="m010-d1t1391-2">
   <w.rf>
    <LM>w#w-d1t1391-2</LM>
   </w.rf>
   <form>Vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m010-d1e1388-x2-832">
   <w.rf>
    <LM>w#w-d1e1388-x2-832</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1391-3">
   <w.rf>
    <LM>w#w-d1t1391-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m010-d1t1391-4">
   <w.rf>
    <LM>w#w-d1t1391-4</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m010-d1t1391-5">
   <w.rf>
    <LM>w#w-d1t1391-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1391-6">
   <w.rf>
    <LM>w#w-d1t1391-6</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m010-d1t1391-7">
   <w.rf>
    <LM>w#w-d1t1391-7</LM>
   </w.rf>
   <form>srazy</form>
   <lemma>sraz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m010-d-id94871">
   <w.rf>
    <LM>w#w-d-id94871</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1392-x2">
  <m id="m010-d1t1397-1">
   <w.rf>
    <LM>w#w-d1t1397-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d-id94957">
   <w.rf>
    <LM>w#w-d-id94957</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1397-4">
   <w.rf>
    <LM>w#w-d1t1397-4</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1397-5">
   <w.rf>
    <LM>w#w-d1t1397-5</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m010-d1t1397-6">
   <w.rf>
    <LM>w#w-d1t1397-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1397-8">
   <w.rf>
    <LM>w#w-d1t1397-8</LM>
   </w.rf>
   <form>Mýtě</form>
   <lemma>Mýto-2_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m010-d1e1392-x2-6178">
   <w.rf>
    <LM>w#w-d1e1392-x2-6178</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1397-9">
   <w.rf>
    <LM>w#w-d1t1397-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1397-10">
   <w.rf>
    <LM>w#w-d1t1397-10</LM>
   </w.rf>
   <form>rozuteklo</form>
   <lemma>rozutéci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m010-d1t1397-11">
   <w.rf>
    <LM>w#w-d1t1397-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1397-12">
   <w.rf>
    <LM>w#w-d1t1397-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1397-13">
   <w.rf>
    <LM>w#w-d1t1397-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1397-15">
   <w.rf>
    <LM>w#w-d1t1397-15</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m010-d1t1397-16">
   <w.rf>
    <LM>w#w-d1t1397-16</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d-id95162">
   <w.rf>
    <LM>w#w-d-id95162</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1397-18">
   <w.rf>
    <LM>w#w-d1t1397-18</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1397-20">
   <w.rf>
    <LM>w#w-d1t1397-20</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m010-d1t1397-19">
   <w.rf>
    <LM>w#w-d1t1397-19</LM>
   </w.rf>
   <form>nevídám</form>
   <lemma>vídat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m010-d-id94918">
   <w.rf>
    <LM>w#w-d-id94918</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1398-x2">
  <m id="m010-d1t1401-1">
   <w.rf>
    <LM>w#w-d1t1401-1</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1401-2">
   <w.rf>
    <LM>w#w-d1t1401-2</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m010-d1t1401-3">
   <w.rf>
    <LM>w#w-d1t1401-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m010-d1t1401-4">
   <w.rf>
    <LM>w#w-d1t1401-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m010-d1t1401-5">
   <w.rf>
    <LM>w#w-d1t1401-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m010-d1t1401-6">
   <w.rf>
    <LM>w#w-d1t1401-6</LM>
   </w.rf>
   <form>povíte</form>
   <lemma>povědět</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m010-d-id95364">
   <w.rf>
    <LM>w#w-d-id95364</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1402-x2">
  <m id="m010-d1t1405-3">
   <w.rf>
    <LM>w#w-d1t1405-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1405-4">
   <w.rf>
    <LM>w#w-d1t1405-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d-id95480">
   <w.rf>
    <LM>w#w-d-id95480</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1405-6">
   <w.rf>
    <LM>w#w-d1t1405-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1405-7">
   <w.rf>
    <LM>w#w-d1t1405-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1413-2">
   <w.rf>
    <LM>w#w-d1t1413-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1413-1">
   <w.rf>
    <LM>w#w-d1t1413-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1413-3">
   <w.rf>
    <LM>w#w-d1t1413-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1413-4">
   <w.rf>
    <LM>w#w-d1t1413-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m010-d-id95561">
   <w.rf>
    <LM>w#w-d-id95561</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1406-x3">
  <m id="m010-d1t1415-1">
   <w.rf>
    <LM>w#w-d1t1415-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m010-d1e1406-x3-4985">
   <w.rf>
    <LM>w#w-d1e1406-x3-4985</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-4986">
  <m id="m010-d1t1420-3">
   <w.rf>
    <LM>w#w-d1t1420-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m010-d1t1420-2">
   <w.rf>
    <LM>w#w-d1t1420-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m010-d1t1420-4">
   <w.rf>
    <LM>w#w-d1t1420-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m010-d1t1420-5">
   <w.rf>
    <LM>w#w-d1t1420-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m010-d1t1420-6">
   <w.rf>
    <LM>w#w-d1t1420-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m010-d1e1406-x3-6314">
   <w.rf>
    <LM>w#w-d1e1406-x3-6314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-6315">
  <m id="m010-d1t1422-1">
   <w.rf>
    <LM>w#w-d1t1422-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1422-2">
   <w.rf>
    <LM>w#w-d1t1422-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1422-3">
   <w.rf>
    <LM>w#w-d1t1422-3</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d1t1422-4">
   <w.rf>
    <LM>w#w-d1t1422-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d-id95897">
   <w.rf>
    <LM>w#w-d-id95897</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1423-x2">
  <m id="m010-d1t1428-1">
   <w.rf>
    <LM>w#w-d1t1428-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m010-d1t1428-2">
   <w.rf>
    <LM>w#w-d1t1428-2</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1t1428-3">
   <w.rf>
    <LM>w#w-d1t1428-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1428-4">
   <w.rf>
    <LM>w#w-d1t1428-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1428-6">
   <w.rf>
    <LM>w#w-d1t1428-6</LM>
   </w.rf>
   <form>Rakovníka</form>
   <lemma>Rakovník_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m010-d1e1423-x2-5052">
   <w.rf>
    <LM>w#w-d1e1423-x2-5052</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-5053">
  <m id="m010-d1t1434-1">
   <w.rf>
    <LM>w#w-d1t1434-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1434-2">
   <w.rf>
    <LM>w#w-d1t1434-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1434-3">
   <w.rf>
    <LM>w#w-d1t1434-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1434-4">
   <w.rf>
    <LM>w#w-d1t1434-4</LM>
   </w.rf>
   <form>chmelu</form>
   <lemma>chmel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m010-d-id96121">
   <w.rf>
    <LM>w#w-d-id96121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1429-x3">
  <m id="m010-d1t1436-1">
   <w.rf>
    <LM>w#w-d1t1436-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1436-2">
   <w.rf>
    <LM>w#w-d1t1436-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1436-3">
   <w.rf>
    <LM>w#w-d1t1436-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d-id96240">
   <w.rf>
    <LM>w#w-d-id96240</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1437-x2">
  <m id="m010-d1t1440-1">
   <w.rf>
    <LM>w#w-d1t1440-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1440-2">
   <w.rf>
    <LM>w#w-d1t1440-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m010-d1t1440-3">
   <w.rf>
    <LM>w#w-d1t1440-3</LM>
   </w.rf>
   <form>1943</form>
   <lemma>1943</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m010-d-id96388">
   <w.rf>
    <LM>w#w-d-id96388</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1442-3">
   <w.rf>
    <LM>w#w-d1t1442-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1442-4">
   <w.rf>
    <LM>w#w-d1t1442-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m010-d1t1442-5">
   <w.rf>
    <LM>w#w-d1t1442-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1442-6">
   <w.rf>
    <LM>w#w-d1t1442-6</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d1e1437-x2-6499">
   <w.rf>
    <LM>w#w-d1e1437-x2-6499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-6500">
  <m id="m010-d1t1446-3">
   <w.rf>
    <LM>w#w-d1t1446-3</LM>
   </w.rf>
   <form>Zavezli</form>
   <lemma>zavézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m010-d1t1446-1">
   <w.rf>
    <LM>w#w-d1t1446-1</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m010-d1t1446-2">
   <w.rf>
    <LM>w#w-d1t1446-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1444-3">
   <w.rf>
    <LM>w#w-d1t1444-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m010-d1t1444-4">
   <w.rf>
    <LM>w#w-d1t1444-4</LM>
   </w.rf>
   <form>třináctileté</form>
   <lemma>třináctiletý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m010-d1t1444-5">
   <w.rf>
    <LM>w#w-d1t1444-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m010-d-id96625">
   <w.rf>
    <LM>w#w-d-id96625</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1446-6">
   <w.rf>
    <LM>w#w-d1t1446-6</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m010-d1t1448-1">
   <w.rf>
    <LM>w#w-d1t1448-1</LM>
   </w.rf>
   <form>pomáhaly</form>
   <lemma>pomáhat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1448-2">
   <w.rf>
    <LM>w#w-d1t1448-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m010-d1t1448-7">
   <w.rf>
    <LM>w#w-d1t1448-7</LM>
   </w.rf>
   <form>česáním</form>
   <lemma>česání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m010-d1t1448-8">
   <w.rf>
    <LM>w#w-d1t1448-8</LM>
   </w.rf>
   <form>chmelu</form>
   <lemma>chmel</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m010-d-id96286">
   <w.rf>
    <LM>w#w-d-id96286</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1449-x2">
  <m id="m010-d1t1452-1">
   <w.rf>
    <LM>w#w-d1t1452-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m010-d1t1452-2">
   <w.rf>
    <LM>w#w-d1t1452-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m010-d1t1452-3">
   <w.rf>
    <LM>w#w-d1t1452-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1452-4">
   <w.rf>
    <LM>w#w-d1t1452-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1452-5">
   <w.rf>
    <LM>w#w-d1t1452-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m010-d-id96908">
   <w.rf>
    <LM>w#w-d-id96908</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1453-x2">
  <m id="m010-d1t1458-3">
   <w.rf>
    <LM>w#w-d1t1458-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1458-2">
   <w.rf>
    <LM>w#w-d1t1458-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m010-d1t1458-4">
   <w.rf>
    <LM>w#w-d1t1458-4</LM>
   </w.rf>
   <form>děvčata</form>
   <lemma>děvče</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m010-d1t1458-5">
   <w.rf>
    <LM>w#w-d1t1458-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1458-6">
   <w.rf>
    <LM>w#w-d1t1458-6</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS2-P1-------</tag>
  </m>
  <m id="m010-d1t1458-7">
   <w.rf>
    <LM>w#w-d1t1458-7</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d1t1460-1">
   <w.rf>
    <LM>w#w-d1t1460-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1460-2">
   <w.rf>
    <LM>w#w-d1t1460-2</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m010-d1t1460-15">
   <w.rf>
    <LM>w#w-d1t1460-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1460-14">
   <w.rf>
    <LM>w#w-d1t1460-14</LM>
   </w.rf>
   <form>nepoznám</form>
   <lemma>poznat</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m010-d-id96954">
   <w.rf>
    <LM>w#w-d-id96954</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1461-x2">
  <m id="m010-d1t1466-4">
   <w.rf>
    <LM>w#w-d1t1466-4</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1466-3">
   <w.rf>
    <LM>w#w-d1t1466-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m010-d1t1466-8">
   <w.rf>
    <LM>w#w-d1t1466-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1466-5">
   <w.rf>
    <LM>w#w-d1t1466-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1t1466-6">
   <w.rf>
    <LM>w#w-d1t1466-6</LM>
   </w.rf>
   <form>odjinud</form>
   <lemma>odjinud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1e1461-x2-5199">
   <w.rf>
    <LM>w#w-d1e1461-x2-5199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1466-9">
   <w.rf>
    <LM>w#w-d1t1466-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m010-d1t1466-10">
   <w.rf>
    <LM>w#w-d1t1466-10</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m010-d1t1466-11">
   <w.rf>
    <LM>w#w-d1t1466-11</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m010-d-id97336">
   <w.rf>
    <LM>w#w-d-id97336</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1461-x3">
  <m id="m010-d1t1468-1">
   <w.rf>
    <LM>w#w-d1t1468-1</LM>
   </w.rf>
   <form>Jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m010-d1t1468-2">
   <w.rf>
    <LM>w#w-d1t1468-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1468-3">
   <w.rf>
    <LM>w#w-d1t1468-3</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m010-d-id97550">
   <w.rf>
    <LM>w#w-d-id97550</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1469-x2">
  <m id="m010-d1t1474-4">
   <w.rf>
    <LM>w#w-d1t1474-4</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m010-d1e1469-x2-6655">
   <w.rf>
    <LM>w#w-d1e1469-x2-6655</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1476-1">
   <w.rf>
    <LM>w#w-d1t1476-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1476-7">
   <w.rf>
    <LM>w#w-d1t1476-7</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d1t1476-6">
   <w.rf>
    <LM>w#w-d1t1476-6</LM>
   </w.rf>
   <form>třetí</form>
   <lemma>třetí</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m010-d1t1476-8">
   <w.rf>
    <LM>w#w-d1t1476-8</LM>
   </w.rf>
   <form>zleva</form>
   <lemma>zleva</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m010-d-id97826">
   <w.rf>
    <LM>w#w-d-id97826</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m010-d1t1476-12">
   <w.rf>
    <LM>w#w-d1t1476-12</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m010-d1t1476-13">
   <w.rf>
    <LM>w#w-d1t1476-13</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m010-d1t1482-1">
   <w.rf>
    <LM>w#w-d1t1482-1</LM>
   </w.rf>
   <form>bílou</form>
   <lemma>bílý_;o</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m010-d1t1482-2">
   <w.rf>
    <LM>w#w-d1t1482-2</LM>
   </w.rf>
   <form>zástěru</form>
   <lemma>zástěra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m010-d1t1490-1">
   <w.rf>
    <LM>w#w-d1t1490-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m010-d1t1490-2">
   <w.rf>
    <LM>w#w-d1t1490-2</LM>
   </w.rf>
   <form>šátek</form>
   <lemma>šátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m010-d1t1490-3">
   <w.rf>
    <LM>w#w-d1t1490-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m010-d1t1490-4">
   <w.rf>
    <LM>w#w-d1t1490-4</LM>
   </w.rf>
   <form>hlavě</form>
   <lemma>hlava</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m010-d-id98009">
   <w.rf>
    <LM>w#w-d-id98009</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m010-d1e1491-x2">
  <m id="m010-d1t1494-1">
   <w.rf>
    <LM>w#w-d1t1494-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m010-d1t1494-2">
   <w.rf>
    <LM>w#w-d1t1494-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m010-d1t1494-3">
   <w.rf>
    <LM>w#w-d1t1494-3</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m010-d1t1494-4">
   <w.rf>
    <LM>w#w-d1t1494-4</LM>
   </w.rf>
   <form>školní</form>
   <lemma>školní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m010-d1t1494-5">
   <w.rf>
    <LM>w#w-d1t1494-5</LM>
   </w.rf>
   <form>brigáda</form>
   <lemma>brigáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m010-d-id98210">
   <w.rf>
    <LM>w#w-d-id98210</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
