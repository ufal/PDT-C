<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_017.11.w.gz" />
  </references>
 </head>
 <s id="m017-1146">
  <m id="m017-d1t3291-6">
   <w.rf>
    <LM>w#w-d1t3291-6</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m017-d1t3291-7">
   <w.rf>
    <LM>w#w-d1t3291-7</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m017-d1t3291-8">
   <w.rf>
    <LM>w#w-d1t3291-8</LM>
   </w.rf>
   <form>přinesl</form>
   <lemma>přinést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d-m-d1e3282-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3282-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3292-x2">
  <m id="m017-d1t3295-1">
   <w.rf>
    <LM>w#w-d1t3295-1</LM>
   </w.rf>
   <form>Sešla</form>
   <lemma>sejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m017-d1t3295-2">
   <w.rf>
    <LM>w#w-d1t3295-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3295-3">
   <w.rf>
    <LM>w#w-d1t3295-3</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t3295-4">
   <w.rf>
    <LM>w#w-d1t3295-4</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d-id164259-punct">
   <w.rf>
    <LM>w#w-d-id164259-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3300-x2">
  <m id="m017-d1t3303-1">
   <w.rf>
    <LM>w#w-d1t3303-1</LM>
   </w.rf>
   <form>Sešla</form>
   <lemma>sejít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m017-d1t3303-2">
   <w.rf>
    <LM>w#w-d1t3303-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3303-3">
   <w.rf>
    <LM>w#w-d1t3303-3</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t3303-4">
   <w.rf>
    <LM>w#w-d1t3303-4</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e3300-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3300-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3304-x2">
  <m id="m017-d1t3307-1">
   <w.rf>
    <LM>w#w-d1t3307-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3307-2">
   <w.rf>
    <LM>w#w-d1t3307-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t3307-3">
   <w.rf>
    <LM>w#w-d1t3307-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d1e3304-x2-354">
   <w.rf>
    <LM>w#w-d1e3304-x2-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-356">
  <m id="m017-d1t3309-1">
   <w.rf>
    <LM>w#w-d1t3309-1</LM>
   </w.rf>
   <form>Scházíte</form>
   <lemma>scházet</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t3309-2">
   <w.rf>
    <LM>w#w-d1t3309-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3309-3">
   <w.rf>
    <LM>w#w-d1t3309-3</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3309-4">
   <w.rf>
    <LM>w#w-d1t3309-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t3309-5">
   <w.rf>
    <LM>w#w-d1t3309-5</LM>
   </w.rf>
   <form>jindy</form>
   <lemma>jindy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3309-6">
   <w.rf>
    <LM>w#w-d1t3309-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3309-7">
   <w.rf>
    <LM>w#w-d1t3309-7</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t3309-8">
   <w.rf>
    <LM>w#w-d1t3309-8</LM>
   </w.rf>
   <form>oslavách</form>
   <lemma>oslava</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m017-d-id164633-punct">
   <w.rf>
    <LM>w#w-d-id164633-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3310-x2">
  <m id="m017-d1e3310-x2-386">
   <w.rf>
    <LM>w#w-d1e3310-x2-386</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3315-2">
   <w.rf>
    <LM>w#w-d1t3315-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3315-1">
   <w.rf>
    <LM>w#w-d1t3315-1</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m017-d1t3315-3">
   <w.rf>
    <LM>w#w-d1t3315-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m017-d1e3310-x2-390">
   <w.rf>
    <LM>w#w-d1e3310-x2-390</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-392_2">
  <m id="m017-d1t3315-6">
   <w.rf>
    <LM>w#w-d1t3315-6</LM>
   </w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t3315-7">
   <w.rf>
    <LM>w#w-d1t3315-7</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m017-392_2-1161">
   <w.rf>
    <LM>w#w-392_2-1161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3315-10">
   <w.rf>
    <LM>w#w-d1t3315-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-392_2-1162">
   <w.rf>
    <LM>w#w-392_2-1162</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3315-12">
   <w.rf>
    <LM>w#w-d1t3315-12</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m017-d1t3315-11">
   <w.rf>
    <LM>w#w-d1t3315-11</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-392_2-1163">
   <w.rf>
    <LM>w#w-392_2-1163</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3317-1">
   <w.rf>
    <LM>w#w-d1t3317-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3317-2">
   <w.rf>
    <LM>w#w-d1t3317-2</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t3317-4">
   <w.rf>
    <LM>w#w-d1t3317-4</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m017-d1t3317-5">
   <w.rf>
    <LM>w#w-d1t3317-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t3317-6">
   <w.rf>
    <LM>w#w-d1t3317-6</LM>
   </w.rf>
   <form>svátek</form>
   <lemma>svátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d-id165043-punct">
   <w.rf>
    <LM>w#w-d-id165043-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3317-10">
   <w.rf>
    <LM>w#w-d1t3317-10</LM>
   </w.rf>
   <form>zajdeme</form>
   <lemma>zajít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m017-d1t3317-9">
   <w.rf>
    <LM>w#w-d1t3317-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id165092-punct">
   <w.rf>
    <LM>w#w-d-id165092-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3317-12">
   <w.rf>
    <LM>w#w-d1t3317-12</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m017-d1t3317-13">
   <w.rf>
    <LM>w#w-d1t3317-13</LM>
   </w.rf>
   <form>zajdou</form>
   <lemma>zajít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m017-d1t3319-1">
   <w.rf>
    <LM>w#w-d1t3319-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t3319-2">
   <w.rf>
    <LM>w#w-d1t3319-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m017-392_2-1165">
   <w.rf>
    <LM>w#w-392_2-1165</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1164">
  <m id="m017-d1t3319-5">
   <w.rf>
    <LM>w#w-d1t3319-5</LM>
   </w.rf>
   <form>Sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t3319-7">
   <w.rf>
    <LM>w#w-d1t3319-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3319-8">
   <w.rf>
    <LM>w#w-d1t3319-8</LM>
   </w.rf>
   <form>špatně</form>
   <lemma>špatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t3319-10">
   <w.rf>
    <LM>w#w-d1t3319-10</LM>
   </w.rf>
   <form>chodí</form>
   <lemma>chodit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-398-400">
   <w.rf>
    <LM>w#w-398-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-402">
  <m id="m017-d1t3321-9">
   <w.rf>
    <LM>w#w-d1t3321-9</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3321-10">
   <w.rf>
    <LM>w#w-d1t3321-10</LM>
   </w.rf>
   <form>přijedou</form>
   <lemma>přijet</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m017-d1t3321-11">
   <w.rf>
    <LM>w#w-d1t3321-11</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9XP1FS3-------</tag>
  </m>
  <m id="m017-d1t3321-12">
   <w.rf>
    <LM>w#w-d1t3321-12</LM>
   </w.rf>
   <form>příbuzní</form>
   <lemma>příbuzný-1_^(člen_rodiny)</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m017-d-id165468-punct">
   <w.rf>
    <LM>w#w-d-id165468-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3321-16">
   <w.rf>
    <LM>w#w-d1t3321-16</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t3321-17">
   <w.rf>
    <LM>w#w-d1t3321-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t3324-2">
   <w.rf>
    <LM>w#w-d1t3324-2</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d-id165550-punct">
   <w.rf>
    <LM>w#w-d-id165550-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3324-6">
   <w.rf>
    <LM>w#w-d1t3324-6</LM>
   </w.rf>
   <form>zajdou</form>
   <lemma>zajít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m017-d1t3324-5">
   <w.rf>
    <LM>w#w-d1t3324-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3326-1">
   <w.rf>
    <LM>w#w-d1t3326-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t3326-2">
   <w.rf>
    <LM>w#w-d1t3326-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m017-d-id165638-punct">
   <w.rf>
    <LM>w#w-d-id165638-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3326-4">
   <w.rf>
    <LM>w#w-d1t3326-4</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3328-1">
   <w.rf>
    <LM>w#w-d1t3328-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t3328-2">
   <w.rf>
    <LM>w#w-d1t3328-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3328-3">
   <w.rf>
    <LM>w#w-d1t3328-3</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3328-4">
   <w.rf>
    <LM>w#w-d1t3328-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t3328-5">
   <w.rf>
    <LM>w#w-d1t3328-5</LM>
   </w.rf>
   <form>kontaktu</form>
   <lemma>kontakt</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-402-1209">
   <w.rf>
    <LM>w#w-402-1209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1210">
  <m id="m017-d1t3328-8">
   <w.rf>
    <LM>w#w-d1t3328-8</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t3328-9">
   <w.rf>
    <LM>w#w-d1t3328-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t3328-10">
   <w.rf>
    <LM>w#w-d1t3328-10</LM>
   </w.rf>
   <form>manželčiny</form>
   <lemma>manželčin_^(*3ka)</lemma>
   <tag>AUFS2F---------</tag>
  </m>
  <m id="m017-d1t3330-1">
   <w.rf>
    <LM>w#w-d1t3330-1</LM>
   </w.rf>
   <form>strany</form>
   <lemma>strana</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m017-d-m-d1e3310-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3310-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3331-x2">
  <m id="m017-d1t3336-2">
   <w.rf>
    <LM>w#w-d1t3336-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3336-3">
   <w.rf>
    <LM>w#w-d1t3336-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t3336-4">
   <w.rf>
    <LM>w#w-d1t3336-4</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d1e3331-x2-492">
   <w.rf>
    <LM>w#w-d1e3331-x2-492</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-494_2">
  <m id="m017-d1t3338-1">
   <w.rf>
    <LM>w#w-d1t3338-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m017-d1t3338-2">
   <w.rf>
    <LM>w#w-d1t3338-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m017-d1t3338-3">
   <w.rf>
    <LM>w#w-d1t3338-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3338-4">
   <w.rf>
    <LM>w#w-d1t3338-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t3338-5">
   <w.rf>
    <LM>w#w-d1t3338-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m017-d1t3338-6">
   <w.rf>
    <LM>w#w-d1t3338-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t3340-1">
   <w.rf>
    <LM>w#w-d1t3340-1</LM>
   </w.rf>
   <form>oslavy</form>
   <lemma>oslava</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m017-d-id166095-punct">
   <w.rf>
    <LM>w#w-d-id166095-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3341-x2">
  <m id="m017-d1t3346-3">
   <w.rf>
    <LM>w#w-d1t3346-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3346-4">
   <w.rf>
    <LM>w#w-d1t3346-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3346-5">
   <w.rf>
    <LM>w#w-d1t3346-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3346-6">
   <w.rf>
    <LM>w#w-d1t3346-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1t3346-7">
   <w.rf>
    <LM>w#w-d1t3346-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t3346-8">
   <w.rf>
    <LM>w#w-d1t3346-8</LM>
   </w.rf>
   <form>náladě</form>
   <lemma>nálada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d-id166309-punct">
   <w.rf>
    <LM>w#w-d-id166309-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3356-12">
   <w.rf>
    <LM>w#w-d1t3356-12</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t3356-10">
   <w.rf>
    <LM>w#w-d1t3356-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3356-13">
   <w.rf>
    <LM>w#w-d1t3356-13</LM>
   </w.rf>
   <form>hodit</form>
   <lemma>hodit-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d1e3341-x2-512">
   <w.rf>
    <LM>w#w-d1e3341-x2-512</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t3356-7">
   <w.rf>
    <LM>w#w-d1t3356-7</LM>
   </w.rf>
   <form>bazénu</form>
   <lemma>bazén</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m017-d1e3341-x2-514">
   <w.rf>
    <LM>w#w-d1e3341-x2-514</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3356-2">
   <w.rf>
    <LM>w#w-d1t3356-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t3356-3">
   <w.rf>
    <LM>w#w-d1t3356-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t3356-4">
   <w.rf>
    <LM>w#w-d1t3356-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3356-5">
   <w.rf>
    <LM>w#w-d1t3356-5</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1e3341-x2-1216">
   <w.rf>
    <LM>w#w-d1e3341-x2-1216</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1217">
  <m id="m017-d1t3366-4">
   <w.rf>
    <LM>w#w-d1t3366-4</LM>
   </w.rf>
   <form>Bývali</form>
   <lemma>bývat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t3366-2">
   <w.rf>
    <LM>w#w-d1t3366-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m017-d1t3366-3">
   <w.rf>
    <LM>w#w-d1t3366-3</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m017-d1t3366-5">
   <w.rf>
    <LM>w#w-d1t3366-5</LM>
   </w.rf>
   <form>polámali</form>
   <lemma>polámat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d-m-d1e3363-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3363-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3382-x2">
  <m id="m017-d1t3385-1">
   <w.rf>
    <LM>w#w-d1t3385-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1e3382-x2-518">
   <w.rf>
    <LM>w#w-d1e3382-x2-518</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-520">
  <m id="m017-d1t3385-4">
   <w.rf>
    <LM>w#w-d1t3385-4</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t3385-5">
   <w.rf>
    <LM>w#w-d1t3385-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m017-d1t3385-6">
   <w.rf>
    <LM>w#w-d1t3385-6</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t3385-7">
   <w.rf>
    <LM>w#w-d1t3385-7</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-520-522">
   <w.rf>
    <LM>w#w-520-522</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-524_2">
  <m id="m017-d1t3387-1">
   <w.rf>
    <LM>w#w-d1t3387-1</LM>
   </w.rf>
   <form>Děkujeme</form>
   <lemma>děkovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t3387-2">
   <w.rf>
    <LM>w#w-d1t3387-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m017-d1t3387-3">
   <w.rf>
    <LM>w#w-d1t3387-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t3387-4">
   <w.rf>
    <LM>w#w-d1t3387-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSIS4-P2-------</tag>
  </m>
  <m id="m017-d1t3387-5">
   <w.rf>
    <LM>w#w-d1t3387-5</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d-m-d1e3382-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3382-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3388-x2">
  <m id="m017-d1t3391-3">
   <w.rf>
    <LM>w#w-d1t3391-3</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d1t3391-4">
   <w.rf>
    <LM>w#w-d1t3391-4</LM>
   </w.rf>
   <form>zač</form>
   <lemma>co-1</lemma>
   <tag>PQ--4--------z-</tag>
  </m>
  <m id="m017-d-m-d1e3388-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3388-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3392-x2">
  <m id="m017-d1t3395-1">
   <w.rf>
    <LM>w#w-d1t3395-1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t3395-2">
   <w.rf>
    <LM>w#w-d1t3395-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t3395-3">
   <w.rf>
    <LM>w#w-d1t3395-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t3395-4">
   <w.rf>
    <LM>w#w-d1t3395-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m017-d1t3395-5">
   <w.rf>
    <LM>w#w-d1t3395-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t3395-6">
   <w.rf>
    <LM>w#w-d1t3395-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m017-d1t3395-7">
   <w.rf>
    <LM>w#w-d1t3395-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1e3392-x2-530">
   <w.rf>
    <LM>w#w-d1e3392-x2-530</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-532">
  <m id="m017-d1t3399-1">
   <w.rf>
    <LM>w#w-d1t3399-1</LM>
   </w.rf>
   <form>Počkejte</form>
   <lemma>počkat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m017-d1t3399-2">
   <w.rf>
    <LM>w#w-d1t3399-2</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-id167397-punct">
   <w.rf>
    <LM>w#w-d-id167397-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t3399-4">
   <w.rf>
    <LM>w#w-d1t3399-4</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m017-d1t3399-5">
   <w.rf>
    <LM>w#w-d1t3399-5</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m017-d1t3399-6">
   <w.rf>
    <LM>w#w-d1t3399-6</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m017-d1t3399-7">
   <w.rf>
    <LM>w#w-d1t3399-7</LM>
   </w.rf>
   <form>vysvobodit</form>
   <lemma>vysvobodit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-d-m-d1e3392-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3392-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3400-x2">
  <m id="m017-d1t3405-1">
   <w.rf>
    <LM>w#w-d1t3405-1</LM>
   </w.rf>
   <form>Nashledanou</form>
   <lemma>nashledanou</lemma>
   <tag>TT------------6</tag>
  </m>
  <m id="m017-d-m-d1e3400-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3400-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e3400-x3">
  <m id="m017-d1t3407-1">
   <w.rf>
    <LM>w#w-d1t3407-1</LM>
   </w.rf>
   <form>Nashledanou</form>
   <lemma>nashledanou</lemma>
   <tag>TT------------6</tag>
  </m>
  <m id="m017-d-m-d1e3400-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3400-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
