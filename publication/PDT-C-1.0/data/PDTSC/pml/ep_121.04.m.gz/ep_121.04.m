<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ep_121.04.w.gz" />
  </references>
 </head>
 <s id="m121-d1e902-x2">
  <m id="m121-d1t907-1">
   <w.rf>
    <LM>w#w-d1t907-1</LM>
   </w.rf>
   <form>Odkud</form>
   <lemma>odkud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t907-2">
   <w.rf>
    <LM>w#w-d1t907-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t907-3">
   <w.rf>
    <LM>w#w-d1t907-3</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m121-d1t907-4">
   <w.rf>
    <LM>w#w-d1t907-4</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id103040-punct">
   <w.rf>
    <LM>w#w-d-id103040-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e914-x2">
  <m id="m121-d1t911-3">
   <w.rf>
    <LM>w#w-d1t911-3</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t911-4">
   <w.rf>
    <LM>w#w-d1t911-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t911-5">
   <w.rf>
    <LM>w#w-d1t911-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t917-1">
   <w.rf>
    <LM>w#w-d1t917-1</LM>
   </w.rf>
   <form>šťastná</form>
   <lemma>šťastný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t917-2">
   <w.rf>
    <LM>w#w-d1t917-2</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t917-3">
   <w.rf>
    <LM>w#w-d1t917-3</LM>
   </w.rf>
   <form>dvouletého</form>
   <lemma>dvouletý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m121-d1t917-4">
   <w.rf>
    <LM>w#w-d1t917-4</LM>
   </w.rf>
   <form>syna</form>
   <lemma>syn</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m121-d1e914-x2-55">
   <w.rf>
    <LM>w#w-d1e914-x2-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-56">
  <m id="m121-d1t917-6">
   <w.rf>
    <LM>w#w-d1t917-6</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m121-d1t917-7">
   <w.rf>
    <LM>w#w-d1t917-7</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1e914-x2-169">
   <w.rf>
    <LM>w#w-d1e914-x2-169</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t919-7">
   <w.rf>
    <LM>w#w-d1t919-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t919-9">
   <w.rf>
    <LM>w#w-d1t919-9</LM>
   </w.rf>
   <form>Krkonoš</form>
   <lemma>Krkonoše_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-d1e914-x2-170">
   <w.rf>
    <LM>w#w-d1e914-x2-170</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t921-4">
   <w.rf>
    <LM>w#w-d1t921-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t921-3">
   <w.rf>
    <LM>w#w-d1t921-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t921-2">
   <w.rf>
    <LM>w#w-d1t921-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t921-5">
   <w.rf>
    <LM>w#w-d1t921-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t921-6">
   <w.rf>
    <LM>w#w-d1t921-6</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m121-d1t921-7">
   <w.rf>
    <LM>w#w-d1t921-7</LM>
   </w.rf>
   <form>rekreaci</form>
   <lemma>rekreace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-56-406">
   <w.rf>
    <LM>w#w-56-406</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-407">
  <m id="m121-d1t921-10">
   <w.rf>
    <LM>w#w-d1t921-10</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t921-9">
   <w.rf>
    <LM>w#w-d1t921-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t921-12">
   <w.rf>
    <LM>w#w-d1t921-12</LM>
   </w.rf>
   <form>šťastné</form>
   <lemma>šťastný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d1t921-13">
   <w.rf>
    <LM>w#w-d1t921-13</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-56-57">
   <w.rf>
    <LM>w#w-56-57</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t925-6">
   <w.rf>
    <LM>w#w-d1t925-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t925-5">
   <w.rf>
    <LM>w#w-d1t925-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t925-7">
   <w.rf>
    <LM>w#w-d1t925-7</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t925-1">
   <w.rf>
    <LM>w#w-d1t925-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t925-2">
   <w.rf>
    <LM>w#w-d1t925-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t925-4">
   <w.rf>
    <LM>w#w-d1t925-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d-id103833-punct">
   <w.rf>
    <LM>w#w-d-id103833-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t925-9">
   <w.rf>
    <LM>w#w-d1t925-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t928-3">
   <w.rf>
    <LM>w#w-d1t928-3</LM>
   </w.rf>
   <form>všecko</form>
   <lemma>všecek</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m121-d1t928-2">
   <w.rf>
    <LM>w#w-d1t928-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t928-5">
   <w.rf>
    <LM>w#w-d1t928-5</LM>
   </w.rf>
   <form>pozitivní</form>
   <lemma>pozitivní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-m-d1e914-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e914-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e929-x2">
  <m id="m121-d1t932-1">
   <w.rf>
    <LM>w#w-d1t932-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d1t932-2">
   <w.rf>
    <LM>w#w-d1t932-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m121-d1t932-3">
   <w.rf>
    <LM>w#w-d1t932-3</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d-id104044-punct">
   <w.rf>
    <LM>w#w-d-id104044-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e933-x2">
  <m id="m121-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d-id104121-punct">
   <w.rf>
    <LM>w#w-d-id104121-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t936-3">
   <w.rf>
    <LM>w#w-d1t936-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t936-4">
   <w.rf>
    <LM>w#w-d1t936-4</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m121-d1t936-5">
   <w.rf>
    <LM>w#w-d1t936-5</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d1e933-x2-413">
   <w.rf>
    <LM>w#w-d1e933-x2-413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-414">
  <m id="m121-d1t940-2">
   <w.rf>
    <LM>w#w-d1t940-2</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m121-d-id104232-punct">
   <w.rf>
    <LM>w#w-d-id104232-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t940-4">
   <w.rf>
    <LM>w#w-d1t940-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t940-5">
   <w.rf>
    <LM>w#w-d1t940-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t940-6">
   <w.rf>
    <LM>w#w-d1t940-6</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t940-7">
   <w.rf>
    <LM>w#w-d1t940-7</LM>
   </w.rf>
   <form>tátu</form>
   <lemma>táta</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m121-d1t940-8">
   <w.rf>
    <LM>w#w-d1t940-8</LM>
   </w.rf>
   <form>sportovce</form>
   <lemma>sportovec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m121-d-id104318-punct">
   <w.rf>
    <LM>w#w-d-id104318-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t940-10">
   <w.rf>
    <LM>w#w-d1t940-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t940-11">
   <w.rf>
    <LM>w#w-d1t940-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t942-1">
   <w.rf>
    <LM>w#w-d1t942-1</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m121-d1t942-2">
   <w.rf>
    <LM>w#w-d1t942-2</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m121-d1t940-12">
   <w.rf>
    <LM>w#w-d1t940-12</LM>
   </w.rf>
   <form>lyžování</form>
   <lemma>lyžování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-d1e933-x2-182">
   <w.rf>
    <LM>w#w-d1e933-x2-182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-183">
  <m id="m121-d1t942-4">
   <w.rf>
    <LM>w#w-d1t942-4</LM>
   </w.rf>
   <form>Zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d-id104445-punct">
   <w.rf>
    <LM>w#w-d-id104445-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t942-6">
   <w.rf>
    <LM>w#w-d1t942-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t942-7">
   <w.rf>
    <LM>w#w-d1t942-7</LM>
   </w.rf>
   <form>mluvím</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t942-8">
   <w.rf>
    <LM>w#w-d1t942-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t942-9">
   <w.rf>
    <LM>w#w-d1t942-9</LM>
   </w.rf>
   <form>množném</form>
   <lemma>množný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m121-d1t942-10">
   <w.rf>
    <LM>w#w-d1t942-10</LM>
   </w.rf>
   <form>čísle</form>
   <lemma>číslo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-183-422">
   <w.rf>
    <LM>w#w-183-422</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-423">
  <m id="m121-d1t942-13">
   <w.rf>
    <LM>w#w-d1t942-13</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t942-15">
   <w.rf>
    <LM>w#w-d1t942-15</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d-id104602-punct">
   <w.rf>
    <LM>w#w-d-id104602-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t942-19">
   <w.rf>
    <LM>w#w-d1t942-19</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t942-20">
   <w.rf>
    <LM>w#w-d1t942-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t942-21">
   <w.rf>
    <LM>w#w-d1t942-21</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t942-22">
   <w.rf>
    <LM>w#w-d1t942-22</LM>
   </w.rf>
   <form>vychovávána</form>
   <lemma>vychovávat_^(*4at)</lemma>
   <tag>VsQW----X-API--</tag>
  </m>
  <m id="m121-d1t942-26">
   <w.rf>
    <LM>w#w-d1t942-26</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t942-27">
   <w.rf>
    <LM>w#w-d1t942-27</LM>
   </w.rf>
   <form>žila</form>
   <lemma>žít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t942-29">
   <w.rf>
    <LM>w#w-d1t942-29</LM>
   </w.rf>
   <form>úzce</form>
   <lemma>úzce</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t942-30">
   <w.rf>
    <LM>w#w-d1t942-30</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t942-32">
   <w.rf>
    <LM>w#w-d1t942-32</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m121-d1t942-33">
   <w.rf>
    <LM>w#w-d1t942-33</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-423-424">
   <w.rf>
    <LM>w#w-423-424</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-425">
  <m id="m121-183-184">
   <w.rf>
    <LM>w#w-183-184</LM>
   </w.rf>
   <form>Uvědomuji</form>
   <lemma>uvědomovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m121-d1t944-3">
   <w.rf>
    <LM>w#w-d1t944-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d-id104940-punct">
   <w.rf>
    <LM>w#w-d-id104940-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t947-2">
   <w.rf>
    <LM>w#w-d1t947-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t947-3">
   <w.rf>
    <LM>w#w-d1t947-3</LM>
   </w.rf>
   <form>řikám</form>
   <lemma>řikat_,h_^(^GC**říkat)</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t947-4">
   <w.rf>
    <LM>w#w-d1t947-4</LM>
   </w.rf>
   <form>množné</form>
   <lemma>množný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m121-d1t947-5">
   <w.rf>
    <LM>w#w-d1t947-5</LM>
   </w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-d-id105011-punct">
   <w.rf>
    <LM>w#w-d-id105011-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t947-7">
   <w.rf>
    <LM>w#w-d1t947-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t947-8">
   <w.rf>
    <LM>w#w-d1t947-8</LM>
   </w.rf>
   <form>patří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t947-9">
   <w.rf>
    <LM>w#w-d1t947-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t947-11">
   <w.rf>
    <LM>w#w-d1t947-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t947-12">
   <w.rf>
    <LM>w#w-d1t947-12</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t947-13">
   <w.rf>
    <LM>w#w-d1t947-13</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t947-14">
   <w.rf>
    <LM>w#w-d1t947-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t947-15">
   <w.rf>
    <LM>w#w-d1t947-15</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS4-S1------6</tag>
  </m>
  <m id="m121-d1t947-16">
   <w.rf>
    <LM>w#w-d1t947-16</LM>
   </w.rf>
   <form>sestru</form>
   <lemma>sestra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e933-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e933-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e948-x2">
  <m id="m121-d1t955-2">
   <w.rf>
    <LM>w#w-d1t955-2</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d1t955-3">
   <w.rf>
    <LM>w#w-d1t955-3</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m121-d1t955-4">
   <w.rf>
    <LM>w#w-d1t955-4</LM>
   </w.rf>
   <form>zimní</form>
   <lemma>zimní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m121-d1t955-5">
   <w.rf>
    <LM>w#w-d1t955-5</LM>
   </w.rf>
   <form>sporty</form>
   <lemma>sport</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-d-id105323-punct">
   <w.rf>
    <LM>w#w-d-id105323-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e956-x2">
  <m id="m121-d1t959-1">
   <w.rf>
    <LM>w#w-d1t959-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d-id105400-punct">
   <w.rf>
    <LM>w#w-d-id105400-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t959-3">
   <w.rf>
    <LM>w#w-d1t959-3</LM>
   </w.rf>
   <form>lyžuji</form>
   <lemma>lyžovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m121-d1e956-x2-432">
   <w.rf>
    <LM>w#w-d1e956-x2-432</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-433">
  <m id="m121-d1t959-5">
   <w.rf>
    <LM>w#w-d1t959-5</LM>
   </w.rf>
   <form>Dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t959-6">
   <w.rf>
    <LM>w#w-d1t959-6</LM>
   </w.rf>
   <form>chodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t959-9">
   <w.rf>
    <LM>w#w-d1t959-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t959-10">
   <w.rf>
    <LM>w#w-d1t959-10</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t959-7">
   <w.rf>
    <LM>w#w-d1t959-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t959-8">
   <w.rf>
    <LM>w#w-d1t959-8</LM>
   </w.rf>
   <form>běžky</form>
   <lemma>běžka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d-id105526-punct">
   <w.rf>
    <LM>w#w-d-id105526-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t959-12">
   <w.rf>
    <LM>w#w-d1t959-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1e956-x2-191">
   <w.rf>
    <LM>w#w-d1e956-x2-191</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t961-1">
   <w.rf>
    <LM>w#w-d1t961-1</LM>
   </w.rf>
   <form>sjezdu</form>
   <lemma>sjezd</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m121-d1t961-6">
   <w.rf>
    <LM>w#w-d1t961-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t961-5">
   <w.rf>
    <LM>w#w-d1t961-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t961-7">
   <w.rf>
    <LM>w#w-d1t961-7</LM>
   </w.rf>
   <form>bojím</form>
   <lemma>bát-1</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t961-8">
   <w.rf>
    <LM>w#w-d1t961-8</LM>
   </w.rf>
   <form>padat</form>
   <lemma>padat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d-id105684-punct">
   <w.rf>
    <LM>w#w-d-id105684-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t961-10">
   <w.rf>
    <LM>w#w-d1t961-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t961-12">
   <w.rf>
    <LM>w#w-d1t961-12</LM>
   </w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t961-11">
   <w.rf>
    <LM>w#w-d1t961-11</LM>
   </w.rf>
   <form>běžkařím</form>
   <lemma>běžkařit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d-m-d1e956-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e956-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e962-x2">
  <m id="m121-d1t965-1">
   <w.rf>
    <LM>w#w-d1t965-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t965-2">
   <w.rf>
    <LM>w#w-d1t965-2</LM>
   </w.rf>
   <form>kterých</form>
   <lemma>který</lemma>
   <tag>P4XP2----------</tag>
  </m>
  <m id="m121-d1t965-3">
   <w.rf>
    <LM>w#w-d1t965-3</LM>
   </w.rf>
   <form>hor</form>
   <lemma>hora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-d1t965-4">
   <w.rf>
    <LM>w#w-d1t965-4</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d1t965-5">
   <w.rf>
    <LM>w#w-d1t965-5</LM>
   </w.rf>
   <form>nejraději</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m121-d-id105894-punct">
   <w.rf>
    <LM>w#w-d-id105894-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e966-x2">
  <m id="m121-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>Nejradši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m121-d1t969-3">
   <w.rf>
    <LM>w#w-d1t969-3</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t969-5">
   <w.rf>
    <LM>w#w-d1t969-5</LM>
   </w.rf>
   <form>Jeseníky</form>
   <lemma>Jeseník_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-d-id106035-punct">
   <w.rf>
    <LM>w#w-d-id106035-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t969-8">
   <w.rf>
    <LM>w#w-d1t969-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t969-10">
   <w.rf>
    <LM>w#w-d1t969-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m121-d1t969-9">
   <w.rf>
    <LM>w#w-d1t969-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t969-11">
   <w.rf>
    <LM>w#w-d1t969-11</LM>
   </w.rf>
   <form>školní</form>
   <lemma>školní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m121-d1t969-12">
   <w.rf>
    <LM>w#w-d1t969-12</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m121-d1t969-14">
   <w.rf>
    <LM>w#w-d1t969-14</LM>
   </w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m121-d1e966-x2-454">
   <w.rf>
    <LM>w#w-d1e966-x2-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-455">
  <m id="m121-d1t971-2">
   <w.rf>
    <LM>w#w-d1t971-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t971-3">
   <w.rf>
    <LM>w#w-d1t971-3</LM>
   </w.rf>
   <form>znám</form>
   <lemma>znát</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t971-4">
   <w.rf>
    <LM>w#w-d1t971-4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t971-8">
   <w.rf>
    <LM>w#w-d1t971-8</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m121-d1t971-10">
   <w.rf>
    <LM>w#w-d1t971-10</LM>
   </w.rf>
   <form>masiv</form>
   <lemma>masiv</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t971-12">
   <w.rf>
    <LM>w#w-d1t971-12</LM>
   </w.rf>
   <form>Pradědu</form>
   <lemma>Praděd_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m121-d1e966-x2-81">
   <w.rf>
    <LM>w#w-d1e966-x2-81</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t971-16">
   <w.rf>
    <LM>w#w-d1t971-16</LM>
   </w.rf>
   <form>Petrovy</form>
   <lemma>Petrův_;Y_^(*2)_(*2o)</lemma>
   <tag>AUIP4M---------</tag>
  </m>
  <m id="m121-d1t971-17">
   <w.rf>
    <LM>w#w-d1t971-17</LM>
   </w.rf>
   <form>kameny</form>
   <lemma>kámen</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-d1t971-19">
   <w.rf>
    <LM>w#w-d1t971-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t971-20">
   <w.rf>
    <LM>w#w-d1t971-20</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m121-d1t971-22">
   <w.rf>
    <LM>w#w-d1t971-22</LM>
   </w.rf>
   <form>Šeráka</form>
   <lemma>Šerák-2_;G</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m121-d-id106489-punct">
   <w.rf>
    <LM>w#w-d-id106489-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t971-25">
   <w.rf>
    <LM>w#w-d1t971-25</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t971-26">
   <w.rf>
    <LM>w#w-d1t971-26</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m121-d1t971-27">
   <w.rf>
    <LM>w#w-d1t971-27</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t971-28">
   <w.rf>
    <LM>w#w-d1t971-28</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t971-29">
   <w.rf>
    <LM>w#w-d1t971-29</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m121-d1e966-x2-82">
   <w.rf>
    <LM>w#w-d1e966-x2-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-83">
  <m id="m121-d1t971-33">
   <w.rf>
    <LM>w#w-d1t971-33</LM>
   </w.rf>
   <form>Chodíme</form>
   <lemma>chodit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t971-30">
   <w.rf>
    <LM>w#w-d1t971-30</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t971-31">
   <w.rf>
    <LM>w#w-d1t971-31</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t971-32">
   <w.rf>
    <LM>w#w-d1t971-32</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-d1e966-x2-225">
   <w.rf>
    <LM>w#w-d1e966-x2-225</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t971-34">
   <w.rf>
    <LM>w#w-d1t971-34</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t971-35">
   <w.rf>
    <LM>w#w-d1t971-35</LM>
   </w.rf>
   <form>turistika</form>
   <lemma>turistika</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-83-459">
   <w.rf>
    <LM>w#w-83-459</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-460">
  <m id="m121-d1t973-3">
   <w.rf>
    <LM>w#w-d1t973-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t973-4">
   <w.rf>
    <LM>w#w-d1t973-4</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t973-10">
   <w.rf>
    <LM>w#w-d1t973-10</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t973-7">
   <w.rf>
    <LM>w#w-d1t973-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t973-9">
   <w.rf>
    <LM>w#w-d1t973-9</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t973-11">
   <w.rf>
    <LM>w#w-d1t973-11</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t973-8">
   <w.rf>
    <LM>w#w-d1t973-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t973-12">
   <w.rf>
    <LM>w#w-d1t973-12</LM>
   </w.rf>
   <form>pustilo</form>
   <lemma>pustit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m121-d-id106864-punct">
   <w.rf>
    <LM>w#w-d-id106864-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t973-14">
   <w.rf>
    <LM>w#w-d1t973-14</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t973-15">
   <w.rf>
    <LM>w#w-d1t973-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t973-16">
   <w.rf>
    <LM>w#w-d1t973-16</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m121-d1t973-17">
   <w.rf>
    <LM>w#w-d1t973-17</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m121-d1t973-18">
   <w.rf>
    <LM>w#w-d1t973-18</LM>
   </w.rf>
   <form>sjezdovky</form>
   <lemma>sjezdovka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m121-d1t975-1">
   <w.rf>
    <LM>w#w-d1t975-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t975-2">
   <w.rf>
    <LM>w#w-d1t975-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t975-3">
   <w.rf>
    <LM>w#w-d1t975-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m121-d1t975-4">
   <w.rf>
    <LM>w#w-d1t975-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t975-6">
   <w.rf>
    <LM>w#w-d1t975-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t975-7">
   <w.rf>
    <LM>w#w-d1t975-7</LM>
   </w.rf>
   <form>netroufám</form>
   <lemma>troufat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m121-d-m-d1e966-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e966-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e983-x2">
  <m id="m121-d1t986-1">
   <w.rf>
    <LM>w#w-d1t986-1</LM>
   </w.rf>
   <form>Další</form>
   <lemma>další</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m121-d1t986-2">
   <w.rf>
    <LM>w#w-d1t986-2</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-m-d1e983-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e983-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e987-x2">
  <m id="m121-d1t992-1">
   <w.rf>
    <LM>w#w-d1t992-1</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t992-2">
   <w.rf>
    <LM>w#w-d1t992-2</LM>
   </w.rf>
   <form>jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FS6----------</tag>
  </m>
  <m id="m121-d1t992-3">
   <w.rf>
    <LM>w#w-d1t992-3</LM>
   </w.rf>
   <form>příležitosti</form>
   <lemma>příležitost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t992-4">
   <w.rf>
    <LM>w#w-d1t992-4</LM>
   </w.rf>
   <form>vznikla</form>
   <lemma>vzniknout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m121-d1t992-5">
   <w.rf>
    <LM>w#w-d1t992-5</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m121-d1t992-6">
   <w.rf>
    <LM>w#w-d1t992-6</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-id107302-punct">
   <w.rf>
    <LM>w#w-d-id107302-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e995-x2">
  <m id="m121-d1t998-1">
   <w.rf>
    <LM>w#w-d1t998-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t998-2">
   <w.rf>
    <LM>w#w-d1t998-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t998-3">
   <w.rf>
    <LM>w#w-d1t998-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t998-4">
   <w.rf>
    <LM>w#w-d1t998-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t998-6">
   <w.rf>
    <LM>w#w-d1t998-6</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1e995-x2-237">
   <w.rf>
    <LM>w#w-d1e995-x2-237</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1000-1">
   <w.rf>
    <LM>w#w-d1t1000-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1000-2">
   <w.rf>
    <LM>w#w-d1t1000-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1000-3">
   <w.rf>
    <LM>w#w-d1t1000-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1000-4">
   <w.rf>
    <LM>w#w-d1t1000-4</LM>
   </w.rf>
   <form>přestěhovali</form>
   <lemma>přestěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m121-d1e995-x2-248">
   <w.rf>
    <LM>w#w-d1e995-x2-248</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-249">
  <m id="m121-d1t1002-3">
   <w.rf>
    <LM>w#w-d1t1002-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1002-1">
   <w.rf>
    <LM>w#w-d1t1002-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1002-2">
   <w.rf>
    <LM>w#w-d1t1002-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1002-4">
   <w.rf>
    <LM>w#w-d1t1002-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1002-5">
   <w.rf>
    <LM>w#w-d1t1002-5</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m121-d1t1002-6">
   <w.rf>
    <LM>w#w-d1t1002-6</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1002-8">
   <w.rf>
    <LM>w#w-d1t1002-8</LM>
   </w.rf>
   <form>Alena</form>
   <lemma>Alena_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1004-1">
   <w.rf>
    <LM>w#w-d1t1004-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1004-3">
   <w.rf>
    <LM>w#w-d1t1004-3</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1004-4">
   <w.rf>
    <LM>w#w-d1t1004-4</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1004-6">
   <w.rf>
    <LM>w#w-d1t1004-6</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m121-d1t1004-7">
   <w.rf>
    <LM>w#w-d1t1004-7</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-249-268">
   <w.rf>
    <LM>w#w-249-268</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-269">
  <m id="m121-d1t1006-2">
   <w.rf>
    <LM>w#w-d1t1006-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1006-1">
   <w.rf>
    <LM>w#w-d1t1006-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1006-3">
   <w.rf>
    <LM>w#w-d1t1006-3</LM>
   </w.rf>
   <form>šťastné</form>
   <lemma>šťastný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d1t1006-4">
   <w.rf>
    <LM>w#w-d1t1006-4</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d-id107890-punct">
   <w.rf>
    <LM>w#w-d-id107890-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1006-6">
   <w.rf>
    <LM>w#w-d1t1006-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1006-7">
   <w.rf>
    <LM>w#w-d1t1006-7</LM>
   </w.rf>
   <form>narození</form>
   <lemma>narození_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1006-8">
   <w.rf>
    <LM>w#w-d1t1006-8</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m121-d1t1006-9">
   <w.rf>
    <LM>w#w-d1t1006-9</LM>
   </w.rf>
   <form>dítěte</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m121-d1t1006-10">
   <w.rf>
    <LM>w#w-d1t1006-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1006-11">
   <w.rf>
    <LM>w#w-d1t1006-11</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1006-12">
   <w.rf>
    <LM>w#w-d1t1006-12</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1006-14">
   <w.rf>
    <LM>w#w-d1t1006-14</LM>
   </w.rf>
   <form>ženu</form>
   <lemma>žena</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1006-15">
   <w.rf>
    <LM>w#w-d1t1006-15</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1006-16">
   <w.rf>
    <LM>w#w-d1t1006-16</LM>
   </w.rf>
   <form>důležité</form>
   <lemma>důležitý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m121-d1t1006-17">
   <w.rf>
    <LM>w#w-d1t1006-17</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1006-18">
   <w.rf>
    <LM>w#w-d1t1006-18</LM>
   </w.rf>
   <form>navíc</form>
   <lemma>navíc</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1006-20">
   <w.rf>
    <LM>w#w-d1t1006-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1006-22">
   <w.rf>
    <LM>w#w-d1t1006-22</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m121-d1t1006-23">
   <w.rf>
    <LM>w#w-d1t1006-23</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-d1t1006-27">
   <w.rf>
    <LM>w#w-d1t1006-27</LM>
   </w.rf>
   <form>nemohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m121-d1t1006-29">
   <w.rf>
    <LM>w#w-d1t1006-29</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1006-30">
   <w.rf>
    <LM>w#w-d1t1006-30</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m121-d1t1006-31">
   <w.rf>
    <LM>w#w-d1t1006-31</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m121-269-480">
   <w.rf>
    <LM>w#w-269-480</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-481">
  <m id="m121-d1t1009-7">
   <w.rf>
    <LM>w#w-d1t1009-7</LM>
   </w.rf>
   <form>Podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1009-5">
   <w.rf>
    <LM>w#w-d1t1009-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1009-6">
   <w.rf>
    <LM>w#w-d1t1009-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1009-1">
   <w.rf>
    <LM>w#w-d1t1009-1</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1009-2">
   <w.rf>
    <LM>w#w-d1t1009-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1009-3">
   <w.rf>
    <LM>w#w-d1t1009-3</LM>
   </w.rf>
   <form>určité</form>
   <lemma>určitý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1009-4">
   <w.rf>
    <LM>w#w-d1t1009-4</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d-id108413-punct">
   <w.rf>
    <LM>w#w-d-id108413-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1009-9">
   <w.rf>
    <LM>w#w-d1t1009-9</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1011-1">
   <w.rf>
    <LM>w#w-d1t1011-1</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1011-2">
   <w.rf>
    <LM>w#w-d1t1011-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m121-d1t1011-4">
   <w.rf>
    <LM>w#w-d1t1011-4</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1011-7">
   <w.rf>
    <LM>w#w-d1t1011-7</LM>
   </w.rf>
   <form>znamenalo</form>
   <lemma>znamenat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1011-8">
   <w.rf>
    <LM>w#w-d1t1011-8</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d-id108571-punct">
   <w.rf>
    <LM>w#w-d-id108571-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1011-10">
   <w.rf>
    <LM>w#w-d1t1011-10</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1011-11">
   <w.rf>
    <LM>w#w-d1t1011-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1011-12">
   <w.rf>
    <LM>w#w-d1t1011-12</LM>
   </w.rf>
   <form>konečně</form>
   <lemma>konečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d1t1011-14">
   <w.rf>
    <LM>w#w-d1t1011-14</LM>
   </w.rf>
   <form>narodilo</form>
   <lemma>narodit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m121-269-277">
   <w.rf>
    <LM>w#w-269-277</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-278">
  <m id="m121-d1t1011-17">
   <w.rf>
    <LM>w#w-d1t1011-17</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1011-18">
   <w.rf>
    <LM>w#w-d1t1011-18</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1011-19">
   <w.rf>
    <LM>w#w-d1t1011-19</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e995-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e995-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1018-x2">
  <m id="m121-d1t1021-1">
   <w.rf>
    <LM>w#w-d1t1021-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m121-d1t1021-2">
   <w.rf>
    <LM>w#w-d1t1021-2</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d1t1021-3">
   <w.rf>
    <LM>w#w-d1t1021-3</LM>
   </w.rf>
   <form>dětí</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m121-d-id108834-punct">
   <w.rf>
    <LM>w#w-d-id108834-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1022-x2">
  <m id="m121-d1t1027-2">
   <w.rf>
    <LM>w#w-d1t1027-2</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1027-3">
   <w.rf>
    <LM>w#w-d1t1027-3</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m121-d1t1027-4">
   <w.rf>
    <LM>w#w-d1t1027-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1022-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1022-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1034-x2">
  <m id="m121-d1t1037-1">
   <w.rf>
    <LM>w#w-d1t1037-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1037-2">
   <w.rf>
    <LM>w#w-d1t1037-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1037-3">
   <w.rf>
    <LM>w#w-d1t1037-3</LM>
   </w.rf>
   <form>jmenují</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---3P-AAB--</tag>
  </m>
  <m id="m121-d-id109066-punct">
   <w.rf>
    <LM>w#w-d-id109066-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1038-x2">
  <m id="m121-d1t1043-1">
   <w.rf>
    <LM>w#w-d1t1043-1</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1043-2">
   <w.rf>
    <LM>w#w-d1t1043-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1043-3">
   <w.rf>
    <LM>w#w-d1t1043-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m121-d1t1043-5">
   <w.rf>
    <LM>w#w-d1t1043-5</LM>
   </w.rf>
   <form>Julek</form>
   <lemma>Julek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1043-7">
   <w.rf>
    <LM>w#w-d1t1043-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1043-8">
   <w.rf>
    <LM>w#w-d1t1043-8</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1043-9">
   <w.rf>
    <LM>w#w-d1t1043-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1043-10">
   <w.rf>
    <LM>w#w-d1t1043-10</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m121-d1t1043-12">
   <w.rf>
    <LM>w#w-d1t1043-12</LM>
   </w.rf>
   <form>Alena</form>
   <lemma>Alena_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1038-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1038-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1044-x2">
  <m id="m121-d1t1047-1">
   <w.rf>
    <LM>w#w-d1t1047-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t1047-2">
   <w.rf>
    <LM>w#w-d1t1047-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1047-3">
   <w.rf>
    <LM>w#w-d1t1047-3</LM>
   </w.rf>
   <form>dělají</form>
   <lemma>dělat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m121-d-id109411-punct">
   <w.rf>
    <LM>w#w-d-id109411-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1048-x2">
  <m id="m121-d1t1053-2">
   <w.rf>
    <LM>w#w-d1t1053-2</LM>
   </w.rf>
   <form>Julek</form>
   <lemma>Julek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1053-5">
   <w.rf>
    <LM>w#w-d1t1053-5</LM>
   </w.rf>
   <form>nejdřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m121-d1t1053-4">
   <w.rf>
    <LM>w#w-d1t1053-4</LM>
   </w.rf>
   <form>vystudoval</form>
   <lemma>vystudovat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1053-6">
   <w.rf>
    <LM>w#w-d1t1053-6</LM>
   </w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1053-7">
   <w.rf>
    <LM>w#w-d1t1053-7</LM>
   </w.rf>
   <form>zemědělskou</form>
   <lemma>zemědělský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d-id109577-punct">
   <w.rf>
    <LM>w#w-d-id109577-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1053-9">
   <w.rf>
    <LM>w#w-d1t1053-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1053-10">
   <w.rf>
    <LM>w#w-d1t1053-10</LM>
   </w.rf>
   <form>zároveň</form>
   <lemma>zároveň</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1053-12">
   <w.rf>
    <LM>w#w-d1t1053-12</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t1053-11">
   <w.rf>
    <LM>w#w-d1t1053-11</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1053-13">
   <w.rf>
    <LM>w#w-d1t1053-13</LM>
   </w.rf>
   <form>přibral</form>
   <lemma>přibrat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1055-1">
   <w.rf>
    <LM>w#w-d1t1055-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1055-2">
   <w.rf>
    <LM>w#w-d1t1055-2</LM>
   </w.rf>
   <form>přírodovědeckou</form>
   <lemma>přírodovědecký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1055-3">
   <w.rf>
    <LM>w#w-d1t1055-3</LM>
   </w.rf>
   <form>fakultu</form>
   <lemma>fakulta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1e1048-x2-497">
   <w.rf>
    <LM>w#w-d1e1048-x2-497</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-498">
  <m id="m121-d1t1055-6">
   <w.rf>
    <LM>w#w-d1t1055-6</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1055-8">
   <w.rf>
    <LM>w#w-d1t1055-8</LM>
   </w.rf>
   <form>zemědělské</form>
   <lemma>zemědělský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1055-10">
   <w.rf>
    <LM>w#w-d1t1055-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1055-11">
   <w.rf>
    <LM>w#w-d1t1055-11</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m121-d1t1055-12">
   <w.rf>
    <LM>w#w-d1t1055-12</LM>
   </w.rf>
   <form>zdálo</form>
   <lemma>zdát</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m121-d-id109852-punct">
   <w.rf>
    <LM>w#w-d-id109852-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1055-14">
   <w.rf>
    <LM>w#w-d1t1055-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1055-16">
   <w.rf>
    <LM>w#w-d1t1055-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1055-15">
   <w.rf>
    <LM>w#w-d1t1055-15</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m121-d1t1055-18">
   <w.rf>
    <LM>w#w-d1t1055-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1e1048-x2-294">
   <w.rf>
    <LM>w#w-d1e1048-x2-294</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1055-19">
   <w.rf>
    <LM>w#w-d1t1055-19</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t1055-20">
   <w.rf>
    <LM>w#w-d1t1055-20</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m121-d1t1055-21">
   <w.rf>
    <LM>w#w-d1t1055-21</LM>
   </w.rf>
   <form>chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1055-22">
   <w.rf>
    <LM>w#w-d1t1055-22</LM>
   </w.rf>
   <form>studovat</form>
   <lemma>studovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-498-499">
   <w.rf>
    <LM>w#w-498-499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-500">
  <m id="m121-d1t1059-2">
   <w.rf>
    <LM>w#w-d1t1059-2</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1059-3">
   <w.rf>
    <LM>w#w-d1t1059-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1059-4">
   <w.rf>
    <LM>w#w-d1t1059-4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t1059-5">
   <w.rf>
    <LM>w#w-d1t1059-5</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m121-d1t1059-6">
   <w.rf>
    <LM>w#w-d1t1059-6</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m121-d1t1059-8">
   <w.rf>
    <LM>w#w-d1t1059-8</LM>
   </w.rf>
   <form>opustil</form>
   <lemma>opustit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1059-9">
   <w.rf>
    <LM>w#w-d1t1059-9</LM>
   </w.rf>
   <form>vědu</form>
   <lemma>věda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1062-1">
   <w.rf>
    <LM>w#w-d1t1062-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1062-2">
   <w.rf>
    <LM>w#w-d1t1062-2</LM>
   </w.rf>
   <form>zabývá</form>
   <lemma>zabývat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1062-3">
   <w.rf>
    <LM>w#w-d1t1062-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1062-4">
   <w.rf>
    <LM>w#w-d1t1062-4</LM>
   </w.rf>
   <form>genealogií</form>
   <lemma>genealogie</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-d-id110234-punct">
   <w.rf>
    <LM>w#w-d-id110234-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1062-6">
   <w.rf>
    <LM>w#w-d1t1062-6</LM>
   </w.rf>
   <form>pátrá</form>
   <lemma>pátrat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1062-7">
   <w.rf>
    <LM>w#w-d1t1062-7</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1064-1">
   <w.rf>
    <LM>w#w-d1t1064-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1064-2">
   <w.rf>
    <LM>w#w-d1t1064-2</LM>
   </w.rf>
   <form>předcích</form>
   <lemma>předek-2_^(generačně)</lemma>
   <tag>NNMP6-----A----</tag>
  </m>
  <m id="m121-500-501">
   <w.rf>
    <LM>w#w-500-501</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-502">
  <m id="m121-d1t1066-2">
   <w.rf>
    <LM>w#w-d1t1066-2</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>svojí</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS4---------6</tag>
  </m>
  <m id="m121-d1t1066-4">
   <w.rf>
    <LM>w#w-d1t1066-4</LM>
   </w.rf>
   <form>webovou</form>
   <lemma>webový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1066-5">
   <w.rf>
    <LM>w#w-d1t1066-5</LM>
   </w.rf>
   <form>adresu</form>
   <lemma>adresa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1066-6">
   <w.rf>
    <LM>w#w-d1t1066-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1066-7">
   <w.rf>
    <LM>w#w-d1t1066-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1066-8">
   <w.rf>
    <LM>w#w-d1t1066-8</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1066-9">
   <w.rf>
    <LM>w#w-d1t1066-9</LM>
   </w.rf>
   <form>šťastný</form>
   <lemma>šťastný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m121-d-id110462-punct">
   <w.rf>
    <LM>w#w-d-id110462-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1066-11">
   <w.rf>
    <LM>w#w-d1t1066-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1066-12">
   <w.rf>
    <LM>w#w-d1t1066-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1066-13">
   <w.rf>
    <LM>w#w-d1t1066-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1066-14">
   <w.rf>
    <LM>w#w-d1t1066-14</LM>
   </w.rf>
   <form>svobodné</form>
   <lemma>svobodný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1066-15">
   <w.rf>
    <LM>w#w-d1t1066-15</LM>
   </w.rf>
   <form>noze</form>
   <lemma>noha</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1e1048-x2-297">
   <w.rf>
    <LM>w#w-d1e1048-x2-297</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-298">
  <m id="m121-d1t1070-1">
   <w.rf>
    <LM>w#w-d1t1070-1</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m121-d-id110588-punct">
   <w.rf>
    <LM>w#w-d-id110588-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1070-3">
   <w.rf>
    <LM>w#w-d1t1070-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1070-4">
   <w.rf>
    <LM>w#w-d1t1070-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1070-5">
   <w.rf>
    <LM>w#w-d1t1070-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m121-d1t1070-6">
   <w.rf>
    <LM>w#w-d1t1070-6</LM>
   </w.rf>
   <form>daří</form>
   <lemma>dařit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-298-317">
   <w.rf>
    <LM>w#w-298-317</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1048-x3">
  <m id="m121-d1t1075-2">
   <w.rf>
    <LM>w#w-d1t1075-2</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1075-6">
   <w.rf>
    <LM>w#w-d1t1075-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t1075-5">
   <w.rf>
    <LM>w#w-d1t1075-5</LM>
   </w.rf>
   <form>odmalička</form>
   <lemma>odmalička</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1075-7">
   <w.rf>
    <LM>w#w-d1t1075-7</LM>
   </w.rf>
   <form>hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1075-8">
   <w.rf>
    <LM>w#w-d1t1075-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1075-9">
   <w.rf>
    <LM>w#w-d1t1075-9</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1075-10">
   <w.rf>
    <LM>w#w-d1t1075-10</LM>
   </w.rf>
   <form>učitelku</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-id110831-punct">
   <w.rf>
    <LM>w#w-d-id110831-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1077-1">
   <w.rf>
    <LM>w#w-d1t1077-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1077-2">
   <w.rf>
    <LM>w#w-d1t1077-2</LM>
   </w.rf>
   <form>vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1e1048-x3-328">
   <w.rf>
    <LM>w#w-d1e1048-x3-328</LM>
   </w.rf>
   <form>pedagogickou</form>
   <lemma>pedagogický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1079-1">
   <w.rf>
    <LM>w#w-d1t1079-1</LM>
   </w.rf>
   <form>fakultu</form>
   <lemma>fakulta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1079-6">
   <w.rf>
    <LM>w#w-d1t1079-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1079-8">
   <w.rf>
    <LM>w#w-d1t1079-8</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t1079-10">
   <w.rf>
    <LM>w#w-d1t1079-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1081-1">
   <w.rf>
    <LM>w#w-d1t1081-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1081-2">
   <w.rf>
    <LM>w#w-d1t1081-2</LM>
   </w.rf>
   <form>učitelkou</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-d1e1048-x3-329">
   <w.rf>
    <LM>w#w-d1e1048-x3-329</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-330">
  <m id="m121-d1t1083-1">
   <w.rf>
    <LM>w#w-d1t1083-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1083-2">
   <w.rf>
    <LM>w#w-d1t1083-2</LM>
   </w.rf>
   <form>současné</form>
   <lemma>současný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1083-3">
   <w.rf>
    <LM>w#w-d1t1083-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1t1083-4">
   <w.rf>
    <LM>w#w-d1t1083-4</LM>
   </w.rf>
   <form>vyhrála</form>
   <lemma>vyhrát</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1083-5">
   <w.rf>
    <LM>w#w-d1t1083-5</LM>
   </w.rf>
   <form>konkurz</form>
   <lemma>konkurz</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m121-d1t1083-6">
   <w.rf>
    <LM>w#w-d1t1083-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1083-7">
   <w.rf>
    <LM>w#w-d1t1083-7</LM>
   </w.rf>
   <form>ředitelku</form>
   <lemma>ředitelka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1083-8">
   <w.rf>
    <LM>w#w-d1t1083-8</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d-id111196-punct">
   <w.rf>
    <LM>w#w-d-id111196-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1083-10">
   <w.rf>
    <LM>w#w-d1t1083-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1083-11">
   <w.rf>
    <LM>w#w-d1t1083-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1083-12">
   <w.rf>
    <LM>w#w-d1t1083-12</LM>
   </w.rf>
   <form>ředitelkou</form>
   <lemma>ředitelka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m121-d1t1083-13">
   <w.rf>
    <LM>w#w-d1t1083-13</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d1t1083-14">
   <w.rf>
    <LM>w#w-d1t1083-14</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m121-d1t1083-16">
   <w.rf>
    <LM>w#w-d1t1083-16</LM>
   </w.rf>
   <form>Strašnicích</form>
   <lemma>Strašnice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m121-d-id111315-punct">
   <w.rf>
    <LM>w#w-d-id111315-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1083-19">
   <w.rf>
    <LM>w#w-d1t1083-19</LM>
   </w.rf>
   <form>daří</form>
   <lemma>dařit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1083-20">
   <w.rf>
    <LM>w#w-d1t1083-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1083-21">
   <w.rf>
    <LM>w#w-d1t1083-21</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m121-d1t1083-22">
   <w.rf>
    <LM>w#w-d1t1083-22</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m121-d-m-d1e1048-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1048-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1084-x2">
  <m id="m121-d1t1087-2">
   <w.rf>
    <LM>w#w-d1t1087-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t1087-3">
   <w.rf>
    <LM>w#w-d1t1087-3</LM>
   </w.rf>
   <form>učí</form>
   <lemma>učit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1087-4">
   <w.rf>
    <LM>w#w-d1t1087-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1087-5">
   <w.rf>
    <LM>w#w-d1t1087-5</LM>
   </w.rf>
   <form>předměty</form>
   <lemma>předmět</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m121-d-id111516-punct">
   <w.rf>
    <LM>w#w-d-id111516-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1088-x2">
  <m id="m121-d1t1091-4">
   <w.rf>
    <LM>w#w-d1t1091-4</LM>
   </w.rf>
   <form>Začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1091-5">
   <w.rf>
    <LM>w#w-d1t1091-5</LM>
   </w.rf>
   <form>studovat</form>
   <lemma>studovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m121-d1t1091-6">
   <w.rf>
    <LM>w#w-d1t1091-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1091-8">
   <w.rf>
    <LM>w#w-d1t1091-8</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m121-d1t1091-9">
   <w.rf>
    <LM>w#w-d1t1091-9</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d1e1088-x2-535">
   <w.rf>
    <LM>w#w-d1e1088-x2-535</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-536">
  <m id="m121-d1t1093-1">
   <w.rf>
    <LM>w#w-d1t1093-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m121-d1t1093-2">
   <w.rf>
    <LM>w#w-d1t1093-2</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1093-3">
   <w.rf>
    <LM>w#w-d1t1093-3</LM>
   </w.rf>
   <form>nesouhlasil</form>
   <lemma>souhlasit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m121-d1t1093-4">
   <w.rf>
    <LM>w#w-d1t1093-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m121-d1t1093-5">
   <w.rf>
    <LM>w#w-d1t1093-5</LM>
   </w.rf>
   <form>příchodem</form>
   <lemma>příchod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m121-d1t1093-6">
   <w.rf>
    <LM>w#w-d1t1093-6</LM>
   </w.rf>
   <form>vojsk</form>
   <lemma>vojsko</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m121-d-id111860-punct">
   <w.rf>
    <LM>w#w-d-id111860-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1093-8">
   <w.rf>
    <LM>w#w-d1t1093-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1093-9">
   <w.rf>
    <LM>w#w-d1t1093-9</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m121-d1t1093-10">
   <w.rf>
    <LM>w#w-d1t1093-10</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m121-d1t1093-11">
   <w.rf>
    <LM>w#w-d1t1093-11</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1095-1">
   <w.rf>
    <LM>w#w-d1t1095-1</LM>
   </w.rf>
   <form>těžkou</form>
   <lemma>těžký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1095-2">
   <w.rf>
    <LM>w#w-d1t1095-2</LM>
   </w.rf>
   <form>cestu</form>
   <lemma>cesta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1093-14">
   <w.rf>
    <LM>w#w-d1t1093-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1093-15">
   <w.rf>
    <LM>w#w-d1t1093-15</LM>
   </w.rf>
   <form>vysokou</form>
   <lemma>vysoký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1093-16">
   <w.rf>
    <LM>w#w-d1t1093-16</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-id112009-punct">
   <w.rf>
    <LM>w#w-d-id112009-punct</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1095-3">
   <w.rf>
    <LM>w#w-d1t1095-3</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m121-d1t1095-4">
   <w.rf>
    <LM>w#w-d1t1095-4</LM>
   </w.rf>
   <form>vzdělání</form>
   <lemma>vzdělání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m121-d1e1088-x2-349">
   <w.rf>
    <LM>w#w-d1e1088-x2-349</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-351">
  <m id="m121-d1t1097-6">
   <w.rf>
    <LM>w#w-d1t1097-6</LM>
   </w.rf>
   <form>Podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m121-d1t1097-7">
   <w.rf>
    <LM>w#w-d1t1097-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1097-8">
   <w.rf>
    <LM>w#w-d1t1097-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m121-d1t1097-9">
   <w.rf>
    <LM>w#w-d1t1097-9</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m121-d1t1097-10">
   <w.rf>
    <LM>w#w-d1t1097-10</LM>
   </w.rf>
   <form>přátelům</form>
   <lemma>přítel</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m121-d1t1097-11">
   <w.rf>
    <LM>w#w-d1t1097-11</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m121-d1t1097-12">
   <w.rf>
    <LM>w#w-d1t1097-12</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m121-d1t1097-13">
   <w.rf>
    <LM>w#w-d1t1097-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1097-15">
   <w.rf>
    <LM>w#w-d1t1097-15</LM>
   </w.rf>
   <form>pedagogickou</form>
   <lemma>pedagogický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1097-16">
   <w.rf>
    <LM>w#w-d1t1097-16</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1097-17">
   <w.rf>
    <LM>w#w-d1t1097-17</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1097-18">
   <w.rf>
    <LM>w#w-d1t1097-18</LM>
   </w.rf>
   <form>ruštinu</form>
   <lemma>ruština</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1e1088-x2-347">
   <w.rf>
    <LM>w#w-d1e1088-x2-347</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1097-19">
   <w.rf>
    <LM>w#w-d1t1097-19</LM>
   </w.rf>
   <form>hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1097-20">
   <w.rf>
    <LM>w#w-d1t1097-20</LM>
   </w.rf>
   <form>výchovu</form>
   <lemma>výchova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-351-547">
   <w.rf>
    <LM>w#w-351-547</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-548">
  <m id="m121-d1t1102-3">
   <w.rf>
    <LM>w#w-d1t1102-3</LM>
   </w.rf>
   <form>Vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1102-2">
   <w.rf>
    <LM>w#w-d1t1102-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m121-d-id112487-punct">
   <w.rf>
    <LM>w#w-d-id112487-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1102-5">
   <w.rf>
    <LM>w#w-d1t1102-5</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1102-6">
   <w.rf>
    <LM>w#w-d1t1102-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1102-8">
   <w.rf>
    <LM>w#w-d1t1102-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m121-d1t1102-9">
   <w.rf>
    <LM>w#w-d1t1102-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1102-10">
   <w.rf>
    <LM>w#w-d1t1102-10</LM>
   </w.rf>
   <form>poslednim</form>
   <lemma>poslední</lemma>
   <tag>AANS6----1A---6</tag>
  </m>
  <m id="m121-d1t1102-11">
   <w.rf>
    <LM>w#w-d1t1102-11</LM>
   </w.rf>
   <form>ročníku</form>
   <lemma>ročník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m121-d1t1102-12">
   <w.rf>
    <LM>w#w-d1t1102-12</LM>
   </w.rf>
   <form>fakulty</form>
   <lemma>fakulta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m121-d-id112620-punct">
   <w.rf>
    <LM>w#w-d-id112620-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1102-16">
   <w.rf>
    <LM>w#w-d1t1102-16</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1102-17">
   <w.rf>
    <LM>w#w-d1t1102-17</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m121-d1t1102-19">
   <w.rf>
    <LM>w#w-d1t1102-19</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1102-18">
   <w.rf>
    <LM>w#w-d1t1102-18</LM>
   </w.rf>
   <form>1989</form>
   <lemma>1989</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m121-351-92">
   <w.rf>
    <LM>w#w-351-92</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-93">
  <m id="m121-d1t1102-23">
   <w.rf>
    <LM>w#w-d1t1102-23</LM>
   </w.rf>
   <form>Hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1102-24">
   <w.rf>
    <LM>w#w-d1t1102-24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1102-25">
   <w.rf>
    <LM>w#w-d1t1102-25</LM>
   </w.rf>
   <form>zápětí</form>
   <lemma>zápětí_,a</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-d1t1102-26">
   <w.rf>
    <LM>w#w-d1t1102-26</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m121-d1t1102-27">
   <w.rf>
    <LM>w#w-d1t1102-27</LM>
   </w.rf>
   <form>udělala</form>
   <lemma>udělat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m121-d1t1102-28">
   <w.rf>
    <LM>w#w-d1t1102-28</LM>
   </w.rf>
   <form>angličtinu</form>
   <lemma>angličtina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-id112855-punct">
   <w.rf>
    <LM>w#w-d-id112855-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1102-30">
   <w.rf>
    <LM>w#w-d1t1102-30</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m121-d1t1102-31">
   <w.rf>
    <LM>w#w-d1t1102-31</LM>
   </w.rf>
   <form>učí</form>
   <lemma>učit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1102-32">
   <w.rf>
    <LM>w#w-d1t1102-32</LM>
   </w.rf>
   <form>angličtinu</form>
   <lemma>angličtina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d1t1102-33">
   <w.rf>
    <LM>w#w-d1t1102-33</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1102-34">
   <w.rf>
    <LM>w#w-d1t1102-34</LM>
   </w.rf>
   <form>hudební</form>
   <lemma>hudební</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d1t1102-35">
   <w.rf>
    <LM>w#w-d1t1102-35</LM>
   </w.rf>
   <form>výchovu</form>
   <lemma>výchova</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1088-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1088-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1103-x2">
  <m id="m121-d1t1106-1">
   <w.rf>
    <LM>w#w-d1t1106-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m121-d1t1106-2">
   <w.rf>
    <LM>w#w-d1t1106-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m121-d1t1106-3">
   <w.rf>
    <LM>w#w-d1t1106-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d1t1106-4">
   <w.rf>
    <LM>w#w-d1t1106-4</LM>
   </w.rf>
   <form>vnoučata</form>
   <lemma>vnouče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m121-d-id113072-punct">
   <w.rf>
    <LM>w#w-d-id113072-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1107-x2">
  <m id="m121-d1t1112-1">
   <w.rf>
    <LM>w#w-d1t1112-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m121-d-id113158-punct">
   <w.rf>
    <LM>w#w-d-id113158-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1112-3">
   <w.rf>
    <LM>w#w-d1t1112-3</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m121-d1t1112-4">
   <w.rf>
    <LM>w#w-d1t1112-4</LM>
   </w.rf>
   <form>vnoučat</form>
   <lemma>vnouče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m121-d1e1107-x2-354">
   <w.rf>
    <LM>w#w-d1e1107-x2-354</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m121-d1t1114-1">
   <w.rf>
    <LM>w#w-d1t1114-1</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m121-d1t1114-2">
   <w.rf>
    <LM>w#w-d1t1114-2</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1114-3">
   <w.rf>
    <LM>w#w-d1t1114-3</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m121-d1t1114-4">
   <w.rf>
    <LM>w#w-d1t1114-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d1t1114-5">
   <w.rf>
    <LM>w#w-d1t1114-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m121-d1t1114-6">
   <w.rf>
    <LM>w#w-d1t1114-6</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m121-d1t1114-7">
   <w.rf>
    <LM>w#w-d1t1114-7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1114-8">
   <w.rf>
    <LM>w#w-d1t1114-8</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m121-d1t1114-9">
   <w.rf>
    <LM>w#w-d1t1114-9</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m121-d-m-d1e1107-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1107-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1115-x2">
  <m id="m121-d1t1118-1">
   <w.rf>
    <LM>w#w-d1t1118-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m121-d1e1115-x2-355">
   <w.rf>
    <LM>w#w-d1e1115-x2-355</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-356">
  <m id="m121-d1t1120-1">
   <w.rf>
    <LM>w#w-d1t1120-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m121-d1t1120-2">
   <w.rf>
    <LM>w#w-d1t1120-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m121-d1t1120-3">
   <w.rf>
    <LM>w#w-d1t1120-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m121-d1t1120-4">
   <w.rf>
    <LM>w#w-d1t1120-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m121-d-m-d1e1115-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1115-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1121-x2">
  <m id="m121-d1t1126-1">
   <w.rf>
    <LM>w#w-d1t1126-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m121-d1t1126-2">
   <w.rf>
    <LM>w#w-d1t1126-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m121-d1t1126-3">
   <w.rf>
    <LM>w#w-d1t1126-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1126-4">
   <w.rf>
    <LM>w#w-d1t1126-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m121-d1t1126-5">
   <w.rf>
    <LM>w#w-d1t1126-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m121-d-id113632-punct">
   <w.rf>
    <LM>w#w-d-id113632-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1121-x4">
  <m id="m121-d1t1128-2">
   <w.rf>
    <LM>w#w-d1t1128-2</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1128-3">
   <w.rf>
    <LM>w#w-d1t1128-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1128-5">
   <w.rf>
    <LM>w#w-d1t1128-5</LM>
   </w.rf>
   <form>nešťastný</form>
   <lemma>šťastný</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m121-d1t1128-6">
   <w.rf>
    <LM>w#w-d1t1128-6</LM>
   </w.rf>
   <form>srpen</form>
   <lemma>srpen</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m121-d1t1128-7">
   <w.rf>
    <LM>w#w-d1t1128-7</LM>
   </w.rf>
   <form>1968</form>
   <lemma>1968</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m121-d-m-d1e1121-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1121-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m121-d1e1129-x2">
  <m id="m121-d1t1134-1">
   <w.rf>
    <LM>w#w-d1t1134-1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m121-d1t1134-2">
   <w.rf>
    <LM>w#w-d1t1134-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m121-d1t1134-3">
   <w.rf>
    <LM>w#w-d1t1134-3</LM>
   </w.rf>
   <form>muzeum</form>
   <lemma>muzeum</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m121-d1t1134-4">
   <w.rf>
    <LM>w#w-d1t1134-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m121-d1t1134-6">
   <w.rf>
    <LM>w#w-d1t1134-6</LM>
   </w.rf>
   <form>Václavském</form>
   <lemma>václavský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m121-d1t1134-7">
   <w.rf>
    <LM>w#w-d1t1134-7</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m121-d1e1129-x2-558">
   <w.rf>
    <LM>w#w-d1e1129-x2-558</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
