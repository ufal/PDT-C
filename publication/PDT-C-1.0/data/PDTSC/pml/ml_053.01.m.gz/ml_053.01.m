<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_053.01.w.gz" />
  </references>
 </head>
 <s id="m053-174">
  <m id="m053-d1t304-3">
   <w.rf>
    <LM>w#w-d1t304-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t304-4">
   <w.rf>
    <LM>w#w-d1t304-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t304-5">
   <w.rf>
    <LM>w#w-d1t304-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m053-d1t304-6">
   <w.rf>
    <LM>w#w-d1t304-6</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m053-d1t304-7">
   <w.rf>
    <LM>w#w-d1t304-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m053-d1t304-1">
   <w.rf>
    <LM>w#w-d1t304-1</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t304-8">
   <w.rf>
    <LM>w#w-d1t304-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t304-9">
   <w.rf>
    <LM>w#w-d1t304-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t304-10">
   <w.rf>
    <LM>w#w-d1t304-10</LM>
   </w.rf>
   <form>dívčina</form>
   <lemma>dívčina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d-id64341-punct">
   <w.rf>
    <LM>w#w-d-id64341-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t306-1">
   <w.rf>
    <LM>w#w-d1t306-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t308-2">
   <w.rf>
    <LM>w#w-d1t308-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t308-1">
   <w.rf>
    <LM>w#w-d1t308-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t308-3">
   <w.rf>
    <LM>w#w-d1t308-3</LM>
   </w.rf>
   <form>snažila</form>
   <lemma>snažit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m053-d1t308-4">
   <w.rf>
    <LM>w#w-d1t308-4</LM>
   </w.rf>
   <form>přeplavat</form>
   <lemma>přeplavat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-d1t308-5">
   <w.rf>
    <LM>w#w-d1t308-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t308-6">
   <w.rf>
    <LM>w#w-d1t308-6</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m053-d1t308-7">
   <w.rf>
    <LM>w#w-d1t308-7</LM>
   </w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m053-d1t308-8">
   <w.rf>
    <LM>w#w-d1t308-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t308-9">
   <w.rf>
    <LM>w#w-d1t308-9</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m053-174-179">
   <w.rf>
    <LM>w#w-174-179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-180">
  <m id="m053-d1t308-12">
   <w.rf>
    <LM>w#w-d1t308-12</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t308-13">
   <w.rf>
    <LM>w#w-d1t308-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t308-14">
   <w.rf>
    <LM>w#w-d1t308-14</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t308-15">
   <w.rf>
    <LM>w#w-d1t308-15</LM>
   </w.rf>
   <form>600</form>
   <lemma>600</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m053-d1t308-16">
   <w.rf>
    <LM>w#w-d1t308-16</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m053-d1t310-1">
   <w.rf>
    <LM>w#w-d1t310-1</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m053-180-29">
   <w.rf>
    <LM>w#w-180-29</LM>
   </w.rf>
   <form>trasa</form>
   <lemma>trasa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-180-183">
   <w.rf>
    <LM>w#w-180-183</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-180-128">
   <w.rf>
    <LM>w#w-180-128</LM>
   </w.rf>
   <form>600</form>
   <lemma>600</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m053-180-129">
   <w.rf>
    <LM>w#w-180-129</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m053-d1t310-5">
   <w.rf>
    <LM>w#w-d1t310-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t310-6">
   <w.rf>
    <LM>w#w-d1t310-6</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-180-186">
   <w.rf>
    <LM>w#w-180-186</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t318-1">
   <w.rf>
    <LM>w#w-d1t318-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t318-3">
   <w.rf>
    <LM>w#w-d1t318-3</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m053-d1t318-4">
   <w.rf>
    <LM>w#w-d1t318-4</LM>
   </w.rf>
   <form>zabrat</form>
   <lemma>zabrat_^([zabavit]_něco_někomu)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-d-m-d1e288-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e288-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e323-x2">
  <m id="m053-d1t328-1">
   <w.rf>
    <LM>w#w-d1t328-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m053-d1t328-2">
   <w.rf>
    <LM>w#w-d1t328-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t328-3">
   <w.rf>
    <LM>w#w-d1t328-3</LM>
   </w.rf>
   <form>děláváte</form>
   <lemma>dělávat_^(*4at)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m053-d-id65006-punct">
   <w.rf>
    <LM>w#w-d-id65006-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e329-x2">
  <m id="m053-d1t334-1">
   <w.rf>
    <LM>w#w-d1t334-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m053-d1t334-2">
   <w.rf>
    <LM>w#w-d1t334-2</LM>
   </w.rf>
   <form>chytám</form>
   <lemma>chytat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m053-d1t334-3">
   <w.rf>
    <LM>w#w-d1t334-3</LM>
   </w.rf>
   <form>ryby</form>
   <lemma>ryba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m053-d1e329-x2-196">
   <w.rf>
    <LM>w#w-d1e329-x2-196</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t336-1">
   <w.rf>
    <LM>w#w-d1t336-1</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t336-4">
   <w.rf>
    <LM>w#w-d1t336-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t336-6">
   <w.rf>
    <LM>w#w-d1t336-6</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starat_^(se)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t336-7">
   <w.rf>
    <LM>w#w-d1t336-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t336-8">
   <w.rf>
    <LM>w#w-d1t336-8</LM>
   </w.rf>
   <form>domácnost</form>
   <lemma>domácnost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d1e329-x2-197">
   <w.rf>
    <LM>w#w-d1e329-x2-197</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-198">
  <m id="m053-d1t338-4">
   <w.rf>
    <LM>w#w-d1t338-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t338-5">
   <w.rf>
    <LM>w#w-d1t338-5</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t338-6">
   <w.rf>
    <LM>w#w-d1t338-6</LM>
   </w.rf>
   <form>nemá</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m053-d1t338-8">
   <w.rf>
    <LM>w#w-d1t338-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m053-d1t338-9">
   <w.rf>
    <LM>w#w-d1t338-9</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-198-199">
   <w.rf>
    <LM>w#w-198-199</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-198-200">
   <w.rf>
    <LM>w#w-198-200</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t338-10">
   <w.rf>
    <LM>w#w-d1t338-10</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t338-11">
   <w.rf>
    <LM>w#w-d1t338-11</LM>
   </w.rf>
   <form>pejska</form>
   <lemma>pejsek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m053-d-id65417-punct">
   <w.rf>
    <LM>w#w-d-id65417-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t340-1">
   <w.rf>
    <LM>w#w-d1t340-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t340-2">
   <w.rf>
    <LM>w#w-d1t340-2</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t340-3">
   <w.rf>
    <LM>w#w-d1t340-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m053-d1t340-4">
   <w.rf>
    <LM>w#w-d1t340-4</LM>
   </w.rf>
   <form>pejskem</form>
   <lemma>pejsek</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m053-198-201">
   <w.rf>
    <LM>w#w-198-201</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-202">
  <m id="m053-d1t343-4">
   <w.rf>
    <LM>w#w-d1t343-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t343-5">
   <w.rf>
    <LM>w#w-d1t343-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m053-d1t343-6">
   <w.rf>
    <LM>w#w-d1t343-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t343-8">
   <w.rf>
    <LM>w#w-d1t343-8</LM>
   </w.rf>
   <form>břehu</form>
   <lemma>břeh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m053-202-207">
   <w.rf>
    <LM>w#w-202-207</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t343-11">
   <w.rf>
    <LM>w#w-d1t343-11</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m053-d1t343-12">
   <w.rf>
    <LM>w#w-d1t343-12</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t343-13">
   <w.rf>
    <LM>w#w-d1t343-13</LM>
   </w.rf>
   <form>karavan</form>
   <lemma>karavan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d-id65673-punct">
   <w.rf>
    <LM>w#w-d-id65673-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t343-15">
   <w.rf>
    <LM>w#w-d1t343-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t343-16">
   <w.rf>
    <LM>w#w-d1t343-16</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m053-d1t343-17">
   <w.rf>
    <LM>w#w-d1t343-17</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m053-d1t343-18">
   <w.rf>
    <LM>w#w-d1t343-18</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m053-202-209">
   <w.rf>
    <LM>w#w-202-209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-210">
  <m id="m053-210-211">
   <w.rf>
    <LM>w#w-210-211</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t347-1">
   <w.rf>
    <LM>w#w-d1t347-1</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m053-d1t347-2">
   <w.rf>
    <LM>w#w-d1t347-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t347-3">
   <w.rf>
    <LM>w#w-d1t347-3</LM>
   </w.rf>
   <form>procházku</form>
   <lemma>procházka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d1t347-4">
   <w.rf>
    <LM>w#w-d1t347-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t347-6">
   <w.rf>
    <LM>w#w-d1t347-6</LM>
   </w.rf>
   <form>kempu</form>
   <lemma>kemp</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m053-d1t347-9">
   <w.rf>
    <LM>w#w-d1t347-9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t347-11">
   <w.rf>
    <LM>w#w-d1t347-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t347-10">
   <w.rf>
    <LM>w#w-d1t347-10</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t347-12">
   <w.rf>
    <LM>w#w-d1t347-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t347-13">
   <w.rf>
    <LM>w#w-d1t347-13</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-210-213">
   <w.rf>
    <LM>w#w-210-213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-214">
  <m id="m053-d1t347-17">
   <w.rf>
    <LM>w#w-d1t347-17</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t347-18">
   <w.rf>
    <LM>w#w-d1t347-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t347-19">
   <w.rf>
    <LM>w#w-d1t347-19</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t347-20">
   <w.rf>
    <LM>w#w-d1t347-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t347-21">
   <w.rf>
    <LM>w#w-d1t347-21</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m053-d1t347-22">
   <w.rf>
    <LM>w#w-d1t347-22</LM>
   </w.rf>
   <form>koukat</form>
   <lemma>koukat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-214-215">
   <w.rf>
    <LM>w#w-214-215</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e348-x2">
  <m id="m053-d1t351-1">
   <w.rf>
    <LM>w#w-d1t351-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t351-2">
   <w.rf>
    <LM>w#w-d1t351-2</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t351-3">
   <w.rf>
    <LM>w#w-d1t351-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t351-4">
   <w.rf>
    <LM>w#w-d1t351-4</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m053-d-m-d1e348-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e348-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e352-x2">
  <m id="m053-d1t355-1">
   <w.rf>
    <LM>w#w-d1t355-1</LM>
   </w.rf>
   <form>Nádhera</form>
   <lemma>nádhera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1e352-x2-218">
   <w.rf>
    <LM>w#w-d1e352-x2-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-219">
  <m id="m053-d1t361-1">
   <w.rf>
    <LM>w#w-d1t361-1</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t361-2">
   <w.rf>
    <LM>w#w-d1t361-2</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t361-3">
   <w.rf>
    <LM>w#w-d1t361-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t361-4">
   <w.rf>
    <LM>w#w-d1t361-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t361-5">
   <w.rf>
    <LM>w#w-d1t361-5</LM>
   </w.rf>
   <form>pojedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m053-219-222">
   <w.rf>
    <LM>w#w-219-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-223">
  <m id="m053-d1t361-7">
   <w.rf>
    <LM>w#w-d1t361-7</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t361-8">
   <w.rf>
    <LM>w#w-d1t361-8</LM>
   </w.rf>
   <form>přijedu</form>
   <lemma>přijet</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m053-d1t361-9">
   <w.rf>
    <LM>w#w-d1t361-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t361-9-sw1">
   <w.rf>
    <LM>w#w-d1t361-9</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>odsud</form>
   <lemma>odsud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d-id66512-punct">
   <w.rf>
    <LM>w#w-d-id66512-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t361-12">
   <w.rf>
    <LM>w#w-d1t361-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t361-13">
   <w.rf>
    <LM>w#w-d1t361-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t361-14">
   <w.rf>
    <LM>w#w-d1t361-14</LM>
   </w.rf>
   <form>sbalíme</form>
   <lemma>sbalit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m053-223-224">
   <w.rf>
    <LM>w#w-223-224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t361-16">
   <w.rf>
    <LM>w#w-d1t361-16</LM>
   </w.rf>
   <form>nastrkáme</form>
   <lemma>nastrkat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m053-d1t361-17">
   <w.rf>
    <LM>w#w-d1t361-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t361-18">
   <w.rf>
    <LM>w#w-d1t361-18</LM>
   </w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m053-d1t361-19">
   <w.rf>
    <LM>w#w-d1t361-19</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t361-20">
   <w.rf>
    <LM>w#w-d1t361-20</LM>
   </w.rf>
   <form>pojedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m053-223-225">
   <w.rf>
    <LM>w#w-223-225</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-226">
  <m id="m053-d1t366-2">
   <w.rf>
    <LM>w#w-d1t366-2</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m053-d1t366-3">
   <w.rf>
    <LM>w#w-d1t366-3</LM>
   </w.rf>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t366-5">
   <w.rf>
    <LM>w#w-d1t366-5</LM>
   </w.rf>
   <form>musíme</form>
   <lemma>muset</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t366-4">
   <w.rf>
    <LM>w#w-d1t366-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t366-6">
   <w.rf>
    <LM>w#w-d1t366-6</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d-id66770-punct">
   <w.rf>
    <LM>w#w-d-id66770-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t366-8">
   <w.rf>
    <LM>w#w-d1t366-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t366-9">
   <w.rf>
    <LM>w#w-d1t366-9</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t366-12">
   <w.rf>
    <LM>w#w-d1t366-12</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m053-d1t366-13">
   <w.rf>
    <LM>w#w-d1t366-13</LM>
   </w.rf>
   <form>muset</form>
   <lemma>muset</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t366-14">
   <w.rf>
    <LM>w#w-d1t366-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t366-15">
   <w.rf>
    <LM>w#w-d1t366-15</LM>
   </w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t366-16">
   <w.rf>
    <LM>w#w-d1t366-16</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m053-d1t366-17">
   <w.rf>
    <LM>w#w-d1t366-17</LM>
   </w.rf>
   <form>lékařce</form>
   <lemma>lékařka_^(*2)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m053-d-m-d1e352-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e352-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e373-x2">
  <m id="m053-d1t378-4">
   <w.rf>
    <LM>w#w-d1t378-4</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t378-5">
   <w.rf>
    <LM>w#w-d1t378-5</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m053-d1t380-1">
   <w.rf>
    <LM>w#w-d1t380-1</LM>
   </w.rf>
   <form>příští</form>
   <lemma>příští</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t380-2">
   <w.rf>
    <LM>w#w-d1t380-2</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t378-6">
   <w.rf>
    <LM>w#w-d1t378-6</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d-id67178-punct">
   <w.rf>
    <LM>w#w-d-id67178-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t380-4">
   <w.rf>
    <LM>w#w-d1t380-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t380-5">
   <w.rf>
    <LM>w#w-d1t380-5</LM>
   </w.rf>
   <form>vyrazíme</form>
   <lemma>vyrazit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m053-d1t380-6">
   <w.rf>
    <LM>w#w-d1t380-6</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1e373-x2-231">
   <w.rf>
    <LM>w#w-d1e373-x2-231</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-232">
  <m id="m053-d1t387-2">
   <w.rf>
    <LM>w#w-d1t387-2</LM>
   </w.rf>
   <form>Předminulý</form>
   <lemma>předminulý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t387-3">
   <w.rf>
    <LM>w#w-d1t387-3</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t387-4">
   <w.rf>
    <LM>w#w-d1t387-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--4----------</tag>
  </m>
  <m id="m053-d1t387-5">
   <w.rf>
    <LM>w#w-d1t387-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>čtvrtek</form>
   <lemma>čtvrtek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t387-6">
   <w.rf>
    <LM>w#w-d1t387-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t387-7">
   <w.rf>
    <LM>w#w-d1t387-7</LM>
   </w.rf>
   <form>přijeli</form>
   <lemma>přijet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d-id67500-punct">
   <w.rf>
    <LM>w#w-d-id67500-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t389-1">
   <w.rf>
    <LM>w#w-d1t389-1</LM>
   </w.rf>
   <form>přivezli</form>
   <lemma>přivézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d1t389-2">
   <w.rf>
    <LM>w#w-d1t389-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t389-3">
   <w.rf>
    <LM>w#w-d1t389-3</LM>
   </w.rf>
   <form>sedmikilového</form>
   <lemma>sedmikilový</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m053-d1t389-4">
   <w.rf>
    <LM>w#w-d1t389-4</LM>
   </w.rf>
   <form>amura</form>
   <lemma>amur-2</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m053-d-id67580-punct">
   <w.rf>
    <LM>w#w-d-id67580-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m053-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>kapry</form>
   <lemma>kapr</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m053-232-235">
   <w.rf>
    <LM>w#w-232-235</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t393-1">
   <w.rf>
    <LM>w#w-d1t393-1</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m053-d1t393-2">
   <w.rf>
    <LM>w#w-d1t393-2</LM>
   </w.rf>
   <form>cejny</form>
   <lemma>cejn-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m053-232-236">
   <w.rf>
    <LM>w#w-232-236</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t393-3">
   <w.rf>
    <LM>w#w-d1t393-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m053-d1t393-4">
   <w.rf>
    <LM>w#w-d1t393-4</LM>
   </w.rf>
   <form>bašta</form>
   <lemma>bašta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d-m-d1e373-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e373-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e394-x2">
  <m id="m053-d1t399-1">
   <w.rf>
    <LM>w#w-d1t399-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d1e394-x2-239">
   <w.rf>
    <LM>w#w-d1e394-x2-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-240">
  <m id="m053-d1t399-3">
   <w.rf>
    <LM>w#w-d1t399-3</LM>
   </w.rf>
   <form>Povíte</form>
   <lemma>povědět</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m053-d1t399-4">
   <w.rf>
    <LM>w#w-d1t399-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m053-d1t399-5">
   <w.rf>
    <LM>w#w-d1t399-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m053-d1t399-6">
   <w.rf>
    <LM>w#w-d1t399-6</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m053-d1t399-7">
   <w.rf>
    <LM>w#w-d1t399-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t399-8">
   <w.rf>
    <LM>w#w-d1t399-8</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m053-d-id67879-punct">
   <w.rf>
    <LM>w#w-d-id67879-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e400-x2">
  <m id="m053-d1t407-1">
   <w.rf>
    <LM>w#w-d1t407-1</LM>
   </w.rf>
   <form>Mohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m053-d1t407-2">
   <w.rf>
    <LM>w#w-d1t407-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m053-d1t407-3">
   <w.rf>
    <LM>w#w-d1t407-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m053-d1t407-4">
   <w.rf>
    <LM>w#w-d1t407-4</LM>
   </w.rf>
   <form>povědět</form>
   <lemma>povědět</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-d1e400-x2-166">
   <w.rf>
    <LM>w#w-d1e400-x2-166</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-167">
  <m id="m053-d1t409-1">
   <w.rf>
    <LM>w#w-d1t409-1</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m053-d-id68045-punct">
   <w.rf>
    <LM>w#w-d-id68045-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t409-4">
   <w.rf>
    <LM>w#w-d1t409-4</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t409-5">
   <w.rf>
    <LM>w#w-d1t409-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t409-6">
   <w.rf>
    <LM>w#w-d1t409-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t409-7">
   <w.rf>
    <LM>w#w-d1t409-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t409-8">
   <w.rf>
    <LM>w#w-d1t409-8</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m053-d1t409-9">
   <w.rf>
    <LM>w#w-d1t409-9</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1e400-x2-257">
   <w.rf>
    <LM>w#w-d1e400-x2-257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1e400-x2-258">
   <w.rf>
    <LM>w#w-d1e400-x2-258</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1e400-x2-259">
   <w.rf>
    <LM>w#w-d1e400-x2-259</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t416-3">
   <w.rf>
    <LM>w#w-d1t416-3</LM>
   </w.rf>
   <form>boční</form>
   <lemma>boční</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m053-d1t416-4">
   <w.rf>
    <LM>w#w-d1t416-4</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m053-d1t416-7">
   <w.rf>
    <LM>w#w-d1t416-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t416-8">
   <w.rf>
    <LM>w#w-d1t416-8</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m053-d1t416-10">
   <w.rf>
    <LM>w#w-d1t416-10</LM>
   </w.rf>
   <form>zastřešený</form>
   <lemma>zastřešený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t416-9">
   <w.rf>
    <LM>w#w-d1t416-9</LM>
   </w.rf>
   <form>karavan</form>
   <lemma>karavan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1e400-x2-252">
   <w.rf>
    <LM>w#w-d1e400-x2-252</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-251">
  <m id="m053-d1t418-2">
   <w.rf>
    <LM>w#w-d1t418-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t418-3">
   <w.rf>
    <LM>w#w-d1t418-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m053-d1t418-4">
   <w.rf>
    <LM>w#w-d1t418-4</LM>
   </w.rf>
   <form>2002</form>
   <lemma>2002</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m053-d1t422-4">
   <w.rf>
    <LM>w#w-d1t422-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t422-3">
   <w.rf>
    <LM>w#w-d1t422-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t422-5">
   <w.rf>
    <LM>w#w-d1t422-5</LM>
   </w.rf>
   <form>zvedla</form>
   <lemma>zvednout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m053-d1t422-6">
   <w.rf>
    <LM>w#w-d1t422-6</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-251-253">
   <w.rf>
    <LM>w#w-251-253</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-254">
  <m id="m053-d1t427-1">
   <w.rf>
    <LM>w#w-d1t427-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t429-2">
   <w.rf>
    <LM>w#w-d1t429-2</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t429-1">
   <w.rf>
    <LM>w#w-d1t429-1</LM>
   </w.rf>
   <form>zatopila</form>
   <lemma>zatopit_^(zaplavit_i_udělat_teplo)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m053-d1t429-4">
   <w.rf>
    <LM>w#w-d1t429-4</LM>
   </w.rf>
   <form>Budějovice</form>
   <lemma>Budějovice_;G</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m053-d-m-d1e400-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e400-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e433-x2">
  <m id="m053-d1t438-9">
   <w.rf>
    <LM>w#w-d1t438-9</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t438-7">
   <w.rf>
    <LM>w#w-d1t438-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t446-2">
   <w.rf>
    <LM>w#w-d1t446-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t446-4">
   <w.rf>
    <LM>w#w-d1t446-4</LM>
   </w.rf>
   <form>Orlík</form>
   <lemma>Orlík_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d-id69192-punct">
   <w.rf>
    <LM>w#w-d-id69192-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t446-7">
   <w.rf>
    <LM>w#w-d1t446-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t446-9">
   <w.rf>
    <LM>w#w-d1t446-9</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m053-d1t446-8">
   <w.rf>
    <LM>w#w-d1t446-8</LM>
   </w.rf>
   <form>správce</form>
   <lemma>správce</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m053-d1t446-10">
   <w.rf>
    <LM>w#w-d1t446-10</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m053-d1e443-x2-278">
   <w.rf>
    <LM>w#w-d1e443-x2-278</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1e443-x2-279">
   <w.rf>
    <LM>w#w-d1e443-x2-279</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t448-1">
   <w.rf>
    <LM>w#w-d1t448-1</LM>
   </w.rf>
   <form>Zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t448-2">
   <w.rf>
    <LM>w#w-d1t448-2</LM>
   </w.rf>
   <form>nebezpečí</form>
   <lemma>nebezpečí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m053-d1t448-3">
   <w.rf>
    <LM>w#w-d1t448-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m053-d-id69319-punct">
   <w.rf>
    <LM>w#w-d-id69319-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t448-5">
   <w.rf>
    <LM>w#w-d1t448-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t452-1">
   <w.rf>
    <LM>w#w-d1t452-1</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t452-2">
   <w.rf>
    <LM>w#w-d1t452-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t452-3">
   <w.rf>
    <LM>w#w-d1t452-3</LM>
   </w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-d1e433-x2-196">
   <w.rf>
    <LM>w#w-d1e433-x2-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-201">
  <m id="m053-d1t452-7">
   <w.rf>
    <LM>w#w-d1t452-7</LM>
   </w.rf>
   <form>Přijeďte</form>
   <lemma>přijet</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m053-d1t452-6">
   <w.rf>
    <LM>w#w-d1t452-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m053-d1e443-x2-284">
   <w.rf>
    <LM>w#w-d1e443-x2-284</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t452-8">
   <w.rf>
    <LM>w#w-d1t452-8</LM>
   </w.rf>
   <form>ať</form>
   <lemma>ať-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t452-9">
   <w.rf>
    <LM>w#w-d1t452-9</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m053-d1t452-10">
   <w.rf>
    <LM>w#w-d1t452-10</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t452-11">
   <w.rf>
    <LM>w#w-d1t452-11</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m053-d1e443-x2-281">
   <w.rf>
    <LM>w#w-d1e443-x2-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1e443-x2-282">
   <w.rf>
    <LM>w#w-d1e443-x2-282</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-283">
  <m id="m053-d1t457-3">
   <w.rf>
    <LM>w#w-d1t457-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t457-4">
   <w.rf>
    <LM>w#w-d1t457-4</LM>
   </w.rf>
   <form>pondělí</form>
   <lemma>pondělí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m053-d1t457-2">
   <w.rf>
    <LM>w#w-d1t457-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t457-5">
   <w.rf>
    <LM>w#w-d1t457-5</LM>
   </w.rf>
   <form>sedli</form>
   <lemma>sednout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m053-d1t457-6">
   <w.rf>
    <LM>w#w-d1t457-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t457-7">
   <w.rf>
    <LM>w#w-d1t457-7</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-283-287">
   <w.rf>
    <LM>w#w-283-287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-288">
  <m id="m053-d1t461-1">
   <w.rf>
    <LM>w#w-d1t461-1</LM>
   </w.rf>
   <form>Celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m053-d1t461-2">
   <w.rf>
    <LM>w#w-d1t461-2</LM>
   </w.rf>
   <form>noc</form>
   <lemma>noc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d1t461-3">
   <w.rf>
    <LM>w#w-d1t461-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t461-4">
   <w.rf>
    <LM>w#w-d1t461-4</LM>
   </w.rf>
   <form>pondělka</form>
   <lemma>pondělek</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m053-d1t461-5">
   <w.rf>
    <LM>w#w-d1t461-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t461-6">
   <w.rf>
    <LM>w#w-d1t461-6</LM>
   </w.rf>
   <form>úterý</form>
   <lemma>úterý</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m053-288-289">
   <w.rf>
    <LM>w#w-288-289</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t461-7">
   <w.rf>
    <LM>w#w-d1t461-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t461-8">
   <w.rf>
    <LM>w#w-d1t461-8</LM>
   </w.rf>
   <form>dvanáctého</form>
   <lemma>dvanáctý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m053-d1t461-9">
   <w.rf>
    <LM>w#w-d1t461-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t461-10">
   <w.rf>
    <LM>w#w-d1t461-10</LM>
   </w.rf>
   <form>třináctého</form>
   <lemma>třináctý</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m053-d1t461-11">
   <w.rf>
    <LM>w#w-d1t461-11</LM>
   </w.rf>
   <form>srpna</form>
   <lemma>srpen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m053-288-290">
   <w.rf>
    <LM>w#w-288-290</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t463-1">
   <w.rf>
    <LM>w#w-d1t463-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t463-2">
   <w.rf>
    <LM>w#w-d1t463-2</LM>
   </w.rf>
   <form>každé</form>
   <lemma>každý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m053-d1t463-3">
   <w.rf>
    <LM>w#w-d1t463-3</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m053-d1t463-4">
   <w.rf>
    <LM>w#w-d1t463-4</LM>
   </w.rf>
   <form>hodiny</form>
   <lemma>hodina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m053-d1t463-5">
   <w.rf>
    <LM>w#w-d1t463-5</LM>
   </w.rf>
   <form>vstávali</form>
   <lemma>vstávat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t465-1">
   <w.rf>
    <LM>w#w-d1t465-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t465-2">
   <w.rf>
    <LM>w#w-d1t465-2</LM>
   </w.rf>
   <form>číhali</form>
   <lemma>číhat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t465-3">
   <w.rf>
    <LM>w#w-d1t465-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t465-4">
   <w.rf>
    <LM>w#w-d1t465-4</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-288-291">
   <w.rf>
    <LM>w#w-288-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-286">
  <m id="m053-d1t467-3">
   <w.rf>
    <LM>w#w-d1t467-3</LM>
   </w.rf>
   <form>Voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t467-4">
   <w.rf>
    <LM>w#w-d1t467-4</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m053-d1t467-5">
   <w.rf>
    <LM>w#w-d1t467-5</LM>
   </w.rf>
   <form>stoupat</form>
   <lemma>stoupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t467-6">
   <w.rf>
    <LM>w#w-d1t467-6</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t467-7">
   <w.rf>
    <LM>w#w-d1t467-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t467-8">
   <w.rf>
    <LM>w#w-d1t467-8</LM>
   </w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m053-d1t467-9">
   <w.rf>
    <LM>w#w-d1t467-9</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m053-d1t467-10">
   <w.rf>
    <LM>w#w-d1t467-10</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t467-12">
   <w.rf>
    <LM>w#w-d1t467-12</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m053-d1t467-13">
   <w.rf>
    <LM>w#w-d1t467-13</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-286-295">
   <w.rf>
    <LM>w#w-286-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e443-x3">
  <m id="m053-d1t470-2">
   <w.rf>
    <LM>w#w-d1t470-2</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m053-d1t470-3">
   <w.rf>
    <LM>w#w-d1t470-3</LM>
   </w.rf>
   <form>hodina</form>
   <lemma>hodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t470-4">
   <w.rf>
    <LM>w#w-d1t470-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m053-d1t472-1">
   <w.rf>
    <LM>w#w-d1t472-1</LM>
   </w.rf>
   <form>přibylo</form>
   <lemma>přibýt</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m053-d1t470-5">
   <w.rf>
    <LM>w#w-d1t470-5</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m053-d1t470-6">
   <w.rf>
    <LM>w#w-d1t470-6</LM>
   </w.rf>
   <form>metru</form>
   <lemma>metr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m053-d1t472-2">
   <w.rf>
    <LM>w#w-d1t472-2</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m053-d1t470-7">
   <w.rf>
    <LM>w#w-d1t470-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t470-8">
   <w.rf>
    <LM>w#w-d1t470-8</LM>
   </w.rf>
   <form>sloupec</form>
   <lemma>sloupec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1e443-x3-299">
   <w.rf>
    <LM>w#w-d1e443-x3-299</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-300">
  <m id="m053-d1t474-3">
   <w.rf>
    <LM>w#w-d1t474-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t474-4">
   <w.rf>
    <LM>w#w-d1t474-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t474-5">
   <w.rf>
    <LM>w#w-d1t474-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t474-6">
   <w.rf>
    <LM>w#w-d1t474-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t474-7">
   <w.rf>
    <LM>w#w-d1t474-7</LM>
   </w.rf>
   <form>blížilo</form>
   <lemma>blížit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m053-d1t474-8">
   <w.rf>
    <LM>w#w-d1t474-8</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m053-d1t474-10">
   <w.rf>
    <LM>w#w-d1t474-10</LM>
   </w.rf>
   <form>karavanu</form>
   <lemma>karavan</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m053-d-id70532-punct">
   <w.rf>
    <LM>w#w-d-id70532-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t474-12">
   <w.rf>
    <LM>w#w-d1t474-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t483-2">
   <w.rf>
    <LM>w#w-d1t483-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t483-3">
   <w.rf>
    <LM>w#w-d1t483-3</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d1t483-4">
   <w.rf>
    <LM>w#w-d1t483-4</LM>
   </w.rf>
   <form>vynášet</form>
   <lemma>vynášet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t483-5">
   <w.rf>
    <LM>w#w-d1t483-5</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m053-d-id70700-punct">
   <w.rf>
    <LM>w#w-d-id70700-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t483-7">
   <w.rf>
    <LM>w#w-d1t483-7</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m053-d1t483-8">
   <w.rf>
    <LM>w#w-d1t483-8</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m053-d1t483-9">
   <w.rf>
    <LM>w#w-d1t483-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t483-10">
   <w.rf>
    <LM>w#w-d1t483-10</LM>
   </w.rf>
   <form>mohly</form>
   <lemma>moci</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m053-d1t483-11">
   <w.rf>
    <LM>w#w-d1t483-11</LM>
   </w.rf>
   <form>zbytečně</form>
   <lemma>zbytečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d1t483-12">
   <w.rf>
    <LM>w#w-d1t483-12</LM>
   </w.rf>
   <form>namočit</form>
   <lemma>namočit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-d1t485-1">
   <w.rf>
    <LM>w#w-d1t485-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t485-2">
   <w.rf>
    <LM>w#w-d1t485-2</LM>
   </w.rf>
   <form>zničit</form>
   <lemma>zničit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m053-300-304">
   <w.rf>
    <LM>w#w-300-304</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-305">
  <m id="m053-d1t489-4">
   <w.rf>
    <LM>w#w-d1t489-4</LM>
   </w.rf>
   <form>Vynesli</form>
   <lemma>vynést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d1t489-2">
   <w.rf>
    <LM>w#w-d1t489-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t489-3">
   <w.rf>
    <LM>w#w-d1t489-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t489-5">
   <w.rf>
    <LM>w#w-d1t489-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t489-6">
   <w.rf>
    <LM>w#w-d1t489-6</LM>
   </w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m053-d1t489-7">
   <w.rf>
    <LM>w#w-d1t489-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t489-9">
   <w.rf>
    <LM>w#w-d1t489-9</LM>
   </w.rf>
   <form>odvezli</form>
   <lemma>odvézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d1t489-11">
   <w.rf>
    <LM>w#w-d1t489-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t489-12">
   <w.rf>
    <LM>w#w-d1t489-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t489-13">
   <w.rf>
    <LM>w#w-d1t489-13</LM>
   </w.rf>
   <form>kopec</form>
   <lemma>kopec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-305-307">
   <w.rf>
    <LM>w#w-305-307</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-308">
  <m id="m053-d1t491-4">
   <w.rf>
    <LM>w#w-d1t491-4</LM>
   </w.rf>
   <form>Škodu</form>
   <lemma>škoda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d1t491-5">
   <w.rf>
    <LM>w#w-d1t491-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t491-6">
   <w.rf>
    <LM>w#w-d1t491-6</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m053-d-m-d1e443-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e443-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e504-x2">
  <m id="m053-d1t499-2">
   <w.rf>
    <LM>w#w-d1t499-2</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m053-d1t499-3">
   <w.rf>
    <LM>w#w-d1t499-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m053-d1t507-4">
   <w.rf>
    <LM>w#w-d1t507-4</LM>
   </w.rf>
   <form>zatopený</form>
   <lemma>zatopený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t507-2">
   <w.rf>
    <LM>w#w-d1t507-2</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t507-3">
   <w.rf>
    <LM>w#w-d1t507-3</LM>
   </w.rf>
   <form>karavan</form>
   <lemma>karavan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d-id71447-punct">
   <w.rf>
    <LM>w#w-d-id71447-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t507-7">
   <w.rf>
    <LM>w#w-d1t507-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t507-8">
   <w.rf>
    <LM>w#w-d1t507-8</LM>
   </w.rf>
   <form>koukala</form>
   <lemma>koukat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m053-d1t507-9">
   <w.rf>
    <LM>w#w-d1t507-9</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t507-10">
   <w.rf>
    <LM>w#w-d1t507-10</LM>
   </w.rf>
   <form>střecha</form>
   <lemma>střecha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1e504-x2-6">
   <w.rf>
    <LM>w#w-d1e504-x2-6</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-7">
  <m id="m053-d1t507-11">
   <w.rf>
    <LM>w#w-d1t507-11</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t507-12">
   <w.rf>
    <LM>w#w-d1t507-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t507-13">
   <w.rf>
    <LM>w#w-d1t507-13</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t507-14">
   <w.rf>
    <LM>w#w-d1t507-14</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t507-15">
   <w.rf>
    <LM>w#w-d1t507-15</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m053-d1t507-16">
   <w.rf>
    <LM>w#w-d1t507-16</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m053-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m053-d1t511-2">
   <w.rf>
    <LM>w#w-d1t511-2</LM>
   </w.rf>
   <form>sedmimetrové</form>
   <lemma>sedmimetrový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m053-d1t511-3">
   <w.rf>
    <LM>w#w-d1t511-3</LM>
   </w.rf>
   <form>maringotky</form>
   <lemma>maringotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m053-d1t511-5">
   <w.rf>
    <LM>w#w-d1t511-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t511-6">
   <w.rf>
    <LM>w#w-d1t511-6</LM>
   </w.rf>
   <form>kolech</form>
   <lemma>kolo</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m053-7-8">
   <w.rf>
    <LM>w#w-7-8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-9">
  <m id="m053-d1t515-3">
   <w.rf>
    <LM>w#w-d1t515-3</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m053-d1t515-7">
   <w.rf>
    <LM>w#w-d1t515-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t515-4">
   <w.rf>
    <LM>w#w-d1t515-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t515-5">
   <w.rf>
    <LM>w#w-d1t515-5</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m053-d1t515-6">
   <w.rf>
    <LM>w#w-d1t515-6</LM>
   </w.rf>
   <form>níž</form>
   <lemma>nízko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m053-d1t515-9">
   <w.rf>
    <LM>w#w-d1t515-9</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t515-10">
   <w.rf>
    <LM>w#w-d1t515-10</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m053-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t520-2">
   <w.rf>
    <LM>w#w-d1t520-2</LM>
   </w.rf>
   <form>plavaly</form>
   <lemma>plavat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m053-9-15">
   <w.rf>
    <LM>w#w-9-15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-16">
  <m id="m053-d1t531-2">
   <w.rf>
    <LM>w#w-d1t531-2</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t531-4">
   <w.rf>
    <LM>w#w-d1t531-4</LM>
   </w.rf>
   <form>maringotky</form>
   <lemma>maringotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m053-d1t526-1">
   <w.rf>
    <LM>w#w-d1t526-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m053-d1t526-2">
   <w.rf>
    <LM>w#w-d1t526-2</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t526-3">
   <w.rf>
    <LM>w#w-d1t526-3</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m053-d1t526-4">
   <w.rf>
    <LM>w#w-d1t526-4</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m053-d1t526-5">
   <w.rf>
    <LM>w#w-d1t526-5</LM>
   </w.rf>
   <form>centimetrů</form>
   <lemma>centimetr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m053-d1t528-1">
   <w.rf>
    <LM>w#w-d1t528-1</LM>
   </w.rf>
   <form>střechy</form>
   <lemma>střecha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m053-16-42">
   <w.rf>
    <LM>w#w-16-42</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t535-2">
   <w.rf>
    <LM>w#w-d1t535-2</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1t535-3">
   <w.rf>
    <LM>w#w-d1t535-3</LM>
   </w.rf>
   <form>stoupla</form>
   <lemma>stoupnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m053-d1t535-4">
   <w.rf>
    <LM>w#w-d1t535-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t535-5">
   <w.rf>
    <LM>w#w-d1t535-5</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m053-d1t535-6">
   <w.rf>
    <LM>w#w-d1t535-6</LM>
   </w.rf>
   <form>metru</form>
   <lemma>metr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m053-d1t535-7">
   <w.rf>
    <LM>w#w-d1t535-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t535-8">
   <w.rf>
    <LM>w#w-d1t535-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m053-d1t535-9">
   <w.rf>
    <LM>w#w-d1t535-9</LM>
   </w.rf>
   <form>20</form>
   <lemma>20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m053-d1t535-10">
   <w.rf>
    <LM>w#w-d1t535-10</LM>
   </w.rf>
   <form>centimetrů</form>
   <lemma>centimetr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m053-d1t537-1">
   <w.rf>
    <LM>w#w-d1t537-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m053-d1t537-2">
   <w.rf>
    <LM>w#w-d1t537-2</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t537-3">
   <w.rf>
    <LM>w#w-d1t537-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-16-22">
   <w.rf>
    <LM>w#w-16-22</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e504-x3">
  <m id="m053-d1t539-4">
   <w.rf>
    <LM>w#w-d1t539-4</LM>
   </w.rf>
   <form>Vzduch</form>
   <lemma>vzduch</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m053-d1t539-5">
   <w.rf>
    <LM>w#w-d1t539-5</LM>
   </w.rf>
   <form>nahromaděný</form>
   <lemma>nahromaděný_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m053-d1t539-7">
   <w.rf>
    <LM>w#w-d1t539-7</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m053-d1t539-8">
   <w.rf>
    <LM>w#w-d1t539-8</LM>
   </w.rf>
   <form>střechou</form>
   <lemma>střecha</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m053-d1t541-1">
   <w.rf>
    <LM>w#w-d1t541-1</LM>
   </w.rf>
   <form>nadzvedával</form>
   <lemma>nadzvedávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m053-d1t541-2">
   <w.rf>
    <LM>w#w-d1t541-2</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m053-d1t541-4">
   <w.rf>
    <LM>w#w-d1t541-4</LM>
   </w.rf>
   <form>maringotku</form>
   <lemma>maringotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d-m-d1e504-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e504-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e542-x2">
  <m id="m053-d1t547-1">
   <w.rf>
    <LM>w#w-d1t547-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t547-2">
   <w.rf>
    <LM>w#w-d1t547-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t547-3">
   <w.rf>
    <LM>w#w-d1t547-3</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m053-d1e542-x2-25">
   <w.rf>
    <LM>w#w-d1e542-x2-25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-27">
  <m id="m053-d1t547-7">
   <w.rf>
    <LM>w#w-d1t547-7</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m053-d1t547-6">
   <w.rf>
    <LM>w#w-d1t547-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m053-d1t547-8">
   <w.rf>
    <LM>w#w-d1t547-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t547-9">
   <w.rf>
    <LM>w#w-d1t547-9</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m053-d1t547-10">
   <w.rf>
    <LM>w#w-d1t547-10</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m053-d-m-d1e542-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e542-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e548-x2">
  <m id="m053-d1t551-1">
   <w.rf>
    <LM>w#w-d1t551-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d1e548-x2-29">
   <w.rf>
    <LM>w#w-d1e548-x2-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-30">
  <m id="m053-d1t553-2">
   <w.rf>
    <LM>w#w-d1t553-2</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t553-3">
   <w.rf>
    <LM>w#w-d1t553-3</LM>
   </w.rf>
   <form>vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m053-d1t553-5">
   <w.rf>
    <LM>w#w-d1t553-5</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d1t553-6">
   <w.rf>
    <LM>w#w-d1t553-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m053-d1t553-8">
   <w.rf>
    <LM>w#w-d1t553-8</LM>
   </w.rf>
   <form>povodně</form>
   <lemma>povodeň</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m053-d-m-d1e548-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e548-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e556-x3">
  <m id="m053-d1t565-1">
   <w.rf>
    <LM>w#w-d1t565-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t565-2">
   <w.rf>
    <LM>w#w-d1t565-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t565-3">
   <w.rf>
    <LM>w#w-d1t565-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t565-4">
   <w.rf>
    <LM>w#w-d1t565-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m053-d1t565-5">
   <w.rf>
    <LM>w#w-d1t565-5</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m053-d1t565-6">
   <w.rf>
    <LM>w#w-d1t565-6</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d-id73381-punct">
   <w.rf>
    <LM>w#w-d-id73381-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e566-x2">
  <m id="m053-d1t569-1">
   <w.rf>
    <LM>w#w-d1t569-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m053-d1t569-2">
   <w.rf>
    <LM>w#w-d1t569-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t569-4">
   <w.rf>
    <LM>w#w-d1t569-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m053-d1t569-5">
   <w.rf>
    <LM>w#w-d1t569-5</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m053-d1t569-6">
   <w.rf>
    <LM>w#w-d1t569-6</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d1e566-x2-42">
   <w.rf>
    <LM>w#w-d1e566-x2-42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-41">
  <m id="m053-d1t573-1">
   <w.rf>
    <LM>w#w-d1t573-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t573-2">
   <w.rf>
    <LM>w#w-d1t573-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t573-3">
   <w.rf>
    <LM>w#w-d1t573-3</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m053-d1t573-4">
   <w.rf>
    <LM>w#w-d1t573-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t573-6">
   <w.rf>
    <LM>w#w-d1t573-6</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSIS4-P1-------</tag>
  </m>
  <m id="m053-d1t573-7">
   <w.rf>
    <LM>w#w-d1t573-7</LM>
   </w.rf>
   <form>karavan</form>
   <lemma>karavan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d-id73650-punct">
   <w.rf>
    <LM>w#w-d-id73650-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t573-9">
   <w.rf>
    <LM>w#w-d1t573-9</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t573-10">
   <w.rf>
    <LM>w#w-d1t573-10</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m053-d1t573-12">
   <w.rf>
    <LM>w#w-d1t573-12</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t573-11">
   <w.rf>
    <LM>w#w-d1t573-11</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t573-13">
   <w.rf>
    <LM>w#w-d1t573-13</LM>
   </w.rf>
   <form>zastřešený</form>
   <lemma>zastřešený_^(*3it)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t575-1">
   <w.rf>
    <LM>w#w-d1t575-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t575-2">
   <w.rf>
    <LM>w#w-d1t575-2</LM>
   </w.rf>
   <form>vybudovaný</form>
   <lemma>vybudovaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-41-43">
   <w.rf>
    <LM>w#w-41-43</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-44">
  <m id="m053-d1t582-1">
   <w.rf>
    <LM>w#w-d1t582-1</LM>
   </w.rf>
   <form>Ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m053-d1t582-2">
   <w.rf>
    <LM>w#w-d1t582-2</LM>
   </w.rf>
   <form>skutečnosti</form>
   <lemma>skutečnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m053-d1t582-6">
   <w.rf>
    <LM>w#w-d1t582-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t582-7">
   <w.rf>
    <LM>w#w-d1t582-7</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t582-11">
   <w.rf>
    <LM>w#w-d1t582-11</LM>
   </w.rf>
   <form>vevnitř</form>
   <lemma>vevnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t582-3">
   <w.rf>
    <LM>w#w-d1t582-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t582-5">
   <w.rf>
    <LM>w#w-d1t582-5</LM>
   </w.rf>
   <form>karavanu</form>
   <lemma>karavan</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m053-d1t582-8">
   <w.rf>
    <LM>w#w-d1t582-8</LM>
   </w.rf>
   <form>třičtvrtě</form>
   <lemma>třičtvrtě</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m053-d1t582-9">
   <w.rf>
    <LM>w#w-d1t582-9</LM>
   </w.rf>
   <form>metru</form>
   <lemma>metr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m053-d1t582-10">
   <w.rf>
    <LM>w#w-d1t582-10</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m053-44-48">
   <w.rf>
    <LM>w#w-44-48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-50">
  <m id="m053-d1t584-2">
   <w.rf>
    <LM>w#w-d1t584-2</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m053-d-id74038-punct">
   <w.rf>
    <LM>w#w-d-id74038-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t584-4">
   <w.rf>
    <LM>w#w-d1t584-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t584-5">
   <w.rf>
    <LM>w#w-d1t584-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t584-6">
   <w.rf>
    <LM>w#w-d1t584-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t584-7">
   <w.rf>
    <LM>w#w-d1t584-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m053-d1t584-8">
   <w.rf>
    <LM>w#w-d1t584-8</LM>
   </w.rf>
   <form>vynesli</form>
   <lemma>vynést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m053-d-id74148-punct">
   <w.rf>
    <LM>w#w-d-id74148-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t586-5">
   <w.rf>
    <LM>w#w-d1t586-5</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m053-d1t586-4">
   <w.rf>
    <LM>w#w-d1t586-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t586-7">
   <w.rf>
    <LM>w#w-d1t586-7</LM>
   </w.rf>
   <form>nevznikla</form>
   <lemma>vzniknout</lemma>
   <tag>VpQW----R-NAP-1</tag>
  </m>
  <m id="m053-d1t586-6">
   <w.rf>
    <LM>w#w-d1t586-6</LM>
   </w.rf>
   <form>absolutně</form>
   <lemma>absolutně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d1t586-8">
   <w.rf>
    <LM>w#w-d1t586-8</LM>
   </w.rf>
   <form>žádná</form>
   <lemma>žádný</lemma>
   <tag>PWFS1----------</tag>
  </m>
  <m id="m053-d1t586-9">
   <w.rf>
    <LM>w#w-d1t586-9</LM>
   </w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d-m-d1e566-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e566-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e587-x3">
  <m id="m053-d1t596-1">
   <w.rf>
    <LM>w#w-d1t596-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m053-d1t596-2">
   <w.rf>
    <LM>w#w-d1t596-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m053-d1t596-3">
   <w.rf>
    <LM>w#w-d1t596-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t596-4">
   <w.rf>
    <LM>w#w-d1t596-4</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m053-d-m-d1e587-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e587-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-d1e597-x2">
  <m id="m053-d1t600-1">
   <w.rf>
    <LM>w#w-d1t600-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m053-d1t600-2">
   <w.rf>
    <LM>w#w-d1t600-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t600-3">
   <w.rf>
    <LM>w#w-d1t600-3</LM>
   </w.rf>
   <form>štěstí</form>
   <lemma>štěstí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m053-d-id74557-punct">
   <w.rf>
    <LM>w#w-d-id74557-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t600-6">
   <w.rf>
    <LM>w#w-d1t600-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t600-7">
   <w.rf>
    <LM>w#w-d1t600-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t600-8">
   <w.rf>
    <LM>w#w-d1t600-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t600-9">
   <w.rf>
    <LM>w#w-d1t600-9</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m053-d1t600-10">
   <w.rf>
    <LM>w#w-d1t600-10</LM>
   </w.rf>
   <form>zvládli</form>
   <lemma>zvládnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m053-d1e597-x2-61">
   <w.rf>
    <LM>w#w-d1e597-x2-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-62">
  <m id="m053-d1t602-2">
   <w.rf>
    <LM>w#w-d1t602-2</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t602-4">
   <w.rf>
    <LM>w#w-d1t602-4</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m053-62-63">
   <w.rf>
    <LM>w#w-62-63</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-64">
  <m id="m053-d1t606-1">
   <w.rf>
    <LM>w#w-d1t606-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t606-3">
   <w.rf>
    <LM>w#w-d1t606-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t606-4">
   <w.rf>
    <LM>w#w-d1t606-4</LM>
   </w.rf>
   <form>popředí</form>
   <lemma>popředí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m053-d1t606-5">
   <w.rf>
    <LM>w#w-d1t606-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m053-d1t606-6">
   <w.rf>
    <LM>w#w-d1t606-6</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t606-7">
   <w.rf>
    <LM>w#w-d1t606-7</LM>
   </w.rf>
   <form>pramička</form>
   <lemma>pramička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m053-d-id74856-punct">
   <w.rf>
    <LM>w#w-d-id74856-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t606-9">
   <w.rf>
    <LM>w#w-d1t606-9</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m053-d1t606-10">
   <w.rf>
    <LM>w#w-d1t606-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t606-11">
   <w.rf>
    <LM>w#w-d1t606-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t606-12">
   <w.rf>
    <LM>w#w-d1t606-12</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-64-68">
   <w.rf>
    <LM>w#w-64-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-69">
  <m id="m053-d1t608-5">
   <w.rf>
    <LM>w#w-d1t608-5</LM>
   </w.rf>
   <form>Jezdím</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m053-d1t608-3">
   <w.rf>
    <LM>w#w-d1t608-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m053-d1t608-4">
   <w.rf>
    <LM>w#w-d1t608-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m053-d1t608-6">
   <w.rf>
    <LM>w#w-d1t608-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t608-7">
   <w.rf>
    <LM>w#w-d1t608-7</LM>
   </w.rf>
   <form>ryby</form>
   <lemma>ryba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m053-69-70">
   <w.rf>
    <LM>w#w-69-70</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t611-2">
   <w.rf>
    <LM>w#w-d1t611-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m053-d1t611-3">
   <w.rf>
    <LM>w#w-d1t611-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m053-d1t611-4">
   <w.rf>
    <LM>w#w-d1t611-4</LM>
   </w.rf>
   <form>vyjíždíme</form>
   <lemma>vyjíždět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m053-d1t611-9">
   <w.rf>
    <LM>w#w-d1t611-9</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t611-10">
   <w.rf>
    <LM>w#w-d1t611-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m053-d1t611-11">
   <w.rf>
    <LM>w#w-d1t611-11</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-69-71">
   <w.rf>
    <LM>w#w-69-71</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m053-72">
  <m id="m053-d1t615-1">
   <w.rf>
    <LM>w#w-d1t615-1</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t615-5">
   <w.rf>
    <LM>w#w-d1t615-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m053-d1t615-2">
   <w.rf>
    <LM>w#w-d1t615-2</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m053-d1t615-3">
   <w.rf>
    <LM>w#w-d1t615-3</LM>
   </w.rf>
   <form>dvěma</form>
   <lemma>dva`2</lemma>
   <tag>CnXP7----------</tag>
  </m>
  <m id="m053-d1t615-4">
   <w.rf>
    <LM>w#w-d1t615-4</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m053-d1t615-6">
   <w.rf>
    <LM>w#w-d1t615-6</LM>
   </w.rf>
   <form>koupil</form>
   <lemma>koupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m053-d1t615-7">
   <w.rf>
    <LM>w#w-d1t615-7</LM>
   </w.rf>
   <form>benzínový</form>
   <lemma>benzínový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m053-d1t615-8">
   <w.rf>
    <LM>w#w-d1t615-8</LM>
   </w.rf>
   <form>motůrek</form>
   <lemma>motůrek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m053-d-id75347-punct">
   <w.rf>
    <LM>w#w-d-id75347-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m053-d1t615-10">
   <w.rf>
    <LM>w#w-d1t615-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m053-d1t615-11">
   <w.rf>
    <LM>w#w-d1t615-11</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m053-d1t615-12">
   <w.rf>
    <LM>w#w-d1t615-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m053-d1t615-13">
   <w.rf>
    <LM>w#w-d1t615-13</LM>
   </w.rf>
   <form>nemusím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m053-d1t617-1">
   <w.rf>
    <LM>w#w-d1t617-1</LM>
   </w.rf>
   <form>popohánět</form>
   <lemma>popohánět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m053-d1t617-2">
   <w.rf>
    <LM>w#w-d1t617-2</LM>
   </w.rf>
   <form>ručně</form>
   <lemma>ručně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m053-d1t617-3">
   <w.rf>
    <LM>w#w-d1t617-3</LM>
   </w.rf>
   <form>vesly</form>
   <lemma>veslo</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m053-d-m-d1e597-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e597-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
