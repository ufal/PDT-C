<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_115.08.w.gz" />
  </references>
 </head>
 <s id="m115-253">
  <m id="m115-d1t1261-30">
   <w.rf>
    <LM>w#w-d1t1261-30</LM>
   </w.rf>
   <form>Původně</form>
   <lemma>původně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m115-d1t1261-31">
   <w.rf>
    <LM>w#w-d1t1261-31</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1261-32">
   <w.rf>
    <LM>w#w-d1t1261-32</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1261-33">
   <w.rf>
    <LM>w#w-d1t1261-33</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1261-34">
   <w.rf>
    <LM>w#w-d1t1261-34</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m115-d1t1261-35">
   <w.rf>
    <LM>w#w-d1t1261-35</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1261-37">
   <w.rf>
    <LM>w#w-d1t1261-37</LM>
   </w.rf>
   <form>Zahradním</form>
   <lemma>zahradní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m115-d1t1261-38">
   <w.rf>
    <LM>w#w-d1t1261-38</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m115-d-id135482-punct">
   <w.rf>
    <LM>w#w-d-id135482-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1261-41">
   <w.rf>
    <LM>w#w-d1t1261-41</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1261-42">
   <w.rf>
    <LM>w#w-d1t1261-42</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1261-43">
   <w.rf>
    <LM>w#w-d1t1261-43</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1261-44">
   <w.rf>
    <LM>w#w-d1t1261-44</LM>
   </w.rf>
   <form>vilku</form>
   <lemma>vilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m115-d-id135552-punct">
   <w.rf>
    <LM>w#w-d-id135552-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1261-46">
   <w.rf>
    <LM>w#w-d1t1261-46</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1261-47">
   <w.rf>
    <LM>w#w-d1t1261-47</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d-id135592-punct">
   <w.rf>
    <LM>w#w-d-id135592-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1261-49">
   <w.rf>
    <LM>w#w-d1t1261-49</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1261-50">
   <w.rf>
    <LM>w#w-d1t1261-50</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1261-51">
   <w.rf>
    <LM>w#w-d1t1261-51</LM>
   </w.rf>
   <form>umřela</form>
   <lemma>umřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m115-d-id135647-punct">
   <w.rf>
    <LM>w#w-d-id135647-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1261-54">
   <w.rf>
    <LM>w#w-d1t1261-54</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1261-55">
   <w.rf>
    <LM>w#w-d1t1261-55</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1261-57">
   <w.rf>
    <LM>w#w-d1t1261-57</LM>
   </w.rf>
   <form>přeneslo</form>
   <lemma>přenést</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m115-d1t1261-58">
   <w.rf>
    <LM>w#w-d1t1261-58</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m115-d1t1261-59">
   <w.rf>
    <LM>w#w-d1t1261-59</LM>
   </w.rf>
   <form>sestře</form>
   <lemma>sestra</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m115-253-254">
   <w.rf>
    <LM>w#w-253-254</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-256">
  <m id="m115-d1t1265-7">
   <w.rf>
    <LM>w#w-d1t1265-7</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1265-8">
   <w.rf>
    <LM>w#w-d1t1265-8</LM>
   </w.rf>
   <form>rozbalily</form>
   <lemma>rozbalit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m115-d1t1265-9">
   <w.rf>
    <LM>w#w-d1t1265-9</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m115-256-260">
   <w.rf>
    <LM>w#w-256-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-262">
  <m id="m115-d1t1269-1">
   <w.rf>
    <LM>w#w-d1t1269-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-262-263">
   <w.rf>
    <LM>w#w-262-263</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1269-2">
   <w.rf>
    <LM>w#w-d1t1269-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS1----------</tag>
  </m>
  <m id="m115-d1t1269-3">
   <w.rf>
    <LM>w#w-d1t1269-3</LM>
   </w.rf>
   <form>miminko</form>
   <lemma>miminko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m115-d-id135986-punct">
   <w.rf>
    <LM>w#w-d-id135986-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1269-5">
   <w.rf>
    <LM>w#w-d1t1269-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1269-6">
   <w.rf>
    <LM>w#w-d1t1269-6</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-262-264">
   <w.rf>
    <LM>w#w-262-264</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1232-x5">
  <m id="m115-d1t1269-7">
   <w.rf>
    <LM>w#w-d1t1269-7</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1269-8">
   <w.rf>
    <LM>w#w-d1t1269-8</LM>
   </w.rf>
   <form>rozbalily</form>
   <lemma>rozbalit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m115-d1t1269-10">
   <w.rf>
    <LM>w#w-d1t1269-10</LM>
   </w.rf>
   <form>dárky</form>
   <lemma>dárek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m115-d1t1269-12">
   <w.rf>
    <LM>w#w-d1t1269-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1269-13">
   <w.rf>
    <LM>w#w-d1t1269-13</LM>
   </w.rf>
   <form>radujou</form>
   <lemma>radovat</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m115-d1t1269-14">
   <w.rf>
    <LM>w#w-d1t1269-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1e1232-x5-274">
   <w.rf>
    <LM>w#w-d1e1232-x5-274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-278">
  <m id="m115-d1t1269-17">
   <w.rf>
    <LM>w#w-d1t1269-17</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1269-18">
   <w.rf>
    <LM>w#w-d1t1269-18</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1269-19">
   <w.rf>
    <LM>w#w-d1t1269-19</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m115-d1t1269-21">
   <w.rf>
    <LM>w#w-d1t1269-21</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m115-d1t1269-22">
   <w.rf>
    <LM>w#w-d1t1269-22</LM>
   </w.rf>
   <form>atmosféra</form>
   <lemma>atmosféra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-278-281">
   <w.rf>
    <LM>w#w-278-281</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-284">
  <m id="m115-d1t1269-26">
   <w.rf>
    <LM>w#w-d1t1269-26</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1269-27">
   <w.rf>
    <LM>w#w-d1t1269-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1272-1">
   <w.rf>
    <LM>w#w-d1t1272-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m115-d1t1272-2">
   <w.rf>
    <LM>w#w-d1t1272-2</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m115-284-285">
   <w.rf>
    <LM>w#w-284-285</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1272-4">
   <w.rf>
    <LM>w#w-d1t1272-4</LM>
   </w.rf>
   <form>spokojené</form>
   <lemma>spokojený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m115-284-287">
   <w.rf>
    <LM>w#w-284-287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-289">
  <m id="m115-d1t1276-1">
   <w.rf>
    <LM>w#w-d1t1276-1</LM>
   </w.rf>
   <form>Dodržujeme</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-289-101">
   <w.rf>
    <LM>w#w-289-101</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1276-2">
   <w.rf>
    <LM>w#w-d1t1276-2</LM>
   </w.rf>
   <form>dosud</form>
   <lemma>dosud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-289-290">
   <w.rf>
    <LM>w#w-289-290</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-291">
  <m id="m115-d1t1276-5">
   <w.rf>
    <LM>w#w-d1t1276-5</LM>
   </w.rf>
   <form>Mikuláše</form>
   <lemma>Mikuláš-1_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m115-d1t1276-7">
   <w.rf>
    <LM>w#w-d1t1276-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1276-9">
   <w.rf>
    <LM>w#w-d1t1276-9</LM>
   </w.rf>
   <form>Ježíška</form>
   <lemma>Ježíšek_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m115-d1t1276-11">
   <w.rf>
    <LM>w#w-d1t1276-11</LM>
   </w.rf>
   <form>slavíme</form>
   <lemma>slavit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1276-12">
   <w.rf>
    <LM>w#w-d1t1276-12</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1276-13">
   <w.rf>
    <LM>w#w-d1t1276-13</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m115-d1t1276-14">
   <w.rf>
    <LM>w#w-d1t1276-14</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-291-292">
   <w.rf>
    <LM>w#w-291-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-293">
  <m id="m115-d1t1278-3">
   <w.rf>
    <LM>w#w-d1t1278-3</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1278-4">
   <w.rf>
    <LM>w#w-d1t1278-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m115-d1t1278-2">
   <w.rf>
    <LM>w#w-d1t1278-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1278-6">
   <w.rf>
    <LM>w#w-d1t1278-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1278-7">
   <w.rf>
    <LM>w#w-d1t1278-7</LM>
   </w.rf>
   <form>osmnáct</form>
   <lemma>osmnáct`18</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m115-d1t1278-8">
   <w.rf>
    <LM>w#w-d1t1278-8</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1278-9">
   <w.rf>
    <LM>w#w-d1t1278-9</LM>
   </w.rf>
   <form>kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m115-d-m-d1e1232-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1232-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1279-x3">
  <m id="m115-d1t1286-1">
   <w.rf>
    <LM>w#w-d1t1286-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m115-d1t1286-2">
   <w.rf>
    <LM>w#w-d1t1286-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1286-3">
   <w.rf>
    <LM>w#w-d1t1286-3</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1t1286-4">
   <w.rf>
    <LM>w#w-d1t1286-4</LM>
   </w.rf>
   <form>jíte</form>
   <lemma>jíst</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m115-d-id136944-punct">
   <w.rf>
    <LM>w#w-d-id136944-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1287-x2">
  <m id="m115-d1t1294-1">
   <w.rf>
    <LM>w#w-d1t1294-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1294-2">
   <w.rf>
    <LM>w#w-d1t1294-2</LM>
   </w.rf>
   <form>vánoce</form>
   <lemma>vánoce_,i_^(^DS**Vánoce)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1t1294-3">
   <w.rf>
    <LM>w#w-d1t1294-3</LM>
   </w.rf>
   <form>jíme</form>
   <lemma>jíst</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1294-4">
   <w.rf>
    <LM>w#w-d1t1294-4</LM>
   </w.rf>
   <form>tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m115-d1t1294-5">
   <w.rf>
    <LM>w#w-d1t1294-5</LM>
   </w.rf>
   <form>jídla</form>
   <lemma>jídlo</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m115-d1e1287-x2-306">
   <w.rf>
    <LM>w#w-d1e1287-x2-306</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-308">
  <m id="m115-d1t1294-9">
   <w.rf>
    <LM>w#w-d1t1294-9</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1294-11">
   <w.rf>
    <LM>w#w-d1t1294-11</LM>
   </w.rf>
   <form>ryby</form>
   <lemma>ryba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1t1294-10">
   <w.rf>
    <LM>w#w-d1t1294-10</LM>
   </w.rf>
   <form>nemilují</form>
   <lemma>milovat</lemma>
   <tag>VB-P---3P-NAI--</tag>
  </m>
  <m id="m115-d-id137188-punct">
   <w.rf>
    <LM>w#w-d-id137188-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1294-13">
   <w.rf>
    <LM>w#w-d1t1294-13</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1294-15">
   <w.rf>
    <LM>w#w-d1t1294-15</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m115-d1t1294-16">
   <w.rf>
    <LM>w#w-d1t1294-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m115-d1t1294-19">
   <w.rf>
    <LM>w#w-d1t1294-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m115-d1t1294-20">
   <w.rf>
    <LM>w#w-d1t1294-20</LM>
   </w.rf>
   <form>nenecháme</form>
   <lemma>nechat</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m115-d1t1294-21">
   <w.rf>
    <LM>w#w-d1t1294-21</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m115-308-309">
   <w.rf>
    <LM>w#w-308-309</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-310">
  <m id="m115-d1t1294-24">
   <w.rf>
    <LM>w#w-d1t1294-24</LM>
   </w.rf>
   <form>Máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1294-25">
   <w.rf>
    <LM>w#w-d1t1294-25</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1294-26">
   <w.rf>
    <LM>w#w-d1t1294-26</LM>
   </w.rf>
   <form>rozdělené</form>
   <lemma>rozdělený_^(*3it)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m115-310-311">
   <w.rf>
    <LM>w#w-310-311</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-313">
  <m id="m115-d1t1296-2">
   <w.rf>
    <LM>w#w-d1t1296-2</LM>
   </w.rf>
   <form>Sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1296-3">
   <w.rf>
    <LM>w#w-d1t1296-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1296-5">
   <w.rf>
    <LM>w#w-d1t1296-5</LM>
   </w.rf>
   <form>rybí</form>
   <lemma>rybí</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m115-d1t1296-4">
   <w.rf>
    <LM>w#w-d1t1296-4</LM>
   </w.rf>
   <form>polévku</form>
   <lemma>polévka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m115-313-314">
   <w.rf>
    <LM>w#w-313-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-317">
  <m id="m115-d1t1298-2">
   <w.rf>
    <LM>w#w-d1t1298-2</LM>
   </w.rf>
   <form>Neteř</form>
   <lemma>neteř</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1298-3">
   <w.rf>
    <LM>w#w-d1t1298-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1298-4">
   <w.rf>
    <LM>w#w-d1t1298-4</LM>
   </w.rf>
   <form>salát</form>
   <lemma>salát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m115-317-318">
   <w.rf>
    <LM>w#w-317-318</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-320">
  <m id="m115-d1t1301-2">
   <w.rf>
    <LM>w#w-d1t1301-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m115-320-321">
   <w.rf>
    <LM>w#w-320-321</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1301-4">
   <w.rf>
    <LM>w#w-d1t1301-4</LM>
   </w.rf>
   <form>holky</form>
   <lemma>holka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1301-5">
   <w.rf>
    <LM>w#w-d1t1301-5</LM>
   </w.rf>
   <form>kupujeme</form>
   <lemma>kupovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-320-322">
   <w.rf>
    <LM>w#w-320-322</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1301-8">
   <w.rf>
    <LM>w#w-d1t1301-8</LM>
   </w.rf>
   <form>obalujeme</form>
   <lemma>obalovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1301-9">
   <w.rf>
    <LM>w#w-d1t1301-9</LM>
   </w.rf>
   <form>kapry</form>
   <lemma>kapr</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m115-320-323">
   <w.rf>
    <LM>w#w-320-323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-324">
  <m id="m115-d1t1305-2">
   <w.rf>
    <LM>w#w-d1t1305-2</LM>
   </w.rf>
   <form>Druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m115-d1t1305-3">
   <w.rf>
    <LM>w#w-d1t1305-3</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1305-5">
   <w.rf>
    <LM>w#w-d1t1305-5</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1305-6">
   <w.rf>
    <LM>w#w-d1t1305-6</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1305-7">
   <w.rf>
    <LM>w#w-d1t1305-7</LM>
   </w.rf>
   <form>řízky</form>
   <lemma>řízek-1</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m115-324-325">
   <w.rf>
    <LM>w#w-324-325</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-326">
  <m id="m115-d1t1305-11">
   <w.rf>
    <LM>w#w-d1t1305-11</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1305-10">
   <w.rf>
    <LM>w#w-d1t1305-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1305-12">
   <w.rf>
    <LM>w#w-d1t1305-12</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d-id137875-punct">
   <w.rf>
    <LM>w#w-d-id137875-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1305-14">
   <w.rf>
    <LM>w#w-d1t1305-14</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1305-15">
   <w.rf>
    <LM>w#w-d1t1305-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m115-d1t1305-16">
   <w.rf>
    <LM>w#w-d1t1305-16</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m115-d1t1305-17">
   <w.rf>
    <LM>w#w-d1t1305-17</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m115-d1t1305-18">
   <w.rf>
    <LM>w#w-d1t1305-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1305-19">
   <w.rf>
    <LM>w#w-d1t1305-19</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m115-326-327">
   <w.rf>
    <LM>w#w-326-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-328">
  <m id="m115-d1t1305-21">
   <w.rf>
    <LM>w#w-d1t1305-21</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d-id138008-punct">
   <w.rf>
    <LM>w#w-d-id138008-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1305-23">
   <w.rf>
    <LM>w#w-d1t1305-23</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1305-24">
   <w.rf>
    <LM>w#w-d1t1305-24</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1305-25">
   <w.rf>
    <LM>w#w-d1t1305-25</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1305-26">
   <w.rf>
    <LM>w#w-d1t1305-26</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1305-27">
   <w.rf>
    <LM>w#w-d1t1305-27</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1t1307-2">
   <w.rf>
    <LM>w#w-d1t1307-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1307-1">
   <w.rf>
    <LM>w#w-d1t1307-1</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m115-d1t1307-3">
   <w.rf>
    <LM>w#w-d1t1307-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1307-6">
   <w.rf>
    <LM>w#w-d1t1307-6</LM>
   </w.rf>
   <form>Zahradním</form>
   <lemma>zahradní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m115-d1t1307-7">
   <w.rf>
    <LM>w#w-d1t1307-7</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m115-d-id138214-punct">
   <w.rf>
    <LM>w#w-d-id138214-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1307-10">
   <w.rf>
    <LM>w#w-d1t1307-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1307-11">
   <w.rf>
    <LM>w#w-d1t1307-11</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1307-17">
   <w.rf>
    <LM>w#w-d1t1307-17</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1307-12">
   <w.rf>
    <LM>w#w-d1t1307-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1307-14">
   <w.rf>
    <LM>w#w-d1t1307-14</LM>
   </w.rf>
   <form>Vánoce</form>
   <lemma>Vánoce_;m</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1t1307-16">
   <w.rf>
    <LM>w#w-d1t1307-16</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1307-18">
   <w.rf>
    <LM>w#w-d1t1307-18</LM>
   </w.rf>
   <form>kapra</form>
   <lemma>kapr</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m115-d1t1307-19">
   <w.rf>
    <LM>w#w-d1t1307-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1307-20">
   <w.rf>
    <LM>w#w-d1t1307-20</LM>
   </w.rf>
   <form>rosolu</form>
   <lemma>rosol-2</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m115-d1t1307-21">
   <w.rf>
    <LM>w#w-d1t1307-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1307-22">
   <w.rf>
    <LM>w#w-d1t1307-22</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m115-d1t1307-25">
   <w.rf>
    <LM>w#w-d1t1307-25</LM>
   </w.rf>
   <form>huspeniny</form>
   <lemma>huspenina</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d1e1287-x3-353">
   <w.rf>
    <LM>w#w-d1e1287-x3-353</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-355">
  <m id="m115-d1t1311-7">
   <w.rf>
    <LM>w#w-d1t1311-7</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m115-d1t1311-8">
   <w.rf>
    <LM>w#w-d1t1311-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m115-d1t1311-5">
   <w.rf>
    <LM>w#w-d1t1311-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1311-6">
   <w.rf>
    <LM>w#w-d1t1311-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1311-9">
   <w.rf>
    <LM>w#w-d1t1311-9</LM>
   </w.rf>
   <form>neděláme</form>
   <lemma>dělat</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m115-355-364">
   <w.rf>
    <LM>w#w-355-364</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-365">
  <m id="m115-d1t1311-13">
   <w.rf>
    <LM>w#w-d1t1311-13</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1311-12">
   <w.rf>
    <LM>w#w-d1t1311-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1311-14">
   <w.rf>
    <LM>w#w-d1t1311-14</LM>
   </w.rf>
   <form>neumíme</form>
   <lemma>umět</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m115-365-366">
   <w.rf>
    <LM>w#w-365-366</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-367">
  <m id="m115-d1t1311-16">
   <w.rf>
    <LM>w#w-d1t1311-16</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1311-17">
   <w.rf>
    <LM>w#w-d1t1311-17</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1311-18">
   <w.rf>
    <LM>w#w-d1t1311-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1311-19">
   <w.rf>
    <LM>w#w-d1t1311-19</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d-id138748-punct">
   <w.rf>
    <LM>w#w-d-id138748-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1311-21">
   <w.rf>
    <LM>w#w-d1t1311-21</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1311-22">
   <w.rf>
    <LM>w#w-d1t1311-22</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1311-23">
   <w.rf>
    <LM>w#w-d1t1311-23</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m115-d1t1311-24">
   <w.rf>
    <LM>w#w-d1t1311-24</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m115-d1t1311-25">
   <w.rf>
    <LM>w#w-d1t1311-25</LM>
   </w.rf>
   <form>dobré</form>
   <lemma>dobrý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m115-367-368">
   <w.rf>
    <LM>w#w-367-368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-369">
  <m id="m115-d1t1314-2">
   <w.rf>
    <LM>w#w-d1t1314-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1314-3">
   <w.rf>
    <LM>w#w-d1t1314-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1314-4">
   <w.rf>
    <LM>w#w-d1t1314-4</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1314-6">
   <w.rf>
    <LM>w#w-d1t1314-6</LM>
   </w.rf>
   <form>tradiční</form>
   <lemma>tradiční</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m115-d1t1314-7">
   <w.rf>
    <LM>w#w-d1t1314-7</LM>
   </w.rf>
   <form>rajské</form>
   <lemma>rajský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m115-d1t1314-8">
   <w.rf>
    <LM>w#w-d1t1314-8</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m115-369-370">
   <w.rf>
    <LM>w#w-369-370</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-371">
  <m id="m115-d1t1314-10">
   <w.rf>
    <LM>w#w-d1t1314-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1314-11">
   <w.rf>
    <LM>w#w-d1t1314-11</LM>
   </w.rf>
   <form>uměla</form>
   <lemma>umět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1314-12">
   <w.rf>
    <LM>w#w-d1t1314-12</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-371-372">
   <w.rf>
    <LM>w#w-371-372</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-381">
  <m id="m115-d1t1314-17">
   <w.rf>
    <LM>w#w-d1t1314-17</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1314-15">
   <w.rf>
    <LM>w#w-d1t1314-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1314-16">
   <w.rf>
    <LM>w#w-d1t1314-16</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m115-d1t1314-18">
   <w.rf>
    <LM>w#w-d1t1314-18</LM>
   </w.rf>
   <form>nenapsala</form>
   <lemma>napsat</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m115-d1t1314-19">
   <w.rf>
    <LM>w#w-d1t1314-19</LM>
   </w.rf>
   <form>recept</form>
   <lemma>recept</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m115-d-id139131-punct">
   <w.rf>
    <LM>w#w-d-id139131-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1314-21">
   <w.rf>
    <LM>w#w-d1t1314-21</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1314-22">
   <w.rf>
    <LM>w#w-d1t1314-22</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1314-23">
   <w.rf>
    <LM>w#w-d1t1314-23</LM>
   </w.rf>
   <form>dělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1314-24">
   <w.rf>
    <LM>w#w-d1t1314-24</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1314-25">
   <w.rf>
    <LM>w#w-d1t1314-25</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m115-d1t1314-26">
   <w.rf>
    <LM>w#w-d1t1314-26</LM>
   </w.rf>
   <form>napodobeninu</form>
   <lemma>napodobenina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m115-381-393">
   <w.rf>
    <LM>w#w-381-393</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1287-x4">
  <m id="m115-d1t1316-3">
   <w.rf>
    <LM>w#w-d1t1316-3</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m115-d1t1316-4">
   <w.rf>
    <LM>w#w-d1t1316-4</LM>
   </w.rf>
   <form>vynikající</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m115-d1e1287-x4-398">
   <w.rf>
    <LM>w#w-d1e1287-x4-398</LM>
   </w.rf>
   <form>majstrštyk</form>
   <lemma>majstrštyk_,a</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m115-d1t1320-1">
   <w.rf>
    <LM>w#w-d1t1320-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m115-d1t1320-2">
   <w.rf>
    <LM>w#w-d1t1320-2</LM>
   </w.rf>
   <form>citronový</form>
   <lemma>citronový_,s_^(^DD**citrónový)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m115-d1t1320-3">
   <w.rf>
    <LM>w#w-d1t1320-3</LM>
   </w.rf>
   <form>pudink</form>
   <lemma>pudink</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m115-d1e1287-x4-399">
   <w.rf>
    <LM>w#w-d1e1287-x4-399</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-400">
  <m id="m115-d1t1320-6">
   <w.rf>
    <LM>w#w-d1t1320-6</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1320-5">
   <w.rf>
    <LM>w#w-d1t1320-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1320-7">
   <w.rf>
    <LM>w#w-d1t1320-7</LM>
   </w.rf>
   <form>nepřesný</form>
   <lemma>přesný</lemma>
   <tag>AAIS4----1N----</tag>
  </m>
  <m id="m115-d1t1320-8">
   <w.rf>
    <LM>w#w-d1t1320-8</LM>
   </w.rf>
   <form>recept</form>
   <lemma>recept</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m115-400-401">
   <w.rf>
    <LM>w#w-400-401</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-402">
  <m id="m115-d1t1320-15">
   <w.rf>
    <LM>w#w-d1t1320-15</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1320-12">
   <w.rf>
    <LM>w#w-d1t1320-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1320-13">
   <w.rf>
    <LM>w#w-d1t1320-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1320-14">
   <w.rf>
    <LM>w#w-d1t1320-14</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S6--1-------</tag>
  </m>
  <m id="m115-d1t1320-16">
   <w.rf>
    <LM>w#w-d1t1320-16</LM>
   </w.rf>
   <form>vyžadují</form>
   <lemma>vyžadovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m115-402-403">
   <w.rf>
    <LM>w#w-402-403</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1320-17">
   <w.rf>
    <LM>w#w-d1t1320-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1320-18">
   <w.rf>
    <LM>w#w-d1t1320-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1320-19">
   <w.rf>
    <LM>w#w-d1t1320-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m115-d1t1320-20">
   <w.rf>
    <LM>w#w-d1t1320-20</LM>
   </w.rf>
   <form>snažím</form>
   <lemma>snažit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1320-21">
   <w.rf>
    <LM>w#w-d1t1320-21</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m115-402-1038">
   <w.rf>
    <LM>w#w-402-1038</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-1039">
  <m id="m115-d1t1320-23">
   <w.rf>
    <LM>w#w-d1t1320-23</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1320-24">
   <w.rf>
    <LM>w#w-d1t1320-24</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1320-25">
   <w.rf>
    <LM>w#w-d1t1320-25</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1320-26">
   <w.rf>
    <LM>w#w-d1t1320-26</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1320-27">
   <w.rf>
    <LM>w#w-d1t1320-27</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m115-d1t1320-28">
   <w.rf>
    <LM>w#w-d1t1320-28</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1320-29">
   <w.rf>
    <LM>w#w-d1t1320-29</LM>
   </w.rf>
   <form>vynikající</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGNS1-----A----</tag>
  </m>
  <m id="m115-402-222">
   <w.rf>
    <LM>w#w-402-222</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1320-30">
   <w.rf>
    <LM>w#w-d1t1320-30</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1320-31">
   <w.rf>
    <LM>w#w-d1t1320-31</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1320-32">
   <w.rf>
    <LM>w#w-d1t1320-32</LM>
   </w.rf>
   <form>bývalo</form>
   <lemma>bývat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m115-d1t1320-33">
   <w.rf>
    <LM>w#w-d1t1320-33</LM>
   </w.rf>
   <form>dřív</form>
   <lemma>dříve</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m115-d-m-d1e1287-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1287-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1323-x2">
  <m id="m115-d1t1326-1">
   <w.rf>
    <LM>w#w-d1t1326-1</LM>
   </w.rf>
   <form>Dodržujete</form>
   <lemma>dodržovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m115-d1t1326-2">
   <w.rf>
    <LM>w#w-d1t1326-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m115-d1t1326-3">
   <w.rf>
    <LM>w#w-d1t1326-3</LM>
   </w.rf>
   <form>vánoční</form>
   <lemma>vánoční</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m115-d1t1326-4">
   <w.rf>
    <LM>w#w-d1t1326-4</LM>
   </w.rf>
   <form>zvyky</form>
   <lemma>zvyk</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m115-d-id139959-punct">
   <w.rf>
    <LM>w#w-d-id139959-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1327-x2">
  <m id="m115-d1t1334-2">
   <w.rf>
    <LM>w#w-d1t1334-2</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1334-3">
   <w.rf>
    <LM>w#w-d1t1334-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1334-5">
   <w.rf>
    <LM>w#w-d1t1334-5</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1334-6">
   <w.rf>
    <LM>w#w-d1t1334-6</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1e1327-x2-415">
   <w.rf>
    <LM>w#w-d1e1327-x2-415</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-418">
  <m id="m115-d1t1334-9">
   <w.rf>
    <LM>w#w-d1t1334-9</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-d1t1334-10">
   <w.rf>
    <LM>w#w-d1t1334-10</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1334-11">
   <w.rf>
    <LM>w#w-d1t1334-11</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1334-12">
   <w.rf>
    <LM>w#w-d1t1334-12</LM>
   </w.rf>
   <form>moderní</form>
   <lemma>moderní</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m115-418-419">
   <w.rf>
    <LM>w#w-418-419</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-425">
  <m id="m115-d1t1334-19">
   <w.rf>
    <LM>w#w-d1t1334-19</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1334-21">
   <w.rf>
    <LM>w#w-d1t1334-21</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1334-22">
   <w.rf>
    <LM>w#w-d1t1334-22</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1334-23">
   <w.rf>
    <LM>w#w-d1t1334-23</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1334-24">
   <w.rf>
    <LM>w#w-d1t1334-24</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-425-426">
   <w.rf>
    <LM>w#w-425-426</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1334-26">
   <w.rf>
    <LM>w#w-d1t1334-26</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1334-27">
   <w.rf>
    <LM>w#w-d1t1334-27</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1334-28">
   <w.rf>
    <LM>w#w-d1t1334-28</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1334-30">
   <w.rf>
    <LM>w#w-d1t1334-30</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFP4----2A----</tag>
  </m>
  <m id="m115-d1t1334-31">
   <w.rf>
    <LM>w#w-d1t1334-31</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-425-427">
   <w.rf>
    <LM>w#w-425-427</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-425-428">
   <w.rf>
    <LM>w#w-425-428</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1334-17">
   <w.rf>
    <LM>w#w-d1t1334-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-425-429">
   <w.rf>
    <LM>w#w-425-429</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m115-d1t1334-18">
   <w.rf>
    <LM>w#w-d1t1334-18</LM>
   </w.rf>
   <form>dodržovali</form>
   <lemma>dodržovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-425-430">
   <w.rf>
    <LM>w#w-425-430</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-432">
  <m id="m115-d1t1336-4">
   <w.rf>
    <LM>w#w-d1t1336-4</LM>
   </w.rf>
   <form>Zpívaly</form>
   <lemma>zpívat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1336-3">
   <w.rf>
    <LM>w#w-d1t1336-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1336-6">
   <w.rf>
    <LM>w#w-d1t1336-6</LM>
   </w.rf>
   <form>koledy</form>
   <lemma>koleda</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-432-433">
   <w.rf>
    <LM>w#w-432-433</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1336-9">
   <w.rf>
    <LM>w#w-d1t1336-9</LM>
   </w.rf>
   <form>házelo</form>
   <lemma>házet</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m115-d1t1336-10">
   <w.rf>
    <LM>w#w-d1t1336-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1336-11">
   <w.rf>
    <LM>w#w-d1t1336-11</LM>
   </w.rf>
   <form>střevícem</form>
   <lemma>střevíc</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m115-432-434">
   <w.rf>
    <LM>w#w-432-434</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1336-13">
   <w.rf>
    <LM>w#w-d1t1336-13</LM>
   </w.rf>
   <form>lilo</form>
   <lemma>lít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m115-d1t1336-14">
   <w.rf>
    <LM>w#w-d1t1336-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1336-15">
   <w.rf>
    <LM>w#w-d1t1336-15</LM>
   </w.rf>
   <form>olovo</form>
   <lemma>olovo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m115-d1t1338-1">
   <w.rf>
    <LM>w#w-d1t1338-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1338-6">
   <w.rf>
    <LM>w#w-d1t1338-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1338-8">
   <w.rf>
    <LM>w#w-d1t1338-8</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Mikuláše</form>
   <lemma>Mikuláš-1_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m115-d1t1338-3">
   <w.rf>
    <LM>w#w-d1t1338-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1338-10">
   <w.rf>
    <LM>w#w-d1t1338-10</LM>
   </w.rf>
   <form>dávaly</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1338-11">
   <w.rf>
    <LM>w#w-d1t1338-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m115-d1t1338-12">
   <w.rf>
    <LM>w#w-d1t1338-12</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m115-d1t1338-4">
   <w.rf>
    <LM>w#w-d1t1338-4</LM>
   </w.rf>
   <form>třešňové</form>
   <lemma>třešňový</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m115-d1t1338-5">
   <w.rf>
    <LM>w#w-d1t1338-5</LM>
   </w.rf>
   <form>větvičky</form>
   <lemma>větvička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m115-432-436">
   <w.rf>
    <LM>w#w-432-436</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-438">
  <m id="m115-d1t1338-16">
   <w.rf>
    <LM>w#w-d1t1338-16</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1338-17">
   <w.rf>
    <LM>w#w-d1t1338-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1338-18">
   <w.rf>
    <LM>w#w-d1t1338-18</LM>
   </w.rf>
   <form>dodržovalo</form>
   <lemma>dodržovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m115-438-439">
   <w.rf>
    <LM>w#w-438-439</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-440">
  <m id="m115-d1t1338-22">
   <w.rf>
    <LM>w#w-d1t1338-22</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1338-23">
   <w.rf>
    <LM>w#w-d1t1338-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m115-d1t1338-24">
   <w.rf>
    <LM>w#w-d1t1338-24</LM>
   </w.rf>
   <form>dodržovali</form>
   <lemma>dodržovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1338-28">
   <w.rf>
    <LM>w#w-d1t1338-28</LM>
   </w.rf>
   <form>půst</form>
   <lemma>půst</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m115-d-id141146-punct">
   <w.rf>
    <LM>w#w-d-id141146-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1338-30">
   <w.rf>
    <LM>w#w-d1t1338-30</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m115-d1t1338-31">
   <w.rf>
    <LM>w#w-d1t1338-31</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1338-32">
   <w.rf>
    <LM>w#w-d1t1338-32</LM>
   </w.rf>
   <form>zlaté</form>
   <lemma>zlatý-1_^(atribut;_z._řetízek,_poklad,...)</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m115-d1t1338-33">
   <w.rf>
    <LM>w#w-d1t1338-33</LM>
   </w.rf>
   <form>prasátko</form>
   <lemma>prasátko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m115-d1e1327-x3-454">
   <w.rf>
    <LM>w#w-d1e1327-x3-454</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-455">
  <m id="m115-d1t1338-36">
   <w.rf>
    <LM>w#w-d1t1338-36</LM>
   </w.rf>
   <form>Teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1338-38">
   <w.rf>
    <LM>w#w-d1t1338-38</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1338-35">
   <w.rf>
    <LM>w#w-d1t1338-35</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1338-40">
   <w.rf>
    <LM>w#w-d1t1338-40</LM>
   </w.rf>
   <form>doba</form>
   <lemma>doba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1338-42">
   <w.rf>
    <LM>w#w-d1t1338-42</LM>
   </w.rf>
   <form>uspěchaná</form>
   <lemma>uspěchaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m115-d1t1341-5">
   <w.rf>
    <LM>w#w-d1t1341-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1341-6">
   <w.rf>
    <LM>w#w-d1t1341-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1341-7">
   <w.rf>
    <LM>w#w-d1t1341-7</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m115-d1t1341-8">
   <w.rf>
    <LM>w#w-d1t1341-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1341-9">
   <w.rf>
    <LM>w#w-d1t1341-9</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-455-461">
   <w.rf>
    <LM>w#w-455-461</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1341-13">
   <w.rf>
    <LM>w#w-d1t1341-13</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1341-14">
   <w.rf>
    <LM>w#w-d1t1341-14</LM>
   </w.rf>
   <form>generací</form>
   <lemma>generace</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m115-455-462">
   <w.rf>
    <LM>w#w-455-462</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1341-16">
   <w.rf>
    <LM>w#w-d1t1341-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1341-18">
   <w.rf>
    <LM>w#w-d1t1341-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1341-20">
   <w.rf>
    <LM>w#w-d1t1341-20</LM>
   </w.rf>
   <form>zvyky</form>
   <lemma>zvyk</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m115-d1t1341-21">
   <w.rf>
    <LM>w#w-d1t1341-21</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1341-22">
   <w.rf>
    <LM>w#w-d1t1341-22</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m115-d1t1341-23">
   <w.rf>
    <LM>w#w-d1t1341-23</LM>
   </w.rf>
   <form>nezbývá</form>
   <lemma>zbývat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m115-d1t1341-24">
   <w.rf>
    <LM>w#w-d1t1341-24</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m115-d-m-d1e1327-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1327-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1342-x2">
  <m id="m115-d1t1345-1">
   <w.rf>
    <LM>w#w-d1t1345-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m115-d-m-d1e1342-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1342-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1352-x2">
  <m id="m115-d1t1357-1">
   <w.rf>
    <LM>w#w-d1t1357-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m115-d1t1357-2">
   <w.rf>
    <LM>w#w-d1t1357-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1357-3">
   <w.rf>
    <LM>w#w-d1t1357-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1357-4">
   <w.rf>
    <LM>w#w-d1t1357-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m115-d1t1357-5">
   <w.rf>
    <LM>w#w-d1t1357-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m115-d-id141996-punct">
   <w.rf>
    <LM>w#w-d-id141996-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1364-x2">
  <m id="m115-d1t1369-3">
   <w.rf>
    <LM>w#w-d1t1369-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1369-4">
   <w.rf>
    <LM>w#w-d1t1369-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1369-5">
   <w.rf>
    <LM>w#w-d1t1369-5</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1369-6">
   <w.rf>
    <LM>w#w-d1t1369-6</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m115-d1t1369-7">
   <w.rf>
    <LM>w#w-d1t1369-7</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS2----2A----</tag>
  </m>
  <m id="m115-d1t1369-8">
   <w.rf>
    <LM>w#w-d1t1369-8</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m115-d1e1364-x2-473">
   <w.rf>
    <LM>w#w-d1e1364-x2-473</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-475">
  <m id="m115-d1t1369-17">
   <w.rf>
    <LM>w#w-d1t1369-17</LM>
   </w.rf>
   <form>Vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1369-16">
   <w.rf>
    <LM>w#w-d1t1369-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1369-18">
   <w.rf>
    <LM>w#w-d1t1369-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1369-19">
   <w.rf>
    <LM>w#w-d1t1369-19</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m115-d1t1369-20">
   <w.rf>
    <LM>w#w-d1t1369-20</LM>
   </w.rf>
   <form>1989</form>
   <lemma>1989</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m115-475-476">
   <w.rf>
    <LM>w#w-475-476</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1371-6">
   <w.rf>
    <LM>w#w-d1t1371-6</LM>
   </w.rf>
   <form>těsně</form>
   <lemma>těsně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m115-d1t1371-7">
   <w.rf>
    <LM>w#w-d1t1371-7</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m115-d1t1373-3">
   <w.rf>
    <LM>w#w-d1t1373-3</LM>
   </w.rf>
   <form>sametovou</form>
   <lemma>sametový</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m115-d1t1373-2">
   <w.rf>
    <LM>w#w-d1t1373-2</LM>
   </w.rf>
   <form>revolucí</form>
   <lemma>revoluce</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m115-d1t1373-5">
   <w.rf>
    <LM>w#w-d1t1373-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1373-6">
   <w.rf>
    <LM>w#w-d1t1373-6</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m115-d1t1373-7">
   <w.rf>
    <LM>w#w-d1t1373-7</LM>
   </w.rf>
   <form>narodilo</form>
   <lemma>narodit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m115-d1t1373-8">
   <w.rf>
    <LM>w#w-d1t1373-8</LM>
   </w.rf>
   <form>děťátko</form>
   <lemma>děťátko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m115-475-480">
   <w.rf>
    <LM>w#w-475-480</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-482">
  <m id="m115-d1t1373-10">
   <w.rf>
    <LM>w#w-d1t1373-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1373-11">
   <w.rf>
    <LM>w#w-d1t1373-11</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-482-483">
   <w.rf>
    <LM>w#w-482-483</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1373-12">
   <w.rf>
    <LM>w#w-d1t1373-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1373-13">
   <w.rf>
    <LM>w#w-d1t1373-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1373-14">
   <w.rf>
    <LM>w#w-d1t1373-14</LM>
   </w.rf>
   <form>vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1373-15">
   <w.rf>
    <LM>w#w-d1t1373-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1373-17">
   <w.rf>
    <LM>w#w-d1t1373-17</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m115-d1t1373-18">
   <w.rf>
    <LM>w#w-d1t1373-18</LM>
   </w.rf>
   <form>1989</form>
   <lemma>1989</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m115-482-484">
   <w.rf>
    <LM>w#w-482-484</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-486">
  <m id="m115-d1t1375-2">
   <w.rf>
    <LM>w#w-d1t1375-2</LM>
   </w.rf>
   <form>Všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP4----------</tag>
  </m>
  <m id="m115-d1t1375-4">
   <w.rf>
    <LM>w#w-d1t1375-4</LM>
   </w.rf>
   <form>výhody</form>
   <lemma>výhoda</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m115-d-id142879-punct">
   <w.rf>
    <LM>w#w-d-id142879-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1375-6">
   <w.rf>
    <LM>w#w-d1t1375-6</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m115-d1t1375-13">
   <w.rf>
    <LM>w#w-d1t1375-13</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1375-8">
   <w.rf>
    <LM>w#w-d1t1375-8</LM>
   </w.rf>
   <form>požívali</form>
   <lemma>požívat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1375-10">
   <w.rf>
    <LM>w#w-d1t1375-10</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m115-d1t1375-11">
   <w.rf>
    <LM>w#w-d1t1375-11</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m115-d-id142981-punct">
   <w.rf>
    <LM>w#w-d-id142981-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1375-14">
   <w.rf>
    <LM>w#w-d1t1375-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1375-15">
   <w.rf>
    <LM>w#w-d1t1375-15</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1375-16">
   <w.rf>
    <LM>w#w-d1t1375-16</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m115-d1t1375-17">
   <w.rf>
    <LM>w#w-d1t1375-17</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m115-d1t1375-18">
   <w.rf>
    <LM>w#w-d1t1375-18</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m115-d-id143083-punct">
   <w.rf>
    <LM>w#w-d-id143083-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1375-20">
   <w.rf>
    <LM>w#w-d1t1375-20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1375-21">
   <w.rf>
    <LM>w#w-d1t1375-21</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m115-d1t1375-22">
   <w.rf>
    <LM>w#w-d1t1375-22</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m115-d1t1375-23">
   <w.rf>
    <LM>w#w-d1t1375-23</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m115-d1t1375-24">
   <w.rf>
    <LM>w#w-d1t1375-24</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m115-486-487">
   <w.rf>
    <LM>w#w-486-487</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m115-d1t1375-28">
   <w.rf>
    <LM>w#w-d1t1375-28</LM>
   </w.rf>
   <form>zmeškala</form>
   <lemma>zmeškat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m115-486-1078">
   <w.rf>
    <LM>w#w-486-1078</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-1080">
  <m id="m115-d1t1375-32">
   <w.rf>
    <LM>w#w-d1t1375-32</LM>
   </w.rf>
   <form>Musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1375-31">
   <w.rf>
    <LM>w#w-d1t1375-31</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m115-d1t1375-33">
   <w.rf>
    <LM>w#w-d1t1375-33</LM>
   </w.rf>
   <form>starat</form>
   <lemma>starat_^(se)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m115-d1t1375-34">
   <w.rf>
    <LM>w#w-d1t1375-34</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m115-d1t1375-35">
   <w.rf>
    <LM>w#w-d1t1375-35</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m115-d1e1364-x3-499">
   <w.rf>
    <LM>w#w-d1e1364-x3-499</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-500">
  <m id="m115-d1t1375-39">
   <w.rf>
    <LM>w#w-d1t1375-39</LM>
   </w.rf>
   <form>Stihla</form>
   <lemma>stihnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m115-d1t1375-38">
   <w.rf>
    <LM>w#w-d1t1375-38</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m115-d1t1375-40">
   <w.rf>
    <LM>w#w-d1t1375-40</LM>
   </w.rf>
   <form>udělat</form>
   <lemma>udělat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m115-d1t1375-37">
   <w.rf>
    <LM>w#w-d1t1375-37</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d1t1375-41">
   <w.rf>
    <LM>w#w-d1t1375-41</LM>
   </w.rf>
   <form>doktorát</form>
   <lemma>doktorát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m115-500-503">
   <w.rf>
    <LM>w#w-500-503</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-505">
  <m id="m115-d1t1375-48">
   <w.rf>
    <LM>w#w-d1t1375-48</LM>
   </w.rf>
   <form>Ježdění</form>
   <lemma>ježdění</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m115-d1t1375-49">
   <w.rf>
    <LM>w#w-d1t1375-49</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m115-d1t1375-50">
   <w.rf>
    <LM>w#w-d1t1375-50</LM>
   </w.rf>
   <form>světa</form>
   <lemma>svět</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m115-d1t1375-53">
   <w.rf>
    <LM>w#w-d1t1375-53</LM>
   </w.rf>
   <form>nestihla</form>
   <lemma>stihnout</lemma>
   <tag>VpQW----R-NAP-1</tag>
  </m>
  <m id="m115-d-m-d1e1364-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1364-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1376-x3">
  <m id="m115-d1t1383-1">
   <w.rf>
    <LM>w#w-d1t1383-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m115-d1t1383-2">
   <w.rf>
    <LM>w#w-d1t1383-2</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m115-d1t1383-3">
   <w.rf>
    <LM>w#w-d1t1383-3</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m115-d1t1383-4">
   <w.rf>
    <LM>w#w-d1t1383-4</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1383-5">
   <w.rf>
    <LM>w#w-d1t1383-5</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m115-d-id143803-punct">
   <w.rf>
    <LM>w#w-d-id143803-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-d1e1385-x2">
  <m id="m115-d1t1390-1">
   <w.rf>
    <LM>w#w-d1t1390-1</LM>
   </w.rf>
   <form>Moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m115-d1t1390-2">
   <w.rf>
    <LM>w#w-d1t1390-2</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1390-3">
   <w.rf>
    <LM>w#w-d1t1390-3</LM>
   </w.rf>
   <form>vystudovala</form>
   <lemma>vystudovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m115-d1t1392-1">
   <w.rf>
    <LM>w#w-d1t1392-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m115-d1t1392-3">
   <w.rf>
    <LM>w#w-d1t1392-3</LM>
   </w.rf>
   <form>Filozofické</form>
   <lemma>filozofický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m115-d1t1392-4">
   <w.rf>
    <LM>w#w-d1t1392-4</LM>
   </w.rf>
   <form>fakultě</form>
   <lemma>fakulta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m115-d1t1392-6">
   <w.rf>
    <LM>w#w-d1t1392-6</LM>
   </w.rf>
   <form>katedru</form>
   <lemma>katedra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m115-d1t1392-7">
   <w.rf>
    <LM>w#w-d1t1392-7</LM>
   </w.rf>
   <form>informatiky</form>
   <lemma>informatika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m115-d1e1385-x2-520">
   <w.rf>
    <LM>w#w-d1e1385-x2-520</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-521">
  <m id="m115-d1t1392-10">
   <w.rf>
    <LM>w#w-d1t1392-10</LM>
   </w.rf>
   <form>Pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m115-d1t1392-11">
   <w.rf>
    <LM>w#w-d1t1392-11</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m115-d1t1392-15">
   <w.rf>
    <LM>w#w-d1t1392-15</LM>
   </w.rf>
   <form>knihovnice</form>
   <lemma>knihovnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-d1t1392-16">
   <w.rf>
    <LM>w#w-d1t1392-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m115-d1t1392-17">
   <w.rf>
    <LM>w#w-d1t1392-17</LM>
   </w.rf>
   <form>informační</form>
   <lemma>informační</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m115-d1t1392-18">
   <w.rf>
    <LM>w#w-d1t1392-18</LM>
   </w.rf>
   <form>pracovnice</form>
   <lemma>pracovnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m115-521-538">
   <w.rf>
    <LM>w#w-521-538</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m115-537">
  <m id="m115-d1t1392-21">
   <w.rf>
    <LM>w#w-d1t1392-21</LM>
   </w.rf>
   <form>Takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m115-d1t1392-22">
   <w.rf>
    <LM>w#w-d1t1392-22</LM>
   </w.rf>
   <form>dědičné</form>
   <lemma>dědičný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m115-537-540">
   <w.rf>
    <LM>w#w-537-540</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m115-537-541">
   <w.rf>
    <LM>w#w-537-541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
