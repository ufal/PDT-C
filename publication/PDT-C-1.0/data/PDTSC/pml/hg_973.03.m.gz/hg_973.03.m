<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_973.03.w.gz" />
  </references>
 </head>
 <s id="m973-26797_03-11391">
  <m id="m973-id62407-7">
   <w.rf>
    <LM>w#w-id62407-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62407-8">
   <w.rf>
    <LM>w#w-id62407-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id62407-9">
   <w.rf>
    <LM>w#w-id62407-9</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m973-id62407-10">
   <w.rf>
    <LM>w#w-id62407-10</LM>
   </w.rf>
   <form>krutost</form>
   <lemma>krutost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-11391-314">
   <w.rf>
    <LM>w#w-11391-314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-315">
  <m id="m973-id62417-1">
   <w.rf>
    <LM>w#w-id62417-1</LM>
   </w.rf>
   <form>Druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m973-id62417-2">
   <w.rf>
    <LM>w#w-id62417-2</LM>
   </w.rf>
   <form>krutost</form>
   <lemma>krutost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62417-3">
   <w.rf>
    <LM>w#w-id62417-3</LM>
   </w.rf>
   <form>spočívala</form>
   <lemma>spočívat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62417-4">
   <w.rf>
    <LM>w#w-id62417-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62417-5">
   <w.rf>
    <LM>w#w-id62417-5</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m973-d-id92524">
   <w.rf>
    <LM>w#w-d-id92524</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62426-1">
   <w.rf>
    <LM>w#w-id62426-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62426-3">
   <w.rf>
    <LM>w#w-id62426-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62426-4">
   <w.rf>
    <LM>w#w-id62426-4</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62426-6">
   <w.rf>
    <LM>w#w-id62426-6</LM>
   </w.rf>
   <form>pozvánku</form>
   <lemma>pozvánka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-11391-11417">
   <w.rf>
    <LM>w#w-11391-11417</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62426-7">
   <w.rf>
    <LM>w#w-id62426-7</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m973-id62426-8">
   <w.rf>
    <LM>w#w-id62426-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id62426-9">
   <w.rf>
    <LM>w#w-id62426-9</LM>
   </w.rf>
   <form>dostavil</form>
   <lemma>dostavit_^(se,na_dané_místo)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62426-10">
   <w.rf>
    <LM>w#w-id62426-10</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62426-11">
   <w.rf>
    <LM>w#w-id62426-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62426-12">
   <w.rf>
    <LM>w#w-id62426-12</LM>
   </w.rf>
   <form>milici</form>
   <lemma>milice</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-d-id92708">
   <w.rf>
    <LM>w#w-d-id92708</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x4">
  <m id="m973-id62450-1">
   <w.rf>
    <LM>w#w-id62450-1</LM>
   </w.rf>
   <form>Přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62450-2">
   <w.rf>
    <LM>w#w-id62450-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62450-3">
   <w.rf>
    <LM>w#w-id62450-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62265-x4-322">
   <w.rf>
    <LM>w#w-id62265-x4-322</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-323">
  <m id="m973-id62460-2">
   <w.rf>
    <LM>w#w-id62460-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id62460-3">
   <w.rf>
    <LM>w#w-id62460-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62460-6">
   <w.rf>
    <LM>w#w-id62460-6</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m973-id62460-7">
   <w.rf>
    <LM>w#w-id62460-7</LM>
   </w.rf>
   <form>sál</form>
   <lemma>sál</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id62265-x4-11818">
   <w.rf>
    <LM>w#w-id62265-x4-11818</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62470-1">
   <w.rf>
    <LM>w#w-id62470-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62479-1">
   <w.rf>
    <LM>w#w-id62479-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62479-2">
   <w.rf>
    <LM>w#w-id62479-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m973-id62479-3">
   <w.rf>
    <LM>w#w-id62479-3</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id62470-3">
   <w.rf>
    <LM>w#w-id62470-3</LM>
   </w.rf>
   <form>posadili</form>
   <lemma>posadit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id62479-4">
   <w.rf>
    <LM>w#w-id62479-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62479-5">
   <w.rf>
    <LM>w#w-id62479-5</LM>
   </w.rf>
   <form>lavice</form>
   <lemma>lavice</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-id62489-1">
   <w.rf>
    <LM>w#w-id62489-1</LM>
   </w.rf>
   <form>jednotlivé</form>
   <lemma>jednotlivý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m973-id62489-3">
   <w.rf>
    <LM>w#w-id62489-3</LM>
   </w.rf>
   <form>pozvané</form>
   <lemma>pozvaný_^(*2t)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m973-d-id93112">
   <w.rf>
    <LM>w#w-d-id93112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62489-4">
   <w.rf>
    <LM>w#w-id62489-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62489-5">
   <w.rf>
    <LM>w#w-id62489-5</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id62489-6">
   <w.rf>
    <LM>w#w-id62489-6</LM>
   </w.rf>
   <form>samí</form>
   <lemma>samý</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m973-id62489-7">
   <w.rf>
    <LM>w#w-id62489-7</LM>
   </w.rf>
   <form>emigranti</form>
   <lemma>emigrant</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m973-323-326">
   <w.rf>
    <LM>w#w-323-326</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62489-8">
   <w.rf>
    <LM>w#w-id62489-8</LM>
   </w.rf>
   <form>upozorňuju</form>
   <lemma>upozorňovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-323-324">
   <w.rf>
    <LM>w#w-323-324</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-325">
  <m id="m973-id62517-1">
   <w.rf>
    <LM>w#w-id62517-1</LM>
   </w.rf>
   <form>Dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id62517-2">
   <w.rf>
    <LM>w#w-id62517-2</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m973-id62517-4">
   <w.rf>
    <LM>w#w-id62517-4</LM>
   </w.rf>
   <form>třístránkový</form>
   <lemma>třístránkový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m973-id62517-5">
   <w.rf>
    <LM>w#w-id62517-5</LM>
   </w.rf>
   <form>dotazník</form>
   <lemma>dotazník</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id62265-x4-11823">
   <w.rf>
    <LM>w#w-id62265-x4-11823</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62517-7">
   <w.rf>
    <LM>w#w-id62517-7</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62517-8">
   <w.rf>
    <LM>w#w-id62517-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62517-9">
   <w.rf>
    <LM>w#w-id62517-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id62517-10">
   <w.rf>
    <LM>w#w-id62517-10</LM>
   </w.rf>
   <form>uměli</form>
   <lemma>umět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id62517-12">
   <w.rf>
    <LM>w#w-id62517-12</LM>
   </w.rf>
   <form>rusky</form>
   <lemma>rusky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id62265-x4-11825">
   <w.rf>
    <LM>w#w-id62265-x4-11825</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62517-13">
   <w.rf>
    <LM>w#w-id62517-13</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62517-14">
   <w.rf>
    <LM>w#w-id62517-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id62517-15">
   <w.rf>
    <LM>w#w-id62517-15</LM>
   </w.rf>
   <form>rozuměli</form>
   <lemma>rozumět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-325-327">
   <w.rf>
    <LM>w#w-325-327</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-328">
  <m id="m973-id62528-2">
   <w.rf>
    <LM>w#w-id62528-2</LM>
   </w.rf>
   <form>Řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id62265-x4-11828">
   <w.rf>
    <LM>w#w-id62265-x4-11828</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x4-11829">
   <w.rf>
    <LM>w#w-id62265-x4-11829</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62528-5">
   <w.rf>
    <LM>w#w-id62528-5</LM>
   </w.rf>
   <form>Budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m973-id62528-8">
   <w.rf>
    <LM>w#w-id62528-8</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m973-id62528-6">
   <w.rf>
    <LM>w#w-id62528-6</LM>
   </w.rf>
   <form>psát</form>
   <lemma>psát</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-d-id93644">
   <w.rf>
    <LM>w#w-d-id93644</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x4-11831">
   <w.rf>
    <LM>w#w-id62265-x4-11831</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x5">
  <m id="m973-id62543-1">
   <w.rf>
    <LM>w#w-id62543-1</LM>
   </w.rf>
   <form>Až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62543-2">
   <w.rf>
    <LM>w#w-id62543-2</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m973-id62543-3">
   <w.rf>
    <LM>w#w-id62543-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62543-4">
   <w.rf>
    <LM>w#w-id62543-4</LM>
   </w.rf>
   <form>pochopil</form>
   <lemma>pochopit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-d-id93739">
   <w.rf>
    <LM>w#w-d-id93739</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62543-5">
   <w.rf>
    <LM>w#w-id62543-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62543-6">
   <w.rf>
    <LM>w#w-id62543-6</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m973-id62543-8">
   <w.rf>
    <LM>w#w-id62543-8</LM>
   </w.rf>
   <form>dotazník</form>
   <lemma>dotazník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id62543-9">
   <w.rf>
    <LM>w#w-id62543-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id62543-10">
   <w.rf>
    <LM>w#w-id62543-10</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62543-11">
   <w.rf>
    <LM>w#w-id62543-11</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62543-14">
   <w.rf>
    <LM>w#w-id62543-14</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m973-id62543-15">
   <w.rf>
    <LM>w#w-id62543-15</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS3----------</tag>
  </m>
  <m id="m973-id62543-16">
   <w.rf>
    <LM>w#w-id62543-16</LM>
   </w.rf>
   <form>větě</form>
   <lemma>věta</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m973-d-id93927">
   <w.rf>
    <LM>w#w-d-id93927</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x6">
  <m id="m973-id62558-3">
   <w.rf>
    <LM>w#w-id62558-3</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62558-2">
   <w.rf>
    <LM>w#w-id62558-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62558-4">
   <w.rf>
    <LM>w#w-id62558-4</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id62558-5">
   <w.rf>
    <LM>w#w-id62558-5</LM>
   </w.rf>
   <form>věta</form>
   <lemma>věta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-d-id94038">
   <w.rf>
    <LM>w#w-d-id94038</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62558-6">
   <w.rf>
    <LM>w#w-id62558-6</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m973-id62558-7">
   <w.rf>
    <LM>w#w-id62558-7</LM>
   </w.rf>
   <form>stála</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62558-8">
   <w.rf>
    <LM>w#w-id62558-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62558-10">
   <w.rf>
    <LM>w#w-id62558-10</LM>
   </w.rf>
   <form>dotazníku</form>
   <lemma>dotazník</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-id62265-x6-339">
   <w.rf>
    <LM>w#w-id62265-x6-339</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-340">
  <m id="m973-id62558-12">
   <w.rf>
    <LM>w#w-id62558-12</LM>
   </w.rf>
   <form>Zněla</form>
   <lemma>znít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62558-13">
   <w.rf>
    <LM>w#w-id62558-13</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62558-14">
   <w.rf>
    <LM>w#w-id62558-14</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62265-x6-13223">
   <w.rf>
    <LM>w#w-id62265-x6-13223</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x6-13224">
   <w.rf>
    <LM>w#w-id62265-x6-13224</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62573-1">
   <w.rf>
    <LM>w#w-id62573-1</LM>
   </w.rf>
   <form>Mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id62573-2">
   <w.rf>
    <LM>w#w-id62573-2</LM>
   </w.rf>
   <form>vládou</form>
   <lemma>vláda</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m973-id62573-3">
   <w.rf>
    <LM>w#w-id62573-3</LM>
   </w.rf>
   <form>Sovětského</form>
   <lemma>sovětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m973-id62573-4">
   <w.rf>
    <LM>w#w-id62573-4</LM>
   </w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id62583-1">
   <w.rf>
    <LM>w#w-id62583-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62583-2">
   <w.rf>
    <LM>w#w-id62583-2</LM>
   </w.rf>
   <form>Německem</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m973-id62583-3">
   <w.rf>
    <LM>w#w-id62583-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62583-4">
   <w.rf>
    <LM>w#w-id62583-4</LM>
   </w.rf>
   <form>uzavřena</form>
   <lemma>uzavřít</lemma>
   <tag>VsQW----X-APP--</tag>
  </m>
  <m id="m973-id62583-5">
   <w.rf>
    <LM>w#w-id62583-5</LM>
   </w.rf>
   <form>dohoda</form>
   <lemma>dohoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62611-1">
   <w.rf>
    <LM>w#w-id62611-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62611-2">
   <w.rf>
    <LM>w#w-id62611-2</LM>
   </w.rf>
   <form>repatriaci</form>
   <lemma>repatriace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id62611-3">
   <w.rf>
    <LM>w#w-id62611-3</LM>
   </w.rf>
   <form>emigrantů</form>
   <lemma>emigrant</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-d-id94469">
   <w.rf>
    <LM>w#w-d-id94469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x6-13225">
   <w.rf>
    <LM>w#w-id62265-x6-13225</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x9">
  <m id="m973-id62639-1">
   <w.rf>
    <LM>w#w-id62639-1</LM>
   </w.rf>
   <form>Máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id62639-2">
   <w.rf>
    <LM>w#w-id62639-2</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m973-id62639-3">
   <w.rf>
    <LM>w#w-id62639-3</LM>
   </w.rf>
   <form>možnosti</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-d-id94597">
   <w.rf>
    <LM>w#w-d-id94597</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62658-1">
   <w.rf>
    <LM>w#w-id62658-1</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62658-3">
   <w.rf>
    <LM>w#w-id62658-3</LM>
   </w.rf>
   <form>projevíte</form>
   <lemma>projevit</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m973-id62658-4">
   <w.rf>
    <LM>w#w-id62658-4</LM>
   </w.rf>
   <form>přání</form>
   <lemma>přání_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id62658-5">
   <w.rf>
    <LM>w#w-id62658-5</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62658-6">
   <w.rf>
    <LM>w#w-id62658-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id62658-7">
   <w.rf>
    <LM>w#w-id62658-7</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-d-id94733">
   <w.rf>
    <LM>w#w-d-id94733</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62677-2">
   <w.rf>
    <LM>w#w-id62677-2</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62677-3">
   <w.rf>
    <LM>w#w-id62677-3</LM>
   </w.rf>
   <form>projevíte</form>
   <lemma>projevit</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m973-id62677-4">
   <w.rf>
    <LM>w#w-id62677-4</LM>
   </w.rf>
   <form>přání</form>
   <lemma>přání_^(*2t)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id62677-5">
   <w.rf>
    <LM>w#w-id62677-5</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62677-6">
   <w.rf>
    <LM>w#w-id62677-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62677-7">
   <w.rf>
    <LM>w#w-id62677-7</LM>
   </w.rf>
   <form>Sovětském</form>
   <lemma>sovětský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m973-id62677-8">
   <w.rf>
    <LM>w#w-id62677-8</LM>
   </w.rf>
   <form>Svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m973-id62687-1">
   <w.rf>
    <LM>w#w-id62687-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62687-2">
   <w.rf>
    <LM>w#w-id62687-2</LM>
   </w.rf>
   <form>přijmout</form>
   <lemma>přijmout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62687-3">
   <w.rf>
    <LM>w#w-id62687-3</LM>
   </w.rf>
   <form>sovětské</form>
   <lemma>sovětský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m973-id62687-4">
   <w.rf>
    <LM>w#w-id62687-4</LM>
   </w.rf>
   <form>občanství</form>
   <lemma>občanství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-d-id94954">
   <w.rf>
    <LM>w#w-d-id94954</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x10">
  <m id="m973-id62711-5">
   <w.rf>
    <LM>w#w-id62711-5</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62711-3">
   <w.rf>
    <LM>w#w-id62711-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62711-4">
   <w.rf>
    <LM>w#w-id62711-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id62711-7">
   <w.rf>
    <LM>w#w-id62711-7</LM>
   </w.rf>
   <form>neuvědomil</form>
   <lemma>uvědomit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m973-d-id95105">
   <w.rf>
    <LM>w#w-d-id95105</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62711-8">
   <w.rf>
    <LM>w#w-id62711-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62711-9">
   <w.rf>
    <LM>w#w-id62711-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62711-10">
   <w.rf>
    <LM>w#w-id62711-10</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62721-1">
   <w.rf>
    <LM>w#w-id62721-1</LM>
   </w.rf>
   <form>utekl</form>
   <lemma>utéci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62721-2">
   <w.rf>
    <LM>w#w-id62721-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id62721-4">
   <w.rf>
    <LM>w#w-id62721-4</LM>
   </w.rf>
   <form>koncentráku</form>
   <lemma>koncentrák</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id62265-x10-359">
   <w.rf>
    <LM>w#w-id62265-x10-359</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-360">
  <m id="m973-id62739-3">
   <w.rf>
    <LM>w#w-id62739-3</LM>
   </w.rf>
   <form>Seděl</form>
   <lemma>sedět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id62739-2">
   <w.rf>
    <LM>w#w-id62739-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62265-x10-14841">
   <w.rf>
    <LM>w#w-id62265-x10-14841</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62749-1">
   <w.rf>
    <LM>w#w-id62749-1</LM>
   </w.rf>
   <form>hlavu</form>
   <lemma>hlava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-id62749-2">
   <w.rf>
    <LM>w#w-id62749-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62749-3">
   <w.rf>
    <LM>w#w-id62749-3</LM>
   </w.rf>
   <form>dlaních</form>
   <lemma>dlaň</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m973-id62265-x10-14842">
   <w.rf>
    <LM>w#w-id62265-x10-14842</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62749-4">
   <w.rf>
    <LM>w#w-id62749-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62749-5">
   <w.rf>
    <LM>w#w-id62749-5</LM>
   </w.rf>
   <form>úporně</form>
   <lemma>úporně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id62749-6">
   <w.rf>
    <LM>w#w-id62749-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62749-7">
   <w.rf>
    <LM>w#w-id62749-7</LM>
   </w.rf>
   <form>přemýšlel</form>
   <lemma>přemýšlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id62265-x10-14844">
   <w.rf>
    <LM>w#w-id62265-x10-14844</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62749-8">
   <w.rf>
    <LM>w#w-id62749-8</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m973-id62749-9">
   <w.rf>
    <LM>w#w-id62749-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62749-10">
   <w.rf>
    <LM>w#w-id62749-10</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62749-11">
   <w.rf>
    <LM>w#w-id62749-11</LM>
   </w.rf>
   <form>napsat</form>
   <lemma>napsat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-d-id95468">
   <w.rf>
    <LM>w#w-d-id95468</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x11">
  <m id="m973-id62754-1">
   <w.rf>
    <LM>w#w-id62754-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id62754-2">
   <w.rf>
    <LM>w#w-id62754-2</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m973-id62754-3">
   <w.rf>
    <LM>w#w-id62754-3</LM>
   </w.rf>
   <form>straně</form>
   <lemma>strana</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id62265-x11-375">
   <w.rf>
    <LM>w#w-id62265-x11-375</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62764-1">
   <w.rf>
    <LM>w#w-id62764-1</LM>
   </w.rf>
   <form>touha</form>
   <lemma>touha</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62764-2">
   <w.rf>
    <LM>w#w-id62764-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62764-3">
   <w.rf>
    <LM>w#w-id62764-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-id62764-4">
   <w.rf>
    <LM>w#w-id62764-4</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m973-d-id95603">
   <w.rf>
    <LM>w#w-d-id95603</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62764-5">
   <w.rf>
    <LM>w#w-id62764-5</LM>
   </w.rf>
   <form>sestry</form>
   <lemma>sestra</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-d-id95627">
   <w.rf>
    <LM>w#w-d-id95627</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62764-6">
   <w.rf>
    <LM>w#w-id62764-6</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62764-7">
   <w.rf>
    <LM>w#w-id62764-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id62764-8">
   <w.rf>
    <LM>w#w-id62764-8</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62265-x11-376">
   <w.rf>
    <LM>w#w-id62265-x11-376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-377">
  <m id="m973-id62774-8">
   <w.rf>
    <LM>w#w-id62774-8</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62774-9">
   <w.rf>
    <LM>w#w-id62774-9</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m973-id62774-10">
   <w.rf>
    <LM>w#w-id62774-10</LM>
   </w.rf>
   <form>okamžik</form>
   <lemma>okamžik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id62764-9">
   <w.rf>
    <LM>w#w-id62764-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m973-id62764-10">
   <w.rf>
    <LM>w#w-id62764-10</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62764-11">
   <w.rf>
    <LM>w#w-id62764-11</LM>
   </w.rf>
   <form>nenapadlo</form>
   <lemma>napadnout</lemma>
   <tag>VpNS----R-NAP-1</tag>
  </m>
  <m id="m973-d-id95731">
   <w.rf>
    <LM>w#w-d-id95731</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62774-1">
   <w.rf>
    <LM>w#w-id62774-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62774-2">
   <w.rf>
    <LM>w#w-id62774-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m973-id62774-3">
   <w.rf>
    <LM>w#w-id62774-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62774-4">
   <w.rf>
    <LM>w#w-id62774-4</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id62774-5">
   <w.rf>
    <LM>w#w-id62774-5</LM>
   </w.rf>
   <form>skončit</form>
   <lemma>skončit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62774-6">
   <w.rf>
    <LM>w#w-id62774-6</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62774-7">
   <w.rf>
    <LM>w#w-id62774-7</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-d-id95884">
   <w.rf>
    <LM>w#w-d-id95884</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x12">
  <m id="m973-id62789-2">
   <w.rf>
    <LM>w#w-id62789-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62789-3">
   <w.rf>
    <LM>w#w-id62789-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62265-x12-16168">
   <w.rf>
    <LM>w#w-id62265-x12-16168</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62789-4">
   <w.rf>
    <LM>w#w-id62789-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62789-5">
   <w.rf>
    <LM>w#w-id62789-5</LM>
   </w.rf>
   <form>seděl</form>
   <lemma>sedět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m973-id62265-x12-16169">
   <w.rf>
    <LM>w#w-id62265-x12-16169</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62798-2">
   <w.rf>
    <LM>w#w-id62798-2</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62798-1">
   <w.rf>
    <LM>w#w-id62798-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62798-3">
   <w.rf>
    <LM>w#w-id62798-3</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m973-id62265-x12-16172">
   <w.rf>
    <LM>w#w-id62265-x12-16172</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62265-x12-16170">
   <w.rf>
    <LM>w#w-id62265-x12-16170</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62808-1">
   <w.rf>
    <LM>w#w-id62808-1</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m973-id62265-x12-7786">
   <w.rf>
    <LM>w#w-id62265-x12-7786</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62808-2">
   <w.rf>
    <LM>w#w-id62808-2</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62808-3">
   <w.rf>
    <LM>w#w-id62808-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62808-4">
   <w.rf>
    <LM>w#w-id62808-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id62808-6">
   <w.rf>
    <LM>w#w-id62808-6</LM>
   </w.rf>
   <form>policistka</form>
   <lemma>policistka_^(*2a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62265-x12-16174">
   <w.rf>
    <LM>w#w-id62265-x12-16174</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62808-11">
   <w.rf>
    <LM>w#w-id62808-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id62808-12">
   <w.rf>
    <LM>w#w-id62808-12</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS7----------</tag>
  </m>
  <m id="m973-id62808-13">
   <w.rf>
    <LM>w#w-id62808-13</LM>
   </w.rf>
   <form>šarží</form>
   <lemma>šarže</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m973-d-id96227">
   <w.rf>
    <LM>w#w-d-id96227</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x13">
  <m id="m973-id62823-1">
   <w.rf>
    <LM>w#w-id62823-1</LM>
   </w.rf>
   <form>Mladá</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-d-id96275">
   <w.rf>
    <LM>w#w-d-id96275</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62823-2">
   <w.rf>
    <LM>w#w-id62823-2</LM>
   </w.rf>
   <form>hezká</form>
   <lemma>hezký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id62265-x13-386">
   <w.rf>
    <LM>w#w-id62265-x13-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-387">
  <m id="m973-id62832-2">
   <w.rf>
    <LM>w#w-id62832-2</LM>
   </w.rf>
   <form>Najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62832-3">
   <w.rf>
    <LM>w#w-id62832-3</LM>
   </w.rf>
   <form>slyším</form>
   <lemma>slyšet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-d-id96357">
   <w.rf>
    <LM>w#w-d-id96357</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62832-4">
   <w.rf>
    <LM>w#w-id62832-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62832-5">
   <w.rf>
    <LM>w#w-id62832-5</LM>
   </w.rf>
   <form>stojí</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id62832-6">
   <w.rf>
    <LM>w#w-id62832-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id62832-7">
   <w.rf>
    <LM>w#w-id62832-7</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m973-id62832-8">
   <w.rf>
    <LM>w#w-id62832-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62832-9">
   <w.rf>
    <LM>w#w-id62832-9</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id62832-10">
   <w.rf>
    <LM>w#w-id62832-10</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m973-id62832-12">
   <w.rf>
    <LM>w#w-id62832-12</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id62832-13">
   <w.rf>
    <LM>w#w-id62832-13</LM>
   </w.rf>
   <form>ucha</form>
   <lemma>ucho-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m973-id62265-x13-16897">
   <w.rf>
    <LM>w#w-id62265-x13-16897</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x13-16975">
   <w.rf>
    <LM>w#w-id62265-x13-16975</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62852-1">
   <w.rf>
    <LM>w#w-id62852-1</LM>
   </w.rf>
   <form>Nepiš</form>
   <lemma>psát</lemma>
   <tag>Vi-S---2--N-I--</tag>
  </m>
  <m id="m973-d-id96556">
   <w.rf>
    <LM>w#w-d-id96556</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62852-2">
   <w.rf>
    <LM>w#w-id62852-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62852-3">
   <w.rf>
    <LM>w#w-id62852-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id62852-4">
   <w.rf>
    <LM>w#w-id62852-4</LM>
   </w.rf>
   <form>chceš</form>
   <lemma>chtít</lemma>
   <tag>VB-S---2P-AAI--</tag>
  </m>
  <m id="m973-id62852-5">
   <w.rf>
    <LM>w#w-id62852-5</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-d-id96627">
   <w.rf>
    <LM>w#w-d-id96627</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62265-x13-16977">
   <w.rf>
    <LM>w#w-id62265-x13-16977</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x14">
  <m id="m973-id62866-3">
   <w.rf>
    <LM>w#w-id62866-3</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62866-2">
   <w.rf>
    <LM>w#w-id62866-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62866-4">
   <w.rf>
    <LM>w#w-id62866-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62866-5">
   <w.rf>
    <LM>w#w-id62866-5</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m973-d-id96730">
   <w.rf>
    <LM>w#w-d-id96730</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x15">
  <m id="m973-id62880-2">
   <w.rf>
    <LM>w#w-id62880-2</LM>
   </w.rf>
   <form>Napsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id62880-3">
   <w.rf>
    <LM>w#w-id62880-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62265-x15-17067">
   <w.rf>
    <LM>w#w-id62265-x15-17067</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62880-4">
   <w.rf>
    <LM>w#w-id62880-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62880-5">
   <w.rf>
    <LM>w#w-id62880-5</LM>
   </w.rf>
   <form>chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id62880-6">
   <w.rf>
    <LM>w#w-id62880-6</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62890-1">
   <w.rf>
    <LM>w#w-id62890-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id62890-2">
   <w.rf>
    <LM>w#w-id62890-2</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62890-3">
   <w.rf>
    <LM>w#w-id62890-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id62890-4">
   <w.rf>
    <LM>w#w-id62890-4</LM>
   </w.rf>
   <form>sovětské</form>
   <lemma>sovětský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m973-id62890-5">
   <w.rf>
    <LM>w#w-id62890-5</LM>
   </w.rf>
   <form>občanství</form>
   <lemma>občanství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-d-id96930">
   <w.rf>
    <LM>w#w-d-id96930</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x16">
  <m id="m973-id62909-1">
   <w.rf>
    <LM>w#w-id62909-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id62909-2">
   <w.rf>
    <LM>w#w-id62909-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m973-id62909-3">
   <w.rf>
    <LM>w#w-id62909-3</LM>
   </w.rf>
   <form>poradila</form>
   <lemma>poradit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m973-d-id97040">
   <w.rf>
    <LM>w#w-d-id97040</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62265-x17">
  <m id="m973-id62923-1">
   <w.rf>
    <LM>w#w-id62923-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62923-2">
   <w.rf>
    <LM>w#w-id62923-2</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m973-id62923-3">
   <w.rf>
    <LM>w#w-id62923-3</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m973-id62923-4">
   <w.rf>
    <LM>w#w-id62923-4</LM>
   </w.rf>
   <form>nato</form>
   <lemma>nato</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62932-1">
   <w.rf>
    <LM>w#w-id62932-1</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m973-id62932-2">
   <w.rf>
    <LM>w#w-id62932-2</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m973-d-id97198">
   <w.rf>
    <LM>w#w-d-id97198</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62932-3">
   <w.rf>
    <LM>w#w-id62932-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m973-id62932-4">
   <w.rf>
    <LM>w#w-id62932-4</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-d-id97238">
   <w.rf>
    <LM>w#w-d-id97238</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62932-5">
   <w.rf>
    <LM>w#w-id62932-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id62932-6">
   <w.rf>
    <LM>w#w-id62932-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id62932-7">
   <w.rf>
    <LM>w#w-id62932-7</LM>
   </w.rf>
   <form>chtějí</form>
   <lemma>chtít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m973-id62932-8">
   <w.rf>
    <LM>w#w-id62932-8</LM>
   </w.rf>
   <form>vrátit</form>
   <lemma>vrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id62265-x17-17305">
   <w.rf>
    <LM>w#w-id62265-x17-17305</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62942-2">
   <w.rf>
    <LM>w#w-id62942-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id62942-3">
   <w.rf>
    <LM>w#w-id62942-3</LM>
   </w.rf>
   <form>odtransportováni</form>
   <lemma>odtransportovat</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m973-id62942-4">
   <w.rf>
    <LM>w#w-id62942-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id62942-5">
   <w.rf>
    <LM>w#w-id62942-5</LM>
   </w.rf>
   <form>gulagu</form>
   <lemma>gulag</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-d-id97389">
   <w.rf>
    <LM>w#w-d-id97389</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62945-x1">
  <m id="m973-id62961-1">
   <w.rf>
    <LM>w#w-id62961-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62961-2">
   <w.rf>
    <LM>w#w-id62961-2</LM>
   </w.rf>
   <form>bysme</form>
   <lemma>být</lemma>
   <tag>Vc----------Im6</tag>
  </m>
  <m id="m973-id62961-4">
   <w.rf>
    <LM>w#w-id62961-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id62961-5">
   <w.rf>
    <LM>w#w-id62961-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id62961-3">
   <w.rf>
    <LM>w#w-id62961-3</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id62961-6">
   <w.rf>
    <LM>w#w-id62961-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id62961-7">
   <w.rf>
    <LM>w#w-id62961-7</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m973-id62961-8">
   <w.rf>
    <LM>w#w-id62961-8</LM>
   </w.rf>
   <form>nezasvěcené</form>
   <lemma>zasvěcený_^(*4tit)</lemma>
   <tag>AAMP4----1N----</tag>
  </m>
  <m id="m973-id62961-9">
   <w.rf>
    <LM>w#w-id62961-9</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m973-id62945-x1-5620">
   <w.rf>
    <LM>w#w-id62945-x1-5620</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id62961-10">
   <w.rf>
    <LM>w#w-id62961-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id62961-11">
   <w.rf>
    <LM>w#w-id62961-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id62961-13">
   <w.rf>
    <LM>w#w-id62961-13</LM>
   </w.rf>
   <form>gulag</form>
   <lemma>gulag</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id62945-x1-17430">
   <w.rf>
    <LM>w#w-id62945-x1-17430</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-d-id97596">
   <w.rf>
    <LM>w#w-d-id97596</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id62964-x1">
  <m id="m973-id63007-1">
   <w.rf>
    <LM>w#w-id63007-1</LM>
   </w.rf>
   <form>Gulag</form>
   <lemma>gulag</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id63007-2">
   <w.rf>
    <LM>w#w-id63007-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63007-3">
   <w.rf>
    <LM>w#w-id63007-3</LM>
   </w.rf>
   <form>zkratka</form>
   <lemma>zkratka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id62964-x1-17442">
   <w.rf>
    <LM>w#w-id62964-x1-17442</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-17435">
  <m id="m973-17435-409">
   <w.rf>
    <LM>w#w-17435-409</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id63025-2">
   <w.rf>
    <LM>w#w-id63025-2</LM>
   </w.rf>
   <form>definovat</form>
   <lemma>definovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m973-id63025-3">
   <w.rf>
    <LM>w#w-id63025-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id63025-4">
   <w.rf>
    <LM>w#w-id63025-4</LM>
   </w.rf>
   <form>dešifrovat</form>
   <lemma>dešifrovat</lemma>
   <tag>Vf--------A-B--</tag>
  </m>
  <m id="m973-17435-17446">
   <w.rf>
    <LM>w#w-17435-17446</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m973-17435-17447">
   <w.rf>
    <LM>w#w-17435-17447</LM>
   </w.rf>
   <form>zkratku</form>
   <lemma>zkratka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-17435-410">
   <w.rf>
    <LM>w#w-17435-410</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-17451">
  <m id="m973-id63039-2">
   <w.rf>
    <LM>w#w-id63039-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63039-3">
   <w.rf>
    <LM>w#w-id63039-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63039-4">
   <w.rf>
    <LM>w#w-id63039-4</LM>
   </w.rf>
   <form>koncentrák</form>
   <lemma>koncentrák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-17451-414">
   <w.rf>
    <LM>w#w-17451-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-415">
  <m id="m973-id63050-1">
   <w.rf>
    <LM>w#w-id63050-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m973-id63050-2">
   <w.rf>
    <LM>w#w-id63050-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63050-3">
   <w.rf>
    <LM>w#w-id63050-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63050-4">
   <w.rf>
    <LM>w#w-id63050-4</LM>
   </w.rf>
   <form>gulag</form>
   <lemma>gulag</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-17451-7940">
   <w.rf>
    <LM>w#w-17451-7940</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63039-8">
   <w.rf>
    <LM>w#w-id63039-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63039-10">
   <w.rf>
    <LM>w#w-id63039-10</LM>
   </w.rf>
   <form>víceméně</form>
   <lemma>víceméně</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63039-13">
   <w.rf>
    <LM>w#w-id63039-13</LM>
   </w.rf>
   <form>nejlíp</form>
   <lemma>lépe</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m973-id63039-14">
   <w.rf>
    <LM>w#w-id63039-14</LM>
   </w.rf>
   <form>patrné</form>
   <lemma>patrný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m973-17451-17467">
   <w.rf>
    <LM>w#w-17451-17467</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63039-15">
   <w.rf>
    <LM>w#w-id63039-15</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-17451-17471">
   <w.rf>
    <LM>w#w-17451-17471</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id63039-16">
   <w.rf>
    <LM>w#w-id63039-16</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m973-id63039-17">
   <w.rf>
    <LM>w#w-id63039-17</LM>
   </w.rf>
   <form>přečte</form>
   <lemma>přečíst</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m973-id63039-19">
   <w.rf>
    <LM>w#w-id63039-19</LM>
   </w.rf>
   <form>knihy</form>
   <lemma>kniha</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-id63039-20">
   <w.rf>
    <LM>w#w-id63039-20</LM>
   </w.rf>
   <form>Solženicyna</form>
   <lemma>Solženicyn_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m973-17451-17472">
   <w.rf>
    <LM>w#w-17451-17472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-17451-17469">
   <w.rf>
    <LM>w#w-17451-17469</LM>
   </w.rf>
   <form>Souostroví</form>
   <lemma>souostroví</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m973-id63060-1">
   <w.rf>
    <LM>w#w-id63060-1</LM>
   </w.rf>
   <form>Gulag</form>
   <lemma>gulag</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-415-432">
   <w.rf>
    <LM>w#w-415-432</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-433">
  <m id="m973-id63069-1">
   <w.rf>
    <LM>w#w-id63069-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63069-2">
   <w.rf>
    <LM>w#w-id63069-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63069-3">
   <w.rf>
    <LM>w#w-id63069-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63069-4">
   <w.rf>
    <LM>w#w-id63069-4</LM>
   </w.rf>
   <form>zkratka</form>
   <lemma>zkratka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63072-x1-419">
   <w.rf>
    <LM>w#w-id63072-x1-419</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63072-x1-17592">
   <w.rf>
    <LM>w#w-id63072-x1-17592</LM>
   </w.rf>
   <form>Gosudarstvennoje</form>
   <lemma>Gosudarstvennoje-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id63072-x1-17591">
   <w.rf>
    <LM>w#w-id63072-x1-17591</LM>
   </w.rf>
   <form>Upravlenije</form>
   <lemma>Upravlenije-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id63072-x1-17587">
   <w.rf>
    <LM>w#w-id63072-x1-17587</LM>
   </w.rf>
   <form>Lagrov</form>
   <lemma>Lagrov-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m973-id63072-x1-420">
   <w.rf>
    <LM>w#w-id63072-x1-420</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-d-id98509">
   <w.rf>
    <LM>w#w-d-id98509</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-17741">
  <m id="m973-id63110-1">
   <w.rf>
    <LM>w#w-id63110-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63110-2">
   <w.rf>
    <LM>w#w-id63110-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63110-3">
   <w.rf>
    <LM>w#w-id63110-3</LM>
   </w.rf>
   <form>zkratka</form>
   <lemma>zkratka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63072-x1-17738">
   <w.rf>
    <LM>w#w-id63072-x1-17738</LM>
   </w.rf>
   <form>gulag</form>
   <lemma>gulag</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m973-id63072-x1-17740">
   <w.rf>
    <LM>w#w-id63072-x1-17740</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63072-x2">
  <m id="m973-id63124-1">
   <w.rf>
    <LM>w#w-id63124-1</LM>
   </w.rf>
   <form>Zkráceně</form>
   <lemma>zkráceně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63124-2">
   <w.rf>
    <LM>w#w-id63124-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63124-3">
   <w.rf>
    <LM>w#w-id63124-3</LM>
   </w.rf>
   <form>znamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63072-x2-17751">
   <w.rf>
    <LM>w#w-id63072-x2-17751</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63124-4">
   <w.rf>
    <LM>w#w-id63124-4</LM>
   </w.rf>
   <form>státní</form>
   <lemma>státní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id63134-1">
   <w.rf>
    <LM>w#w-id63134-1</LM>
   </w.rf>
   <form>správa</form>
   <lemma>správa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63152-1">
   <w.rf>
    <LM>w#w-id63152-1</LM>
   </w.rf>
   <form>lágru</form>
   <lemma>lágr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id63072-x2-17752">
   <w.rf>
    <LM>w#w-id63072-x2-17752</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-d-id98677">
   <w.rf>
    <LM>w#w-d-id98677</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63072-x3">
  <m id="m973-id63157-1">
   <w.rf>
    <LM>w#w-id63157-1</LM>
   </w.rf>
   <form>Lágru</form>
   <lemma>lágr</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id63161-1">
   <w.rf>
    <LM>w#w-id63161-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id63161-2">
   <w.rf>
    <LM>w#w-id63161-2</LM>
   </w.rf>
   <form>věznic</form>
   <lemma>věznice</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m973-id63072-x4-18045">
   <w.rf>
    <LM>w#w-id63072-x4-18045</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63161-3">
   <w.rf>
    <LM>w#w-id63161-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63161-4">
   <w.rf>
    <LM>w#w-id63161-4</LM>
   </w.rf>
   <form>budete</form>
   <lemma>být</lemma>
   <tag>VB-P---2F-AAI--</tag>
  </m>
  <m id="m973-id63161-5">
   <w.rf>
    <LM>w#w-id63161-5</LM>
   </w.rf>
   <form>chtít</form>
   <lemma>chtít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m973-d-id98827">
   <w.rf>
    <LM>w#w-d-id98827</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63072-x5">
  <m id="m973-id63166-5">
   <w.rf>
    <LM>w#w-id63166-5</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id63166-3">
   <w.rf>
    <LM>w#w-id63166-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id63166-4">
   <w.rf>
    <LM>w#w-id63166-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id63166-6">
   <w.rf>
    <LM>w#w-id63166-6</LM>
   </w.rf>
   <form>přeložit</form>
   <lemma>přeložit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-id63072-x5-18228">
   <w.rf>
    <LM>w#w-id63072-x5-18228</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63166-7">
   <w.rf>
    <LM>w#w-id63166-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63166-8">
   <w.rf>
    <LM>w#w-id63166-8</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id63072-x5-18229">
   <w.rf>
    <LM>w#w-id63072-x5-18229</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-18416">
  <m id="m973-id63177-5">
   <w.rf>
    <LM>w#w-id63177-5</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63177-3">
   <w.rf>
    <LM>w#w-id63177-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id63177-4">
   <w.rf>
    <LM>w#w-id63177-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id63213-1">
   <w.rf>
    <LM>w#w-id63213-1</LM>
   </w.rf>
   <form>pochopil</form>
   <lemma>pochopit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-d-id98836">
   <w.rf>
    <LM>w#w-d-id98836</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63179-x1">
  <m id="m973-id63199-1">
   <w.rf>
    <LM>w#w-id63199-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63199-2">
   <w.rf>
    <LM>w#w-id63199-2</LM>
   </w.rf>
   <form>praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id63199-3">
   <w.rf>
    <LM>w#w-id63199-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63199-4">
   <w.rf>
    <LM>w#w-id63199-4</LM>
   </w.rf>
   <form>znamenalo</form>
   <lemma>znamenat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id63179-x1-464">
   <w.rf>
    <LM>w#w-id63179-x1-464</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m973-id63179-x1-18713">
   <w.rf>
    <LM>w#w-id63179-x1-18713</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63215-x1">
  <m id="m973-id63231-1">
   <w.rf>
    <LM>w#w-id63231-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63231-2">
   <w.rf>
    <LM>w#w-id63231-2</LM>
   </w.rf>
   <form>praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id63231-3">
   <w.rf>
    <LM>w#w-id63231-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63231-4">
   <w.rf>
    <LM>w#w-id63231-4</LM>
   </w.rf>
   <form>znamenalo</form>
   <lemma>znamenat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id63215-x1-5755">
   <w.rf>
    <LM>w#w-id63215-x1-5755</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63231-8">
   <w.rf>
    <LM>w#w-id63231-8</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63240-2">
   <w.rf>
    <LM>w#w-id63240-2</LM>
   </w.rf>
   <form>odtransportovali</form>
   <lemma>odtransportovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id63240-4">
   <w.rf>
    <LM>w#w-id63240-4</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m973-id63231-5">
   <w.rf>
    <LM>w#w-id63231-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id63231-6">
   <w.rf>
    <LM>w#w-id63231-6</LM>
   </w.rf>
   <form>Sibiř</form>
   <lemma>Sibiř_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-id63250-2">
   <w.rf>
    <LM>w#w-id63250-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id63250-3">
   <w.rf>
    <LM>w#w-id63250-3</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id63250-4">
   <w.rf>
    <LM>w#w-id63250-4</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m973-id63250-5">
   <w.rf>
    <LM>w#w-id63250-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id63250-7">
   <w.rf>
    <LM>w#w-id63250-7</LM>
   </w.rf>
   <form>pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63250-6">
   <w.rf>
    <LM>w#w-id63250-6</LM>
   </w.rf>
   <form>přežil</form>
   <lemma>přežít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id63215-x1-18726">
   <w.rf>
    <LM>w#w-id63215-x1-18726</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-18719">
  <m id="m973-id63250-8">
   <w.rf>
    <LM>w#w-id63250-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63250-9">
   <w.rf>
    <LM>w#w-id63250-9</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m973-id63250-10">
   <w.rf>
    <LM>w#w-id63250-10</LM>
   </w.rf>
   <form>vyhlazovací</form>
   <lemma>vyhlazovací_^(*2t)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m973-id63250-11">
   <w.rf>
    <LM>w#w-id63250-11</LM>
   </w.rf>
   <form>lágry</form>
   <lemma>lágr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m973-id63250-12">
   <w.rf>
    <LM>w#w-id63250-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63261-1">
   <w.rf>
    <LM>w#w-id63261-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id63261-2">
   <w.rf>
    <LM>w#w-id63261-2</LM>
   </w.rf>
   <form>Němců</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-18719-18728">
   <w.rf>
    <LM>w#w-18719-18728</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63261-4">
   <w.rf>
    <LM>w#w-id63261-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-18719-18729">
   <w.rf>
    <LM>w#w-18719-18729</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m973-id63261-5">
   <w.rf>
    <LM>w#w-id63261-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63261-6">
   <w.rf>
    <LM>w#w-id63261-6</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id63261-7">
   <w.rf>
    <LM>w#w-id63261-7</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m973-id63261-8">
   <w.rf>
    <LM>w#w-id63261-8</LM>
   </w.rf>
   <form>plynové</form>
   <lemma>plynový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m973-id63261-9">
   <w.rf>
    <LM>w#w-id63261-9</LM>
   </w.rf>
   <form>komory</form>
   <lemma>komora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m973-18719-470">
   <w.rf>
    <LM>w#w-18719-470</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-471">
  <m id="m973-id63271-2">
   <w.rf>
    <LM>w#w-id63271-2</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m973-id63271-3">
   <w.rf>
    <LM>w#w-id63271-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63271-4">
   <w.rf>
    <LM>w#w-id63271-4</LM>
   </w.rf>
   <form>lágry</form>
   <lemma>lágr</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m973-d-id99948">
   <w.rf>
    <LM>w#w-d-id99948</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63271-5">
   <w.rf>
    <LM>w#w-id63271-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63289-1">
   <w.rf>
    <LM>w#w-id63289-1</LM>
   </w.rf>
   <form>přežili</form>
   <lemma>přežít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id63289-2">
   <w.rf>
    <LM>w#w-id63289-2</LM>
   </w.rf>
   <form>pouze</form>
   <lemma>pouze</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63289-3">
   <w.rf>
    <LM>w#w-id63289-3</LM>
   </w.rf>
   <form>skutečně</form>
   <lemma>skutečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63289-4">
   <w.rf>
    <LM>w#w-id63289-4</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m973-18719-18733">
   <w.rf>
    <LM>w#w-18719-18733</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63289-5">
   <w.rf>
    <LM>w#w-id63289-5</LM>
   </w.rf>
   <form>silní</form>
   <lemma>silný</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m973-18719-18734">
   <w.rf>
    <LM>w#w-18719-18734</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63289-6">
   <w.rf>
    <LM>w#w-id63289-6</LM>
   </w.rf>
   <form>zdraví</form>
   <lemma>zdravý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m973-id63289-7">
   <w.rf>
    <LM>w#w-id63289-7</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m973-d-id100117">
   <w.rf>
    <LM>w#w-d-id100117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63215-x2">
  <m id="m973-id63309-1">
   <w.rf>
    <LM>w#w-id63309-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id63215-x2-475">
   <w.rf>
    <LM>w#w-id63215-x2-475</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m973-id63309-2">
   <w.rf>
    <LM>w#w-id63309-2</LM>
   </w.rf>
   <form>šance</form>
   <lemma>šance</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63215-x2-19313">
   <w.rf>
    <LM>w#w-id63215-x2-19313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63330-x1">
  <m id="m973-id63345-1">
   <w.rf>
    <LM>w#w-id63345-1</LM>
   </w.rf>
   <form>Pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m973-id63345-2">
   <w.rf>
    <LM>w#w-id63345-2</LM>
   </w.rf>
   <form>tábory</form>
   <lemma>tábor-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m973-id63330-x1-20251">
   <w.rf>
    <LM>w#w-id63330-x1-20251</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63330-x1-20252">
   <w.rf>
    <LM>w#w-id63330-x1-20252</LM>
   </w.rf>
   <form>řekněme</form>
   <lemma>říci</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m973-d-id100326">
   <w.rf>
    <LM>w#w-d-id100326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63348-x1">
  <m id="m973-id63363-1">
   <w.rf>
    <LM>w#w-id63363-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m973-id63348-x1-20257">
   <w.rf>
    <LM>w#w-id63348-x1-20257</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63363-2">
   <w.rf>
    <LM>w#w-id63363-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m973-id63363-3">
   <w.rf>
    <LM>w#w-id63363-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63363-4">
   <w.rf>
    <LM>w#w-id63363-4</LM>
   </w.rf>
   <form>pracovní</form>
   <lemma>pracovní</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m973-id63363-5">
   <w.rf>
    <LM>w#w-id63363-5</LM>
   </w.rf>
   <form>tábory</form>
   <lemma>tábor-1</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m973-d-id100469">
   <w.rf>
    <LM>w#w-d-id100469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63348-x2">
  <m id="m973-id63378-1">
   <w.rf>
    <LM>w#w-id63378-1</LM>
   </w.rf>
   <form>Daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63348-x2-155">
   <w.rf>
    <LM>w#w-id63348-x2-155</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63378-2">
   <w.rf>
    <LM>w#w-id63378-2</LM>
   </w.rf>
   <form>daleko</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63378-3">
   <w.rf>
    <LM>w#w-id63378-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m973-id63378-5">
   <w.rf>
    <LM>w#w-id63378-5</LM>
   </w.rf>
   <form>civilizace</form>
   <lemma>civilizace</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m973-id63348-x2-20259">
   <w.rf>
    <LM>w#w-id63348-x2-20259</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63378-6">
   <w.rf>
    <LM>w#w-id63378-6</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63378-7">
   <w.rf>
    <LM>w#w-id63378-7</LM>
   </w.rf>
   <form>útěku</form>
   <lemma>útěk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m973-id63348-x2-484">
   <w.rf>
    <LM>w#w-id63348-x2-484</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m973-id63378-10">
   <w.rf>
    <LM>w#w-id63378-10</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63378-8">
   <w.rf>
    <LM>w#w-id63378-8</LM>
   </w.rf>
   <form>nulová</form>
   <lemma>nulový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m973-id63378-11">
   <w.rf>
    <LM>w#w-id63378-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id63378-12">
   <w.rf>
    <LM>w#w-id63378-12</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-d-id100478">
   <w.rf>
    <LM>w#w-d-id100478</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63400-x1">
  <m id="m973-id63420-4">
   <w.rf>
    <LM>w#w-id63420-4</LM>
   </w.rf>
   <form>Rozhodl</form>
   <lemma>rozhodnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m973-id63420-2">
   <w.rf>
    <LM>w#w-id63420-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id63420-3">
   <w.rf>
    <LM>w#w-id63420-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63420-5">
   <w.rf>
    <LM>w#w-id63420-5</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m973-id63420-6">
   <w.rf>
    <LM>w#w-id63420-6</LM>
   </w.rf>
   <form>sovětské</form>
   <lemma>sovětský</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m973-id63420-7">
   <w.rf>
    <LM>w#w-id63420-7</LM>
   </w.rf>
   <form>občanství</form>
   <lemma>občanství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m973-id63420-8">
   <w.rf>
    <LM>w#w-id63420-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m973-id63420-9">
   <w.rf>
    <LM>w#w-id63420-9</LM>
   </w.rf>
   <form>zůstal</form>
   <lemma>zůstat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id63420-10">
   <w.rf>
    <LM>w#w-id63420-10</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m973-id63420-11">
   <w.rf>
    <LM>w#w-id63420-11</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63420-12">
   <w.rf>
    <LM>w#w-id63420-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63420-13">
   <w.rf>
    <LM>w#w-id63420-13</LM>
   </w.rf>
   <form>pekárně</form>
   <lemma>pekárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id63400-x1-20816">
   <w.rf>
    <LM>w#w-id63400-x1-20816</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63437-x1">
  <m id="m973-id63452-1">
   <w.rf>
    <LM>w#w-id63452-1</LM>
   </w.rf>
   <form>Zůstal</form>
   <lemma>zůstat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-id63452-2">
   <w.rf>
    <LM>w#w-id63452-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id63452-3">
   <w.rf>
    <LM>w#w-id63452-3</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63452-4">
   <w.rf>
    <LM>w#w-id63452-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63452-6">
   <w.rf>
    <LM>w#w-id63452-6</LM>
   </w.rf>
   <form>pekárně</form>
   <lemma>pekárna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id63437-x1-20825">
   <w.rf>
    <LM>w#w-id63437-x1-20825</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63452-7">
   <w.rf>
    <LM>w#w-id63452-7</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m973-id63452-8">
   <w.rf>
    <LM>w#w-id63452-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63452-9">
   <w.rf>
    <LM>w#w-id63452-9</LM>
   </w.rf>
   <form>nedělo</form>
   <lemma>dít-2_^(říkat)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m973-id63437-x1-20826">
   <w.rf>
    <LM>w#w-id63437-x1-20826</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63471-2">
   <w.rf>
    <LM>w#w-id63471-2</LM>
   </w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m973-id63471-3">
   <w.rf>
    <LM>w#w-id63471-3</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m973-id63480-1">
   <w.rf>
    <LM>w#w-id63480-1</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63480-2">
   <w.rf>
    <LM>w#w-id63480-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63480-3">
   <w.rf>
    <LM>w#w-id63480-3</LM>
   </w.rf>
   <form>noci</form>
   <lemma>noc</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m973-id63480-4">
   <w.rf>
    <LM>w#w-id63480-4</LM>
   </w.rf>
   <form>odvezli</form>
   <lemma>odvézt</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m973-id63437-x1-490">
   <w.rf>
    <LM>w#w-id63437-x1-490</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-491">
  <m id="m973-id63490-1">
   <w.rf>
    <LM>w#w-id63490-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63490-2">
   <w.rf>
    <LM>w#w-id63490-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id63490-3">
   <w.rf>
    <LM>w#w-id63490-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63437-x1-20829">
   <w.rf>
    <LM>w#w-id63437-x1-20829</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id63490-4">
   <w.rf>
    <LM>w#w-id63490-4</LM>
   </w.rf>
   <form>dozvěděl</form>
   <lemma>dozvědět</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-d-id101426">
   <w.rf>
    <LM>w#w-d-id101426</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63490-6">
   <w.rf>
    <LM>w#w-id63490-6</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63490-7">
   <w.rf>
    <LM>w#w-id63490-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m973-id63500-1">
   <w.rf>
    <LM>w#w-id63500-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63490-8">
   <w.rf>
    <LM>w#w-id63490-8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m973-id63490-9">
   <w.rf>
    <LM>w#w-id63490-9</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m973-id63500-2">
   <w.rf>
    <LM>w#w-id63500-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63500-4">
   <w.rf>
    <LM>w#w-id63500-4</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m973-id63500-5">
   <w.rf>
    <LM>w#w-id63500-5</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m973-id63500-3">
   <w.rf>
    <LM>w#w-id63500-3</LM>
   </w.rf>
   <form>bavili</form>
   <lemma>bavit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id63437-x1-20838">
   <w.rf>
    <LM>w#w-id63437-x1-20838</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-20831">
  <m id="m973-id63500-8">
   <w.rf>
    <LM>w#w-id63500-8</LM>
   </w.rf>
   <form>Povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-20831-20840">
   <w.rf>
    <LM>w#w-20831-20840</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-20831-20841">
   <w.rf>
    <LM>w#w-20831-20841</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63500-9">
   <w.rf>
    <LM>w#w-id63500-9</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m973-id63500-10">
   <w.rf>
    <LM>w#w-id63500-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m973-id63500-11">
   <w.rf>
    <LM>w#w-id63500-11</LM>
   </w.rf>
   <form>napsal</form>
   <lemma>napsat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m973-20831-20843">
   <w.rf>
    <LM>w#w-20831-20843</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-20831-20844">
   <w.rf>
    <LM>w#w-20831-20844</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-493">
  <m id="m973-id63500-13">
   <w.rf>
    <LM>w#w-id63500-13</LM>
   </w.rf>
   <form>Povídám</form>
   <lemma>povídat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-20831-20845">
   <w.rf>
    <LM>w#w-20831-20845</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-20831-20846">
   <w.rf>
    <LM>w#w-20831-20846</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63500-14">
   <w.rf>
    <LM>w#w-id63500-14</LM>
   </w.rf>
   <form>Že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63500-15">
   <w.rf>
    <LM>w#w-id63500-15</LM>
   </w.rf>
   <form>chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id63500-16">
   <w.rf>
    <LM>w#w-id63500-16</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-20831-20848">
   <w.rf>
    <LM>w#w-20831-20848</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-20831-20849">
   <w.rf>
    <LM>w#w-20831-20849</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-494">
  <m id="m973-20831-20851">
   <w.rf>
    <LM>w#w-20831-20851</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63500-19">
   <w.rf>
    <LM>w#w-id63500-19</LM>
   </w.rf>
   <form>Člověče</form>
   <lemma>člověk</lemma>
   <tag>NNMS5-----A----</tag>
  </m>
  <m id="m973-id63511-1">
   <w.rf>
    <LM>w#w-id63511-1</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63511-2">
   <w.rf>
    <LM>w#w-id63511-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m973-id63511-3">
   <w.rf>
    <LM>w#w-id63511-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m973-id63511-4">
   <w.rf>
    <LM>w#w-id63511-4</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m973-20831-20853">
   <w.rf>
    <LM>w#w-20831-20853</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63511-7">
   <w.rf>
    <LM>w#w-id63511-7</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m973-id63511-8">
   <w.rf>
    <LM>w#w-id63511-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63511-9">
   <w.rf>
    <LM>w#w-id63511-9</LM>
   </w.rf>
   <form>radši</form>
   <lemma>rád-2</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m973-id63511-10">
   <w.rf>
    <LM>w#w-id63511-10</LM>
   </w.rf>
   <form>vrátím</form>
   <lemma>vrátit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m973-id63511-11">
   <w.rf>
    <LM>w#w-id63511-11</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-20831-20854">
   <w.rf>
    <LM>w#w-20831-20854</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63511-14">
   <w.rf>
    <LM>w#w-id63511-14</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m973-id63511-16">
   <w.rf>
    <LM>w#w-id63511-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63511-15">
   <w.rf>
    <LM>w#w-id63511-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63511-17">
   <w.rf>
    <LM>w#w-id63511-17</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m973-id63511-18">
   <w.rf>
    <LM>w#w-id63511-18</LM>
   </w.rf>
   <form>stát</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m973-20831-20855">
   <w.rf>
    <LM>w#w-20831-20855</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-20831-20856">
   <w.rf>
    <LM>w#w-20831-20856</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-20857">
  <m id="m973-id63521-5">
   <w.rf>
    <LM>w#w-id63521-5</LM>
   </w.rf>
   <form>Domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63521-4">
   <w.rf>
    <LM>w#w-id63521-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63521-6">
   <w.rf>
    <LM>w#w-id63521-6</LM>
   </w.rf>
   <form>nevrátil</form>
   <lemma>vrátit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m973-20857-20868">
   <w.rf>
    <LM>w#w-20857-20868</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63531-3">
   <w.rf>
    <LM>w#w-id63531-3</LM>
   </w.rf>
   <form>brali</form>
   <lemma>brát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m973-id63531-2">
   <w.rf>
    <LM>w#w-id63531-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-id63531-4">
   <w.rf>
    <LM>w#w-id63531-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63531-5">
   <w.rf>
    <LM>w#w-id63531-5</LM>
   </w.rf>
   <form>projev</form>
   <lemma>projev</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m973-id63531-6">
   <w.rf>
    <LM>w#w-id63531-6</LM>
   </w.rf>
   <form>nedůvěry</form>
   <lemma>nedůvěra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m973-d-id102266">
   <w.rf>
    <LM>w#w-d-id102266</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63437-x2">
  <m id="m973-id63536-3">
   <w.rf>
    <LM>w#w-id63536-3</LM>
   </w.rf>
   <form>Chápu</form>
   <lemma>chápat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m973-id63536-2">
   <w.rf>
    <LM>w#w-id63536-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m973-d-id102337">
   <w.rf>
    <LM>w#w-d-id102337</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-id63437-x3">
  <m id="m973-id63550-3">
   <w.rf>
    <LM>w#w-id63550-3</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m973-id63550-2">
   <w.rf>
    <LM>w#w-id63550-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m973-id63550-7">
   <w.rf>
    <LM>w#w-id63550-7</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m973-id63550-8">
   <w.rf>
    <LM>w#w-id63550-8</LM>
   </w.rf>
   <form>schylovalo</form>
   <lemma>schylovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m973-id63550-4">
   <w.rf>
    <LM>w#w-id63550-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m973-id63550-6">
   <w.rf>
    <LM>w#w-id63550-6</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m973-id63437-x3-503">
   <w.rf>
    <LM>w#w-id63437-x3-503</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m973-26797_03-504">
  <m id="m973-id63560-1">
   <w.rf>
    <LM>w#w-id63560-1</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m973-id63560-2">
   <w.rf>
    <LM>w#w-id63560-2</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-d-id102514">
   <w.rf>
    <LM>w#w-d-id102514</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63560-3">
   <w.rf>
    <LM>w#w-id63560-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63560-4">
   <w.rf>
    <LM>w#w-id63560-4</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m973-id63560-5">
   <w.rf>
    <LM>w#w-id63560-5</LM>
   </w.rf>
   <form>nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m973-d-id102569">
   <w.rf>
    <LM>w#w-d-id102569</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m973-id63560-6">
   <w.rf>
    <LM>w#w-id63560-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m973-id63560-7">
   <w.rf>
    <LM>w#w-id63560-7</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m973-id63560-8">
   <w.rf>
    <LM>w#w-id63560-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m973-504-505">
   <w.rf>
    <LM>w#w-504-505</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
