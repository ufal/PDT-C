<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_976.03.w.gz" />
  </references>
 </head>
 <s id="m976-26797_06-1151">
  <m id="m976-id62733-1">
   <w.rf>
    <LM>w#w-id62733-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id62733-2">
   <w.rf>
    <LM>w#w-id62733-2</LM>
   </w.rf>
   <form>březnu</form>
   <lemma>březen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-id62733-3">
   <w.rf>
    <LM>w#w-id62733-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m976-id62733-4">
   <w.rf>
    <LM>w#w-id62733-4</LM>
   </w.rf>
   <form>Sokolovo</form>
   <lemma>Sokolovo_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m976-d-id93341">
   <w.rf>
    <LM>w#w-d-id93341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id62749-x1">
  <m id="m976-id62764-1">
   <w.rf>
    <LM>w#w-id62764-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id62764-2">
   <w.rf>
    <LM>w#w-id62764-2</LM>
   </w.rf>
   <form>březnu</form>
   <lemma>březen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-id62764-3">
   <w.rf>
    <LM>w#w-id62764-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m976-id62764-4">
   <w.rf>
    <LM>w#w-id62764-4</LM>
   </w.rf>
   <form>Sokolovo</form>
   <lemma>Sokolovo_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m976-d-id93831">
   <w.rf>
    <LM>w#w-d-id93831</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-421">
  <m id="m976-id62774-2">
   <w.rf>
    <LM>w#w-id62774-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id62774-3">
   <w.rf>
    <LM>w#w-id62774-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m976-id62774-4">
   <w.rf>
    <LM>w#w-id62774-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m976-id62774-6">
   <w.rf>
    <LM>w#w-id62774-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62774-5">
   <w.rf>
    <LM>w#w-id62774-5</LM>
   </w.rf>
   <form>vezmete</form>
   <lemma>vzít</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m976-421-457">
   <w.rf>
    <LM>w#w-421-457</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-421-458">
   <w.rf>
    <LM>w#w-421-458</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id62774-8">
   <w.rf>
    <LM>w#w-id62774-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id62774-10">
   <w.rf>
    <LM>w#w-id62774-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id62774-12">
   <w.rf>
    <LM>w#w-id62774-12</LM>
   </w.rf>
   <form>Veseloje</form>
   <lemma>Veseloje_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m976-id62774-13">
   <w.rf>
    <LM>w#w-id62774-13</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id62774-14">
   <w.rf>
    <LM>w#w-id62774-14</LM>
   </w.rf>
   <form>pěším</form>
   <lemma>pěší</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m976-id62774-15">
   <w.rf>
    <LM>w#w-id62774-15</LM>
   </w.rf>
   <form>pochodem</form>
   <lemma>pochod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m976-d-id94083">
   <w.rf>
    <LM>w#w-d-id94083</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62785-3">
   <w.rf>
    <LM>w#w-id62785-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62785-4">
   <w.rf>
    <LM>w#w-id62785-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m976-id62785-5">
   <w.rf>
    <LM>w#w-id62785-5</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m976-id62785-6">
   <w.rf>
    <LM>w#w-id62785-6</LM>
   </w.rf>
   <form>neodvezl</form>
   <lemma>odvézt</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m976-421-389">
   <w.rf>
    <LM>w#w-421-389</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-390">
  <m id="m976-id62785-10">
   <w.rf>
    <LM>w#w-id62785-10</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id62785-11">
   <w.rf>
    <LM>w#w-id62785-11</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m976-id62785-8">
   <w.rf>
    <LM>w#w-id62785-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id62785-9">
   <w.rf>
    <LM>w#w-id62785-9</LM>
   </w.rf>
   <form>strávili</form>
   <lemma>strávit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id62785-12">
   <w.rf>
    <LM>w#w-id62785-12</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-421-443">
   <w.rf>
    <LM>w#w-421-443</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m976-421-444">
   <w.rf>
    <LM>w#w-421-444</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m976-421-451">
   <w.rf>
    <LM>w#w-421-451</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62804-1">
   <w.rf>
    <LM>w#w-id62804-1</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-421-446">
   <w.rf>
    <LM>w#w-421-446</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m976-id62804-2">
   <w.rf>
    <LM>w#w-id62804-2</LM>
   </w.rf>
   <form>nehonili</form>
   <lemma>honit</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m976-421-452">
   <w.rf>
    <LM>w#w-421-452</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62814-1">
   <w.rf>
    <LM>w#w-id62814-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id62814-2">
   <w.rf>
    <LM>w#w-id62814-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id62814-3">
   <w.rf>
    <LM>w#w-id62814-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id62814-5">
   <w.rf>
    <LM>w#w-id62814-5</LM>
   </w.rf>
   <form>Veseloje</form>
   <lemma>Veseloje_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m976-id62814-6">
   <w.rf>
    <LM>w#w-id62814-6</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id62814-7">
   <w.rf>
    <LM>w#w-id62814-7</LM>
   </w.rf>
   <form>přijít</form>
   <lemma>přijít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m976-id62814-8">
   <w.rf>
    <LM>w#w-id62814-8</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62814-11">
   <w.rf>
    <LM>w#w-id62814-11</LM>
   </w.rf>
   <form>koncem</form>
   <lemma>konec</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m976-id62814-12">
   <w.rf>
    <LM>w#w-id62814-12</LM>
   </w.rf>
   <form>března</form>
   <lemma>březen</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-390-403">
   <w.rf>
    <LM>w#w-390-403</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-404">
  <m id="m976-id62824-2">
   <w.rf>
    <LM>w#w-id62824-2</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id62824-3">
   <w.rf>
    <LM>w#w-id62824-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id62824-8">
   <w.rf>
    <LM>w#w-id62824-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62824-4">
   <w.rf>
    <LM>w#w-id62824-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id62824-5">
   <w.rf>
    <LM>w#w-id62824-5</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62824-6">
   <w.rf>
    <LM>w#w-id62824-6</LM>
   </w.rf>
   <form>duben</form>
   <lemma>duben</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-id62824-10">
   <w.rf>
    <LM>w#w-id62824-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id62834-1">
   <w.rf>
    <LM>w#w-id62834-1</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m976-id62834-2">
   <w.rf>
    <LM>w#w-id62834-2</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m976-id62834-3">
   <w.rf>
    <LM>w#w-id62834-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id62834-4">
   <w.rf>
    <LM>w#w-id62834-4</LM>
   </w.rf>
   <form>květnu</form>
   <lemma>květen</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-d-id94781">
   <w.rf>
    <LM>w#w-d-id94781</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id62749-x2">
  <m id="m976-id62749-x2-532">
   <w.rf>
    <LM>w#w-id62749-x2-532</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id62839-1">
   <w.rf>
    <LM>w#w-id62839-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id62839-2">
   <w.rf>
    <LM>w#w-id62839-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-d-id94829">
   <w.rf>
    <LM>w#w-d-id94829</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id62749-x3">
  <m id="m976-id62862-4">
   <w.rf>
    <LM>w#w-id62862-4</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62862-5">
   <w.rf>
    <LM>w#w-id62862-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id62862-7">
   <w.rf>
    <LM>w#w-id62862-7</LM>
   </w.rf>
   <form>odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62872-1">
   <w.rf>
    <LM>w#w-id62872-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id62872-2">
   <w.rf>
    <LM>w#w-id62872-2</LM>
   </w.rf>
   <form>odtransportováni</form>
   <lemma>odtransportovat</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m976-id62749-x3-540">
   <w.rf>
    <LM>w#w-id62749-x3-540</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62872-3">
   <w.rf>
    <LM>w#w-id62872-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62872-4">
   <w.rf>
    <LM>w#w-id62872-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id62872-5">
   <w.rf>
    <LM>w#w-id62872-5</LM>
   </w.rf>
   <form>pěšky</form>
   <lemma>pěšky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-d-id95112">
   <w.rf>
    <LM>w#w-d-id95112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62881-1">
   <w.rf>
    <LM>w#w-id62881-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id62749-x3-541">
   <w.rf>
    <LM>w#w-id62749-x3-541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62749-x3-542">
   <w.rf>
    <LM>w#w-id62749-x3-542</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62749-x3-543">
   <w.rf>
    <LM>w#w-id62749-x3-543</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-545">
  <m id="m976-id62909-1">
   <w.rf>
    <LM>w#w-id62909-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id62909-2">
   <w.rf>
    <LM>w#w-id62909-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id62909-3">
   <w.rf>
    <LM>w#w-id62909-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id62909-4">
   <w.rf>
    <LM>w#w-id62909-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m976-d-id95268">
   <w.rf>
    <LM>w#w-d-id95268</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id62956-x1">
  <m id="m976-id62956-x1-431">
   <w.rf>
    <LM>w#w-id62956-x1-431</LM>
   </w.rf>
   <form>Novochopjorsk</form>
   <lemma>Novochopjorsk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m976-id62956-x1-1652">
   <w.rf>
    <LM>w#w-id62956-x1-1652</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1655">
  <m id="m976-1655-432">
   <w.rf>
    <LM>w#w-1655-432</LM>
   </w.rf>
   <form>Novochopjorsk</form>
   <lemma>Novochopjorsk_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m976-1655-1659">
   <w.rf>
    <LM>w#w-1655-1659</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1523">
  <m id="m976-id62990-1">
   <w.rf>
    <LM>w#w-id62990-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m976-id62990-2">
   <w.rf>
    <LM>w#w-id62990-2</LM>
   </w.rf>
   <form>skleróza</form>
   <lemma>skleróza</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id62990-3">
   <w.rf>
    <LM>w#w-id62990-3</LM>
   </w.rf>
   <form>pracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m976-id62990-4">
   <w.rf>
    <LM>w#w-id62990-4</LM>
   </w.rf>
   <form>vydatně</form>
   <lemma>vydatně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-d-id95531">
   <w.rf>
    <LM>w#w-d-id95531</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id62990-5">
   <w.rf>
    <LM>w#w-id62990-5</LM>
   </w.rf>
   <form>věřte</form>
   <lemma>věřit</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m976-id62990-6">
   <w.rf>
    <LM>w#w-id62990-6</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m976-d-id95570">
   <w.rf>
    <LM>w#w-d-id95570</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id62956-x2">
  <m id="m976-id63005-1">
   <w.rf>
    <LM>w#w-id63005-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63005-2">
   <w.rf>
    <LM>w#w-id63005-2</LM>
   </w.rf>
   <form>Novochopjorsku</form>
   <lemma>Novochopjorsk_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-id63005-3">
   <w.rf>
    <LM>w#w-id63005-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63005-4">
   <w.rf>
    <LM>w#w-id63005-4</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63014-1">
   <w.rf>
    <LM>w#w-id63014-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63014-2">
   <w.rf>
    <LM>w#w-id63014-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63014-5">
   <w.rf>
    <LM>w#w-id63014-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63014-4">
   <w.rf>
    <LM>w#w-id63014-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63014-6">
   <w.rf>
    <LM>w#w-id63014-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63014-8">
   <w.rf>
    <LM>w#w-id63014-8</LM>
   </w.rf>
   <form>velitelem</form>
   <lemma>velitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m976-id63014-9">
   <w.rf>
    <LM>w#w-id63014-9</LM>
   </w.rf>
   <form>čety</form>
   <lemma>četa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-d-id95579">
   <w.rf>
    <LM>w#w-d-id95579</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1765">
  <m id="m976-1765-1768">
   <w.rf>
    <LM>w#w-1765-1768</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m976-1765-1769">
   <w.rf>
    <LM>w#w-1765-1769</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-1765-1770">
   <w.rf>
    <LM>w#w-1765-1770</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-1765-1771">
   <w.rf>
    <LM>w#w-1765-1771</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-1765-1774">
   <w.rf>
    <LM>w#w-1765-1774</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-1765-1775">
   <w.rf>
    <LM>w#w-1765-1775</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-1765-1772">
   <w.rf>
    <LM>w#w-1765-1772</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63054-x1">
  <m id="m976-id63078-1">
   <w.rf>
    <LM>w#w-id63078-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m976-id63078-2">
   <w.rf>
    <LM>w#w-id63078-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63078-3">
   <w.rf>
    <LM>w#w-id63078-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63078-5">
   <w.rf>
    <LM>w#w-id63078-5</LM>
   </w.rf>
   <form>četař</form>
   <lemma>četař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-id63054-x1-1785">
   <w.rf>
    <LM>w#w-id63054-x1-1785</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63078-6">
   <w.rf>
    <LM>w#w-id63078-6</LM>
   </w.rf>
   <form>velitel</form>
   <lemma>velitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-id63078-7">
   <w.rf>
    <LM>w#w-id63078-7</LM>
   </w.rf>
   <form>čety</form>
   <lemma>četa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-id63054-x1-1786">
   <w.rf>
    <LM>w#w-id63054-x1-1786</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2115">
  <m id="m976-id63054-x1-1788">
   <w.rf>
    <LM>w#w-id63054-x1-1788</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63078-12">
   <w.rf>
    <LM>w#w-id63078-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63078-13">
   <w.rf>
    <LM>w#w-id63078-13</LM>
   </w.rf>
   <form>důstojnickou</form>
   <lemma>důstojnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m976-id63078-14">
   <w.rf>
    <LM>w#w-id63078-14</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m976-id63054-x1-1789">
   <w.rf>
    <LM>w#w-id63054-x1-1789</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63054-x1-1790">
   <w.rf>
    <LM>w#w-id63054-x1-1790</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63078-19">
   <w.rf>
    <LM>w#w-id63078-19</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63078-16">
   <w.rf>
    <LM>w#w-id63078-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63078-15">
   <w.rf>
    <LM>w#w-id63078-15</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m976-id63078-17">
   <w.rf>
    <LM>w#w-id63078-17</LM>
   </w.rf>
   <form>důstojníkem</form>
   <lemma>důstojník</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m976-id63054-x1-1800">
   <w.rf>
    <LM>w#w-id63054-x1-1800</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1793">
  <m id="m976-id63099-2">
   <w.rf>
    <LM>w#w-id63099-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63099-3">
   <w.rf>
    <LM>w#w-id63099-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63099-8">
   <w.rf>
    <LM>w#w-id63099-8</LM>
   </w.rf>
   <form>pochopitelně</form>
   <lemma>pochopitelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63099-4">
   <w.rf>
    <LM>w#w-id63099-4</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63099-5">
   <w.rf>
    <LM>w#w-id63099-5</LM>
   </w.rf>
   <form>usilovný</form>
   <lemma>usilovný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m976-id63099-6">
   <w.rf>
    <LM>w#w-id63099-6</LM>
   </w.rf>
   <form>výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-1793-1806">
   <w.rf>
    <LM>w#w-1793-1806</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63099-10">
   <w.rf>
    <LM>w#w-id63099-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63099-9">
   <w.rf>
    <LM>w#w-id63099-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63099-11">
   <w.rf>
    <LM>w#w-id63099-11</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63099-12">
   <w.rf>
    <LM>w#w-id63099-12</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63099-13">
   <w.rf>
    <LM>w#w-id63099-13</LM>
   </w.rf>
   <form>krajina</form>
   <lemma>krajina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-1793-445">
   <w.rf>
    <LM>w#w-1793-445</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-446">
  <m id="m976-id63110-1">
   <w.rf>
    <LM>w#w-id63110-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m976-id63099-14">
   <w.rf>
    <LM>w#w-id63099-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63110-4">
   <w.rf>
    <LM>w#w-id63110-4</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m976-id63110-2">
   <w.rf>
    <LM>w#w-id63110-2</LM>
   </w.rf>
   <form>tancovačky</form>
   <lemma>tancovačka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m976-1793-1808">
   <w.rf>
    <LM>w#w-1793-1808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63110-5">
   <w.rf>
    <LM>w#w-id63110-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63110-7">
   <w.rf>
    <LM>w#w-id63110-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63129-5">
   <w.rf>
    <LM>w#w-id63129-5</LM>
   </w.rf>
   <form>poměr</form>
   <lemma>poměr_^(vztah_mezi_2_věcmi/lidmi)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m976-1793-1810">
   <w.rf>
    <LM>w#w-1793-1810</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63129-1">
   <w.rf>
    <LM>w#w-id63129-1</LM>
   </w.rf>
   <form>dejme</form>
   <lemma>dát-1</lemma>
   <tag>Vi-P---1--A-P--</tag>
  </m>
  <m id="m976-id63129-2">
   <w.rf>
    <LM>w#w-id63129-2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m976-d-id96731">
   <w.rf>
    <LM>w#w-d-id96731</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63129-6">
   <w.rf>
    <LM>w#w-id63129-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id63129-7">
   <w.rf>
    <LM>w#w-id63129-7</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m976-id63129-8">
   <w.rf>
    <LM>w#w-id63129-8</LM>
   </w.rf>
   <form>ku</form>
   <lemma>k-1</lemma>
   <tag>RV--3---------1</tag>
  </m>
  <m id="m976-id63129-9">
   <w.rf>
    <LM>w#w-id63129-9</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS3----------</tag>
  </m>
  <m id="m976-d-id96849">
   <w.rf>
    <LM>w#w-d-id96849</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63129-10">
   <w.rf>
    <LM>w#w-id63129-10</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m976-id63129-11">
   <w.rf>
    <LM>w#w-id63129-11</LM>
   </w.rf>
   <form>děvčat</form>
   <lemma>děvče</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m976-id63129-12">
   <w.rf>
    <LM>w#w-id63129-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63129-13">
   <w.rf>
    <LM>w#w-id63129-13</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnMS4----------</tag>
  </m>
  <m id="m976-id63129-14">
   <w.rf>
    <LM>w#w-id63129-14</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m976-d-id96937">
   <w.rf>
    <LM>w#w-d-id96937</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1812">
  <m id="m976-id63139-1">
   <w.rf>
    <LM>w#w-id63139-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id63139-2">
   <w.rf>
    <LM>w#w-id63139-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m976-id63139-5">
   <w.rf>
    <LM>w#w-id63139-5</LM>
   </w.rf>
   <form>vyložené</form>
   <lemma>vyložený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m976-id63139-3">
   <w.rf>
    <LM>w#w-id63139-3</LM>
   </w.rf>
   <form>eldorádo</form>
   <lemma>eldorádo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m976-1812-1837">
   <w.rf>
    <LM>w#w-1812-1837</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1823">
  <m id="m976-id63158-2">
   <w.rf>
    <LM>w#w-id63158-2</LM>
   </w.rf>
   <form>Jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m976-id63158-4">
   <w.rf>
    <LM>w#w-id63158-4</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m976-id63158-5">
   <w.rf>
    <LM>w#w-id63158-5</LM>
   </w.rf>
   <form>voják</form>
   <lemma>voják</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-id63158-6">
   <w.rf>
    <LM>w#w-id63158-6</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63158-7">
   <w.rf>
    <LM>w#w-id63158-7</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m976-id63158-8">
   <w.rf>
    <LM>w#w-id63158-8</LM>
   </w.rf>
   <form>milenky</form>
   <lemma>milenka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m976-id63158-9">
   <w.rf>
    <LM>w#w-id63158-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63158-10">
   <w.rf>
    <LM>w#w-id63158-10</LM>
   </w.rf>
   <form>nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m976-id63158-11">
   <w.rf>
    <LM>w#w-id63158-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m976-id63158-12">
   <w.rf>
    <LM>w#w-id63158-12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m976-id63158-13">
   <w.rf>
    <LM>w#w-id63158-13</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m976-id63158-14">
   <w.rf>
    <LM>w#w-id63158-14</LM>
   </w.rf>
   <form>rady</form>
   <lemma>rada-1_^(př._dát_někomu_dobrou_radu;poradní_sbor)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m976-1823-1851">
   <w.rf>
    <LM>w#w-1823-1851</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-1844">
  <m id="m976-id63178-1">
   <w.rf>
    <LM>w#w-id63178-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id63178-2">
   <w.rf>
    <LM>w#w-id63178-2</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63178-3">
   <w.rf>
    <LM>w#w-id63178-3</LM>
   </w.rf>
   <form>nepatří</form>
   <lemma>patřit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m976-d-id97389">
   <w.rf>
    <LM>w#w-d-id97389</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63181-x1">
  <m id="m976-id63196-1">
   <w.rf>
    <LM>w#w-id63196-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63196-2">
   <w.rf>
    <LM>w#w-id63196-2</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m976-d-id97485">
   <w.rf>
    <LM>w#w-d-id97485</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63199-x1">
  <m id="m976-id63214-6">
   <w.rf>
    <LM>w#w-id63214-6</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63214-3">
   <w.rf>
    <LM>w#w-id63214-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63214-4">
   <w.rf>
    <LM>w#w-id63214-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63214-5">
   <w.rf>
    <LM>w#w-id63214-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63199-x1-2178">
   <w.rf>
    <LM>w#w-id63199-x1-2178</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m976-id63250-2">
   <w.rf>
    <LM>w#w-id63250-2</LM>
   </w.rf>
   <form>zážitky</form>
   <lemma>zážitek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m976-id63199-x1-2175">
   <w.rf>
    <LM>w#w-id63199-x1-2175</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2182">
  <m id="m976-2182-2185">
   <w.rf>
    <LM>w#w-2182-2185</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-2182-2186">
   <w.rf>
    <LM>w#w-2182-2186</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-2182-2187">
   <w.rf>
    <LM>w#w-2182-2187</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-2182-2188">
   <w.rf>
    <LM>w#w-2182-2188</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-2182-2189">
   <w.rf>
    <LM>w#w-2182-2189</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS2----------</tag>
  </m>
  <m id="m976-2182-2191">
   <w.rf>
    <LM>w#w-2182-2191</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-2182-2190">
   <w.rf>
    <LM>w#w-2182-2190</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-2182-2192">
   <w.rf>
    <LM>w#w-2182-2192</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2162">
  <m id="m976-id63250-3">
   <w.rf>
    <LM>w#w-id63250-3</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-2162-2210">
   <w.rf>
    <LM>w#w-2162-2210</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63250-6">
   <w.rf>
    <LM>w#w-id63250-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63250-5">
   <w.rf>
    <LM>w#w-id63250-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63250-7">
   <w.rf>
    <LM>w#w-id63250-7</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63250-8">
   <w.rf>
    <LM>w#w-id63250-8</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS2----------</tag>
  </m>
  <m id="m976-d-id97837">
   <w.rf>
    <LM>w#w-d-id97837</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2213">
  <m id="m976-id63250-10">
   <w.rf>
    <LM>w#w-id63250-10</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63250-11">
   <w.rf>
    <LM>w#w-id63250-11</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63250-14">
   <w.rf>
    <LM>w#w-id63250-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63250-15">
   <w.rf>
    <LM>w#w-id63250-15</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63250-16">
   <w.rf>
    <LM>w#w-id63250-16</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m976-2162-2207">
   <w.rf>
    <LM>w#w-2162-2207</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63250-17">
   <w.rf>
    <LM>w#w-id63250-17</LM>
   </w.rf>
   <form>Bjedrich</form>
   <lemma>Bjedrich_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-2162-2208">
   <w.rf>
    <LM>w#w-2162-2208</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-d-id97678">
   <w.rf>
    <LM>w#w-d-id97678</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63272-x1">
  <m id="m976-id63297-2">
   <w.rf>
    <LM>w#w-id63297-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63297-3">
   <w.rf>
    <LM>w#w-id63297-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id63297-5">
   <w.rf>
    <LM>w#w-id63297-5</LM>
   </w.rf>
   <form>hodná</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63297-6">
   <w.rf>
    <LM>w#w-id63297-6</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63272-x1-2340">
   <w.rf>
    <LM>w#w-id63272-x1-2340</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2333">
  <m id="m976-id63316-6">
   <w.rf>
    <LM>w#w-id63316-6</LM>
   </w.rf>
   <form>Odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63316-7">
   <w.rf>
    <LM>w#w-id63316-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63316-5">
   <w.rf>
    <LM>w#w-id63316-5</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63316-8">
   <w.rf>
    <LM>w#w-id63316-8</LM>
   </w.rf>
   <form>putovali</form>
   <lemma>putovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-2333-2344">
   <w.rf>
    <LM>w#w-2333-2344</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m976-2333-2347">
   <w.rf>
    <LM>w#w-2333-2347</LM>
   </w.rf>
   <form>Kyjevu</form>
   <lemma>Kyjev_;G</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m976-2333-2348">
   <w.rf>
    <LM>w#w-2333-2348</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63326-1">
   <w.rf>
    <LM>w#w-id63326-1</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m976-id63326-2">
   <w.rf>
    <LM>w#w-id63326-2</LM>
   </w.rf>
   <form>operace</form>
   <lemma>operace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63326-3">
   <w.rf>
    <LM>w#w-id63326-3</LM>
   </w.rf>
   <form>Kyjevská</form>
   <lemma>kyjevský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-d-id98396">
   <w.rf>
    <LM>w#w-d-id98396</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63272-x2">
  <m id="m976-id63340-4">
   <w.rf>
    <LM>w#w-id63340-4</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63340-7">
   <w.rf>
    <LM>w#w-id63340-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63340-6">
   <w.rf>
    <LM>w#w-id63340-6</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63340-10">
   <w.rf>
    <LM>w#w-id63340-10</LM>
   </w.rf>
   <form>odjeli</form>
   <lemma>odjet</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id63340-11">
   <w.rf>
    <LM>w#w-id63340-11</LM>
   </w.rf>
   <form>transportem</form>
   <lemma>transport</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m976-id63272-x2-2518">
   <w.rf>
    <LM>w#w-id63272-x2-2518</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63272-x2-468">
   <w.rf>
    <LM>w#w-id63272-x2-468</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63340-14">
   <w.rf>
    <LM>w#w-id63340-14</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63340-15">
   <w.rf>
    <LM>w#w-id63340-15</LM>
   </w.rf>
   <form>brigáda</form>
   <lemma>brigáda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63272-x2-2519">
   <w.rf>
    <LM>w#w-id63272-x2-2519</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63350-1">
   <w.rf>
    <LM>w#w-id63350-1</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m976-id63350-2">
   <w.rf>
    <LM>w#w-id63350-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63350-3">
   <w.rf>
    <LM>w#w-id63350-3</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m976-id63350-4">
   <w.rf>
    <LM>w#w-id63350-4</LM>
   </w.rf>
   <form>prapory</form>
   <lemma>prapor</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m976-id63272-x2-466">
   <w.rf>
    <LM>w#w-id63272-x2-466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-467">
  <m id="m976-id63360-1">
   <w.rf>
    <LM>w#w-id63360-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63360-2">
   <w.rf>
    <LM>w#w-id63360-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63360-3">
   <w.rf>
    <LM>w#w-id63360-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63360-4">
   <w.rf>
    <LM>w#w-id63360-4</LM>
   </w.rf>
   <form>prapor</form>
   <lemma>prapor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-id63360-5">
   <w.rf>
    <LM>w#w-id63360-5</LM>
   </w.rf>
   <form>tankový</form>
   <lemma>tankový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m976-id63272-x2-2521">
   <w.rf>
    <LM>w#w-id63272-x2-2521</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63360-8">
   <w.rf>
    <LM>w#w-id63360-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63370-1">
   <w.rf>
    <LM>w#w-id63370-1</LM>
   </w.rf>
   <form>pořádně</form>
   <lemma>pořádně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63360-9">
   <w.rf>
    <LM>w#w-id63360-9</LM>
   </w.rf>
   <form>vybavená</form>
   <lemma>vybavený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-d-id98946">
   <w.rf>
    <LM>w#w-d-id98946</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63382-x1">
  <m id="m976-id63397-1">
   <w.rf>
    <LM>w#w-id63397-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id63397-3">
   <w.rf>
    <LM>w#w-id63397-3</LM>
   </w.rf>
   <form>Novochopjorsku</form>
   <lemma>Novochopjorsk_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-id63397-4">
   <w.rf>
    <LM>w#w-id63397-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id63397-5">
   <w.rf>
    <LM>w#w-id63397-5</LM>
   </w.rf>
   <form>přidali</form>
   <lemma>přidat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id63397-6">
   <w.rf>
    <LM>w#w-id63397-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m976-id63397-7">
   <w.rf>
    <LM>w#w-id63397-7</LM>
   </w.rf>
   <form>vojáci</form>
   <lemma>voják</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m976-id63420-1">
   <w.rf>
    <LM>w#w-id63420-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63420-2">
   <w.rf>
    <LM>w#w-id63420-2</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63420-3">
   <w.rf>
    <LM>w#w-id63420-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-id63420-4">
   <w.rf>
    <LM>w#w-id63420-4</LM>
   </w.rf>
   <form>výcvik</form>
   <lemma>výcvik</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-id63382-x1-2608">
   <w.rf>
    <LM>w#w-id63382-x1-2608</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2611">
  <m id="m976-2611-2614">
   <w.rf>
    <LM>w#w-2611-2614</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-2611-2617">
   <w.rf>
    <LM>w#w-2611-2617</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-2611-2615">
   <w.rf>
    <LM>w#w-2611-2615</LM>
   </w.rf>
   <form>jistě</form>
   <lemma>jistě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-2611-2616">
   <w.rf>
    <LM>w#w-2611-2616</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2586">
  <m id="m976-id63420-6">
   <w.rf>
    <LM>w#w-id63420-6</LM>
   </w.rf>
   <form>Čili</form>
   <lemma>čili-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63420-7">
   <w.rf>
    <LM>w#w-id63420-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63420-8">
   <w.rf>
    <LM>w#w-id63420-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63420-9">
   <w.rf>
    <LM>w#w-id63420-9</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-id63420-10">
   <w.rf>
    <LM>w#w-id63420-10</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63420-11">
   <w.rf>
    <LM>w#w-id63420-11</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63420-12">
   <w.rf>
    <LM>w#w-id63420-12</LM>
   </w.rf>
   <form>instruktor</form>
   <lemma>instruktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-2586-2635">
   <w.rf>
    <LM>w#w-2586-2635</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63420-13">
   <w.rf>
    <LM>w#w-id63420-13</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-2586-2633">
   <w.rf>
    <LM>w#w-2586-2633</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63428-x1">
  <m id="m976-id63444-1">
   <w.rf>
    <LM>w#w-id63444-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63444-3">
   <w.rf>
    <LM>w#w-id63444-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63444-6">
   <w.rf>
    <LM>w#w-id63444-6</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m976-id63444-8">
   <w.rf>
    <LM>w#w-id63444-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63444-9">
   <w.rf>
    <LM>w#w-id63444-9</LM>
   </w.rf>
   <form>instruktor</form>
   <lemma>instruktor</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-d-id99617">
   <w.rf>
    <LM>w#w-d-id99617</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63444-11">
   <w.rf>
    <LM>w#w-id63444-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63463-3">
   <w.rf>
    <LM>w#w-id63463-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63463-4">
   <w.rf>
    <LM>w#w-id63463-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63444-12">
   <w.rf>
    <LM>w#w-id63444-12</LM>
   </w.rf>
   <form>velitelem</form>
   <lemma>velitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m976-id63463-1">
   <w.rf>
    <LM>w#w-id63463-1</LM>
   </w.rf>
   <form>minometné</form>
   <lemma>minometný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m976-id63463-2">
   <w.rf>
    <LM>w#w-id63463-2</LM>
   </w.rf>
   <form>čety</form>
   <lemma>četa</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-id63473-1">
   <w.rf>
    <LM>w#w-id63473-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63473-2">
   <w.rf>
    <LM>w#w-id63473-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63473-3">
   <w.rf>
    <LM>w#w-id63473-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63428-x1-2776">
   <w.rf>
    <LM>w#w-id63428-x1-2776</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63428-x1-2777">
   <w.rf>
    <LM>w#w-id63428-x1-2777</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-d-id99467">
   <w.rf>
    <LM>w#w-d-id99467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63475-x1">
  <m id="m976-id63495-4">
   <w.rf>
    <LM>w#w-id63495-4</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63495-1">
   <w.rf>
    <LM>w#w-id63495-1</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63495-2">
   <w.rf>
    <LM>w#w-id63495-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-id63495-5">
   <w.rf>
    <LM>w#w-id63495-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m976-id63495-6">
   <w.rf>
    <LM>w#w-id63495-6</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m976-id63495-3">
   <w.rf>
    <LM>w#w-id63495-3</LM>
   </w.rf>
   <form>nováčky</form>
   <lemma>nováček</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m976-d-id99980">
   <w.rf>
    <LM>w#w-d-id99980</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63511-x1">
  <m id="m976-id63527-6">
   <w.rf>
    <LM>w#w-id63527-6</LM>
   </w.rf>
   <form>Samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id63527-2">
   <w.rf>
    <LM>w#w-id63527-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id63527-1">
   <w.rf>
    <LM>w#w-id63527-1</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63527-4">
   <w.rf>
    <LM>w#w-id63527-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m976-id63527-5">
   <w.rf>
    <LM>w#w-id63527-5</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m976-id63527-3">
   <w.rf>
    <LM>w#w-id63527-3</LM>
   </w.rf>
   <form>nováčky</form>
   <lemma>nováček</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m976-d-id100158">
   <w.rf>
    <LM>w#w-d-id100158</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63527-7">
   <w.rf>
    <LM>w#w-id63527-7</LM>
   </w.rf>
   <form>nějací</form>
   <lemma>nějaký</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m976-id63527-8">
   <w.rf>
    <LM>w#w-id63527-8</LM>
   </w.rf>
   <form>nováčci</form>
   <lemma>nováček</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m976-id63527-9">
   <w.rf>
    <LM>w#w-id63527-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63511-x1-482">
   <w.rf>
    <LM>w#w-id63511-x1-482</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-483">
  <m id="m976-id63537-1">
   <w.rf>
    <LM>w#w-id63537-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63537-5">
   <w.rf>
    <LM>w#w-id63537-5</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63537-6">
   <w.rf>
    <LM>w#w-id63537-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id63537-7">
   <w.rf>
    <LM>w#w-id63537-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63537-9">
   <w.rf>
    <LM>w#w-id63537-9</LM>
   </w.rf>
   <form>formovaly</form>
   <lemma>formovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m976-id63537-11">
   <w.rf>
    <LM>w#w-id63537-11</LM>
   </w.rf>
   <form>jednotky</form>
   <lemma>jednotka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m976-id63511-x1-2256">
   <w.rf>
    <LM>w#w-id63511-x1-2256</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63547-2">
   <w.rf>
    <LM>w#w-id63547-2</LM>
   </w.rf>
   <form>naplňovaly</form>
   <lemma>naplňovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m976-id63547-1">
   <w.rf>
    <LM>w#w-id63547-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m976-id63547-6">
   <w.rf>
    <LM>w#w-id63547-6</LM>
   </w.rf>
   <form>slovenskými</form>
   <lemma>slovenský</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m976-id63547-7">
   <w.rf>
    <LM>w#w-id63547-7</LM>
   </w.rf>
   <form>přeběhlíky</form>
   <lemma>přeběhlík</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m976-id63547-9">
   <w.rf>
    <LM>w#w-id63547-9</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m976-id63547-10">
   <w.rf>
    <LM>w#w-id63547-10</LM>
   </w.rf>
   <form>slovenské</form>
   <lemma>slovenský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m976-id63547-11">
   <w.rf>
    <LM>w#w-id63547-11</LM>
   </w.rf>
   <form>armády</form>
   <lemma>armáda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-d-id100614">
   <w.rf>
    <LM>w#w-d-id100614</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63511-x2">
  <m id="m976-id63572-1">
   <w.rf>
    <LM>w#w-id63572-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63572-2">
   <w.rf>
    <LM>w#w-id63572-2</LM>
   </w.rf>
   <form>následovala</form>
   <lemma>následovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63511-x2-2435">
   <w.rf>
    <LM>w#w-id63511-x2-2435</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63572-7">
   <w.rf>
    <LM>w#w-id63572-7</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63572-5">
   <w.rf>
    <LM>w#w-id63572-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m976-id63572-6">
   <w.rf>
    <LM>w#w-id63572-6</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63572-8">
   <w.rf>
    <LM>w#w-id63572-8</LM>
   </w.rf>
   <form>zkrátím</form>
   <lemma>zkrátit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m976-d-id100796">
   <w.rf>
    <LM>w#w-d-id100796</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63572-10">
   <w.rf>
    <LM>w#w-id63572-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63582-2">
   <w.rf>
    <LM>w#w-id63582-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m976-id63582-3">
   <w.rf>
    <LM>w#w-id63582-3</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63582-5">
   <w.rf>
    <LM>w#w-id63582-5</LM>
   </w.rf>
   <form>nezvládneme</form>
   <lemma>zvládnout</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m976-id63511-x2-2439">
   <w.rf>
    <LM>w#w-id63511-x2-2439</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63592-3">
   <w.rf>
    <LM>w#w-id63592-3</LM>
   </w.rf>
   <form>akce</form>
   <lemma>akce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63592-4">
   <w.rf>
    <LM>w#w-id63592-4</LM>
   </w.rf>
   <form>Kyjevská</form>
   <lemma>kyjevský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63511-x2-489">
   <w.rf>
    <LM>w#w-id63511-x2-489</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-490">
  <m id="m976-490-492">
   <w.rf>
    <LM>w#w-490-492</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-490-493">
   <w.rf>
    <LM>w#w-490-493</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-490-494">
   <w.rf>
    <LM>w#w-490-494</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m976-490-495">
   <w.rf>
    <LM>w#w-490-495</LM>
   </w.rf>
   <form>Kyjevská</form>
   <lemma>kyjevský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-490-496">
   <w.rf>
    <LM>w#w-490-496</LM>
   </w.rf>
   <form>operace</form>
   <lemma>operace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-490-497">
   <w.rf>
    <LM>w#w-490-497</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63602-1">
   <w.rf>
    <LM>w#w-id63602-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63602-2">
   <w.rf>
    <LM>w#w-id63602-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63620-1">
   <w.rf>
    <LM>w#w-id63620-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63620-2">
   <w.rf>
    <LM>w#w-id63620-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id63620-3">
   <w.rf>
    <LM>w#w-id63620-3</LM>
   </w.rf>
   <form>prvním</form>
   <lemma>první-1</lemma>
   <tag>CrIS6----------</tag>
  </m>
  <m id="m976-id63620-4">
   <w.rf>
    <LM>w#w-id63620-4</LM>
   </w.rf>
   <form>sledu</form>
   <lemma>sled</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-id63620-5">
   <w.rf>
    <LM>w#w-id63620-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id63620-7">
   <w.rf>
    <LM>w#w-id63620-7</LM>
   </w.rf>
   <form>útoku</form>
   <lemma>útok</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m976-id63620-8">
   <w.rf>
    <LM>w#w-id63620-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63620-9">
   <w.rf>
    <LM>w#w-id63620-9</LM>
   </w.rf>
   <form>Kyjev</form>
   <lemma>Kyjev_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-id63511-x2-2456">
   <w.rf>
    <LM>w#w-id63511-x2-2456</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2451">
  <m id="m976-id63630-2">
   <w.rf>
    <LM>w#w-id63630-2</LM>
   </w.rf>
   <form>Nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m976-id63630-3">
   <w.rf>
    <LM>w#w-id63630-3</LM>
   </w.rf>
   <form>vykládat</form>
   <lemma>vykládat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m976-2451-2639">
   <w.rf>
    <LM>w#w-2451-2639</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63630-4">
   <w.rf>
    <LM>w#w-id63630-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63630-5">
   <w.rf>
    <LM>w#w-id63630-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-2451-499">
   <w.rf>
    <LM>w#w-2451-499</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id63630-6">
   <w.rf>
    <LM>w#w-id63630-6</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id63630-7">
   <w.rf>
    <LM>w#w-id63630-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63630-9">
   <w.rf>
    <LM>w#w-id63630-9</LM>
   </w.rf>
   <form>předmostí</form>
   <lemma>předmostí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m976-id63640-2">
   <w.rf>
    <LM>w#w-id63640-2</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63640-4">
   <w.rf>
    <LM>w#w-id63640-4</LM>
   </w.rf>
   <form>pontonové</form>
   <lemma>pontonový</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m976-id63640-5">
   <w.rf>
    <LM>w#w-id63640-5</LM>
   </w.rf>
   <form>mosty</form>
   <lemma>most</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m976-id63640-6">
   <w.rf>
    <LM>w#w-id63640-6</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m976-id63640-7">
   <w.rf>
    <LM>w#w-id63640-7</LM>
   </w.rf>
   <form>stálou</form>
   <lemma>stálý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m976-id63640-8">
   <w.rf>
    <LM>w#w-id63640-8</LM>
   </w.rf>
   <form>palbou</form>
   <lemma>palba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m976-id63640-9">
   <w.rf>
    <LM>w#w-id63640-9</LM>
   </w.rf>
   <form>Němců</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m976-2451-2641">
   <w.rf>
    <LM>w#w-2451-2641</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63660-1">
   <w.rf>
    <LM>w#w-id63660-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-2451-188">
   <w.rf>
    <LM>w#w-2451-188</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63660-2">
   <w.rf>
    <LM>w#w-id63660-2</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63660-3">
   <w.rf>
    <LM>w#w-id63660-3</LM>
   </w.rf>
   <form>následovala</form>
   <lemma>následovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63660-4">
   <w.rf>
    <LM>w#w-id63660-4</LM>
   </w.rf>
   <form>ohromná</form>
   <lemma>ohromný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63660-5">
   <w.rf>
    <LM>w#w-id63660-5</LM>
   </w.rf>
   <form>série</form>
   <lemma>série</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63660-6">
   <w.rf>
    <LM>w#w-id63660-6</LM>
   </w.rf>
   <form>všelijakých</form>
   <lemma>všelijaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m976-id63660-7">
   <w.rf>
    <LM>w#w-id63660-7</LM>
   </w.rf>
   <form>bojů</form>
   <lemma>boj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m976-2451-2649">
   <w.rf>
    <LM>w#w-2451-2649</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-2650">
  <m id="m976-2650-508">
   <w.rf>
    <LM>w#w-2650-508</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-2650-509">
   <w.rf>
    <LM>w#w-2650-509</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-2650-510">
   <w.rf>
    <LM>w#w-2650-510</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-2650-511">
   <w.rf>
    <LM>w#w-2650-511</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-2650-512">
   <w.rf>
    <LM>w#w-2650-512</LM>
   </w.rf>
   <form>Vasylkiva</form>
   <lemma>Vasylkiv_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-2650-515">
   <w.rf>
    <LM>w#w-2650-515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-516">
  <m id="m976-id63688-1">
   <w.rf>
    <LM>w#w-id63688-1</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63688-2">
   <w.rf>
    <LM>w#w-id63688-2</LM>
   </w.rf>
   <form>Vasylkiva</form>
   <lemma>Vasylkiv_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-id63688-3">
   <w.rf>
    <LM>w#w-id63688-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63688-4">
   <w.rf>
    <LM>w#w-id63688-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id63688-5">
   <w.rf>
    <LM>w#w-id63688-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63688-6">
   <w.rf>
    <LM>w#w-id63688-6</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id63688-7">
   <w.rf>
    <LM>w#w-id63688-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63688-8">
   <w.rf>
    <LM>w#w-id63688-8</LM>
   </w.rf>
   <form>Kyjeva</form>
   <lemma>Kyjev_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-d-id101891">
   <w.rf>
    <LM>w#w-d-id101891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63698-1">
   <w.rf>
    <LM>w#w-id63698-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63708-3">
   <w.rf>
    <LM>w#w-id63708-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m976-id63708-4">
   <w.rf>
    <LM>w#w-id63708-4</LM>
   </w.rf>
   <form>hlášeno</form>
   <lemma>hlásit</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m976-d-id102020">
   <w.rf>
    <LM>w#w-d-id102020</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63708-5">
   <w.rf>
    <LM>w#w-id63708-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63708-6">
   <w.rf>
    <LM>w#w-id63708-6</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m976-id63708-7">
   <w.rf>
    <LM>w#w-id63708-7</LM>
   </w.rf>
   <form>navštíví</form>
   <lemma>navštívit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m976-id63708-8">
   <w.rf>
    <LM>w#w-id63708-8</LM>
   </w.rf>
   <form>prezident</form>
   <lemma>prezident</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-id63708-9">
   <w.rf>
    <LM>w#w-id63708-9</LM>
   </w.rf>
   <form>Beneš</form>
   <lemma>Beneš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m976-d-id102107">
   <w.rf>
    <LM>w#w-d-id102107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63511-x3">
  <m id="m976-id63732-1">
   <w.rf>
    <LM>w#w-id63732-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m976-id63732-3">
   <w.rf>
    <LM>w#w-id63732-3</LM>
   </w.rf>
   <form>návštěvě</form>
   <lemma>návštěva</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m976-id63732-4">
   <w.rf>
    <LM>w#w-id63732-4</LM>
   </w.rf>
   <form>nedošlo</form>
   <lemma>dojít</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m976-id63732-5">
   <w.rf>
    <LM>w#w-id63732-5</LM>
   </w.rf>
   <form>zřejmě</form>
   <lemma>zřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id63732-6">
   <w.rf>
    <LM>w#w-id63732-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63732-7">
   <w.rf>
    <LM>w#w-id63732-7</LM>
   </w.rf>
   <form>nějakých</form>
   <lemma>nějaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m976-id63732-8">
   <w.rf>
    <LM>w#w-id63732-8</LM>
   </w.rf>
   <form>vyšších</form>
   <lemma>vysoký</lemma>
   <tag>AAIP2----2A----</tag>
  </m>
  <m id="m976-id63732-9">
   <w.rf>
    <LM>w#w-id63732-9</LM>
   </w.rf>
   <form>politických</form>
   <lemma>politický</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m976-id63732-10">
   <w.rf>
    <LM>w#w-id63732-10</LM>
   </w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m976-id63511-x3-524">
   <w.rf>
    <LM>w#w-id63511-x3-524</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-525">
  <m id="m976-id63742-1">
   <w.rf>
    <LM>w#w-id63742-1</LM>
   </w.rf>
   <form>Oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63742-2">
   <w.rf>
    <LM>w#w-id63742-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id63742-3">
   <w.rf>
    <LM>w#w-id63742-3</LM>
   </w.rf>
   <form>řeklo</form>
   <lemma>říci</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m976-d-id102368">
   <w.rf>
    <LM>w#w-d-id102368</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63752-1">
   <w.rf>
    <LM>w#w-id63752-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63752-2">
   <w.rf>
    <LM>w#w-id63752-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63752-5">
   <w.rf>
    <LM>w#w-id63752-5</LM>
   </w.rf>
   <form>odhalen</form>
   <lemma>odhalit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m976-id63752-6">
   <w.rf>
    <LM>w#w-id63752-6</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m976-id63752-7">
   <w.rf>
    <LM>w#w-id63752-7</LM>
   </w.rf>
   <form>pokus</form>
   <lemma>pokus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m976-id63752-8">
   <w.rf>
    <LM>w#w-id63752-8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63752-9">
   <w.rf>
    <LM>w#w-id63752-9</LM>
   </w.rf>
   <form>atentát</form>
   <lemma>atentát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-id63752-10">
   <w.rf>
    <LM>w#w-id63752-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63752-11">
   <w.rf>
    <LM>w#w-id63752-11</LM>
   </w.rf>
   <form>Beneše</form>
   <lemma>Beneš_;Y</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m976-id63752-12">
   <w.rf>
    <LM>w#w-id63752-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63752-13">
   <w.rf>
    <LM>w#w-id63752-13</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id63752-14">
   <w.rf>
    <LM>w#w-id63752-14</LM>
   </w.rf>
   <form>sovětská</form>
   <lemma>sovětský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63752-15">
   <w.rf>
    <LM>w#w-id63752-15</LM>
   </w.rf>
   <form>vláda</form>
   <lemma>vláda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63752-16">
   <w.rf>
    <LM>w#w-id63752-16</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m976-id63752-17">
   <w.rf>
    <LM>w#w-id63752-17</LM>
   </w.rf>
   <form>zaručit</form>
   <lemma>zaručit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m976-id63752-18">
   <w.rf>
    <LM>w#w-id63752-18</LM>
   </w.rf>
   <form>bezpečnost</form>
   <lemma>bezpečnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m976-id63511-x3-408">
   <w.rf>
    <LM>w#w-id63511-x3-408</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-410">
  <m id="m976-id63763-2">
   <w.rf>
    <LM>w#w-id63763-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63763-3">
   <w.rf>
    <LM>w#w-id63763-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63763-4">
   <w.rf>
    <LM>w#w-id63763-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63763-5">
   <w.rf>
    <LM>w#w-id63763-5</LM>
   </w.rf>
   <form>prožili</form>
   <lemma>prožít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m976-id63763-6">
   <w.rf>
    <LM>w#w-id63763-6</LM>
   </w.rf>
   <form>pěkných</form>
   <lemma>pěkný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m976-id63763-7">
   <w.rf>
    <LM>w#w-id63763-7</LM>
   </w.rf>
   <form>pár</form>
   <lemma>pár-1</lemma>
   <tag>Ca--X----------</tag>
  </m>
  <m id="m976-id63763-8">
   <w.rf>
    <LM>w#w-id63763-8</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m976-id63763-9">
   <w.rf>
    <LM>w#w-id63763-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id63763-11">
   <w.rf>
    <LM>w#w-id63763-11</LM>
   </w.rf>
   <form>krásných</form>
   <lemma>krásný</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m976-id63782-4">
   <w.rf>
    <LM>w#w-id63782-4</LM>
   </w.rf>
   <form>kasárnách</form>
   <lemma>kasárna</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m976-id63828-2">
   <w.rf>
    <LM>w#w-id63828-2</LM>
   </w.rf>
   <form>vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m976-id63828-1">
   <w.rf>
    <LM>w#w-id63828-1</LM>
   </w.rf>
   <form>akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-410-3143">
   <w.rf>
    <LM>w#w-410-3143</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63838-3">
   <w.rf>
    <LM>w#w-id63838-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63838-4">
   <w.rf>
    <LM>w#w-id63838-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63838-5">
   <w.rf>
    <LM>w#w-id63838-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id63838-6">
   <w.rf>
    <LM>w#w-id63838-6</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m976-id63838-7">
   <w.rf>
    <LM>w#w-id63838-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-410-432">
   <w.rf>
    <LM>w#w-410-432</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-410-433">
   <w.rf>
    <LM>w#w-410-433</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-410-434">
   <w.rf>
    <LM>w#w-410-434</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-410-435">
   <w.rf>
    <LM>w#w-410-435</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-410-436">
   <w.rf>
    <LM>w#w-410-436</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63848-1">
   <w.rf>
    <LM>w#w-id63848-1</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-410-442">
   <w.rf>
    <LM>w#w-410-442</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63848-4">
   <w.rf>
    <LM>w#w-id63848-4</LM>
   </w.rf>
   <form>lepší</form>
   <lemma>lepší</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m976-id63848-5">
   <w.rf>
    <LM>w#w-id63848-5</LM>
   </w.rf>
   <form>stravování</form>
   <lemma>stravování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m976-410-526">
   <w.rf>
    <LM>w#w-410-526</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-527">
  <m id="m976-id63848-7">
   <w.rf>
    <LM>w#w-id63848-7</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m976-id63857-1">
   <w.rf>
    <LM>w#w-id63857-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m976-id63857-2">
   <w.rf>
    <LM>w#w-id63857-2</LM>
   </w.rf>
   <form>připravené</form>
   <lemma>připravený_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m976-id63857-3">
   <w.rf>
    <LM>w#w-id63857-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63857-4">
   <w.rf>
    <LM>w#w-id63857-4</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m976-id63857-5">
   <w.rf>
    <LM>w#w-id63857-5</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m976-410-421">
   <w.rf>
    <LM>w#w-410-421</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63857-6">
   <w.rf>
    <LM>w#w-id63857-6</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m976-id63857-7">
   <w.rf>
    <LM>w#w-id63857-7</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m976-id63857-8">
   <w.rf>
    <LM>w#w-id63857-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63857-9">
   <w.rf>
    <LM>w#w-id63857-9</LM>
   </w.rf>
   <form>sešlo</form>
   <lemma>sejít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m976-410-422">
   <w.rf>
    <LM>w#w-410-422</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-423">
  <m id="m976-id63868-1">
   <w.rf>
    <LM>w#w-id63868-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63868-2">
   <w.rf>
    <LM>w#w-id63868-2</LM>
   </w.rf>
   <form>následovala</form>
   <lemma>následovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m976-id63868-3">
   <w.rf>
    <LM>w#w-id63868-3</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63868-4">
   <w.rf>
    <LM>w#w-id63868-4</LM>
   </w.rf>
   <form>série</form>
   <lemma>série</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63868-5">
   <w.rf>
    <LM>w#w-id63868-5</LM>
   </w.rf>
   <form>bojů</form>
   <lemma>boj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m976-id63877-1">
   <w.rf>
    <LM>w#w-id63877-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m976-id63877-2">
   <w.rf>
    <LM>w#w-id63877-2</LM>
   </w.rf>
   <form>Fastova</form>
   <lemma>Fastov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m976-id63877-3">
   <w.rf>
    <LM>w#w-id63877-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m976-id63877-4">
   <w.rf>
    <LM>w#w-id63877-4</LM>
   </w.rf>
   <form>Štědrý</form>
   <lemma>štědrý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m976-id63877-5">
   <w.rf>
    <LM>w#w-id63877-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-d-id103596">
   <w.rf>
    <LM>w#w-d-id103596</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63877-6">
   <w.rf>
    <LM>w#w-id63877-6</LM>
   </w.rf>
   <form>Komunačajka</form>
   <lemma>Komunačajka_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-423-446">
   <w.rf>
    <LM>w#w-423-446</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63896-1">
   <w.rf>
    <LM>w#w-id63896-1</LM>
   </w.rf>
   <form>Ostrožany</form>
   <lemma>Ostrožany_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m976-d-id103685">
   <w.rf>
    <LM>w#w-d-id103685</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63896-8">
   <w.rf>
    <LM>w#w-id63896-8</LM>
   </w.rf>
   <form>ohromná</form>
   <lemma>ohromný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m976-id63896-9">
   <w.rf>
    <LM>w#w-id63896-9</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-id63896-10">
   <w.rf>
    <LM>w#w-id63896-10</LM>
   </w.rf>
   <form>všelijakých</form>
   <lemma>všelijaký</lemma>
   <tag>PZXP2----------</tag>
  </m>
  <m id="m976-id63896-11">
   <w.rf>
    <LM>w#w-id63896-11</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m976-423-452">
   <w.rf>
    <LM>w#w-423-452</LM>
   </w.rf>
   <form>bojů</form>
   <lemma>boj</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m976-423-453">
   <w.rf>
    <LM>w#w-423-453</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-454">
  <m id="m976-id63907-4">
   <w.rf>
    <LM>w#w-id63907-4</LM>
   </w.rf>
   <form>Každou</form>
   <lemma>každý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m976-id63907-5">
   <w.rf>
    <LM>w#w-id63907-5</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m976-id63907-2">
   <w.rf>
    <LM>w#w-id63907-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m976-id63907-3">
   <w.rf>
    <LM>w#w-id63907-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m976-id63907-9">
   <w.rf>
    <LM>w#w-id63907-9</LM>
   </w.rf>
   <form>nasazeni</form>
   <lemma>nasadit</lemma>
   <tag>VsMP----X-APP--</tag>
  </m>
  <m id="m976-id63907-6">
   <w.rf>
    <LM>w#w-id63907-6</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id63907-7">
   <w.rf>
    <LM>w#w-id63907-7</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-454-465">
   <w.rf>
    <LM>w#w-454-465</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63917-1">
   <w.rf>
    <LM>w#w-id63917-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63926-1">
   <w.rf>
    <LM>w#w-id63926-1</LM>
   </w.rf>
   <form>nejhorší</form>
   <lemma>horší</lemma>
   <tag>AANS1----3A----</tag>
  </m>
  <m id="m976-454-466">
   <w.rf>
    <LM>w#w-454-466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-454-467">
   <w.rf>
    <LM>w#w-454-467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-d-id102116">
   <w.rf>
    <LM>w#w-d-id102116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63938-x1">
  <m id="m976-id63938-x1-479">
   <w.rf>
    <LM>w#w-id63938-x1-479</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m976-id63938-x1-480">
   <w.rf>
    <LM>w#w-id63938-x1-480</LM>
   </w.rf>
   <form>osobně</form>
   <lemma>osobně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63953-1">
   <w.rf>
    <LM>w#w-id63953-1</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m976-id63953-2">
   <w.rf>
    <LM>w#w-id63953-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id63953-3">
   <w.rf>
    <LM>w#w-id63953-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZYP4----------</tag>
  </m>
  <m id="m976-id63962-1">
   <w.rf>
    <LM>w#w-id63962-1</LM>
   </w.rf>
   <form>poznatky</form>
   <lemma>poznatek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m976-id63938-x1-590">
   <w.rf>
    <LM>w#w-id63938-x1-590</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id63962-3">
   <w.rf>
    <LM>w#w-id63962-3</LM>
   </w.rf>
   <form>zážitky</form>
   <lemma>zážitek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m976-id63938-x1-586">
   <w.rf>
    <LM>w#w-id63938-x1-586</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m976-id63938-x1-539">
   <w.rf>
    <LM>w#w-id63938-x1-539</LM>
   </w.rf>
   <form>eventuálně</form>
   <lemma>eventuálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id63938-x1-587">
   <w.rf>
    <LM>w#w-id63938-x1-587</LM>
   </w.rf>
   <form>zranění</form>
   <lemma>zranění_^(*3it)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m976-d-id104088">
   <w.rf>
    <LM>w#w-d-id104088</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-id63965-x1">
  <m id="m976-id64008-1">
   <w.rf>
    <LM>w#w-id64008-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id64008-2">
   <w.rf>
    <LM>w#w-id64008-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id64008-4">
   <w.rf>
    <LM>w#w-id64008-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m976-id64008-3">
   <w.rf>
    <LM>w#w-id64008-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m976-id64008-5">
   <w.rf>
    <LM>w#w-id64008-5</LM>
   </w.rf>
   <form>zraněný</form>
   <lemma>zraněný_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m976-id63965-x1-686">
   <w.rf>
    <LM>w#w-id63965-x1-686</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id64008-6">
   <w.rf>
    <LM>w#w-id64008-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m976-id64008-7">
   <w.rf>
    <LM>w#w-id64008-7</LM>
   </w.rf>
   <form>přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m976-id64008-8">
   <w.rf>
    <LM>w#w-id64008-8</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m976-id64008-9">
   <w.rf>
    <LM>w#w-id64008-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m976-id64008-10">
   <w.rf>
    <LM>w#w-id64008-10</LM>
   </w.rf>
   <form>Dukle</form>
   <lemma>Dukla_;G_;m_^(sport._klub;;průsmyk)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m976-id63965-x1-540">
   <w.rf>
    <LM>w#w-id63965-x1-540</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m976-26797_06-541">
  <m id="m976-id64018-2">
   <w.rf>
    <LM>w#w-id64018-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m976-id64018-4">
   <w.rf>
    <LM>w#w-id64018-4</LM>
   </w.rf>
   <form>osobně</form>
   <lemma>osobně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id64018-3">
   <w.rf>
    <LM>w#w-id64018-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m976-id64018-5">
   <w.rf>
    <LM>w#w-id64018-5</LM>
   </w.rf>
   <form>zažil</form>
   <lemma>zažít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m976-id64018-7">
   <w.rf>
    <LM>w#w-id64018-7</LM>
   </w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAIS4----3A----</tag>
  </m>
  <m id="m976-id64018-8">
   <w.rf>
    <LM>w#w-id64018-8</LM>
   </w.rf>
   <form>šok</form>
   <lemma>šok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m976-d-id104643">
   <w.rf>
    <LM>w#w-d-id104643</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id64028-1">
   <w.rf>
    <LM>w#w-id64028-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m976-id64028-3">
   <w.rf>
    <LM>w#w-id64028-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m976-id64038-1">
   <w.rf>
    <LM>w#w-id64038-1</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m976-id64038-2">
   <w.rf>
    <LM>w#w-id64038-2</LM>
   </w.rf>
   <form>prapor</form>
   <lemma>prapor</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m976-id64028-5">
   <w.rf>
    <LM>w#w-id64028-5</LM>
   </w.rf>
   <form>náhle</form>
   <lemma>náhle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m976-id64028-9">
   <w.rf>
    <LM>w#w-id64028-9</LM>
   </w.rf>
   <form>vyslán</form>
   <lemma>vyslat</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m976-id64028-6">
   <w.rf>
    <LM>w#w-id64028-6</LM>
   </w.rf>
   <form>usilovným</form>
   <lemma>usilovný</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m976-id64028-7">
   <w.rf>
    <LM>w#w-id64028-7</LM>
   </w.rf>
   <form>nočním</form>
   <lemma>noční</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m976-id64028-8">
   <w.rf>
    <LM>w#w-id64028-8</LM>
   </w.rf>
   <form>pochodem</form>
   <lemma>pochod</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m976-id64028-10">
   <w.rf>
    <LM>w#w-id64028-10</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m976-id64028-11">
   <w.rf>
    <LM>w#w-id64028-11</LM>
   </w.rf>
   <form>dobytí</form>
   <lemma>dobytí_^(*3ýt)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m976-id64048-1">
   <w.rf>
    <LM>w#w-id64048-1</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m976-d-id104920">
   <w.rf>
    <LM>w#w-d-id104920</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m976-id64048-2">
   <w.rf>
    <LM>w#w-id64048-2</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m976-id64048-3">
   <w.rf>
    <LM>w#w-id64048-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m976-id64048-4">
   <w.rf>
    <LM>w#w-id64048-4</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m976-id64048-5">
   <w.rf>
    <LM>w#w-id64048-5</LM>
   </w.rf>
   <form>Ruda</form>
   <lemma>Ruda-2_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m976-d-id104991">
   <w.rf>
    <LM>w#w-d-id104991</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
