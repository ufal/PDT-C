<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_047.03.w.gz" />
  </references>
 </head>
 <s id="m047-d1e809-x3">
  <m id="m047-d1t816-1">
   <w.rf>
    <LM>w#w-d1t816-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t816-2">
   <w.rf>
    <LM>w#w-d1t816-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t816-3">
   <w.rf>
    <LM>w#w-d1t816-3</LM>
   </w.rf>
   <form>mrzí</form>
   <lemma>mrzet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m047-d-m-d1e809-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e809-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e817-x2">
  <m id="m047-d1t822-2">
   <w.rf>
    <LM>w#w-d1t822-2</LM>
   </w.rf>
   <form>Takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t822-3">
   <w.rf>
    <LM>w#w-d1t822-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t822-4">
   <w.rf>
    <LM>w#w-d1t822-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m047-d-m-d1e817-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e817-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e825-x3">
  <m id="m047-d1t832-1">
   <w.rf>
    <LM>w#w-d1t832-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t832-2">
   <w.rf>
    <LM>w#w-d1t832-2</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m047-d-id83525-punct">
   <w.rf>
    <LM>w#w-d-id83525-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t832-4">
   <w.rf>
    <LM>w#w-d1t832-4</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t832-5">
   <w.rf>
    <LM>w#w-d1t832-5</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m047-d1t832-6">
   <w.rf>
    <LM>w#w-d1t832-6</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-d-id83580-punct">
   <w.rf>
    <LM>w#w-d-id83580-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e833-x2">
  <m id="m047-d1t838-2">
   <w.rf>
    <LM>w#w-d1t838-2</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t840-6">
   <w.rf>
    <LM>w#w-d1t840-6</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m047-d1t840-1">
   <w.rf>
    <LM>w#w-d1t840-1</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t840-2">
   <w.rf>
    <LM>w#w-d1t840-2</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m047-d1t840-3">
   <w.rf>
    <LM>w#w-d1t840-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m047-d-m-d1e833-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e833-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e841-x2">
  <m id="m047-d1t846-1">
   <w.rf>
    <LM>w#w-d1t846-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m047-d1t846-2">
   <w.rf>
    <LM>w#w-d1t846-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t846-3">
   <w.rf>
    <LM>w#w-d1t846-3</LM>
   </w.rf>
   <form>ně</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3------1</tag>
  </m>
  <m id="m047-d1t846-4">
   <w.rf>
    <LM>w#w-d1t846-4</LM>
   </w.rf>
   <form>jistě</form>
   <lemma>jistě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t846-5">
   <w.rf>
    <LM>w#w-d1t846-5</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m047-d-m-d1e841-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e841-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e851-x2">
  <m id="m047-d1e851-x2-192">
   <w.rf>
    <LM>w#w-d1e851-x2-192</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1e851-x2-193">
   <w.rf>
    <LM>w#w-d1e851-x2-193</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m047-d1e851-x2-194">
   <w.rf>
    <LM>w#w-d1e851-x2-194</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t854-7">
   <w.rf>
    <LM>w#w-d1t854-7</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t854-8">
   <w.rf>
    <LM>w#w-d1t854-8</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m047-d1e851-x2-195">
   <w.rf>
    <LM>w#w-d1e851-x2-195</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t854-9">
   <w.rf>
    <LM>w#w-d1t854-9</LM>
   </w.rf>
   <form>mámu</form>
   <lemma>máma</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m047-d1e851-x2-196">
   <w.rf>
    <LM>w#w-d1e851-x2-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-197">
  <m id="m047-d1t854-11">
   <w.rf>
    <LM>w#w-d1t854-11</LM>
   </w.rf>
   <form>Umřela</form>
   <lemma>umřít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m047-d1t854-12">
   <w.rf>
    <LM>w#w-d1t854-12</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-197-198">
   <w.rf>
    <LM>w#w-197-198</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t854-13">
   <w.rf>
    <LM>w#w-d1t854-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t854-14">
   <w.rf>
    <LM>w#w-d1t854-14</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m047-d1t854-15">
   <w.rf>
    <LM>w#w-d1t854-15</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m047-d1t854-16">
   <w.rf>
    <LM>w#w-d1t854-16</LM>
   </w.rf>
   <form>64</form>
   <lemma>64</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m047-197-199">
   <w.rf>
    <LM>w#w-197-199</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-200">
  <m id="m047-d1t856-7">
   <w.rf>
    <LM>w#w-d1t856-7</LM>
   </w.rf>
   <form>Nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m047-d1t856-6">
   <w.rf>
    <LM>w#w-d1t856-6</LM>
   </w.rf>
   <form>maminku</form>
   <lemma>maminka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m047-d1t856-3">
   <w.rf>
    <LM>w#w-d1t856-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t856-4">
   <w.rf>
    <LM>w#w-d1t856-4</LM>
   </w.rf>
   <form>dlouho</form>
   <lemma>dlouho</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-d-m-d1e851-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e851-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e859-x2">
  <m id="m047-d1t864-1">
   <w.rf>
    <LM>w#w-d1t864-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t864-2">
   <w.rf>
    <LM>w#w-d1t864-2</LM>
   </w.rf>
   <form>víte</form>
   <lemma>vědět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m047-d-id84490-punct">
   <w.rf>
    <LM>w#w-d-id84490-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t872-1">
   <w.rf>
    <LM>w#w-d1t872-1</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m047-d1t872-2">
   <w.rf>
    <LM>w#w-d1t872-2</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m047-d1t874-1">
   <w.rf>
    <LM>w#w-d1t874-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t874-2">
   <w.rf>
    <LM>w#w-d1t874-2</LM>
   </w.rf>
   <form>každému</form>
   <lemma>každý</lemma>
   <tag>AAMS3----1A----</tag>
  </m>
  <m id="m047-d-m-d1e869-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e869-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e875-x3">
  <m id="m047-d1t886-1">
   <w.rf>
    <LM>w#w-d1t886-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m047-d1t886-2">
   <w.rf>
    <LM>w#w-d1t886-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m047-d1t886-3">
   <w.rf>
    <LM>w#w-d1t886-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t886-4">
   <w.rf>
    <LM>w#w-d1t886-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m047-d1t886-5">
   <w.rf>
    <LM>w#w-d1t886-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t886-6">
   <w.rf>
    <LM>w#w-d1t886-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m047-d-id84923-punct">
   <w.rf>
    <LM>w#w-d-id84923-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e887-x2">
  <m id="m047-d1t890-1">
   <w.rf>
    <LM>w#w-d1t890-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t890-5">
   <w.rf>
    <LM>w#w-d1t890-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t890-4">
   <w.rf>
    <LM>w#w-d1t890-4</LM>
   </w.rf>
   <form>mladí</form>
   <lemma>mladý</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m047-d1t890-7">
   <w.rf>
    <LM>w#w-d1t890-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t890-6">
   <w.rf>
    <LM>w#w-d1t890-6</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-d1t890-8">
   <w.rf>
    <LM>w#w-d1t890-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t890-9">
   <w.rf>
    <LM>w#w-d1t890-9</LM>
   </w.rf>
   <form>rodinách</form>
   <lemma>rodina</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m047-d1t890-10">
   <w.rf>
    <LM>w#w-d1t890-10</LM>
   </w.rf>
   <form>vyptávají</form>
   <lemma>vyptávat_^(*4at)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m047-d1t890-11">
   <w.rf>
    <LM>w#w-d1t890-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t890-12">
   <w.rf>
    <LM>w#w-d1t890-12</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m047-d1t890-13">
   <w.rf>
    <LM>w#w-d1t890-13</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m047-d1e887-x2-218">
   <w.rf>
    <LM>w#w-d1e887-x2-218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-219">
  <m id="m047-d1t894-1">
   <w.rf>
    <LM>w#w-d1t894-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t894-2">
   <w.rf>
    <LM>w#w-d1t894-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t894-3">
   <w.rf>
    <LM>w#w-d1t894-3</LM>
   </w.rf>
   <form>nedělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m047-d-id85293-punct">
   <w.rf>
    <LM>w#w-d-id85293-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t894-5">
   <w.rf>
    <LM>w#w-d1t894-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t894-7">
   <w.rf>
    <LM>w#w-d1t894-7</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m047-d1t894-8">
   <w.rf>
    <LM>w#w-d1t894-8</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m047-d1t894-9">
   <w.rf>
    <LM>w#w-d1t894-9</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m047-d1t896-1">
   <w.rf>
    <LM>w#w-d1t896-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t896-2">
   <w.rf>
    <LM>w#w-d1t896-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t896-3">
   <w.rf>
    <LM>w#w-d1t896-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t896-4">
   <w.rf>
    <LM>w#w-d1t896-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m047-d1t896-5">
   <w.rf>
    <LM>w#w-d1t896-5</LM>
   </w.rf>
   <form>nedovím</form>
   <lemma>dovědět</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m047-219-220">
   <w.rf>
    <LM>w#w-219-220</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-221">
  <m id="m047-d1t901-1">
   <w.rf>
    <LM>w#w-d1t901-1</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t901-4">
   <w.rf>
    <LM>w#w-d1t901-4</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP3----------</tag>
  </m>
  <m id="m047-d1t901-5">
   <w.rf>
    <LM>w#w-d1t901-5</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m047-d1t901-6">
   <w.rf>
    <LM>w#w-d1t901-6</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-221-222">
   <w.rf>
    <LM>w#w-221-222</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-221-223">
   <w.rf>
    <LM>w#w-221-223</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t901-7">
   <w.rf>
    <LM>w#w-d1t901-7</LM>
   </w.rf>
   <form>Ptejte</form>
   <lemma>ptát</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m047-d1t901-8">
   <w.rf>
    <LM>w#w-d1t901-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d-id85623-punct">
   <w.rf>
    <LM>w#w-d-id85623-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t901-10">
   <w.rf>
    <LM>w#w-d1t901-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m047-d1t901-11">
   <w.rf>
    <LM>w#w-d1t901-11</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m047-d1t901-12">
   <w.rf>
    <LM>w#w-d1t901-12</LM>
   </w.rf>
   <form>vědět</form>
   <lemma>vědět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m047-d-id85678-punct">
   <w.rf>
    <LM>w#w-d-id85678-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t903-1">
   <w.rf>
    <LM>w#w-d1t903-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t903-2">
   <w.rf>
    <LM>w#w-d1t903-2</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t903-3">
   <w.rf>
    <LM>w#w-d1t903-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>tu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t903-4">
   <w.rf>
    <LM>w#w-d1t903-4</LM>
   </w.rf>
   <form>nebudu</form>
   <lemma>být</lemma>
   <tag>VB-S---1F-NAI--</tag>
  </m>
  <m id="m047-221-224">
   <w.rf>
    <LM>w#w-221-224</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t903-5">
   <w.rf>
    <LM>w#w-d1t903-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t903-6">
   <w.rf>
    <LM>w#w-d1t903-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t903-7">
   <w.rf>
    <LM>w#w-d1t903-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m047-d1t903-8">
   <w.rf>
    <LM>w#w-d1t903-8</LM>
   </w.rf>
   <form>nedozvíte</form>
   <lemma>dozvědět</lemma>
   <tag>VB-P---2P-NAP--</tag>
  </m>
  <m id="m047-221-225">
   <w.rf>
    <LM>w#w-221-225</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-221-226">
   <w.rf>
    <LM>w#w-221-226</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-227">
  <m id="m047-d1t907-1">
   <w.rf>
    <LM>w#w-d1t907-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m047-d1t907-2">
   <w.rf>
    <LM>w#w-d1t907-2</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t907-3">
   <w.rf>
    <LM>w#w-d1t907-3</LM>
   </w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m047-d1t907-4">
   <w.rf>
    <LM>w#w-d1t907-4</LM>
   </w.rf>
   <form>mezery</form>
   <lemma>mezera</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m047-d1t907-5">
   <w.rf>
    <LM>w#w-d1t907-5</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-227-228">
   <w.rf>
    <LM>w#w-227-228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-229">
  <m id="m047-d1t907-9">
   <w.rf>
    <LM>w#w-d1t907-9</LM>
   </w.rf>
   <form>Spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m047-d1t909-1">
   <w.rf>
    <LM>w#w-d1t909-1</LM>
   </w.rf>
   <form>věcí</form>
   <lemma>věc</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m047-d1t909-2">
   <w.rf>
    <LM>w#w-d1t909-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m047-d-id86017-punct">
   <w.rf>
    <LM>w#w-d-id86017-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t909-4">
   <w.rf>
    <LM>w#w-d1t909-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t909-5">
   <w.rf>
    <LM>w#w-d1t909-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t909-6">
   <w.rf>
    <LM>w#w-d1t909-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t909-7">
   <w.rf>
    <LM>w#w-d1t909-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m047-d1t909-8">
   <w.rf>
    <LM>w#w-d1t909-8</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-d1t909-9">
   <w.rf>
    <LM>w#w-d1t909-9</LM>
   </w.rf>
   <form>nemluvilo</form>
   <lemma>mluvit</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m047-d1e887-x3-242">
   <w.rf>
    <LM>w#w-d1e887-x3-242</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-243">
  <m id="m047-d1t916-1">
   <w.rf>
    <LM>w#w-d1t916-1</LM>
   </w.rf>
   <form>Tento</form>
   <lemma>tento</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m047-d1t916-2">
   <w.rf>
    <LM>w#w-d1t916-2</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m047-d1t916-3">
   <w.rf>
    <LM>w#w-d1t916-3</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-d1t916-4">
   <w.rf>
    <LM>w#w-d1t916-4</LM>
   </w.rf>
   <form>všecky</form>
   <lemma>všecek</lemma>
   <tag>PLFP4----------</tag>
  </m>
  <m id="m047-d1t916-5">
   <w.rf>
    <LM>w#w-d1t916-5</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m047-d1t916-6">
   <w.rf>
    <LM>w#w-d1t916-6</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m047-d1t916-7">
   <w.rf>
    <LM>w#w-d1t916-7</LM>
   </w.rf>
   <form>pravého</form>
   <lemma>pravý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m047-d1t916-8">
   <w.rf>
    <LM>w#w-d1t916-8</LM>
   </w.rf>
   <form>otce</form>
   <lemma>otec</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m047-d1t916-9">
   <w.rf>
    <LM>w#w-d1t916-9</LM>
   </w.rf>
   <form>zničil</form>
   <lemma>zničit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-243-251">
   <w.rf>
    <LM>w#w-243-251</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-252">
  <m id="m047-d1t918-5">
   <w.rf>
    <LM>w#w-d1t918-5</LM>
   </w.rf>
   <form>Vzal</form>
   <lemma>vzít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-d1t918-3">
   <w.rf>
    <LM>w#w-d1t918-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m047-d1t918-4">
   <w.rf>
    <LM>w#w-d1t918-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t918-7">
   <w.rf>
    <LM>w#w-d1t918-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t918-8">
   <w.rf>
    <LM>w#w-d1t918-8</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m047-252-253">
   <w.rf>
    <LM>w#w-252-253</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-254">
  <m id="m047-d1t918-11">
   <w.rf>
    <LM>w#w-d1t918-11</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-d1t918-10">
   <w.rf>
    <LM>w#w-d1t918-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m047-d1t918-12">
   <w.rf>
    <LM>w#w-d1t918-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t918-13">
   <w.rf>
    <LM>w#w-d1t918-13</LM>
   </w.rf>
   <form>své</form>
   <lemma>svůj-1</lemma>
   <tag>P8NS4---------1</tag>
  </m>
  <m id="m047-d1t918-14">
   <w.rf>
    <LM>w#w-d1t918-14</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m047-254-255">
   <w.rf>
    <LM>w#w-254-255</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-256">
  <m id="m047-d1t920-1">
   <w.rf>
    <LM>w#w-d1t920-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t920-2">
   <w.rf>
    <LM>w#w-d1t920-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t920-3">
   <w.rf>
    <LM>w#w-d1t920-3</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t920-4">
   <w.rf>
    <LM>w#w-d1t920-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m047-d1t920-6">
   <w.rf>
    <LM>w#w-d1t920-6</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m047-d1t920-7">
   <w.rf>
    <LM>w#w-d1t920-7</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m047-d-id86677-punct">
   <w.rf>
    <LM>w#w-d-id86677-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t920-9">
   <w.rf>
    <LM>w#w-d1t920-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t920-10">
   <w.rf>
    <LM>w#w-d1t920-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t920-11">
   <w.rf>
    <LM>w#w-d1t920-11</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m047-d1t920-12">
   <w.rf>
    <LM>w#w-d1t920-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t920-13">
   <w.rf>
    <LM>w#w-d1t920-13</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m047-d1t920-14">
   <w.rf>
    <LM>w#w-d1t920-14</LM>
   </w.rf>
   <form>jméno</form>
   <lemma>jméno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m047-256-257">
   <w.rf>
    <LM>w#w-256-257</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-258">
  <m id="m047-d1t922-3">
   <w.rf>
    <LM>w#w-d1t922-3</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m047-d1t922-4">
   <w.rf>
    <LM>w#w-d1t922-4</LM>
   </w.rf>
   <form>zničil</form>
   <lemma>zničit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-258-259">
   <w.rf>
    <LM>w#w-258-259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-260">
  <m id="m047-d1t922-11">
   <w.rf>
    <LM>w#w-d1t922-11</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t922-12">
   <w.rf>
    <LM>w#w-d1t922-12</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m047-260-261">
   <w.rf>
    <LM>w#w-260-261</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t922-14">
   <w.rf>
    <LM>w#w-d1t922-14</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t922-15">
   <w.rf>
    <LM>w#w-d1t922-15</LM>
   </w.rf>
   <form>vypadal</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t922-8">
   <w.rf>
    <LM>w#w-d1t922-8</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m047-d1t922-9">
   <w.rf>
    <LM>w#w-d1t922-9</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m047-d1t922-10">
   <w.rf>
    <LM>w#w-d1t922-10</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-d-m-d1e887-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e887-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e933-x2">
  <m id="m047-d1t936-1">
   <w.rf>
    <LM>w#w-d1t936-1</LM>
   </w.rf>
   <form>Vybavujete</form>
   <lemma>vybavovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m047-d1t936-2">
   <w.rf>
    <LM>w#w-d1t936-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m047-d1t936-3">
   <w.rf>
    <LM>w#w-d1t936-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m047-d1t936-4">
   <w.rf>
    <LM>w#w-d1t936-4</LM>
   </w.rf>
   <form>společný</form>
   <lemma>společný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m047-d1t936-5">
   <w.rf>
    <LM>w#w-d1t936-5</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m047-d-id87201-punct">
   <w.rf>
    <LM>w#w-d-id87201-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e937-x2">
  <m id="m047-d1t942-5">
   <w.rf>
    <LM>w#w-d1t942-5</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1e937-x2-268">
   <w.rf>
    <LM>w#w-d1e937-x2-268</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t942-6">
   <w.rf>
    <LM>w#w-d1t942-6</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t942-7">
   <w.rf>
    <LM>w#w-d1t942-7</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d-m-d1e937-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e937-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e937-x3">
  <m id="m047-d1t944-1">
   <w.rf>
    <LM>w#w-d1t944-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m047-d1t944-2">
   <w.rf>
    <LM>w#w-d1t944-2</LM>
   </w.rf>
   <form>maminkou</form>
   <lemma>maminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m047-d1e937-x3-270">
   <w.rf>
    <LM>w#w-d1e937-x3-270</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e945-x2">
  <m id="m047-d1t950-2">
   <w.rf>
    <LM>w#w-d1t950-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m047-d1t950-3">
   <w.rf>
    <LM>w#w-d1t950-3</LM>
   </w.rf>
   <form>maminou</form>
   <lemma>mamina_,h</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m047-d1t950-6">
   <w.rf>
    <LM>w#w-d1t950-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t950-7">
   <w.rf>
    <LM>w#w-d1t950-7</LM>
   </w.rf>
   <form>běžně</form>
   <lemma>běžně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-d1e945-x2-280">
   <w.rf>
    <LM>w#w-d1e945-x2-280</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-281">
  <m id="m047-d1t954-1">
   <w.rf>
    <LM>w#w-d1t954-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m047-d1t954-2">
   <w.rf>
    <LM>w#w-d1t954-2</LM>
   </w.rf>
   <form>maminkou</form>
   <lemma>maminka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m047-d1t952-4">
   <w.rf>
    <LM>w#w-d1t952-4</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t954-3">
   <w.rf>
    <LM>w#w-d1t954-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t952-5">
   <w.rf>
    <LM>w#w-d1t952-5</LM>
   </w.rf>
   <form>smutné</form>
   <lemma>smutný</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m047-d1t952-6">
   <w.rf>
    <LM>w#w-d1t952-6</LM>
   </w.rf>
   <form>zážitky</form>
   <lemma>zážitek</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m047-281-282">
   <w.rf>
    <LM>w#w-281-282</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-284">
  <m id="m047-d1t956-1">
   <w.rf>
    <LM>w#w-d1t956-1</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t956-3">
   <w.rf>
    <LM>w#w-d1t956-3</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t956-4">
   <w.rf>
    <LM>w#w-d1t956-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t956-5">
   <w.rf>
    <LM>w#w-d1t956-5</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t956-6">
   <w.rf>
    <LM>w#w-d1t956-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m047-d1t956-7">
   <w.rf>
    <LM>w#w-d1t956-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m047-284-285">
   <w.rf>
    <LM>w#w-284-285</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t956-10">
   <w.rf>
    <LM>w#w-d1t956-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m047-d1t956-9">
   <w.rf>
    <LM>w#w-d1t956-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m047-d1t956-12">
   <w.rf>
    <LM>w#w-d1t956-12</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m047-d1t956-13">
   <w.rf>
    <LM>w#w-d1t956-13</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m047-284-287">
   <w.rf>
    <LM>w#w-284-287</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t959-2">
   <w.rf>
    <LM>w#w-d1t959-2</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-d1t959-3">
   <w.rf>
    <LM>w#w-d1t959-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t959-4">
   <w.rf>
    <LM>w#w-d1t959-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t959-5">
   <w.rf>
    <LM>w#w-d1t959-5</LM>
   </w.rf>
   <form>nasazený</form>
   <lemma>nasazený_^(*4dit)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m047-d1t959-6">
   <w.rf>
    <LM>w#w-d1t959-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t959-8">
   <w.rf>
    <LM>w#w-d1t959-8</LM>
   </w.rf>
   <form>Německu</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m047-284-354">
   <w.rf>
    <LM>w#w-284-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-357">
  <m id="m047-d1t961-2">
   <w.rf>
    <LM>w#w-d1t961-2</LM>
   </w.rf>
   <form>Naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m047-d1t961-3">
   <w.rf>
    <LM>w#w-d1t961-3</LM>
   </w.rf>
   <form>mami</form>
   <lemma>mami_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m047-d1t963-1">
   <w.rf>
    <LM>w#w-d1t963-1</LM>
   </w.rf>
   <form>uklízela</form>
   <lemma>uklízet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t963-4">
   <w.rf>
    <LM>w#w-d1t963-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t963-6">
   <w.rf>
    <LM>w#w-d1t963-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t963-6-sw1">
   <w.rf>
    <LM>w#w-d1t963-6</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m047-d1t965-1">
   <w.rf>
    <LM>w#w-d1t965-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t965-2">
   <w.rf>
    <LM>w#w-d1t965-2</LM>
   </w.rf>
   <form>hejtmanství</form>
   <lemma>hejtmanství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m047-284-289">
   <w.rf>
    <LM>w#w-284-289</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-290">
  <m id="m047-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t969-5">
   <w.rf>
    <LM>w#w-d1t969-5</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m047-d1t969-7">
   <w.rf>
    <LM>w#w-d1t969-7</LM>
   </w.rf>
   <form>gestapo</form>
   <lemma>gestapo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m047-d-id88471-punct">
   <w.rf>
    <LM>w#w-d-id88471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t969-9">
   <w.rf>
    <LM>w#w-d1t969-9</LM>
   </w.rf>
   <form>hejtmanství</form>
   <lemma>hejtmanství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m047-d1e945-x3-312">
   <w.rf>
    <LM>w#w-d1e945-x3-312</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t969-11">
   <w.rf>
    <LM>w#w-d1t969-11</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m047-d1t969-14">
   <w.rf>
    <LM>w#w-d1t969-14</LM>
   </w.rf>
   <form>úřady</form>
   <lemma>úřad</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m047-d1t969-6">
   <w.rf>
    <LM>w#w-d1t969-6</LM>
   </w.rf>
   <form>spojené</form>
   <lemma>spojený_^(*3it)</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m047-d1e945-x3-313">
   <w.rf>
    <LM>w#w-d1e945-x3-313</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-314">
  <m id="m047-d1t972-2">
   <w.rf>
    <LM>w#w-d1t972-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t972-4">
   <w.rf>
    <LM>w#w-d1t972-4</LM>
   </w.rf>
   <form>gestapu</form>
   <lemma>gestapo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m047-d1t974-3">
   <w.rf>
    <LM>w#w-d1t974-3</LM>
   </w.rf>
   <form>onemocněla</form>
   <lemma>onemocnět</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m047-d1t974-1">
   <w.rf>
    <LM>w#w-d1t974-1</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m047-d1t974-2">
   <w.rf>
    <LM>w#w-d1t974-2</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m047-d1t974-4">
   <w.rf>
    <LM>w#w-d1t974-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t974-5">
   <w.rf>
    <LM>w#w-d1t974-5</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m047-d1t974-6">
   <w.rf>
    <LM>w#w-d1t974-6</LM>
   </w.rf>
   <form>máma</form>
   <lemma>máma</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m047-d1t976-1">
   <w.rf>
    <LM>w#w-d1t976-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t976-3">
   <w.rf>
    <LM>w#w-d1t976-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m047-d1t976-4">
   <w.rf>
    <LM>w#w-d1t976-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m047-d1t976-2">
   <w.rf>
    <LM>w#w-d1t976-2</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t976-5">
   <w.rf>
    <LM>w#w-d1t976-5</LM>
   </w.rf>
   <form>zaskakovat</form>
   <lemma>zaskakovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m047-314-326">
   <w.rf>
    <LM>w#w-314-326</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-327">
  <m id="m047-d1t976-8">
   <w.rf>
    <LM>w#w-d1t976-8</LM>
   </w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t976-7">
   <w.rf>
    <LM>w#w-d1t976-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t978-1">
   <w.rf>
    <LM>w#w-d1t978-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t978-2">
   <w.rf>
    <LM>w#w-d1t978-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m047-d1t978-4">
   <w.rf>
    <LM>w#w-d1t978-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t978-5">
   <w.rf>
    <LM>w#w-d1t978-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t978-7">
   <w.rf>
    <LM>w#w-d1t978-7</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m047-d1t978-3">
   <w.rf>
    <LM>w#w-d1t978-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-d1t978-9">
   <w.rf>
    <LM>w#w-d1t978-9</LM>
   </w.rf>
   <form>nálety</form>
   <lemma>nálet</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m047-d-id89012-punct">
   <w.rf>
    <LM>w#w-d-id89012-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t982-1">
   <w.rf>
    <LM>w#w-d1t982-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m047-d1t982-2">
   <w.rf>
    <LM>w#w-d1t982-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t982-3">
   <w.rf>
    <LM>w#w-d1t982-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t982-9">
   <w.rf>
    <LM>w#w-d1t982-9</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t982-10">
   <w.rf>
    <LM>w#w-d1t982-10</LM>
   </w.rf>
   <form>nechávat</form>
   <lemma>nechávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m047-d1t982-11">
   <w.rf>
    <LM>w#w-d1t982-11</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m047-327-258">
   <w.rf>
    <LM>w#w-327-258</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t985-4">
   <w.rf>
    <LM>w#w-d1t985-4</LM>
   </w.rf>
   <form>brávala</form>
   <lemma>brávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t985-2">
   <w.rf>
    <LM>w#w-d1t985-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t985-5">
   <w.rf>
    <LM>w#w-d1t985-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m047-d1t985-7">
   <w.rf>
    <LM>w#w-d1t985-7</LM>
   </w.rf>
   <form>uklízení</form>
   <lemma>uklízení_^(*2t)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m047-327-328">
   <w.rf>
    <LM>w#w-327-328</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m047-d1t985-3">
   <w.rf>
    <LM>w#w-d1t985-3</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m047-327-329">
   <w.rf>
    <LM>w#w-327-329</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-331">
  <m id="m047-d1t987-5">
   <w.rf>
    <LM>w#w-d1t987-5</LM>
   </w.rf>
   <form>Vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m047-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t987-4">
   <w.rf>
    <LM>w#w-d1t987-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d-id89360-punct">
   <w.rf>
    <LM>w#w-d-id89360-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t987-7">
   <w.rf>
    <LM>w#w-d1t987-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t987-8">
   <w.rf>
    <LM>w#w-d1t987-8</LM>
   </w.rf>
   <form>zaskakovala</form>
   <lemma>zaskakovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t987-9">
   <w.rf>
    <LM>w#w-d1t987-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t987-11">
   <w.rf>
    <LM>w#w-d1t987-11</LM>
   </w.rf>
   <form>gestapu</form>
   <lemma>gestapo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m047-331-337">
   <w.rf>
    <LM>w#w-331-337</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-339">
  <m id="m047-d1t987-12">
   <w.rf>
    <LM>w#w-d1t987-12</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t987-13">
   <w.rf>
    <LM>w#w-d1t987-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m047-d1t987-14">
   <w.rf>
    <LM>w#w-d1t987-14</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t989-1">
   <w.rf>
    <LM>w#w-d1t989-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t989-3">
   <w.rf>
    <LM>w#w-d1t989-3</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m047-d1t989-5">
   <w.rf>
    <LM>w#w-d1t989-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m047-d1t989-7">
   <w.rf>
    <LM>w#w-d1t989-7</LM>
   </w.rf>
   <form>nábřeží</form>
   <lemma>nábřeží</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m047-d1e945-x4-350">
   <w.rf>
    <LM>w#w-d1e945-x4-350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-351">
  <m id="m047-d1t989-13">
   <w.rf>
    <LM>w#w-d1t989-13</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t989-12">
   <w.rf>
    <LM>w#w-d1t989-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t989-9">
   <w.rf>
    <LM>w#w-d1t989-9</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m047-d1t989-10">
   <w.rf>
    <LM>w#w-d1t989-10</LM>
   </w.rf>
   <form>kachlíkový</form>
   <lemma>kachlíkový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m047-d1t989-11">
   <w.rf>
    <LM>w#w-d1t989-11</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m047-351-271">
   <w.rf>
    <LM>w#w-351-271</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-274">
  <m id="m047-d1e990-x3-364">
   <w.rf>
    <LM>w#w-d1e990-x3-364</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t999-1">
   <w.rf>
    <LM>w#w-d1t999-1</LM>
   </w.rf>
   <form>sídlili</form>
   <lemma>sídlit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m047-d-m-d1e990-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e990-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e1000-x2">
  <m id="m047-d1t1005-7">
   <w.rf>
    <LM>w#w-d1t1005-7</LM>
   </w.rf>
   <form>Pomáhala</form>
   <lemma>pomáhat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t1005-4">
   <w.rf>
    <LM>w#w-d1t1005-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t1005-5">
   <w.rf>
    <LM>w#w-d1t1005-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1e1000-x2-374">
   <w.rf>
    <LM>w#w-d1e1000-x2-374</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-375">
  <m id="m047-d1t1007-1">
   <w.rf>
    <LM>w#w-d1t1007-1</LM>
   </w.rf>
   <form>Vynášela</form>
   <lemma>vynášet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m047-d1t1007-2">
   <w.rf>
    <LM>w#w-d1t1007-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t1007-3">
   <w.rf>
    <LM>w#w-d1t1007-3</LM>
   </w.rf>
   <form>košíky</form>
   <lemma>košík</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m047-375-376">
   <w.rf>
    <LM>w#w-375-376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-377">
  <m id="m047-d1t1007-11">
   <w.rf>
    <LM>w#w-d1t1007-11</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m047-d1t1007-10">
   <w.rf>
    <LM>w#w-d1t1007-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1007-12">
   <w.rf>
    <LM>w#w-d1t1007-12</LM>
   </w.rf>
   <form>široké</form>
   <lemma>široký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m047-d1t1007-13">
   <w.rf>
    <LM>w#w-d1t1007-13</LM>
   </w.rf>
   <form>chodby</form>
   <lemma>chodba</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m047-d1t1009-1">
   <w.rf>
    <LM>w#w-d1t1009-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t1009-4">
   <w.rf>
    <LM>w#w-d1t1009-4</LM>
   </w.rf>
   <form>bachař</form>
   <lemma>bachař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-d-id90217-punct">
   <w.rf>
    <LM>w#w-d-id90217-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t1009-6">
   <w.rf>
    <LM>w#w-d1t1009-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m047-d1t1009-7">
   <w.rf>
    <LM>w#w-d1t1009-7</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t1009-8">
   <w.rf>
    <LM>w#w-d1t1009-8</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1009-9">
   <w.rf>
    <LM>w#w-d1t1009-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-377-378">
   <w.rf>
    <LM>w#w-377-378</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-379">
  <m id="m047-d1t1011-4">
   <w.rf>
    <LM>w#w-d1t1011-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-379-380">
   <w.rf>
    <LM>w#w-379-380</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1011-5">
   <w.rf>
    <LM>w#w-d1t1011-5</LM>
   </w.rf>
   <form>veliký</form>
   <lemma>veliký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m047-d1t1011-6">
   <w.rf>
    <LM>w#w-d1t1011-6</LM>
   </w.rf>
   <form>nákladní</form>
   <lemma>nákladní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m047-d1t1011-7">
   <w.rf>
    <LM>w#w-d1t1011-7</LM>
   </w.rf>
   <form>výtah</form>
   <lemma>výtah</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m047-379-381">
   <w.rf>
    <LM>w#w-379-381</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-382">
  <m id="m047-d1t1016-5">
   <w.rf>
    <LM>w#w-d1t1016-5</LM>
   </w.rf>
   <form>Všiml</form>
   <lemma>všimnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m047-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m047-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m047-d-id90479-punct">
   <w.rf>
    <LM>w#w-d-id90479-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t1016-7">
   <w.rf>
    <LM>w#w-d1t1016-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t1016-10">
   <w.rf>
    <LM>w#w-d1t1016-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1016-16">
   <w.rf>
    <LM>w#w-d1t1016-16</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m047-d1t1016-11">
   <w.rf>
    <LM>w#w-d1t1016-11</LM>
   </w.rf>
   <form>vysýpám</form>
   <lemma>vysýpat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m047-d1t1016-14">
   <w.rf>
    <LM>w#w-d1t1016-14</LM>
   </w.rf>
   <form>košíky</form>
   <lemma>košík</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m047-382-383">
   <w.rf>
    <LM>w#w-382-383</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-384">
  <m id="m047-d1t1016-22">
   <w.rf>
    <LM>w#w-d1t1016-22</LM>
   </w.rf>
   <form>Dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-d1t1016-20">
   <w.rf>
    <LM>w#w-d1t1016-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-384-385">
   <w.rf>
    <LM>w#w-384-385</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m047-d1t1016-21">
   <w.rf>
    <LM>w#w-d1t1016-21</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m047-d1t1016-23">
   <w.rf>
    <LM>w#w-d1t1016-23</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m047-d1t1016-24">
   <w.rf>
    <LM>w#w-d1t1016-24</LM>
   </w.rf>
   <form>řeči</form>
   <lemma>řeč</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m047-384-386">
   <w.rf>
    <LM>w#w-384-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-387">
  <m id="m047-d1t1016-25">
   <w.rf>
    <LM>w#w-d1t1016-25</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t1016-26">
   <w.rf>
    <LM>w#w-d1t1016-26</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t1016-28">
   <w.rf>
    <LM>w#w-d1t1016-28</LM>
   </w.rf>
   <form>Čech</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m047-387-388">
   <w.rf>
    <LM>w#w-387-388</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-389">
  <m id="m047-389-401">
   <w.rf>
    <LM>w#w-389-401</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t1018-5">
   <w.rf>
    <LM>w#w-d1t1018-5</LM>
   </w.rf>
   <form>leccos</form>
   <lemma>leccos</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m047-d1t1018-3">
   <w.rf>
    <LM>w#w-d1t1018-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m047-d1t1018-4">
   <w.rf>
    <LM>w#w-d1t1018-4</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m047-d1t1018-6">
   <w.rf>
    <LM>w#w-d1t1018-6</LM>
   </w.rf>
   <form>vyptával</form>
   <lemma>vyptávat_^(*4at)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1e1000-x3-412">
   <w.rf>
    <LM>w#w-d1e1000-x3-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e1000-x3">
  <m id="m047-d1t1018-10">
   <w.rf>
    <LM>w#w-d1t1018-10</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1018-11">
   <w.rf>
    <LM>w#w-d1t1018-11</LM>
   </w.rf>
   <form>najednou</form>
   <lemma>najednou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1018-12">
   <w.rf>
    <LM>w#w-d1t1018-12</LM>
   </w.rf>
   <form>povídá</form>
   <lemma>povídat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m047-d1e1000-x3-413">
   <w.rf>
    <LM>w#w-d1e1000-x3-413</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1e1000-x3-414">
   <w.rf>
    <LM>w#w-d1e1000-x3-414</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t1018-14">
   <w.rf>
    <LM>w#w-d1t1018-14</LM>
   </w.rf>
   <form>Pojď</form>
   <lemma>jít</lemma>
   <tag>Vi-S---2--A-I-1</tag>
  </m>
  <m id="m047-d1e1000-x3-415">
   <w.rf>
    <LM>w#w-d1e1000-x3-415</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1t1018-15">
   <w.rf>
    <LM>w#w-d1t1018-15</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m047-d1t1018-16">
   <w.rf>
    <LM>w#w-d1t1018-16</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ty</lemma>
   <tag>PH-S3--2-------</tag>
  </m>
  <m id="m047-d1t1018-17">
   <w.rf>
    <LM>w#w-d1t1018-17</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m047-d1t1018-18">
   <w.rf>
    <LM>w#w-d1t1018-18</LM>
   </w.rf>
   <form>ukážu</form>
   <lemma>ukázat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m047-d1e1000-x3-397">
   <w.rf>
    <LM>w#w-d1e1000-x3-397</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m047-d1e1000-x3-417">
   <w.rf>
    <LM>w#w-d1e1000-x3-417</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-398">
  <m id="m047-d1t1022-2">
   <w.rf>
    <LM>w#w-d1t1022-2</LM>
   </w.rf>
   <form>Zavedl</form>
   <lemma>zavést</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-d1t1022-3">
   <w.rf>
    <LM>w#w-d1t1022-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t1022-4">
   <w.rf>
    <LM>w#w-d1t1022-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m047-d1t1022-6">
   <w.rf>
    <LM>w#w-d1t1022-6</LM>
   </w.rf>
   <form>výtahu</form>
   <lemma>výtah</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m047-d1e1000-x3-418">
   <w.rf>
    <LM>w#w-d1e1000-x3-418</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-419">
  <m id="m047-d1t1024-2">
   <w.rf>
    <LM>w#w-d1t1024-2</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m047-d1t1024-3">
   <w.rf>
    <LM>w#w-d1t1024-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t1024-4">
   <w.rf>
    <LM>w#w-d1t1024-4</LM>
   </w.rf>
   <form>plný</form>
   <lemma>plný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m047-d1t1024-6">
   <w.rf>
    <LM>w#w-d1t1024-6</LM>
   </w.rf>
   <form>polských</form>
   <lemma>polský</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m047-d1t1024-8">
   <w.rf>
    <LM>w#w-d1t1024-8</LM>
   </w.rf>
   <form>vězeňkyň</form>
   <lemma>vězeňkyně</lemma>
   <tag>NNFP2-----A---1</tag>
  </m>
  <m id="m047-419-420">
   <w.rf>
    <LM>w#w-419-420</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-421">
  <m id="m047-d1t1024-12">
   <w.rf>
    <LM>w#w-d1t1024-12</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m047-421-422">
   <w.rf>
    <LM>w#w-421-422</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1t1027-2">
   <w.rf>
    <LM>w#w-d1t1027-2</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m047-d1t1027-3">
   <w.rf>
    <LM>w#w-d1t1027-3</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m047-d1t1027-4">
   <w.rf>
    <LM>w#w-d1t1027-4</LM>
   </w.rf>
   <form>druhé</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m047-421-295">
   <w.rf>
    <LM>w#w-421-295</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-303">
  <m id="m047-d1t1027-7">
   <w.rf>
    <LM>w#w-d1t1027-7</LM>
   </w.rf>
   <form>Stály</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m047-421-425">
   <w.rf>
    <LM>w#w-421-425</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m047-d1t1027-6">
   <w.rf>
    <LM>w#w-d1t1027-6</LM>
   </w.rf>
   <form>svíčky</form>
   <lemma>svíčka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m047-421-426">
   <w.rf>
    <LM>w#w-421-426</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-427">
  <m id="m047-d1t1029-6">
   <w.rf>
    <LM>w#w-d1t1029-6</LM>
   </w.rf>
   <form>Strčil</form>
   <lemma>strčit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m047-d1t1029-3">
   <w.rf>
    <LM>w#w-d1t1029-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m047-d1t1029-4">
   <w.rf>
    <LM>w#w-d1t1029-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m047-d1t1029-5">
   <w.rf>
    <LM>w#w-d1t1029-5</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m047-d1t1037-1">
   <w.rf>
    <LM>w#w-d1t1037-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1t1037-2">
   <w.rf>
    <LM>w#w-d1t1037-2</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t1037-3">
   <w.rf>
    <LM>w#w-d1t1037-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m047-d1t1037-4">
   <w.rf>
    <LM>w#w-d1t1037-4</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m047-d1t1037-5">
   <w.rf>
    <LM>w#w-d1t1037-5</LM>
   </w.rf>
   <form>nahoru</form>
   <lemma>nahoru</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d1e1032-x2-433">
   <w.rf>
    <LM>w#w-d1e1032-x2-433</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m047-d1e1032-x2-434">
   <w.rf>
    <LM>w#w-d1e1032-x2-434</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m047-d-m-d1e1032-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1032-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m047-d1e1032-x3">
  <m id="m047-d1t1039-1">
   <w.rf>
    <LM>w#w-d1t1039-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m047-d1t1039-2">
   <w.rf>
    <LM>w#w-d1t1039-2</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m047-d1t1039-3">
   <w.rf>
    <LM>w#w-d1t1039-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m047-d1t1039-4">
   <w.rf>
    <LM>w#w-d1t1039-4</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m047-d1t1039-5">
   <w.rf>
    <LM>w#w-d1t1039-5</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m047-d1t1039-6">
   <w.rf>
    <LM>w#w-d1t1039-6</LM>
   </w.rf>
   <form>šok</form>
   <lemma>šok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m047-d1e1032-x3-437">
   <w.rf>
    <LM>w#w-d1e1032-x3-437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
