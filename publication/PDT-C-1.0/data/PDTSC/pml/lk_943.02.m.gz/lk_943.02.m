<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_943.02.w.gz" />
  </references>
 </head>
 <s id="m943-27484_03-162">
  <m id="m943-d1t876-1">
   <w.rf>
    <LM>w#w-d1t876-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t876-2">
   <w.rf>
    <LM>w#w-d1t876-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t878-2">
   <w.rf>
    <LM>w#w-d1t878-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t878-3">
   <w.rf>
    <LM>w#w-d1t878-3</LM>
   </w.rf>
   <form>vyprávět</form>
   <lemma>vyprávět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t876-3">
   <w.rf>
    <LM>w#w-d1t876-3</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t878-1">
   <w.rf>
    <LM>w#w-d1t878-1</LM>
   </w.rf>
   <form>Sienkiewicze</form>
   <lemma>Sienkiewicz_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m943-162-1067">
   <w.rf>
    <LM>w#w-162-1067</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t874-5">
   <w.rf>
    <LM>w#w-d1t874-5</LM>
   </w.rf>
   <form>přemýšlela</form>
   <lemma>přemýšlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t874-4">
   <w.rf>
    <LM>w#w-d1t874-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t874-6">
   <w.rf>
    <LM>w#w-d1t874-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t874-7">
   <w.rf>
    <LM>w#w-d1t874-7</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m943-d1t872-2">
   <w.rf>
    <LM>w#w-d1t872-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t874-1">
   <w.rf>
    <LM>w#w-d1t874-1</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1t874-2">
   <w.rf>
    <LM>w#w-d1t874-2</LM>
   </w.rf>
   <form>předem</form>
   <lemma>předem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-162-1068">
   <w.rf>
    <LM>w#w-162-1068</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1069">
  <m id="m943-d1t878-7">
   <w.rf>
    <LM>w#w-d1t878-7</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t878-5">
   <w.rf>
    <LM>w#w-d1t878-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t878-6">
   <w.rf>
    <LM>w#w-d1t878-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-162-179">
   <w.rf>
    <LM>w#w-162-179</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-162-180">
   <w.rf>
    <LM>w#w-162-180</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t878-8">
   <w.rf>
    <LM>w#w-d1t878-8</LM>
   </w.rf>
   <form>Ježiš</form>
   <lemma>ježiš_,e_^(^GC**jéžíš)</lemma>
   <tag>II-------------</tag>
  </m>
  <m id="m943-1069-1070">
   <w.rf>
    <LM>w#w-1069-1070</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-162-181">
   <w.rf>
    <LM>w#w-162-181</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-162-184">
   <w.rf>
    <LM>w#w-162-184</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t878-9">
   <w.rf>
    <LM>w#w-d1t878-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t878-10">
   <w.rf>
    <LM>w#w-d1t878-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t878-11">
   <w.rf>
    <LM>w#w-d1t878-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-162-186">
   <w.rf>
    <LM>w#w-162-186</LM>
   </w.rf>
   <form>psala</form>
   <lemma>psát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t881-2">
   <w.rf>
    <LM>w#w-d1t881-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t881-3">
   <w.rf>
    <LM>w#w-d1t881-3</LM>
   </w.rf>
   <form>papírek</form>
   <lemma>papírek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-162-187">
   <w.rf>
    <LM>w#w-162-187</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-188">
  <m id="m943-d1t881-5">
   <w.rf>
    <LM>w#w-d1t881-5</LM>
   </w.rf>
   <form>Papírek</form>
   <lemma>papírek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1t881-6">
   <w.rf>
    <LM>w#w-d1t881-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t881-7">
   <w.rf>
    <LM>w#w-d1t881-7</LM>
   </w.rf>
   <form>tužku</form>
   <lemma>tužka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t881-9">
   <w.rf>
    <LM>w#w-d1t881-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t881-10">
   <w.rf>
    <LM>w#w-d1t881-10</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d-id86135">
   <w.rf>
    <LM>w#w-d-id86135</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t881-12">
   <w.rf>
    <LM>w#w-d1t881-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t881-13">
   <w.rf>
    <LM>w#w-d1t881-13</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t881-14">
   <w.rf>
    <LM>w#w-d1t881-14</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m943-188-200">
   <w.rf>
    <LM>w#w-188-200</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t881-18">
   <w.rf>
    <LM>w#w-d1t881-18</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t881-20">
   <w.rf>
    <LM>w#w-d1t881-20</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t881-21">
   <w.rf>
    <LM>w#w-d1t881-21</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-188-203">
   <w.rf>
    <LM>w#w-188-203</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t881-22">
   <w.rf>
    <LM>w#w-d1t881-22</LM>
   </w.rf>
   <form>přivezly</form>
   <lemma>přivézt</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-188-552">
   <w.rf>
    <LM>w#w-188-552</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t881-24">
   <w.rf>
    <LM>w#w-d1t881-24</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m943-188-545">
   <w.rf>
    <LM>w#w-188-545</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-188-549">
   <w.rf>
    <LM>w#w-188-549</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t883-3">
   <w.rf>
    <LM>w#w-d1t883-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m943-d1t883-4">
   <w.rf>
    <LM>w#w-d1t883-4</LM>
   </w.rf>
   <form>nevzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-NAP--</tag>
  </m>
  <m id="m943-188-554">
   <w.rf>
    <LM>w#w-188-554</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-555">
  <m id="m943-d1t883-7">
   <w.rf>
    <LM>w#w-d1t883-7</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t883-6">
   <w.rf>
    <LM>w#w-d1t883-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t883-5">
   <w.rf>
    <LM>w#w-d1t883-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t883-8">
   <w.rf>
    <LM>w#w-d1t883-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t885-1">
   <w.rf>
    <LM>w#w-d1t885-1</LM>
   </w.rf>
   <form>příruční</form>
   <lemma>příruční</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m943-d1t885-2">
   <w.rf>
    <LM>w#w-d1t885-2</LM>
   </w.rf>
   <form>tašce</form>
   <lemma>taška</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m943-188-551">
   <w.rf>
    <LM>w#w-188-551</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-514">
  <m id="m943-d1t887-1">
   <w.rf>
    <LM>w#w-d1t887-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t887-2">
   <w.rf>
    <LM>w#w-d1t887-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t891-1">
   <w.rf>
    <LM>w#w-d1t891-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t891-3">
   <w.rf>
    <LM>w#w-d1t891-3</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1t891-6">
   <w.rf>
    <LM>w#w-d1t891-6</LM>
   </w.rf>
   <form>papír</form>
   <lemma>papír</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1t891-4">
   <w.rf>
    <LM>w#w-d1t891-4</LM>
   </w.rf>
   <form>sehnat</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-514-748">
   <w.rf>
    <LM>w#w-514-748</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t896-1">
   <w.rf>
    <LM>w#w-d1t896-1</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m943-d-id86782">
   <w.rf>
    <LM>w#w-d-id86782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t896-3">
   <w.rf>
    <LM>w#w-d1t896-3</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t896-4">
   <w.rf>
    <LM>w#w-d1t896-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t896-5">
   <w.rf>
    <LM>w#w-d1t896-5</LM>
   </w.rf>
   <form>sehnaly</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-d1t896-6">
   <w.rf>
    <LM>w#w-d1t896-6</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t896-8">
   <w.rf>
    <LM>w#w-d1t896-8</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHP1-P1-------</tag>
  </m>
  <m id="m943-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>vedoucí</form>
   <lemma>vedoucí-3</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-514-1076">
   <w.rf>
    <LM>w#w-514-1076</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1077">
  <m id="m943-d1t902-2">
   <w.rf>
    <LM>w#w-d1t902-2</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t902-1">
   <w.rf>
    <LM>w#w-d1t902-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t902-3">
   <w.rf>
    <LM>w#w-d1t902-3</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t902-6">
   <w.rf>
    <LM>w#w-d1t902-6</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t902-4">
   <w.rf>
    <LM>w#w-d1t902-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1t902-5">
   <w.rf>
    <LM>w#w-d1t902-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t902-8">
   <w.rf>
    <LM>w#w-d1t902-8</LM>
   </w.rf>
   <form>takovouhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m943-d1t902-9">
   <w.rf>
    <LM>w#w-d1t902-9</LM>
   </w.rf>
   <form>přípravu</form>
   <lemma>příprava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-514-756">
   <w.rf>
    <LM>w#w-514-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-757">
  <m id="m943-d1t904-2">
   <w.rf>
    <LM>w#w-d1t904-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t904-3">
   <w.rf>
    <LM>w#w-d1t904-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m943-d1t904-9">
   <w.rf>
    <LM>w#w-d1t904-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-757-766">
   <w.rf>
    <LM>w#w-757-766</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t904-5">
   <w.rf>
    <LM>w#w-d1t904-5</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t904-4">
   <w.rf>
    <LM>w#w-d1t904-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d-id87185">
   <w.rf>
    <LM>w#w-d-id87185</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t904-12">
   <w.rf>
    <LM>w#w-d1t904-12</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d1t904-13">
   <w.rf>
    <LM>w#w-d1t904-13</LM>
   </w.rf>
   <form>plus</form>
   <lemma>plus-1_^(znaménko_plus;_vyjádření_kladné_vlastnosti)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-757-768">
   <w.rf>
    <LM>w#w-757-768</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t907-1">
   <w.rf>
    <LM>w#w-d1t907-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t907-2">
   <w.rf>
    <LM>w#w-d1t907-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t907-3">
   <w.rf>
    <LM>w#w-d1t907-3</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m943-d1t907-4">
   <w.rf>
    <LM>w#w-d1t907-4</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAMP4----2A----</tag>
  </m>
  <m id="m943-d1t909-1">
   <w.rf>
    <LM>w#w-d1t909-1</LM>
   </w.rf>
   <form>vedli</form>
   <lemma>vést</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t909-2">
   <w.rf>
    <LM>w#w-d1t909-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d1t909-3">
   <w.rf>
    <LM>w#w-d1t909-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m943-d-id87438">
   <w.rf>
    <LM>w#w-d-id87438</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t909-5">
   <w.rf>
    <LM>w#w-d1t909-5</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m943-d1t909-9">
   <w.rf>
    <LM>w#w-d1t909-9</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t909-6">
   <w.rf>
    <LM>w#w-d1t909-6</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t909-7">
   <w.rf>
    <LM>w#w-d1t909-7</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t909-8">
   <w.rf>
    <LM>w#w-d1t909-8</LM>
   </w.rf>
   <form>intelektuálně</form>
   <lemma>intelektuálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-757-771">
   <w.rf>
    <LM>w#w-757-771</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-772">
  <m id="m943-d1t909-11">
   <w.rf>
    <LM>w#w-d1t909-11</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t911-2">
   <w.rf>
    <LM>w#w-d1t911-2</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m943-d1t911-3">
   <w.rf>
    <LM>w#w-d1t911-3</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m943-d1t911-1">
   <w.rf>
    <LM>w#w-d1t911-1</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t913-1">
   <w.rf>
    <LM>w#w-d1t913-1</LM>
   </w.rf>
   <form>starost</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t913-2">
   <w.rf>
    <LM>w#w-d1t913-2</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t913-3">
   <w.rf>
    <LM>w#w-d1t913-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t913-5">
   <w.rf>
    <LM>w#w-d1t913-5</LM>
   </w.rf>
   <form>žvanec</form>
   <lemma>žvanec</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1t913-6">
   <w.rf>
    <LM>w#w-d1t913-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-772-782">
   <w.rf>
    <LM>w#w-772-782</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-772-783">
   <w.rf>
    <LM>w#w-772-783</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-772-784">
   <w.rf>
    <LM>w#w-772-784</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t913-7">
   <w.rf>
    <LM>w#w-d1t913-7</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t924-1">
   <w.rf>
    <LM>w#w-d1t924-1</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m943-772-786">
   <w.rf>
    <LM>w#w-772-786</LM>
   </w.rf>
   <form>způsobem</form>
   <lemma>způsob</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m943-d1t924-2">
   <w.rf>
    <LM>w#w-d1t924-2</LM>
   </w.rf>
   <form>obstál</form>
   <lemma>obstát</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m943-d1t913-8">
   <w.rf>
    <LM>w#w-d1t913-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t913-10">
   <w.rf>
    <LM>w#w-d1t913-10</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m943-d-id87894">
   <w.rf>
    <LM>w#w-d-id87894</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e927-x2">
  <m id="m943-d1t930-1">
   <w.rf>
    <LM>w#w-d1t930-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t930-2">
   <w.rf>
    <LM>w#w-d1t930-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m943-d1t930-3">
   <w.rf>
    <LM>w#w-d1t930-3</LM>
   </w.rf>
   <form>vnímala</form>
   <lemma>vnímat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t930-4">
   <w.rf>
    <LM>w#w-d1t930-4</LM>
   </w.rf>
   <form>transporty</form>
   <lemma>transport</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m943-d1e927-x2-808">
   <w.rf>
    <LM>w#w-d1e927-x2-808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t930-6">
   <w.rf>
    <LM>w#w-d1t930-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t930-7">
   <w.rf>
    <LM>w#w-d1t930-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t930-8">
   <w.rf>
    <LM>w#w-d1t930-8</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d1e927-x2-807">
   <w.rf>
    <LM>w#w-d1e927-x2-807</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t930-9">
   <w.rf>
    <LM>w#w-d1t930-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t930-10">
   <w.rf>
    <LM>w#w-d1t930-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t930-11">
   <w.rf>
    <LM>w#w-d1t930-11</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d-id88069">
   <w.rf>
    <LM>w#w-d-id88069</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x2">
  <m id="m943-d1t940-1">
   <w.rf>
    <LM>w#w-d1t940-1</LM>
   </w.rf>
   <form>Transporty</form>
   <lemma>transport</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m943-d1t940-2">
   <w.rf>
    <LM>w#w-d1t940-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t940-3">
   <w.rf>
    <LM>w#w-d1t940-3</LM>
   </w.rf>
   <form>Terezína</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d1t951-2">
   <w.rf>
    <LM>w#w-d1t951-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m943-d1t947-1">
   <w.rf>
    <LM>w#w-d1t947-1</LM>
   </w.rf>
   <form>citově</form>
   <lemma>citově_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t953-1">
   <w.rf>
    <LM>w#w-d1t953-1</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m943-d1t955-1">
   <w.rf>
    <LM>w#w-d1t955-1</LM>
   </w.rf>
   <form>deprimovaly</form>
   <lemma>deprimovat</lemma>
   <tag>VpTP----R-AAB--</tag>
  </m>
  <m id="m943-d-id88439">
   <w.rf>
    <LM>w#w-d-id88439</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x3">
  <m id="m943-d1t962-8">
   <w.rf>
    <LM>w#w-d1t962-8</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t962-6">
   <w.rf>
    <LM>w#w-d1t962-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t962-7">
   <w.rf>
    <LM>w#w-d1t962-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1e931-x3-882">
   <w.rf>
    <LM>w#w-d1e931-x3-882</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t962-9">
   <w.rf>
    <LM>w#w-d1t962-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t962-10">
   <w.rf>
    <LM>w#w-d1t962-10</LM>
   </w.rf>
   <form>čeho</form>
   <lemma>co-1</lemma>
   <tag>PQ--2----------</tag>
  </m>
  <m id="m943-d1t962-13">
   <w.rf>
    <LM>w#w-d1t962-13</LM>
   </w.rf>
   <form>chudáci</form>
   <lemma>chudák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m943-d1t962-14">
   <w.rf>
    <LM>w#w-d1t962-14</LM>
   </w.rf>
   <form>jdou</form>
   <lemma>jít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m943-d1e931-x3-885">
   <w.rf>
    <LM>w#w-d1e931-x3-885</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x4">
  <m id="m943-d1t966-3">
   <w.rf>
    <LM>w#w-d1t966-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t966-2">
   <w.rf>
    <LM>w#w-d1t966-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m943-d1t966-4">
   <w.rf>
    <LM>w#w-d1t966-4</LM>
   </w.rf>
   <form>líto</form>
   <lemma>líto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t966-8">
   <w.rf>
    <LM>w#w-d1t966-8</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m943-d1e931-x4-978">
   <w.rf>
    <LM>w#w-d1e931-x4-978</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t966-9">
   <w.rf>
    <LM>w#w-d1t966-9</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m943-d1t966-10">
   <w.rf>
    <LM>w#w-d1t966-10</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t966-11">
   <w.rf>
    <LM>w#w-d1t966-11</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1e931-x4-1101">
   <w.rf>
    <LM>w#w-d1e931-x4-1101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1102">
  <m id="m943-d1t966-16">
   <w.rf>
    <LM>w#w-d1t966-16</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t966-14">
   <w.rf>
    <LM>w#w-d1t966-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t966-15">
   <w.rf>
    <LM>w#w-d1t966-15</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1e931-x4-993">
   <w.rf>
    <LM>w#w-d1e931-x4-993</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e931-x4-994">
   <w.rf>
    <LM>w#w-d1e931-x4-994</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t968-1">
   <w.rf>
    <LM>w#w-d1t968-1</LM>
   </w.rf>
   <form>Přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t968-2">
   <w.rf>
    <LM>w#w-d1t968-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t968-4">
   <w.rf>
    <LM>w#w-d1t968-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t968-3">
   <w.rf>
    <LM>w#w-d1t968-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t968-5">
   <w.rf>
    <LM>w#w-d1t968-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t968-6">
   <w.rf>
    <LM>w#w-d1t968-6</LM>
   </w.rf>
   <form>Čechách</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m943-1102-1103">
   <w.rf>
    <LM>w#w-1102-1103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1104">
  <m id="m943-d1t973-1">
   <w.rf>
    <LM>w#w-d1t973-1</LM>
   </w.rf>
   <form>Dokud</form>
   <lemma>dokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t973-2">
   <w.rf>
    <LM>w#w-d1t973-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t973-4">
   <w.rf>
    <LM>w#w-d1t973-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t973-5">
   <w.rf>
    <LM>w#w-d1t973-5</LM>
   </w.rf>
   <form>Čechách</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m943-d1e931-x4-987">
   <w.rf>
    <LM>w#w-d1e931-x4-987</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t975-2">
   <w.rf>
    <LM>w#w-d1t975-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t975-3">
   <w.rf>
    <LM>w#w-d1t975-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t975-4">
   <w.rf>
    <LM>w#w-d1t975-4</LM>
   </w.rf>
   <form>snad</form>
   <lemma>snad</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t975-5">
   <w.rf>
    <LM>w#w-d1t975-5</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m943-d1t975-6">
   <w.rf>
    <LM>w#w-d1t975-6</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m943-d1t975-8">
   <w.rf>
    <LM>w#w-d1t975-8</LM>
   </w.rf>
   <form>hrozného</form>
   <lemma>hrozný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m943-d1t975-9">
   <w.rf>
    <LM>w#w-d1t975-9</LM>
   </w.rf>
   <form>stát</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-d1e931-x4-989">
   <w.rf>
    <LM>w#w-d1e931-x4-989</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t977-1">
   <w.rf>
    <LM>w#w-d1t977-1</LM>
   </w.rf>
   <form>vždyť</form>
   <lemma>vždyť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t977-2">
   <w.rf>
    <LM>w#w-d1t977-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t977-4">
   <w.rf>
    <LM>w#w-d1t977-4</LM>
   </w.rf>
   <form>mamince</form>
   <lemma>maminka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m943-d1t977-5">
   <w.rf>
    <LM>w#w-d1t977-5</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-3</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d-id89413">
   <w.rf>
    <LM>w#w-d-id89413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e931-x4-995">
   <w.rf>
    <LM>w#w-d1e931-x4-995</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x5">
  <m id="m943-d1t984-2">
   <w.rf>
    <LM>w#w-d1t984-2</LM>
   </w.rf>
   <form>Strach</form>
   <lemma>strach</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1t984-3">
   <w.rf>
    <LM>w#w-d1t984-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t984-4">
   <w.rf>
    <LM>w#w-d1t984-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m943-d1e931-x5-1085">
   <w.rf>
    <LM>w#w-d1e931-x5-1085</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t984-5">
   <w.rf>
    <LM>w#w-d1t984-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t984-6">
   <w.rf>
    <LM>w#w-d1t984-6</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m943-d1t984-7">
   <w.rf>
    <LM>w#w-d1t984-7</LM>
   </w.rf>
   <form>pošlou</form>
   <lemma>poslat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m943-d1t984-8">
   <w.rf>
    <LM>w#w-d1t984-8</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t984-9">
   <w.rf>
    <LM>w#w-d1t984-9</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d-id89595">
   <w.rf>
    <LM>w#w-d-id89595</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t986-2">
   <w.rf>
    <LM>w#w-d1t986-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m943-d1t986-6">
   <w.rf>
    <LM>w#w-d1t986-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t986-8">
   <w.rf>
    <LM>w#w-d1t986-8</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d1t986-4">
   <w.rf>
    <LM>w#w-d1t986-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t986-5">
   <w.rf>
    <LM>w#w-d1t986-5</LM>
   </w.rf>
   <form>deprimoval</form>
   <lemma>deprimovat</lemma>
   <tag>VpYS----R-AAB--</tag>
  </m>
  <m id="m943-d1e931-x5-1109">
   <w.rf>
    <LM>w#w-d1e931-x5-1109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1110">
  <m id="m943-d1t988-2">
   <w.rf>
    <LM>w#w-d1t988-2</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t988-3">
   <w.rf>
    <LM>w#w-d1t988-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t992-1">
   <w.rf>
    <LM>w#w-d1t992-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t994-1">
   <w.rf>
    <LM>w#w-d1t994-1</LM>
   </w.rf>
   <form>lítost</form>
   <lemma>lítost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1e931-x5-1089">
   <w.rf>
    <LM>w#w-d1e931-x5-1089</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t999-1">
   <w.rf>
    <LM>w#w-d1t999-1</LM>
   </w.rf>
   <form>cítila</form>
   <lemma>cítit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t999-2">
   <w.rf>
    <LM>w#w-d1t999-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t999-4">
   <w.rf>
    <LM>w#w-d1t999-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t999-6">
   <w.rf>
    <LM>w#w-d1t999-6</LM>
   </w.rf>
   <form>lidmi</form>
   <lemma>lidé</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m943-d1e931-x5-1094">
   <w.rf>
    <LM>w#w-d1e931-x5-1094</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t999-7">
   <w.rf>
    <LM>w#w-d1t999-7</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m943-d1t999-8">
   <w.rf>
    <LM>w#w-d1t999-8</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t999-9">
   <w.rf>
    <LM>w#w-d1t999-9</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d-id90141">
   <w.rf>
    <LM>w#w-d-id90141</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x6">
  <m id="m943-d1t1003-1">
   <w.rf>
    <LM>w#w-d1t1003-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m943-d1e931-x6-1156">
   <w.rf>
    <LM>w#w-d1e931-x6-1156</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m943-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m943-d1e931-x6-1157">
   <w.rf>
    <LM>w#w-d1e931-x6-1157</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1005-2">
   <w.rf>
    <LM>w#w-d1t1005-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1005-3">
   <w.rf>
    <LM>w#w-d1t1005-3</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1e931-x6-1160">
   <w.rf>
    <LM>w#w-d1e931-x6-1160</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e931-x6-1161">
   <w.rf>
    <LM>w#w-d1e931-x6-1161</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1007-1">
   <w.rf>
    <LM>w#w-d1t1007-1</LM>
   </w.rf>
   <form>Přijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m943-d1t1007-2">
   <w.rf>
    <LM>w#w-d1t1007-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1007-3">
   <w.rf>
    <LM>w#w-d1t1007-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1007-4">
   <w.rf>
    <LM>w#w-d1t1007-4</LM>
   </w.rf>
   <form>každého</form>
   <lemma>každý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m943-d1e931-x6-1115">
   <w.rf>
    <LM>w#w-d1e931-x6-1115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1116">
  <m id="m943-d1t1007-7">
   <w.rf>
    <LM>w#w-d1t1007-7</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1007-8">
   <w.rf>
    <LM>w#w-d1t1007-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m943-d1t1007-9">
   <w.rf>
    <LM>w#w-d1t1007-9</LM>
   </w.rf>
   <form>trvat</form>
   <lemma>trvat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1007-10">
   <w.rf>
    <LM>w#w-d1t1007-10</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1e931-x6-1167">
   <w.rf>
    <LM>w#w-d1e931-x6-1167</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1010-1">
   <w.rf>
    <LM>w#w-d1t1010-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1010-2">
   <w.rf>
    <LM>w#w-d1t1010-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1010-3">
   <w.rf>
    <LM>w#w-d1t1010-3</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1010-4">
   <w.rf>
    <LM>w#w-d1t1010-4</LM>
   </w.rf>
   <form>musejí</form>
   <lemma>muset</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1010-5">
   <w.rf>
    <LM>w#w-d1t1010-5</LM>
   </w.rf>
   <form>dostat</form>
   <lemma>dostat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-d1t1010-6">
   <w.rf>
    <LM>w#w-d1t1010-6</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m943-d1t1010-7">
   <w.rf>
    <LM>w#w-d1t1010-7</LM>
   </w.rf>
   <form>Židé</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m943-d-id90582">
   <w.rf>
    <LM>w#w-d-id90582</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e931-x6-1162">
   <w.rf>
    <LM>w#w-d1e931-x6-1162</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x7">
  <m id="m943-d1t1014-4">
   <w.rf>
    <LM>w#w-d1t1014-4</LM>
   </w.rf>
   <form>Přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m943-d1t1014-3">
   <w.rf>
    <LM>w#w-d1t1014-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m943-d1e931-x7-1294">
   <w.rf>
    <LM>w#w-d1e931-x7-1294</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1014-7">
   <w.rf>
    <LM>w#w-d1t1014-7</LM>
   </w.rf>
   <form>přirozené</form>
   <lemma>přirozený</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d1e931-x7-1296">
   <w.rf>
    <LM>w#w-d1e931-x7-1296</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1016-3">
   <w.rf>
    <LM>w#w-d1t1016-3</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m943-d1t1016-1">
   <w.rf>
    <LM>w#w-d1t1016-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1016-2">
   <w.rf>
    <LM>w#w-d1t1016-2</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1016-4">
   <w.rf>
    <LM>w#w-d1t1016-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1e931-x7-1298">
   <w.rf>
    <LM>w#w-d1e931-x7-1298</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1016-6">
   <w.rf>
    <LM>w#w-d1t1016-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1018-2">
   <w.rf>
    <LM>w#w-d1t1018-2</LM>
   </w.rf>
   <form>neušetří</form>
   <lemma>ušetřit</lemma>
   <tag>VB-P---3P-NAP--</tag>
  </m>
  <m id="m943-d1t1018-3">
   <w.rf>
    <LM>w#w-d1t1018-3</LM>
   </w.rf>
   <form>nikoho</form>
   <lemma>nikdo</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m943-d1e931-x7-1118">
   <w.rf>
    <LM>w#w-d1e931-x7-1118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1119">
  <m id="m943-d1t1018-5">
   <w.rf>
    <LM>w#w-d1t1018-5</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1018-6">
   <w.rf>
    <LM>w#w-d1t1018-6</LM>
   </w.rf>
   <form>neskončí</form>
   <lemma>skončit</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m943-d1t1018-7">
   <w.rf>
    <LM>w#w-d1t1018-7</LM>
   </w.rf>
   <form>válka</form>
   <lemma>válka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1e931-x7-1301">
   <w.rf>
    <LM>w#w-d1e931-x7-1301</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1020-2">
   <w.rf>
    <LM>w#w-d1t1020-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1020-7">
   <w.rf>
    <LM>w#w-d1t1020-7</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m943-d1t1020-8">
   <w.rf>
    <LM>w#w-d1t1020-8</LM>
   </w.rf>
   <form>Žid</form>
   <lemma>Žid_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m943-d1t1020-5">
   <w.rf>
    <LM>w#w-d1t1020-5</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1020-6">
   <w.rf>
    <LM>w#w-d1t1020-6</LM>
   </w.rf>
   <form>počítat</form>
   <lemma>počítat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1020-3">
   <w.rf>
    <LM>w#w-d1t1020-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t1020-4">
   <w.rf>
    <LM>w#w-d1t1020-4</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m943-d1e931-x7-1762">
   <w.rf>
    <LM>w#w-d1e931-x7-1762</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1023-1">
   <w.rf>
    <LM>w#w-d1t1023-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1e931-x7-1765">
   <w.rf>
    <LM>w#w-d1e931-x7-1765</LM>
   </w.rf>
   <form>sem</form>
   <lemma>sem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1023-9">
   <w.rf>
    <LM>w#w-d1t1023-9</LM>
   </w.rf>
   <form>půjde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m943-d1e931-x7-1767">
   <w.rf>
    <LM>w#w-d1e931-x7-1767</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1735">
  <m id="m943-d1t1025-1">
   <w.rf>
    <LM>w#w-d1t1025-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1025-2">
   <w.rf>
    <LM>w#w-d1t1025-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m943-d1t1025-3">
   <w.rf>
    <LM>w#w-d1t1025-3</LM>
   </w.rf>
   <form>líto</form>
   <lemma>líto</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1025-5">
   <w.rf>
    <LM>w#w-d1t1025-5</LM>
   </w.rf>
   <form>starých</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m943-d1t1025-6">
   <w.rf>
    <LM>w#w-d1t1025-6</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m943-d-id91365">
   <w.rf>
    <LM>w#w-d-id91365</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-1735-1122">
   <w.rf>
    <LM>w#w-1735-1122</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1027-1">
   <w.rf>
    <LM>w#w-d1t1027-1</LM>
   </w.rf>
   <form>dokud</form>
   <lemma>dokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1025-9">
   <w.rf>
    <LM>w#w-d1t1025-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1027-3">
   <w.rf>
    <LM>w#w-d1t1027-3</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1029-1">
   <w.rf>
    <LM>w#w-d1t1029-1</LM>
   </w.rf>
   <form>takovouhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m943-d1t1029-3">
   <w.rf>
    <LM>w#w-d1t1029-3</LM>
   </w.rf>
   <form>denní</form>
   <lemma>denní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m943-d1t1029-4">
   <w.rf>
    <LM>w#w-d1t1029-4</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-1735-1775">
   <w.rf>
    <LM>w#w-1735-1775</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1031-1">
   <w.rf>
    <LM>w#w-d1t1031-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1031-2">
   <w.rf>
    <LM>w#w-d1t1031-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1031-3">
   <w.rf>
    <LM>w#w-d1t1031-3</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t1031-4">
   <w.rf>
    <LM>w#w-d1t1031-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1033-1">
   <w.rf>
    <LM>w#w-d1t1033-1</LM>
   </w.rf>
   <form>posíláni</form>
   <lemma>posílat</lemma>
   <tag>VsMP----X-API--</tag>
  </m>
  <m id="m943-d1t1033-2">
   <w.rf>
    <LM>w#w-d1t1033-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1033-3">
   <w.rf>
    <LM>w#w-d1t1033-3</LM>
   </w.rf>
   <form>pomoc</form>
   <lemma>pomoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t1036-1">
   <w.rf>
    <LM>w#w-d1t1036-1</LM>
   </w.rf>
   <form>přijíždějícím</form>
   <lemma>přijíždějící_^(*4t)</lemma>
   <tag>AGIP3-----A----</tag>
  </m>
  <m id="m943-d1t1036-2">
   <w.rf>
    <LM>w#w-d1t1036-2</LM>
   </w.rf>
   <form>transportům</form>
   <lemma>transport</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m943-1735-1777">
   <w.rf>
    <LM>w#w-1735-1777</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1778">
  <m id="m943-d1t1040-3">
   <w.rf>
    <LM>w#w-d1t1040-3</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1042-2">
   <w.rf>
    <LM>w#w-d1t1042-2</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m943-d1t1042-3">
   <w.rf>
    <LM>w#w-d1t1042-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1042-4">
   <w.rf>
    <LM>w#w-d1t1042-4</LM>
   </w.rf>
   <form>poslali</form>
   <lemma>poslat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m943-d1t1042-5">
   <w.rf>
    <LM>w#w-d1t1042-5</LM>
   </w.rf>
   <form>celou</form>
   <lemma>celý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m943-d1t1042-6">
   <w.rf>
    <LM>w#w-d1t1042-6</LM>
   </w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t1042-7">
   <w.rf>
    <LM>w#w-d1t1042-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1042-9">
   <w.rf>
    <LM>w#w-d1t1042-9</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m943-d1t1042-10">
   <w.rf>
    <LM>w#w-d1t1042-10</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1042-11">
   <w.rf>
    <LM>w#w-d1t1042-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1042-12">
   <w.rf>
    <LM>w#w-d1t1042-12</LM>
   </w.rf>
   <form>starosti</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m943-d1t1042-15">
   <w.rf>
    <LM>w#w-d1t1042-15</LM>
   </w.rf>
   <form>dvě</form>
   <lemma>dva`2</lemma>
   <tag>CnHP4----------</tag>
  </m>
  <m id="m943-d1t1042-17">
   <w.rf>
    <LM>w#w-d1t1042-17</LM>
   </w.rf>
   <form>babičky</form>
   <lemma>babička</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m943-d1t1044-1">
   <w.rf>
    <LM>w#w-d1t1044-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1044-5">
   <w.rf>
    <LM>w#w-d1t1044-5</LM>
   </w.rf>
   <form>vedly</form>
   <lemma>vést</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1044-3">
   <w.rf>
    <LM>w#w-d1t1044-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1044-4">
   <w.rf>
    <LM>w#w-d1t1044-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m943-1778-1789">
   <w.rf>
    <LM>w#w-1778-1789</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1790">
  <m id="m943-d1t1046-8">
   <w.rf>
    <LM>w#w-d1t1046-8</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1046-7">
   <w.rf>
    <LM>w#w-d1t1046-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1046-9">
   <w.rf>
    <LM>w#w-d1t1046-9</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m943-d1t1046-11">
   <w.rf>
    <LM>w#w-d1t1046-11</LM>
   </w.rf>
   <form>šokující</form>
   <lemma>šokující_^(*5ovat)</lemma>
   <tag>AGIS1-----A----</tag>
  </m>
  <m id="m943-d1t1049-1">
   <w.rf>
    <LM>w#w-d1t1049-1</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d-id92412">
   <w.rf>
    <LM>w#w-d-id92412</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m943-d1t1051-4">
   <w.rf>
    <LM>w#w-d1t1051-4</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1t1051-5">
   <w.rf>
    <LM>w#w-d1t1051-5</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m943-d1t1051-7">
   <w.rf>
    <LM>w#w-d1t1051-7</LM>
   </w.rf>
   <form>neprošel</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m943-d-id92532">
   <w.rf>
    <LM>w#w-d-id92532</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1051-9">
   <w.rf>
    <LM>w#w-d1t1051-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1053-3">
   <w.rf>
    <LM>w#w-d1t1053-3</LM>
   </w.rf>
   <form>například</form>
   <lemma>například</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1053-1">
   <w.rf>
    <LM>w#w-d1t1053-1</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m943-d1t1053-2">
   <w.rf>
    <LM>w#w-d1t1053-2</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1t1057-1">
   <w.rf>
    <LM>w#w-d1t1057-1</LM>
   </w.rf>
   <form>prošel</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m943-d1t1059-1">
   <w.rf>
    <LM>w#w-d1t1059-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1059-2">
   <w.rf>
    <LM>w#w-d1t1059-2</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d1t1057-2">
   <w.rf>
    <LM>w#w-d1t1057-2</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m943-d1t1057-3">
   <w.rf>
    <LM>w#w-d1t1057-3</LM>
   </w.rf>
   <form>prohlídkou</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d-id92676">
   <w.rf>
    <LM>w#w-d-id92676</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x10">
  <m id="m943-d1e931-x10-2454">
   <w.rf>
    <LM>w#w-d1e931-x10-2454</LM>
   </w.rf>
   <form>Musely</form>
   <lemma>muset</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1e931-x10-2455">
   <w.rf>
    <LM>w#w-d1e931-x10-2455</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1064-2">
   <w.rf>
    <LM>w#w-d1t1064-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t1064-3">
   <w.rf>
    <LM>w#w-d1t1064-3</LM>
   </w.rf>
   <form>naha</form>
   <lemma>naho</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m943-d1e931-x10-2457">
   <w.rf>
    <LM>w#w-d1e931-x10-2457</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1066-3">
   <w.rf>
    <LM>w#w-d1t1066-3</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLFP4----------</tag>
  </m>
  <m id="m943-d1t1066-4">
   <w.rf>
    <LM>w#w-d1t1066-4</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m943-d1e931-x10-2456">
   <w.rf>
    <LM>w#w-d1e931-x10-2456</LM>
   </w.rf>
   <form>dát</form>
   <lemma>dát-1</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-d1t1066-5">
   <w.rf>
    <LM>w#w-d1t1066-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1066-6">
   <w.rf>
    <LM>w#w-d1t1066-6</LM>
   </w.rf>
   <form>hromádku</form>
   <lemma>hromádka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1e931-x10-1132">
   <w.rf>
    <LM>w#w-d1e931-x10-1132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1133">
  <m id="m943-d1t1066-10">
   <w.rf>
    <LM>w#w-d1t1066-10</LM>
   </w.rf>
   <form>Němky</form>
   <lemma>Němka_;E</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-d1t1066-11">
   <w.rf>
    <LM>w#w-d1t1066-11</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m943-d1t1066-12">
   <w.rf>
    <LM>w#w-d1t1066-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t1070-1">
   <w.rf>
    <LM>w#w-d1t1070-1</LM>
   </w.rf>
   <form>prohledaly</form>
   <lemma>prohledat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-d1e931-x10-2458">
   <w.rf>
    <LM>w#w-d1e931-x10-2458</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1070-4">
   <w.rf>
    <LM>w#w-d1t1070-4</LM>
   </w.rf>
   <form>včetně</form>
   <lemma>včetně-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t1070-5">
   <w.rf>
    <LM>w#w-d1t1070-5</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m943-d1e931-x10-2459">
   <w.rf>
    <LM>w#w-d1e931-x10-2459</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1072-1">
   <w.rf>
    <LM>w#w-d1t1072-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1072-2">
   <w.rf>
    <LM>w#w-d1t1072-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1072-3">
   <w.rf>
    <LM>w#w-d1t1072-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1072-4">
   <w.rf>
    <LM>w#w-d1t1072-4</LM>
   </w.rf>
   <form>musela</form>
   <lemma>muset</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1072-5">
   <w.rf>
    <LM>w#w-d1t1072-5</LM>
   </w.rf>
   <form>ohnout</form>
   <lemma>ohnout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-d1t1072-6">
   <w.rf>
    <LM>w#w-d1t1072-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1081-3">
   <w.rf>
    <LM>w#w-d1t1081-3</LM>
   </w.rf>
   <form>dívaly</form>
   <lemma>dívat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1e931-x10-2461">
   <w.rf>
    <LM>w#w-d1e931-x10-2461</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1081-2">
   <w.rf>
    <LM>w#w-d1t1081-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m943-d1t1081-4">
   <w.rf>
    <LM>w#w-d1t1081-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t1081-5">
   <w.rf>
    <LM>w#w-d1t1081-5</LM>
   </w.rf>
   <form>řitního</form>
   <lemma>řitní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m943-d1t1081-6">
   <w.rf>
    <LM>w#w-d1t1081-6</LM>
   </w.rf>
   <form>otvoru</form>
   <lemma>otvor</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-1133-1134">
   <w.rf>
    <LM>w#w-1133-1134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1135">
  <m id="m943-1135-1136">
   <w.rf>
    <LM>w#w-1135-1136</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1090-4">
   <w.rf>
    <LM>w#w-d1t1090-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1090-6">
   <w.rf>
    <LM>w#w-d1t1090-6</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d-id93659">
   <w.rf>
    <LM>w#w-d-id93659</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x11">
  <m id="m943-d1t1094-1">
   <w.rf>
    <LM>w#w-d1t1094-1</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1094-2">
   <w.rf>
    <LM>w#w-d1t1094-2</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1094-3">
   <w.rf>
    <LM>w#w-d1t1094-3</LM>
   </w.rf>
   <form>nahá</form>
   <lemma>nahý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m943-d1t1094-4">
   <w.rf>
    <LM>w#w-d1t1094-4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t1094-5">
   <w.rf>
    <LM>w#w-d1t1094-5</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m943-d1t1096-5">
   <w.rf>
    <LM>w#w-d1t1096-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1096-2">
   <w.rf>
    <LM>w#w-d1t1096-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t1096-3">
   <w.rf>
    <LM>w#w-d1t1096-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m943-d1t1096-4">
   <w.rf>
    <LM>w#w-d1t1096-4</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m943-d1t1096-6">
   <w.rf>
    <LM>w#w-d1t1096-6</LM>
   </w.rf>
   <form>neznala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m943-d-id93865">
   <w.rf>
    <LM>w#w-d-id93865</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x12">
  <m id="m943-d1t1103-1">
   <w.rf>
    <LM>w#w-d1t1103-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1103-2">
   <w.rf>
    <LM>w#w-d1t1103-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m943-d1t1103-3">
   <w.rf>
    <LM>w#w-d1t1103-3</LM>
   </w.rf>
   <form>šestnáct</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m943-d-id93993">
   <w.rf>
    <LM>w#w-d-id93993</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x13">
  <m id="m943-d1t1111-2">
   <w.rf>
    <LM>w#w-d1t1111-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1111-1">
   <w.rf>
    <LM>w#w-d1t1111-1</LM>
   </w.rf>
   <form>fakt</form>
   <lemma>fakt-1</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1e931-x13-2619">
   <w.rf>
    <LM>w#w-d1e931-x13-2619</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1111-5">
   <w.rf>
    <LM>w#w-d1t1111-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1114-1">
   <w.rf>
    <LM>w#w-d1t1114-1</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1114-2">
   <w.rf>
    <LM>w#w-d1t1114-2</LM>
   </w.rf>
   <form>ženy</form>
   <lemma>žena</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-d1t1114-3">
   <w.rf>
    <LM>w#w-d1t1114-3</LM>
   </w.rf>
   <form>zvlášť</form>
   <lemma>zvlášť-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1e931-x13-1149">
   <w.rf>
    <LM>w#w-d1e931-x13-1149</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1150">
  <m id="m943-d1t1116-2">
   <w.rf>
    <LM>w#w-d1t1116-2</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1116-3">
   <w.rf>
    <LM>w#w-d1t1116-3</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m943-d1t1116-4">
   <w.rf>
    <LM>w#w-d1t1116-4</LM>
   </w.rf>
   <form>masa</form>
   <lemma>masa_^(velké_množství)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1e931-x13-2620">
   <w.rf>
    <LM>w#w-d1e931-x13-2620</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1116-6">
   <w.rf>
    <LM>w#w-d1t1116-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1e931-x13-2621">
   <w.rf>
    <LM>w#w-d1e931-x13-2621</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1116-7">
   <w.rf>
    <LM>w#w-d1t1116-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1116-8">
   <w.rf>
    <LM>w#w-d1t1116-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1116-9">
   <w.rf>
    <LM>w#w-d1t1116-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1116-10">
   <w.rf>
    <LM>w#w-d1t1116-10</LM>
   </w.rf>
   <form>setkala</form>
   <lemma>setkat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m943-d1t1116-11">
   <w.rf>
    <LM>w#w-d1t1116-11</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1116-12">
   <w.rf>
    <LM>w#w-d1t1116-12</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1t1118-1">
   <w.rf>
    <LM>w#w-d1t1118-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t1118-2">
   <w.rf>
    <LM>w#w-d1t1118-2</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m943-d1t1118-3">
   <w.rf>
    <LM>w#w-d1t1118-3</LM>
   </w.rf>
   <form>spoustou</form>
   <lemma>spousta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d1t1118-5">
   <w.rf>
    <LM>w#w-d1t1118-5</LM>
   </w.rf>
   <form>nahých</form>
   <lemma>nahý</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m943-d1t1118-6">
   <w.rf>
    <LM>w#w-d1t1118-6</LM>
   </w.rf>
   <form>žen</form>
   <lemma>žena</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m943-d-id94631">
   <w.rf>
    <LM>w#w-d-id94631</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1118-11">
   <w.rf>
    <LM>w#w-d1t1118-11</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1118-13">
   <w.rf>
    <LM>w#w-d1t1118-13</LM>
   </w.rf>
   <form>hrozné</form>
   <lemma>hrozný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d-id94732">
   <w.rf>
    <LM>w#w-d-id94732</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x14">
  <m id="m943-d1t1122-2">
   <w.rf>
    <LM>w#w-d1t1122-2</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d-id94889">
   <w.rf>
    <LM>w#w-d-id94889</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1122-4">
   <w.rf>
    <LM>w#w-d1t1122-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1122-8">
   <w.rf>
    <LM>w#w-d1t1122-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m943-d1t1122-9">
   <w.rf>
    <LM>w#w-d1t1122-9</LM>
   </w.rf>
   <form>neprošly</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpTP----R-NAP--</tag>
  </m>
  <m id="m943-d1t1122-6">
   <w.rf>
    <LM>w#w-d1t1122-6</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m943-d1t1122-7">
   <w.rf>
    <LM>w#w-d1t1122-7</LM>
   </w.rf>
   <form>transporty</form>
   <lemma>transport</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m943-d-id94991">
   <w.rf>
    <LM>w#w-d-id94991</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x15">
  <m id="m943-d1t1124-2">
   <w.rf>
    <LM>w#w-d1t1124-2</LM>
   </w.rf>
   <form>My</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m943-d1t1124-3">
   <w.rf>
    <LM>w#w-d1t1124-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1124-4">
   <w.rf>
    <LM>w#w-d1t1124-4</LM>
   </w.rf>
   <form>prošli</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m943-d1t1127-1">
   <w.rf>
    <LM>w#w-d1t1127-1</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m943-d1t1127-2">
   <w.rf>
    <LM>w#w-d1t1127-2</LM>
   </w.rf>
   <form>prohlídkou</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d1t1129-1">
   <w.rf>
    <LM>w#w-d1t1129-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m943-d1t1129-3">
   <w.rf>
    <LM>w#w-d1t1129-3</LM>
   </w.rf>
   <form>šlojzce</form>
   <lemma>šlojzka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d-id95181">
   <w.rf>
    <LM>w#w-d-id95181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x17">
  <m id="m943-d1e931-x17-1164">
   <w.rf>
    <LM>w#w-d1e931-x17-1164</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1135-1">
   <w.rf>
    <LM>w#w-d1t1135-1</LM>
   </w.rf>
   <form>Šlojzka</form>
   <lemma>šlojzka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d1e931-x17-1165">
   <w.rf>
    <LM>w#w-d1e931-x17-1165</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1135-3">
   <w.rf>
    <LM>w#w-d1t1135-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1137-1">
   <w.rf>
    <LM>w#w-d1t1137-1</LM>
   </w.rf>
   <form>speciální</form>
   <lemma>speciální</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m943-d1t1137-2">
   <w.rf>
    <LM>w#w-d1t1137-2</LM>
   </w.rf>
   <form>název</form>
   <lemma>název</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d-id95340">
   <w.rf>
    <LM>w#w-d-id95340</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1142-4">
   <w.rf>
    <LM>w#w-d1t1142-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1142-1">
   <w.rf>
    <LM>w#w-d1t1142-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1144-1">
   <w.rf>
    <LM>w#w-d1t1144-1</LM>
   </w.rf>
   <form>kasárna</form>
   <lemma>kasárna</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m943-d1e931-x17-2776">
   <w.rf>
    <LM>w#w-d1e931-x17-2776</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1148-1">
   <w.rf>
    <LM>w#w-d1t1148-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1148-2">
   <w.rf>
    <LM>w#w-d1t1148-2</LM>
   </w.rf>
   <form>přicházely</form>
   <lemma>přicházet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1153-1">
   <w.rf>
    <LM>w#w-d1t1153-1</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLIP1----------</tag>
  </m>
  <m id="m943-d1t1153-2">
   <w.rf>
    <LM>w#w-d1t1153-2</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m943-d1t1153-3">
   <w.rf>
    <LM>w#w-d1t1153-3</LM>
   </w.rf>
   <form>transporty</form>
   <lemma>transport</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m943-d-id95565">
   <w.rf>
    <LM>w#w-d-id95565</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x18">
  <m id="m943-d1t1163-3">
   <w.rf>
    <LM>w#w-d1t1163-3</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m943-d1t1163-2">
   <w.rf>
    <LM>w#w-d1t1163-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1163-1">
   <w.rf>
    <LM>w#w-d1t1163-1</LM>
   </w.rf>
   <form>musel</form>
   <lemma>muset</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1163-4">
   <w.rf>
    <LM>w#w-d1t1163-4</LM>
   </w.rf>
   <form>přiznat</form>
   <lemma>přiznat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m943-d-id95841">
   <w.rf>
    <LM>w#w-d-id95841</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1163-6">
   <w.rf>
    <LM>w#w-d1t1163-6</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1168-3">
   <w.rf>
    <LM>w#w-d1t1168-3</LM>
   </w.rf>
   <form>neprováží</form>
   <lemma>provážet_^(př._přes_hranice)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m943-d1t1168-4">
   <w.rf>
    <LM>w#w-d1t1168-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m943-d1t1168-8">
   <w.rf>
    <LM>w#w-d1t1168-8</LM>
   </w.rf>
   <form>cenného</form>
   <lemma>cenný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m943-d1e931-x18-190">
   <w.rf>
    <LM>w#w-d1e931-x18-190</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1168-9">
   <w.rf>
    <LM>w#w-d1t1168-9</LM>
   </w.rf>
   <form>což</form>
   <lemma>což-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m943-d1t1168-10">
   <w.rf>
    <LM>w#w-d1t1168-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1168-11">
   <w.rf>
    <LM>w#w-d1t1168-11</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m943-d1t1168-12">
   <w.rf>
    <LM>w#w-d1t1168-12</LM>
   </w.rf>
   <form>zakázané</form>
   <lemma>zakázaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d1e931-x18-195">
   <w.rf>
    <LM>w#w-d1e931-x18-195</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-196">
  <m id="m943-d1t1168-15">
   <w.rf>
    <LM>w#w-d1t1168-15</LM>
   </w.rf>
   <form>Nesměly</form>
   <lemma>smět</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m943-d1t1168-16">
   <w.rf>
    <LM>w#w-d1t1168-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1168-17">
   <w.rf>
    <LM>w#w-d1t1168-17</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1168-18">
   <w.rf>
    <LM>w#w-d1t1168-18</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d1t1170-4">
   <w.rf>
    <LM>w#w-d1t1170-4</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1170-1">
   <w.rf>
    <LM>w#w-d1t1170-1</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m943-d1t1170-2">
   <w.rf>
    <LM>w#w-d1t1170-2</LM>
   </w.rf>
   <form>cennosti</form>
   <lemma>cennost_^(*3ý)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-196-206">
   <w.rf>
    <LM>w#w-196-206</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1170-5">
   <w.rf>
    <LM>w#w-d1t1170-5</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWNS1----------</tag>
  </m>
  <m id="m943-d1t1170-6">
   <w.rf>
    <LM>w#w-d1t1170-6</LM>
   </w.rf>
   <form>zlato</form>
   <lemma>zlato</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m943-d-id96251">
   <w.rf>
    <LM>w#w-d-id96251</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1170-10">
   <w.rf>
    <LM>w#w-d1t1170-10</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWIP1----------</tag>
  </m>
  <m id="m943-d1t1170-11">
   <w.rf>
    <LM>w#w-d1t1170-11</LM>
   </w.rf>
   <form>šperky</form>
   <lemma>šperk</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m943-196-212">
   <w.rf>
    <LM>w#w-196-212</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1170-12">
   <w.rf>
    <LM>w#w-d1t1170-12</LM>
   </w.rf>
   <form>nesmělo</form>
   <lemma>smět</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m943-196-215">
   <w.rf>
    <LM>w#w-196-215</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1170-14">
   <w.rf>
    <LM>w#w-d1t1170-14</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1170-15">
   <w.rf>
    <LM>w#w-d1t1170-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m943-196-216">
   <w.rf>
    <LM>w#w-196-216</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1172-3">
   <w.rf>
    <LM>w#w-d1t1172-3</LM>
   </w.rf>
   <form>žádné</form>
   <lemma>žádný</lemma>
   <tag>PWIP1----------</tag>
  </m>
  <m id="m943-d1t1172-4">
   <w.rf>
    <LM>w#w-d1t1172-4</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m943-196-218">
   <w.rf>
    <LM>w#w-196-218</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1174-2">
   <w.rf>
    <LM>w#w-d1t1174-2</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t1174-3">
   <w.rf>
    <LM>w#w-d1t1174-3</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m943-d1t1174-4">
   <w.rf>
    <LM>w#w-d1t1174-4</LM>
   </w.rf>
   <form>nesměl</form>
   <lemma>smět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m943-d1t1174-5">
   <w.rf>
    <LM>w#w-d1t1174-5</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m943-d1t1174-6">
   <w.rf>
    <LM>w#w-d1t1174-6</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d-id96558">
   <w.rf>
    <LM>w#w-d-id96558</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e931-x19">
  <m id="m943-d1t1179-4">
   <w.rf>
    <LM>w#w-d1t1179-4</LM>
   </w.rf>
   <form>Šlojzkou</form>
   <lemma>šlojzka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d1t1181-3">
   <w.rf>
    <LM>w#w-d1t1181-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1181-4">
   <w.rf>
    <LM>w#w-d1t1181-4</LM>
   </w.rf>
   <form>prošlo</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m943-d1e931-x19-277">
   <w.rf>
    <LM>w#w-d1e931-x19-277</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1183-1">
   <w.rf>
    <LM>w#w-d1t1183-1</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1183-3">
   <w.rf>
    <LM>w#w-d1t1183-3</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m943-d1t1183-4">
   <w.rf>
    <LM>w#w-d1t1183-4</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1t1183-5">
   <w.rf>
    <LM>w#w-d1t1183-5</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m943-d1t1189-1">
   <w.rf>
    <LM>w#w-d1t1189-1</LM>
   </w.rf>
   <form>podroben</form>
   <lemma>podrobit</lemma>
   <tag>VsYS----X-APP--</tag>
  </m>
  <m id="m943-d1t1189-3">
   <w.rf>
    <LM>w#w-d1t1189-3</LM>
   </w.rf>
   <form>osobní</form>
   <lemma>osobní</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m943-d1t1189-4">
   <w.rf>
    <LM>w#w-d1t1189-4</LM>
   </w.rf>
   <form>prohlídce</form>
   <lemma>prohlídka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m943-d1e931-x19-349">
   <w.rf>
    <LM>w#w-d1e931-x19-349</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1192-1">
   <w.rf>
    <LM>w#w-d1t1192-1</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m943-d1t1192-2">
   <w.rf>
    <LM>w#w-d1t1192-2</LM>
   </w.rf>
   <form>transport</form>
   <lemma>transport</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m943-d1e931-x19-351">
   <w.rf>
    <LM>w#w-d1e931-x19-351</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1192-3">
   <w.rf>
    <LM>w#w-d1t1192-3</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d-id97015">
   <w.rf>
    <LM>w#w-d-id97015</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e1193-x2">
  <m id="m943-d1t1196-1">
   <w.rf>
    <LM>w#w-d1t1196-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1196-2">
   <w.rf>
    <LM>w#w-d1t1196-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1t1196-3">
   <w.rf>
    <LM>w#w-d1t1196-3</LM>
   </w.rf>
   <form>vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m943-d1t1196-4">
   <w.rf>
    <LM>w#w-d1t1196-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1196-5">
   <w.rf>
    <LM>w#w-d1t1196-5</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m943-d1t1196-6">
   <w.rf>
    <LM>w#w-d1t1196-6</LM>
   </w.rf>
   <form>okrašlovací</form>
   <lemma>okrašlovací_^(*2t)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m943-d1t1196-7">
   <w.rf>
    <LM>w#w-d1t1196-7</LM>
   </w.rf>
   <form>akci</form>
   <lemma>akce</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1e1193-x2-443">
   <w.rf>
    <LM>w#w-d1e1193-x2-443</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1196-8">
   <w.rf>
    <LM>w#w-d1t1196-8</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m943-d1t1196-9">
   <w.rf>
    <LM>w#w-d1t1196-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1196-10">
   <w.rf>
    <LM>w#w-d1t1196-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1196-11">
   <w.rf>
    <LM>w#w-d1t1196-11</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d1t1202-1">
   <w.rf>
    <LM>w#w-d1t1202-1</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1202-2">
   <w.rf>
    <LM>w#w-d1t1202-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1202-3">
   <w.rf>
    <LM>w#w-d1t1202-3</LM>
   </w.rf>
   <form>souvislosti</form>
   <lemma>souvislost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m943-d1t1202-4">
   <w.rf>
    <LM>w#w-d1t1202-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t1202-6">
   <w.rf>
    <LM>w#w-d1t1202-6</LM>
   </w.rf>
   <form>návštěvou</form>
   <lemma>návštěva</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m943-d1t1202-7">
   <w.rf>
    <LM>w#w-d1t1202-7</LM>
   </w.rf>
   <form>Červeného</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m943-d1t1202-8">
   <w.rf>
    <LM>w#w-d1t1202-8</LM>
   </w.rf>
   <form>kříže</form>
   <lemma>kříž</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d-id97362">
   <w.rf>
    <LM>w#w-d-id97362</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e1197-x4">
  <m id="m943-d1t1216-6">
   <w.rf>
    <LM>w#w-d1t1216-6</LM>
   </w.rf>
   <form>Hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t1216-2">
   <w.rf>
    <LM>w#w-d1t1216-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1216-3">
   <w.rf>
    <LM>w#w-d1t1216-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1216-7">
   <w.rf>
    <LM>w#w-d1t1216-7</LM>
   </w.rf>
   <form>těšily</form>
   <lemma>těšit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1216-9">
   <w.rf>
    <LM>w#w-d1t1216-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1216-11">
   <w.rf>
    <LM>w#w-d1t1216-11</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t1216-12">
   <w.rf>
    <LM>w#w-d1t1216-12</LM>
   </w.rf>
   <form>Červeného</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m943-d1t1216-13">
   <w.rf>
    <LM>w#w-d1t1216-13</LM>
   </w.rf>
   <form>kříže</form>
   <lemma>kříž</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d-id97808">
   <w.rf>
    <LM>w#w-d-id97808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1221-3">
   <w.rf>
    <LM>w#w-d1t1221-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1221-4">
   <w.rf>
    <LM>w#w-d1t1221-4</LM>
   </w.rf>
   <form>jakmile</form>
   <lemma>jakmile</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1221-5">
   <w.rf>
    <LM>w#w-d1t1221-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1221-6">
   <w.rf>
    <LM>w#w-d1t1221-6</LM>
   </w.rf>
   <form>začaly</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-d1t1221-7">
   <w.rf>
    <LM>w#w-d1t1221-7</LM>
   </w.rf>
   <form>dělat</form>
   <lemma>dělat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d1t1221-9">
   <w.rf>
    <LM>w#w-d1t1221-9</LM>
   </w.rf>
   <form>Potěmkinovy</form>
   <lemma>Potěmkinův_;Y_^(*2)</lemma>
   <tag>AUFP1M---------</tag>
  </m>
  <m id="m943-d1t1221-10">
   <w.rf>
    <LM>w#w-d1t1221-10</LM>
   </w.rf>
   <form>vesnice</form>
   <lemma>vesnice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-d1e1207-x2-782">
   <w.rf>
    <LM>w#w-d1e1207-x2-782</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1223-1">
   <w.rf>
    <LM>w#w-d1t1223-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1223-2">
   <w.rf>
    <LM>w#w-d1t1223-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1223-4">
   <w.rf>
    <LM>w#w-d1t1223-4</LM>
   </w.rf>
   <form>veškerý</form>
   <lemma>veškerý</lemma>
   <tag>PLIS4----------</tag>
  </m>
  <m id="m943-d1t1223-5">
   <w.rf>
    <LM>w#w-d1t1223-5</LM>
   </w.rf>
   <form>zájem</form>
   <lemma>zájem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1t1223-7">
   <w.rf>
    <LM>w#w-d1t1223-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1223-8">
   <w.rf>
    <LM>w#w-d1t1223-8</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t1223-9">
   <w.rf>
    <LM>w#w-d1t1223-9</LM>
   </w.rf>
   <form>Červeného</form>
   <lemma>červený-1_;o</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m943-d1t1223-10">
   <w.rf>
    <LM>w#w-d1t1223-10</LM>
   </w.rf>
   <form>kříže</form>
   <lemma>kříž</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m943-d1t1223-3">
   <w.rf>
    <LM>w#w-d1t1223-3</LM>
   </w.rf>
   <form>ztratily</form>
   <lemma>ztratit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-d1e1197-x4-1203">
   <w.rf>
    <LM>w#w-d1e1197-x4-1203</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1204">
  <m id="m943-d1t1223-13">
   <w.rf>
    <LM>w#w-d1t1223-13</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1223-12">
   <w.rf>
    <LM>w#w-d1t1223-12</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m943-d1t1223-14">
   <w.rf>
    <LM>w#w-d1t1223-14</LM>
   </w.rf>
   <form>jasné</form>
   <lemma>jasný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d1e1207-x2-791">
   <w.rf>
    <LM>w#w-d1e1207-x2-791</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1225-1">
   <w.rf>
    <LM>w#w-d1t1225-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1225-2">
   <w.rf>
    <LM>w#w-d1t1225-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1225-4">
   <w.rf>
    <LM>w#w-d1t1225-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d1t1225-5">
   <w.rf>
    <LM>w#w-d1t1225-5</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m943-d1t1225-6">
   <w.rf>
    <LM>w#w-d1t1225-6</LM>
   </w.rf>
   <form>lidem</form>
   <lemma>lidé</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m943-d1t1225-3">
   <w.rf>
    <LM>w#w-d1t1225-3</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1227-1">
   <w.rf>
    <LM>w#w-d1t1227-1</LM>
   </w.rf>
   <form>nedostaneme</form>
   <lemma>dostat</lemma>
   <tag>VB-P---1P-NAP--</tag>
  </m>
  <m id="m943-d1t1229-1">
   <w.rf>
    <LM>w#w-d1t1229-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1229-2">
   <w.rf>
    <LM>w#w-d1t1229-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1229-4">
   <w.rf>
    <LM>w#w-d1t1229-4</LM>
   </w.rf>
   <form>lidé</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m943-d1t1229-5">
   <w.rf>
    <LM>w#w-d1t1229-5</LM>
   </w.rf>
   <form>neuvidí</form>
   <lemma>uvidět</lemma>
   <tag>VB-P---3P-NAP--</tag>
  </m>
  <m id="m943-d-id98533">
   <w.rf>
    <LM>w#w-d-id98533</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1229-7">
   <w.rf>
    <LM>w#w-d1t1229-7</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1229-8">
   <w.rf>
    <LM>w#w-d1t1229-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1229-9">
   <w.rf>
    <LM>w#w-d1t1229-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1229-11">
   <w.rf>
    <LM>w#w-d1t1229-11</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d1t1229-12">
   <w.rf>
    <LM>w#w-d1t1229-12</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d-id98634">
   <w.rf>
    <LM>w#w-d-id98634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e1207-x3">
  <m id="m943-d1t1234-2">
   <w.rf>
    <LM>w#w-d1t1234-2</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m943-d1t1234-3">
   <w.rf>
    <LM>w#w-d1t1234-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d1t1234-4">
   <w.rf>
    <LM>w#w-d1t1234-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m943-d-id98744">
   <w.rf>
    <LM>w#w-d-id98744</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1234-6">
   <w.rf>
    <LM>w#w-d1t1234-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1234-7">
   <w.rf>
    <LM>w#w-d1t1234-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1234-8">
   <w.rf>
    <LM>w#w-d1t1234-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1234-9">
   <w.rf>
    <LM>w#w-d1t1234-9</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m943-d1t1234-10">
   <w.rf>
    <LM>w#w-d1t1234-10</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m943-d1t1234-11">
   <w.rf>
    <LM>w#w-d1t1234-11</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1234-13">
   <w.rf>
    <LM>w#w-d1t1234-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1234-15">
   <w.rf>
    <LM>w#w-d1t1234-15</LM>
   </w.rf>
   <form>Landwirtschaftu</form>
   <lemma>landwirtschaft</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m943-d-id98908">
   <w.rf>
    <LM>w#w-d-id98908</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e1207-x3-1185">
   <w.rf>
    <LM>w#w-d1e1207-x3-1185</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1234-18">
   <w.rf>
    <LM>w#w-d1t1234-18</LM>
   </w.rf>
   <form>zemědělství</form>
   <lemma>zemědělství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m943-d1e1207-x3-1183">
   <w.rf>
    <LM>w#w-d1e1207-x3-1183</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1236-1">
   <w.rf>
    <LM>w#w-d1t1236-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1236-2">
   <w.rf>
    <LM>w#w-d1t1236-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1236-3">
   <w.rf>
    <LM>w#w-d1t1236-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1236-4">
   <w.rf>
    <LM>w#w-d1t1236-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m943-d1t1236-6">
   <w.rf>
    <LM>w#w-d1t1236-6</LM>
   </w.rf>
   <form>okrašlovacím</form>
   <lemma>okrašlovací_^(*2t)</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m943-d1t1236-7">
   <w.rf>
    <LM>w#w-d1t1236-7</LM>
   </w.rf>
   <form>pracím</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m943-d1t1236-8">
   <w.rf>
    <LM>w#w-d1t1236-8</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1236-9">
   <w.rf>
    <LM>w#w-d1t1236-9</LM>
   </w.rf>
   <form>nedostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m943-d1e1207-x3-1209">
   <w.rf>
    <LM>w#w-d1e1207-x3-1209</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1210">
  <m id="m943-d1t1240-3">
   <w.rf>
    <LM>w#w-d1t1240-3</LM>
   </w.rf>
   <form>Náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m943-d1t1240-4">
   <w.rf>
    <LM>w#w-d1t1240-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1244-1">
   <w.rf>
    <LM>w#w-d1t1244-1</LM>
   </w.rf>
   <form>zabedněné</form>
   <lemma>zabedněný_^(*3it)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m943-d1e1207-x3-1923">
   <w.rf>
    <LM>w#w-d1e1207-x3-1923</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1906">
  <m id="m943-d1t1244-5">
   <w.rf>
    <LM>w#w-d1t1244-5</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m943-d1e1207-x4-1418">
   <w.rf>
    <LM>w#w-d1e1207-x4-1418</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1244-6">
   <w.rf>
    <LM>w#w-d1t1244-6</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m943-d1t1244-7">
   <w.rf>
    <LM>w#w-d1t1244-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1244-8">
   <w.rf>
    <LM>w#w-d1t1244-8</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1244-9">
   <w.rf>
    <LM>w#w-d1t1244-9</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m943-d1t1244-11">
   <w.rf>
    <LM>w#w-d1t1244-11</LM>
   </w.rf>
   <form>okrašlování</form>
   <lemma>okrašlování_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m943-d1e1207-x4-1419">
   <w.rf>
    <LM>w#w-d1e1207-x4-1419</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-1906-1980">
   <w.rf>
    <LM>w#w-1906-1980</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1247-3">
   <w.rf>
    <LM>w#w-d1t1247-3</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m943-d1t1247-4">
   <w.rf>
    <LM>w#w-d1t1247-4</LM>
   </w.rf>
   <form>hradba</form>
   <lemma>hradba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-1906-1213">
   <w.rf>
    <LM>w#w-1906-1213</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1214">
  <m id="m943-d1t1249-3">
   <w.rf>
    <LM>w#w-d1t1249-3</LM>
   </w.rf>
   <form>Uvnitř</form>
   <lemma>uvnitř-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1249-2">
   <w.rf>
    <LM>w#w-d1t1249-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1249-4">
   <w.rf>
    <LM>w#w-d1t1249-4</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-d1t1249-6">
   <w.rf>
    <LM>w#w-d1t1249-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1249-7">
   <w.rf>
    <LM>w#w-d1t1249-7</LM>
   </w.rf>
   <form>zkrášlování</form>
   <lemma>zkrášlování_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m943-d1e1207-x4-1420">
   <w.rf>
    <LM>w#w-d1e1207-x4-1420</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1253-3">
   <w.rf>
    <LM>w#w-d1t1253-3</LM>
   </w.rf>
   <form>zařizovala</form>
   <lemma>zařizovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1e1207-x4-1422">
   <w.rf>
    <LM>w#w-d1e1207-x4-1422</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1253-5">
   <w.rf>
    <LM>w#w-d1t1253-5</LM>
   </w.rf>
   <form>kavárna</form>
   <lemma>kavárna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d1e1207-x4-1423">
   <w.rf>
    <LM>w#w-d1e1207-x4-1423</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1424">
  <m id="m943-d1t1255-1">
   <w.rf>
    <LM>w#w-d1t1255-1</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1255-3">
   <w.rf>
    <LM>w#w-d1t1255-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1257-1">
   <w.rf>
    <LM>w#w-d1t1257-1</LM>
   </w.rf>
   <form>vydal</form>
   <lemma>vydat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m943-d1t1257-2">
   <w.rf>
    <LM>w#w-d1t1257-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m943-d1t1257-4">
   <w.rf>
    <LM>w#w-d1t1257-4</LM>
   </w.rf>
   <form>ghetttogeld</form>
   <lemma>ghetttogeld-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m943-1424-2141">
   <w.rf>
    <LM>w#w-1424-2141</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1257-5">
   <w.rf>
    <LM>w#w-d1t1257-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m943-d1t1257-6">
   <w.rf>
    <LM>w#w-d1t1257-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1257-8">
   <w.rf>
    <LM>w#w-d1t1257-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1257-9">
   <w.rf>
    <LM>w#w-d1t1257-9</LM>
   </w.rf>
   <form>dostaly</form>
   <lemma>dostat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m943-1424-1217">
   <w.rf>
    <LM>w#w-1424-1217</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1218">
  <m id="m943-d1t1257-13">
   <w.rf>
    <LM>w#w-d1t1257-13</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1257-12">
   <w.rf>
    <LM>w#w-d1t1257-12</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1257-17">
   <w.rf>
    <LM>w#w-d1t1257-17</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1257-14">
   <w.rf>
    <LM>w#w-d1t1257-14</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m943-d1t1257-16">
   <w.rf>
    <LM>w#w-d1t1257-16</LM>
   </w.rf>
   <form>koruny</form>
   <lemma>koruna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m943-1424-2146">
   <w.rf>
    <LM>w#w-1424-2146</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-1424-2147">
   <w.rf>
    <LM>w#w-1424-2147</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m943-d1t1257-19">
   <w.rf>
    <LM>w#w-d1t1257-19</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1257-20">
   <w.rf>
    <LM>w#w-d1t1257-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1t1257-21">
   <w.rf>
    <LM>w#w-d1t1257-21</LM>
   </w.rf>
   <form>přivezla</form>
   <lemma>přivézt</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m943-1424-2150">
   <w.rf>
    <LM>w#w-1424-2150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-2151">
  <m id="m943-d1t1260-6">
   <w.rf>
    <LM>w#w-d1t1260-6</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m943-d1t1260-5">
   <w.rf>
    <LM>w#w-d1t1260-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m943-d1t1260-1">
   <w.rf>
    <LM>w#w-d1t1260-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1260-7">
   <w.rf>
    <LM>w#w-d1t1260-7</LM>
   </w.rf>
   <form>úplná</form>
   <lemma>úplný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m943-d1t1260-8">
   <w.rf>
    <LM>w#w-d1t1260-8</LM>
   </w.rf>
   <form>blbost</form>
   <lemma>blbost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m943-d-id100247">
   <w.rf>
    <LM>w#w-d-id100247</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1260-10">
   <w.rf>
    <LM>w#w-d1t1260-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1260-14">
   <w.rf>
    <LM>w#w-d1t1260-14</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t1260-13">
   <w.rf>
    <LM>w#w-d1t1260-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m943-d1t1260-11">
   <w.rf>
    <LM>w#w-d1t1260-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1260-12">
   <w.rf>
    <LM>w#w-d1t1260-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-d1t1260-15">
   <w.rf>
    <LM>w#w-d1t1260-15</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m943-d1t1260-16">
   <w.rf>
    <LM>w#w-d1t1260-16</LM>
   </w.rf>
   <form>neprodávalo</form>
   <lemma>prodávat_^(*4at)</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m943-2151-2159">
   <w.rf>
    <LM>w#w-2151-2159</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-2160">
  <m id="m943-d1t1260-21">
   <w.rf>
    <LM>w#w-d1t1260-21</LM>
   </w.rf>
   <form>Dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1260-19">
   <w.rf>
    <LM>w#w-d1t1260-19</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1260-20">
   <w.rf>
    <LM>w#w-d1t1260-20</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m943-d1t1260-26">
   <w.rf>
    <LM>w#w-d1t1260-26</LM>
   </w.rf>
   <form>chodily</form>
   <lemma>chodit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1260-23">
   <w.rf>
    <LM>w#w-d1t1260-23</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m943-d1t1260-25">
   <w.rf>
    <LM>w#w-d1t1260-25</LM>
   </w.rf>
   <form>ešusem</form>
   <lemma>ešus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m943-d1t1260-27">
   <w.rf>
    <LM>w#w-d1t1260-27</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1260-29">
   <w.rf>
    <LM>w#w-d1t1260-29</LM>
   </w.rf>
   <form>menáž</form>
   <lemma>menáž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d-id100558">
   <w.rf>
    <LM>w#w-d-id100558</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1260-31">
   <w.rf>
    <LM>w#w-d1t1260-31</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1260-32">
   <w.rf>
    <LM>w#w-d1t1260-32</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m943-d1t1264-2">
   <w.rf>
    <LM>w#w-d1t1264-2</LM>
   </w.rf>
   <form>pleskli</form>
   <lemma>plesknout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m943-d1t1268-2">
   <w.rf>
    <LM>w#w-d1t1268-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-2160-2172">
   <w.rf>
    <LM>w#w-2160-2172</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1268-3">
   <w.rf>
    <LM>w#w-d1t1268-3</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m943-d1t1268-4">
   <w.rf>
    <LM>w#w-d1t1268-4</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1268-5">
   <w.rf>
    <LM>w#w-d1t1268-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m943-2160-2173">
   <w.rf>
    <LM>w#w-2160-2173</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-2174">
  <m id="m943-d1t1273-1">
   <w.rf>
    <LM>w#w-d1t1273-1</LM>
   </w.rf>
   <form>Neměly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m943-d1t1270-3">
   <w.rf>
    <LM>w#w-d1t1270-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1273-2">
   <w.rf>
    <LM>w#w-d1t1273-2</LM>
   </w.rf>
   <form>žádnou</form>
   <lemma>žádný</lemma>
   <tag>PWFS4----------</tag>
  </m>
  <m id="m943-d1t1273-3">
   <w.rf>
    <LM>w#w-d1t1273-3</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m943-d1t1273-4">
   <w.rf>
    <LM>w#w-d1t1273-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1273-5">
   <w.rf>
    <LM>w#w-d1t1273-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m943-2174-2186">
   <w.rf>
    <LM>w#w-2174-2186</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m943-d1t1273-6">
   <w.rf>
    <LM>w#w-d1t1273-6</LM>
   </w.rf>
   <form>kupovat</form>
   <lemma>kupovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m943-d-id100961">
   <w.rf>
    <LM>w#w-d-id100961</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-d1e1207-x5">
  <m id="m943-d1t1290-1">
   <w.rf>
    <LM>w#w-d1t1290-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m943-d1t1290-2">
   <w.rf>
    <LM>w#w-d1t1290-2</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m943-d1t1290-3">
   <w.rf>
    <LM>w#w-d1t1290-3</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m943-d1t1286-10">
   <w.rf>
    <LM>w#w-d1t1286-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1286-11">
   <w.rf>
    <LM>w#w-d1t1286-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m943-d1t1288-1">
   <w.rf>
    <LM>w#w-d1t1288-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m943-d1t1288-2">
   <w.rf>
    <LM>w#w-d1t1288-2</LM>
   </w.rf>
   <form>takoví</form>
   <lemma>takový</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m943-d-id101506">
   <w.rf>
    <LM>w#w-d-id101506</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1290-5">
   <w.rf>
    <LM>w#w-d1t1290-5</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1290-6">
   <w.rf>
    <LM>w#w-d1t1290-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1294-3">
   <w.rf>
    <LM>w#w-d1t1294-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m943-d1t1294-4">
   <w.rf>
    <LM>w#w-d1t1294-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1294-5">
   <w.rf>
    <LM>w#w-d1t1294-5</LM>
   </w.rf>
   <form>dětmi</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m943-d-id101656">
   <w.rf>
    <LM>w#w-d-id101656</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1296-1">
   <w.rf>
    <LM>w#w-d1t1296-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m943-d1t1296-2">
   <w.rf>
    <LM>w#w-d1t1296-2</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1296-3">
   <w.rf>
    <LM>w#w-d1t1296-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1296-4">
   <w.rf>
    <LM>w#w-d1t1296-4</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1296-5">
   <w.rf>
    <LM>w#w-d1t1296-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m943-d1t1296-6">
   <w.rf>
    <LM>w#w-d1t1296-6</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m943-d1t1296-7">
   <w.rf>
    <LM>w#w-d1t1296-7</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m943-d1t1296-8">
   <w.rf>
    <LM>w#w-d1t1296-8</LM>
   </w.rf>
   <form>kritický</form>
   <lemma>kritický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m943-d1t1296-9">
   <w.rf>
    <LM>w#w-d1t1296-9</LM>
   </w.rf>
   <form>názor</form>
   <lemma>názor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m943-d1e1207-x5-1237">
   <w.rf>
    <LM>w#w-d1e1207-x5-1237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m943-27484_03-1238">
  <m id="m943-d1t1299-7">
   <w.rf>
    <LM>w#w-d1t1299-7</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m943-d1t1299-8">
   <w.rf>
    <LM>w#w-d1t1299-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m943-d1t1299-9">
   <w.rf>
    <LM>w#w-d1t1299-9</LM>
   </w.rf>
   <form>dnešní</form>
   <lemma>dnešní</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m943-d1t1299-10">
   <w.rf>
    <LM>w#w-d1t1299-10</LM>
   </w.rf>
   <form>puberťáci</form>
   <lemma>puberťák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m943-d1t1299-13">
   <w.rf>
    <LM>w#w-d1t1299-13</LM>
   </w.rf>
   <form>říkají</form>
   <lemma>říkat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m943-d1e1207-x5-2403">
   <w.rf>
    <LM>w#w-d1e1207-x5-2403</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e1207-x5-2404">
   <w.rf>
    <LM>w#w-d1e1207-x5-2404</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1t1299-14">
   <w.rf>
    <LM>w#w-d1t1299-14</LM>
   </w.rf>
   <form>Všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m943-d1t1299-15">
   <w.rf>
    <LM>w#w-d1t1299-15</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m943-d1t1299-16">
   <w.rf>
    <LM>w#w-d1t1299-16</LM>
   </w.rf>
   <form>blbý</form>
   <lemma>blbý_,h</lemma>
   <tag>AANS1----1A---6</tag>
  </m>
  <m id="m943-d1e1207-x5-2407">
   <w.rf>
    <LM>w#w-d1e1207-x5-2407</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m943-d1e1207-x5-2405">
   <w.rf>
    <LM>w#w-d1e1207-x5-2405</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
