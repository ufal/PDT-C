<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_017.02.w.gz" />
  </references>
 </head>
 <s id="m017-798">
  <m id="m017-d1t516-20">
   <w.rf>
    <LM>w#w-d1t516-20</LM>
   </w.rf>
   <form>Většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t516-19">
   <w.rf>
    <LM>w#w-d1t516-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t516-21">
   <w.rf>
    <LM>w#w-d1t516-21</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1t516-23">
   <w.rf>
    <LM>w#w-d1t516-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m017-d1t516-24">
   <w.rf>
    <LM>w#w-d1t516-24</LM>
   </w.rf>
   <form>synem</form>
   <lemma>syn</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m017-d1t516-25">
   <w.rf>
    <LM>w#w-d1t516-25</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t516-26">
   <w.rf>
    <LM>w#w-d1t516-26</LM>
   </w.rf>
   <form>závody</form>
   <lemma>závod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m017-798-48">
   <w.rf>
    <LM>w#w-798-48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-49">
  <m id="m017-d1t516-31">
   <w.rf>
    <LM>w#w-d1t516-31</LM>
   </w.rf>
   <form>Jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1t516-30">
   <w.rf>
    <LM>w#w-d1t516-30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t516-32">
   <w.rf>
    <LM>w#w-d1t516-32</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t516-33">
   <w.rf>
    <LM>w#w-d1t516-33</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t516-34">
   <w.rf>
    <LM>w#w-d1t516-34</LM>
   </w.rf>
   <form>rámci</form>
   <lemma>rámec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m017-d1t518-1">
   <w.rf>
    <LM>w#w-d1t518-1</LM>
   </w.rf>
   <form>Západočeského</form>
   <lemma>západočeský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m017-d1t518-2">
   <w.rf>
    <LM>w#w-d1t518-2</LM>
   </w.rf>
   <form>kraje</form>
   <lemma>kraj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m017-49-50">
   <w.rf>
    <LM>w#w-49-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-51">
  <m id="m017-d1t518-7">
   <w.rf>
    <LM>w#w-d1t518-7</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-51-72">
   <w.rf>
    <LM>w#w-51-72</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t518-5">
   <w.rf>
    <LM>w#w-d1t518-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t518-6">
   <w.rf>
    <LM>w#w-d1t518-6</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t518-8">
   <w.rf>
    <LM>w#w-d1t518-8</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t518-9">
   <w.rf>
    <LM>w#w-d1t518-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t518-11">
   <w.rf>
    <LM>w#w-d1t518-11</LM>
   </w.rf>
   <form>Moravu</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t518-13">
   <w.rf>
    <LM>w#w-d1t518-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t520-1">
   <w.rf>
    <LM>w#w-d1t520-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t520-3">
   <w.rf>
    <LM>w#w-d1t520-3</LM>
   </w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m017-d1t520-5">
   <w.rf>
    <LM>w#w-d1t520-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t520-6">
   <w.rf>
    <LM>w#w-d1t520-6</LM>
   </w.rf>
   <form>závody</form>
   <lemma>závod</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m017-d-id73600-punct">
   <w.rf>
    <LM>w#w-d-id73600-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t520-9">
   <w.rf>
    <LM>w#w-d1t520-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t520-10">
   <w.rf>
    <LM>w#w-d1t520-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t520-11">
   <w.rf>
    <LM>w#w-d1t520-11</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m017-d1t520-12">
   <w.rf>
    <LM>w#w-d1t520-12</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t520-13">
   <w.rf>
    <LM>w#w-d1t520-13</LM>
   </w.rf>
   <form>doprovod</form>
   <lemma>doprovod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e502-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e502-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e523-x2">
  <m id="m017-d1t528-4">
   <w.rf>
    <LM>w#w-d1t528-4</LM>
   </w.rf>
   <form>Využívali</form>
   <lemma>využívat_^(*3t)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m017-d1t528-2">
   <w.rf>
    <LM>w#w-d1t528-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t528-6">
   <w.rf>
    <LM>w#w-d1t528-6</LM>
   </w.rf>
   <form>ROH</form>
   <lemma>ROH_;m_^(Revoluční_odborové_hnutí)</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m017-d-id73873-punct">
   <w.rf>
    <LM>w#w-d-id73873-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1e523-x2-56">
   <w.rf>
    <LM>w#w-d1e523-x2-56</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t530-3">
   <w.rf>
    <LM>w#w-d1t530-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t530-4">
   <w.rf>
    <LM>w#w-d1t530-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1e523-x2-57">
   <w.rf>
    <LM>w#w-d1e523-x2-57</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t530-5">
   <w.rf>
    <LM>w#w-d1t530-5</LM>
   </w.rf>
   <form>dostali</form>
   <lemma>dostat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m017-d1t530-6">
   <w.rf>
    <LM>w#w-d1t530-6</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t530-7">
   <w.rf>
    <LM>w#w-d1t530-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t530-8">
   <w.rf>
    <LM>w#w-d1t530-8</LM>
   </w.rf>
   <form>jiných</form>
   <lemma>jiný</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m017-d1t530-9">
   <w.rf>
    <LM>w#w-d1t530-9</LM>
   </w.rf>
   <form>hor</form>
   <lemma>hora</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m017-d-m-d1e523-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e523-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e535-x2">
  <m id="m017-d1t538-1">
   <w.rf>
    <LM>w#w-d1t538-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t538-2">
   <w.rf>
    <LM>w#w-d1t538-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t538-3">
   <w.rf>
    <LM>w#w-d1t538-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m017-d1t538-4">
   <w.rf>
    <LM>w#w-d1t538-4</LM>
   </w.rf>
   <form>nejvíce</form>
   <lemma>více</lemma>
   <tag>Dg-------3A----</tag>
  </m>
  <m id="m017-d1t538-5">
   <w.rf>
    <LM>w#w-d1t538-5</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d-id74134-punct">
   <w.rf>
    <LM>w#w-d-id74134-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e540-x2">
  <m id="m017-d1t545-3">
   <w.rf>
    <LM>w#w-d1t545-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t545-4">
   <w.rf>
    <LM>w#w-d1t545-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t545-5">
   <w.rf>
    <LM>w#w-d1t545-5</LM>
   </w.rf>
   <form>otázka</form>
   <lemma>otázka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1e540-x2-67">
   <w.rf>
    <LM>w#w-d1e540-x2-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-70">
  <m id="m017-d1t545-7">
   <w.rf>
    <LM>w#w-d1t545-7</LM>
   </w.rf>
   <form>Nejvíc</form>
   <lemma>více</lemma>
   <tag>Dg-------3A---1</tag>
  </m>
  <m id="m017-d1t545-8">
   <w.rf>
    <LM>w#w-d1t545-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t545-9">
   <w.rf>
    <LM>w#w-d1t545-9</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m017-d1t545-10">
   <w.rf>
    <LM>w#w-d1t545-10</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m017-d1t545-11">
   <w.rf>
    <LM>w#w-d1t545-11</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m017-d1t545-13">
   <w.rf>
    <LM>w#w-d1t545-13</LM>
   </w.rf>
   <form>Francii</form>
   <lemma>Francie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d-id74389-punct">
   <w.rf>
    <LM>w#w-d-id74389-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t547-2">
   <w.rf>
    <LM>w#w-d1t547-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t547-4">
   <w.rf>
    <LM>w#w-d1t547-4</LM>
   </w.rf>
   <form>Alpe</form>
   <lemma>Alpe-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m017-d1e540-x2-918">
   <w.rf>
    <LM>w#w-d1e540-x2-918</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>d</form>
   <lemma>d-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m017-d1e540-x2-918-sw1">
   <w.rf>
    <LM>w#w-d1e540-x2-918</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>´</form>
   <lemma>´</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1e540-x2-918-sw2">
   <w.rf>
    <LM>w#w-d1e540-x2-918</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Huez</form>
   <lemma>Huez-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m017-d-m-d1e540-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e540-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e548-x2">
  <m id="m017-d1t555-1">
   <w.rf>
    <LM>w#w-d1t555-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t555-2">
   <w.rf>
    <LM>w#w-d1t555-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t555-3">
   <w.rf>
    <LM>w#w-d1t555-3</LM>
   </w.rf>
   <form>jmenují</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---3P-AAB--</tag>
  </m>
  <m id="m017-d1t555-4">
   <w.rf>
    <LM>w#w-d1t555-4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHP1-P2-------</tag>
  </m>
  <m id="m017-d1t555-5">
   <w.rf>
    <LM>w#w-d1t555-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m017-d-id74601-punct">
   <w.rf>
    <LM>w#w-d-id74601-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e556-x2">
  <m id="m017-d1t559-2">
   <w.rf>
    <LM>w#w-d1t559-2</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t559-3">
   <w.rf>
    <LM>w#w-d1t559-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t559-4">
   <w.rf>
    <LM>w#w-d1t559-4</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m017-d1t559-6">
   <w.rf>
    <LM>w#w-d1t559-6</LM>
   </w.rf>
   <form>Luboš</form>
   <lemma>Luboš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t559-7">
   <w.rf>
    <LM>w#w-d1t559-7</LM>
   </w.rf>
   <form>Černý</form>
   <lemma>Černý_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t569-1">
   <w.rf>
    <LM>w#w-d1t569-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1e556-x2-76">
   <w.rf>
    <LM>w#w-d1e556-x2-76</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t569-3">
   <w.rf>
    <LM>w#w-d1t569-3</LM>
   </w.rf>
   <form>Jana</form>
   <lemma>Jana_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t569-4">
   <w.rf>
    <LM>w#w-d1t569-4</LM>
   </w.rf>
   <form>Černá</form>
   <lemma>Černá_;G_;Y_^(*1ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e556-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e556-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e570-x2">
  <m id="m017-d1t573-1">
   <w.rf>
    <LM>w#w-d1t573-1</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t573-2">
   <w.rf>
    <LM>w#w-d1t573-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t573-3">
   <w.rf>
    <LM>w#w-d1t573-3</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m017-d-id75044-punct">
   <w.rf>
    <LM>w#w-d-id75044-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e574-x2">
  <m id="m017-d1t577-1">
   <w.rf>
    <LM>w#w-d1t577-1</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d1t577-2">
   <w.rf>
    <LM>w#w-d1t577-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t577-3">
   <w.rf>
    <LM>w#w-d1t577-3</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m017-d1e574-x2-79">
   <w.rf>
    <LM>w#w-d1e574-x2-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-80">
  <m id="m017-d1t579-1">
   <w.rf>
    <LM>w#w-d1t579-1</LM>
   </w.rf>
   <form>Letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t577-5">
   <w.rf>
    <LM>w#w-d1t577-5</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m017-d1t577-6">
   <w.rf>
    <LM>w#w-d1t577-6</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m017-d1t579-2">
   <w.rf>
    <LM>w#w-d1t579-2</LM>
   </w.rf>
   <form>padesát</form>
   <lemma>padesát`50</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m017-d-m-d1e574-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e574-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e580-x2">
  <m id="m017-d1t587-1">
   <w.rf>
    <LM>w#w-d1t587-1</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t587-2">
   <w.rf>
    <LM>w#w-d1t587-2</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t587-3">
   <w.rf>
    <LM>w#w-d1t587-3</LM>
   </w.rf>
   <form>závodně</form>
   <lemma>závodně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d-id75349-punct">
   <w.rf>
    <LM>w#w-d-id75349-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e588-x2">
  <m id="m017-d1t591-1">
   <w.rf>
    <LM>w#w-d1t591-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d-id75426-punct">
   <w.rf>
    <LM>w#w-d-id75426-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t591-3">
   <w.rf>
    <LM>w#w-d1t591-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t591-5">
   <w.rf>
    <LM>w#w-d1t591-5</LM>
   </w.rf>
   <form>nejezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d1t591-6">
   <w.rf>
    <LM>w#w-d1t591-6</LM>
   </w.rf>
   <form>závodně</form>
   <lemma>závodně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1e588-x2-83">
   <w.rf>
    <LM>w#w-d1e588-x2-83</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-84">
  <m id="m017-d1t599-1">
   <w.rf>
    <LM>w#w-d1t599-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t599-2">
   <w.rf>
    <LM>w#w-d1t599-2</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t599-3">
   <w.rf>
    <LM>w#w-d1t599-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t599-4">
   <w.rf>
    <LM>w#w-d1t599-4</LM>
   </w.rf>
   <form>rekreačně</form>
   <lemma>rekreačně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d-m-d1e594-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e594-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-958">
  <m id="m017-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t607-5">
   <w.rf>
    <LM>w#w-d1t607-5</LM>
   </w.rf>
   <form>těchto</form>
   <lemma>tento</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m017-d1t607-6">
   <w.rf>
    <LM>w#w-d1t607-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m017-d1t607-7">
   <w.rf>
    <LM>w#w-d1t607-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t607-8">
   <w.rf>
    <LM>w#w-d1t607-8</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1t607-9">
   <w.rf>
    <LM>w#w-d1t607-9</LM>
   </w.rf>
   <form>závodně</form>
   <lemma>závodně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t607-10">
   <w.rf>
    <LM>w#w-d1t607-10</LM>
   </w.rf>
   <form>celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t609-1">
   <w.rf>
    <LM>w#w-d1t609-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t609-2">
   <w.rf>
    <LM>w#w-d1t609-2</LM>
   </w.rf>
   <form>nejde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d-id75877-punct">
   <w.rf>
    <LM>w#w-d-id75877-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t609-4">
   <w.rf>
    <LM>w#w-d1t609-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t609-5">
   <w.rf>
    <LM>w#w-d1t609-5</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t609-6">
   <w.rf>
    <LM>w#w-d1t609-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t620-1">
   <w.rf>
    <LM>w#w-d1t620-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-958-962">
   <w.rf>
    <LM>w#w-958-962</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t626-1">
   <w.rf>
    <LM>w#w-d1t626-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t626-2">
   <w.rf>
    <LM>w#w-d1t626-2</LM>
   </w.rf>
   <form>nechá</form>
   <lemma>nechat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m017-d1t626-3">
   <w.rf>
    <LM>w#w-d1t626-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m017-958-964">
   <w.rf>
    <LM>w#w-958-964</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t626-4">
   <w.rf>
    <LM>w#w-d1t626-4</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m017-d1t626-5">
   <w.rf>
    <LM>w#w-d1t626-5</LM>
   </w.rf>
   <form>pán</form>
   <lemma>pán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d-m-d1e621-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e621-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e627-x2">
  <m id="m017-d1t630-1">
   <w.rf>
    <LM>w#w-d1t630-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m017-d1t630-2">
   <w.rf>
    <LM>w#w-d1t630-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t630-3">
   <w.rf>
    <LM>w#w-d1t630-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t630-4">
   <w.rf>
    <LM>w#w-d1t630-4</LM>
   </w.rf>
   <form>závodil</form>
   <lemma>závodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d-id76301-punct">
   <w.rf>
    <LM>w#w-d-id76301-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e633-x2">
  <m id="m017-d1t636-1">
   <w.rf>
    <LM>w#w-d1t636-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1e633-x2-978">
   <w.rf>
    <LM>w#w-d1e633-x2-978</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>nezávodil</form>
   <lemma>závodit</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m017-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1e633-x2-980">
   <w.rf>
    <LM>w#w-d1e633-x2-980</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-982">
  <m id="m017-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>Dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t636-7">
   <w.rf>
    <LM>w#w-d1t636-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t636-9">
   <w.rf>
    <LM>w#w-d1t636-9</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t636-10">
   <w.rf>
    <LM>w#w-d1t636-10</LM>
   </w.rf>
   <form>doprovod</form>
   <lemma>doprovod</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d1t636-11">
   <w.rf>
    <LM>w#w-d1t636-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t636-13">
   <w.rf>
    <LM>w#w-d1t636-13</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m017-d1t636-14">
   <w.rf>
    <LM>w#w-d1t636-14</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m017-982-99">
   <w.rf>
    <LM>w#w-982-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-100">
  <m id="m017-d1t636-16">
   <w.rf>
    <LM>w#w-d1t636-16</LM>
   </w.rf>
   <form>Lyžovat</form>
   <lemma>lyžovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1t636-17">
   <w.rf>
    <LM>w#w-d1t636-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t636-18">
   <w.rf>
    <LM>w#w-d1t636-18</LM>
   </w.rf>
   <form>lyžoval</form>
   <lemma>lyžovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d-id76618-punct">
   <w.rf>
    <LM>w#w-d-id76618-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t636-20">
   <w.rf>
    <LM>w#w-d1t636-20</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t638-1">
   <w.rf>
    <LM>w#w-d1t638-1</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t638-2">
   <w.rf>
    <LM>w#w-d1t638-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t638-6">
   <w.rf>
    <LM>w#w-d1t638-6</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t638-8">
   <w.rf>
    <LM>w#w-d1t638-8</LM>
   </w.rf>
   <form>lyžování</form>
   <lemma>lyžování_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m017-d1t638-4">
   <w.rf>
    <LM>w#w-d1t638-4</LM>
   </w.rf>
   <form>pomocné</form>
   <lemma>pomocný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m017-d1t638-10">
   <w.rf>
    <LM>w#w-d1t638-10</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m017-d-m-d1e633-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e633-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e639-x2">
  <m id="m017-d1t646-1">
   <w.rf>
    <LM>w#w-d1t646-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1e639-x2-986">
   <w.rf>
    <LM>w#w-d1e639-x2-986</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-988">
  <m id="m017-d1t650-1">
   <w.rf>
    <LM>w#w-d1t650-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m017-d1t650-2">
   <w.rf>
    <LM>w#w-d1t650-2</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t650-3">
   <w.rf>
    <LM>w#w-d1t650-3</LM>
   </w.rf>
   <form>dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t650-4">
   <w.rf>
    <LM>w#w-d1t650-4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m017-d1t650-5">
   <w.rf>
    <LM>w#w-d1t650-5</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d-id76987-punct">
   <w.rf>
    <LM>w#w-d-id76987-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e651-x2">
  <m id="m017-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>Dělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t656-1">
   <w.rf>
    <LM>w#w-d1t656-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t656-2">
   <w.rf>
    <LM>w#w-d1t656-2</LM>
   </w.rf>
   <form>družině</form>
   <lemma>družina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m017-d1t656-4">
   <w.rf>
    <LM>w#w-d1t656-4</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d-m-d1e651-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e651-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e657-x2">
  <m id="m017-d1t666-1">
   <w.rf>
    <LM>w#w-d1t666-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id77278-punct">
   <w.rf>
    <LM>w#w-d-id77278-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e667-x2">
  <m id="m017-d1t670-1">
   <w.rf>
    <LM>w#w-d1t670-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t670-3">
   <w.rf>
    <LM>w#w-d1t670-3</LM>
   </w.rf>
   <form>Blovicích</form>
   <lemma>Blovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m017-d-m-d1e667-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e667-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e671-x2">
  <m id="m017-d1t674-1">
   <w.rf>
    <LM>w#w-d1t674-1</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t674-2">
   <w.rf>
    <LM>w#w-d1t674-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m017-d1t674-3">
   <w.rf>
    <LM>w#w-d1t674-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t674-4">
   <w.rf>
    <LM>w#w-d1t674-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m017-d1t674-5">
   <w.rf>
    <LM>w#w-d1t674-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m017-d1t674-6">
   <w.rf>
    <LM>w#w-d1t674-6</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m017-d1t674-7">
   <w.rf>
    <LM>w#w-d1t674-7</LM>
   </w.rf>
   <form>řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m017-d-id77543-punct">
   <w.rf>
    <LM>w#w-d-id77543-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e675-x2">
  <m id="m017-d1t678-3">
   <w.rf>
    <LM>w#w-d1t678-3</LM>
   </w.rf>
   <form>Celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t680-1">
   <w.rf>
    <LM>w#w-d1t680-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t680-2">
   <w.rf>
    <LM>w#w-d1t680-2</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m017-d1e675-x2-110">
   <w.rf>
    <LM>w#w-d1e675-x2-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-111">
  <m id="m017-d1t680-6">
   <w.rf>
    <LM>w#w-d1t680-6</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t680-5">
   <w.rf>
    <LM>w#w-d1t680-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t680-9">
   <w.rf>
    <LM>w#w-d1t680-9</LM>
   </w.rf>
   <form>úzká</form>
   <lemma>úzký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t680-10">
   <w.rf>
    <LM>w#w-d1t680-10</LM>
   </w.rf>
   <form>výseč</form>
   <lemma>výseč</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1e675-x2-1030">
   <w.rf>
    <LM>w#w-d1e675-x2-1030</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1032">
  <m id="m017-d1t680-13">
   <w.rf>
    <LM>w#w-d1t680-13</LM>
   </w.rf>
   <form>Akorát</form>
   <lemma>akorát-2_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t680-14">
   <w.rf>
    <LM>w#w-d1t680-14</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m017-d1t680-15">
   <w.rf>
    <LM>w#w-d1t680-15</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t680-16">
   <w.rf>
    <LM>w#w-d1t680-16</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m017-d1t680-18">
   <w.rf>
    <LM>w#w-d1t680-18</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d-id77920-punct">
   <w.rf>
    <LM>w#w-d-id77920-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t682-1">
   <w.rf>
    <LM>w#w-d1t682-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t682-2">
   <w.rf>
    <LM>w#w-d1t682-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t682-3">
   <w.rf>
    <LM>w#w-d1t682-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t682-5">
   <w.rf>
    <LM>w#w-d1t682-5</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t682-4">
   <w.rf>
    <LM>w#w-d1t682-4</LM>
   </w.rf>
   <form>podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m017-d1t682-6">
   <w.rf>
    <LM>w#w-d1t682-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t682-8">
   <w.rf>
    <LM>w#w-d1t682-8</LM>
   </w.rf>
   <form>výzbroj</form>
   <lemma>výzbroj-1</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t684-2">
   <w.rf>
    <LM>w#w-d1t684-2</LM>
   </w.rf>
   <form>lyžařů</form>
   <lemma>lyžař</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m017-d1e675-x2-1028">
   <w.rf>
    <LM>w#w-d1e675-x2-1028</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-120-121">
   <w.rf>
    <LM>w#w-120-121</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t684-7">
   <w.rf>
    <LM>w#w-d1t684-7</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m017-d1t684-10">
   <w.rf>
    <LM>w#w-d1t684-10</LM>
   </w.rf>
   <form>starou</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m017-d1t684-11">
   <w.rf>
    <LM>w#w-d1t684-11</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-1032-122">
   <w.rf>
    <LM>w#w-1032-122</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t686-4">
   <w.rf>
    <LM>w#w-d1t686-4</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m017-d1t686-2">
   <w.rf>
    <LM>w#w-d1t686-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t686-3">
   <w.rf>
    <LM>w#w-d1t686-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t686-5">
   <w.rf>
    <LM>w#w-d1t686-5</LM>
   </w.rf>
   <form>srovnat</form>
   <lemma>srovnat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m017-1032-118">
   <w.rf>
    <LM>w#w-1032-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e687-x2">
  <m id="m017-d1t696-1">
   <w.rf>
    <LM>w#w-d1t696-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1e687-x2-124">
   <w.rf>
    <LM>w#w-d1e687-x2-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-125">
  <m id="m017-d1t696-4">
   <w.rf>
    <LM>w#w-d1t696-4</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m017-d1t696-5">
   <w.rf>
    <LM>w#w-d1t696-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t696-6">
   <w.rf>
    <LM>w#w-d1t696-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m017-d1t696-7">
   <w.rf>
    <LM>w#w-d1t696-7</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-m-d1e687-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e687-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e698-x2">
  <m id="m017-d1t703-1">
   <w.rf>
    <LM>w#w-d1t703-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m017-d1t703-2">
   <w.rf>
    <LM>w#w-d1t703-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t703-3">
   <w.rf>
    <LM>w#w-d1t703-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m017-d1t703-4">
   <w.rf>
    <LM>w#w-d1t703-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d-id78590-punct">
   <w.rf>
    <LM>w#w-d-id78590-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e710-x2">
  <m id="m017-d1t715-10">
   <w.rf>
    <LM>w#w-d1t715-10</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t715-4">
   <w.rf>
    <LM>w#w-d1t715-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t715-7">
   <w.rf>
    <LM>w#w-d1t715-7</LM>
   </w.rf>
   <form>věku</form>
   <lemma>věk</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m017-d1t715-8">
   <w.rf>
    <LM>w#w-d1t715-8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t715-9">
   <w.rf>
    <LM>w#w-d1t715-9</LM>
   </w.rf>
   <form>vojně</form>
   <lemma>vojna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d1t715-13">
   <w.rf>
    <LM>w#w-d1t715-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t715-14">
   <w.rf>
    <LM>w#w-d1t715-14</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t715-15">
   <w.rf>
    <LM>w#w-d1t715-15</LM>
   </w.rf>
   <form>rybařit</form>
   <lemma>rybařit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1e710-x2-132">
   <w.rf>
    <LM>w#w-d1e710-x2-132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-135">
  <m id="m017-d1t717-2">
   <w.rf>
    <LM>w#w-d1t717-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1e710-x2-1060">
   <w.rf>
    <LM>w#w-d1e710-x2-1060</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t715-17">
   <w.rf>
    <LM>w#w-d1t715-17</LM>
   </w.rf>
   <form>sice</form>
   <lemma>sice-1_^(spojka;_připouští_se_určitá_fakta)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t715-19">
   <w.rf>
    <LM>w#w-d1t715-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t715-20">
   <w.rf>
    <LM>w#w-d1t715-20</LM>
   </w.rf>
   <form>krátkou</form>
   <lemma>krátký</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m017-d1t717-1">
   <w.rf>
    <LM>w#w-d1t717-1</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d1t717-3">
   <w.rf>
    <LM>w#w-d1t717-3</LM>
   </w.rf>
   <form>přestal</form>
   <lemma>přestat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1e710-x2-129">
   <w.rf>
    <LM>w#w-d1e710-x2-129</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1100">
  <m id="m017-d1t721-1">
   <w.rf>
    <LM>w#w-d1t721-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m017-d1t721-2">
   <w.rf>
    <LM>w#w-d1t721-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t721-3">
   <w.rf>
    <LM>w#w-d1t721-3</LM>
   </w.rf>
   <form>chytil</form>
   <lemma>chytit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t721-4">
   <w.rf>
    <LM>w#w-d1t721-4</LM>
   </w.rf>
   <form>štiku</form>
   <lemma>štika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-id79106-punct">
   <w.rf>
    <LM>w#w-d-id79106-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t721-7">
   <w.rf>
    <LM>w#w-d1t721-7</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m017-d1t721-8">
   <w.rf>
    <LM>w#w-d1t721-8</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>6.20</form>
   <lemma>6.20</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m017-d1t721-9">
   <w.rf>
    <LM>w#w-d1t721-9</LM>
   </w.rf>
   <form>kg</form>
   <lemma>kilogram</lemma>
   <tag>NNIXX-----A---b</tag>
  </m>
  <m id="m017-1100-144">
   <w.rf>
    <LM>w#w-1100-144</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-145">
  <m id="m017-d1t724-2">
   <w.rf>
    <LM>w#w-d1t724-2</LM>
   </w.rf>
   <form>Barák</form>
   <lemma>barák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d1t721-13">
   <w.rf>
    <LM>w#w-d1t721-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t721-14">
   <w.rf>
    <LM>w#w-d1t721-14</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t724-3">
   <w.rf>
    <LM>w#w-d1t724-3</LM>
   </w.rf>
   <form>nedodělaný</form>
   <lemma>dodělaný_^(*2t)</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m017-145-146">
   <w.rf>
    <LM>w#w-145-146</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-147">
  <m id="m017-d1t724-5">
   <w.rf>
    <LM>w#w-d1t724-5</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t724-6">
   <w.rf>
    <LM>w#w-d1t724-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t724-8">
   <w.rf>
    <LM>w#w-d1t724-8</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d-id79376-punct">
   <w.rf>
    <LM>w#w-d-id79376-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t724-11">
   <w.rf>
    <LM>w#w-d1t724-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t724-16">
   <w.rf>
    <LM>w#w-d1t724-16</LM>
   </w.rf>
   <form>hradba</form>
   <lemma>hradba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t724-12">
   <w.rf>
    <LM>w#w-d1t724-12</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m017-d1t724-18">
   <w.rf>
    <LM>w#w-d1t724-18</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t726-1">
   <w.rf>
    <LM>w#w-d1t726-1</LM>
   </w.rf>
   <form>kůly</form>
   <lemma>kůl</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m017-d1t726-6">
   <w.rf>
    <LM>w#w-d1t726-6</LM>
   </w.rf>
   <form>ohražené</form>
   <lemma>ohražený</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m017-d1t726-7">
   <w.rf>
    <LM>w#w-d1t726-7</LM>
   </w.rf>
   <form>pletivem</form>
   <lemma>pletivo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m017-d1e710-x2-1070">
   <w.rf>
    <LM>w#w-d1e710-x2-1070</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e735-x2">
  <m id="m017-d1t738-5">
   <w.rf>
    <LM>w#w-d1t738-5</LM>
   </w.rf>
   <form>Věnoval</form>
   <lemma>věnovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t738-1">
   <w.rf>
    <LM>w#w-d1t738-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t738-2">
   <w.rf>
    <LM>w#w-d1t738-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t738-3">
   <w.rf>
    <LM>w#w-d1t738-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m017-d-id79818-punct">
   <w.rf>
    <LM>w#w-d-id79818-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t740-1">
   <w.rf>
    <LM>w#w-d1t740-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t740-2">
   <w.rf>
    <LM>w#w-d1t740-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t740-3">
   <w.rf>
    <LM>w#w-d1t740-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m017-d1t740-4">
   <w.rf>
    <LM>w#w-d1t740-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m017-d1t740-5">
   <w.rf>
    <LM>w#w-d1t740-5</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d1t740-6">
   <w.rf>
    <LM>w#w-d1t740-6</LM>
   </w.rf>
   <form>přestal</form>
   <lemma>přestat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t740-7">
   <w.rf>
    <LM>w#w-d1t740-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m017-d1t740-8">
   <w.rf>
    <LM>w#w-d1t740-8</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1e735-x2-1104">
   <w.rf>
    <LM>w#w-d1e735-x2-1104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t740-9">
   <w.rf>
    <LM>w#w-d1t740-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t740-10">
   <w.rf>
    <LM>w#w-d1t740-10</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t742-1">
   <w.rf>
    <LM>w#w-d1t742-1</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t742-2">
   <w.rf>
    <LM>w#w-d1t742-2</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t742-3">
   <w.rf>
    <LM>w#w-d1t742-3</LM>
   </w.rf>
   <form>deseti</form>
   <lemma>deset`10</lemma>
   <tag>Cl-P7----------</tag>
  </m>
  <m id="m017-d1t742-4">
   <w.rf>
    <LM>w#w-d1t742-4</LM>
   </w.rf>
   <form>lety</form>
   <lemma>léta</lemma>
   <tag>NNNP7-----A----</tag>
  </m>
  <m id="m017-d1t742-6">
   <w.rf>
    <LM>w#w-d1t742-6</LM>
   </w.rf>
   <form>rybařit</form>
   <lemma>rybařit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m017-d1t742-7">
   <w.rf>
    <LM>w#w-d1t742-7</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m017-d-id80084-punct">
   <w.rf>
    <LM>w#w-d-id80084-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t742-11">
   <w.rf>
    <LM>w#w-d1t742-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m017-d1t742-12">
   <w.rf>
    <LM>w#w-d1t742-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t742-13">
   <w.rf>
    <LM>w#w-d1t742-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m017-d1t742-14">
   <w.rf>
    <LM>w#w-d1t742-14</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m017-d1t742-15">
   <w.rf>
    <LM>w#w-d1t742-15</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t742-16">
   <w.rf>
    <LM>w#w-d1t742-16</LM>
   </w.rf>
   <form>znova</form>
   <lemma>znova</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t742-17">
   <w.rf>
    <LM>w#w-d1t742-17</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d-m-d1e735-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e735-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e743-x2">
  <m id="m017-d1t746-1">
   <w.rf>
    <LM>w#w-d1t746-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t746-2">
   <w.rf>
    <LM>w#w-d1t746-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t746-3">
   <w.rf>
    <LM>w#w-d1t746-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t746-4">
   <w.rf>
    <LM>w#w-d1t746-4</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m017-d1t746-5">
   <w.rf>
    <LM>w#w-d1t746-5</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d1e743-x2-1108">
   <w.rf>
    <LM>w#w-d1e743-x2-1108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e743-x3">
  <m id="m017-d1t748-1">
   <w.rf>
    <LM>w#w-d1t748-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t748-2">
   <w.rf>
    <LM>w#w-d1t748-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t748-3">
   <w.rf>
    <LM>w#w-d1t748-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t748-4">
   <w.rf>
    <LM>w#w-d1t748-4</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m017-d-id80434-punct">
   <w.rf>
    <LM>w#w-d-id80434-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e749-x3">
  <m id="m017-d1t754-1">
   <w.rf>
    <LM>w#w-d1t754-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m017-d1t754-3">
   <w.rf>
    <LM>w#w-d1t754-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t754-4">
   <w.rf>
    <LM>w#w-d1t754-4</LM>
   </w.rf>
   <form>těžko</form>
   <lemma>těžko_^(souvisící_s_váhou;_i_zdr._stav)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m017-d1t754-5">
   <w.rf>
    <LM>w#w-d1t754-5</LM>
   </w.rf>
   <form>řeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m017-d1e749-x3-162">
   <w.rf>
    <LM>w#w-d1e749-x3-162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-163">
  <m id="m017-d1t756-2">
   <w.rf>
    <LM>w#w-d1t756-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t756-3">
   <w.rf>
    <LM>w#w-d1t756-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t756-1">
   <w.rf>
    <LM>w#w-d1t756-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t756-4">
   <w.rf>
    <LM>w#w-d1t756-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t756-8">
   <w.rf>
    <LM>w#w-d1t756-8</LM>
   </w.rf>
   <form>40</form>
   <lemma>40</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m017-d1t756-9">
   <w.rf>
    <LM>w#w-d1t756-9</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m017-d-m-d1e749-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e749-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e757-x2">
  <m id="m017-d1t764-1">
   <w.rf>
    <LM>w#w-d1t764-1</LM>
   </w.rf>
   <form>Nevadí</form>
   <lemma>vadit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m017-d1e757-x2-1132">
   <w.rf>
    <LM>w#w-d1e757-x2-1132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-1134">
  <m id="m017-d1t768-1">
   <w.rf>
    <LM>w#w-d1t768-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m017-d1t768-2">
   <w.rf>
    <LM>w#w-d1t768-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t768-3">
   <w.rf>
    <LM>w#w-d1t768-3</LM>
   </w.rf>
   <form>ulovil</form>
   <lemma>ulovit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m017-d1t768-4">
   <w.rf>
    <LM>w#w-d1t768-4</LM>
   </w.rf>
   <form>tuhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m017-d1t768-5">
   <w.rf>
    <LM>w#w-d1t768-5</LM>
   </w.rf>
   <form>rybu</form>
   <lemma>ryba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m017-d-id80948-punct">
   <w.rf>
    <LM>w#w-d-id80948-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e769-x2">
  <m id="m017-d1t772-4">
   <w.rf>
    <LM>w#w-d1t772-4</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t772-5">
   <w.rf>
    <LM>w#w-d1t772-5</LM>
   </w.rf>
   <form>ulovená</form>
   <lemma>ulovený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m017-d1t772-6">
   <w.rf>
    <LM>w#w-d1t772-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m017-d1t772-7">
   <w.rf>
    <LM>w#w-d1t772-7</LM>
   </w.rf>
   <form>Úslavě</form>
   <lemma>Úslava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m017-d1t776-1">
   <w.rf>
    <LM>w#w-d1t776-1</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m017-d1t776-2">
   <w.rf>
    <LM>w#w-d1t776-2</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS7-P1-------</tag>
  </m>
  <m id="m017-d1t776-3">
   <w.rf>
    <LM>w#w-d1t776-3</LM>
   </w.rf>
   <form>parcelou</form>
   <lemma>parcela</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m017-d1e769-x2-169">
   <w.rf>
    <LM>w#w-d1e769-x2-169</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-170">
  <m id="m017-d1t778-6">
   <w.rf>
    <LM>w#w-d1t778-6</LM>
   </w.rf>
   <form>Zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m017-d1t778-7">
   <w.rf>
    <LM>w#w-d1t778-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m017-d1t778-4">
   <w.rf>
    <LM>w#w-d1t778-4</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t778-8">
   <w.rf>
    <LM>w#w-d1t778-8</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t778-9">
   <w.rf>
    <LM>w#w-d1t778-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m017-d1t778-10">
   <w.rf>
    <LM>w#w-d1t778-10</LM>
   </w.rf>
   <form>řece</form>
   <lemma>řeka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m017-170-171">
   <w.rf>
    <LM>w#w-170-171</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e779-x2">
  <m id="m017-d1t782-1">
   <w.rf>
    <LM>w#w-d1t782-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m017-d1t782-2">
   <w.rf>
    <LM>w#w-d1t782-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m017-d1t782-3">
   <w.rf>
    <LM>w#w-d1t782-3</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m017-d1t782-4">
   <w.rf>
    <LM>w#w-d1t782-4</LM>
   </w.rf>
   <form>nejlepší</form>
   <lemma>lepší</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m017-d1t782-5">
   <w.rf>
    <LM>w#w-d1t782-5</LM>
   </w.rf>
   <form>úlovek</form>
   <lemma>úlovek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m017-d-id81584-punct">
   <w.rf>
    <LM>w#w-d-id81584-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e783-x2">
  <m id="m017-d1t786-2">
   <w.rf>
    <LM>w#w-d1t786-2</LM>
   </w.rf>
   <form>Nechá</form>
   <lemma>nechat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m017-d1t786-3">
   <w.rf>
    <LM>w#w-d1t786-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m017-d1t786-4">
   <w.rf>
    <LM>w#w-d1t786-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m017-d-id81708-punct">
   <w.rf>
    <LM>w#w-d-id81708-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m017-d1t786-6">
   <w.rf>
    <LM>w#w-d1t786-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m017-d1t786-7">
   <w.rf>
    <LM>w#w-d1t786-7</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d-m-d1e783-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e783-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e787-x2">
  <m id="m017-d1t790-1">
   <w.rf>
    <LM>w#w-d1t790-1</LM>
   </w.rf>
   <form>Pamatujete</form>
   <lemma>pamatovat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m017-d1t790-2">
   <w.rf>
    <LM>w#w-d1t790-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m017-d1t792-1">
   <w.rf>
    <LM>w#w-d1t792-1</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m017-d1t792-2">
   <w.rf>
    <LM>w#w-d1t792-2</LM>
   </w.rf>
   <form>jiný</form>
   <lemma>jiný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m017-d1t792-3">
   <w.rf>
    <LM>w#w-d1t792-3</LM>
   </w.rf>
   <form>kapitální</form>
   <lemma>kapitální</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m017-d1t792-4">
   <w.rf>
    <LM>w#w-d1t792-4</LM>
   </w.rf>
   <form>úlovek</form>
   <lemma>úlovek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m017-d-id81902-punct">
   <w.rf>
    <LM>w#w-d-id81902-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m017-d1e794-x2">
  <m id="m017-d1t797-3">
   <w.rf>
    <LM>w#w-d1t797-3</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1t797-4">
   <w.rf>
    <LM>w#w-d1t797-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m017-d1e794-x2-181">
   <w.rf>
    <LM>w#w-d1e794-x2-181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
