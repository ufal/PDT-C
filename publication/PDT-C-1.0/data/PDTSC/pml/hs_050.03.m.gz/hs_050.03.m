<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hs_050.03.w.gz" />
  </references>
 </head>
 <s id="m050-d1e825-x2">
  <m id="m050-d1t832-4">
   <w.rf>
    <LM>w#w-d1t832-4</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t832-3">
   <w.rf>
    <LM>w#w-d1t832-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t832-5">
   <w.rf>
    <LM>w#w-d1t832-5</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m050-d1t832-6">
   <w.rf>
    <LM>w#w-d1t832-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t832-7">
   <w.rf>
    <LM>w#w-d1t832-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t832-8">
   <w.rf>
    <LM>w#w-d1t832-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t834-1">
   <w.rf>
    <LM>w#w-d1t834-1</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m050-d1t832-10">
   <w.rf>
    <LM>w#w-d1t832-10</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t834-2">
   <w.rf>
    <LM>w#w-d1t834-2</LM>
   </w.rf>
   <form>nestačila</form>
   <lemma>stačit</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m050-d1e825-x2-222">
   <w.rf>
    <LM>w#w-d1e825-x2-222</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-223">
  <m id="m050-d1t834-4">
   <w.rf>
    <LM>w#w-d1t834-4</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t834-5">
   <w.rf>
    <LM>w#w-d1t834-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t834-6">
   <w.rf>
    <LM>w#w-d1t834-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t834-7">
   <w.rf>
    <LM>w#w-d1t834-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t834-8">
   <w.rf>
    <LM>w#w-d1t834-8</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t834-9">
   <w.rf>
    <LM>w#w-d1t834-9</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d-id81027-punct">
   <w.rf>
    <LM>w#w-d-id81027-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t834-12">
   <w.rf>
    <LM>w#w-d1t834-12</LM>
   </w.rf>
   <form>taťka</form>
   <lemma>taťka_,h</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t834-13">
   <w.rf>
    <LM>w#w-d1t834-13</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m050-d1t834-14">
   <w.rf>
    <LM>w#w-d1t834-14</LM>
   </w.rf>
   <form>nenápadně</form>
   <lemma>nápadně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m050-d1t834-15">
   <w.rf>
    <LM>w#w-d1t834-15</LM>
   </w.rf>
   <form>pomáhal</form>
   <lemma>pomáhat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t834-16">
   <w.rf>
    <LM>w#w-d1t834-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t834-17">
   <w.rf>
    <LM>w#w-d1t834-17</LM>
   </w.rf>
   <form>tlačil</form>
   <lemma>tlačit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t834-18">
   <w.rf>
    <LM>w#w-d1t834-18</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m050-d1t834-19">
   <w.rf>
    <LM>w#w-d1t834-19</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t834-20">
   <w.rf>
    <LM>w#w-d1t834-20</LM>
   </w.rf>
   <form>kopců</form>
   <lemma>kopec</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m050-d-id81186-punct">
   <w.rf>
    <LM>w#w-d-id81186-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t836-1">
   <w.rf>
    <LM>w#w-d1t836-1</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m050-d1t836-2">
   <w.rf>
    <LM>w#w-d1t836-2</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m050-d1t836-3">
   <w.rf>
    <LM>w#w-d1t836-3</LM>
   </w.rf>
   <form>klukům</form>
   <lemma>kluk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m050-d1t836-4">
   <w.rf>
    <LM>w#w-d1t836-4</LM>
   </w.rf>
   <form>stačila</form>
   <lemma>stačit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d-m-d1e825-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e825-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e825-x4">
  <m id="m050-d1t856-1">
   <w.rf>
    <LM>w#w-d1t856-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t856-2">
   <w.rf>
    <LM>w#w-d1t856-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t856-3">
   <w.rf>
    <LM>w#w-d1t856-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t856-4">
   <w.rf>
    <LM>w#w-d1t856-4</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d-m-d1e825-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e825-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-365">
  <m id="m050-d1t861-3">
   <w.rf>
    <LM>w#w-d1t861-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t861-2">
   <w.rf>
    <LM>w#w-d1t861-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t861-4">
   <w.rf>
    <LM>w#w-d1t861-4</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t861-5">
   <w.rf>
    <LM>w#w-d1t861-5</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d1e858-x2-226">
   <w.rf>
    <LM>w#w-d1e858-x2-226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-227">
  <m id="m050-d1t861-7">
   <w.rf>
    <LM>w#w-d1t861-7</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t861-8">
   <w.rf>
    <LM>w#w-d1t861-8</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t861-10">
   <w.rf>
    <LM>w#w-d1t861-10</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t861-11">
   <w.rf>
    <LM>w#w-d1t861-11</LM>
   </w.rf>
   <form>obětavý</form>
   <lemma>obětavý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m050-227-228">
   <w.rf>
    <LM>w#w-227-228</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-229">
  <m id="m050-d1t861-13">
   <w.rf>
    <LM>w#w-d1t861-13</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t861-14">
   <w.rf>
    <LM>w#w-d1t861-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t861-15">
   <w.rf>
    <LM>w#w-d1t861-15</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m050-d1t861-16">
   <w.rf>
    <LM>w#w-d1t861-16</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t861-17">
   <w.rf>
    <LM>w#w-d1t861-17</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m050-d1t861-18">
   <w.rf>
    <LM>w#w-d1t861-18</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d-id81727-punct">
   <w.rf>
    <LM>w#w-d-id81727-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t861-20">
   <w.rf>
    <LM>w#w-d1t861-20</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t861-21">
   <w.rf>
    <LM>w#w-d1t861-21</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t861-22">
   <w.rf>
    <LM>w#w-d1t861-22</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m050-d1t861-23">
   <w.rf>
    <LM>w#w-d1t861-23</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t861-24">
   <w.rf>
    <LM>w#w-d1t861-24</LM>
   </w.rf>
   <form>věnoval</form>
   <lemma>věnovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-229-230">
   <w.rf>
    <LM>w#w-229-230</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-231">
  <m id="m050-d1t863-1">
   <w.rf>
    <LM>w#w-d1t863-1</LM>
   </w.rf>
   <form>Klukům</form>
   <lemma>kluk</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m050-d1t863-2">
   <w.rf>
    <LM>w#w-d1t863-2</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m050-d1t863-3">
   <w.rf>
    <LM>w#w-d1t863-3</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m050-d1t863-4">
   <w.rf>
    <LM>w#w-d1t863-4</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m050-d1t863-5">
   <w.rf>
    <LM>w#w-d1t863-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t863-6">
   <w.rf>
    <LM>w#w-d1t863-6</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m050-d1t863-7">
   <w.rf>
    <LM>w#w-d1t863-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e858-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e858-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e866-x2">
  <m id="m050-d1t871-2">
   <w.rf>
    <LM>w#w-d1t871-2</LM>
   </w.rf>
   <form>Chtěl</form>
   <lemma>chtít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d-id82060-punct">
   <w.rf>
    <LM>w#w-d-id82060-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t871-4">
   <w.rf>
    <LM>w#w-d1t871-4</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m050-d1t871-5">
   <w.rf>
    <LM>w#w-d1t871-5</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m050-d1t871-6">
   <w.rf>
    <LM>w#w-d1t871-6</LM>
   </w.rf>
   <form>stačila</form>
   <lemma>stačit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d-id82116-punct">
   <w.rf>
    <LM>w#w-d-id82116-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t871-9">
   <w.rf>
    <LM>w#w-d1t871-9</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t871-11">
   <w.rf>
    <LM>w#w-d1t871-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t871-12">
   <w.rf>
    <LM>w#w-d1t871-12</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m050-d1t871-13">
   <w.rf>
    <LM>w#w-d1t871-13</LM>
   </w.rf>
   <form>nesmáli</form>
   <lemma>smát</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m050-d-id82189-punct">
   <w.rf>
    <LM>w#w-d-id82189-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t871-15">
   <w.rf>
    <LM>w#w-d1t871-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t871-16">
   <w.rf>
    <LM>w#w-d1t871-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t871-17">
   <w.rf>
    <LM>w#w-d1t871-17</LM>
   </w.rf>
   <form>holka</form>
   <lemma>holka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t871-18">
   <w.rf>
    <LM>w#w-d1t871-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t871-19">
   <w.rf>
    <LM>w#w-d1t871-19</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t871-20">
   <w.rf>
    <LM>w#w-d1t871-20</LM>
   </w.rf>
   <form>nejmenší</form>
   <lemma>malý</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m050-d1t871-21">
   <w.rf>
    <LM>w#w-d1t871-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t871-22">
   <w.rf>
    <LM>w#w-d1t871-22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t871-23">
   <w.rf>
    <LM>w#w-d1t871-23</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m050-d1t871-24">
   <w.rf>
    <LM>w#w-d1t871-24</LM>
   </w.rf>
   <form>nestačím</form>
   <lemma>stačit</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m050-d1e866-x2-238">
   <w.rf>
    <LM>w#w-d1e866-x2-238</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-241">
  <m id="m050-d1t871-27">
   <w.rf>
    <LM>w#w-d1t871-27</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t871-28">
   <w.rf>
    <LM>w#w-d1t871-28</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t871-29">
   <w.rf>
    <LM>w#w-d1t871-29</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t871-30">
   <w.rf>
    <LM>w#w-d1t871-30</LM>
   </w.rf>
   <form>udělal</form>
   <lemma>udělat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m050-241-391">
   <w.rf>
    <LM>w#w-241-391</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-392">
  <m id="m050-d1t875-1">
   <w.rf>
    <LM>w#w-d1t875-1</LM>
   </w.rf>
   <form>Vyzdvihl</form>
   <lemma>vyzdvihnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m050-d1t873-2">
   <w.rf>
    <LM>w#w-d1t873-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m050-d-id82535-punct">
   <w.rf>
    <LM>w#w-d-id82535-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t875-7">
   <w.rf>
    <LM>w#w-d1t875-7</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t875-8">
   <w.rf>
    <LM>w#w-d1t875-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t875-9">
   <w.rf>
    <LM>w#w-d1t875-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t875-11">
   <w.rf>
    <LM>w#w-d1t875-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t875-10">
   <w.rf>
    <LM>w#w-d1t875-10</LM>
   </w.rf>
   <form>dokázala</form>
   <lemma>dokázat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m050-d1t875-12">
   <w.rf>
    <LM>w#w-d1t875-12</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t875-13">
   <w.rf>
    <LM>w#w-d1t875-13</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m050-d1t875-14">
   <w.rf>
    <LM>w#w-d1t875-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t877-1">
   <w.rf>
    <LM>w#w-d1t877-1</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t877-2">
   <w.rf>
    <LM>w#w-d1t877-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t877-3">
   <w.rf>
    <LM>w#w-d1t877-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t877-4">
   <w.rf>
    <LM>w#w-d1t877-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m050-d1t877-5">
   <w.rf>
    <LM>w#w-d1t877-5</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t877-6">
   <w.rf>
    <LM>w#w-d1t877-6</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d-m-d1e866-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e866-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e883-x2">
  <m id="m050-d1t886-1">
   <w.rf>
    <LM>w#w-d1t886-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t886-2">
   <w.rf>
    <LM>w#w-d1t886-2</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t886-3">
   <w.rf>
    <LM>w#w-d1t886-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t888-1">
   <w.rf>
    <LM>w#w-d1t888-1</LM>
   </w.rf>
   <form>hodný</form>
   <lemma>hodný_^(být_hoden;nezlobivý)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m050-d1t888-2">
   <w.rf>
    <LM>w#w-d1t888-2</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d-m-d1e883-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e883-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e889-x2">
  <m id="m050-d1t892-1">
   <w.rf>
    <LM>w#w-d1t892-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t892-2">
   <w.rf>
    <LM>w#w-d1t892-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t892-3">
   <w.rf>
    <LM>w#w-d1t892-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t892-4">
   <w.rf>
    <LM>w#w-d1t892-4</LM>
   </w.rf>
   <form>jediné</form>
   <lemma>jediný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d1t892-5">
   <w.rf>
    <LM>w#w-d1t892-5</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m050-d-id83051-punct">
   <w.rf>
    <LM>w#w-d-id83051-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e893-x2">
  <m id="m050-d1t898-8">
   <w.rf>
    <LM>w#w-d1t898-8</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t898-9">
   <w.rf>
    <LM>w#w-d1t898-9</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m050-d1t898-10">
   <w.rf>
    <LM>w#w-d1t898-10</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d1t898-6">
   <w.rf>
    <LM>w#w-d1t898-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t898-7">
   <w.rf>
    <LM>w#w-d1t898-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t898-11">
   <w.rf>
    <LM>w#w-d1t898-11</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t898-12">
   <w.rf>
    <LM>w#w-d1t898-12</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m050-d1e893-x2-249">
   <w.rf>
    <LM>w#w-d1e893-x2-249</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t898-14">
   <w.rf>
    <LM>w#w-d1t898-14</LM>
   </w.rf>
   <form>díky</form>
   <lemma>díky</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m050-d1t898-15">
   <w.rf>
    <LM>w#w-d1t898-15</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m050-d-id83328-punct">
   <w.rf>
    <LM>w#w-d-id83328-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t898-17">
   <w.rf>
    <LM>w#w-d1t898-17</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t898-19">
   <w.rf>
    <LM>w#w-d1t898-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t898-20">
   <w.rf>
    <LM>w#w-d1t898-20</LM>
   </w.rf>
   <form>vedl</form>
   <lemma>vést</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t898-22">
   <w.rf>
    <LM>w#w-d1t898-22</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m050-d1t898-23">
   <w.rf>
    <LM>w#w-d1t898-23</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t898-24">
   <w.rf>
    <LM>w#w-d1t898-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t898-25">
   <w.rf>
    <LM>w#w-d1t898-25</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t898-26">
   <w.rf>
    <LM>w#w-d1t898-26</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t898-27">
   <w.rf>
    <LM>w#w-d1t898-27</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m050-d1t898-28">
   <w.rf>
    <LM>w#w-d1t898-28</LM>
   </w.rf>
   <form>dohlídl</form>
   <lemma>dohlídnout_,h_^(^GC**dohlédnout)</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m050-d1t898-29">
   <w.rf>
    <LM>w#w-d1t898-29</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t898-32">
   <w.rf>
    <LM>w#w-d1t898-32</LM>
   </w.rf>
   <form>pomohl</form>
   <lemma>pomoci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m050-d1t898-31">
   <w.rf>
    <LM>w#w-d1t898-31</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m050-d1e893-x2-247">
   <w.rf>
    <LM>w#w-d1e893-x2-247</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e901-x2">
  <m id="m050-d1t906-1">
   <w.rf>
    <LM>w#w-d1t906-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t906-3">
   <w.rf>
    <LM>w#w-d1t906-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t906-4">
   <w.rf>
    <LM>w#w-d1t906-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m050-d1t906-5">
   <w.rf>
    <LM>w#w-d1t906-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1t906-2">
   <w.rf>
    <LM>w#w-d1t906-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d-id83712-punct">
   <w.rf>
    <LM>w#w-d-id83712-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e907-x2">
  <m id="m050-d1t912-3">
   <w.rf>
    <LM>w#w-d1t912-3</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t912-2">
   <w.rf>
    <LM>w#w-d1t912-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d-id83829-punct">
   <w.rf>
    <LM>w#w-d-id83829-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t912-5">
   <w.rf>
    <LM>w#w-d1t912-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t912-6">
   <w.rf>
    <LM>w#w-d1t912-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t912-7">
   <w.rf>
    <LM>w#w-d1t912-7</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t912-8">
   <w.rf>
    <LM>w#w-d1t912-8</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t912-9">
   <w.rf>
    <LM>w#w-d1t912-9</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t912-11">
   <w.rf>
    <LM>w#w-d1t912-11</LM>
   </w.rf>
   <form>Starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m050-d1t912-12">
   <w.rf>
    <LM>w#w-d1t912-12</LM>
   </w.rf>
   <form>Plzenec</form>
   <lemma>Plzenec_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d1t912-16">
   <w.rf>
    <LM>w#w-d1t912-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t914-2">
   <w.rf>
    <LM>w#w-d1t914-2</LM>
   </w.rf>
   <form>Lopatu</form>
   <lemma>lopata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d1e907-x2-263">
   <w.rf>
    <LM>w#w-d1e907-x2-263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-264">
  <m id="m050-d1t916-3">
   <w.rf>
    <LM>w#w-d1t916-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t916-2">
   <w.rf>
    <LM>w#w-d1t916-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t916-1">
   <w.rf>
    <LM>w#w-d1t916-1</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t916-6">
   <w.rf>
    <LM>w#w-d1t916-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t916-7">
   <w.rf>
    <LM>w#w-d1t916-7</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m050-d1t916-8">
   <w.rf>
    <LM>w#w-d1t916-8</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d1t916-4">
   <w.rf>
    <LM>w#w-d1t916-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t916-11">
   <w.rf>
    <LM>w#w-d1t916-11</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t916-12">
   <w.rf>
    <LM>w#w-d1t916-12</LM>
   </w.rf>
   <form>dlouhý</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m050-d1t916-13">
   <w.rf>
    <LM>w#w-d1t916-13</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-264-181">
   <w.rf>
    <LM>w#w-264-181</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-264-180">
   <w.rf>
    <LM>w#w-264-180</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-264-179">
   <w.rf>
    <LM>w#w-264-179</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-264-178">
   <w.rf>
    <LM>w#w-264-178</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-264-177">
   <w.rf>
    <LM>w#w-264-177</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-264-410">
   <w.rf>
    <LM>w#w-264-410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-264-411">
   <w.rf>
    <LM>w#w-264-411</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-264-412">
   <w.rf>
    <LM>w#w-264-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-266">
  <m id="m050-266-162">
   <w.rf>
    <LM>w#w-266-162</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m050-266-161">
   <w.rf>
    <LM>w#w-266-161</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m050-266-163">
   <w.rf>
    <LM>w#w-266-163</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t918-7">
   <w.rf>
    <LM>w#w-d1t918-7</LM>
   </w.rf>
   <form>kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m050-d1t918-8">
   <w.rf>
    <LM>w#w-d1t918-8</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m050-d1t918-10">
   <w.rf>
    <LM>w#w-d1t918-10</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t918-11">
   <w.rf>
    <LM>w#w-d1t918-11</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d1t918-12">
   <w.rf>
    <LM>w#w-d1t918-12</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m050-266-182">
   <w.rf>
    <LM>w#w-266-182</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-268">
  <m id="m050-d1t923-1">
   <w.rf>
    <LM>w#w-d1t923-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m050-d1t923-2">
   <w.rf>
    <LM>w#w-d1t923-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t923-3">
   <w.rf>
    <LM>w#w-d1t923-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t923-5">
   <w.rf>
    <LM>w#w-d1t923-5</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m050-d1t923-6">
   <w.rf>
    <LM>w#w-d1t923-6</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t923-7">
   <w.rf>
    <LM>w#w-d1t923-7</LM>
   </w.rf>
   <form>dvanáct</form>
   <lemma>dvanáct`12</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m050-d1t935-4">
   <w.rf>
    <LM>w#w-d1t935-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m050-d-id84563-punct">
   <w.rf>
    <LM>w#w-d-id84563-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t923-10">
   <w.rf>
    <LM>w#w-d1t923-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t923-9">
   <w.rf>
    <LM>w#w-d1t923-9</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m050-d-m-d1e907-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e907-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e942-x2">
  <m id="m050-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>Myslela</form>
   <lemma>myslit</lemma>
   <tag>VpQW----R-AAI-1</tag>
  </m>
  <m id="m050-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d-id84858-punct">
   <w.rf>
    <LM>w#w-d-id84858-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t945-5">
   <w.rf>
    <LM>w#w-d1t945-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t945-7">
   <w.rf>
    <LM>w#w-d1t945-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t945-8">
   <w.rf>
    <LM>w#w-d1t945-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t945-9">
   <w.rf>
    <LM>w#w-d1t945-9</LM>
   </w.rf>
   <form>vyfocená</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m050-d-id84932-punct">
   <w.rf>
    <LM>w#w-d-id84932-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e946-x2">
  <m id="m050-d1e946-x2-204">
   <w.rf>
    <LM>w#w-d1e946-x2-204</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1e946-x2-203">
   <w.rf>
    <LM>w#w-d1e946-x2-203</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m050-d1e946-x2-208">
   <w.rf>
    <LM>w#w-d1e946-x2-208</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1e946-x2-205">
   <w.rf>
    <LM>w#w-d1e946-x2-205</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-207">
  <m id="m050-d1t951-2">
   <w.rf>
    <LM>w#w-d1t951-2</LM>
   </w.rf>
   <form>Celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t951-3">
   <w.rf>
    <LM>w#w-d1t951-3</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t951-4">
   <w.rf>
    <LM>w#w-d1t951-4</LM>
   </w.rf>
   <form>vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e946-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e946-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e952-x2">
  <m id="m050-d1t957-1">
   <w.rf>
    <LM>w#w-d1t957-1</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t957-2">
   <w.rf>
    <LM>w#w-d1t957-2</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m050-d1t957-3">
   <w.rf>
    <LM>w#w-d1t957-3</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d-id85230-punct">
   <w.rf>
    <LM>w#w-d-id85230-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e959-x2">
  <m id="m050-d1t964-1">
   <w.rf>
    <LM>w#w-d1t964-1</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m050-d1t964-2">
   <w.rf>
    <LM>w#w-d1t964-2</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t964-3">
   <w.rf>
    <LM>w#w-d1t964-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t964-4">
   <w.rf>
    <LM>w#w-d1t964-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t964-5">
   <w.rf>
    <LM>w#w-d1t964-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t964-7">
   <w.rf>
    <LM>w#w-d1t964-7</LM>
   </w.rf>
   <form>uprostřed</form>
   <lemma>uprostřed-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1e959-x2-274">
   <w.rf>
    <LM>w#w-d1e959-x2-274</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t964-8">
   <w.rf>
    <LM>w#w-d1t964-8</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t964-10">
   <w.rf>
    <LM>w#w-d1t964-10</LM>
   </w.rf>
   <form>svých</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP2----------</tag>
  </m>
  <m id="m050-d1t964-11">
   <w.rf>
    <LM>w#w-d1t964-11</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m050-d-id85471-punct">
   <w.rf>
    <LM>w#w-d-id85471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t964-13">
   <w.rf>
    <LM>w#w-d1t964-13</LM>
   </w.rf>
   <form>spolužáků</form>
   <lemma>spolužák</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m050-d-m-d1e959-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e959-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e965-x2">
  <m id="m050-d1t968-1">
   <w.rf>
    <LM>w#w-d1t968-1</LM>
   </w.rf>
   <form>Můžete</form>
   <lemma>moci</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t968-2">
   <w.rf>
    <LM>w#w-d1t968-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m050-d1t968-3">
   <w.rf>
    <LM>w#w-d1t968-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m050-d1t968-4">
   <w.rf>
    <LM>w#w-d1t968-4</LM>
   </w.rf>
   <form>ukázat</form>
   <lemma>ukázat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m050-d-id85610-punct">
   <w.rf>
    <LM>w#w-d-id85610-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e969-x2">
  <m id="m050-d1t978-1">
   <w.rf>
    <LM>w#w-d1t978-1</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t978-2">
   <w.rf>
    <LM>w#w-d1t978-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t978-3">
   <w.rf>
    <LM>w#w-d1t978-3</LM>
   </w.rf>
   <form>bráška</form>
   <lemma>bráška</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t978-4">
   <w.rf>
    <LM>w#w-d1t978-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t978-5">
   <w.rf>
    <LM>w#w-d1t978-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t978-6">
   <w.rf>
    <LM>w#w-d1t978-6</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m050-d-m-d1e969-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e969-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e984-x2">
  <m id="m050-d1t991-1">
   <w.rf>
    <LM>w#w-d1t991-1</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t991-2">
   <w.rf>
    <LM>w#w-d1t991-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t991-3">
   <w.rf>
    <LM>w#w-d1t991-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t991-4">
   <w.rf>
    <LM>w#w-d1t991-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m050-d1t991-5">
   <w.rf>
    <LM>w#w-d1t991-5</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m050-d1t991-6">
   <w.rf>
    <LM>w#w-d1t991-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t991-7">
   <w.rf>
    <LM>w#w-d1t991-7</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m050-d1t991-8">
   <w.rf>
    <LM>w#w-d1t991-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t991-9">
   <w.rf>
    <LM>w#w-d1t991-9</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m050-d-id86014-punct">
   <w.rf>
    <LM>w#w-d-id86014-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e992-x2">
  <m id="m050-d1t995-2">
   <w.rf>
    <LM>w#w-d1t995-2</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t995-3">
   <w.rf>
    <LM>w#w-d1t995-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t995-4">
   <w.rf>
    <LM>w#w-d1t995-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t995-5">
   <w.rf>
    <LM>w#w-d1t995-5</LM>
   </w.rf>
   <form>pěší</form>
   <lemma>pěší</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m050-d-id86146-punct">
   <w.rf>
    <LM>w#w-d-id86146-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t995-7">
   <w.rf>
    <LM>w#w-d1t995-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t995-9">
   <w.rf>
    <LM>w#w-d1t995-9</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m050-d1t995-11">
   <w.rf>
    <LM>w#w-d1t995-11</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t995-12">
   <w.rf>
    <LM>w#w-d1t995-12</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t995-13">
   <w.rf>
    <LM>w#w-d1t995-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t995-15">
   <w.rf>
    <LM>w#w-d1t995-15</LM>
   </w.rf>
   <form>kolo</form>
   <lemma>kolo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m050-d1e992-x2-285">
   <w.rf>
    <LM>w#w-d1e992-x2-285</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-286">
  <m id="m050-d1t997-1">
   <w.rf>
    <LM>w#w-d1t997-1</LM>
   </w.rf>
   <form>Ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m050-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t997-3">
   <w.rf>
    <LM>w#w-d1t997-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t997-4">
   <w.rf>
    <LM>w#w-d1t997-4</LM>
   </w.rf>
   <form>nemohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m050-d1t997-5">
   <w.rf>
    <LM>w#w-d1t997-5</LM>
   </w.rf>
   <form>dočkat</form>
   <lemma>dočkat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m050-286-287">
   <w.rf>
    <LM>w#w-286-287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-288">
  <m id="m050-d1t997-8">
   <w.rf>
    <LM>w#w-d1t997-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t997-9">
   <w.rf>
    <LM>w#w-d1t997-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t997-10">
   <w.rf>
    <LM>w#w-d1t997-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-288-289">
   <w.rf>
    <LM>w#w-288-289</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t999-2">
   <w.rf>
    <LM>w#w-d1t999-2</LM>
   </w.rf>
   <form>výlet</form>
   <lemma>výlet</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d1t999-3">
   <w.rf>
    <LM>w#w-d1t999-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t999-4">
   <w.rf>
    <LM>w#w-d1t999-4</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t999-5">
   <w.rf>
    <LM>w#w-d1t999-5</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t999-6">
   <w.rf>
    <LM>w#w-d1t999-6</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m050-d1t999-7">
   <w.rf>
    <LM>w#w-d1t999-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t999-8">
   <w.rf>
    <LM>w#w-d1t999-8</LM>
   </w.rf>
   <form>měsíc</form>
   <lemma>měsíc</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d1t999-9">
   <w.rf>
    <LM>w#w-d1t999-9</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t999-12">
   <w.rf>
    <LM>w#w-d1t999-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t999-13">
   <w.rf>
    <LM>w#w-d1t999-13</LM>
   </w.rf>
   <form>čtrnáct</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m050-d1t999-14">
   <w.rf>
    <LM>w#w-d1t999-14</LM>
   </w.rf>
   <form>dní</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP2-----A---1</tag>
  </m>
  <m id="m050-288-290">
   <w.rf>
    <LM>w#w-288-290</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-291">
  <m id="m050-d1t999-15">
   <w.rf>
    <LM>w#w-d1t999-15</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t999-16">
   <w.rf>
    <LM>w#w-d1t999-16</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m050-d1t999-18">
   <w.rf>
    <LM>w#w-d1t999-18</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t999-20">
   <w.rf>
    <LM>w#w-d1t999-20</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m050-d1t999-19">
   <w.rf>
    <LM>w#w-d1t999-19</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m050-d1t1001-1">
   <w.rf>
    <LM>w#w-d1t1001-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1001-2">
   <w.rf>
    <LM>w#w-d1t1001-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1001-3">
   <w.rf>
    <LM>w#w-d1t1001-3</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1t1001-4">
   <w.rf>
    <LM>w#w-d1t1001-4</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t1001-6">
   <w.rf>
    <LM>w#w-d1t1001-6</LM>
   </w.rf>
   <form>příprava</form>
   <lemma>příprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-291-292">
   <w.rf>
    <LM>w#w-291-292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-293">
  <m id="m050-d1t1003-1">
   <w.rf>
    <LM>w#w-d1t1003-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>jaře</form>
   <lemma>jaro</lemma>
   <tag>NNNS6-----A---1</tag>
  </m>
  <m id="m050-d-id86915-punct">
   <w.rf>
    <LM>w#w-d-id86915-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>podzim</form>
   <lemma>podzim</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d1t1003-8">
   <w.rf>
    <LM>w#w-d1t1003-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1003-11">
   <w.rf>
    <LM>w#w-d1t1003-11</LM>
   </w.rf>
   <form>kola</form>
   <lemma>kolo</lemma>
   <tag>NNNP1-----A----</tag>
  </m>
  <m id="m050-d1t1003-9">
   <w.rf>
    <LM>w#w-d1t1003-9</LM>
   </w.rf>
   <form>dávala</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t1003-12">
   <w.rf>
    <LM>w#w-d1t1003-12</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1003-13">
   <w.rf>
    <LM>w#w-d1t1003-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1003-14">
   <w.rf>
    <LM>w#w-d1t1003-14</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m050-d1t1003-15">
   <w.rf>
    <LM>w#w-d1t1003-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1003-16">
   <w.rf>
    <LM>w#w-d1t1003-16</LM>
   </w.rf>
   <form>těšili</form>
   <lemma>těšit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d-id87111-punct">
   <w.rf>
    <LM>w#w-d-id87111-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1003-18">
   <w.rf>
    <LM>w#w-d1t1003-18</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1003-19">
   <w.rf>
    <LM>w#w-d1t1003-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1003-20">
   <w.rf>
    <LM>w#w-d1t1003-20</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1003-21">
   <w.rf>
    <LM>w#w-d1t1003-21</LM>
   </w.rf>
   <form>vyrazí</form>
   <lemma>vyrazit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m050-293-303">
   <w.rf>
    <LM>w#w-293-303</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e992-x3">
  <m id="m050-d1t1006-1">
   <w.rf>
    <LM>w#w-d1t1006-1</LM>
   </w.rf>
   <form>Čekalo</form>
   <lemma>čekat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t1006-2">
   <w.rf>
    <LM>w#w-d1t1006-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1006-4">
   <w.rf>
    <LM>w#w-d1t1006-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1006-5">
   <w.rf>
    <LM>w#w-d1t1006-5</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m050-d1t1006-6">
   <w.rf>
    <LM>w#w-d1t1006-6</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m050-d-id87276-punct">
   <w.rf>
    <LM>w#w-d-id87276-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1008-1">
   <w.rf>
    <LM>w#w-d1t1008-1</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m050-d1t1008-2">
   <w.rf>
    <LM>w#w-d1t1008-2</LM>
   </w.rf>
   <form>nezmokli</form>
   <lemma>zmoknout</lemma>
   <tag>VpMP----R-NAP-1</tag>
  </m>
  <m id="m050-d1e992-x3-80">
   <w.rf>
    <LM>w#w-d1e992-x3-80</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1008-5">
   <w.rf>
    <LM>w#w-d1t1008-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1010-1">
   <w.rf>
    <LM>w#w-d1t1010-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1010-2">
   <w.rf>
    <LM>w#w-d1t1010-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1010-3">
   <w.rf>
    <LM>w#w-d1t1010-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1010-4">
   <w.rf>
    <LM>w#w-d1t1010-4</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m050-d1t1010-5">
   <w.rf>
    <LM>w#w-d1t1010-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1010-6">
   <w.rf>
    <LM>w#w-d1t1010-6</LM>
   </w.rf>
   <form>vyrazili</form>
   <lemma>vyrazit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m050-d1t1010-7">
   <w.rf>
    <LM>w#w-d1t1010-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d-m-d1e992-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e992-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1013-x2">
  <m id="m050-d1t1018-2">
   <w.rf>
    <LM>w#w-d1t1018-2</LM>
   </w.rf>
   <form>Vidíte</form>
   <lemma>vidět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m050-d1t1018-4">
   <w.rf>
    <LM>w#w-d1t1018-4</LM>
   </w.rf>
   <form>někoho</form>
   <lemma>někdo</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m050-d1t1018-5">
   <w.rf>
    <LM>w#w-d1t1018-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t1018-6">
   <w.rf>
    <LM>w#w-d1t1018-6</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m050-d1t1018-7">
   <w.rf>
    <LM>w#w-d1t1018-7</LM>
   </w.rf>
   <form>kluků</form>
   <lemma>kluk</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m050-d1t1018-8">
   <w.rf>
    <LM>w#w-d1t1018-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1018-9">
   <w.rf>
    <LM>w#w-d1t1018-9</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-id87680-punct">
   <w.rf>
    <LM>w#w-d-id87680-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1019-x2">
  <m id="m050-d1t1024-2">
   <w.rf>
    <LM>w#w-d1t1024-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1024-3">
   <w.rf>
    <LM>w#w-d1t1024-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m050-d1t1024-5">
   <w.rf>
    <LM>w#w-d1t1024-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t1024-6">
   <w.rf>
    <LM>w#w-d1t1024-6</LM>
   </w.rf>
   <form>známí</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m050-d-m-d1e1019-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1019-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1025-x2">
  <m id="m050-d1t1030-1">
   <w.rf>
    <LM>w#w-d1t1030-1</LM>
   </w.rf>
   <form>Tuhleto</form>
   <lemma>tuhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1030-3">
   <w.rf>
    <LM>w#w-d1t1030-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m050-d1t1032-5">
   <w.rf>
    <LM>w#w-d1t1032-5</LM>
   </w.rf>
   <form>největší</form>
   <lemma>velký</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m050-d1t1032-1">
   <w.rf>
    <LM>w#w-d1t1032-1</LM>
   </w.rf>
   <form>kamarád</form>
   <lemma>kamarád</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m050-d1t1032-3">
   <w.rf>
    <LM>w#w-d1t1032-3</LM>
   </w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m050-d-id88000-punct">
   <w.rf>
    <LM>w#w-d-id88000-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1032-7">
   <w.rf>
    <LM>w#w-d1t1032-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1032-8">
   <w.rf>
    <LM>w#w-d1t1032-8</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m050-d1t1032-9">
   <w.rf>
    <LM>w#w-d1t1032-9</LM>
   </w.rf>
   <form>teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1032-10">
   <w.rf>
    <LM>w#w-d1t1032-10</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1032-11">
   <w.rf>
    <LM>w#w-d1t1032-11</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1032-12">
   <w.rf>
    <LM>w#w-d1t1032-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1032-14">
   <w.rf>
    <LM>w#w-d1t1032-14</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d1e1025-x2-312">
   <w.rf>
    <LM>w#w-d1e1025-x2-312</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-313">
  <m id="m050-d1t1032-20">
   <w.rf>
    <LM>w#w-d1t1032-20</LM>
   </w.rf>
   <form>Teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1032-22">
   <w.rf>
    <LM>w#w-d1t1032-22</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1032-23">
   <w.rf>
    <LM>w#w-d1t1032-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1032-21">
   <w.rf>
    <LM>w#w-d1t1032-21</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t1032-19">
   <w.rf>
    <LM>w#w-d1t1032-19</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1032-24">
   <w.rf>
    <LM>w#w-d1t1032-24</LM>
   </w.rf>
   <form>dávno</form>
   <lemma>dávno-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t1032-25">
   <w.rf>
    <LM>w#w-d1t1032-25</LM>
   </w.rf>
   <form>dospělí</form>
   <lemma>dospělý_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m050-d1t1032-26">
   <w.rf>
    <LM>w#w-d1t1032-26</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m050-d-id88272-punct">
   <w.rf>
    <LM>w#w-d-id88272-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1032-30">
   <w.rf>
    <LM>w#w-d1t1032-30</LM>
   </w.rf>
   <form>oženili</form>
   <lemma>oženit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m050-d1t1032-29">
   <w.rf>
    <LM>w#w-d1t1032-29</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1032-31">
   <w.rf>
    <LM>w#w-d1t1032-31</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1032-32">
   <w.rf>
    <LM>w#w-d1t1032-32</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-P---3P-AAI-1</tag>
  </m>
  <m id="m050-d1t1032-33">
   <w.rf>
    <LM>w#w-d1t1032-33</LM>
   </w.rf>
   <form>různě</form>
   <lemma>různě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t1034-1">
   <w.rf>
    <LM>w#w-d1t1034-1</LM>
   </w.rf>
   <form>jinde</form>
   <lemma>jinde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e1025-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1025-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1042-x2">
  <m id="m050-d1t1045-1">
   <w.rf>
    <LM>w#w-d1t1045-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1e1042-x2-315">
   <w.rf>
    <LM>w#w-d1e1042-x2-315</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-316">
  <m id="m050-d1t1047-4">
   <w.rf>
    <LM>w#w-d1t1047-4</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m050-d1t1047-2">
   <w.rf>
    <LM>w#w-d1t1047-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d1t1047-1">
   <w.rf>
    <LM>w#w-d1t1047-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-316-317">
   <w.rf>
    <LM>w#w-316-317</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1047-3">
   <w.rf>
    <LM>w#w-d1t1047-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m050-d1t1047-5">
   <w.rf>
    <LM>w#w-d1t1047-5</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1047-6">
   <w.rf>
    <LM>w#w-d1t1047-6</LM>
   </w.rf>
   <form>pohledu</form>
   <lemma>pohled</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d1t1047-7">
   <w.rf>
    <LM>w#w-d1t1047-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1047-8">
   <w.rf>
    <LM>w#w-d1t1047-8</LM>
   </w.rf>
   <form>tuhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m050-d1t1047-9">
   <w.rf>
    <LM>w#w-d1t1047-9</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d-id88649-punct">
   <w.rf>
    <LM>w#w-d-id88649-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1048-x2">
  <m id="m050-d1t1051-2">
   <w.rf>
    <LM>w#w-d1t1051-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1e1048-x2-457">
   <w.rf>
    <LM>w#w-d1e1048-x2-457</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1051-3">
   <w.rf>
    <LM>w#w-d1t1051-3</LM>
   </w.rf>
   <form>můžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1051-4">
   <w.rf>
    <LM>w#w-d1t1051-4</LM>
   </w.rf>
   <form>posunout</form>
   <lemma>posunout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m050-d1t1051-5">
   <w.rf>
    <LM>w#w-d1t1051-5</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1051-6">
   <w.rf>
    <LM>w#w-d1t1051-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1051-7">
   <w.rf>
    <LM>w#w-d1t1051-7</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m050-d1t1051-8">
   <w.rf>
    <LM>w#w-d1t1051-8</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d-m-d1e1048-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1048-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1054-x2">
  <m id="m050-d1t1057-1">
   <w.rf>
    <LM>w#w-d1t1057-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1e1054-x2-319">
   <w.rf>
    <LM>w#w-d1e1054-x2-319</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-320">
  <m id="m050-d1t1059-1">
   <w.rf>
    <LM>w#w-d1t1059-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m050-d1t1059-2">
   <w.rf>
    <LM>w#w-d1t1059-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1059-3">
   <w.rf>
    <LM>w#w-d1t1059-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1059-4">
   <w.rf>
    <LM>w#w-d1t1059-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1059-5">
   <w.rf>
    <LM>w#w-d1t1059-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m050-d-id88991-punct">
   <w.rf>
    <LM>w#w-d-id88991-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1061-x2">
  <m id="m050-d1t1064-1">
   <w.rf>
    <LM>w#w-d1t1064-1</LM>
   </w.rf>
   <form>Toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1064-2">
   <w.rf>
    <LM>w#w-d1t1064-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1064-4">
   <w.rf>
    <LM>w#w-d1t1064-4</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1064-3">
   <w.rf>
    <LM>w#w-d1t1064-3</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1t1064-5">
   <w.rf>
    <LM>w#w-d1t1064-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m050-d1t1064-6">
   <w.rf>
    <LM>w#w-d1t1064-6</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1-------</tag>
  </m>
  <m id="m050-d1t1064-7">
   <w.rf>
    <LM>w#w-d1t1064-7</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-d-id89148-punct">
   <w.rf>
    <LM>w#w-d-id89148-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1064-9">
   <w.rf>
    <LM>w#w-d1t1064-9</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1064-11">
   <w.rf>
    <LM>w#w-d1t1064-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1064-12">
   <w.rf>
    <LM>w#w-d1t1064-12</LM>
   </w.rf>
   <form>chodila</form>
   <lemma>chodit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t1064-10">
   <w.rf>
    <LM>w#w-d1t1064-10</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m050-d-m-d1e1061-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1061-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1067-x2">
  <m id="m050-d1t1072-1">
   <w.rf>
    <LM>w#w-d1t1072-1</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1072-2">
   <w.rf>
    <LM>w#w-d1t1072-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1072-3">
   <w.rf>
    <LM>w#w-d1t1072-3</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t1072-4">
   <w.rf>
    <LM>w#w-d1t1072-4</LM>
   </w.rf>
   <form>mí</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1------1</tag>
  </m>
  <m id="m050-d1t1072-5">
   <w.rf>
    <LM>w#w-d1t1072-5</LM>
   </w.rf>
   <form>spolužáci</form>
   <lemma>spolužák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m050-d1t1072-6">
   <w.rf>
    <LM>w#w-d1t1072-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1072-7">
   <w.rf>
    <LM>w#w-d1t1072-7</LM>
   </w.rf>
   <form>spolužačky</form>
   <lemma>spolužačka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m050-d1e1067-x2-335">
   <w.rf>
    <LM>w#w-d1e1067-x2-335</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-349">
  <m id="m050-d1t1074-13">
   <w.rf>
    <LM>w#w-d1t1074-13</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1074-14">
   <w.rf>
    <LM>w#w-d1t1074-14</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1074-15">
   <w.rf>
    <LM>w#w-d1t1074-15</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d-id89608-punct">
   <w.rf>
    <LM>w#w-d-id89608-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1074-18">
   <w.rf>
    <LM>w#w-d1t1074-18</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t1074-17">
   <w.rf>
    <LM>w#w-d1t1074-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1074-19">
   <w.rf>
    <LM>w#w-d1t1074-19</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1074-21">
   <w.rf>
    <LM>w#w-d1t1074-21</LM>
   </w.rf>
   <form>Božkově</form>
   <lemma>Božkov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-349-350">
   <w.rf>
    <LM>w#w-349-350</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-351">
  <m id="m050-d1t1074-24">
   <w.rf>
    <LM>w#w-d1t1074-24</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1074-25">
   <w.rf>
    <LM>w#w-d1t1074-25</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m050-d1t1074-27">
   <w.rf>
    <LM>w#w-d1t1074-27</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m050-d1t1074-28">
   <w.rf>
    <LM>w#w-d1t1074-28</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m050-d1t1074-29">
   <w.rf>
    <LM>w#w-d1t1074-29</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d-id89791-punct">
   <w.rf>
    <LM>w#w-d-id89791-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1074-32">
   <w.rf>
    <LM>w#w-d1t1074-32</LM>
   </w.rf>
   <form>jakoby</form>
   <lemma>jakoby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t1074-33">
   <w.rf>
    <LM>w#w-d1t1074-33</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1074-34">
   <w.rf>
    <LM>w#w-d1t1074-34</LM>
   </w.rf>
   <form>vesnici</form>
   <lemma>vesnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m050-d-m-d1e1067-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1067-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1079-x2">
  <m id="m050-d1t1082-1">
   <w.rf>
    <LM>w#w-d1t1082-1</LM>
   </w.rf>
   <form>Teda</form>
   <lemma>teda-1_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t1082-3">
   <w.rf>
    <LM>w#w-d1t1082-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1082-4">
   <w.rf>
    <LM>w#w-d1t1082-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1082-5">
   <w.rf>
    <LM>w#w-d1t1082-5</LM>
   </w.rf>
   <form>okraj</form>
   <lemma>okraj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m050-d1t1082-7">
   <w.rf>
    <LM>w#w-d1t1082-7</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m050-d-id90030-punct">
   <w.rf>
    <LM>w#w-d-id90030-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1082-11">
   <w.rf>
    <LM>w#w-d1t1082-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m050-d1t1082-12">
   <w.rf>
    <LM>w#w-d1t1082-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1082-13">
   <w.rf>
    <LM>w#w-d1t1082-13</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m050-d1t1082-14">
   <w.rf>
    <LM>w#w-d1t1082-14</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m050-d1t1082-15">
   <w.rf>
    <LM>w#w-d1t1082-15</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m050-d1e1079-x2-352">
   <w.rf>
    <LM>w#w-d1e1079-x2-352</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-353">
  <m id="m050-d1t1084-5">
   <w.rf>
    <LM>w#w-d1t1084-5</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t1084-3">
   <w.rf>
    <LM>w#w-d1t1084-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1084-4">
   <w.rf>
    <LM>w#w-d1t1084-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1084-7">
   <w.rf>
    <LM>w#w-d1t1084-7</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t1084-8">
   <w.rf>
    <LM>w#w-d1t1084-8</LM>
   </w.rf>
   <form>obětavé</form>
   <lemma>obětavý</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m050-d1t1086-1">
   <w.rf>
    <LM>w#w-d1t1086-1</LM>
   </w.rf>
   <form>pány</form>
   <lemma>pán</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m050-d1t1086-2">
   <w.rf>
    <LM>w#w-d1t1086-2</LM>
   </w.rf>
   <form>učitele</form>
   <lemma>učitel</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m050-d1t1086-3">
   <w.rf>
    <LM>w#w-d1t1086-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1086-4">
   <w.rf>
    <LM>w#w-d1t1086-4</LM>
   </w.rf>
   <form>učitelky</form>
   <lemma>učitelka_^(*2)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d-id90329-punct">
   <w.rf>
    <LM>w#w-d-id90329-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1088-1">
   <w.rf>
    <LM>w#w-d1t1088-1</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m050-d1t1088-2">
   <w.rf>
    <LM>w#w-d1t1088-2</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m050-d1t1088-3">
   <w.rf>
    <LM>w#w-d1t1088-3</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m050-d1t1088-5">
   <w.rf>
    <LM>w#w-d1t1088-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1088-6">
   <w.rf>
    <LM>w#w-d1t1088-6</LM>
   </w.rf>
   <form>závěr</form>
   <lemma>závěr_^(př._z_jednání,_úvah)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m050-d1t1088-7">
   <w.rf>
    <LM>w#w-d1t1088-7</LM>
   </w.rf>
   <form>školního</form>
   <lemma>školní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m050-d1t1088-8">
   <w.rf>
    <LM>w#w-d1t1088-8</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m050-d1t1088-4">
   <w.rf>
    <LM>w#w-d1t1088-4</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t1088-9">
   <w.rf>
    <LM>w#w-d1t1088-9</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m050-d1t1088-10">
   <w.rf>
    <LM>w#w-d1t1088-10</LM>
   </w.rf>
   <form>besídky</form>
   <lemma>besídka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-d-id90502-punct">
   <w.rf>
    <LM>w#w-d-id90502-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1088-12">
   <w.rf>
    <LM>w#w-d1t1088-12</LM>
   </w.rf>
   <form>hry</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m050-353-354">
   <w.rf>
    <LM>w#w-353-354</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-355">
  <m id="m050-d1t1090-4">
   <w.rf>
    <LM>w#w-d1t1090-4</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1090-3">
   <w.rf>
    <LM>w#w-d1t1090-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1090-5">
   <w.rf>
    <LM>w#w-d1t1090-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d1t1090-6">
   <w.rf>
    <LM>w#w-d1t1090-6</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m050-d1t1090-7">
   <w.rf>
    <LM>w#w-d1t1090-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m050-d1t1090-9">
   <w.rf>
    <LM>w#w-d1t1090-9</LM>
   </w.rf>
   <form>Ferdu</form>
   <lemma>Ferda_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m050-d1t1090-10">
   <w.rf>
    <LM>w#w-d1t1090-10</LM>
   </w.rf>
   <form>Mravence</form>
   <lemma>mravenec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m050-d-m-d1e1079-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1079-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1096-x2">
  <m id="m050-d1t1101-1">
   <w.rf>
    <LM>w#w-d1t1101-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t1101-2">
   <w.rf>
    <LM>w#w-d1t1101-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1101-3">
   <w.rf>
    <LM>w#w-d1t1101-3</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1101-6">
   <w.rf>
    <LM>w#w-d1t1101-6</LM>
   </w.rf>
   <form>vystoupení</form>
   <lemma>vystoupení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m050-d1e1096-x2-358">
   <w.rf>
    <LM>w#w-d1e1096-x2-358</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1101-5">
   <w.rf>
    <LM>w#w-d1t1101-5</LM>
   </w.rf>
   <form>trošku</form>
   <lemma>trošku</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1101-8">
   <w.rf>
    <LM>w#w-d1t1101-8</LM>
   </w.rf>
   <form>divadelní</form>
   <lemma>divadelní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m050-d-id90884-punct">
   <w.rf>
    <LM>w#w-d-id90884-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1101-10">
   <w.rf>
    <LM>w#w-d1t1101-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1101-11">
   <w.rf>
    <LM>w#w-d1t1101-11</LM>
   </w.rf>
   <form>dělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t1101-12">
   <w.rf>
    <LM>w#w-d1t1101-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m050-d1t1101-13">
   <w.rf>
    <LM>w#w-d1t1101-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m050-d1t1101-14">
   <w.rf>
    <LM>w#w-d1t1101-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1101-15">
   <w.rf>
    <LM>w#w-d1t1101-15</LM>
   </w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m050-d-id90979-punct">
   <w.rf>
    <LM>w#w-d-id90979-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1101-17">
   <w.rf>
    <LM>w#w-d1t1101-17</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m050-d1t1101-18">
   <w.rf>
    <LM>w#w-d1t1101-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1101-19">
   <w.rf>
    <LM>w#w-d1t1101-19</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m050-d1t1101-20">
   <w.rf>
    <LM>w#w-d1t1101-20</LM>
   </w.rf>
   <form>školního</form>
   <lemma>školní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m050-d1t1101-21">
   <w.rf>
    <LM>w#w-d1t1101-21</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m050-d1t1101-22">
   <w.rf>
    <LM>w#w-d1t1101-22</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1101-23">
   <w.rf>
    <LM>w#w-d1t1101-23</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m050-d1t1101-24">
   <w.rf>
    <LM>w#w-d1t1101-24</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d-m-d1e1096-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1096-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m050-d1e1106-x2">
  <m id="m050-d1t1111-1">
   <w.rf>
    <LM>w#w-d1t1111-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m050-d1t1111-2">
   <w.rf>
    <LM>w#w-d1t1111-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1111-3">
   <w.rf>
    <LM>w#w-d1t1111-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t1111-5">
   <w.rf>
    <LM>w#w-d1t1111-5</LM>
   </w.rf>
   <form>soutěže</form>
   <lemma>soutěž</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m050-d1e1106-x2-366">
   <w.rf>
    <LM>w#w-d1e1106-x2-366</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m050-d1t1111-6">
   <w.rf>
    <LM>w#w-d1t1111-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1111-7">
   <w.rf>
    <LM>w#w-d1t1111-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m050-d1t1111-8">
   <w.rf>
    <LM>w#w-d1t1111-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m050-d1t1111-9">
   <w.rf>
    <LM>w#w-d1t1111-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m050-d1t1111-10">
   <w.rf>
    <LM>w#w-d1t1111-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m050-d1t1111-11">
   <w.rf>
    <LM>w#w-d1t1111-11</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m050-d1t1111-12">
   <w.rf>
    <LM>w#w-d1t1111-12</LM>
   </w.rf>
   <form>vyhráli</form>
   <lemma>vyhrát</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m050-d1t1113-1">
   <w.rf>
    <LM>w#w-d1t1113-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m050-d1t1113-2">
   <w.rf>
    <LM>w#w-d1t1113-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m050-d1t1113-3">
   <w.rf>
    <LM>w#w-d1t1113-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m050-d1t1113-4">
   <w.rf>
    <LM>w#w-d1t1113-4</LM>
   </w.rf>
   <form>hřišti</form>
   <lemma>hřiště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m050-d1e1106-x2-368">
   <w.rf>
    <LM>w#w-d1e1106-x2-368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
