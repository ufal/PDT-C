<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_037.01.w.gz" />
  </references>
 </head>
 <s id="m037-210">
  <m id="m037-d1t287-4">
   <w.rf>
    <LM>w#w-d1t287-4</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t287-3">
   <w.rf>
    <LM>w#w-d1t287-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t287-6">
   <w.rf>
    <LM>w#w-d1t287-6</LM>
   </w.rf>
   <form>ráznější</form>
   <lemma>rázný</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m037-d1t287-7">
   <w.rf>
    <LM>w#w-d1t287-7</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t287-8">
   <w.rf>
    <LM>w#w-d1t287-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m037-210-219">
   <w.rf>
    <LM>w#w-210-219</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-220">
  <m id="m037-d1t289-2">
   <w.rf>
    <LM>w#w-d1t289-2</LM>
   </w.rf>
   <form>Vyskočila</form>
   <lemma>vyskočit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m037-d1t291-4">
   <w.rf>
    <LM>w#w-d1t291-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t291-5">
   <w.rf>
    <LM>w#w-d1t291-5</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m037-220-221">
   <w.rf>
    <LM>w#w-220-221</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-220-222">
   <w.rf>
    <LM>w#w-220-222</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t291-7">
   <w.rf>
    <LM>w#w-d1t291-7</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-220-223">
   <w.rf>
    <LM>w#w-220-223</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t291-10">
   <w.rf>
    <LM>w#w-d1t291-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t291-11">
   <w.rf>
    <LM>w#w-d1t291-11</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t291-12">
   <w.rf>
    <LM>w#w-d1t291-12</LM>
   </w.rf>
   <form>vzdálené</form>
   <lemma>vzdálený_^(*3it)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m037-d1t291-13">
   <w.rf>
    <LM>w#w-d1t291-13</LM>
   </w.rf>
   <form>příbuzné</form>
   <lemma>příbuzná-1_^(*3ý-1)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e273-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e273-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-220-224">
   <w.rf>
    <LM>w#w-220-224</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-225">
  <m id="m037-d1t289-3">
   <w.rf>
    <LM>w#w-d1t289-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m037-225-154">
   <w.rf>
    <LM>w#w-225-154</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m037-d1t289-4">
   <w.rf>
    <LM>w#w-d1t289-4</LM>
   </w.rf>
   <form>mlčela</form>
   <lemma>mlčet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-225-226">
   <w.rf>
    <LM>w#w-225-226</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e292-x2">
  <m id="m037-d1t299-1">
   <w.rf>
    <LM>w#w-d1t299-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t299-2">
   <w.rf>
    <LM>w#w-d1t299-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t299-3">
   <w.rf>
    <LM>w#w-d1t299-3</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m037-d1t299-4">
   <w.rf>
    <LM>w#w-d1t299-4</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e292-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e292-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e307-x2">
  <m id="m037-d1t310-3">
   <w.rf>
    <LM>w#w-d1t310-3</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t310-2">
   <w.rf>
    <LM>w#w-d1t310-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t310-4">
   <w.rf>
    <LM>w#w-d1t310-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m037-d1t310-5">
   <w.rf>
    <LM>w#w-d1t310-5</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m037-d1t310-6">
   <w.rf>
    <LM>w#w-d1t310-6</LM>
   </w.rf>
   <form>vdávala</form>
   <lemma>vdávat_^(*3t)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1e307-x2-235">
   <w.rf>
    <LM>w#w-d1e307-x2-235</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-236">
  <m id="m037-d1t312-3">
   <w.rf>
    <LM>w#w-d1t312-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t312-4">
   <w.rf>
    <LM>w#w-d1t312-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t314-1">
   <w.rf>
    <LM>w#w-d1t314-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t312-2">
   <w.rf>
    <LM>w#w-d1t312-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t314-2">
   <w.rf>
    <LM>w#w-d1t314-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t314-3">
   <w.rf>
    <LM>w#w-d1t314-3</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m037-d1t314-4">
   <w.rf>
    <LM>w#w-d1t314-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t314-5">
   <w.rf>
    <LM>w#w-d1t314-5</LM>
   </w.rf>
   <form>důchodkyně</form>
   <lemma>důchodkyně_^(*4ce)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m037-d-id65076-punct">
   <w.rf>
    <LM>w#w-d-id65076-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t314-10">
   <w.rf>
    <LM>w#w-d1t314-10</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m037-d1t314-8">
   <w.rf>
    <LM>w#w-d1t314-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t314-9">
   <w.rf>
    <LM>w#w-d1t314-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t314-11">
   <w.rf>
    <LM>w#w-d1t314-11</LM>
   </w.rf>
   <form>scházely</form>
   <lemma>scházet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-236-237">
   <w.rf>
    <LM>w#w-236-237</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-238">
  <m id="m037-d1t316-2">
   <w.rf>
    <LM>w#w-d1t316-2</LM>
   </w.rf>
   <form>Bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t316-3">
   <w.rf>
    <LM>w#w-d1t316-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t316-5">
   <w.rf>
    <LM>w#w-d1t316-5</LM>
   </w.rf>
   <form>Blovicích</form>
   <lemma>Blovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m037-238-239">
   <w.rf>
    <LM>w#w-238-239</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-240">
  <m id="m037-d1t318-5">
   <w.rf>
    <LM>w#w-d1t318-5</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t318-4">
   <w.rf>
    <LM>w#w-d1t318-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t318-6">
   <w.rf>
    <LM>w#w-d1t318-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t318-7">
   <w.rf>
    <LM>w#w-d1t318-7</LM>
   </w.rf>
   <form>setkaly</form>
   <lemma>setkat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m037-d1t318-8">
   <w.rf>
    <LM>w#w-d1t318-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t318-9">
   <w.rf>
    <LM>w#w-d1t318-9</LM>
   </w.rf>
   <form>popovídaly</form>
   <lemma>popovídat</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m037-d1t318-10">
   <w.rf>
    <LM>w#w-d1t318-10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t318-11">
   <w.rf>
    <LM>w#w-d1t318-11</LM>
   </w.rf>
   <form>rodinných</form>
   <lemma>rodinný</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m037-d1t318-12">
   <w.rf>
    <LM>w#w-d1t318-12</LM>
   </w.rf>
   <form>starostech</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m037-d-id65449-punct">
   <w.rf>
    <LM>w#w-d-id65449-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t318-14">
   <w.rf>
    <LM>w#w-d1t318-14</LM>
   </w.rf>
   <form>radostech</form>
   <lemma>radost</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m037-d1t321-1">
   <w.rf>
    <LM>w#w-d1t321-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t321-2">
   <w.rf>
    <LM>w#w-d1t321-2</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t321-3">
   <w.rf>
    <LM>w#w-d1t321-3</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m037-d-m-d1e307-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e307-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e324-x2">
  <m id="m037-d1t333-1">
   <w.rf>
    <LM>w#w-d1t333-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t333-2">
   <w.rf>
    <LM>w#w-d1t333-2</LM>
   </w.rf>
   <form>mládí</form>
   <lemma>mládí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m037-d1t333-3">
   <w.rf>
    <LM>w#w-d1t333-3</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t333-4">
   <w.rf>
    <LM>w#w-d1t333-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t333-5">
   <w.rf>
    <LM>w#w-d1t333-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t333-7">
   <w.rf>
    <LM>w#w-d1t333-7</LM>
   </w.rf>
   <form>Mileči</form>
   <lemma>Mileč_;G</lemma>
   <tag>NNFS6-----A---1</tag>
  </m>
  <m id="m037-d-id65752-punct">
   <w.rf>
    <LM>w#w-d-id65752-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e334-x2">
  <m id="m037-d1t339-5">
   <w.rf>
    <LM>w#w-d1t339-5</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1e334-x2-262">
   <w.rf>
    <LM>w#w-d1e334-x2-262</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t339-8">
   <w.rf>
    <LM>w#w-d1t339-8</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m037-d1t339-10">
   <w.rf>
    <LM>w#w-d1t339-10</LM>
   </w.rf>
   <form>Vrčeni</form>
   <lemma>Vrčeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d1e334-x2-2112">
   <w.rf>
    <LM>w#w-d1e334-x2-2112</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t341-3">
   <w.rf>
    <LM>w#w-d1t341-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t341-4">
   <w.rf>
    <LM>w#w-d1t341-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t341-5">
   <w.rf>
    <LM>w#w-d1t341-5</LM>
   </w.rf>
   <form>druhou</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS4----------</tag>
  </m>
  <m id="m037-d1t341-6">
   <w.rf>
    <LM>w#w-d1t341-6</LM>
   </w.rf>
   <form>stranu</form>
   <lemma>strana</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d1t341-8">
   <w.rf>
    <LM>w#w-d1t341-8</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t341-10">
   <w.rf>
    <LM>w#w-d1t341-10</LM>
   </w.rf>
   <form>Nepomuku</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m037-264-265">
   <w.rf>
    <LM>w#w-264-265</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-266">
  <m id="m037-d1t341-13">
   <w.rf>
    <LM>w#w-d1t341-13</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t341-14">
   <w.rf>
    <LM>w#w-d1t341-14</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m037-d1t341-16">
   <w.rf>
    <LM>w#w-d1t341-16</LM>
   </w.rf>
   <form>Nepomuk</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m037-d1t341-18">
   <w.rf>
    <LM>w#w-d1t341-18</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t341-19">
   <w.rf>
    <LM>w#w-d1t341-19</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t341-20">
   <w.rf>
    <LM>w#w-d1t341-20</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m037-d1t341-21">
   <w.rf>
    <LM>w#w-d1t341-21</LM>
   </w.rf>
   <form>kilometry</form>
   <lemma>kilometr</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m037-d-m-d1e334-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e334-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e356-x3">
  <m id="m037-d1t365-1">
   <w.rf>
    <LM>w#w-d1t365-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t365-2">
   <w.rf>
    <LM>w#w-d1t365-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t365-3">
   <w.rf>
    <LM>w#w-d1t365-3</LM>
   </w.rf>
   <form>jmenovali</form>
   <lemma>jmenovat</lemma>
   <tag>VpMP----R-AAB--</tag>
  </m>
  <m id="m037-d1t365-4">
   <w.rf>
    <LM>w#w-d1t365-4</LM>
   </w.rf>
   <form>vaši</form>
   <lemma>váš</lemma>
   <tag>PSMP1-P2-------</tag>
  </m>
  <m id="m037-d1t365-5">
   <w.rf>
    <LM>w#w-d1t365-5</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m037-d-id66565-punct">
   <w.rf>
    <LM>w#w-d-id66565-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e367-x2">
  <m id="m037-d1t370-4">
   <w.rf>
    <LM>w#w-d1t370-4</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m037-d1t370-5">
   <w.rf>
    <LM>w#w-d1t370-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m037-d1t370-7">
   <w.rf>
    <LM>w#w-d1t370-7</LM>
   </w.rf>
   <form>Josef</form>
   <lemma>Josef_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m037-d1t370-8">
   <w.rf>
    <LM>w#w-d1t370-8</LM>
   </w.rf>
   <form>Ceplecha</form>
   <lemma>Ceplecha_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m037-d-id66746-punct">
   <w.rf>
    <LM>w#w-d-id66746-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t370-11">
   <w.rf>
    <LM>w#w-d1t370-11</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t370-13">
   <w.rf>
    <LM>w#w-d1t370-13</LM>
   </w.rf>
   <form>Anna</form>
   <lemma>Anna_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t370-14">
   <w.rf>
    <LM>w#w-d1t370-14</LM>
   </w.rf>
   <form>Ceplechová</form>
   <lemma>Ceplechová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-id66819-punct">
   <w.rf>
    <LM>w#w-d-id66819-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t370-17">
   <w.rf>
    <LM>w#w-d1t370-17</LM>
   </w.rf>
   <form>rozená</form>
   <lemma>rozený_^(*4dit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1t370-19">
   <w.rf>
    <LM>w#w-d1t370-19</LM>
   </w.rf>
   <form>Korýtková</form>
   <lemma>Korýtková_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e367-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e367-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e371-x2">
  <m id="m037-d1t374-1">
   <w.rf>
    <LM>w#w-d1t374-1</LM>
   </w.rf>
   <form>Čím</form>
   <lemma>co-1</lemma>
   <tag>PQ--7----------</tag>
  </m>
  <m id="m037-d1t374-2">
   <w.rf>
    <LM>w#w-d1t374-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m037-d-id66961-punct">
   <w.rf>
    <LM>w#w-d-id66961-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e375-x2">
  <m id="m037-d1t378-1">
   <w.rf>
    <LM>w#w-d1t378-1</LM>
   </w.rf>
   <form>Zemědělci</form>
   <lemma>zemědělec</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m037-d-m-d1e375-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e375-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e389-x2">
  <m id="m037-d1t392-1">
   <w.rf>
    <LM>w#w-d1t392-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m037-d1t392-2">
   <w.rf>
    <LM>w#w-d1t392-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m037-d1t392-3">
   <w.rf>
    <LM>w#w-d1t392-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t392-4">
   <w.rf>
    <LM>w#w-d1t392-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m037-d1t392-5">
   <w.rf>
    <LM>w#w-d1t392-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m037-d1t392-6">
   <w.rf>
    <LM>w#w-d1t392-6</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m037-d1t392-7">
   <w.rf>
    <LM>w#w-d1t392-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m037-d-id67323-punct">
   <w.rf>
    <LM>w#w-d-id67323-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e393-x2">
  <m id="m037-d1t396-1">
   <w.rf>
    <LM>w#w-d1t396-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m037-d1t396-2">
   <w.rf>
    <LM>w#w-d1t396-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m037-d1t396-3">
   <w.rf>
    <LM>w#w-d1t396-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t396-4">
   <w.rf>
    <LM>w#w-d1t396-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t396-5">
   <w.rf>
    <LM>w#w-d1t396-5</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1e393-x2-295">
   <w.rf>
    <LM>w#w-d1e393-x2-295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t404-1">
   <w.rf>
    <LM>w#w-d1t404-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t404-2">
   <w.rf>
    <LM>w#w-d1t404-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t404-3">
   <w.rf>
    <LM>w#w-d1t404-3</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m037-d1t404-4">
   <w.rf>
    <LM>w#w-d1t404-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t404-5">
   <w.rf>
    <LM>w#w-d1t404-5</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e399-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e399-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e399-x3">
  <m id="m037-d1t408-2">
   <w.rf>
    <LM>w#w-d1t408-2</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m037-d1t408-3">
   <w.rf>
    <LM>w#w-d1t408-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t408-4">
   <w.rf>
    <LM>w#w-d1t408-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m037-d-m-d1e399-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e399-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e409-x2">
  <m id="m037-d1t414-1">
   <w.rf>
    <LM>w#w-d1t414-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m037-d1t414-2">
   <w.rf>
    <LM>w#w-d1t414-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t414-3">
   <w.rf>
    <LM>w#w-d1t414-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t414-4">
   <w.rf>
    <LM>w#w-d1t414-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t414-5">
   <w.rf>
    <LM>w#w-d1t414-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d-id67806-punct">
   <w.rf>
    <LM>w#w-d-id67806-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e421-x2">
  <m id="m037-d1t424-2">
   <w.rf>
    <LM>w#w-d1t424-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t424-1">
   <w.rf>
    <LM>w#w-d1t424-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t424-3">
   <w.rf>
    <LM>w#w-d1t424-3</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t424-4">
   <w.rf>
    <LM>w#w-d1t424-4</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t426-1">
   <w.rf>
    <LM>w#w-d1t426-1</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m037-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>kamarádek</form>
   <lemma>kamarádka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m037-d1e421-x2-313">
   <w.rf>
    <LM>w#w-d1e421-x2-313</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1e421-x2-314">
   <w.rf>
    <LM>w#w-d1e421-x2-314</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m037-d-id68028-punct">
   <w.rf>
    <LM>w#w-d-id68028-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t426-6">
   <w.rf>
    <LM>w#w-d1t426-6</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t426-7">
   <w.rf>
    <LM>w#w-d1t426-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t426-8">
   <w.rf>
    <LM>w#w-d1t426-8</LM>
   </w.rf>
   <form>končily</form>
   <lemma>končit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t426-9">
   <w.rf>
    <LM>w#w-d1t426-9</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d1t426-10">
   <w.rf>
    <LM>w#w-d1t426-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t426-12">
   <w.rf>
    <LM>w#w-d1t426-12</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d1e421-x2-315">
   <w.rf>
    <LM>w#w-d1e421-x2-315</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-316">
  <m id="m037-d1t426-21">
   <w.rf>
    <LM>w#w-d1t426-21</LM>
   </w.rf>
   <form>Daly</form>
   <lemma>dát-1</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m037-d1t426-16">
   <w.rf>
    <LM>w#w-d1t426-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t426-17">
   <w.rf>
    <LM>w#w-d1t426-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t426-18">
   <w.rf>
    <LM>w#w-d1t426-18</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t426-19">
   <w.rf>
    <LM>w#w-d1t426-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t426-20">
   <w.rf>
    <LM>w#w-d1t426-20</LM>
   </w.rf>
   <form>konci</form>
   <lemma>konec</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m037-d1t426-22">
   <w.rf>
    <LM>w#w-d1t426-22</LM>
   </w.rf>
   <form>vyfotografovat</form>
   <lemma>vyfotografovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m037-d-m-d1e421-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e421-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e429-x2">
  <m id="m037-d1t434-1">
   <w.rf>
    <LM>w#w-d1t434-1</LM>
   </w.rf>
   <form>Jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m037-d1t434-2">
   <w.rf>
    <LM>w#w-d1t434-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t436-1">
   <w.rf>
    <LM>w#w-d1t436-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t436-3">
   <w.rf>
    <LM>w#w-d1t436-3</LM>
   </w.rf>
   <form>Myslíva</form>
   <lemma>Myslív-1_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m037-d-m-d1e429-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e429-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e429-x3">
  <m id="m037-d1t438-1">
   <w.rf>
    <LM>w#w-d1t438-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t438-2">
   <w.rf>
    <LM>w#w-d1t438-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t438-3">
   <w.rf>
    <LM>w#w-d1t438-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m037-d-m-d1e429-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e429-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e440-x2">
  <m id="m037-d1t443-2">
   <w.rf>
    <LM>w#w-d1t443-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m037-d1t443-3">
   <w.rf>
    <LM>w#w-d1t443-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t443-4">
   <w.rf>
    <LM>w#w-d1t443-4</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m037-d-id68608-punct">
   <w.rf>
    <LM>w#w-d-id68608-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t445-2">
   <w.rf>
    <LM>w#w-d1t445-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1e440-x2-321">
   <w.rf>
    <LM>w#w-d1e440-x2-321</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t445-3">
   <w.rf>
    <LM>w#w-d1t445-3</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHP1-S1-------</tag>
  </m>
  <m id="m037-d1t445-5">
   <w.rf>
    <LM>w#w-d1t445-5</LM>
   </w.rf>
   <form>nejkrásnější</form>
   <lemma>krásný</lemma>
   <tag>AAIP1----3A----</tag>
  </m>
  <m id="m037-d1t445-6">
   <w.rf>
    <LM>w#w-d1t445-6</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e440-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e440-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e448-x2">
  <m id="m037-d1t451-1">
   <w.rf>
    <LM>w#w-d1t451-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t451-2">
   <w.rf>
    <LM>w#w-d1t451-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m037-d1t451-3">
   <w.rf>
    <LM>w#w-d1t451-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t451-4">
   <w.rf>
    <LM>w#w-d1t451-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d-id68836-punct">
   <w.rf>
    <LM>w#w-d-id68836-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e452-x2">
  <m id="m037-d1t455-1">
   <w.rf>
    <LM>w#w-d1t455-1</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t455-3">
   <w.rf>
    <LM>w#w-d1t455-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t455-4">
   <w.rf>
    <LM>w#w-d1t455-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m037-d1t455-5">
   <w.rf>
    <LM>w#w-d1t455-5</LM>
   </w.rf>
   <form>bílé</form>
   <lemma>bílý_;o</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m037-d1t455-6">
   <w.rf>
    <LM>w#w-d1t455-6</LM>
   </w.rf>
   <form>halence</form>
   <lemma>halenka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d-m-d1e452-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e452-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e468-x2">
  <m id="m037-d1t471-1">
   <w.rf>
    <LM>w#w-d1t471-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t471-2">
   <w.rf>
    <LM>w#w-d1t471-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t471-5">
   <w.rf>
    <LM>w#w-d1t471-5</LM>
   </w.rf>
   <form>kamarádky</form>
   <lemma>kamarádka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m037-d1t471-3">
   <w.rf>
    <LM>w#w-d1t471-3</LM>
   </w.rf>
   <form>jmenovaly</form>
   <lemma>jmenovat</lemma>
   <tag>VpTP----R-AAB--</tag>
  </m>
  <m id="m037-d-id69231-punct">
   <w.rf>
    <LM>w#w-d-id69231-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e472-x2">
  <m id="m037-d1t479-1">
   <w.rf>
    <LM>w#w-d1t479-1</LM>
   </w.rf>
   <form>Nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t479-3">
   <w.rf>
    <LM>w#w-d1t479-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t481-2">
   <w.rf>
    <LM>w#w-d1t481-2</LM>
   </w.rf>
   <form>Věra</form>
   <lemma>Věra_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t481-3">
   <w.rf>
    <LM>w#w-d1t481-3</LM>
   </w.rf>
   <form>Bláhová</form>
   <lemma>Bláhová_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t486-15">
   <w.rf>
    <LM>w#w-d1t486-15</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t486-17">
   <w.rf>
    <LM>w#w-d1t486-17</LM>
   </w.rf>
   <form>Myslíva</form>
   <lemma>Myslív-1_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m037-d1t481-5">
   <w.rf>
    <LM>w#w-d1t481-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t481-7">
   <w.rf>
    <LM>w#w-d1t481-7</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t481-10">
   <w.rf>
    <LM>w#w-d1t481-10</LM>
   </w.rf>
   <form>Věra</form>
   <lemma>Věra_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t481-11">
   <w.rf>
    <LM>w#w-d1t481-11</LM>
   </w.rf>
   <form>Blažková</form>
   <lemma>Blažková_;Y_^(*3a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t486-4">
   <w.rf>
    <LM>w#w-d1t486-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t486-6">
   <w.rf>
    <LM>w#w-d1t486-6</LM>
   </w.rf>
   <form>Horní</form>
   <lemma>horní-1_^(vrchní)</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m037-d1t486-7">
   <w.rf>
    <LM>w#w-d1t486-7</LM>
   </w.rf>
   <form>Břízy</form>
   <lemma>bříza</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m037-d1e472-x2-336">
   <w.rf>
    <LM>w#w-d1e472-x2-336</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e489-x2">
  <m id="m037-d1t496-1">
   <w.rf>
    <LM>w#w-d1t496-1</LM>
   </w.rf>
   <form>Rozdělily</form>
   <lemma>rozdělit</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m037-d1t496-2">
   <w.rf>
    <LM>w#w-d1t496-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t496-3">
   <w.rf>
    <LM>w#w-d1t496-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1e489-x2-25">
   <w.rf>
    <LM>w#w-d1e489-x2-25</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1e489-x2-26">
   <w.rf>
    <LM>w#w-d1e489-x2-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d-m-d1e489-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e489-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e489-x3">
  <m id="m037-d1t498-1">
   <w.rf>
    <LM>w#w-d1t498-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m037-d1t498-2">
   <w.rf>
    <LM>w#w-d1t498-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m037-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t498-4">
   <w.rf>
    <LM>w#w-d1t498-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m037-d-id69970-punct">
   <w.rf>
    <LM>w#w-d-id69970-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e499-x2">
  <m id="m037-d1t504-1">
   <w.rf>
    <LM>w#w-d1t504-1</LM>
   </w.rf>
   <form>Sedmnáct</form>
   <lemma>sedmnáct`17</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m037-d-m-d1e499-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e499-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e505-x3">
  <m id="m037-d1t514-1">
   <w.rf>
    <LM>w#w-d1t514-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t514-3">
   <w.rf>
    <LM>w#w-d1t514-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t514-4">
   <w.rf>
    <LM>w#w-d1t514-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m037-d1t514-5">
   <w.rf>
    <LM>w#w-d1t514-5</LM>
   </w.rf>
   <form>pravda</form>
   <lemma>pravda-1</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-id70202-punct">
   <w.rf>
    <LM>w#w-d-id70202-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t514-7">
   <w.rf>
    <LM>w#w-d1t514-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t514-10">
   <w.rf>
    <LM>w#w-d1t514-10</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t514-9">
   <w.rf>
    <LM>w#w-d1t514-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m037-d-m-d1e505-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e505-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e533-x2">
  <m id="m037-d1t536-1">
   <w.rf>
    <LM>w#w-d1t536-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t536-2">
   <w.rf>
    <LM>w#w-d1t536-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m037-d1t536-3">
   <w.rf>
    <LM>w#w-d1t536-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t536-4">
   <w.rf>
    <LM>w#w-d1t536-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>chodily</form>
   <lemma>chodit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t536-5">
   <w.rf>
    <LM>w#w-d1t536-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t536-6">
   <w.rf>
    <LM>w#w-d1t536-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m037-d-id70519-punct">
   <w.rf>
    <LM>w#w-d-id70519-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e537-x2">
  <m id="m037-d1t542-6">
   <w.rf>
    <LM>w#w-d1t542-6</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t542-5">
   <w.rf>
    <LM>w#w-d1t542-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t542-8">
   <w.rf>
    <LM>w#w-d1t542-8</LM>
   </w.rf>
   <form>správně</form>
   <lemma>správně_^(*1í)_(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m037-d1t542-4">
   <w.rf>
    <LM>w#w-d1t542-4</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m037-d1t542-9">
   <w.rf>
    <LM>w#w-d1t542-9</LM>
   </w.rf>
   <form>Odborná</form>
   <lemma>odborný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1t542-10">
   <w.rf>
    <LM>w#w-d1t542-10</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t542-11">
   <w.rf>
    <LM>w#w-d1t542-11</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t542-12">
   <w.rf>
    <LM>w#w-d1t542-12</LM>
   </w.rf>
   <form>ženská</form>
   <lemma>ženský</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m037-d1t542-13">
   <w.rf>
    <LM>w#w-d1t542-13</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m037-d-id70774-punct">
   <w.rf>
    <LM>w#w-d-id70774-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t542-16">
   <w.rf>
    <LM>w#w-d1t542-16</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t542-18">
   <w.rf>
    <LM>w#w-d1t542-18</LM>
   </w.rf>
   <form>Rodinná</form>
   <lemma>rodinný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1t542-19">
   <w.rf>
    <LM>w#w-d1t542-19</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1e537-x2-42">
   <w.rf>
    <LM>w#w-d1e537-x2-42</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-43">
  <m id="m037-d1t542-26">
   <w.rf>
    <LM>w#w-d1t542-26</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t542-24">
   <w.rf>
    <LM>w#w-d1t542-24</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t542-27">
   <w.rf>
    <LM>w#w-d1t542-27</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m037-d1t542-28">
   <w.rf>
    <LM>w#w-d1t542-28</LM>
   </w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m037-43-44">
   <w.rf>
    <LM>w#w-43-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-45">
  <m id="m037-d1t542-33">
   <w.rf>
    <LM>w#w-d1t542-33</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t542-35">
   <w.rf>
    <LM>w#w-d1t542-35</LM>
   </w.rf>
   <form>školu</form>
   <lemma>škola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d1t542-36">
   <w.rf>
    <LM>w#w-d1t542-36</LM>
   </w.rf>
   <form>zavřeli</form>
   <lemma>zavřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m037-d1t542-38">
   <w.rf>
    <LM>w#w-d1t542-38</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-45-46">
   <w.rf>
    <LM>w#w-45-46</LM>
   </w.rf>
   <form>otevřeli</form>
   <lemma>otevřít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m037-45-47">
   <w.rf>
    <LM>w#w-45-47</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t544-8">
   <w.rf>
    <LM>w#w-d1t544-8</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m037-45-50">
   <w.rf>
    <LM>w#w-45-50</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t544-3">
   <w.rf>
    <LM>w#w-d1t544-3</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t544-4">
   <w.rf>
    <LM>w#w-d1t544-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t544-5">
   <w.rf>
    <LM>w#w-d1t544-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t544-6">
   <w.rf>
    <LM>w#w-d1t544-6</LM>
   </w.rf>
   <form>revoluci</form>
   <lemma>revoluce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d-m-d1e537-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e537-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e549-x2">
  <m id="m037-d1t552-1">
   <w.rf>
    <LM>w#w-d1t552-1</LM>
   </w.rf>
   <form>Měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t552-2">
   <w.rf>
    <LM>w#w-d1t552-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m037-d1t552-3">
   <w.rf>
    <LM>w#w-d1t552-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m037-d1t552-4">
   <w.rf>
    <LM>w#w-d1t552-4</LM>
   </w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d1t552-5">
   <w.rf>
    <LM>w#w-d1t552-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1t552-6">
   <w.rf>
    <LM>w#w-d1t552-6</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m037-d-id71424-punct">
   <w.rf>
    <LM>w#w-d-id71424-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e553-x2">
  <m id="m037-d1t556-1">
   <w.rf>
    <LM>w#w-d1t556-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m037-d1e553-x2-2127">
   <w.rf>
    <LM>w#w-d1e553-x2-2127</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t556-2">
   <w.rf>
    <LM>w#w-d1t556-2</LM>
   </w.rf>
   <form>neměly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m037-d-id71516-punct">
   <w.rf>
    <LM>w#w-d-id71516-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t556-4">
   <w.rf>
    <LM>w#w-d1t556-4</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m037-d1t556-5">
   <w.rf>
    <LM>w#w-d1t556-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m037-d1t556-6">
   <w.rf>
    <LM>w#w-d1t556-6</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t556-7">
   <w.rf>
    <LM>w#w-d1t556-7</LM>
   </w.rf>
   <form>dívky</form>
   <lemma>dívka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e553-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e553-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e567-x2">
  <m id="m037-d1t572-1">
   <w.rf>
    <LM>w#w-d1t572-1</LM>
   </w.rf>
   <form>Chlapci</form>
   <lemma>chlapec</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m037-d1t572-3">
   <w.rf>
    <LM>w#w-d1t572-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t572-4">
   <w.rf>
    <LM>w#w-d1t572-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m037-d1t572-5">
   <w.rf>
    <LM>w#w-d1t572-5</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t572-6">
   <w.rf>
    <LM>w#w-d1t572-6</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m037-d1t572-7">
   <w.rf>
    <LM>w#w-d1t572-7</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m037-d1t572-8">
   <w.rf>
    <LM>w#w-d1t572-8</LM>
   </w.rf>
   <form>školou</form>
   <lemma>škola</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m037-d-m-d1e567-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e567-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e592-x2">
  <m id="m037-d1t595-1">
   <w.rf>
    <LM>w#w-d1t595-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m037-d1t595-2">
   <w.rf>
    <LM>w#w-d1t595-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m037-d1t595-3">
   <w.rf>
    <LM>w#w-d1t595-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t595-4">
   <w.rf>
    <LM>w#w-d1t595-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m037-d1t595-5">
   <w.rf>
    <LM>w#w-d1t595-5</LM>
   </w.rf>
   <form>historku</form>
   <lemma>historka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m037-d1t595-6">
   <w.rf>
    <LM>w#w-d1t595-6</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m037-d1t595-7">
   <w.rf>
    <LM>w#w-d1t595-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m037-d-id72111-punct">
   <w.rf>
    <LM>w#w-d-id72111-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e596-x2">
  <m id="m037-d1t601-6">
   <w.rf>
    <LM>w#w-d1t601-6</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m037-d1t601-7">
   <w.rf>
    <LM>w#w-d1t601-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m037-d1t601-8">
   <w.rf>
    <LM>w#w-d1t601-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t601-9">
   <w.rf>
    <LM>w#w-d1t601-9</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m037-d1e596-x2-69">
   <w.rf>
    <LM>w#w-d1e596-x2-69</LM>
   </w.rf>
   <form>1948</form>
   <lemma>1948</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m037-d-id72369-punct">
   <w.rf>
    <LM>w#w-d-id72369-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t605-1">
   <w.rf>
    <LM>w#w-d1t605-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m037-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>komunistická</form>
   <lemma>komunistický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1t610-1">
   <w.rf>
    <LM>w#w-d1t610-1</LM>
   </w.rf>
   <form>revoluce</form>
   <lemma>revoluce</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1e596-x2-70">
   <w.rf>
    <LM>w#w-d1e596-x2-70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-71">
  <m id="m037-d1t612-5">
   <w.rf>
    <LM>w#w-d1t612-5</LM>
   </w.rf>
   <form>Plzní</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m037-d1t612-3">
   <w.rf>
    <LM>w#w-d1t612-3</LM>
   </w.rf>
   <form>pochodovali</form>
   <lemma>pochodovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m037-d1t612-7">
   <w.rf>
    <LM>w#w-d1t612-7</LM>
   </w.rf>
   <form>komunisté</form>
   <lemma>komunista</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m037-71-72">
   <w.rf>
    <LM>w#w-71-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-73">
  <m id="m037-d1t620-2">
   <w.rf>
    <LM>w#w-d1t620-2</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t616-2">
   <w.rf>
    <LM>w#w-d1t616-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t620-1">
   <w.rf>
    <LM>w#w-d1t620-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t616-5">
   <w.rf>
    <LM>w#w-d1t616-5</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m037-d1t616-6">
   <w.rf>
    <LM>w#w-d1t616-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m037-d1t616-7">
   <w.rf>
    <LM>w#w-d1t616-7</LM>
   </w.rf>
   <form>spolužákyně</form>
   <lemma>spolužákyně</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d1t620-4">
   <w.rf>
    <LM>w#w-d1t620-4</LM>
   </w.rf>
   <form>komunistka</form>
   <lemma>komunistka_^(*2a)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-id72820-punct">
   <w.rf>
    <LM>w#w-d-id72820-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t623-2">
   <w.rf>
    <LM>w#w-d1t623-2</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t623-4">
   <w.rf>
    <LM>w#w-d1t623-4</LM>
   </w.rf>
   <form>utekla</form>
   <lemma>utéci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m037-d1t623-9">
   <w.rf>
    <LM>w#w-d1t623-9</LM>
   </w.rf>
   <form>oknem</form>
   <lemma>okno</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m037-d1t623-5">
   <w.rf>
    <LM>w#w-d1t623-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m037-d1t623-6">
   <w.rf>
    <LM>w#w-d1t623-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m037-d1t629-1">
   <w.rf>
    <LM>w#w-d1t629-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t629-2">
   <w.rf>
    <LM>w#w-d1t629-2</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t629-3">
   <w.rf>
    <LM>w#w-d1t629-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t629-4">
   <w.rf>
    <LM>w#w-d1t629-4</LM>
   </w.rf>
   <form>průvodu</form>
   <lemma>průvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m037-d-m-d1e624-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e624-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e634-x2">
  <m id="m037-d1t639-2">
   <w.rf>
    <LM>w#w-d1t639-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t639-3">
   <w.rf>
    <LM>w#w-d1t639-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m037-d1t639-4">
   <w.rf>
    <LM>w#w-d1t639-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S6--1-------</tag>
  </m>
  <m id="m037-d1t639-7">
   <w.rf>
    <LM>w#w-d1t639-7</LM>
   </w.rf>
   <form>uvízlo</form>
   <lemma>uvíznout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m037-d-m-d1e634-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e634-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e643-x3">
  <m id="m037-d1t652-2">
   <w.rf>
    <LM>w#w-d1t652-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m037-d1t652-1">
   <w.rf>
    <LM>w#w-d1t652-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t652-3">
   <w.rf>
    <LM>w#w-d1t652-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t652-4">
   <w.rf>
    <LM>w#w-d1t652-4</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-m-d1e643-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e643-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e653-x2">
  <m id="m037-d1t656-5">
   <w.rf>
    <LM>w#w-d1t656-5</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t656-6">
   <w.rf>
    <LM>w#w-d1t656-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t656-7">
   <w.rf>
    <LM>w#w-d1t656-7</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t656-8">
   <w.rf>
    <LM>w#w-d1t656-8</LM>
   </w.rf>
   <form>špatná</form>
   <lemma>špatný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1t656-9">
   <w.rf>
    <LM>w#w-d1t656-9</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m037-d-id73616-punct">
   <w.rf>
    <LM>w#w-d-id73616-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t658-1">
   <w.rf>
    <LM>w#w-d1t658-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t658-2">
   <w.rf>
    <LM>w#w-d1t658-2</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m037-d1t662-3">
   <w.rf>
    <LM>w#w-d1t662-3</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m037-d1t662-4">
   <w.rf>
    <LM>w#w-d1t662-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m037-d1t662-1">
   <w.rf>
    <LM>w#w-d1t662-1</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t662-2">
   <w.rf>
    <LM>w#w-d1t662-2</LM>
   </w.rf>
   <form>protestovala</form>
   <lemma>protestovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d-id73847-punct">
   <w.rf>
    <LM>w#w-d-id73847-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t662-6">
   <w.rf>
    <LM>w#w-d1t662-6</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m037-d1t662-8">
   <w.rf>
    <LM>w#w-d1t662-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t662-9">
   <w.rf>
    <LM>w#w-d1t662-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t662-10">
   <w.rf>
    <LM>w#w-d1t662-10</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t662-11">
   <w.rf>
    <LM>w#w-d1t662-11</LM>
   </w.rf>
   <form>vyloučená</form>
   <lemma>vyloučený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m037-d1e653-x2-95">
   <w.rf>
    <LM>w#w-d1e653-x2-95</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-96">
  <m id="m037-d1t664-1">
   <w.rf>
    <LM>w#w-d1t664-1</LM>
   </w.rf>
   <form>Tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m037-96-97">
   <w.rf>
    <LM>w#w-96-97</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t664-4">
   <w.rf>
    <LM>w#w-d1t664-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m037-d1t664-5">
   <w.rf>
    <LM>w#w-d1t664-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m037-d1t664-6">
   <w.rf>
    <LM>w#w-d1t664-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t664-7">
   <w.rf>
    <LM>w#w-d1t664-7</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m037-d1t664-8">
   <w.rf>
    <LM>w#w-d1t664-8</LM>
   </w.rf>
   <form>vzpomínala</form>
   <lemma>vzpomínat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d-id74079-punct">
   <w.rf>
    <LM>w#w-d-id74079-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t664-12">
   <w.rf>
    <LM>w#w-d1t664-12</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m037-d1t664-13">
   <w.rf>
    <LM>w#w-d1t664-13</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m037-d1t664-15">
   <w.rf>
    <LM>w#w-d1t664-15</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m037-d1t664-19">
   <w.rf>
    <LM>w#w-d1t664-19</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-96-100">
   <w.rf>
    <LM>w#w-96-100</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t664-20">
   <w.rf>
    <LM>w#w-d1t664-20</LM>
   </w.rf>
   <form>policajtů</form>
   <lemma>policajt</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m037-96-101">
   <w.rf>
    <LM>w#w-96-101</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-96-98">
   <w.rf>
    <LM>w#w-96-98</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-96-99">
   <w.rf>
    <LM>w#w-96-99</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t664-23">
   <w.rf>
    <LM>w#w-d1t664-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t664-22">
   <w.rf>
    <LM>w#w-d1t664-22</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t664-24">
   <w.rf>
    <LM>w#w-d1t664-24</LM>
   </w.rf>
   <form>říkalo</form>
   <lemma>říkat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m037-d-id74293-punct">
   <w.rf>
    <LM>w#w-d-id74293-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t667-1">
   <w.rf>
    <LM>w#w-d1t667-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t667-2">
   <w.rf>
    <LM>w#w-d1t667-2</LM>
   </w.rf>
   <form>SNB</form>
   <lemma>SNB-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m037-96-102">
   <w.rf>
    <LM>w#w-96-102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-103">
  <m id="m037-d1t669-3">
   <w.rf>
    <LM>w#w-d1t669-3</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m037-d1t669-4">
   <w.rf>
    <LM>w#w-d1t669-4</LM>
   </w.rf>
   <form>skončila</form>
   <lemma>skončit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m037-103-104">
   <w.rf>
    <LM>w#w-103-104</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m037-d1t669-7">
   <w.rf>
    <LM>w#w-d1t669-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m037-d1t669-8">
   <w.rf>
    <LM>w#w-d1t669-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t669-6">
   <w.rf>
    <LM>w#w-d1t669-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t669-9">
   <w.rf>
    <LM>w#w-d1t669-9</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d1t669-10">
   <w.rf>
    <LM>w#w-d1t669-10</LM>
   </w.rf>
   <form>nedozvěděla</form>
   <lemma>dozvědět</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m037-103-105">
   <w.rf>
    <LM>w#w-103-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-106">
  <m id="m037-d1t673-2">
   <w.rf>
    <LM>w#w-d1t673-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m037-d1t673-1">
   <w.rf>
    <LM>w#w-d1t673-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m037-d1t673-6">
   <w.rf>
    <LM>w#w-d1t673-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m037-d1t673-7">
   <w.rf>
    <LM>w#w-d1t673-7</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m037-d1t673-3">
   <w.rf>
    <LM>w#w-d1t673-3</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m037-d1t673-4">
   <w.rf>
    <LM>w#w-d1t673-4</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m037-d1t673-5">
   <w.rf>
    <LM>w#w-d1t673-5</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m037-d1t673-8">
   <w.rf>
    <LM>w#w-d1t673-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m037-d1t673-10">
   <w.rf>
    <LM>w#w-d1t673-10</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m037-106-119">
   <w.rf>
    <LM>w#w-106-119</LM>
   </w.rf>
   <form>1948</form>
   <lemma>1948</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m037-d-m-d1e653-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e653-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m037-d1e676-x3">
  <m id="m037-d1t685-1">
   <w.rf>
    <LM>w#w-d1t685-1</LM>
   </w.rf>
   <form>Stýkáte</form>
   <lemma>stýkat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m037-d1t685-2">
   <w.rf>
    <LM>w#w-d1t685-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m037-d1t685-3">
   <w.rf>
    <LM>w#w-d1t685-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m037-d1t685-4">
   <w.rf>
    <LM>w#w-d1t685-4</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m037-d1t685-5">
   <w.rf>
    <LM>w#w-d1t685-5</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m037-d-id74836-punct">
   <w.rf>
    <LM>w#w-d-id74836-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
