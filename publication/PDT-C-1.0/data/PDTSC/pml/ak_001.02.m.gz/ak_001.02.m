<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_001.02.w.gz" />
  </references>
 </head>
 <s id="m001-4475">
  <m id="m001-d1e618-x2-9251">
   <w.rf>
    <LM>w#w-d1e618-x2-9251</LM>
   </w.rf>
   <form>A</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1e618-x2-9254">
   <w.rf>
    <LM>w#w-d1e618-x2-9254</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d1t629-3">
   <w.rf>
    <LM>w#w-d1t629-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t629-4">
   <w.rf>
    <LM>w#w-d1t629-4</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t629-5">
   <w.rf>
    <LM>w#w-d1t629-5</LM>
   </w.rf>
   <form>koupání</form>
   <lemma>koupání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m001-d-id82470">
   <w.rf>
    <LM>w#w-d-id82470</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t629-7">
   <w.rf>
    <LM>w#w-d1t629-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t632-1">
   <w.rf>
    <LM>w#w-d1t632-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t632-2">
   <w.rf>
    <LM>w#w-d1t632-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t632-3">
   <w.rf>
    <LM>w#w-d1t632-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t632-4">
   <w.rf>
    <LM>w#w-d1t632-4</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m001-d1t632-5">
   <w.rf>
    <LM>w#w-d1t632-5</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m001-d-id82574">
   <w.rf>
    <LM>w#w-d-id82574</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t632-7">
   <w.rf>
    <LM>w#w-d1t632-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t632-8">
   <w.rf>
    <LM>w#w-d1t632-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t632-9">
   <w.rf>
    <LM>w#w-d1t632-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t632-10">
   <w.rf>
    <LM>w#w-d1t632-10</LM>
   </w.rf>
   <form>překrásně</form>
   <lemma>překrásně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-457-597">
   <w.rf>
    <LM>w#w-457-597</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-598">
  <m id="m001-598-9292">
   <w.rf>
    <LM>w#w-598-9292</LM>
   </w.rf>
   <form>Jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t632-12">
   <w.rf>
    <LM>w#w-d1t632-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t632-13">
   <w.rf>
    <LM>w#w-d1t632-13</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m001-d1t632-14">
   <w.rf>
    <LM>w#w-d1t632-14</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m001-d1t634-1">
   <w.rf>
    <LM>w#w-d1t634-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t634-2">
   <w.rf>
    <LM>w#w-d1t634-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t634-3">
   <w.rf>
    <LM>w#w-d1t634-3</LM>
   </w.rf>
   <form>tvoří</form>
   <lemma>tvořit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m001-d1t634-4">
   <w.rf>
    <LM>w#w-d1t634-4</LM>
   </w.rf>
   <form>zelené</form>
   <lemma>zelený_;o</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m001-d1t634-5">
   <w.rf>
    <LM>w#w-d1t634-5</LM>
   </w.rf>
   <form>sinice</form>
   <lemma>sinice</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m001-598-8808">
   <w.rf>
    <LM>w#w-598-8808</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t634-6">
   <w.rf>
    <LM>w#w-d1t634-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t634-7">
   <w.rf>
    <LM>w#w-d1t634-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t634-8">
   <w.rf>
    <LM>w#w-d1t634-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t634-11">
   <w.rf>
    <LM>w#w-d1t634-11</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t634-9">
   <w.rf>
    <LM>w#w-d1t634-9</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m001-d1t634-10">
   <w.rf>
    <LM>w#w-d1t634-10</LM>
   </w.rf>
   <form>koupat</form>
   <lemma>koupat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m001-598-608">
   <w.rf>
    <LM>w#w-598-608</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-609">
  <m id="m001-d1t636-2">
   <w.rf>
    <LM>w#w-d1t636-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t636-3">
   <w.rf>
    <LM>w#w-d1t636-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t636-5">
   <w.rf>
    <LM>w#w-d1t636-5</LM>
   </w.rf>
   <form>vada</form>
   <lemma>vada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t636-6">
   <w.rf>
    <LM>w#w-d1t636-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t636-7">
   <w.rf>
    <LM>w#w-d1t636-7</LM>
   </w.rf>
   <form>kráse</form>
   <lemma>krása</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t636-9">
   <w.rf>
    <LM>w#w-d1t636-9</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m001-d1t636-10">
   <w.rf>
    <LM>w#w-d1t636-10</LM>
   </w.rf>
   <form>hezkého</form>
   <lemma>hezký</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m001-d1t636-11">
   <w.rf>
    <LM>w#w-d1t636-11</LM>
   </w.rf>
   <form>místečka</form>
   <lemma>místečko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m001-d-id83050">
   <w.rf>
    <LM>w#w-d-id83050</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t636-13">
   <w.rf>
    <LM>w#w-d1t636-13</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t636-14">
   <w.rf>
    <LM>w#w-d1t636-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t636-15">
   <w.rf>
    <LM>w#w-d1t636-15</LM>
   </w.rf>
   <form>rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m001-d1t636-16">
   <w.rf>
    <LM>w#w-d1t636-16</LM>
   </w.rf>
   <form>jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d-id83018">
   <w.rf>
    <LM>w#w-d-id83018</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e637-x2">
  <m id="m001-d1t642-1">
   <w.rf>
    <LM>w#w-d1t642-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t642-6">
   <w.rf>
    <LM>w#w-d1t642-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t642-7">
   <w.rf>
    <LM>w#w-d1t642-7</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m001-d1t642-8">
   <w.rf>
    <LM>w#w-d1t642-8</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t642-5">
   <w.rf>
    <LM>w#w-d1t642-5</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m001-d1t642-2">
   <w.rf>
    <LM>w#w-d1t642-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t642-3">
   <w.rf>
    <LM>w#w-d1t642-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m001-d1t642-4">
   <w.rf>
    <LM>w#w-d1t642-4</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m001-d1e637-x2-22">
   <w.rf>
    <LM>w#w-d1e637-x2-22</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e637-x3">
  <m id="m001-d1t646-3">
   <w.rf>
    <LM>w#w-d1t646-3</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m001-d1e637-x3-9374">
   <w.rf>
    <LM>w#w-d1e637-x3-9374</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t646-5">
   <w.rf>
    <LM>w#w-d1t646-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m001-d1t646-6">
   <w.rf>
    <LM>w#w-d1t646-6</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m001-d1t646-8">
   <w.rf>
    <LM>w#w-d1t646-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m001-d1t646-9">
   <w.rf>
    <LM>w#w-d1t646-9</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m001-d1t646-10">
   <w.rf>
    <LM>w#w-d1t646-10</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m001-d1e637-x3-424">
   <w.rf>
    <LM>w#w-d1e637-x3-424</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-425">
  <m id="m001-d1t646-14">
   <w.rf>
    <LM>w#w-d1t646-14</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m001-d1t646-12">
   <w.rf>
    <LM>w#w-d1t646-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m001-d1t646-13">
   <w.rf>
    <LM>w#w-d1t646-13</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t646-15">
   <w.rf>
    <LM>w#w-d1t646-15</LM>
   </w.rf>
   <form>ukázat</form>
   <lemma>ukázat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m001-d1t646-17">
   <w.rf>
    <LM>w#w-d1t646-17</LM>
   </w.rf>
   <form>současný</form>
   <lemma>současný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m001-d1t646-18">
   <w.rf>
    <LM>w#w-d1t646-18</LM>
   </w.rf>
   <form>stav</form>
   <lemma>stav</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-d1e637-x3-9443">
   <w.rf>
    <LM>w#w-d1e637-x3-9443</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t654-1">
   <w.rf>
    <LM>w#w-d1t654-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t654-2">
   <w.rf>
    <LM>w#w-d1t654-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t654-3">
   <w.rf>
    <LM>w#w-d1t654-3</LM>
   </w.rf>
   <form>vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t654-4">
   <w.rf>
    <LM>w#w-d1t654-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d-id83592">
   <w.rf>
    <LM>w#w-d-id83592</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e647-x3">
  <m id="m001-d1t656-1">
   <w.rf>
    <LM>w#w-d1t656-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d1e647-x3-417">
   <w.rf>
    <LM>w#w-d1e647-x3-417</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-418">
  <m id="m001-d1t656-3">
   <w.rf>
    <LM>w#w-d1t656-3</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t656-4">
   <w.rf>
    <LM>w#w-d1t656-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t656-5">
   <w.rf>
    <LM>w#w-d1t656-5</LM>
   </w.rf>
   <form>podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m001-d1t656-6">
   <w.rf>
    <LM>w#w-d1t656-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t656-7">
   <w.rf>
    <LM>w#w-d1t656-7</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m001-d1t656-8">
   <w.rf>
    <LM>w#w-d1t656-8</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1e647-x3-104">
   <w.rf>
    <LM>w#w-d1e647-x3-104</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e657-x2">
  <m id="m001-d1t662-1">
   <w.rf>
    <LM>w#w-d1t662-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m001-d1t662-2">
   <w.rf>
    <LM>w#w-d1t662-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t662-3">
   <w.rf>
    <LM>w#w-d1t662-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t662-4">
   <w.rf>
    <LM>w#w-d1t662-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t662-5">
   <w.rf>
    <LM>w#w-d1t662-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d-id83940">
   <w.rf>
    <LM>w#w-d-id83940</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e657-x4">
  <m id="m001-d1t666-1">
   <w.rf>
    <LM>w#w-d1t666-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d-id83958">
   <w.rf>
    <LM>w#w-d-id83958</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e667-x2">
  <m id="m001-d1t670-2">
   <w.rf>
    <LM>w#w-d1t670-2</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t670-3">
   <w.rf>
    <LM>w#w-d1t670-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t670-4">
   <w.rf>
    <LM>w#w-d1t670-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m001-d1t670-5">
   <w.rf>
    <LM>w#w-d1t670-5</LM>
   </w.rf>
   <form>zájezdu</form>
   <lemma>zájezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m001-d1t670-6">
   <w.rf>
    <LM>w#w-d1t670-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t670-7">
   <w.rf>
    <LM>w#w-d1t670-7</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m001-d1t670-8">
   <w.rf>
    <LM>w#w-d1t670-8</LM>
   </w.rf>
   <form>1971</form>
   <lemma>1971</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m001-d1e667-x2-114">
   <w.rf>
    <LM>w#w-d1e667-x2-114</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t672-1">
   <w.rf>
    <LM>w#w-d1t672-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t672-2">
   <w.rf>
    <LM>w#w-d1t672-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t672-3">
   <w.rf>
    <LM>w#w-d1t672-3</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1t672-4">
   <w.rf>
    <LM>w#w-d1t672-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t672-6">
   <w.rf>
    <LM>w#w-d1t672-6</LM>
   </w.rf>
   <form>Soči</form>
   <lemma>Soči_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m001-d1e667-x2-115">
   <w.rf>
    <LM>w#w-d1e667-x2-115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t672-8">
   <w.rf>
    <LM>w#w-d1t672-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t672-9">
   <w.rf>
    <LM>w#w-d1t672-9</LM>
   </w.rf>
   <form>tehdejšího</form>
   <lemma>tehdejší</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m001-d1t672-11">
   <w.rf>
    <LM>w#w-d1t672-11</LM>
   </w.rf>
   <form>Sovětského</form>
   <lemma>sovětský</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m001-d1t672-12">
   <w.rf>
    <LM>w#w-d1t672-12</LM>
   </w.rf>
   <form>svazu</form>
   <lemma>svaz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m001-d-id84019">
   <w.rf>
    <LM>w#w-d-id84019</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e673-x2">
  <m id="m001-d1t678-1">
   <w.rf>
    <LM>w#w-d1t678-1</LM>
   </w.rf>
   <form>Dala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m001-d1t678-2">
   <w.rf>
    <LM>w#w-d1t678-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m001-d1t678-3">
   <w.rf>
    <LM>w#w-d1t678-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t678-4">
   <w.rf>
    <LM>w#w-d1t678-4</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m001-d1t678-5">
   <w.rf>
    <LM>w#w-d1t678-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t678-6">
   <w.rf>
    <LM>w#w-d1t678-6</LM>
   </w.rf>
   <form>tohohle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m001-d1t678-7">
   <w.rf>
    <LM>w#w-d1t678-7</LM>
   </w.rf>
   <form>zájezdu</form>
   <lemma>zájezd</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m001-d1e673-x2-13553">
   <w.rf>
    <LM>w#w-d1e673-x2-13553</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1e673-x2-13554">
   <w.rf>
    <LM>w#w-d1e673-x2-13554</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1e673-x2-13565">
   <w.rf>
    <LM>w#w-d1e673-x2-13565</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1e673-x2-13555">
   <w.rf>
    <LM>w#w-d1e673-x2-13555</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1e673-x2-13559">
   <w.rf>
    <LM>w#w-d1e673-x2-13559</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m001-d1e673-x2-13560">
   <w.rf>
    <LM>w#w-d1e673-x2-13560</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1e673-x2-175">
   <w.rf>
    <LM>w#w-d1e673-x2-175</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t678-17">
   <w.rf>
    <LM>w#w-d1t678-17</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t678-18">
   <w.rf>
    <LM>w#w-d1t678-18</LM>
   </w.rf>
   <form>dnešního</form>
   <lemma>dnešní</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m001-d1t678-19">
   <w.rf>
    <LM>w#w-d1t678-19</LM>
   </w.rf>
   <form>pohledu</form>
   <lemma>pohled</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m001-d1t678-16">
   <w.rf>
    <LM>w#w-d1t678-16</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1t678-21">
   <w.rf>
    <LM>w#w-d1t678-21</LM>
   </w.rf>
   <form>kdovíjak</form>
   <lemma>kdovíjak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t678-25">
   <w.rf>
    <LM>w#w-d1t678-25</LM>
   </w.rf>
   <form>atraktivní</form>
   <lemma>atraktivní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m001-d1e673-x2-252">
   <w.rf>
    <LM>w#w-d1e673-x2-252</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t682-1">
   <w.rf>
    <LM>w#w-d1t682-1</LM>
   </w.rf>
   <form>jenomže</form>
   <lemma>jenomže</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t682-3">
   <w.rf>
    <LM>w#w-d1t682-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t682-4">
   <w.rf>
    <LM>w#w-d1t682-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m001-d1t682-5">
   <w.rf>
    <LM>w#w-d1t682-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t682-8">
   <w.rf>
    <LM>w#w-d1t682-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t682-9">
   <w.rf>
    <LM>w#w-d1t682-9</LM>
   </w.rf>
   <form>nikam</form>
   <lemma>nikam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t682-10">
   <w.rf>
    <LM>w#w-d1t682-10</LM>
   </w.rf>
   <form>nesmělo</form>
   <lemma>smět</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m001-d-id84999">
   <w.rf>
    <LM>w#w-d-id84999</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t682-14">
   <w.rf>
    <LM>w#w-d1t682-14</LM>
   </w.rf>
   <form>žili</form>
   <lemma>žít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t682-15">
   <w.rf>
    <LM>w#w-d1t682-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t682-16">
   <w.rf>
    <LM>w#w-d1t682-16</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t682-17">
   <w.rf>
    <LM>w#w-d1t682-17</LM>
   </w.rf>
   <form>zadrátované</form>
   <lemma>zadrátovaný_^(*2t)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m001-d1t682-18">
   <w.rf>
    <LM>w#w-d1t682-18</LM>
   </w.rf>
   <form>zemi</form>
   <lemma>země</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1e673-x2-767">
   <w.rf>
    <LM>w#w-d1e673-x2-767</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-760">
  <m id="m001-d1e673-x2-259">
   <w.rf>
    <LM>w#w-d1e673-x2-259</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t687-3">
   <w.rf>
    <LM>w#w-d1t687-3</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t687-4">
   <w.rf>
    <LM>w#w-d1t687-4</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m001-d1t687-5">
   <w.rf>
    <LM>w#w-d1t687-5</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-d1t689-1">
   <w.rf>
    <LM>w#w-d1t689-1</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t689-3">
   <w.rf>
    <LM>w#w-d1t689-3</LM>
   </w.rf>
   <form>Kavkaz</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-d1t689-5">
   <w.rf>
    <LM>w#w-d1t689-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t689-7">
   <w.rf>
    <LM>w#w-d1t689-7</LM>
   </w.rf>
   <form>Soči</form>
   <lemma>Soči_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m001-d-id85295">
   <w.rf>
    <LM>w#w-d-id85295</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t689-10">
   <w.rf>
    <LM>w#w-d1t689-10</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t689-12">
   <w.rf>
    <LM>w#w-d1t689-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t689-13">
   <w.rf>
    <LM>w#w-d1t689-13</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d-id85359">
   <w.rf>
    <LM>w#w-d-id85359</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t691-2">
   <w.rf>
    <LM>w#w-d1t691-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t691-3">
   <w.rf>
    <LM>w#w-d1t691-3</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t691-4">
   <w.rf>
    <LM>w#w-d1t691-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m001-d1t691-5">
   <w.rf>
    <LM>w#w-d1t691-5</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t691-7">
   <w.rf>
    <LM>w#w-d1t691-7</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m001-d1t691-8">
   <w.rf>
    <LM>w#w-d1t691-8</LM>
   </w.rf>
   <form>zázrak</form>
   <lemma>zázrak</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1e673-x2-262">
   <w.rf>
    <LM>w#w-d1e673-x2-262</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1091">
  <m id="m001-d1t693-5">
   <w.rf>
    <LM>w#w-d1t693-5</LM>
   </w.rf>
   <form>Nedala</form>
   <lemma>dát-1</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m001-d1t693-2">
   <w.rf>
    <LM>w#w-d1t693-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m001-d1t693-3">
   <w.rf>
    <LM>w#w-d1t693-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t693-4">
   <w.rf>
    <LM>w#w-d1t693-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t693-6">
   <w.rf>
    <LM>w#w-d1t693-6</LM>
   </w.rf>
   <form>kvůli</form>
   <lemma>kvůli</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m001-d1t693-7">
   <w.rf>
    <LM>w#w-d1t693-7</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m001-d-id85643">
   <w.rf>
    <LM>w#w-d-id85643</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t693-9">
   <w.rf>
    <LM>w#w-d1t693-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t693-10">
   <w.rf>
    <LM>w#w-d1t693-10</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m001-d1t693-11">
   <w.rf>
    <LM>w#w-d1t693-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t693-12">
   <w.rf>
    <LM>w#w-d1t693-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t693-13">
   <w.rf>
    <LM>w#w-d1t693-13</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m001-d1t693-16">
   <w.rf>
    <LM>w#w-d1t693-16</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m001-d1t693-17">
   <w.rf>
    <LM>w#w-d1t693-17</LM>
   </w.rf>
   <form>životní</form>
   <lemma>životní_^(souvisí_se_životem;_prostředí,...)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m001-d1t693-18">
   <w.rf>
    <LM>w#w-d1t693-18</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d-id85809">
   <w.rf>
    <LM>w#w-d-id85809</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t700-1">
   <w.rf>
    <LM>w#w-d1t700-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t700-2">
   <w.rf>
    <LM>w#w-d1t700-2</LM>
   </w.rf>
   <form>proto</form>
   <lemma>proto-2_^(proto_že)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d-id85873">
   <w.rf>
    <LM>w#w-d-id85873</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t700-4">
   <w.rf>
    <LM>w#w-d1t700-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t700-5">
   <w.rf>
    <LM>w#w-d1t700-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t700-6">
   <w.rf>
    <LM>w#w-d1t700-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t700-7">
   <w.rf>
    <LM>w#w-d1t700-7</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1e673-x3-322">
   <w.rf>
    <LM>w#w-d1e673-x3-322</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t700-8">
   <w.rf>
    <LM>w#w-d1t700-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t700-9">
   <w.rf>
    <LM>w#w-d1t700-9</LM>
   </w.rf>
   <form>kterém</form>
   <lemma>který</lemma>
   <tag>P4ZS6----------</tag>
  </m>
  <m id="m001-d1t700-10">
   <w.rf>
    <LM>w#w-d1t700-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m001-d1t700-11">
   <w.rf>
    <LM>w#w-d1t700-11</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m001-d1t700-12">
   <w.rf>
    <LM>w#w-d1t700-12</LM>
   </w.rf>
   <form>nejkrásnější</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m001-d1t700-13">
   <w.rf>
    <LM>w#w-d1t700-13</LM>
   </w.rf>
   <form>parta</form>
   <lemma>parta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t700-16">
   <w.rf>
    <LM>w#w-d1t700-16</LM>
   </w.rf>
   <form>přátel</form>
   <lemma>přítel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m001-d1t702-1">
   <w.rf>
    <LM>w#w-d1t702-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t702-2">
   <w.rf>
    <LM>w#w-d1t702-2</LM>
   </w.rf>
   <form>tehdejšího</form>
   <lemma>tehdejší</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m001-d1t702-3">
   <w.rf>
    <LM>w#w-d1t702-3</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m001-d1t702-4">
   <w.rf>
    <LM>w#w-d1t702-4</LM>
   </w.rf>
   <form>pracoviště</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m001-d1t702-5">
   <w.rf>
    <LM>w#w-d1t702-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t702-6">
   <w.rf>
    <LM>w#w-d1t702-6</LM>
   </w.rf>
   <form>domovech</form>
   <lemma>domov</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m001-d1t702-7">
   <w.rf>
    <LM>w#w-d1t702-7</LM>
   </w.rf>
   <form>mládeže</form>
   <lemma>mládež</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m001-d1e673-x3-323">
   <w.rf>
    <LM>w#w-d1e673-x3-323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-324">
  <m id="m001-d1t706-4">
   <w.rf>
    <LM>w#w-d1t706-4</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t706-5">
   <w.rf>
    <LM>w#w-d1t706-5</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m001-d1t706-6">
   <w.rf>
    <LM>w#w-d1t706-6</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-324-331">
   <w.rf>
    <LM>w#w-324-331</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t706-7">
   <w.rf>
    <LM>w#w-d1t706-7</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t706-8">
   <w.rf>
    <LM>w#w-d1t706-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m001-d1t706-9">
   <w.rf>
    <LM>w#w-d1t706-9</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t706-10">
   <w.rf>
    <LM>w#w-d1t706-10</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-324-333">
   <w.rf>
    <LM>w#w-324-333</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t706-11">
   <w.rf>
    <LM>w#w-d1t706-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m001-d1t706-12">
   <w.rf>
    <LM>w#w-d1t706-12</LM>
   </w.rf>
   <form>nikdy</form>
   <lemma>nikdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t706-13">
   <w.rf>
    <LM>w#w-d1t706-13</LM>
   </w.rf>
   <form>nezažila</form>
   <lemma>zažít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m001-d1t708-4">
   <w.rf>
    <LM>w#w-d1t708-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t708-5">
   <w.rf>
    <LM>w#w-d1t708-5</LM>
   </w.rf>
   <form>přátelský</form>
   <lemma>přátelský</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m001-d1t708-1">
   <w.rf>
    <LM>w#w-d1t708-1</LM>
   </w.rf>
   <form>pedagogický</form>
   <lemma>pedagogický</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m001-d1t708-2">
   <w.rf>
    <LM>w#w-d1t708-2</LM>
   </w.rf>
   <form>sbor</form>
   <lemma>sbor</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-324-334">
   <w.rf>
    <LM>w#w-324-334</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-335">
  <m id="m001-d1t708-7">
   <w.rf>
    <LM>w#w-d1t708-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t708-8">
   <w.rf>
    <LM>w#w-d1t708-8</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t708-9">
   <w.rf>
    <LM>w#w-d1t708-9</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t708-10">
   <w.rf>
    <LM>w#w-d1t708-10</LM>
   </w.rf>
   <form>přátelé</form>
   <lemma>přítel</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m001-d-id86558">
   <w.rf>
    <LM>w#w-d-id86558</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t708-12">
   <w.rf>
    <LM>w#w-d1t708-12</LM>
   </w.rf>
   <form>kteří</form>
   <lemma>který</lemma>
   <tag>P4MP1----------</tag>
  </m>
  <m id="m001-d1t708-13">
   <w.rf>
    <LM>w#w-d1t708-13</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t710-1">
   <w.rf>
    <LM>w#w-d1t710-1</LM>
   </w.rf>
   <form>ochotni</form>
   <lemma>ochotný</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m001-d1t708-14">
   <w.rf>
    <LM>w#w-d1t708-14</LM>
   </w.rf>
   <form>kdykoliv</form>
   <lemma>kdykoliv_,s_^(^DD**kdykoli)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t710-2">
   <w.rf>
    <LM>w#w-d1t710-2</LM>
   </w.rf>
   <form>pomoct</form>
   <lemma>pomoci</lemma>
   <tag>Vf--------A-P-6</tag>
  </m>
  <m id="m001-335-723">
   <w.rf>
    <LM>w#w-335-723</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t718-1">
   <w.rf>
    <LM>w#w-d1t718-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t718-2">
   <w.rf>
    <LM>w#w-d1t718-2</LM>
   </w.rf>
   <form>kterými</form>
   <lemma>který</lemma>
   <tag>P4XP7----------</tag>
  </m>
  <m id="m001-d1t720-2">
   <w.rf>
    <LM>w#w-d1t720-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t720-3">
   <w.rf>
    <LM>w#w-d1t720-3</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m001-d1t720-4">
   <w.rf>
    <LM>w#w-d1t720-4</LM>
   </w.rf>
   <form>myslet</form>
   <lemma>myslit</lemma>
   <tag>Vf--------A-I-1</tag>
  </m>
  <m id="m001-d1t720-5">
   <w.rf>
    <LM>w#w-d1t720-5</LM>
   </w.rf>
   <form>nahlas</form>
   <lemma>nahlas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-335-725">
   <w.rf>
    <LM>w#w-335-725</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t720-6">
   <w.rf>
    <LM>w#w-d1t720-6</LM>
   </w.rf>
   <form>aniž</form>
   <lemma>aniž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t720-7">
   <w.rf>
    <LM>w#w-d1t720-7</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m001-d1t720-8">
   <w.rf>
    <LM>w#w-d1t720-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t720-9">
   <w.rf>
    <LM>w#w-d1t720-9</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d1t720-10">
   <w.rf>
    <LM>w#w-d1t720-10</LM>
   </w.rf>
   <form>obával</form>
   <lemma>obávat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d-id86937">
   <w.rf>
    <LM>w#w-d-id86937</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t722-1">
   <w.rf>
    <LM>w#w-d1t722-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t722-2">
   <w.rf>
    <LM>w#w-d1t722-2</LM>
   </w.rf>
   <form>pomluví</form>
   <lemma>pomluvit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m001-d1t722-3">
   <w.rf>
    <LM>w#w-d1t722-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t722-4">
   <w.rf>
    <LM>w#w-d1t722-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t725-1">
   <w.rf>
    <LM>w#w-d1t725-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t725-2">
   <w.rf>
    <LM>w#w-d1t725-2</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m001-d1t725-3">
   <w.rf>
    <LM>w#w-d1t725-3</LM>
   </w.rf>
   <form>chovat</form>
   <lemma>chovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m001-d1t725-4">
   <w.rf>
    <LM>w#w-d1t725-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t725-5">
   <w.rf>
    <LM>w#w-d1t725-5</LM>
   </w.rf>
   <form>podrazácky</form>
   <lemma>podrazácky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d-id86703">
   <w.rf>
    <LM>w#w-d-id86703</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e711-x3">
  <m id="m001-d1t727-1">
   <w.rf>
    <LM>w#w-d1t727-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m001-d1t727-2">
   <w.rf>
    <LM>w#w-d1t727-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t727-3">
   <w.rf>
    <LM>w#w-d1t727-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t727-4">
   <w.rf>
    <LM>w#w-d1t727-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d-id87183">
   <w.rf>
    <LM>w#w-d-id87183</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e728-x2">
  <m id="m001-d1t733-1">
   <w.rf>
    <LM>w#w-d1t733-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t733-3">
   <w.rf>
    <LM>w#w-d1t733-3</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t733-5">
   <w.rf>
    <LM>w#w-d1t733-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t733-6">
   <w.rf>
    <LM>w#w-d1t733-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m001-d1t733-7">
   <w.rf>
    <LM>w#w-d1t733-7</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d1t733-8">
   <w.rf>
    <LM>w#w-d1t733-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m001-d1t733-9">
   <w.rf>
    <LM>w#w-d1t733-9</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m001-d1e728-x2-287">
   <w.rf>
    <LM>w#w-d1e728-x2-287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-280">
  <m id="m001-d1t735-2">
   <w.rf>
    <LM>w#w-d1t735-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t735-3">
   <w.rf>
    <LM>w#w-d1t735-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t735-4">
   <w.rf>
    <LM>w#w-d1t735-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t735-6">
   <w.rf>
    <LM>w#w-d1t735-6</LM>
   </w.rf>
   <form>Dagomysu</form>
   <lemma>Dagomys_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m001-d1t735-8">
   <w.rf>
    <LM>w#w-d1t735-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t735-9">
   <w.rf>
    <LM>w#w-d1t735-9</LM>
   </w.rf>
   <form>čajové</form>
   <lemma>čajový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m001-d1t735-10">
   <w.rf>
    <LM>w#w-d1t735-10</LM>
   </w.rf>
   <form>plantáži</form>
   <lemma>plantáž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-280-1368">
   <w.rf>
    <LM>w#w-280-1368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1369">
  <m id="m001-280-14449">
   <w.rf>
    <LM>w#w-280-14449</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t739-2">
   <w.rf>
    <LM>w#w-d1t739-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m001-d1t739-3">
   <w.rf>
    <LM>w#w-d1t739-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-280-14447">
   <w.rf>
    <LM>w#w-280-14447</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m001-d1t739-5">
   <w.rf>
    <LM>w#w-d1t739-5</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m001-280-291">
   <w.rf>
    <LM>w#w-280-291</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-292">
  <m id="m001-d1t742-1">
   <w.rf>
    <LM>w#w-d1t742-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m001-d1t742-2">
   <w.rf>
    <LM>w#w-d1t742-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t742-3">
   <w.rf>
    <LM>w#w-d1t742-3</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t742-5">
   <w.rf>
    <LM>w#w-d1t742-5</LM>
   </w.rf>
   <form>Kavkazem</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m001-292-1426">
   <w.rf>
    <LM>w#w-292-1426</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1427">
  <m id="m001-d1t742-7">
   <w.rf>
    <LM>w#w-d1t742-7</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDIP1----------</tag>
  </m>
  <m id="m001-d1t742-8">
   <w.rf>
    <LM>w#w-d1t742-8</LM>
   </w.rf>
   <form>keříky</form>
   <lemma>keřík</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m001-d-id87861">
   <w.rf>
    <LM>w#w-d-id87861</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t742-10">
   <w.rf>
    <LM>w#w-d1t742-10</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m001-d1t742-11">
   <w.rf>
    <LM>w#w-d1t742-11</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m001-d1t742-12">
   <w.rf>
    <LM>w#w-d1t742-12</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t742-13">
   <w.rf>
    <LM>w#w-d1t742-13</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m001-d-id87932">
   <w.rf>
    <LM>w#w-d-id87932</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t742-15">
   <w.rf>
    <LM>w#w-d1t742-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t742-16">
   <w.rf>
    <LM>w#w-d1t742-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t742-17">
   <w.rf>
    <LM>w#w-d1t742-17</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t742-18">
   <w.rf>
    <LM>w#w-d1t742-18</LM>
   </w.rf>
   <form>čaj</form>
   <lemma>čaj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-292-494">
   <w.rf>
    <LM>w#w-292-494</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t744-2">
   <w.rf>
    <LM>w#w-d1t744-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m001-d1t744-1">
   <w.rf>
    <LM>w#w-d1t744-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t744-3">
   <w.rf>
    <LM>w#w-d1t744-3</LM>
   </w.rf>
   <form>čajovníkové</form>
   <lemma>čajovníkový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m001-d1t744-4">
   <w.rf>
    <LM>w#w-d1t744-4</LM>
   </w.rf>
   <form>keře</form>
   <lemma>keř</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m001-292-496">
   <w.rf>
    <LM>w#w-292-496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-497">
  <m id="m001-d1t744-7">
   <w.rf>
    <LM>w#w-d1t744-7</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t744-8">
   <w.rf>
    <LM>w#w-d1t744-8</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m001-d1t744-9">
   <w.rf>
    <LM>w#w-d1t744-9</LM>
   </w.rf>
   <form>údolí</form>
   <lemma>údolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m001-d1t744-12">
   <w.rf>
    <LM>w#w-d1t744-12</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m001-d1t744-13">
   <w.rf>
    <LM>w#w-d1t744-13</LM>
   </w.rf>
   <form>obrovské</form>
   <lemma>obrovský</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m001-d1t746-1">
   <w.rf>
    <LM>w#w-d1t746-1</LM>
   </w.rf>
   <form>plantáže</form>
   <lemma>plantáž</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m001-d1t746-2">
   <w.rf>
    <LM>w#w-d1t746-2</LM>
   </w.rf>
   <form>čaje</form>
   <lemma>čaj</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m001-497-505">
   <w.rf>
    <LM>w#w-497-505</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-310">
  <m id="m001-d1t750-2">
   <w.rf>
    <LM>w#w-d1t750-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t750-4">
   <w.rf>
    <LM>w#w-d1t750-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m001-d1t750-5">
   <w.rf>
    <LM>w#w-d1t750-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t750-6">
   <w.rf>
    <LM>w#w-d1t750-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t750-7">
   <w.rf>
    <LM>w#w-d1t750-7</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-8">
   <w.rf>
    <LM>w#w-d1t750-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-9">
   <w.rf>
    <LM>w#w-d1t750-9</LM>
   </w.rf>
   <form>seznámíme</form>
   <lemma>seznámit</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m001-d1t750-10">
   <w.rf>
    <LM>w#w-d1t750-10</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t750-11">
   <w.rf>
    <LM>w#w-d1t750-11</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m001-d-id88422">
   <w.rf>
    <LM>w#w-d-id88422</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t750-13">
   <w.rf>
    <LM>w#w-d1t750-13</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-15">
   <w.rf>
    <LM>w#w-d1t750-15</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m001-d1t750-16">
   <w.rf>
    <LM>w#w-d1t750-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-17">
   <w.rf>
    <LM>w#w-d1t750-17</LM>
   </w.rf>
   <form>přivítali</form>
   <lemma>přivítat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-d1t750-18">
   <w.rf>
    <LM>w#w-d1t750-18</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t750-19">
   <w.rf>
    <LM>w#w-d1t750-19</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-20">
   <w.rf>
    <LM>w#w-d1t750-20</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m001-d1t750-21">
   <w.rf>
    <LM>w#w-d1t750-21</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t750-22">
   <w.rf>
    <LM>w#w-d1t750-22</LM>
   </w.rf>
   <form>pohostili</form>
   <lemma>pohostit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-310-695">
   <w.rf>
    <LM>w#w-310-695</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-688">
  <m id="m001-d1t752-10">
   <w.rf>
    <LM>w#w-d1t752-10</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t752-1">
   <w.rf>
    <LM>w#w-d1t752-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t752-2">
   <w.rf>
    <LM>w#w-d1t752-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t752-3">
   <w.rf>
    <LM>w#w-d1t752-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t752-8">
   <w.rf>
    <LM>w#w-d1t752-8</LM>
   </w.rf>
   <form>čajová</form>
   <lemma>čajový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m001-d1t752-9">
   <w.rf>
    <LM>w#w-d1t752-9</LM>
   </w.rf>
   <form>plantáž</form>
   <lemma>plantáž</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t752-4">
   <w.rf>
    <LM>w#w-d1t752-4</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t752-6">
   <w.rf>
    <LM>w#w-d1t752-6</LM>
   </w.rf>
   <form>Kavkazem</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m001-d-id88305">
   <w.rf>
    <LM>w#w-d-id88305</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e754-x2">
  <m id="m001-d1t759-1">
   <w.rf>
    <LM>w#w-d1t759-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t759-2">
   <w.rf>
    <LM>w#w-d1t759-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t759-3">
   <w.rf>
    <LM>w#w-d1t759-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m001-d1t759-4">
   <w.rf>
    <LM>w#w-d1t759-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSYS1-P2-------</tag>
  </m>
  <m id="m001-d1t759-5">
   <w.rf>
    <LM>w#w-d1t759-5</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d-id88850">
   <w.rf>
    <LM>w#w-d-id88850</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e754-x4">
  <m id="m001-d1t761-1">
   <w.rf>
    <LM>w#w-d1t761-1</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d1t761-2">
   <w.rf>
    <LM>w#w-d1t761-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t761-3">
   <w.rf>
    <LM>w#w-d1t761-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m001-d1t761-5">
   <w.rf>
    <LM>w#w-d1t761-5</LM>
   </w.rf>
   <form>Jiří</form>
   <lemma>Jiří_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d1t761-6">
   <w.rf>
    <LM>w#w-d1t761-6</LM>
   </w.rf>
   <form>Legát</form>
   <lemma>Legát_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d-id88867">
   <w.rf>
    <LM>w#w-d-id88867</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e762-x2">
  <m id="m001-d1t767-1">
   <w.rf>
    <LM>w#w-d1t767-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t767-2">
   <w.rf>
    <LM>w#w-d1t767-2</LM>
   </w.rf>
   <form>dlouhou</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m001-d1t767-3">
   <w.rf>
    <LM>w#w-d1t767-3</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1t767-4">
   <w.rf>
    <LM>w#w-d1t767-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m001-d1t767-5">
   <w.rf>
    <LM>w#w-d1t767-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t767-6">
   <w.rf>
    <LM>w#w-d1t767-6</LM>
   </w.rf>
   <form>strávili</form>
   <lemma>strávit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-d-id89112">
   <w.rf>
    <LM>w#w-d-id89112</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e762-x4">
  <m id="m001-d1t771-1">
   <w.rf>
    <LM>w#w-d1t771-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t771-2">
   <w.rf>
    <LM>w#w-d1t771-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t771-3">
   <w.rf>
    <LM>w#w-d1t771-3</LM>
   </w.rf>
   <form>dvanáctidenní</form>
   <lemma>dvanáctidenní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m001-d1t771-5">
   <w.rf>
    <LM>w#w-d1t771-5</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1e762-x4-797">
   <w.rf>
    <LM>w#w-d1e762-x4-797</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1764">
  <m id="m001-d1t773-12">
   <w.rf>
    <LM>w#w-d1t773-12</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t773-10">
   <w.rf>
    <LM>w#w-d1t773-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t773-11">
   <w.rf>
    <LM>w#w-d1t773-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t773-6">
   <w.rf>
    <LM>w#w-d1t773-6</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m001-d1t773-7">
   <w.rf>
    <LM>w#w-d1t773-7</LM>
   </w.rf>
   <form>chvilky</form>
   <lemma>chvilka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m001-d-id89130">
   <w.rf>
    <LM>w#w-d-id89130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e774-x2">
  <m id="m001-d1t781-1">
   <w.rf>
    <LM>w#w-d1t781-1</LM>
   </w.rf>
   <form>Nejen</form>
   <lemma>nejen</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t781-4">
   <w.rf>
    <LM>w#w-d1t781-4</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m001-d1e774-x2-935">
   <w.rf>
    <LM>w#w-d1e774-x2-935</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t781-18">
   <w.rf>
    <LM>w#w-d1t781-18</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t781-9">
   <w.rf>
    <LM>w#w-d1t781-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t781-11">
   <w.rf>
    <LM>w#w-d1t781-11</LM>
   </w.rf>
   <form>Kavkaz</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-d1e774-x2-936">
   <w.rf>
    <LM>w#w-d1e774-x2-936</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t781-13">
   <w.rf>
    <LM>w#w-d1t781-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t781-14">
   <w.rf>
    <LM>w#w-d1t781-14</LM>
   </w.rf>
   <form>jezero</form>
   <lemma>jezero</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m001-d1t781-16">
   <w.rf>
    <LM>w#w-d1t781-16</LM>
   </w.rf>
   <form>Rica</form>
   <lemma>Rica_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t785-1">
   <w.rf>
    <LM>w#w-d1t785-1</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t785-2">
   <w.rf>
    <LM>w#w-d1t785-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t785-3">
   <w.rf>
    <LM>w#w-d1t785-3</LM>
   </w.rf>
   <form>horu</form>
   <lemma>hora</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1t785-5">
   <w.rf>
    <LM>w#w-d1t785-5</LM>
   </w.rf>
   <form>Achun</form>
   <lemma>Achun_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1e774-x2-938">
   <w.rf>
    <LM>w#w-d1e774-x2-938</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1e774-x2-939">
   <w.rf>
    <LM>w#w-d1e774-x2-939</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1e774-x2-940">
   <w.rf>
    <LM>w#w-d1e774-x2-940</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-941">
  <m id="m001-d1t788-1">
   <w.rf>
    <LM>w#w-d1t788-1</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m001-d1t788-2">
   <w.rf>
    <LM>w#w-d1t788-2</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m001-d1t788-4">
   <w.rf>
    <LM>w#w-d1t788-4</LM>
   </w.rf>
   <form>Achunu</form>
   <lemma>Achun_;G</lemma>
   <tag>NNIS3-----A----</tag>
  </m>
  <m id="m001-d1t788-7">
   <w.rf>
    <LM>w#w-d1t788-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t788-8">
   <w.rf>
    <LM>w#w-d1t788-8</LM>
   </w.rf>
   <form>váže</form>
   <lemma>vázat</lemma>
   <tag>VB-S---3P-AAI-1</tag>
  </m>
  <m id="m001-d1t788-10">
   <w.rf>
    <LM>w#w-d1t788-10</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m001-d1t788-11">
   <w.rf>
    <LM>w#w-d1t788-11</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-941-949">
   <w.rf>
    <LM>w#w-941-949</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t788-12">
   <w.rf>
    <LM>w#w-d1t788-12</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t788-13">
   <w.rf>
    <LM>w#w-d1t788-13</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t788-14">
   <w.rf>
    <LM>w#w-d1t788-14</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m001-941-950">
   <w.rf>
    <LM>w#w-941-950</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t792-1">
   <w.rf>
    <LM>w#w-d1t792-1</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t792-2">
   <w.rf>
    <LM>w#w-d1t792-2</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m001-941-952">
   <w.rf>
    <LM>w#w-941-952</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-953">
  <m id="m001-d1t792-6">
   <w.rf>
    <LM>w#w-d1t792-6</LM>
   </w.rf>
   <form>Dozvěděli</form>
   <lemma>dozvědět</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-d1t792-7">
   <w.rf>
    <LM>w#w-d1t792-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t792-8">
   <w.rf>
    <LM>w#w-d1t792-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d-id90160">
   <w.rf>
    <LM>w#w-d-id90160</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t792-10">
   <w.rf>
    <LM>w#w-d1t792-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t792-11">
   <w.rf>
    <LM>w#w-d1t792-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t792-12">
   <w.rf>
    <LM>w#w-d1t792-12</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m001-d1t792-13">
   <w.rf>
    <LM>w#w-d1t792-13</LM>
   </w.rf>
   <form>horu</form>
   <lemma>hora</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1t792-14">
   <w.rf>
    <LM>w#w-d1t792-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t792-15">
   <w.rf>
    <LM>w#w-d1t792-15</LM>
   </w.rf>
   <form>minulosti</form>
   <lemma>minulost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d1t794-3">
   <w.rf>
    <LM>w#w-d1t794-3</LM>
   </w.rf>
   <form>vyháněli</form>
   <lemma>vyhánět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t794-4">
   <w.rf>
    <LM>w#w-d1t794-4</LM>
   </w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m001-d1t794-5">
   <w.rf>
    <LM>w#w-d1t794-5</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m001-953-961">
   <w.rf>
    <LM>w#w-953-961</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-962">
  <m id="m001-d1t794-7">
   <w.rf>
    <LM>w#w-d1t794-7</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t794-8">
   <w.rf>
    <LM>w#w-d1t794-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t794-9">
   <w.rf>
    <LM>w#w-d1t794-9</LM>
   </w.rf>
   <form>nemohl</form>
   <lemma>moci</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m001-d1t794-10">
   <w.rf>
    <LM>w#w-d1t794-10</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m001-d1t794-11">
   <w.rf>
    <LM>w#w-d1t794-11</LM>
   </w.rf>
   <form>pracovat</form>
   <lemma>pracovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m001-962-1269">
   <w.rf>
    <LM>w#w-962-1269</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t794-12">
   <w.rf>
    <LM>w#w-d1t794-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t794-13">
   <w.rf>
    <LM>w#w-d1t794-13</LM>
   </w.rf>
   <form>starý</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m001-d1t794-14">
   <w.rf>
    <LM>w#w-d1t794-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t794-15">
   <w.rf>
    <LM>w#w-d1t794-15</LM>
   </w.rf>
   <form>nemocný</form>
   <lemma>nemocný-2_^(vlastnost)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m001-d-id90506">
   <w.rf>
    <LM>w#w-d-id90506</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t796-1">
   <w.rf>
    <LM>w#w-d1t796-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t796-2">
   <w.rf>
    <LM>w#w-d1t796-2</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m001-d1t796-3">
   <w.rf>
    <LM>w#w-d1t796-3</LM>
   </w.rf>
   <form>vyhnali</form>
   <lemma>vyhnat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-d1t796-4">
   <w.rf>
    <LM>w#w-d1t796-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t796-5">
   <w.rf>
    <LM>w#w-d1t796-5</LM>
   </w.rf>
   <form>horu</form>
   <lemma>hora</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1t796-7">
   <w.rf>
    <LM>w#w-d1t796-7</LM>
   </w.rf>
   <form>Achun</form>
   <lemma>Achun_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-962-2101">
   <w.rf>
    <LM>w#w-962-2101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-2102">
  <m id="m001-962-15142">
   <w.rf>
    <LM>w#w-962-15142</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t796-11">
   <w.rf>
    <LM>w#w-d1t796-11</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m001-d1t796-12">
   <w.rf>
    <LM>w#w-d1t796-12</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m001-d1t796-13">
   <w.rf>
    <LM>w#w-d1t796-13</LM>
   </w.rf>
   <form>jakási</form>
   <lemma>jakýsi</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m001-d1t796-14">
   <w.rf>
    <LM>w#w-d1t796-14</LM>
   </w.rf>
   <form>rezervace</form>
   <lemma>rezervace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t798-1">
   <w.rf>
    <LM>w#w-d1t798-1</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t798-2">
   <w.rf>
    <LM>w#w-d1t798-2</LM>
   </w.rf>
   <form>staré</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP4----1A----</tag>
  </m>
  <m id="m001-d1t798-3">
   <w.rf>
    <LM>w#w-d1t798-3</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m001-d-id90776">
   <w.rf>
    <LM>w#w-d-id90776</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t798-5">
   <w.rf>
    <LM>w#w-d1t798-5</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t798-6">
   <w.rf>
    <LM>w#w-d1t798-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m001-d1t798-7">
   <w.rf>
    <LM>w#w-d1t798-7</LM>
   </w.rf>
   <form>nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m001-d1t798-8">
   <w.rf>
    <LM>w#w-d1t798-8</LM>
   </w.rf>
   <form>umřít</form>
   <lemma>umřít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m001-962-1274">
   <w.rf>
    <LM>w#w-962-1274</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1222">
  <m id="m001-d1t803-3">
   <w.rf>
    <LM>w#w-d1t803-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t803-9">
   <w.rf>
    <LM>w#w-d1t803-9</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m001-d1t803-10">
   <w.rf>
    <LM>w#w-d1t803-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t803-4">
   <w.rf>
    <LM>w#w-d1t803-4</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m001-d1t803-5">
   <w.rf>
    <LM>w#w-d1t803-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t803-7">
   <w.rf>
    <LM>w#w-d1t803-7</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m001-d1t805-1">
   <w.rf>
    <LM>w#w-d1t805-1</LM>
   </w.rf>
   <form>tajně</form>
   <lemma>tajně-1_^(*3ý-1)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d1t805-2">
   <w.rf>
    <LM>w#w-d1t805-2</LM>
   </w.rf>
   <form>pašoval</form>
   <lemma>pašovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t803-8">
   <w.rf>
    <LM>w#w-d1t803-8</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t805-3">
   <w.rf>
    <LM>w#w-d1t805-3</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m001-d1t805-4">
   <w.rf>
    <LM>w#w-d1t805-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t805-5">
   <w.rf>
    <LM>w#w-d1t805-5</LM>
   </w.rf>
   <form>přišlo</form>
   <lemma>přijít</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m001-d1t805-6">
   <w.rf>
    <LM>w#w-d1t805-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t805-7">
   <w.rf>
    <LM>w#w-d1t805-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t805-8">
   <w.rf>
    <LM>w#w-d1t805-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m001-d-id91138">
   <w.rf>
    <LM>w#w-d-id91138</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t805-10">
   <w.rf>
    <LM>w#w-d1t805-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t805-11">
   <w.rf>
    <LM>w#w-d1t805-11</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t805-12">
   <w.rf>
    <LM>w#w-d1t805-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m001-d1t805-13">
   <w.rf>
    <LM>w#w-d1t805-13</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m001-d1t805-14">
   <w.rf>
    <LM>w#w-d1t805-14</LM>
   </w.rf>
   <form>tvrdé</form>
   <lemma>tvrdý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m001-d1t805-15">
   <w.rf>
    <LM>w#w-d1t805-15</LM>
   </w.rf>
   <form>tresty</form>
   <lemma>trest</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m001-1222-1279">
   <w.rf>
    <LM>w#w-1222-1279</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-1280">
  <m id="m001-d1t809-4">
   <w.rf>
    <LM>w#w-d1t809-4</LM>
   </w.rf>
   <form>Říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t809-2">
   <w.rf>
    <LM>w#w-d1t809-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t809-3">
   <w.rf>
    <LM>w#w-d1t809-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m001-d-id91312">
   <w.rf>
    <LM>w#w-d-id91312</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t809-6">
   <w.rf>
    <LM>w#w-d1t809-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t809-7">
   <w.rf>
    <LM>w#w-d1t809-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t809-8">
   <w.rf>
    <LM>w#w-d1t809-8</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t809-9">
   <w.rf>
    <LM>w#w-d1t809-9</LM>
   </w.rf>
   <form>neodpovídá</form>
   <lemma>odpovídat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m001-d1t809-10">
   <w.rf>
    <LM>w#w-d1t809-10</LM>
   </w.rf>
   <form>slovanské</form>
   <lemma>slovanský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m001-d-id91399">
   <w.rf>
    <LM>w#w-d-id91399</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t809-12">
   <w.rf>
    <LM>w#w-d1t809-12</LM>
   </w.rf>
   <form>ruské</form>
   <lemma>ruský</lemma>
   <tag>AAFS3----1A----</tag>
  </m>
  <m id="m001-d1t811-1">
   <w.rf>
    <LM>w#w-d1t811-1</LM>
   </w.rf>
   <form>povaze</form>
   <lemma>povaha</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m001-d-id91447">
   <w.rf>
    <LM>w#w-d-id91447</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t811-3">
   <w.rf>
    <LM>w#w-d1t811-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m001-d1t811-5">
   <w.rf>
    <LM>w#w-d1t811-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t811-4">
   <w.rf>
    <LM>w#w-d1t811-4</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t811-6">
   <w.rf>
    <LM>w#w-d1t811-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t811-7">
   <w.rf>
    <LM>w#w-d1t811-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t811-8">
   <w.rf>
    <LM>w#w-d1t811-8</LM>
   </w.rf>
   <form>Asie</form>
   <lemma>Asie_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d-id91549">
   <w.rf>
    <LM>w#w-d-id91549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t811-11">
   <w.rf>
    <LM>w#w-d1t811-11</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t811-12">
   <w.rf>
    <LM>w#w-d1t811-12</LM>
   </w.rf>
   <form>jednání</form>
   <lemma>jednání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-1280-1288">
   <w.rf>
    <LM>w#w-1280-1288</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e774-x4">
  <m id="m001-d1t816-3">
   <w.rf>
    <LM>w#w-d1t816-3</LM>
   </w.rf>
   <form>Jezero</form>
   <lemma>jezero</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-d1t816-5">
   <w.rf>
    <LM>w#w-d1t816-5</LM>
   </w.rf>
   <form>Rica</form>
   <lemma>Rica_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t816-7">
   <w.rf>
    <LM>w#w-d1t816-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t816-11">
   <w.rf>
    <LM>w#w-d1t816-11</LM>
   </w.rf>
   <form>vysokohorské</form>
   <lemma>vysokohorský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d-id91751">
   <w.rf>
    <LM>w#w-d-id91751</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t816-14">
   <w.rf>
    <LM>w#w-d1t816-14</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t816-20">
   <w.rf>
    <LM>w#w-d1t816-20</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t816-18">
   <w.rf>
    <LM>w#w-d1t816-18</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t816-19">
   <w.rf>
    <LM>w#w-d1t816-19</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1e774-x4-178">
   <w.rf>
    <LM>w#w-d1e774-x4-178</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-179">
  <m id="m001-d1t818-2">
   <w.rf>
    <LM>w#w-d1t818-2</LM>
   </w.rf>
   <form>Druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS1----------</tag>
  </m>
  <m id="m001-d1t818-3">
   <w.rf>
    <LM>w#w-d1t818-3</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1t818-4">
   <w.rf>
    <LM>w#w-d1t818-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m001-d1t818-5">
   <w.rf>
    <LM>w#w-d1t818-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t818-6">
   <w.rf>
    <LM>w#w-d1t818-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t818-7">
   <w.rf>
    <LM>w#w-d1t818-7</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m001-d1t818-8">
   <w.rf>
    <LM>w#w-d1t818-8</LM>
   </w.rf>
   <form>čajovou</form>
   <lemma>čajový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m001-d1t818-9">
   <w.rf>
    <LM>w#w-d1t818-9</LM>
   </w.rf>
   <form>plantáž</form>
   <lemma>plantáž</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-179-187">
   <w.rf>
    <LM>w#w-179-187</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-188">
  <m id="m001-d1t822-1">
   <w.rf>
    <LM>w#w-d1t822-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t822-2">
   <w.rf>
    <LM>w#w-d1t822-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t822-3">
   <w.rf>
    <LM>w#w-d1t822-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t822-4">
   <w.rf>
    <LM>w#w-d1t822-4</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t822-5">
   <w.rf>
    <LM>w#w-d1t822-5</LM>
   </w.rf>
   <form>rychlou</form>
   <lemma>rychlý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m001-d1t822-6">
   <w.rf>
    <LM>w#w-d1t822-6</LM>
   </w.rf>
   <form>lodí</form>
   <lemma>loď</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m001-d-id92115">
   <w.rf>
    <LM>w#w-d-id92115</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t822-8">
   <w.rf>
    <LM>w#w-d1t822-8</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS3----------</tag>
  </m>
  <m id="m001-d1t822-9">
   <w.rf>
    <LM>w#w-d1t822-9</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t822-11">
   <w.rf>
    <LM>w#w-d1t822-11</LM>
   </w.rf>
   <form>Kometa</form>
   <lemma>kometa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-188-196">
   <w.rf>
    <LM>w#w-188-196</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t822-13">
   <w.rf>
    <LM>w#w-d1t822-13</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t822-15">
   <w.rf>
    <LM>w#w-d1t822-15</LM>
   </w.rf>
   <form>Černém</form>
   <lemma>černý_;o</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m001-d1t822-16">
   <w.rf>
    <LM>w#w-d1t822-16</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m001-d1t822-18">
   <w.rf>
    <LM>w#w-d1t822-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t822-20">
   <w.rf>
    <LM>w#w-d1t822-20</LM>
   </w.rf>
   <form>Suchumi</form>
   <lemma>Suchumi_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m001-d-id92301">
   <w.rf>
    <LM>w#w-d-id92301</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t827-1">
   <w.rf>
    <LM>w#w-d1t827-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t827-2">
   <w.rf>
    <LM>w#w-d1t827-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t827-3">
   <w.rf>
    <LM>w#w-d1t827-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t827-4">
   <w.rf>
    <LM>w#w-d1t827-4</LM>
   </w.rf>
   <form>subtropické</form>
   <lemma>subtropický</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1t827-5">
   <w.rf>
    <LM>w#w-d1t827-5</LM>
   </w.rf>
   <form>rostlinstvo</form>
   <lemma>rostlinstvo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-188-2667">
   <w.rf>
    <LM>w#w-188-2667</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-2668">
  <m id="m001-d1t827-9">
   <w.rf>
    <LM>w#w-d1t827-9</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t827-8">
   <w.rf>
    <LM>w#w-d1t827-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m001-d1t827-7">
   <w.rf>
    <LM>w#w-d1t827-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t827-10">
   <w.rf>
    <LM>w#w-d1t827-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t827-11">
   <w.rf>
    <LM>w#w-d1t827-11</LM>
   </w.rf>
   <form>krásném</form>
   <lemma>krásný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m001-d1t827-12">
   <w.rf>
    <LM>w#w-d1t827-12</LM>
   </w.rf>
   <form>arboretu</form>
   <lemma>arboretum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m001-188-200">
   <w.rf>
    <LM>w#w-188-200</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-201">
  <m id="m001-d1t829-13">
   <w.rf>
    <LM>w#w-d1t829-13</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t829-8">
   <w.rf>
    <LM>w#w-d1t829-8</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1t829-6">
   <w.rf>
    <LM>w#w-d1t829-6</LM>
   </w.rf>
   <form>Gagra</form>
   <lemma>Gagra-1_;G</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d1t829-9">
   <w.rf>
    <LM>w#w-d1t829-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t829-11">
   <w.rf>
    <LM>w#w-d1t829-11</LM>
   </w.rf>
   <form>Gruzii</form>
   <lemma>Gruzie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-201-350">
   <w.rf>
    <LM>w#w-201-350</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t829-14">
   <w.rf>
    <LM>w#w-d1t829-14</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1t829-15">
   <w.rf>
    <LM>w#w-d1t829-15</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-d-id92650">
   <w.rf>
    <LM>w#w-d-id92650</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e830-x2">
  <m id="m001-d1t839-1">
   <w.rf>
    <LM>w#w-d1t839-1</LM>
   </w.rf>
   <form>Krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1t839-2">
   <w.rf>
    <LM>w#w-d1t839-2</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-d-id92891">
   <w.rf>
    <LM>w#w-d-id92891</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t839-4">
   <w.rf>
    <LM>w#w-d1t839-4</LM>
   </w.rf>
   <form>koupání</form>
   <lemma>koupání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-d1t839-5">
   <w.rf>
    <LM>w#w-d1t839-5</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1e830-x2-503">
   <w.rf>
    <LM>w#w-d1e830-x2-503</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t841-1">
   <w.rf>
    <LM>w#w-d1t841-1</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m001-d1t841-2">
   <w.rf>
    <LM>w#w-d1t841-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t841-3">
   <w.rf>
    <LM>w#w-d1t841-3</LM>
   </w.rf>
   <form>pohodě</form>
   <lemma>pohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m001-d-id92771">
   <w.rf>
    <LM>w#w-d-id92771</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e830-x3">
  <m id="m001-d1t844-1">
   <w.rf>
    <LM>w#w-d1t844-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m001-d1t844-2">
   <w.rf>
    <LM>w#w-d1t844-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t844-3">
   <w.rf>
    <LM>w#w-d1t844-3</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t844-4">
   <w.rf>
    <LM>w#w-d1t844-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m001-d1t844-5">
   <w.rf>
    <LM>w#w-d1t844-5</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m001-d1e830-x3-517">
   <w.rf>
    <LM>w#w-d1e830-x3-517</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e845-x2">
  <m id="m001-d1t852-1">
   <w.rf>
    <LM>w#w-d1t852-1</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t852-4">
   <w.rf>
    <LM>w#w-d1t852-4</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m001-d1t852-7">
   <w.rf>
    <LM>w#w-d1t852-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t852-5">
   <w.rf>
    <LM>w#w-d1t852-5</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m001-d1t852-6">
   <w.rf>
    <LM>w#w-d1t852-6</LM>
   </w.rf>
   <form>přejít</form>
   <lemma>přejít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m001-d1t852-8">
   <w.rf>
    <LM>w#w-d1t852-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t852-10">
   <w.rf>
    <LM>w#w-d1t852-10</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m001-d1t852-11">
   <w.rf>
    <LM>w#w-d1t852-11</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m001-d1e845-x2-121">
   <w.rf>
    <LM>w#w-d1e845-x2-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e853-x2">
  <m id="m001-d1t856-1">
   <w.rf>
    <LM>w#w-d1t856-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d-id93341">
   <w.rf>
    <LM>w#w-d-id93341</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-d1e857-x2">
  <m id="m001-d1t862-1">
   <w.rf>
    <LM>w#w-d1t862-1</LM>
   </w.rf>
   <form>Jo</form>
   <lemma>jo_,h</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m001-d1e857-x2-677">
   <w.rf>
    <LM>w#w-d1e857-x2-677</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t862-2">
   <w.rf>
    <LM>w#w-d1t862-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m001-d1t862-3">
   <w.rf>
    <LM>w#w-d1t862-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t862-4">
   <w.rf>
    <LM>w#w-d1t862-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t862-5">
   <w.rf>
    <LM>w#w-d1t862-5</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t862-6">
   <w.rf>
    <LM>w#w-d1t862-6</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t862-10">
   <w.rf>
    <LM>w#w-d1t862-10</LM>
   </w.rf>
   <form>čajové</form>
   <lemma>čajový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m001-d1t862-11">
   <w.rf>
    <LM>w#w-d1t862-11</LM>
   </w.rf>
   <form>plantáže</form>
   <lemma>plantáž</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m001-d1e857-x2-678">
   <w.rf>
    <LM>w#w-d1e857-x2-678</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-679">
  <m id="m001-d1t866-1">
   <w.rf>
    <LM>w#w-d1t866-1</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m001-d1t866-2">
   <w.rf>
    <LM>w#w-d1t866-2</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d-id93632">
   <w.rf>
    <LM>w#w-d-id93632</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t866-4">
   <w.rf>
    <LM>w#w-d1t866-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m001-d1t866-5">
   <w.rf>
    <LM>w#w-d1t866-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t866-6">
   <w.rf>
    <LM>w#w-d1t866-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t866-7">
   <w.rf>
    <LM>w#w-d1t866-7</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m001-d1t866-8">
   <w.rf>
    <LM>w#w-d1t866-8</LM>
   </w.rf>
   <form>rukama</form>
   <lemma>ruka</lemma>
   <tag>NNFD7-----A----</tag>
  </m>
  <m id="m001-d1t866-9">
   <w.rf>
    <LM>w#w-d1t866-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t866-10">
   <w.rf>
    <LM>w#w-d1t866-10</LM>
   </w.rf>
   <form>bok</form>
   <lemma>bok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m001-d-id93742">
   <w.rf>
    <LM>w#w-d-id93742</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t866-13">
   <w.rf>
    <LM>w#w-d1t866-13</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m001-d1t866-14">
   <w.rf>
    <LM>w#w-d1t866-14</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m001-d1t866-15">
   <w.rf>
    <LM>w#w-d1t866-15</LM>
   </w.rf>
   <form>hospodářka</form>
   <lemma>hospodářka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m001-d-id93806">
   <w.rf>
    <LM>w#w-d-id93806</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t866-17">
   <w.rf>
    <LM>w#w-d1t866-17</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m001-d1t866-18">
   <w.rf>
    <LM>w#w-d1t866-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m001-d1t866-19">
   <w.rf>
    <LM>w#w-d1t866-19</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m001-d1t866-20">
   <w.rf>
    <LM>w#w-d1t866-20</LM>
   </w.rf>
   <form>starala</form>
   <lemma>starat_^(se)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m001-d1t866-21">
   <w.rf>
    <LM>w#w-d1t866-21</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m001-d1t866-22">
   <w.rf>
    <LM>w#w-d1t866-22</LM>
   </w.rf>
   <form>finance</form>
   <lemma>finance</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m001-679-3467">
   <w.rf>
    <LM>w#w-679-3467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-3468">
  <m id="m001-d1t871-4">
   <w.rf>
    <LM>w#w-d1t871-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t871-5">
   <w.rf>
    <LM>w#w-d1t871-5</LM>
   </w.rf>
   <form>pozadí</form>
   <lemma>pozadí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m001-d1t871-8">
   <w.rf>
    <LM>w#w-d1t871-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t871-10">
   <w.rf>
    <LM>w#w-d1t871-10</LM>
   </w.rf>
   <form>Kavkaz</form>
   <lemma>Kavkaz_;G</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-d1t871-12">
   <w.rf>
    <LM>w#w-d1t871-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t871-14">
   <w.rf>
    <LM>w#w-d1t871-14</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m001-d1t871-15">
   <w.rf>
    <LM>w#w-d1t871-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m001-d1t871-17">
   <w.rf>
    <LM>w#w-d1t871-17</LM>
   </w.rf>
   <form>údolí</form>
   <lemma>údolí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m001-d1t871-21">
   <w.rf>
    <LM>w#w-d1t871-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m001-d1t871-22">
   <w.rf>
    <LM>w#w-d1t871-22</LM>
   </w.rf>
   <form>samý</form>
   <lemma>samý</lemma>
   <tag>PLYS1----------</tag>
  </m>
  <m id="m001-d1t871-23">
   <w.rf>
    <LM>w#w-d1t871-23</LM>
   </w.rf>
   <form>čaj</form>
   <lemma>čaj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m001-679-690">
   <w.rf>
    <LM>w#w-679-690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m001-691">
  <m id="m001-d1t873-1">
   <w.rf>
    <LM>w#w-d1t873-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m001-d1t873-2">
   <w.rf>
    <LM>w#w-d1t873-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t873-3">
   <w.rf>
    <LM>w#w-d1t873-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m001-d1t873-4">
   <w.rf>
    <LM>w#w-d1t873-4</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m001-d1t873-5">
   <w.rf>
    <LM>w#w-d1t873-5</LM>
   </w.rf>
   <form>rozhledy</form>
   <lemma>rozhled</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m001-691-699">
   <w.rf>
    <LM>w#w-691-699</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t873-6">
   <w.rf>
    <LM>w#w-d1t873-6</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m001-d1t873-7">
   <w.rf>
    <LM>w#w-d1t873-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t873-8">
   <w.rf>
    <LM>w#w-d1t873-8</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m001-d1t873-9">
   <w.rf>
    <LM>w#w-d1t873-9</LM>
   </w.rf>
   <form>místa</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m001-691-700">
   <w.rf>
    <LM>w#w-691-700</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m001-d1t873-10">
   <w.rf>
    <LM>w#w-d1t873-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m001-d1t873-11">
   <w.rf>
    <LM>w#w-d1t873-11</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m001-d1t873-12">
   <w.rf>
    <LM>w#w-d1t873-12</LM>
   </w.rf>
   <form>vyhlídky</form>
   <lemma>vyhlídka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m001-d-id93409">
   <w.rf>
    <LM>w#w-d-id93409</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
