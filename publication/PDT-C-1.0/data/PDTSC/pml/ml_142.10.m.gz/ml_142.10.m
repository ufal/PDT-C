<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ml_142.10.w.gz" />
  </references>
 </head>
 <s id="m142-d1e1247-x2">
  <m id="m142-d1t1250-1">
   <w.rf>
    <LM>w#w-d1t1250-1</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m142-d1t1250-2">
   <w.rf>
    <LM>w#w-d1t1250-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m142-d1t1250-3">
   <w.rf>
    <LM>w#w-d1t1250-3</LM>
   </w.rf>
   <form>končí</form>
   <lemma>končit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m142-d-id155351-punct">
   <w.rf>
    <LM>w#w-d-id155351-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m142-d1e1251-x2">
  <m id="m142-d1t1254-1">
   <w.rf>
    <LM>w#w-d1t1254-1</LM>
   </w.rf>
   <form>Velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m142-d1t1254-2">
   <w.rf>
    <LM>w#w-d1t1254-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m142-d1t1254-3">
   <w.rf>
    <LM>w#w-d1t1254-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m142-d1t1254-4">
   <w.rf>
    <LM>w#w-d1t1254-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m142-d1t1254-5">
   <w.rf>
    <LM>w#w-d1t1254-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m142-d1t1254-6">
   <w.rf>
    <LM>w#w-d1t1254-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m142-d1t1254-7">
   <w.rf>
    <LM>w#w-d1t1254-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m142-d-m-d1e1251-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1251-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m142-d1e1255-x2">
  <m id="m142-d1t1258-1">
   <w.rf>
    <LM>w#w-d1t1258-1</LM>
   </w.rf>
   <form>Mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m142-d1t1258-2">
   <w.rf>
    <LM>w#w-d1t1258-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m142-d1e1255-x2-355">
   <w.rf>
    <LM>w#w-d1e1255-x2-355</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m142-356">
  <m id="m142-d1t1258-4">
   <w.rf>
    <LM>w#w-d1t1258-4</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m142-d-m-d1e1255-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1255-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m142-d1e1259-x2">
  <m id="m142-d1t1262-1">
   <w.rf>
    <LM>w#w-d1t1262-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m142-d1t1262-2">
   <w.rf>
    <LM>w#w-d1t1262-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m142-d-m-d1e1259-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1259-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m142-d1e1263-x2">
  <m id="m142-d1t1266-1">
   <w.rf>
    <LM>w#w-d1t1266-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m142-d1t1266-2">
   <w.rf>
    <LM>w#w-d1t1266-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m142-d-m-d1e1263-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1263-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
