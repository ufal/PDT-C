<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_012.07.w.gz" />
  </references>
 </head>
 <s id="m012-397">
  <m id="m012-d1t3064-21">
   <w.rf>
    <LM>w#w-d1t3064-21</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3064-22">
   <w.rf>
    <LM>w#w-d1t3064-22</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m012-d1t3064-23">
   <w.rf>
    <LM>w#w-d1t3064-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3064-24">
   <w.rf>
    <LM>w#w-d1t3064-24</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m012-d1t3064-20">
   <w.rf>
    <LM>w#w-d1t3064-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3064-25">
   <w.rf>
    <LM>w#w-d1t3064-25</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m012-d1t3064-26">
   <w.rf>
    <LM>w#w-d1t3064-26</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m012-d-id146294">
   <w.rf>
    <LM>w#w-d-id146294</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3065-x2">
  <m id="m012-d1t3068-1">
   <w.rf>
    <LM>w#w-d1t3068-1</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3068-2">
   <w.rf>
    <LM>w#w-d1t3068-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3068-3">
   <w.rf>
    <LM>w#w-d1t3068-3</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3068-4">
   <w.rf>
    <LM>w#w-d1t3068-4</LM>
   </w.rf>
   <form>stěhoval</form>
   <lemma>stěhovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d-id146796">
   <w.rf>
    <LM>w#w-d-id146796</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3069-x2">
  <m id="m012-d1t3080-1">
   <w.rf>
    <LM>w#w-d1t3080-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3080-2">
   <w.rf>
    <LM>w#w-d1t3080-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3083-1">
   <w.rf>
    <LM>w#w-d1t3083-1</LM>
   </w.rf>
   <form>dlouhá</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-d1t3083-2">
   <w.rf>
    <LM>w#w-d1t3083-2</LM>
   </w.rf>
   <form>historie</form>
   <lemma>historie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d-id147058">
   <w.rf>
    <LM>w#w-d-id147058</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3083-6">
   <w.rf>
    <LM>w#w-d1t3083-6</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m012-d-id147107">
   <w.rf>
    <LM>w#w-d-id147107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3083-8">
   <w.rf>
    <LM>w#w-d1t3083-8</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1e3069-x2-9163">
   <w.rf>
    <LM>w#w-d1e3069-x2-9163</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1e3069-x2-9162">
   <w.rf>
    <LM>w#w-d1e3069-x2-9162</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3085-2">
   <w.rf>
    <LM>w#w-d1t3085-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1e3069-x2-9164">
   <w.rf>
    <LM>w#w-d1e3069-x2-9164</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3085-3">
   <w.rf>
    <LM>w#w-d1t3085-3</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m012-d1t3087-1">
   <w.rf>
    <LM>w#w-d1t3087-1</LM>
   </w.rf>
   <form>říkat</form>
   <lemma>říkat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d1e3069-x2-403">
   <w.rf>
    <LM>w#w-d1e3069-x2-403</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-404">
  <m id="m012-d1t3087-4">
   <w.rf>
    <LM>w#w-d1t3087-4</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m012-d1t3087-5">
   <w.rf>
    <LM>w#w-d1t3087-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m012-d1t3087-6">
   <w.rf>
    <LM>w#w-d1t3087-6</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3087-7">
   <w.rf>
    <LM>w#w-d1t3087-7</LM>
   </w.rf>
   <form>zkrátím</form>
   <lemma>zkrátit</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m012-d-id146843">
   <w.rf>
    <LM>w#w-d-id146843</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3101-x2">
  <m id="m012-d1t3108-1">
   <w.rf>
    <LM>w#w-d1t3108-1</LM>
   </w.rf>
   <form>Tchán</form>
   <lemma>tchán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1t3108-2">
   <w.rf>
    <LM>w#w-d1t3108-2</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3108-3">
   <w.rf>
    <LM>w#w-d1t3108-3</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1e3101-x2-9258">
   <w.rf>
    <LM>w#w-d1e3101-x2-9258</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3108-4">
   <w.rf>
    <LM>w#w-d1t3108-4</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m012-d1t3108-5">
   <w.rf>
    <LM>w#w-d1t3108-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3108-6">
   <w.rf>
    <LM>w#w-d1t3108-6</LM>
   </w.rf>
   <form>zvyklý</form>
   <lemma>zvyklý_^(*2nout)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m012-d1t3108-7">
   <w.rf>
    <LM>w#w-d1t3108-7</LM>
   </w.rf>
   <form>říkat</form>
   <lemma>říkat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d1t3108-9">
   <w.rf>
    <LM>w#w-d1t3108-9</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d-id147570">
   <w.rf>
    <LM>w#w-d-id147570</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3112-2">
   <w.rf>
    <LM>w#w-d1t3112-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3112-3">
   <w.rf>
    <LM>w#w-d1t3112-3</LM>
   </w.rf>
   <form>babi</form>
   <lemma>babi_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m012-d1t3115-2">
   <w.rf>
    <LM>w#w-d1t3115-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3115-3">
   <w.rf>
    <LM>w#w-d1t3115-3</LM>
   </w.rf>
   <form>rozvedli</form>
   <lemma>rozvést</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m012-d1e3101-x2-9263">
   <w.rf>
    <LM>w#w-d1e3101-x2-9263</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-9264">
  <m id="m012-d1t3119-2">
   <w.rf>
    <LM>w#w-d1t3119-2</LM>
   </w.rf>
   <form>Nynější</form>
   <lemma>nynější</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-d1t3121-1">
   <w.rf>
    <LM>w#w-d1t3121-1</LM>
   </w.rf>
   <form>dědova</form>
   <lemma>dědův_^(*2)_(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m012-d1t3119-3">
   <w.rf>
    <LM>w#w-d1t3119-3</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3123-2">
   <w.rf>
    <LM>w#w-d1t3123-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m012-d1t3123-3">
   <w.rf>
    <LM>w#w-d1t3123-3</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3123-4">
   <w.rf>
    <LM>w#w-d1t3123-4</LM>
   </w.rf>
   <form>rozvedená</form>
   <lemma>rozvedený_^(*5ést)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-9264-9272">
   <w.rf>
    <LM>w#w-9264-9272</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3123-8">
   <w.rf>
    <LM>w#w-d1t3123-8</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m012-d1t3123-7">
   <w.rf>
    <LM>w#w-d1t3123-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-9264-9274">
   <w.rf>
    <LM>w#w-9264-9274</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3123-20">
   <w.rf>
    <LM>w#w-d1t3123-20</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3123-24">
   <w.rf>
    <LM>w#w-d1t3123-24</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3123-21">
   <w.rf>
    <LM>w#w-d1t3123-21</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3123-22">
   <w.rf>
    <LM>w#w-d1t3123-22</LM>
   </w.rf>
   <form>35</form>
   <lemma>35</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m012-d1t3123-23">
   <w.rf>
    <LM>w#w-d1t3123-23</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m012-d1t3123-25">
   <w.rf>
    <LM>w#w-d1t3123-25</LM>
   </w.rf>
   <form>žijou</form>
   <lemma>žít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m012-d-id147410">
   <w.rf>
    <LM>w#w-d-id147410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3124-x2">
  <m id="m012-d1t3141-6">
   <w.rf>
    <LM>w#w-d1t3141-6</LM>
   </w.rf>
   <form>Děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1t3141-8">
   <w.rf>
    <LM>w#w-d1t3141-8</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3141-9">
   <w.rf>
    <LM>w#w-d1t3141-9</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m012-d1t3141-10">
   <w.rf>
    <LM>w#w-d1t3141-10</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m012-d1t3141-11">
   <w.rf>
    <LM>w#w-d1t3141-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3143-2">
   <w.rf>
    <LM>w#w-d1t3143-2</LM>
   </w.rf>
   <form>dědova</form>
   <lemma>dědův_^(*2)_(*2a)</lemma>
   <tag>AUFS1M---------</tag>
  </m>
  <m id="m012-d1t3143-1">
   <w.rf>
    <LM>w#w-d1t3143-1</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3147-1">
   <w.rf>
    <LM>w#w-d1t3147-1</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m012-d1t3147-2">
   <w.rf>
    <LM>w#w-d1t3147-2</LM>
   </w.rf>
   <form>kluky</form>
   <lemma>kluk</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m012-d1t3147-3">
   <w.rf>
    <LM>w#w-d1t3147-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3150-1">
   <w.rf>
    <LM>w#w-d1t3150-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3147-4">
   <w.rf>
    <LM>w#w-d1t3147-4</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3147-5">
   <w.rf>
    <LM>w#w-d1t3147-5</LM>
   </w.rf>
   <form>společnou</form>
   <lemma>společný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m012-d1t3147-6">
   <w.rf>
    <LM>w#w-d1t3147-6</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d1e3124-x2-9846">
   <w.rf>
    <LM>w#w-d1e3124-x2-9846</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3156-1">
   <w.rf>
    <LM>w#w-d1t3156-1</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m012-d1t3156-2">
   <w.rf>
    <LM>w#w-d1t3156-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3156-3">
   <w.rf>
    <LM>w#w-d1t3156-3</LM>
   </w.rf>
   <form>34</form>
   <lemma>34</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m012-d1t3156-5">
   <w.rf>
    <LM>w#w-d1t3156-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m012-d-id148736">
   <w.rf>
    <LM>w#w-d-id148736</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3161-x2">
  <m id="m012-d1t3164-1">
   <w.rf>
    <LM>w#w-d1t3164-1</LM>
   </w.rf>
   <form>Právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3166-1">
   <w.rf>
    <LM>w#w-d1t3166-1</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m012-d1t3166-2">
   <w.rf>
    <LM>w#w-d1t3166-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m012-d1t3166-3">
   <w.rf>
    <LM>w#w-d1t3166-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m012-d1t3166-6">
   <w.rf>
    <LM>w#w-d1t3166-6</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m012-d1t3166-7">
   <w.rf>
    <LM>w#w-d1t3166-7</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m012-d1t3166-8">
   <w.rf>
    <LM>w#w-d1t3166-8</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--3----------</tag>
  </m>
  <m id="m012-d-id149056">
   <w.rf>
    <LM>w#w-d-id149056</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3166-10">
   <w.rf>
    <LM>w#w-d1t3166-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3166-11">
   <w.rf>
    <LM>w#w-d1t3166-11</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m012-d1t3168-1">
   <w.rf>
    <LM>w#w-d1t3168-1</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m012-d1t3168-2">
   <w.rf>
    <LM>w#w-d1t3168-2</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m012-d1t3172-2">
   <w.rf>
    <LM>w#w-d1t3172-2</LM>
   </w.rf>
   <form>Laca</form>
   <lemma>Laco_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m012-d1e3161-x2-9853">
   <w.rf>
    <LM>w#w-d1e3161-x2-9853</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1e3161-x2-9854">
   <w.rf>
    <LM>w#w-d1e3161-x2-9854</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m012-d1t3172-4">
   <w.rf>
    <LM>w#w-d1t3172-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3172-5">
   <w.rf>
    <LM>w#w-d1t3172-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m012-d1t3172-7">
   <w.rf>
    <LM>w#w-d1t3172-7</LM>
   </w.rf>
   <form>Slovenska</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m012-d1e3161-x2-422">
   <w.rf>
    <LM>w#w-d1e3161-x2-422</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-423">
  <m id="m012-d1t3175-1">
   <w.rf>
    <LM>w#w-d1t3175-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3175-2">
   <w.rf>
    <LM>w#w-d1t3175-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3175-3">
   <w.rf>
    <LM>w#w-d1t3175-3</LM>
   </w.rf>
   <form>dohodli</form>
   <lemma>dohodnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m012-d-id149314">
   <w.rf>
    <LM>w#w-d-id149314</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3175-5">
   <w.rf>
    <LM>w#w-d1t3175-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3175-6">
   <w.rf>
    <LM>w#w-d1t3175-6</LM>
   </w.rf>
   <form>budou</form>
   <lemma>být</lemma>
   <tag>VB-P---3F-AAI--</tag>
  </m>
  <m id="m012-d1t3177-1">
   <w.rf>
    <LM>w#w-d1t3177-1</LM>
   </w.rf>
   <form>bydlet</form>
   <lemma>bydlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d1t3177-2">
   <w.rf>
    <LM>w#w-d1t3177-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3177-3">
   <w.rf>
    <LM>w#w-d1t3177-3</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m012-d1t3177-4">
   <w.rf>
    <LM>w#w-d1t3177-4</LM>
   </w.rf>
   <form>cesty</form>
   <lemma>cesta</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m012-d-id149425">
   <w.rf>
    <LM>w#w-d-id149425</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3183-4">
   <w.rf>
    <LM>w#w-d1t3183-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3183-6">
   <w.rf>
    <LM>w#w-d1t3183-6</LM>
   </w.rf>
   <form>Moravě</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1e3161-x2-9855">
   <w.rf>
    <LM>w#w-d1e3161-x2-9855</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-9856">
  <m id="m012-d1t3183-9">
   <w.rf>
    <LM>w#w-d1t3183-9</LM>
   </w.rf>
   <form>Sháněli</form>
   <lemma>shánět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3183-10">
   <w.rf>
    <LM>w#w-d1t3183-10</LM>
   </w.rf>
   <form>barák</form>
   <lemma>barák</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1t3185-1">
   <w.rf>
    <LM>w#w-d1t3185-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3185-3">
   <w.rf>
    <LM>w#w-d1t3185-3</LM>
   </w.rf>
   <form>Moravě</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1t3185-5">
   <w.rf>
    <LM>w#w-d1t3185-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3185-8">
   <w.rf>
    <LM>w#w-d1t3185-8</LM>
   </w.rf>
   <form>koupili</form>
   <lemma>koupit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m012-d1t3185-7">
   <w.rf>
    <LM>w#w-d1t3185-7</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m012-d1t3185-6">
   <w.rf>
    <LM>w#w-d1t3185-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-9856-10092">
   <w.rf>
    <LM>w#w-9856-10092</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-10646">
  <m id="m012-d1t3185-15">
   <w.rf>
    <LM>w#w-d1t3185-15</LM>
   </w.rf>
   <form>Verča</form>
   <lemma>Verča_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3185-13">
   <w.rf>
    <LM>w#w-d1t3185-13</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3185-18">
   <w.rf>
    <LM>w#w-d1t3185-18</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3185-19">
   <w.rf>
    <LM>w#w-d1t3185-19</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m012-10646-10801">
   <w.rf>
    <LM>w#w-10646-10801</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3185-21">
   <w.rf>
    <LM>w#w-d1t3185-21</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3185-22">
   <w.rf>
    <LM>w#w-d1t3185-22</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3185-23">
   <w.rf>
    <LM>w#w-d1t3185-23</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3188-2">
   <w.rf>
    <LM>w#w-d1t3188-2</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-10646-436">
   <w.rf>
    <LM>w#w-10646-436</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-437">
  <m id="m012-d1t3190-1">
   <w.rf>
    <LM>w#w-d1t3190-1</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3194-1">
   <w.rf>
    <LM>w#w-d1t3194-1</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1t3196-1">
   <w.rf>
    <LM>w#w-d1t3196-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3196-3">
   <w.rf>
    <LM>w#w-d1t3196-3</LM>
   </w.rf>
   <form>Jarkou</form>
   <lemma>Jarka_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m012-d1t3196-5">
   <w.rf>
    <LM>w#w-d1t3196-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3196-6">
   <w.rf>
    <LM>w#w-d1t3196-6</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3196-7">
   <w.rf>
    <LM>w#w-d1t3196-7</LM>
   </w.rf>
   <form>přece</form>
   <lemma>přece-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3196-8">
   <w.rf>
    <LM>w#w-d1t3196-8</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3196-9">
   <w.rf>
    <LM>w#w-d1t3196-9</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMP1----2A----</tag>
  </m>
  <m id="m012-d-id150192">
   <w.rf>
    <LM>w#w-d-id150192</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3198-1">
   <w.rf>
    <LM>w#w-d1t3198-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3198-2">
   <w.rf>
    <LM>w#w-d1t3198-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3198-3">
   <w.rf>
    <LM>w#w-d1t3198-3</LM>
   </w.rf>
   <form>případě</form>
   <lemma>případ</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m012-d1t3203-1">
   <w.rf>
    <LM>w#w-d1t3203-1</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS2----------</tag>
  </m>
  <m id="m012-d1t3203-2">
   <w.rf>
    <LM>w#w-d1t3203-2</LM>
   </w.rf>
   <form>potřeby</form>
   <lemma>potřeba-1</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m012-d1t3203-3">
   <w.rf>
    <LM>w#w-d1t3203-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3203-4">
   <w.rf>
    <LM>w#w-d1t3203-4</LM>
   </w.rf>
   <form>nouze</form>
   <lemma>nouze</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m012-d1t3203-6">
   <w.rf>
    <LM>w#w-d1t3203-6</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m012-d1t3203-7">
   <w.rf>
    <LM>w#w-d1t3203-7</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3203-8">
   <w.rf>
    <LM>w#w-d1t3203-8</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m012-d1t3203-9">
   <w.rf>
    <LM>w#w-d1t3203-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3203-10">
   <w.rf>
    <LM>w#w-d1t3203-10</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1t3203-11">
   <w.rf>
    <LM>w#w-d1t3203-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3203-12">
   <w.rf>
    <LM>w#w-d1t3203-12</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m012-d1t3203-13">
   <w.rf>
    <LM>w#w-d1t3203-13</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m012-d1t3203-14">
   <w.rf>
    <LM>w#w-d1t3203-14</LM>
   </w.rf>
   <form>pomáhat</form>
   <lemma>pomáhat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d-id149942">
   <w.rf>
    <LM>w#w-d-id149942</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-10808">
  <m id="m012-d1t3213-1">
   <w.rf>
    <LM>w#w-d1t3213-1</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3213-2">
   <w.rf>
    <LM>w#w-d1t3213-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3213-3">
   <w.rf>
    <LM>w#w-d1t3213-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3213-5">
   <w.rf>
    <LM>w#w-d1t3213-5</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m012-d1t3213-6">
   <w.rf>
    <LM>w#w-d1t3213-6</LM>
   </w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m012-d1t3221-1">
   <w.rf>
    <LM>w#w-d1t3221-1</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m012-d-id150540">
   <w.rf>
    <LM>w#w-d-id150540</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-10653">
  <m id="m012-d1t3221-4">
   <w.rf>
    <LM>w#w-d1t3221-4</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3221-9">
   <w.rf>
    <LM>w#w-d1t3221-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3221-5">
   <w.rf>
    <LM>w#w-d1t3221-5</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m012-d1t3221-6">
   <w.rf>
    <LM>w#w-d1t3221-6</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m012-d1t3221-7">
   <w.rf>
    <LM>w#w-d1t3221-7</LM>
   </w.rf>
   <form>menší</form>
   <lemma>malý</lemma>
   <tag>AAIS1----2A----</tag>
  </m>
  <m id="m012-d1t3221-8">
   <w.rf>
    <LM>w#w-d1t3221-8</LM>
   </w.rf>
   <form>důvod</form>
   <lemma>důvod</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m012-d-id150847">
   <w.rf>
    <LM>w#w-d-id150847</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3221-11">
   <w.rf>
    <LM>w#w-d1t3221-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3221-14">
   <w.rf>
    <LM>w#w-d1t3221-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3221-12">
   <w.rf>
    <LM>w#w-d1t3221-12</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3221-13">
   <w.rf>
    <LM>w#w-d1t3221-13</LM>
   </w.rf>
   <form>děda</form>
   <lemma>děda</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1t3221-16">
   <w.rf>
    <LM>w#w-d1t3221-16</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3221-18">
   <w.rf>
    <LM>w#w-d1t3221-18</LM>
   </w.rf>
   <form>Moravě</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1t3221-15">
   <w.rf>
    <LM>w#w-d1t3221-15</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m012-10653-449">
   <w.rf>
    <LM>w#w-10653-449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-450">
  <m id="m012-d1t3221-22">
   <w.rf>
    <LM>w#w-d1t3221-22</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-10653-10920">
   <w.rf>
    <LM>w#w-10653-10920</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m012-d1t3223-2">
   <w.rf>
    <LM>w#w-d1t3223-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m012-d1t3223-4">
   <w.rf>
    <LM>w#w-d1t3223-4</LM>
   </w.rf>
   <form>Moravě</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m012-d1t3223-6">
   <w.rf>
    <LM>w#w-d1t3223-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3223-7">
   <w.rf>
    <LM>w#w-d1t3223-7</LM>
   </w.rf>
   <form>tíhnul</form>
   <lemma>tíhnout</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d-id151141">
   <w.rf>
    <LM>w#w-d-id151141</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3223-10">
   <w.rf>
    <LM>w#w-d1t3223-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3223-11">
   <w.rf>
    <LM>w#w-d1t3223-11</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3223-12">
   <w.rf>
    <LM>w#w-d1t3223-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3223-13">
   <w.rf>
    <LM>w#w-d1t3223-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3223-8">
   <w.rf>
    <LM>w#w-d1t3223-8</LM>
   </w.rf>
   <form>nakonec</form>
   <lemma>nakonec-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3227-2">
   <w.rf>
    <LM>w#w-d1t3227-2</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3227-3">
   <w.rf>
    <LM>w#w-d1t3227-3</LM>
   </w.rf>
   <form>rodilý</form>
   <lemma>rodilý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m012-d1t3223-15">
   <w.rf>
    <LM>w#w-d1t3223-15</LM>
   </w.rf>
   <form>Plzeňák</form>
   <lemma>Plzeňák_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d-id150699">
   <w.rf>
    <LM>w#w-d-id150699</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3228-x2">
  <m id="m012-d1t3233-1">
   <w.rf>
    <LM>w#w-d1t3233-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m012-d1t3233-2">
   <w.rf>
    <LM>w#w-d1t3233-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3233-3">
   <w.rf>
    <LM>w#w-d1t3233-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3233-4">
   <w.rf>
    <LM>w#w-d1t3233-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m012-d1t3233-5">
   <w.rf>
    <LM>w#w-d1t3233-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d-id151503">
   <w.rf>
    <LM>w#w-d-id151503</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3234-x2">
  <m id="m012-d1t3237-1">
   <w.rf>
    <LM>w#w-d1t3237-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d-id151549">
   <w.rf>
    <LM>w#w-d-id151549</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3238-x2">
  <m id="m012-d1t3243-1">
   <w.rf>
    <LM>w#w-d1t3243-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-4</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3243-2">
   <w.rf>
    <LM>w#w-d1t3243-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3243-3">
   <w.rf>
    <LM>w#w-d1t3243-3</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3243-4">
   <w.rf>
    <LM>w#w-d1t3243-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d-id151698">
   <w.rf>
    <LM>w#w-d-id151698</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3248-x2">
  <m id="m012-d1t3253-1">
   <w.rf>
    <LM>w#w-d1t3253-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m012-d1t3253-2">
   <w.rf>
    <LM>w#w-d1t3253-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3253-3">
   <w.rf>
    <LM>w#w-d1t3253-3</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3253-4">
   <w.rf>
    <LM>w#w-d1t3253-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3253-5">
   <w.rf>
    <LM>w#w-d1t3253-5</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m012-d1t3257-1">
   <w.rf>
    <LM>w#w-d1t3257-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3257-2">
   <w.rf>
    <LM>w#w-d1t3257-2</LM>
   </w.rf>
   <form>kamarády</form>
   <lemma>kamarád</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m012-d1t3259-1">
   <w.rf>
    <LM>w#w-d1t3259-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3259-2">
   <w.rf>
    <LM>w#w-d1t3259-2</LM>
   </w.rf>
   <form>dráhy</form>
   <lemma>dráha</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m012-d1e3248-x2-11116">
   <w.rf>
    <LM>w#w-d1e3248-x2-11116</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3262-3">
   <w.rf>
    <LM>w#w-d1t3262-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3262-2">
   <w.rf>
    <LM>w#w-d1t3262-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3264-1">
   <w.rf>
    <LM>w#w-d1t3264-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3264-3">
   <w.rf>
    <LM>w#w-d1t3264-3</LM>
   </w.rf>
   <form>Vydře</form>
   <lemma>Vydra-2_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1e3248-x2-11117">
   <w.rf>
    <LM>w#w-d1e3248-x2-11117</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-11118">
  <m id="m012-d1t3264-10">
   <w.rf>
    <LM>w#w-d1t3264-10</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3264-9">
   <w.rf>
    <LM>w#w-d1t3264-9</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3264-11">
   <w.rf>
    <LM>w#w-d1t3264-11</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m012-d1t3264-13">
   <w.rf>
    <LM>w#w-d1t3264-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m012-d1t3264-14">
   <w.rf>
    <LM>w#w-d1t3264-14</LM>
   </w.rf>
   <form>svými</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP7----------</tag>
  </m>
  <m id="m012-d1t3264-15">
   <w.rf>
    <LM>w#w-d1t3264-15</LM>
   </w.rf>
   <form>dcerami</form>
   <lemma>dcera</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m012-11118-11392">
   <w.rf>
    <LM>w#w-11118-11392</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3275-1">
   <w.rf>
    <LM>w#w-d1t3275-1</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3275-2">
   <w.rf>
    <LM>w#w-d1t3275-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3275-3">
   <w.rf>
    <LM>w#w-d1t3275-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3275-7">
   <w.rf>
    <LM>w#w-d1t3275-7</LM>
   </w.rf>
   <form>Lojza</form>
   <lemma>Lojza_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-11118-11395">
   <w.rf>
    <LM>w#w-11118-11395</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3275-16">
   <w.rf>
    <LM>w#w-d1t3275-16</LM>
   </w.rf>
   <form>Petra</form>
   <lemma>Petra_;G_;Y_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-11118-11396">
   <w.rf>
    <LM>w#w-11118-11396</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3275-13">
   <w.rf>
    <LM>w#w-d1t3275-13</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-11118-11397">
   <w.rf>
    <LM>w#w-11118-11397</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-11118-472">
   <w.rf>
    <LM>w#w-11118-472</LM>
   </w.rf>
   <form>třetího</form>
   <lemma>třetí</lemma>
   <tag>CrIS2----------</tag>
  </m>
  <m id="m012-11118-11398">
   <w.rf>
    <LM>w#w-11118-11398</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3277-5">
   <w.rf>
    <LM>w#w-d1t3277-5</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m012-d1t3277-10">
   <w.rf>
    <LM>w#w-d1t3277-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m012-d1t3277-11">
   <w.rf>
    <LM>w#w-d1t3277-11</LM>
   </w.rf>
   <form>fotí</form>
   <lemma>fotit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-11118-471">
   <w.rf>
    <LM>w#w-11118-471</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3279-1">
   <w.rf>
    <LM>w#w-d1t3279-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3281-2">
   <w.rf>
    <LM>w#w-d1t3281-2</LM>
   </w.rf>
   <form>jejich</form>
   <lemma>jeho</lemma>
   <tag>P9XXXXP3-------</tag>
  </m>
  <m id="m012-d1t3281-3">
   <w.rf>
    <LM>w#w-d1t3281-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m012-d-id152439">
   <w.rf>
    <LM>w#w-d-id152439</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3282-x2">
  <m id="m012-d1t3285-1">
   <w.rf>
    <LM>w#w-d1t3285-1</LM>
   </w.rf>
   <form>Z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3285-2">
   <w.rf>
    <LM>w#w-d1t3285-2</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m012-d1t3285-3">
   <w.rf>
    <LM>w#w-d1t3285-3</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m012-d1t3285-4">
   <w.rf>
    <LM>w#w-d1t3285-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3285-5">
   <w.rf>
    <LM>w#w-d1t3285-5</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m012-d1t3285-6">
   <w.rf>
    <LM>w#w-d1t3285-6</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d-id153102">
   <w.rf>
    <LM>w#w-d-id153102</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3286-x2">
  <m id="m012-d1t3289-8">
   <w.rf>
    <LM>w#w-d1t3289-8</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3289-9">
   <w.rf>
    <LM>w#w-d1t3289-9</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3291-2">
   <w.rf>
    <LM>w#w-d1t3291-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3289-10">
   <w.rf>
    <LM>w#w-d1t3289-10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3289-11">
   <w.rf>
    <LM>w#w-d1t3289-11</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1t3289-12">
   <w.rf>
    <LM>w#w-d1t3289-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3289-13">
   <w.rf>
    <LM>w#w-d1t3289-13</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m012-d1e3286-x2-11478">
   <w.rf>
    <LM>w#w-d1e3286-x2-11478</LM>
   </w.rf>
   <form>později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m012-d-id153421">
   <w.rf>
    <LM>w#w-d-id153421</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3291-4">
   <w.rf>
    <LM>w#w-d1t3291-4</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3297-6">
   <w.rf>
    <LM>w#w-d1t3297-6</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m012-d1t3297-7">
   <w.rf>
    <LM>w#w-d1t3297-7</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3297-1">
   <w.rf>
    <LM>w#w-d1t3297-1</LM>
   </w.rf>
   <form>1991</form>
   <lemma>1991</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m012-d-id153148">
   <w.rf>
    <LM>w#w-d-id153148</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3298-x2">
  <m id="m012-d1t3303-1">
   <w.rf>
    <LM>w#w-d1t3303-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3303-2">
   <w.rf>
    <LM>w#w-d1t3303-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m012-d1t3303-3">
   <w.rf>
    <LM>w#w-d1t3303-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3303-4">
   <w.rf>
    <LM>w#w-d1t3303-4</LM>
   </w.rf>
   <form>pravidelně</form>
   <lemma>pravidelně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-d-id153760">
   <w.rf>
    <LM>w#w-d-id153760</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3304-x2">
  <m id="m012-d1t3307-7">
   <w.rf>
    <LM>w#w-d1t3307-7</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1e3304-x2-11610">
   <w.rf>
    <LM>w#w-d1e3304-x2-11610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3307-8">
   <w.rf>
    <LM>w#w-d1t3307-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3307-9">
   <w.rf>
    <LM>w#w-d1t3307-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3307-11">
   <w.rf>
    <LM>w#w-d1t3307-11</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m012-d1t3309-1">
   <w.rf>
    <LM>w#w-d1t3309-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3307-10">
   <w.rf>
    <LM>w#w-d1t3307-10</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m012-d1t3309-2">
   <w.rf>
    <LM>w#w-d1t3309-2</LM>
   </w.rf>
   <form>výletů</form>
   <lemma>výlet</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m012-d1e3304-x2-11615">
   <w.rf>
    <LM>w#w-d1e3304-x2-11615</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3309-3">
   <w.rf>
    <LM>w#w-d1t3309-3</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m012-d1t3309-4">
   <w.rf>
    <LM>w#w-d1t3309-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3309-5">
   <w.rf>
    <LM>w#w-d1t3309-5</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3309-6">
   <w.rf>
    <LM>w#w-d1t3309-6</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3309-7">
   <w.rf>
    <LM>w#w-d1t3309-7</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1e3304-x2-11617">
   <w.rf>
    <LM>w#w-d1e3304-x2-11617</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-11618">
  <m id="m012-11618-11625">
   <w.rf>
    <LM>w#w-11618-11625</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3315-1">
   <w.rf>
    <LM>w#w-d1t3315-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3315-2">
   <w.rf>
    <LM>w#w-d1t3315-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3315-4">
   <w.rf>
    <LM>w#w-d1t3315-4</LM>
   </w.rf>
   <form>Vydru</form>
   <lemma>Vydra-2_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d1t3315-8">
   <w.rf>
    <LM>w#w-d1t3315-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-11618-11630">
   <w.rf>
    <LM>w#w-11618-11630</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3315-9">
   <w.rf>
    <LM>w#w-d1t3315-9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3315-10">
   <w.rf>
    <LM>w#w-d1t3315-10</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3315-12">
   <w.rf>
    <LM>w#w-d1t3315-12</LM>
   </w.rf>
   <form>samotná</form>
   <lemma>samotný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-d1t3315-11">
   <w.rf>
    <LM>w#w-d1t3315-11</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3315-14">
   <w.rf>
    <LM>w#w-d1t3315-14</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3315-15">
   <w.rf>
    <LM>w#w-d1t3315-15</LM>
   </w.rf>
   <form>tchánem</form>
   <lemma>tchán</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m012-11618-11629">
   <w.rf>
    <LM>w#w-11618-11629</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3315-16">
   <w.rf>
    <LM>w#w-d1t3315-16</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3315-17">
   <w.rf>
    <LM>w#w-d1t3315-17</LM>
   </w.rf>
   <form>dědou</form>
   <lemma>děda</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m012-11618-513">
   <w.rf>
    <LM>w#w-11618-513</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3315-19">
   <w.rf>
    <LM>w#w-d1t3315-19</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3315-20">
   <w.rf>
    <LM>w#w-d1t3315-20</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3318-1">
   <w.rf>
    <LM>w#w-d1t3318-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3318-2">
   <w.rf>
    <LM>w#w-d1t3318-2</LM>
   </w.rf>
   <form>babi</form>
   <lemma>babi_,h</lemma>
   <tag>NNFXX-----A----</tag>
  </m>
  <m id="m012-11618-514">
   <w.rf>
    <LM>w#w-11618-514</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-515">
  <m id="m012-d1t3320-4">
   <w.rf>
    <LM>w#w-d1t3320-4</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-11618-11691">
   <w.rf>
    <LM>w#w-11618-11691</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m012-d1t3320-6">
   <w.rf>
    <LM>w#w-d1t3320-6</LM>
   </w.rf>
   <form>nimi</form>
   <lemma>on-1</lemma>
   <tag>PEXP7--3------1</tag>
  </m>
  <m id="m012-d1t3320-7">
   <w.rf>
    <LM>w#w-d1t3320-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3320-11">
   <w.rf>
    <LM>w#w-d1t3320-11</LM>
   </w.rf>
   <form>konkrétně</form>
   <lemma>konkrétně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-d1t3322-1">
   <w.rf>
    <LM>w#w-d1t3322-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3322-3">
   <w.rf>
    <LM>w#w-d1t3322-3</LM>
   </w.rf>
   <form>Vydře</form>
   <lemma>Vydra-2_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1t3320-9">
   <w.rf>
    <LM>w#w-d1t3320-9</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3322-5">
   <w.rf>
    <LM>w#w-d1t3322-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3322-6">
   <w.rf>
    <LM>w#w-d1t3322-6</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m012-d-id153806">
   <w.rf>
    <LM>w#w-d-id153806</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3323-x2">
  <m id="m012-d1t3328-1">
   <w.rf>
    <LM>w#w-d1t3328-1</LM>
   </w.rf>
   <form>Jezdívali</form>
   <lemma>jezdívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3328-2">
   <w.rf>
    <LM>w#w-d1t3328-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m012-d1t3328-3">
   <w.rf>
    <LM>w#w-d1t3328-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3328-4">
   <w.rf>
    <LM>w#w-d1t3328-4</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d1t3328-5">
   <w.rf>
    <LM>w#w-d1t3328-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3328-6">
   <w.rf>
    <LM>w#w-d1t3328-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m012-d1t3328-7">
   <w.rf>
    <LM>w#w-d1t3328-7</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m012-d-id154911">
   <w.rf>
    <LM>w#w-d-id154911</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3329-x2">
  <m id="m012-d1t3343-1">
   <w.rf>
    <LM>w#w-d1t3343-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3343-2">
   <w.rf>
    <LM>w#w-d1t3343-2</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m012-d1t3343-3">
   <w.rf>
    <LM>w#w-d1t3343-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3343-4">
   <w.rf>
    <LM>w#w-d1t3343-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1e3329-x2-11807">
   <w.rf>
    <LM>w#w-d1e3329-x2-11807</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3343-6">
   <w.rf>
    <LM>w#w-d1t3343-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3343-7">
   <w.rf>
    <LM>w#w-d1t3343-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3345-1">
   <w.rf>
    <LM>w#w-d1t3345-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m012-d1t3345-3">
   <w.rf>
    <LM>w#w-d1t3345-3</LM>
   </w.rf>
   <form>Španělsku</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m012-d1t3345-5">
   <w.rf>
    <LM>w#w-d1t3345-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3345-6">
   <w.rf>
    <LM>w#w-d1t3345-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3345-8">
   <w.rf>
    <LM>w#w-d1t3345-8</LM>
   </w.rf>
   <form>Chorvatsku</form>
   <lemma>Chorvatsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m012-d1e3329-x2-11809">
   <w.rf>
    <LM>w#w-d1e3329-x2-11809</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-11810">
  <m id="m012-d1t3347-2">
   <w.rf>
    <LM>w#w-d1t3347-2</LM>
   </w.rf>
   <form>Jelikož</form>
   <lemma>jelikož</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3347-1">
   <w.rf>
    <LM>w#w-d1t3347-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3347-3">
   <w.rf>
    <LM>w#w-d1t3347-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3349-1">
   <w.rf>
    <LM>w#w-d1t3349-1</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3351-1">
   <w.rf>
    <LM>w#w-d1t3351-1</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m012-d1t3351-2">
   <w.rf>
    <LM>w#w-d1t3351-2</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m012-d1t3351-3">
   <w.rf>
    <LM>w#w-d1t3351-3</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1t3351-4">
   <w.rf>
    <LM>w#w-d1t3351-4</LM>
   </w.rf>
   <form>nedělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m012-d-id155597">
   <w.rf>
    <LM>w#w-d-id155597</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3351-13">
   <w.rf>
    <LM>w#w-d1t3351-13</LM>
   </w.rf>
   <form>nebyli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m012-d1t3351-7">
   <w.rf>
    <LM>w#w-d1t3351-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3351-9">
   <w.rf>
    <LM>w#w-d1t3351-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3351-10">
   <w.rf>
    <LM>w#w-d1t3351-10</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m012-d1t3351-8">
   <w.rf>
    <LM>w#w-d1t3351-8</LM>
   </w.rf>
   <form>finančně</form>
   <lemma>finančně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-d1t3351-11">
   <w.rf>
    <LM>w#w-d1t3351-11</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3351-12">
   <w.rf>
    <LM>w#w-d1t3351-12</LM>
   </w.rf>
   <form>ideálně</form>
   <lemma>ideálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-11810-12309">
   <w.rf>
    <LM>w#w-11810-12309</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-11810-12310">
   <w.rf>
    <LM>w#w-11810-12310</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3365-1">
   <w.rf>
    <LM>w#w-d1t3365-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3365-2">
   <w.rf>
    <LM>w#w-d1t3365-2</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3365-4">
   <w.rf>
    <LM>w#w-d1t3365-4</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-11810-12313">
   <w.rf>
    <LM>w#w-11810-12313</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-11810-12314">
   <w.rf>
    <LM>w#w-11810-12314</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3352-x3">
  <m id="m012-d1t3361-1">
   <w.rf>
    <LM>w#w-d1t3361-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d-id155843">
   <w.rf>
    <LM>w#w-d-id155843</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3362-x2">
  <m id="m012-d1t3365-9">
   <w.rf>
    <LM>w#w-d1t3365-9</LM>
   </w.rf>
   <form>Dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m012-d1t3365-12">
   <w.rf>
    <LM>w#w-d1t3365-12</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3365-13">
   <w.rf>
    <LM>w#w-d1t3365-13</LM>
   </w.rf>
   <form>víckrát</form>
   <lemma>víckrát</lemma>
   <tag>Co-------------</tag>
  </m>
  <m id="m012-d-id156102">
   <w.rf>
    <LM>w#w-d-id156102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3367-1">
   <w.rf>
    <LM>w#w-d1t3367-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3371-2">
   <w.rf>
    <LM>w#w-d1t3371-2</LM>
   </w.rf>
   <form>dcery</form>
   <lemma>dcera</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m012-d1t3371-3">
   <w.rf>
    <LM>w#w-d1t3371-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3371-4">
   <w.rf>
    <LM>w#w-d1t3371-4</LM>
   </w.rf>
   <form>poslali</form>
   <lemma>poslat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m012-d1e3362-x2-12441">
   <w.rf>
    <LM>w#w-d1e3362-x2-12441</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3371-11">
   <w.rf>
    <LM>w#w-d1t3371-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3371-12">
   <w.rf>
    <LM>w#w-d1t3371-12</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m012-d1t3371-13">
   <w.rf>
    <LM>w#w-d1t3371-13</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3371-14">
   <w.rf>
    <LM>w#w-d1t3371-14</LM>
   </w.rf>
   <form>zůstali</form>
   <lemma>zůstat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m012-d1t3371-15">
   <w.rf>
    <LM>w#w-d1t3371-15</LM>
   </w.rf>
   <form>doma</form>
   <lemma>doma</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-d-id155898">
   <w.rf>
    <LM>w#w-d-id155898</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3379-x2">
  <m id="m012-d1t3384-1">
   <w.rf>
    <LM>w#w-d1t3384-1</LM>
   </w.rf>
   <form>Žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3384-2">
   <w.rf>
    <LM>w#w-d1t3384-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3384-4">
   <w.rf>
    <LM>w#w-d1t3384-4</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3384-5">
   <w.rf>
    <LM>w#w-d1t3384-5</LM>
   </w.rf>
   <form>přemlouvala</form>
   <lemma>přemlouvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m012-d1e3379-x2-565">
   <w.rf>
    <LM>w#w-d1e3379-x2-565</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-566">
  <m id="m012-d1t3384-8">
   <w.rf>
    <LM>w#w-d1t3384-8</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3384-9">
   <w.rf>
    <LM>w#w-d1t3384-9</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3384-10">
   <w.rf>
    <LM>w#w-d1t3384-10</LM>
   </w.rf>
   <form>přemluvila</form>
   <lemma>přemluvit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m012-d-id156708">
   <w.rf>
    <LM>w#w-d-id156708</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3384-12">
   <w.rf>
    <LM>w#w-d1t3384-12</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3386-1">
   <w.rf>
    <LM>w#w-d1t3386-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3386-2">
   <w.rf>
    <LM>w#w-d1t3386-2</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m012-d1t3388-1">
   <w.rf>
    <LM>w#w-d1t3388-1</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3388-2">
   <w.rf>
    <LM>w#w-d1t3388-2</LM>
   </w.rf>
   <form>baví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d-id156882">
   <w.rf>
    <LM>w#w-d-id156882</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3388-4">
   <w.rf>
    <LM>w#w-d1t3388-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3388-6">
   <w.rf>
    <LM>w#w-d1t3388-6</LM>
   </w.rf>
   <form>musí</form>
   <lemma>muset</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3388-7">
   <w.rf>
    <LM>w#w-d1t3388-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3388-8">
   <w.rf>
    <LM>w#w-d1t3388-8</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d1t3388-11">
   <w.rf>
    <LM>w#w-d1t3388-11</LM>
   </w.rf>
   <form>nějaká</form>
   <lemma>nějaký</lemma>
   <tag>PZFS1----------</tag>
  </m>
  <m id="m012-d1t3388-12">
   <w.rf>
    <LM>w#w-d1t3388-12</LM>
   </w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1e3379-x2-12546">
   <w.rf>
    <LM>w#w-d1e3379-x2-12546</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-12547">
  <m id="m012-d1t3388-14">
   <w.rf>
    <LM>w#w-d1t3388-14</LM>
   </w.rf>
   <form>Ležet</form>
   <lemma>ležet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m012-d1t3388-15">
   <w.rf>
    <LM>w#w-d1t3388-15</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3390-1">
   <w.rf>
    <LM>w#w-d1t3390-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3390-2">
   <w.rf>
    <LM>w#w-d1t3390-2</LM>
   </w.rf>
   <form>pláži</form>
   <lemma>pláž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d-id157090">
   <w.rf>
    <LM>w#w-d-id157090</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3390-4">
   <w.rf>
    <LM>w#w-d1t3390-4</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3390-5">
   <w.rf>
    <LM>w#w-d1t3390-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m012-d1t3390-9">
   <w.rf>
    <LM>w#w-d1t3390-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3390-6">
   <w.rf>
    <LM>w#w-d1t3390-6</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m012-d1t3390-7">
   <w.rf>
    <LM>w#w-d1t3390-7</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1t3390-8">
   <w.rf>
    <LM>w#w-d1t3390-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3390-10">
   <w.rf>
    <LM>w#w-d1t3390-10</LM>
   </w.rf>
   <form>otrávený</form>
   <lemma>otrávený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m012-d1t3390-11">
   <w.rf>
    <LM>w#w-d1t3390-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3390-12">
   <w.rf>
    <LM>w#w-d1t3390-12</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3390-13">
   <w.rf>
    <LM>w#w-d1t3390-13</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3390-14">
   <w.rf>
    <LM>w#w-d1t3390-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3390-16">
   <w.rf>
    <LM>w#w-d1t3390-16</LM>
   </w.rf>
   <form>nebaví</form>
   <lemma>bavit</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m012-d-id156542">
   <w.rf>
    <LM>w#w-d-id156542</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3391-x3">
  <m id="m012-d1t3398-1">
   <w.rf>
    <LM>w#w-d1t3398-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3398-2">
   <w.rf>
    <LM>w#w-d1t3398-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3398-3">
   <w.rf>
    <LM>w#w-d1t3398-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3398-4">
   <w.rf>
    <LM>w#w-d1t3398-4</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m012-d1t3398-5">
   <w.rf>
    <LM>w#w-d1t3398-5</LM>
   </w.rf>
   <form>horko</form>
   <lemma>horko-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d-id157454">
   <w.rf>
    <LM>w#w-d-id157454</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3399-x2">
  <m id="m012-d1t3406-1">
   <w.rf>
    <LM>w#w-d1t3406-1</LM>
   </w.rf>
   <form>Mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3406-2">
   <w.rf>
    <LM>w#w-d1t3406-2</LM>
   </w.rf>
   <form>štve</form>
   <lemma>štvát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3406-3">
   <w.rf>
    <LM>w#w-d1t3406-3</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3406-4">
   <w.rf>
    <LM>w#w-d1t3406-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d-id157613">
   <w.rf>
    <LM>w#w-d-id157613</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3406-6">
   <w.rf>
    <LM>w#w-d1t3406-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3406-7">
   <w.rf>
    <LM>w#w-d1t3406-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3406-8">
   <w.rf>
    <LM>w#w-d1t3406-8</LM>
   </w.rf>
   <form>válím</form>
   <lemma>válet</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1e3399-x2-12679">
   <w.rf>
    <LM>w#w-d1e3399-x2-12679</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3406-10">
   <w.rf>
    <LM>w#w-d1t3406-10</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m012-d1t3406-11">
   <w.rf>
    <LM>w#w-d1t3406-11</LM>
   </w.rf>
   <form>nedělám</form>
   <lemma>dělat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m012-d1t3406-12">
   <w.rf>
    <LM>w#w-d1t3406-12</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3406-13">
   <w.rf>
    <LM>w#w-d1t3406-13</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m012-d1t3406-14">
   <w.rf>
    <LM>w#w-d1t3406-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3406-15">
   <w.rf>
    <LM>w#w-d1t3406-15</LM>
   </w.rf>
   <form>neděje</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m012-d1e3399-x2-576">
   <w.rf>
    <LM>w#w-d1e3399-x2-576</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-577">
  <m id="m012-d1t3406-18">
   <w.rf>
    <LM>w#w-d1t3406-18</LM>
   </w.rf>
   <form>Že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3406-19">
   <w.rf>
    <LM>w#w-d1t3406-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1t3412-1">
   <w.rf>
    <LM>w#w-d1t3412-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3412-2">
   <w.rf>
    <LM>w#w-d1t3412-2</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-d1t3420-1">
   <w.rf>
    <LM>w#w-d1t3420-1</LM>
   </w.rf>
   <form>jednotvárné</form>
   <lemma>jednotvárný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m012-d1e3399-x2-13032">
   <w.rf>
    <LM>w#w-d1e3399-x2-13032</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3420-2">
   <w.rf>
    <LM>w#w-d1t3420-2</LM>
   </w.rf>
   <form>obrátit</form>
   <lemma>obrátit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m012-d1t3420-3">
   <w.rf>
    <LM>w#w-d1t3420-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1e3399-x2-13033">
   <w.rf>
    <LM>w#w-d1e3399-x2-13033</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3420-4">
   <w.rf>
    <LM>w#w-d1t3420-4</LM>
   </w.rf>
   <form>abych</form>
   <lemma>aby</lemma>
   <tag>J,-----------c-</tag>
  </m>
  <m id="m012-d1t3420-6">
   <w.rf>
    <LM>w#w-d1t3420-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3420-7">
   <w.rf>
    <LM>w#w-d1t3420-7</LM>
   </w.rf>
   <form>nespálil</form>
   <lemma>spálit</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m012-d1e3399-x2-13037">
   <w.rf>
    <LM>w#w-d1e3399-x2-13037</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3420-10">
   <w.rf>
    <LM>w#w-d1t3420-10</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3426-1">
   <w.rf>
    <LM>w#w-d1t3426-1</LM>
   </w.rf>
   <form>vlézt</form>
   <lemma>vlézt</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m012-d1t3426-2">
   <w.rf>
    <LM>w#w-d1t3426-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3426-3">
   <w.rf>
    <LM>w#w-d1t3426-3</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m012-d1e3399-x2-13036">
   <w.rf>
    <LM>w#w-d1e3399-x2-13036</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-12984">
  <m id="m012-d1t3426-4">
   <w.rf>
    <LM>w#w-d1t3426-4</LM>
   </w.rf>
   <form>Slanou</form>
   <lemma>slaný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m012-d1t3426-5">
   <w.rf>
    <LM>w#w-d1t3426-5</LM>
   </w.rf>
   <form>vodu</form>
   <lemma>voda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d1t3434-2">
   <w.rf>
    <LM>w#w-d1t3434-2</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3434-3">
   <w.rf>
    <LM>w#w-d1t3434-3</LM>
   </w.rf>
   <form>nemusím</form>
   <lemma>muset</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m012-d-id158382">
   <w.rf>
    <LM>w#w-d-id158382</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3436-1">
   <w.rf>
    <LM>w#w-d1t3436-1</LM>
   </w.rf>
   <form>nemiluju</form>
   <lemma>milovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m012-12984-13096">
   <w.rf>
    <LM>w#w-12984-13096</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3436-2">
   <w.rf>
    <LM>w#w-d1t3436-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3436-3">
   <w.rf>
    <LM>w#w-d1t3436-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3438-2">
   <w.rf>
    <LM>w#w-d1t3438-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-12984-13101">
   <w.rf>
    <LM>w#w-12984-13101</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3436-7">
   <w.rf>
    <LM>w#w-d1t3436-7</LM>
   </w.rf>
   <form>boleveckých</form>
   <lemma>bolevecký</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m012-d1t3436-9">
   <w.rf>
    <LM>w#w-d1t3436-9</LM>
   </w.rf>
   <form>rybnících</form>
   <lemma>rybník</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m012-d1t3438-3">
   <w.rf>
    <LM>w#w-d1t3438-3</LM>
   </w.rf>
   <form>řádili</form>
   <lemma>řádit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3438-4">
   <w.rf>
    <LM>w#w-d1t3438-4</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3438-5">
   <w.rf>
    <LM>w#w-d1t3438-5</LM>
   </w.rf>
   <form>malička</form>
   <lemma>maličko-2</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m012-12984-13105">
   <w.rf>
    <LM>w#w-12984-13105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-13106">
  <m id="m012-d1t3438-8">
   <w.rf>
    <LM>w#w-d1t3438-8</LM>
   </w.rf>
   <form>Slaná</form>
   <lemma>slaný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-d1t3438-9">
   <w.rf>
    <LM>w#w-d1t3438-9</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3438-10">
   <w.rf>
    <LM>w#w-d1t3438-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m012-d1t3438-7">
   <w.rf>
    <LM>w#w-d1t3438-7</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3438-11">
   <w.rf>
    <LM>w#w-d1t3438-11</LM>
   </w.rf>
   <form>prostě</form>
   <lemma>prostě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m012-d1t3438-14">
   <w.rf>
    <LM>w#w-d1t3438-14</LM>
   </w.rf>
   <form>nedělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m012-d1t3438-15">
   <w.rf>
    <LM>w#w-d1t3438-15</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m012-d1t3438-12">
   <w.rf>
    <LM>w#w-d1t3438-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3438-13">
   <w.rf>
    <LM>w#w-d1t3438-13</LM>
   </w.rf>
   <form>oči</form>
   <lemma>oko-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m012-13106-583">
   <w.rf>
    <LM>w#w-13106-583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-584">
  <m id="m012-d1t3454-2">
   <w.rf>
    <LM>w#w-d1t3454-2</LM>
   </w.rf>
   <form>Pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3454-3">
   <w.rf>
    <LM>w#w-d1t3454-3</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m012-d1t3454-1">
   <w.rf>
    <LM>w#w-d1t3454-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m012-13106-13316">
   <w.rf>
    <LM>w#w-13106-13316</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m012-d1t3456-2">
   <w.rf>
    <LM>w#w-d1t3456-2</LM>
   </w.rf>
   <form>neznamená</form>
   <lemma>znamenat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m012-13106-13317">
   <w.rf>
    <LM>w#w-13106-13317</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-13293">
  <m id="m012-d1t3456-5">
   <w.rf>
    <LM>w#w-d1t3456-5</LM>
   </w.rf>
   <form>Žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d1t3456-7">
   <w.rf>
    <LM>w#w-d1t3456-7</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m012-d-id159132">
   <w.rf>
    <LM>w#w-d-id159132</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3456-11">
   <w.rf>
    <LM>w#w-d1t3456-11</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m012-d1t3456-13">
   <w.rf>
    <LM>w#w-d1t3456-13</LM>
   </w.rf>
   <form>jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3456-8">
   <w.rf>
    <LM>w#w-d1t3456-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3456-9">
   <w.rf>
    <LM>w#w-d1t3456-9</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m012-d-id159181">
   <w.rf>
    <LM>w#w-d-id159181</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3456-15">
   <w.rf>
    <LM>w#w-d1t3456-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3456-16">
   <w.rf>
    <LM>w#w-d1t3456-16</LM>
   </w.rf>
   <form>letos</form>
   <lemma>letos</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3456-17">
   <w.rf>
    <LM>w#w-d1t3456-17</LM>
   </w.rf>
   <form>pojedeme</form>
   <lemma>jet-1</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m012-d1t3456-20">
   <w.rf>
    <LM>w#w-d1t3456-20</LM>
   </w.rf>
   <form>zas</form>
   <lemma>zas-1_,s_^(^DD**zase-1)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3456-21">
   <w.rf>
    <LM>w#w-d1t3456-21</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3456-22">
   <w.rf>
    <LM>w#w-d1t3456-22</LM>
   </w.rf>
   <form>změnu</form>
   <lemma>změna</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m012-d1t3456-24">
   <w.rf>
    <LM>w#w-d1t3456-24</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3456-23">
   <w.rf>
    <LM>w#w-d1t3456-23</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m012-d1t3456-18">
   <w.rf>
    <LM>w#w-d1t3456-18</LM>
   </w.rf>
   <form>sami</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m012-d1t3456-19">
   <w.rf>
    <LM>w#w-d1t3456-19</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m012-d-id158896">
   <w.rf>
    <LM>w#w-d-id158896</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3457-x2">
  <m id="m012-d1t3462-1">
   <w.rf>
    <LM>w#w-d1t3462-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d-id159415">
   <w.rf>
    <LM>w#w-d-id159415</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3463-x2">
  <m id="m012-d1t3468-1">
   <w.rf>
    <LM>w#w-d1t3468-1</LM>
   </w.rf>
   <form>Zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3468-2">
   <w.rf>
    <LM>w#w-d1t3468-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3468-4">
   <w.rf>
    <LM>w#w-d1t3468-4</LM>
   </w.rf>
   <form>Španělska</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m012-d1e3463-x2-595">
   <w.rf>
    <LM>w#w-d1e3463-x2-595</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-596">
  <m id="m012-d1t3470-2">
   <w.rf>
    <LM>w#w-d1t3470-2</LM>
   </w.rf>
   <form>Španělsko</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m012-d1t3470-4">
   <w.rf>
    <LM>w#w-d1t3470-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3470-5">
   <w.rf>
    <LM>w#w-d1t3470-5</LM>
   </w.rf>
   <form>ženě</form>
   <lemma>žena</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m012-d1t3470-6">
   <w.rf>
    <LM>w#w-d1t3470-6</LM>
   </w.rf>
   <form>líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3470-7">
   <w.rf>
    <LM>w#w-d1t3470-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3470-8">
   <w.rf>
    <LM>w#w-d1t3470-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m012-d1t3470-9">
   <w.rf>
    <LM>w#w-d1t3470-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3470-11">
   <w.rf>
    <LM>w#w-d1t3470-11</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m012-d1t3470-10">
   <w.rf>
    <LM>w#w-d1t3470-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3470-12">
   <w.rf>
    <LM>w#w-d1t3470-12</LM>
   </w.rf>
   <form>spokojený</form>
   <lemma>spokojený_^(*3it)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m012-d1e3463-x2-13475">
   <w.rf>
    <LM>w#w-d1e3463-x2-13475</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-13476">
  <m id="m012-d1t3472-1">
   <w.rf>
    <LM>w#w-d1t3472-1</LM>
   </w.rf>
   <form>Letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m012-d1t3472-2">
   <w.rf>
    <LM>w#w-d1t3472-2</LM>
   </w.rf>
   <form>nechceme</form>
   <lemma>chtít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m012-d-id159766">
   <w.rf>
    <LM>w#w-d-id159766</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3472-8">
   <w.rf>
    <LM>w#w-d1t3472-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3472-9">
   <w.rf>
    <LM>w#w-d1t3472-9</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m012-d1t3472-10">
   <w.rf>
    <LM>w#w-d1t3472-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3477-2">
   <w.rf>
    <LM>w#w-d1t3477-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3477-1">
   <w.rf>
    <LM>w#w-d1t3477-1</LM>
   </w.rf>
   <form>letadlem</form>
   <lemma>letadlo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m012-d1t3477-3">
   <w.rf>
    <LM>w#w-d1t3477-3</LM>
   </w.rf>
   <form>letěli</form>
   <lemma>letět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3477-4">
   <w.rf>
    <LM>w#w-d1t3477-4</LM>
   </w.rf>
   <form>oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m012-d-id159997">
   <w.rf>
    <LM>w#w-d-id159997</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3477-6">
   <w.rf>
    <LM>w#w-d1t3477-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3479-2">
   <w.rf>
    <LM>w#w-d1t3479-2</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m012-d-id159461">
   <w.rf>
    <LM>w#w-d-id159461</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3481-x2">
  <m id="m012-d1t3484-1">
   <w.rf>
    <LM>w#w-d1t3484-1</LM>
   </w.rf>
   <form>Řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m012-d1t3484-2">
   <w.rf>
    <LM>w#w-d1t3484-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m012-d1t3484-3">
   <w.rf>
    <LM>w#w-d1t3484-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m012-d1t3484-4">
   <w.rf>
    <LM>w#w-d1t3484-4</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1e3481-x2-13505">
   <w.rf>
    <LM>w#w-d1e3481-x2-13505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3484-5">
   <w.rf>
    <LM>w#w-d1t3484-5</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m012-d1t3484-6">
   <w.rf>
    <LM>w#w-d1t3484-6</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m012-d1t3484-7">
   <w.rf>
    <LM>w#w-d1t3484-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m012-d1t3484-8">
   <w.rf>
    <LM>w#w-d1t3484-8</LM>
   </w.rf>
   <form>Vydry</form>
   <lemma>Vydra-2_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m012-d-id160247">
   <w.rf>
    <LM>w#w-d-id160247</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3485-x2">
  <m id="m012-d1e3485-x2-13631">
   <w.rf>
    <LM>w#w-d1e3485-x2-13631</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m012-d1e3485-x2-13632">
   <w.rf>
    <LM>w#w-d1e3485-x2-13632</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3492-12">
   <w.rf>
    <LM>w#w-d1t3492-12</LM>
   </w.rf>
   <form>krásná</form>
   <lemma>krásný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m012-d1t3492-11">
   <w.rf>
    <LM>w#w-d1t3492-11</LM>
   </w.rf>
   <form>příroda</form>
   <lemma>příroda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m012-d-id160510">
   <w.rf>
    <LM>w#w-d-id160510</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3494-3">
   <w.rf>
    <LM>w#w-d1t3494-3</LM>
   </w.rf>
   <form>člověk</form>
   <lemma>člověk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m012-d1t3494-1">
   <w.rf>
    <LM>w#w-d1t3494-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3494-2">
   <w.rf>
    <LM>w#w-d1t3494-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3499-1">
   <w.rf>
    <LM>w#w-d1t3499-1</LM>
   </w.rf>
   <form>vyžije</form>
   <lemma>vyžít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m012-d-id160702">
   <w.rf>
    <LM>w#w-d-id160702</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3499-3">
   <w.rf>
    <LM>w#w-d1t3499-3</LM>
   </w.rf>
   <form>uklidní</form>
   <lemma>uklidnit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m012-d1e3485-x2-13636">
   <w.rf>
    <LM>w#w-d1e3485-x2-13636</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-13637">
  <m id="m012-d1t3499-6">
   <w.rf>
    <LM>w#w-d1t3499-6</LM>
   </w.rf>
   <form>Nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m012-d1t3499-7">
   <w.rf>
    <LM>w#w-d1t3499-7</LM>
   </w.rf>
   <form>konkrétní</form>
   <lemma>konkrétní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m012-d1t3501-1">
   <w.rf>
    <LM>w#w-d1t3501-1</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m012-d1t3501-2">
   <w.rf>
    <LM>w#w-d1t3501-2</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m012-d1t3501-7">
   <w.rf>
    <LM>w#w-d1t3501-7</LM>
   </w.rf>
   <form>nemáme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m012-13637-13647">
   <w.rf>
    <LM>w#w-13637-13647</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-13648">
  <m id="m012-d1t3505-1">
   <w.rf>
    <LM>w#w-d1t3505-1</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3505-2">
   <w.rf>
    <LM>w#w-d1t3505-2</LM>
   </w.rf>
   <form>jediný</form>
   <lemma>jediný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m012-d-id160963">
   <w.rf>
    <LM>w#w-d-id160963</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m012-d1t3505-4">
   <w.rf>
    <LM>w#w-d1t3505-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3505-9">
   <w.rf>
    <LM>w#w-d1t3505-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m012-d1t3505-10">
   <w.rf>
    <LM>w#w-d1t3505-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3505-11">
   <w.rf>
    <LM>w#w-d1t3505-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3505-12">
   <w.rf>
    <LM>w#w-d1t3505-12</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3507-1">
   <w.rf>
    <LM>w#w-d1t3507-1</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3507-2">
   <w.rf>
    <LM>w#w-d1t3507-2</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m012-d1t3507-3">
   <w.rf>
    <LM>w#w-d1t3507-3</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-d1t3507-4">
   <w.rf>
    <LM>w#w-d1t3507-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m012-d1t3507-5">
   <w.rf>
    <LM>w#w-d1t3507-5</LM>
   </w.rf>
   <form>čtrnácti</form>
   <lemma>čtrnáct`14</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m012-d1t3507-6">
   <w.rf>
    <LM>w#w-d1t3507-6</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m012-13648-13660">
   <w.rf>
    <LM>w#w-13648-13660</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3514-1">
   <w.rf>
    <LM>w#w-d1t3514-1</LM>
   </w.rf>
   <form>školním</form>
   <lemma>školní</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m012-d1t3516-1">
   <w.rf>
    <LM>w#w-d1t3516-1</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m012-d1t3516-5">
   <w.rf>
    <LM>w#w-d1t3516-5</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3516-2">
   <w.rf>
    <LM>w#w-d1t3516-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3516-3">
   <w.rf>
    <LM>w#w-d1t3516-3</LM>
   </w.rf>
   <form>osmé</form>
   <lemma>osmý</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m012-d1t3516-4">
   <w.rf>
    <LM>w#w-d1t3516-4</LM>
   </w.rf>
   <form>třídě</form>
   <lemma>třída</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m012-13648-13665">
   <w.rf>
    <LM>w#w-13648-13665</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m012-d1e3485-x3">
  <m id="m012-d1t3516-7">
   <w.rf>
    <LM>w#w-d1t3516-7</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3516-8">
   <w.rf>
    <LM>w#w-d1t3516-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3516-9">
   <w.rf>
    <LM>w#w-d1t3516-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m012-d1t3516-10">
   <w.rf>
    <LM>w#w-d1t3516-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m012-d1t3516-11">
   <w.rf>
    <LM>w#w-d1t3516-11</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m012-d1t3516-12">
   <w.rf>
    <LM>w#w-d1t3516-12</LM>
   </w.rf>
   <form>dni</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A---1</tag>
  </m>
  <m id="m012-d1t3516-13">
   <w.rf>
    <LM>w#w-d1t3516-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m012-d1t3518-5">
   <w.rf>
    <LM>w#w-d1t3518-5</LM>
   </w.rf>
   <form>opalovali</form>
   <lemma>opalovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m012-d1t3518-3">
   <w.rf>
    <LM>w#w-d1t3518-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m012-d1t3518-4">
   <w.rf>
    <LM>w#w-d1t3518-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m012-d1t3518-1">
   <w.rf>
    <LM>w#w-d1t3518-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m012-d1t3518-2">
   <w.rf>
    <LM>w#w-d1t3518-2</LM>
   </w.rf>
   <form>balvanech</form>
   <lemma>balvan</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m012-d1e3485-x3-13935">
   <w.rf>
    <LM>w#w-d1e3485-x3-13935</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
