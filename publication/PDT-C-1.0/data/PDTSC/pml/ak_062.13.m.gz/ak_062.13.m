<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_062.13.w.gz" />
  </references>
 </head>
 <s id="m062-613">
  <m id="m062-d1t2844-3">
   <w.rf>
    <LM>w#w-d1t2844-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m062-d1t2844-4">
   <w.rf>
    <LM>w#w-d1t2844-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2844-5">
   <w.rf>
    <LM>w#w-d1t2844-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2844-6">
   <w.rf>
    <LM>w#w-d1t2844-6</LM>
   </w.rf>
   <form>děcko</form>
   <lemma>děcko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m062-d-id165230-punct">
   <w.rf>
    <LM>w#w-d-id165230-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2844-8">
   <w.rf>
    <LM>w#w-d1t2844-8</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2844-10">
   <w.rf>
    <LM>w#w-d1t2844-10</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2844-11">
   <w.rf>
    <LM>w#w-d1t2844-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m062-d1t2844-12">
   <w.rf>
    <LM>w#w-d1t2844-12</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-613-614">
   <w.rf>
    <LM>w#w-613-614</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-615">
  <m id="m062-d1t2848-3">
   <w.rf>
    <LM>w#w-d1t2848-3</LM>
   </w.rf>
   <form>Dubček</form>
   <lemma>Dubček_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-d1t2848-5">
   <w.rf>
    <LM>w#w-d1t2848-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2848-6">
   <w.rf>
    <LM>w#w-d1t2848-6</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2848-7">
   <w.rf>
    <LM>w#w-d1t2848-7</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m062-d-id165416-punct">
   <w.rf>
    <LM>w#w-d-id165416-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2848-9">
   <w.rf>
    <LM>w#w-d1t2848-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2848-10">
   <w.rf>
    <LM>w#w-d1t2848-10</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2848-11">
   <w.rf>
    <LM>w#w-d1t2848-11</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d-id165471-punct">
   <w.rf>
    <LM>w#w-d-id165471-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2848-13">
   <w.rf>
    <LM>w#w-d1t2848-13</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m062-d1t2848-15">
   <w.rf>
    <LM>w#w-d1t2848-15</LM>
   </w.rf>
   <form>komunisti</form>
   <lemma>komunista</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m062-d1t2848-16">
   <w.rf>
    <LM>w#w-d1t2848-16</LM>
   </w.rf>
   <form>dovedou</form>
   <lemma>dovést</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m062-615-616">
   <w.rf>
    <LM>w#w-615-616</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-617">
  <m id="m062-d1t2850-2">
   <w.rf>
    <LM>w#w-d1t2850-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2850-3">
   <w.rf>
    <LM>w#w-d1t2850-3</LM>
   </w.rf>
   <form>věděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-617-632">
   <w.rf>
    <LM>w#w-617-632</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2850-4">
   <w.rf>
    <LM>w#w-d1t2850-4</LM>
   </w.rf>
   <form>proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2850-5">
   <w.rf>
    <LM>w#w-d1t2850-5</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2850-6">
   <w.rf>
    <LM>w#w-d1t2850-6</LM>
   </w.rf>
   <form>strach</form>
   <lemma>strach</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-d1e2789-x5-633">
   <w.rf>
    <LM>w#w-d1e2789-x5-633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-634">
  <m id="m062-d1t2855-4">
   <w.rf>
    <LM>w#w-d1t2855-4</LM>
   </w.rf>
   <form>Smrkovský</form>
   <lemma>Smrkovský_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-634-641">
   <w.rf>
    <LM>w#w-634-641</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2855-7">
   <w.rf>
    <LM>w#w-d1t2855-7</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m062-d1t2855-9">
   <w.rf>
    <LM>w#w-d1t2855-9</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-d1t2855-8">
   <w.rf>
    <LM>w#w-d1t2855-8</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2855-10">
   <w.rf>
    <LM>w#w-d1t2855-10</LM>
   </w.rf>
   <form>pryč</form>
   <lemma>pryč-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-634-642">
   <w.rf>
    <LM>w#w-634-642</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-644">
  <m id="m062-d1t2855-13">
   <w.rf>
    <LM>w#w-d1t2855-13</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2855-14">
   <w.rf>
    <LM>w#w-d1t2855-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2855-15">
   <w.rf>
    <LM>w#w-d1t2855-15</LM>
   </w.rf>
   <form>poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2855-16">
   <w.rf>
    <LM>w#w-d1t2855-16</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2855-17">
   <w.rf>
    <LM>w#w-d1t2855-17</LM>
   </w.rf>
   <form>naposled</form>
   <lemma>naposled</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d-id165873-punct">
   <w.rf>
    <LM>w#w-d-id165873-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2855-19">
   <w.rf>
    <LM>w#w-d1t2855-19</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2855-20">
   <w.rf>
    <LM>w#w-d1t2855-20</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2855-21">
   <w.rf>
    <LM>w#w-d1t2855-21</LM>
   </w.rf>
   <form>komunistům</form>
   <lemma>komunista</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m062-d1t2855-23">
   <w.rf>
    <LM>w#w-d1t2855-23</LM>
   </w.rf>
   <form>věřil</form>
   <lemma>věřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2855-24">
   <w.rf>
    <LM>w#w-d1t2855-24</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2855-25">
   <w.rf>
    <LM>w#w-d1t2855-25</LM>
   </w.rf>
   <form>fandil</form>
   <lemma>fandit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-644-645">
   <w.rf>
    <LM>w#w-644-645</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-646">
  <m id="m062-d1t2859-2">
   <w.rf>
    <LM>w#w-d1t2859-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2859-3">
   <w.rf>
    <LM>w#w-d1t2859-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-646-647">
   <w.rf>
    <LM>w#w-646-647</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2859-9">
   <w.rf>
    <LM>w#w-d1t2859-9</LM>
   </w.rf>
   <form>říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-646-391">
   <w.rf>
    <LM>w#w-646-391</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2859-5">
   <w.rf>
    <LM>w#w-d1t2859-5</LM>
   </w.rf>
   <form>komunismus</form>
   <lemma>komunismus_,s_^(^DD**komunizmus)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t2859-6">
   <w.rf>
    <LM>w#w-d1t2859-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m062-d1t2859-7">
   <w.rf>
    <LM>w#w-d1t2859-7</LM>
   </w.rf>
   <form>lidskou</form>
   <lemma>lidský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m062-d1t2859-8">
   <w.rf>
    <LM>w#w-d1t2859-8</LM>
   </w.rf>
   <form>tváří</form>
   <lemma>tvář</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m062-646-651">
   <w.rf>
    <LM>w#w-646-651</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-652">
  <m id="m062-d1t2861-5">
   <w.rf>
    <LM>w#w-d1t2861-5</LM>
   </w.rf>
   <form>Věřil</form>
   <lemma>věřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2861-3">
   <w.rf>
    <LM>w#w-d1t2861-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2861-4">
   <w.rf>
    <LM>w#w-d1t2861-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m062-652-685">
   <w.rf>
    <LM>w#w-652-685</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-687">
  <m id="m062-d1t2874-3">
   <w.rf>
    <LM>w#w-d1t2874-3</LM>
   </w.rf>
   <form>Šik</form>
   <lemma>Šik_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-652-677">
   <w.rf>
    <LM>w#w-652-677</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2876-1">
   <w.rf>
    <LM>w#w-d1t2876-1</LM>
   </w.rf>
   <form>ekonom</form>
   <lemma>ekonom</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-d-id166635-punct">
   <w.rf>
    <LM>w#w-d-id166635-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2861-10">
   <w.rf>
    <LM>w#w-d1t2861-10</LM>
   </w.rf>
   <form>dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2861-11">
   <w.rf>
    <LM>w#w-d1t2861-11</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1e2869-x2-684">
   <w.rf>
    <LM>w#w-d1e2869-x2-684</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2876-5">
   <w.rf>
    <LM>w#w-d1t2876-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2876-8">
   <w.rf>
    <LM>w#w-d1t2876-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t2876-9">
   <w.rf>
    <LM>w#w-d1t2876-9</LM>
   </w.rf>
   <form>dvou</form>
   <lemma>dva`2</lemma>
   <tag>CnXP2----------</tag>
  </m>
  <m id="m062-d1e2869-x2-680">
   <w.rf>
    <LM>w#w-d1e2869-x2-680</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1e2869-x2-681">
   <w.rf>
    <LM>w#w-d1e2869-x2-681</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1e2869-x2-682">
   <w.rf>
    <LM>w#w-d1e2869-x2-682</LM>
   </w.rf>
   <form>pěti</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-P2----------</tag>
  </m>
  <m id="m062-d1e2869-x2-683">
   <w.rf>
    <LM>w#w-d1e2869-x2-683</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m062-d1t2876-14">
   <w.rf>
    <LM>w#w-d1t2876-14</LM>
   </w.rf>
   <form>předeženeme</form>
   <lemma>předehnat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m062-d1t2876-16">
   <w.rf>
    <LM>w#w-d1t2876-16</LM>
   </w.rf>
   <form>Rakousko</form>
   <lemma>Rakousko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m062-687-688">
   <w.rf>
    <LM>w#w-687-688</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-692">
  <m id="m062-d1t2878-1">
   <w.rf>
    <LM>w#w-d1t2878-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2878-2">
   <w.rf>
    <LM>w#w-d1t2878-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m062-d1t2878-3">
   <w.rf>
    <LM>w#w-d1t2878-3</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m062-d1t2878-4">
   <w.rf>
    <LM>w#w-d1t2878-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t2880-1">
   <w.rf>
    <LM>w#w-d1t2880-1</LM>
   </w.rf>
   <form>nejchudších</form>
   <lemma>chudý-1</lemma>
   <tag>AAFP2----3A----</tag>
  </m>
  <m id="m062-d1t2880-2">
   <w.rf>
    <LM>w#w-d1t2880-2</LM>
   </w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m062-d1t2880-3">
   <w.rf>
    <LM>w#w-d1t2880-3</LM>
   </w.rf>
   <form>kapitalismu</form>
   <lemma>kapitalismus_,s_^(^DD**kapitalizmus)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m062-692-703">
   <w.rf>
    <LM>w#w-692-703</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-704">
  <m id="m062-d1t2883-3">
   <w.rf>
    <LM>w#w-d1t2883-3</LM>
   </w.rf>
   <form>Věřil</form>
   <lemma>věřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2883-2">
   <w.rf>
    <LM>w#w-d1t2883-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d-id167069-punct">
   <w.rf>
    <LM>w#w-d-id167069-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2883-6">
   <w.rf>
    <LM>w#w-d1t2883-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2883-9">
   <w.rf>
    <LM>w#w-d1t2883-9</LM>
   </w.rf>
   <form>Rakušáky</form>
   <lemma>Rakušák_;E_,h</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m062-d1t2883-11">
   <w.rf>
    <LM>w#w-d1t2883-11</LM>
   </w.rf>
   <form>předběhnem</form>
   <lemma>předběhnout</lemma>
   <tag>VB-P---1P-AAP-6</tag>
  </m>
  <m id="m062-704-705">
   <w.rf>
    <LM>w#w-704-705</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2885-3">
   <w.rf>
    <LM>w#w-d1t2885-3</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2885-4">
   <w.rf>
    <LM>w#w-d1t2885-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2885-5">
   <w.rf>
    <LM>w#w-d1t2885-5</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m062-d1t2885-6">
   <w.rf>
    <LM>w#w-d1t2885-6</LM>
   </w.rf>
   <form>pracovitý</form>
   <lemma>pracovitý</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m062-d1t2885-7">
   <w.rf>
    <LM>w#w-d1t2885-7</LM>
   </w.rf>
   <form>národ</form>
   <lemma>národ</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-704-708">
   <w.rf>
    <LM>w#w-704-708</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-704-709">
   <w.rf>
    <LM>w#w-704-709</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2885-11">
   <w.rf>
    <LM>w#w-d1t2885-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2885-12">
   <w.rf>
    <LM>w#w-d1t2885-12</LM>
   </w.rf>
   <form>budeme</form>
   <lemma>být</lemma>
   <tag>VB-P---1F-AAI--</tag>
  </m>
  <m id="m062-d1t2885-13">
   <w.rf>
    <LM>w#w-d1t2885-13</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1t2885-14">
   <w.rf>
    <LM>w#w-d1t2885-14</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m062-d1t2887-1">
   <w.rf>
    <LM>w#w-d1t2887-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2887-2">
   <w.rf>
    <LM>w#w-d1t2887-2</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2887-3">
   <w.rf>
    <LM>w#w-d1t2887-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2887-4">
   <w.rf>
    <LM>w#w-d1t2887-4</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m062-d1t2887-6">
   <w.rf>
    <LM>w#w-d1t2887-6</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m062-707-710">
   <w.rf>
    <LM>w#w-707-710</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2892-x2">
  <m id="m062-d1t2895-1">
   <w.rf>
    <LM>w#w-d1t2895-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m062-d1t2895-2">
   <w.rf>
    <LM>w#w-d1t2895-2</LM>
   </w.rf>
   <form>komunismem</form>
   <lemma>komunismus_,s_^(^DD**komunizmus)</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m062-d1t2895-3">
   <w.rf>
    <LM>w#w-d1t2895-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m062-d1t2895-4">
   <w.rf>
    <LM>w#w-d1t2895-4</LM>
   </w.rf>
   <form>lidskou</form>
   <lemma>lidský</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m062-d1t2895-5">
   <w.rf>
    <LM>w#w-d1t2895-5</LM>
   </w.rf>
   <form>tváří</form>
   <lemma>tvář</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m062-d1t2895-6">
   <w.rf>
    <LM>w#w-d1t2895-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2895-7">
   <w.rf>
    <LM>w#w-d1t2895-7</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m062-d1t2895-9">
   <w.rf>
    <LM>w#w-d1t2895-9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2895-8">
   <w.rf>
    <LM>w#w-d1t2895-8</LM>
   </w.rf>
   <form>věřil</form>
   <lemma>věřit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1e2892-x2-734">
   <w.rf>
    <LM>w#w-d1e2892-x2-734</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-735">
  <m id="m062-d1t2899-6">
   <w.rf>
    <LM>w#w-d1t2899-6</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2899-4">
   <w.rf>
    <LM>w#w-d1t2899-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2899-2">
   <w.rf>
    <LM>w#w-d1t2899-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2899-8">
   <w.rf>
    <LM>w#w-d1t2899-8</LM>
   </w.rf>
   <form>komunistům</form>
   <lemma>komunista</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m062-d1t2899-9">
   <w.rf>
    <LM>w#w-d1t2899-9</LM>
   </w.rf>
   <form>nedá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-NAP--</tag>
  </m>
  <m id="m062-d1t2899-10">
   <w.rf>
    <LM>w#w-d1t2899-10</LM>
   </w.rf>
   <form>věřit</form>
   <lemma>věřit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1t2899-11">
   <w.rf>
    <LM>w#w-d1t2899-11</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-735-739">
   <w.rf>
    <LM>w#w-735-739</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-740">
  <m id="m062-d1t2899-13">
   <w.rf>
    <LM>w#w-d1t2899-13</LM>
   </w.rf>
   <form>Proto</form>
   <lemma>proto-1_^(proto;_a_proto,_ale_proto,...)</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2899-14">
   <w.rf>
    <LM>w#w-d1t2899-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2899-15">
   <w.rf>
    <LM>w#w-d1t2899-15</LM>
   </w.rf>
   <form>divím</form>
   <lemma>divit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d-id167879-punct">
   <w.rf>
    <LM>w#w-d-id167879-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2901-1">
   <w.rf>
    <LM>w#w-d1t2901-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2901-6">
   <w.rf>
    <LM>w#w-d1t2901-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m062-d1t2901-2">
   <w.rf>
    <LM>w#w-d1t2901-2</LM>
   </w.rf>
   <form>dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2901-3">
   <w.rf>
    <LM>w#w-d1t2901-3</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m062-d1t2901-4">
   <w.rf>
    <LM>w#w-d1t2901-4</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-d1t2901-5">
   <w.rf>
    <LM>w#w-d1t2901-5</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2901-8">
   <w.rf>
    <LM>w#w-d1t2901-8</LM>
   </w.rf>
   <form>volit</form>
   <lemma>volit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-735-737">
   <w.rf>
    <LM>w#w-735-737</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-738">
  <m id="m062-d1t2906-2">
   <w.rf>
    <LM>w#w-d1t2906-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-738-741">
   <w.rf>
    <LM>w#w-738-741</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2906-3">
   <w.rf>
    <LM>w#w-d1t2906-3</LM>
   </w.rf>
   <form>svoboda</form>
   <lemma>svoboda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m062-738-742">
   <w.rf>
    <LM>w#w-738-742</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2906-4">
   <w.rf>
    <LM>w#w-d1t2906-4</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m062-d1t2906-5">
   <w.rf>
    <LM>w#w-d1t2906-5</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-d1t2906-6">
   <w.rf>
    <LM>w#w-d1t2906-6</LM>
   </w.rf>
   <form>volit</form>
   <lemma>volit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-738-743">
   <w.rf>
    <LM>w#w-738-743</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2906-7">
   <w.rf>
    <LM>w#w-d1t2906-7</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m062-d1t2906-8">
   <w.rf>
    <LM>w#w-d1t2906-8</LM>
   </w.rf>
   <form>chce</form>
   <lemma>chtít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-738-744">
   <w.rf>
    <LM>w#w-738-744</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-746">
  <m id="m062-d1t2906-11">
   <w.rf>
    <LM>w#w-d1t2906-11</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m062-d1t2906-10">
   <w.rf>
    <LM>w#w-d1t2906-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2906-12">
   <w.rf>
    <LM>w#w-d1t2906-12</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-746-747">
   <w.rf>
    <LM>w#w-746-747</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-746-748">
   <w.rf>
    <LM>w#w-746-748</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2906-14">
   <w.rf>
    <LM>w#w-d1t2906-14</LM>
   </w.rf>
   <form>Volte</form>
   <lemma>volit</lemma>
   <tag>Vi-P---2--A-I--</tag>
  </m>
  <m id="m062-d1t2906-15">
   <w.rf>
    <LM>w#w-d1t2906-15</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m062-d1t2906-16">
   <w.rf>
    <LM>w#w-d1t2906-16</LM>
   </w.rf>
   <form>chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m062-d-id168248-punct">
   <w.rf>
    <LM>w#w-d-id168248-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-746-749">
   <w.rf>
    <LM>w#w-746-749</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-4_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2906-18">
   <w.rf>
    <LM>w#w-d1t2906-18</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2906-19">
   <w.rf>
    <LM>w#w-d1t2906-19</LM>
   </w.rf>
   <form>komunisty</form>
   <lemma>komunista</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m062-746-750">
   <w.rf>
    <LM>w#w-746-750</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-746-751">
   <w.rf>
    <LM>w#w-746-751</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-752">
  <m id="m062-d1t2910-2">
   <w.rf>
    <LM>w#w-d1t2910-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2910-3">
   <w.rf>
    <LM>w#w-d1t2910-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2910-5">
   <w.rf>
    <LM>w#w-d1t2910-5</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t2910-4">
   <w.rf>
    <LM>w#w-d1t2910-4</LM>
   </w.rf>
   <form>1968</form>
   <lemma>1968</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m062-d-m-d1e2892-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2892-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2911-x2">
  <m id="m062-d1t2914-1">
   <w.rf>
    <LM>w#w-d1t2914-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2914-2">
   <w.rf>
    <LM>w#w-d1t2914-2</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2914-3">
   <w.rf>
    <LM>w#w-d1t2914-3</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1t2914-4">
   <w.rf>
    <LM>w#w-d1t2914-4</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m062-d-m-d1e2911-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2911-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2916-x2">
  <m id="m062-d1t2919-2">
   <w.rf>
    <LM>w#w-d1t2919-2</LM>
   </w.rf>
   <form>Těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m062-d1t2919-3">
   <w.rf>
    <LM>w#w-d1t2919-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2919-4">
   <w.rf>
    <LM>w#w-d1t2919-4</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m062-d-id168606-punct">
   <w.rf>
    <LM>w#w-d-id168606-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2919-6">
   <w.rf>
    <LM>w#w-d1t2919-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2919-7">
   <w.rf>
    <LM>w#w-d1t2919-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t2919-8">
   <w.rf>
    <LM>w#w-d1t2919-8</LM>
   </w.rf>
   <form>spíš</form>
   <lemma>spíš</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2919-9">
   <w.rf>
    <LM>w#w-d1t2919-9</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m062-d1e2916-x2-761">
   <w.rf>
    <LM>w#w-d1e2916-x2-761</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-762">
  <m id="m062-d1t2919-19">
   <w.rf>
    <LM>w#w-d1t2919-19</LM>
   </w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m062-d1t2919-20">
   <w.rf>
    <LM>w#w-d1t2919-20</LM>
   </w.rf>
   <form>začátku</form>
   <lemma>začátek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m062-d1t2919-17">
   <w.rf>
    <LM>w#w-d1t2919-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2919-18">
   <w.rf>
    <LM>w#w-d1t2919-18</LM>
   </w.rf>
   <form>nevěděli</form>
   <lemma>vědět</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m062-762-763">
   <w.rf>
    <LM>w#w-762-763</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2919-21">
   <w.rf>
    <LM>w#w-d1t2919-21</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m062-d1t2919-22">
   <w.rf>
    <LM>w#w-d1t2919-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2919-23">
   <w.rf>
    <LM>w#w-d1t2919-23</LM>
   </w.rf>
   <form>děje</form>
   <lemma>dít-1_^(dít_se)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-762-764">
   <w.rf>
    <LM>w#w-762-764</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-766">
  <m id="m062-d1t2923-2">
   <w.rf>
    <LM>w#w-d1t2923-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2923-1">
   <w.rf>
    <LM>w#w-d1t2923-1</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m062-d1t2923-3">
   <w.rf>
    <LM>w#w-d1t2923-3</LM>
   </w.rf>
   <form>21</form>
   <lemma>21</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m062-d1t2923-4">
   <w.rf>
    <LM>w#w-d1t2923-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m062-766-773">
   <w.rf>
    <LM>w#w-766-773</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-774">
  <m id="m062-d1t2923-7">
   <w.rf>
    <LM>w#w-d1t2923-7</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2923-6">
   <w.rf>
    <LM>w#w-d1t2923-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2923-8">
   <w.rf>
    <LM>w#w-d1t2923-8</LM>
   </w.rf>
   <form>mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m062-d1t2923-9">
   <w.rf>
    <LM>w#w-d1t2923-9</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-774-775">
   <w.rf>
    <LM>w#w-774-775</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-776">
  <m id="m062-d1t2927-1">
   <w.rf>
    <LM>w#w-d1t2927-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2927-2">
   <w.rf>
    <LM>w#w-d1t2927-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2927-4">
   <w.rf>
    <LM>w#w-d1t2927-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m062-d1t2927-5">
   <w.rf>
    <LM>w#w-d1t2927-5</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m062-d1t2927-3">
   <w.rf>
    <LM>w#w-d1t2927-3</LM>
   </w.rf>
   <form>aparát</form>
   <lemma>aparát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-776-777">
   <w.rf>
    <LM>w#w-776-777</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-778">
  <m id="m062-d1t2927-10">
   <w.rf>
    <LM>w#w-d1t2927-10</LM>
   </w.rf>
   <form>Zrovna</form>
   <lemma>zrovna-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2927-8">
   <w.rf>
    <LM>w#w-d1t2927-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2927-9">
   <w.rf>
    <LM>w#w-d1t2927-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m062-d1t2927-11">
   <w.rf>
    <LM>w#w-d1t2927-11</LM>
   </w.rf>
   <form>půjčil</form>
   <lemma>půjčit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t2927-12">
   <w.rf>
    <LM>w#w-d1t2927-12</LM>
   </w.rf>
   <form>ženě</form>
   <lemma>žena</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m062-d-id169174-punct">
   <w.rf>
    <LM>w#w-d-id169174-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2927-14">
   <w.rf>
    <LM>w#w-d1t2927-14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2927-15">
   <w.rf>
    <LM>w#w-d1t2927-15</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m062-d1t2927-16">
   <w.rf>
    <LM>w#w-d1t2927-16</LM>
   </w.rf>
   <form>fotila</form>
   <lemma>fotit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m062-778-779">
   <w.rf>
    <LM>w#w-778-779</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-780">
  <m id="m062-d1t2932-1">
   <w.rf>
    <LM>w#w-d1t2932-1</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2932-2">
   <w.rf>
    <LM>w#w-d1t2932-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2932-3">
   <w.rf>
    <LM>w#w-d1t2932-3</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2932-4">
   <w.rf>
    <LM>w#w-d1t2932-4</LM>
   </w.rf>
   <form>fotil</form>
   <lemma>fotit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-780-781">
   <w.rf>
    <LM>w#w-780-781</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-782">
  <m id="m062-d1t2932-9">
   <w.rf>
    <LM>w#w-d1t2932-9</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2932-16">
   <w.rf>
    <LM>w#w-d1t2932-16</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t2932-17">
   <w.rf>
    <LM>w#w-d1t2932-17</LM>
   </w.rf>
   <form>tohoto</form>
   <lemma>tento</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m062-d1t2932-18">
   <w.rf>
    <LM>w#w-d1t2932-18</LM>
   </w.rf>
   <form>údobí</form>
   <lemma>údobí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m062-d1t2932-10">
   <w.rf>
    <LM>w#w-d1t2932-10</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m062-d1t2932-11">
   <w.rf>
    <LM>w#w-d1t2932-11</LM>
   </w.rf>
   <form>fotek</form>
   <lemma>fotka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m062-782-783">
   <w.rf>
    <LM>w#w-782-783</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-784">
  <m id="m062-d1t2936-1">
   <w.rf>
    <LM>w#w-d1t2936-1</LM>
   </w.rf>
   <form>Jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2936-2">
   <w.rf>
    <LM>w#w-d1t2936-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2936-4">
   <w.rf>
    <LM>w#w-d1t2936-4</LM>
   </w.rf>
   <form>zažil</form>
   <lemma>zažít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-784-799">
   <w.rf>
    <LM>w#w-784-799</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2940-2">
   <w.rf>
    <LM>w#w-d1t2940-2</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2940-1">
   <w.rf>
    <LM>w#w-d1t2940-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2940-3">
   <w.rf>
    <LM>w#w-d1t2940-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t2940-5">
   <w.rf>
    <LM>w#w-d1t2940-5</LM>
   </w.rf>
   <form>Brna</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m062-800-811">
   <w.rf>
    <LM>w#w-800-811</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-832">
  <m id="m062-d1t2943-1">
   <w.rf>
    <LM>w#w-d1t2943-1</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t2943-2">
   <w.rf>
    <LM>w#w-d1t2943-2</LM>
   </w.rf>
   <form>kina</form>
   <lemma>kino</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m062-d1t2943-6">
   <w.rf>
    <LM>w#w-d1t2943-6</LM>
   </w.rf>
   <form>Družba</form>
   <lemma>Družba_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m062-832-833">
   <w.rf>
    <LM>w#w-832-833</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-832-834">
   <w.rf>
    <LM>w#w-832-834</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2943-8">
   <w.rf>
    <LM>w#w-d1t2943-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-d1t2943-9">
   <w.rf>
    <LM>w#w-d1t2943-9</LM>
   </w.rf>
   <form>divadlo</form>
   <lemma>divadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m062-832-835">
   <w.rf>
    <LM>w#w-832-835</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2945-2">
   <w.rf>
    <LM>w#w-d1t2945-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2945-5">
   <w.rf>
    <LM>w#w-d1t2945-5</LM>
   </w.rf>
   <form>tramvajáři</form>
   <lemma>tramvajář_,l</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m062-d1t2945-6">
   <w.rf>
    <LM>w#w-d1t2945-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2945-8">
   <w.rf>
    <LM>w#w-d1t2945-8</LM>
   </w.rf>
   <form>autaři</form>
   <lemma>autař</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m062-d1t2945-3">
   <w.rf>
    <LM>w#w-d1t2945-3</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2945-10">
   <w.rf>
    <LM>w#w-d1t2945-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2945-11">
   <w.rf>
    <LM>w#w-d1t2945-11</LM>
   </w.rf>
   <form>udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2945-12">
   <w.rf>
    <LM>w#w-d1t2945-12</LM>
   </w.rf>
   <form>barikádu</form>
   <lemma>barikáda</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m062-832-836">
   <w.rf>
    <LM>w#w-832-836</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-837">
  <m id="m062-d1t2949-1">
   <w.rf>
    <LM>w#w-d1t2949-1</LM>
   </w.rf>
   <form>Chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-d1t2949-3">
   <w.rf>
    <LM>w#w-d1t2949-3</LM>
   </w.rf>
   <form>zamezit</form>
   <lemma>zamezit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m062-837-763">
   <w.rf>
    <LM>w#w-837-763</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m062-d-id170060-punct">
   <w.rf>
    <LM>w#w-d-id170060-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2949-5">
   <w.rf>
    <LM>w#w-d1t2949-5</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2949-8">
   <w.rf>
    <LM>w#w-d1t2949-8</LM>
   </w.rf>
   <form>ruský</form>
   <lemma>ruský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m062-d1t2949-7">
   <w.rf>
    <LM>w#w-d1t2949-7</LM>
   </w.rf>
   <form>transportér</form>
   <lemma>transportér</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t2949-10">
   <w.rf>
    <LM>w#w-d1t2949-10</LM>
   </w.rf>
   <form>projel</form>
   <lemma>projet_^(např._autem)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t2949-11">
   <w.rf>
    <LM>w#w-d1t2949-11</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-837-838">
   <w.rf>
    <LM>w#w-837-838</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-839">
  <m id="m062-d1t2953-2">
   <w.rf>
    <LM>w#w-d1t2953-2</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d-id170226-punct">
   <w.rf>
    <LM>w#w-d-id170226-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2953-4">
   <w.rf>
    <LM>w#w-d1t2953-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2956-1">
   <w.rf>
    <LM>w#w-d1t2956-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2956-2">
   <w.rf>
    <LM>w#w-d1t2956-2</LM>
   </w.rf>
   <form>dali</form>
   <lemma>dát-1</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2956-3">
   <w.rf>
    <LM>w#w-d1t2956-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNP4---------5</tag>
  </m>
  <m id="m062-d1t2956-4">
   <w.rf>
    <LM>w#w-d1t2956-4</LM>
   </w.rf>
   <form>auta</form>
   <lemma>auto</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m062-839-840">
   <w.rf>
    <LM>w#w-839-840</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-841">
  <m id="m062-d1t2956-10">
   <w.rf>
    <LM>w#w-d1t2956-10</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m062-d1t2956-11">
   <w.rf>
    <LM>w#w-d1t2956-11</LM>
   </w.rf>
   <form>transportér</form>
   <lemma>transportér</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t2956-12">
   <w.rf>
    <LM>w#w-d1t2956-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m062-d1t2956-13">
   <w.rf>
    <LM>w#w-d1t2956-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m062-d1t2956-14">
   <w.rf>
    <LM>w#w-d1t2956-14</LM>
   </w.rf>
   <form>najel</form>
   <lemma>najet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-841-855">
   <w.rf>
    <LM>w#w-841-855</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2956-18">
   <w.rf>
    <LM>w#w-d1t2956-18</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m062-d1t2956-19">
   <w.rf>
    <LM>w#w-d1t2956-19</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2956-21">
   <w.rf>
    <LM>w#w-d1t2956-21</LM>
   </w.rf>
   <form>dlažební</form>
   <lemma>dlažební</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m062-d1t2956-22">
   <w.rf>
    <LM>w#w-d1t2956-22</LM>
   </w.rf>
   <form>kostky</form>
   <lemma>kostka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m062-d1t2956-23">
   <w.rf>
    <LM>w#w-d1t2956-23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2956-24">
   <w.rf>
    <LM>w#w-d1t2956-24</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2956-25">
   <w.rf>
    <LM>w#w-d1t2956-25</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m062-d1t2956-26">
   <w.rf>
    <LM>w#w-d1t2956-26</LM>
   </w.rf>
   <form>něm</form>
   <lemma>on-1</lemma>
   <tag>PEZS6--3-------</tag>
  </m>
  <m id="m062-d1t2956-27">
   <w.rf>
    <LM>w#w-d1t2956-27</LM>
   </w.rf>
   <form>házet</form>
   <lemma>házet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1e2916-x4-856">
   <w.rf>
    <LM>w#w-d1e2916-x4-856</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-857">
  <m id="m062-d1t2958-3">
   <w.rf>
    <LM>w#w-d1t2958-3</LM>
   </w.rf>
   <form>Transportér</form>
   <lemma>transportér</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t2958-5">
   <w.rf>
    <LM>w#w-d1t2958-5</LM>
   </w.rf>
   <form>sklopil</form>
   <lemma>sklopit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t2964-1">
   <w.rf>
    <LM>w#w-d1t2964-1</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDNP4----------</tag>
  </m>
  <m id="m062-d1t2964-3">
   <w.rf>
    <LM>w#w-d1t2964-3</LM>
   </w.rf>
   <form>železná</form>
   <lemma>železný</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m062-d1t2962-5">
   <w.rf>
    <LM>w#w-d1t2962-5</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m062-857-861">
   <w.rf>
    <LM>w#w-857-861</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2964-8">
   <w.rf>
    <LM>w#w-d1t2964-8</LM>
   </w.rf>
   <form>nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t2964-12">
   <w.rf>
    <LM>w#w-d1t2964-12</LM>
   </w.rf>
   <form>průřezy</form>
   <lemma>průřez</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m062-d1t2966-1">
   <w.rf>
    <LM>w#w-d1t2966-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2966-2">
   <w.rf>
    <LM>w#w-d1t2966-2</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t2966-6">
   <w.rf>
    <LM>w#w-d1t2966-6</LM>
   </w.rf>
   <form>točit</form>
   <lemma>točit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1t2966-4">
   <w.rf>
    <LM>w#w-d1t2966-4</LM>
   </w.rf>
   <form>kulometem</form>
   <lemma>kulomet</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m062-d1t2966-7">
   <w.rf>
    <LM>w#w-d1t2966-7</LM>
   </w.rf>
   <form>dokola</form>
   <lemma>dokola</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-857-862">
   <w.rf>
    <LM>w#w-857-862</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-863">
  <m id="m062-d1t2966-11">
   <w.rf>
    <LM>w#w-d1t2966-11</LM>
   </w.rf>
   <form>Lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m062-d1t2966-12">
   <w.rf>
    <LM>w#w-d1t2966-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2966-13">
   <w.rf>
    <LM>w#w-d1t2966-13</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2966-14">
   <w.rf>
    <LM>w#w-d1t2966-14</LM>
   </w.rf>
   <form>rozprchávat</form>
   <lemma>rozprchávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-863-864">
   <w.rf>
    <LM>w#w-863-864</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-868">
  <m id="m062-d1t2971-5">
   <w.rf>
    <LM>w#w-d1t2971-5</LM>
   </w.rf>
   <form>Nevěděl</form>
   <lemma>vědět</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m062-d1t2971-4">
   <w.rf>
    <LM>w#w-d1t2971-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-868-872">
   <w.rf>
    <LM>w#w-868-872</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2971-6">
   <w.rf>
    <LM>w#w-d1t2971-6</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2971-7">
   <w.rf>
    <LM>w#w-d1t2971-7</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2971-8">
   <w.rf>
    <LM>w#w-d1t2971-8</LM>
   </w.rf>
   <form>rychle</form>
   <lemma>rychle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m062-d1t2971-9">
   <w.rf>
    <LM>w#w-d1t2971-9</LM>
   </w.rf>
   <form>utéct</form>
   <lemma>utéci</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m062-868-874">
   <w.rf>
    <LM>w#w-868-874</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2971-19">
   <w.rf>
    <LM>w#w-d1t2971-19</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2971-20">
   <w.rf>
    <LM>w#w-d1t2971-20</LM>
   </w.rf>
   <form>bude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-AAI--</tag>
  </m>
  <m id="m062-d1t2971-21">
   <w.rf>
    <LM>w#w-d1t2971-21</LM>
   </w.rf>
   <form>střílet</form>
   <lemma>střílet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d1t2971-22">
   <w.rf>
    <LM>w#w-d1t2971-22</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2971-23">
   <w.rf>
    <LM>w#w-d1t2971-23</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m062-868-875">
   <w.rf>
    <LM>w#w-868-875</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-876">
  <m id="m062-d1t2973-2">
   <w.rf>
    <LM>w#w-d1t2973-2</LM>
   </w.rf>
   <form>Stoupl</form>
   <lemma>stoupnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m062-d1t2973-3">
   <w.rf>
    <LM>w#w-d1t2973-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2973-4">
   <w.rf>
    <LM>w#w-d1t2973-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m062-d1t2973-5">
   <w.rf>
    <LM>w#w-d1t2973-5</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m062-d1t2975-1">
   <w.rf>
    <LM>w#w-d1t2975-1</LM>
   </w.rf>
   <form>sloup</form>
   <lemma>sloup</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-d-id171626-punct">
   <w.rf>
    <LM>w#w-d-id171626-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2977-1">
   <w.rf>
    <LM>w#w-d1t2977-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m062-d1t2977-2">
   <w.rf>
    <LM>w#w-d1t2977-2</LM>
   </w.rf>
   <form>držel</form>
   <lemma>držet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t2979-1">
   <w.rf>
    <LM>w#w-d1t2979-1</LM>
   </w.rf>
   <form>elektrické</form>
   <lemma>elektrický</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m062-d1t2979-2">
   <w.rf>
    <LM>w#w-d1t2979-2</LM>
   </w.rf>
   <form>vedení</form>
   <lemma>vedení_^(*5ést)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m062-876-811">
   <w.rf>
    <LM>w#w-876-811</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-876-812">
   <w.rf>
    <LM>w#w-876-812</LM>
   </w.rf>
   <form>elektriky</form>
   <lemma>elektrika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m062-d1e2916-x5-886">
   <w.rf>
    <LM>w#w-d1e2916-x5-886</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-887">
  <m id="m062-d1t2979-9">
   <w.rf>
    <LM>w#w-d1t2979-9</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m062-d1t2979-11">
   <w.rf>
    <LM>w#w-d1t2979-11</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m062-d1t2979-7">
   <w.rf>
    <LM>w#w-d1t2979-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t2979-8">
   <w.rf>
    <LM>w#w-d1t2979-8</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m062-d1t2979-6">
   <w.rf>
    <LM>w#w-d1t2979-6</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m062-887-799">
   <w.rf>
    <LM>w#w-887-799</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2979-13">
   <w.rf>
    <LM>w#w-d1t2979-13</LM>
   </w.rf>
   <form>šalina</form>
   <lemma>šalina_,l</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m062-887-800">
   <w.rf>
    <LM>w#w-887-800</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d-m-d1e2916-x5-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2916-x5-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2980-x2">
  <m id="m062-d1t2987-2">
   <w.rf>
    <LM>w#w-d1t2987-2</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2987-3">
   <w.rf>
    <LM>w#w-d1t2987-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t2987-4">
   <w.rf>
    <LM>w#w-d1t2987-4</LM>
   </w.rf>
   <form>stál</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1e2980-x2-891">
   <w.rf>
    <LM>w#w-d1e2980-x2-891</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2987-9">
   <w.rf>
    <LM>w#w-d1t2987-9</LM>
   </w.rf>
   <form>čekal</form>
   <lemma>čekat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1e2980-x2-892">
   <w.rf>
    <LM>w#w-d1e2980-x2-892</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-894">
  <m id="m062-d1t2987-11">
   <w.rf>
    <LM>w#w-d1t2987-11</LM>
   </w.rf>
   <form>Kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t2987-13">
   <w.rf>
    <LM>w#w-d1t2987-13</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m062-d1t2987-14">
   <w.rf>
    <LM>w#w-d1t2987-14</LM>
   </w.rf>
   <form>střílet</form>
   <lemma>střílet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m062-d-id172152-punct">
   <w.rf>
    <LM>w#w-d-id172152-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t2989-1">
   <w.rf>
    <LM>w#w-d1t2989-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t2989-2">
   <w.rf>
    <LM>w#w-d1t2989-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m062-d1t2989-3">
   <w.rf>
    <LM>w#w-d1t2989-3</LM>
   </w.rf>
   <form>prostřelí</form>
   <lemma>prostřelit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m062-d1t2989-4">
   <w.rf>
    <LM>w#w-d1t2989-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m062-d1t2989-6">
   <w.rf>
    <LM>w#w-d1t2989-6</LM>
   </w.rf>
   <form>sloupem</form>
   <lemma>sloup</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m062-894-895">
   <w.rf>
    <LM>w#w-894-895</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t2989-7">
   <w.rf>
    <LM>w#w-d1t2989-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m062-d1t2989-8">
   <w.rf>
    <LM>w#w-d1t2989-8</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m062-d-m-d1e2980-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2980-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2995-x2">
  <m id="m062-d1t2998-1">
   <w.rf>
    <LM>w#w-d1t2998-1</LM>
   </w.rf>
   <form>Naštěstí</form>
   <lemma>naštěstí</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t2998-2">
   <w.rf>
    <LM>w#w-d1t2998-2</LM>
   </w.rf>
   <form>nestříleli</form>
   <lemma>střílet</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m062-d1e2995-x2-904">
   <w.rf>
    <LM>w#w-d1e2995-x2-904</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-907">
  <m id="m062-d1t3002-2">
   <w.rf>
    <LM>w#w-d1t3002-2</LM>
   </w.rf>
   <form>Transportér</form>
   <lemma>transportér</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m062-d1t3002-3">
   <w.rf>
    <LM>w#w-d1t3002-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t3002-4">
   <w.rf>
    <LM>w#w-d1t3002-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m062-d1t3002-5">
   <w.rf>
    <LM>w#w-d1t3002-5</LM>
   </w.rf>
   <form>sjel</form>
   <lemma>sjet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m062-d1t3004-2">
   <w.rf>
    <LM>w#w-d1t3004-2</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t3004-3">
   <w.rf>
    <LM>w#w-d1t3004-3</LM>
   </w.rf>
   <form>pokračovali</form>
   <lemma>pokračovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-d1t3004-4">
   <w.rf>
    <LM>w#w-d1t3004-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-909-910">
   <w.rf>
    <LM>w#w-909-910</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-911">
  <m id="m062-d1t3006-1">
   <w.rf>
    <LM>w#w-d1t3006-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3006-2">
   <w.rf>
    <LM>w#w-d1t3006-2</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m062-d1t3006-3">
   <w.rf>
    <LM>w#w-d1t3006-3</LM>
   </w.rf>
   <form>přijet</form>
   <lemma>přijet</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m062-d1t3006-5">
   <w.rf>
    <LM>w#w-d1t3006-5</LM>
   </w.rf>
   <form>tanky</form>
   <lemma>tank</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m062-911-919">
   <w.rf>
    <LM>w#w-911-919</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3009-1">
   <w.rf>
    <LM>w#w-d1t3009-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-911-920">
   <w.rf>
    <LM>w#w-911-920</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t3009-3">
   <w.rf>
    <LM>w#w-d1t3009-3</LM>
   </w.rf>
   <form>lidi</form>
   <lemma>lidé</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m062-d1t3009-2">
   <w.rf>
    <LM>w#w-d1t3009-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3009-4">
   <w.rf>
    <LM>w#w-d1t3009-4</LM>
   </w.rf>
   <form>srocovali</form>
   <lemma>srocovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-911-921">
   <w.rf>
    <LM>w#w-911-921</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-922">
  <m id="m062-d1t3011-3">
   <w.rf>
    <LM>w#w-d1t3011-3</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3011-2">
   <w.rf>
    <LM>w#w-d1t3011-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t3011-6">
   <w.rf>
    <LM>w#w-d1t3011-6</LM>
   </w.rf>
   <form>skoro</form>
   <lemma>skoro</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3011-4">
   <w.rf>
    <LM>w#w-d1t3011-4</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m062-d1t3011-5">
   <w.rf>
    <LM>w#w-d1t3011-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-d1t3011-7">
   <w.rf>
    <LM>w#w-d1t3011-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m062-d1t3011-9">
   <w.rf>
    <LM>w#w-d1t3011-9</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m062-922-923">
   <w.rf>
    <LM>w#w-922-923</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-924">
  <m id="m062-d1t3013-1">
   <w.rf>
    <LM>w#w-d1t3013-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t3013-2">
   <w.rf>
    <LM>w#w-d1t3013-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t3013-3">
   <w.rf>
    <LM>w#w-d1t3013-3</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3013-4">
   <w.rf>
    <LM>w#w-d1t3013-4</LM>
   </w.rf>
   <form>možnost</form>
   <lemma>možnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m062-924-928">
   <w.rf>
    <LM>w#w-924-928</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3013-12">
   <w.rf>
    <LM>w#w-d1t3013-12</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t3013-13">
   <w.rf>
    <LM>w#w-d1t3013-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-924-929">
   <w.rf>
    <LM>w#w-924-929</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3013-18">
   <w.rf>
    <LM>w#w-d1t3013-18</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m062-d1t3013-20">
   <w.rf>
    <LM>w#w-d1t3013-20</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m062-924-925">
   <w.rf>
    <LM>w#w-924-925</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-926">
  <m id="m062-d1t3013-8">
   <w.rf>
    <LM>w#w-d1t3013-8</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3013-7">
   <w.rf>
    <LM>w#w-d1t3013-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t3013-9">
   <w.rf>
    <LM>w#w-d1t3013-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3013-10">
   <w.rf>
    <LM>w#w-d1t3013-10</LM>
   </w.rf>
   <form>nemocen</form>
   <lemma>nemocný-2_^(vlastnost)</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m062-926-927">
   <w.rf>
    <LM>w#w-926-927</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-930">
  <m id="m062-d1t3017-2">
   <w.rf>
    <LM>w#w-d1t3017-2</LM>
   </w.rf>
   <form>Prožíval</form>
   <lemma>prožívat_^(*3t)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3017-3">
   <w.rf>
    <LM>w#w-d1t3017-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1t3017-4">
   <w.rf>
    <LM>w#w-d1t3017-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m062-d1t3017-5">
   <w.rf>
    <LM>w#w-d1t3017-5</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m062-d1t3017-6">
   <w.rf>
    <LM>w#w-d1t3017-6</LM>
   </w.rf>
   <form>intenzivně</form>
   <lemma>intenzivně_^(^DD**intenzívně)_(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m062-930-931">
   <w.rf>
    <LM>w#w-930-931</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2995-x3">
  <m id="m062-d1t3024-1">
   <w.rf>
    <LM>w#w-d1t3024-1</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3024-2">
   <w.rf>
    <LM>w#w-d1t3024-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m062-d1t3024-3">
   <w.rf>
    <LM>w#w-d1t3024-3</LM>
   </w.rf>
   <form>pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d-id173403-punct">
   <w.rf>
    <LM>w#w-d-id173403-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3024-5">
   <w.rf>
    <LM>w#w-d1t3024-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m062-d1t3024-8">
   <w.rf>
    <LM>w#w-d1t3024-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3024-9">
   <w.rf>
    <LM>w#w-d1t3024-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3024-12">
   <w.rf>
    <LM>w#w-d1t3024-12</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t3024-13">
   <w.rf>
    <LM>w#w-d1t3024-13</LM>
   </w.rf>
   <form>nádraží</form>
   <lemma>nádraží</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m062-d1t3024-11">
   <w.rf>
    <LM>w#w-d1t3024-11</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-d1t3024-14">
   <w.rf>
    <LM>w#w-d1t3024-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t3024-16">
   <w.rf>
    <LM>w#w-d1t3024-16</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3024-18">
   <w.rf>
    <LM>w#w-d1t3024-18</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m062-d1t3024-19">
   <w.rf>
    <LM>w#w-d1t3024-19</LM>
   </w.rf>
   <form>fotil</form>
   <lemma>fotit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1e2995-x3-946">
   <w.rf>
    <LM>w#w-d1e2995-x3-946</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-949">
  <m id="m062-d1t3028-2">
   <w.rf>
    <LM>w#w-d1t3028-2</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m062-d1t3028-3">
   <w.rf>
    <LM>w#w-d1t3028-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m062-d1t3028-4">
   <w.rf>
    <LM>w#w-d1t3028-4</LM>
   </w.rf>
   <form>mladý</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m062-d1t3028-5">
   <w.rf>
    <LM>w#w-d1t3028-5</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-949-956">
   <w.rf>
    <LM>w#w-949-956</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3028-6">
   <w.rf>
    <LM>w#w-d1t3028-6</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t3028-7">
   <w.rf>
    <LM>w#w-d1t3028-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t3028-8">
   <w.rf>
    <LM>w#w-d1t3028-8</LM>
   </w.rf>
   <form>patnáctiletý</form>
   <lemma>patnáctiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m062-949-958">
   <w.rf>
    <LM>w#w-949-958</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3028-10">
   <w.rf>
    <LM>w#w-d1t3028-10</LM>
   </w.rf>
   <form>šestnáctiletý</form>
   <lemma>šestnáctiletý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m062-d1t3028-11">
   <w.rf>
    <LM>w#w-d1t3028-11</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-949-959">
   <w.rf>
    <LM>w#w-949-959</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-961">
  <m id="m062-d1t3032-17">
   <w.rf>
    <LM>w#w-d1t3032-17</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m062-d1t3032-16">
   <w.rf>
    <LM>w#w-d1t3032-16</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3032-12">
   <w.rf>
    <LM>w#w-d1t3032-12</LM>
   </w.rf>
   <form>nějací</form>
   <lemma>nějaký</lemma>
   <tag>PZMP1----------</tag>
  </m>
  <m id="m062-d1t3032-14">
   <w.rf>
    <LM>w#w-d1t3032-14</LM>
   </w.rf>
   <form>Rusi</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m062-961-962">
   <w.rf>
    <LM>w#w-961-962</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-963">
  <m id="m062-d1t3032-4">
   <w.rf>
    <LM>w#w-d1t3032-4</LM>
   </w.rf>
   <form>Rus</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m062-d1t3032-6">
   <w.rf>
    <LM>w#w-d1t3032-6</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m062-d1t3032-7">
   <w.rf>
    <LM>w#w-d1t3032-7</LM>
   </w.rf>
   <form>němu</form>
   <lemma>on-1</lemma>
   <tag>PEZS3--3------1</tag>
  </m>
  <m id="m062-d1t3032-8">
   <w.rf>
    <LM>w#w-d1t3032-8</LM>
   </w.rf>
   <form>přiběhl</form>
   <lemma>přiběhnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m062-d1t3035-1">
   <w.rf>
    <LM>w#w-d1t3035-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t3035-2">
   <w.rf>
    <LM>w#w-d1t3035-2</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m062-d1t3035-3">
   <w.rf>
    <LM>w#w-d1t3035-3</LM>
   </w.rf>
   <form>fotoaparát</form>
   <lemma>fotoaparát</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-d1t3035-4">
   <w.rf>
    <LM>w#w-d1t3035-4</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m062-d1t3035-6">
   <w.rf>
    <LM>w#w-d1t3035-6</LM>
   </w.rf>
   <form>vytrhl</form>
   <lemma>vytrhnout</lemma>
   <tag>VpYS----R-AAP-1</tag>
  </m>
  <m id="m062-d1t3035-7">
   <w.rf>
    <LM>w#w-d1t3035-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t3035-8">
   <w.rf>
    <LM>w#w-d1t3035-8</LM>
   </w.rf>
   <form>ruky</form>
   <lemma>ruka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m062-963-964">
   <w.rf>
    <LM>w#w-963-964</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-965">
  <m id="m062-d1t3037-6">
   <w.rf>
    <LM>w#w-d1t3037-6</LM>
   </w.rf>
   <form>U</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m062-d1t3037-8">
   <w.rf>
    <LM>w#w-d1t3037-8</LM>
   </w.rf>
   <form>stánků</form>
   <lemma>stánek</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m062-d1t3037-9">
   <w.rf>
    <LM>w#w-d1t3037-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m062-d1t3037-11">
   <w.rf>
    <LM>w#w-d1t3037-11</LM>
   </w.rf>
   <form>pivem</form>
   <lemma>pivo</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m062-d1t3037-3">
   <w.rf>
    <LM>w#w-d1t3037-3</LM>
   </w.rf>
   <form>stála</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m062-d1t3037-4">
   <w.rf>
    <LM>w#w-d1t3037-4</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m062-d1t3037-5">
   <w.rf>
    <LM>w#w-d1t3037-5</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m062-d1t3039-1">
   <w.rf>
    <LM>w#w-d1t3039-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m062-d1t3039-2">
   <w.rf>
    <LM>w#w-d1t3039-2</LM>
   </w.rf>
   <form>nikdo</form>
   <lemma>nikdo</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m062-d1t3039-3">
   <w.rf>
    <LM>w#w-d1t3039-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m062-d1t3039-4">
   <w.rf>
    <LM>w#w-d1t3039-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t3039-5">
   <w.rf>
    <LM>w#w-d1t3039-5</LM>
   </w.rf>
   <form>nehnul</form>
   <lemma>hnout</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m062-965-978">
   <w.rf>
    <LM>w#w-965-978</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m062-d1e2995-x4">
  <m id="m062-d1t3041-3">
   <w.rf>
    <LM>w#w-d1t3041-3</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m062-d1e2995-x4-979">
   <w.rf>
    <LM>w#w-d1e2995-x4-979</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1e2995-x4-980">
   <w.rf>
    <LM>w#w-d1e2995-x4-980</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m062-d1t3041-4">
   <w.rf>
    <LM>w#w-d1t3041-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m062-d1t3041-5">
   <w.rf>
    <LM>w#w-d1t3041-5</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m062-d1t3041-6">
   <w.rf>
    <LM>w#w-d1t3041-6</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m062-d1t3041-7">
   <w.rf>
    <LM>w#w-d1t3041-7</LM>
   </w.rf>
   <form>necháte</form>
   <lemma>nechat</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m062-d1t3041-8">
   <w.rf>
    <LM>w#w-d1t3041-8</LM>
   </w.rf>
   <form>takhle</form>
   <lemma>takhle</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m062-d1t3041-10">
   <w.rf>
    <LM>w#w-d1t3041-10</LM>
   </w.rf>
   <form>ožebračit</form>
   <lemma>ožebračit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m062-d1t3041-11">
   <w.rf>
    <LM>w#w-d1t3041-11</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m062-d1e2995-x4-983">
   <w.rf>
    <LM>w#w-d1e2995-x4-983</LM>
   </w.rf>
   <form>foťák</form>
   <lemma>foťák_,h</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m062-d1e2995-x4-982">
   <w.rf>
    <LM>w#w-d1e2995-x4-982</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
