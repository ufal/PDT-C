<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="pk_040.03.w.gz" />
  </references>
 </head>
 <s id="m040-d1e761-x3">
  <m id="m040-d1t779-4">
   <w.rf>
    <LM>w#w-d1t779-4</LM>
   </w.rf>
   <form>Představila</form>
   <lemma>představit-1_^(si_něco;_něco/někoho_někomu)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d1t779-2">
   <w.rf>
    <LM>w#w-d1t779-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1e761-x3-291">
   <w.rf>
    <LM>w#w-d1e761-x3-291</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P4--1-------</tag>
  </m>
  <m id="m040-d-id78564-punct">
   <w.rf>
    <LM>w#w-d-id78564-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t779-6">
   <w.rf>
    <LM>w#w-d1t779-6</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t779-7">
   <w.rf>
    <LM>w#w-d1t779-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t779-8">
   <w.rf>
    <LM>w#w-d1t779-8</LM>
   </w.rf>
   <form>jmenujeme</form>
   <lemma>jmenovat</lemma>
   <tag>VB-P---1P-AAB--</tag>
  </m>
  <m id="m040-d1e761-x3-414">
   <w.rf>
    <LM>w#w-d1e761-x3-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-415">
  <m id="m040-d1t779-10">
   <w.rf>
    <LM>w#w-d1t779-10</LM>
   </w.rf>
   <form>Manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t779-11">
   <w.rf>
    <LM>w#w-d1t779-11</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m040-d1t779-12">
   <w.rf>
    <LM>w#w-d1t779-12</LM>
   </w.rf>
   <form>řekl</form>
   <lemma>říci</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m040-415-416">
   <w.rf>
    <LM>w#w-415-416</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1e761-x3-412">
   <w.rf>
    <LM>w#w-d1e761-x3-412</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t779-14">
   <w.rf>
    <LM>w#w-d1t779-14</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1e761-x3-413">
   <w.rf>
    <LM>w#w-d1e761-x3-413</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-415-260">
   <w.rf>
    <LM>w#w-415-260</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-264">
  <m id="m040-d1t779-17">
   <w.rf>
    <LM>w#w-d1t779-17</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m040-d1t779-18">
   <w.rf>
    <LM>w#w-d1t779-18</LM>
   </w.rf>
   <form>říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1e761-x3-407">
   <w.rf>
    <LM>w#w-d1e761-x3-407</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1e761-x3-408">
   <w.rf>
    <LM>w#w-d1e761-x3-408</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t779-21">
   <w.rf>
    <LM>w#w-d1t779-21</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t779-22">
   <w.rf>
    <LM>w#w-d1t779-22</LM>
   </w.rf>
   <form>Gott</form>
   <lemma>Gott_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-264-265">
   <w.rf>
    <LM>w#w-264-265</LM>
   </w.rf>
   <form>!</form>
   <lemma>!</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1e761-x3-410">
   <w.rf>
    <LM>w#w-d1e761-x3-410</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-271">
  <m id="m040-d1t779-27">
   <w.rf>
    <LM>w#w-d1t779-27</LM>
   </w.rf>
   <form>Znají</form>
   <lemma>znát</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m040-d1t779-26">
   <w.rf>
    <LM>w#w-d1t779-26</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t779-28">
   <w.rf>
    <LM>w#w-d1t779-28</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t779-29">
   <w.rf>
    <LM>w#w-d1t779-29</LM>
   </w.rf>
   <form>našeho</form>
   <lemma>náš</lemma>
   <tag>PSMS4-P1-------</tag>
  </m>
  <m id="m040-d1t779-31">
   <w.rf>
    <LM>w#w-d1t779-31</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m040-d1t779-32">
   <w.rf>
    <LM>w#w-d1t779-32</LM>
   </w.rf>
   <form>Gotta</form>
   <lemma>Gott_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m040-d-m-d1e761-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e761-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e792-x2">
  <m id="m040-d1t799-2">
   <w.rf>
    <LM>w#w-d1t799-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t799-3">
   <w.rf>
    <LM>w#w-d1t799-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t799-5">
   <w.rf>
    <LM>w#w-d1t799-5</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m040-d1t799-6">
   <w.rf>
    <LM>w#w-d1t799-6</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m040-32-33">
   <w.rf>
    <LM>w#w-32-33</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-34">
  <m id="m040-d1t799-9">
   <w.rf>
    <LM>w#w-d1t799-9</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t799-7">
   <w.rf>
    <LM>w#w-d1t799-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t799-8">
   <w.rf>
    <LM>w#w-d1t799-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t799-10">
   <w.rf>
    <LM>w#w-d1t799-10</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t799-11">
   <w.rf>
    <LM>w#w-d1t799-11</LM>
   </w.rf>
   <form>obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d-id79273-punct">
   <w.rf>
    <LM>w#w-d-id79273-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t799-13">
   <w.rf>
    <LM>w#w-d1t799-13</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t799-14">
   <w.rf>
    <LM>w#w-d1t799-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t799-15">
   <w.rf>
    <LM>w#w-d1t799-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t799-16">
   <w.rf>
    <LM>w#w-d1t799-16</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t799-18">
   <w.rf>
    <LM>w#w-d1t799-18</LM>
   </w.rf>
   <form>jednoho</form>
   <lemma>jeden`1</lemma>
   <tag>CnZS2----------</tag>
  </m>
  <m id="m040-d1t799-19">
   <w.rf>
    <LM>w#w-d1t799-19</LM>
   </w.rf>
   <form>krámku</form>
   <lemma>krámek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m040-d1t799-20">
   <w.rf>
    <LM>w#w-d1t799-20</LM>
   </w.rf>
   <form>zašli</form>
   <lemma>zajít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-34-35">
   <w.rf>
    <LM>w#w-34-35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-36">
  <m id="m040-d1t801-4">
   <w.rf>
    <LM>w#w-d1t801-4</LM>
   </w.rf>
   <form>Uvařili</form>
   <lemma>uvařit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t801-2">
   <w.rf>
    <LM>w#w-d1t801-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m040-d1t801-3">
   <w.rf>
    <LM>w#w-d1t801-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t801-5">
   <w.rf>
    <LM>w#w-d1t801-5</LM>
   </w.rf>
   <form>výborný</form>
   <lemma>výborný</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m040-d1t801-6">
   <w.rf>
    <LM>w#w-d1t801-6</LM>
   </w.rf>
   <form>čaj</form>
   <lemma>čaj</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-36-37">
   <w.rf>
    <LM>w#w-36-37</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-38">
  <m id="m040-d1t803-3">
   <w.rf>
    <LM>w#w-d1t803-3</LM>
   </w.rf>
   <form>Paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t806-7">
   <w.rf>
    <LM>w#w-d1t806-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t803-4">
   <w.rf>
    <LM>w#w-d1t803-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-38-286">
   <w.rf>
    <LM>w#w-38-286</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t803-6">
   <w.rf>
    <LM>w#w-d1t803-6</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m040-d-id79604-punct">
   <w.rf>
    <LM>w#w-d-id79604-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t803-8">
   <w.rf>
    <LM>w#w-d1t803-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t803-9">
   <w.rf>
    <LM>w#w-d1t803-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t803-10">
   <w.rf>
    <LM>w#w-d1t803-10</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m040-d1t803-11">
   <w.rf>
    <LM>w#w-d1t803-11</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-38-288">
   <w.rf>
    <LM>w#w-38-288</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t806-6">
   <w.rf>
    <LM>w#w-d1t806-6</LM>
   </w.rf>
   <form>dohadovala</form>
   <lemma>dohadovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t806-8">
   <w.rf>
    <LM>w#w-d1t806-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t806-10">
   <w.rf>
    <LM>w#w-d1t806-10</LM>
   </w.rf>
   <form>prodávajícím</form>
   <lemma>prodávající-2</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m040-d1t808-1">
   <w.rf>
    <LM>w#w-d1t808-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t808-2">
   <w.rf>
    <LM>w#w-d1t808-2</LM>
   </w.rf>
   <form>ceně</form>
   <lemma>cena</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t808-4">
   <w.rf>
    <LM>w#w-d1t808-4</LM>
   </w.rf>
   <form>obrázku</form>
   <lemma>obrázek</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m040-38-41">
   <w.rf>
    <LM>w#w-38-41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-42">
  <m id="m040-d1t810-4">
   <w.rf>
    <LM>w#w-d1t810-4</LM>
   </w.rf>
   <form>Šel</form>
   <lemma>Šel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1t808-8">
   <w.rf>
    <LM>w#w-d1t808-8</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m040-d1t808-7">
   <w.rf>
    <LM>w#w-d1t808-7</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t808-9">
   <w.rf>
    <LM>w#w-d1t808-9</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t810-3">
   <w.rf>
    <LM>w#w-d1t810-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t810-5">
   <w.rf>
    <LM>w#w-d1t810-5</LM>
   </w.rf>
   <form>dolů</form>
   <lemma>dolů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t810-6">
   <w.rf>
    <LM>w#w-d1t810-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t810-7">
   <w.rf>
    <LM>w#w-d1t810-7</LM>
   </w.rf>
   <form>cenou</form>
   <lemma>cena</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m040-d1t810-8">
   <w.rf>
    <LM>w#w-d1t810-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t810-9">
   <w.rf>
    <LM>w#w-d1t810-9</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m040-d1t810-10">
   <w.rf>
    <LM>w#w-d1t810-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t810-13">
   <w.rf>
    <LM>w#w-d1t810-13</LM>
   </w.rf>
   <form>ten</form>
   <lemma>ten</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m040-d1t810-14">
   <w.rf>
    <LM>w#w-d1t810-14</LM>
   </w.rf>
   <form>obrázek</form>
   <lemma>obrázek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d1t810-12">
   <w.rf>
    <LM>w#w-d1t810-12</LM>
   </w.rf>
   <form>nevzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m040-42-44">
   <w.rf>
    <LM>w#w-42-44</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-45">
  <m id="m040-d1t814-2">
   <w.rf>
    <LM>w#w-d1t814-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t814-3">
   <w.rf>
    <LM>w#w-d1t814-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1t814-6">
   <w.rf>
    <LM>w#w-d1t814-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t814-7">
   <w.rf>
    <LM>w#w-d1t814-7</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m040-d1t814-5">
   <w.rf>
    <LM>w#w-d1t814-5</LM>
   </w.rf>
   <form>nepříjemný</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AAMS1----1N----</tag>
  </m>
  <m id="m040-d-id80274-punct">
   <w.rf>
    <LM>w#w-d-id80274-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t814-9">
   <w.rf>
    <LM>w#w-d1t814-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t814-10">
   <w.rf>
    <LM>w#w-d1t814-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t814-11">
   <w.rf>
    <LM>w#w-d1t814-11</LM>
   </w.rf>
   <form>toto</form>
   <lemma>tento</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t814-12">
   <w.rf>
    <LM>w#w-d1t814-12</LM>
   </w.rf>
   <form>nedělá</form>
   <lemma>dělat</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m040-45-334">
   <w.rf>
    <LM>w#w-45-334</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-335">
  <m id="m040-335-336">
   <w.rf>
    <LM>w#w-335-336</LM>
   </w.rf>
   <form>Buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t814-18">
   <w.rf>
    <LM>w#w-d1t814-18</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t814-20">
   <w.rf>
    <LM>w#w-d1t814-20</LM>
   </w.rf>
   <form>krámu</form>
   <lemma>krám</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m040-d1t814-17">
   <w.rf>
    <LM>w#w-d1t814-17</LM>
   </w.rf>
   <form>jdu</form>
   <lemma>jít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t814-21">
   <w.rf>
    <LM>w#w-d1t814-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t814-22">
   <w.rf>
    <LM>w#w-d1t814-22</LM>
   </w.rf>
   <form>chci</form>
   <lemma>chtít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t814-23">
   <w.rf>
    <LM>w#w-d1t814-23</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t814-24">
   <w.rf>
    <LM>w#w-d1t814-24</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-45-49">
   <w.rf>
    <LM>w#w-45-49</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t816-1">
   <w.rf>
    <LM>w#w-d1t816-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-335-337">
   <w.rf>
    <LM>w#w-335-337</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t816-6">
   <w.rf>
    <LM>w#w-d1t816-6</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t816-3">
   <w.rf>
    <LM>w#w-d1t816-3</LM>
   </w.rf>
   <form>rovnou</form>
   <lemma>rovnou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t816-7">
   <w.rf>
    <LM>w#w-d1t816-7</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m040-d-id80608-punct">
   <w.rf>
    <LM>w#w-d-id80608-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t816-9">
   <w.rf>
    <LM>w#w-d1t816-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t816-10">
   <w.rf>
    <LM>w#w-d1t816-10</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t816-11">
   <w.rf>
    <LM>w#w-d1t816-11</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m040-d1t816-12">
   <w.rf>
    <LM>w#w-d1t816-12</LM>
   </w.rf>
   <form>kupovat</form>
   <lemma>kupovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-d1t816-13">
   <w.rf>
    <LM>w#w-d1t816-13</LM>
   </w.rf>
   <form>nebude</form>
   <lemma>být</lemma>
   <tag>VB-S---3F-NAI--</tag>
  </m>
  <m id="m040-d1e792-x2-442">
   <w.rf>
    <LM>w#w-d1e792-x2-442</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t816-14">
   <w.rf>
    <LM>w#w-d1t816-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t816-15">
   <w.rf>
    <LM>w#w-d1t816-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t816-16">
   <w.rf>
    <LM>w#w-d1t816-16</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m040-d1t816-18">
   <w.rf>
    <LM>w#w-d1t816-18</LM>
   </w.rf>
   <form>nesmlouvali</form>
   <lemma>smlouvat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m040-d-m-d1e792-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e792-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e823-x2">
  <m id="m040-d1t828-1">
   <w.rf>
    <LM>w#w-d1t828-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t828-2">
   <w.rf>
    <LM>w#w-d1t828-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t828-3">
   <w.rf>
    <LM>w#w-d1t828-3</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t828-4">
   <w.rf>
    <LM>w#w-d1t828-4</LM>
   </w.rf>
   <form>turistů</form>
   <lemma>turista</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m040-d-id80882-punct">
   <w.rf>
    <LM>w#w-d-id80882-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e829-x2">
  <m id="m040-d1t834-3">
   <w.rf>
    <LM>w#w-d1t834-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t834-4">
   <w.rf>
    <LM>w#w-d1t834-4</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1e829-x2-61">
   <w.rf>
    <LM>w#w-d1e829-x2-61</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-62">
  <m id="m040-d1t834-6">
   <w.rf>
    <LM>w#w-d1t834-6</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t834-8">
   <w.rf>
    <LM>w#w-d1t834-8</LM>
   </w.rf>
   <form>Čechů</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m040-d1t834-10">
   <w.rf>
    <LM>w#w-d1t834-10</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m040-d1t834-11">
   <w.rf>
    <LM>w#w-d1t834-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t834-12">
   <w.rf>
    <LM>w#w-d1t834-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t834-13">
   <w.rf>
    <LM>w#w-d1t834-13</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d-id81134-punct">
   <w.rf>
    <LM>w#w-d-id81134-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t834-18">
   <w.rf>
    <LM>w#w-d1t834-18</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t834-16">
   <w.rf>
    <LM>w#w-d1t834-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t834-17">
   <w.rf>
    <LM>w#w-d1t834-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t834-19">
   <w.rf>
    <LM>w#w-d1t834-19</LM>
   </w.rf>
   <form>divila</form>
   <lemma>divit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-62-63">
   <w.rf>
    <LM>w#w-62-63</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-64">
  <m id="m040-d1t834-22">
   <w.rf>
    <LM>w#w-d1t834-22</LM>
   </w.rf>
   <form>Rusů</form>
   <lemma>Rus-1_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m040-d1t834-24">
   <w.rf>
    <LM>w#w-d1t834-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t834-25">
   <w.rf>
    <LM>w#w-d1t834-25</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t834-26">
   <w.rf>
    <LM>w#w-d1t834-26</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t834-27">
   <w.rf>
    <LM>w#w-d1t834-27</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m040-d1t834-29">
   <w.rf>
    <LM>w#w-d1t834-29</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t834-30">
   <w.rf>
    <LM>w#w-d1t834-30</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m040-d1t834-32">
   <w.rf>
    <LM>w#w-d1t834-32</LM>
   </w.rf>
   <form>Čechů</form>
   <lemma>Čech_;E_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m040-d-m-d1e829-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e829-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e841-x2">
  <m id="m040-d1t844-1">
   <w.rf>
    <LM>w#w-d1t844-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t844-2">
   <w.rf>
    <LM>w#w-d1t844-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t844-3">
   <w.rf>
    <LM>w#w-d1t844-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t844-4">
   <w.rf>
    <LM>w#w-d1t844-4</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t844-5">
   <w.rf>
    <LM>w#w-d1t844-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t844-6">
   <w.rf>
    <LM>w#w-d1t844-6</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m040-d1t844-7">
   <w.rf>
    <LM>w#w-d1t844-7</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m040-d1t844-8">
   <w.rf>
    <LM>w#w-d1t844-8</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t844-10">
   <w.rf>
    <LM>w#w-d1t844-10</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m040-d-id81593-punct">
   <w.rf>
    <LM>w#w-d-id81593-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e845-x2">
  <m id="m040-d1t852-6">
   <w.rf>
    <LM>w#w-d1t852-6</LM>
   </w.rf>
   <form>Seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d1t852-2">
   <w.rf>
    <LM>w#w-d1t852-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t852-3">
   <w.rf>
    <LM>w#w-d1t852-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t852-4">
   <w.rf>
    <LM>w#w-d1t852-4</LM>
   </w.rf>
   <form>čirou</form>
   <lemma>čirý</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m040-d1t852-5">
   <w.rf>
    <LM>w#w-d1t852-5</LM>
   </w.rf>
   <form>náhodou</form>
   <lemma>náhoda_^(př._s_takovou_n._jsem_počítal,_n._tomu_chtěla)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m040-d1t854-1">
   <w.rf>
    <LM>w#w-d1t854-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t854-3">
   <w.rf>
    <LM>w#w-d1t854-3</LM>
   </w.rf>
   <form>jídelně</form>
   <lemma>jídelna</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1e845-x2-365">
   <w.rf>
    <LM>w#w-d1e845-x2-365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-369">
  <m id="m040-d1t854-6">
   <w.rf>
    <LM>w#w-d1t854-6</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t854-8">
   <w.rf>
    <LM>w#w-d1t854-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t854-9">
   <w.rf>
    <LM>w#w-d1t854-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t854-10">
   <w.rf>
    <LM>w#w-d1t854-10</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d-id81942-punct">
   <w.rf>
    <LM>w#w-d-id81942-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t854-12">
   <w.rf>
    <LM>w#w-d1t854-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t854-13">
   <w.rf>
    <LM>w#w-d1t854-13</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m040-d1t854-14">
   <w.rf>
    <LM>w#w-d1t854-14</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t854-15">
   <w.rf>
    <LM>w#w-d1t854-15</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t854-16">
   <w.rf>
    <LM>w#w-d1t854-16</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t854-18">
   <w.rf>
    <LM>w#w-d1t854-18</LM>
   </w.rf>
   <form>Nepomuka</form>
   <lemma>Nepomuk-2_;G</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m040-d1e845-x2-107">
   <w.rf>
    <LM>w#w-d1e845-x2-107</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t854-20">
   <w.rf>
    <LM>w#w-d1t854-20</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m040-d1t854-22">
   <w.rf>
    <LM>w#w-d1t854-22</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t854-23">
   <w.rf>
    <LM>w#w-d1t854-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t854-24">
   <w.rf>
    <LM>w#w-d1t854-24</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t854-26">
   <w.rf>
    <LM>w#w-d1t854-26</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m040-d-id82176-punct">
   <w.rf>
    <LM>w#w-d-id82176-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t856-3">
   <w.rf>
    <LM>w#w-d1t856-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t856-4">
   <w.rf>
    <LM>w#w-d1t856-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t856-5">
   <w.rf>
    <LM>w#w-d1t856-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t856-6">
   <w.rf>
    <LM>w#w-d1t856-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t856-7">
   <w.rf>
    <LM>w#w-d1t856-7</LM>
   </w.rf>
   <form>dcerou</form>
   <lemma>dcera</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m040-369-370">
   <w.rf>
    <LM>w#w-369-370</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-371">
  <m id="m040-d1t856-14">
   <w.rf>
    <LM>w#w-d1t856-14</LM>
   </w.rf>
   <form>Bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t856-12">
   <w.rf>
    <LM>w#w-d1t856-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t856-15">
   <w.rf>
    <LM>w#w-d1t856-15</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m040-d1t856-16">
   <w.rf>
    <LM>w#w-d1t856-16</LM>
   </w.rf>
   <form>někam</form>
   <lemma>někam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t856-17">
   <w.rf>
    <LM>w#w-d1t856-17</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-d-id82384-punct">
   <w.rf>
    <LM>w#w-d-id82384-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t856-19">
   <w.rf>
    <LM>w#w-d1t856-19</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t856-20">
   <w.rf>
    <LM>w#w-d1t856-20</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1t856-21">
   <w.rf>
    <LM>w#w-d1t856-21</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t856-22">
   <w.rf>
    <LM>w#w-d1t856-22</LM>
   </w.rf>
   <form>blondýna</form>
   <lemma>blondýna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1e845-x2-105">
   <w.rf>
    <LM>w#w-d1e845-x2-105</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-106">
  <m id="m040-d1t861-5">
   <w.rf>
    <LM>w#w-d1t861-5</LM>
   </w.rf>
   <form>Egypťani</form>
   <lemma>Egypťan_;E</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m040-d1t861-7">
   <w.rf>
    <LM>w#w-d1t861-7</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t865-1">
   <w.rf>
    <LM>w#w-d1t865-1</LM>
   </w.rf>
   <form>nepříjemně</form>
   <lemma>příjemně_^(*1ý)</lemma>
   <tag>Dg-------1N----</tag>
  </m>
  <m id="m040-d1t865-2">
   <w.rf>
    <LM>w#w-d1t865-2</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d-id82578-punct">
   <w.rf>
    <LM>w#w-d-id82578-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t863-3">
   <w.rf>
    <LM>w#w-d1t863-3</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t863-4">
   <w.rf>
    <LM>w#w-d1t863-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t863-5">
   <w.rf>
    <LM>w#w-d1t863-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t863-6">
   <w.rf>
    <LM>w#w-d1t863-6</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t863-7">
   <w.rf>
    <LM>w#w-d1t863-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m040-d1t863-9">
   <w.rf>
    <LM>w#w-d1t863-9</LM>
   </w.rf>
   <form>menšího</form>
   <lemma>malý</lemma>
   <tag>AANS2----2A----</tag>
  </m>
  <m id="m040-d1t863-10">
   <w.rf>
    <LM>w#w-d1t863-10</LM>
   </w.rf>
   <form>městečka</form>
   <lemma>městečko</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m040-d1e845-x2-103">
   <w.rf>
    <LM>w#w-d1e845-x2-103</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-104">
  <m id="m040-d1t865-5">
   <w.rf>
    <LM>w#w-d1t865-5</LM>
   </w.rf>
   <form>Říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d-id82795-punct">
   <w.rf>
    <LM>w#w-d-id82795-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t865-7">
   <w.rf>
    <LM>w#w-d1t865-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t865-8">
   <w.rf>
    <LM>w#w-d1t865-8</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m040-d1t865-9">
   <w.rf>
    <LM>w#w-d1t865-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t865-10">
   <w.rf>
    <LM>w#w-d1t865-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t865-11">
   <w.rf>
    <LM>w#w-d1t865-11</LM>
   </w.rf>
   <form>bála</form>
   <lemma>bát-1</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t865-13">
   <w.rf>
    <LM>w#w-d1t865-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t865-14">
   <w.rf>
    <LM>w#w-d1t865-14</LM>
   </w.rf>
   <form>jít</form>
   <lemma>jít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-d1t865-12">
   <w.rf>
    <LM>w#w-d1t865-12</LM>
   </w.rf>
   <form>sama</form>
   <lemma>sám_^(samotný)</lemma>
   <tag>PLFS1----------</tag>
  </m>
  <m id="m040-d1e845-x2-101">
   <w.rf>
    <LM>w#w-d1e845-x2-101</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-102">
  <m id="m040-d1t865-17">
   <w.rf>
    <LM>w#w-d1t865-17</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t865-18">
   <w.rf>
    <LM>w#w-d1t865-18</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d-id82950-punct">
   <w.rf>
    <LM>w#w-d-id82950-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t865-20">
   <w.rf>
    <LM>w#w-d1t865-20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t865-21">
   <w.rf>
    <LM>w#w-d1t865-21</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t865-22">
   <w.rf>
    <LM>w#w-d1t865-22</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t865-23">
   <w.rf>
    <LM>w#w-d1t865-23</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m040-d-id83020-punct">
   <w.rf>
    <LM>w#w-d-id83020-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-102-374">
   <w.rf>
    <LM>w#w-102-374</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-102-375">
   <w.rf>
    <LM>w#w-102-375</LM>
   </w.rf>
   <form>mezi</form>
   <lemma>mezi-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-102-376">
   <w.rf>
    <LM>w#w-102-376</LM>
   </w.rf>
   <form>námi</form>
   <lemma>my</lemma>
   <tag>PP-P7--1-------</tag>
  </m>
  <m id="m040-102-377">
   <w.rf>
    <LM>w#w-102-377</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-102-378">
   <w.rf>
    <LM>w#w-102-378</LM>
   </w.rf>
   <form>chlap</form>
   <lemma>chlap</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-102-387">
   <w.rf>
    <LM>w#w-102-387</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-389">
  <m id="m040-d1t867-10">
   <w.rf>
    <LM>w#w-d1t867-10</LM>
   </w.rf>
   <form>Cítily</form>
   <lemma>cítit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t867-7">
   <w.rf>
    <LM>w#w-d1t867-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t867-8">
   <w.rf>
    <LM>w#w-d1t867-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t867-11">
   <w.rf>
    <LM>w#w-d1t867-11</LM>
   </w.rf>
   <form>lépe</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m040-d-m-d1e845-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e845-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e868-x2">
  <m id="m040-d1t873-1">
   <w.rf>
    <LM>w#w-d1t873-1</LM>
   </w.rf>
   <form>Možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d-id83332-punct">
   <w.rf>
    <LM>w#w-d-id83332-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t873-3">
   <w.rf>
    <LM>w#w-d1t873-3</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t873-4">
   <w.rf>
    <LM>w#w-d1t873-4</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m040-d1t873-5">
   <w.rf>
    <LM>w#w-d1t873-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t873-6">
   <w.rf>
    <LM>w#w-d1t873-6</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--1----------</tag>
  </m>
  <m id="m040-d1t873-7">
   <w.rf>
    <LM>w#w-d1t873-7</LM>
   </w.rf>
   <form>nestalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m040-d-id83426-punct">
   <w.rf>
    <LM>w#w-d-id83426-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t873-10">
   <w.rf>
    <LM>w#w-d1t873-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t883-1">
   <w.rf>
    <LM>w#w-d1t883-1</LM>
   </w.rf>
   <form>nebylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m040-d1t883-2">
   <w.rf>
    <LM>w#w-d1t883-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t883-3">
   <w.rf>
    <LM>w#w-d1t883-3</LM>
   </w.rf>
   <form>příjemné</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-d-id83576-punct">
   <w.rf>
    <LM>w#w-d-id83576-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t883-5">
   <w.rf>
    <LM>w#w-d1t883-5</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t883-6">
   <w.rf>
    <LM>w#w-d1t883-6</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1e868-x2-116">
   <w.rf>
    <LM>w#w-d1e868-x2-116</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-117">
  <m id="m040-d1t883-9">
   <w.rf>
    <LM>w#w-d1t883-9</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t883-7">
   <w.rf>
    <LM>w#w-d1t883-7</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t883-8">
   <w.rf>
    <LM>w#w-d1t883-8</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m040-117-118">
   <w.rf>
    <LM>w#w-117-118</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-120">
  <m id="m040-d1t883-10">
   <w.rf>
    <LM>w#w-d1t883-10</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t883-11">
   <w.rf>
    <LM>w#w-d1t883-11</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t883-16">
   <w.rf>
    <LM>w#w-d1t883-16</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t883-12">
   <w.rf>
    <LM>w#w-d1t883-12</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t883-13">
   <w.rf>
    <LM>w#w-d1t883-13</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m040-d1t883-14">
   <w.rf>
    <LM>w#w-d1t883-14</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t883-17">
   <w.rf>
    <LM>w#w-d1t883-17</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t883-18">
   <w.rf>
    <LM>w#w-d1t883-18</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t883-19">
   <w.rf>
    <LM>w#w-d1t883-19</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS6--3-------</tag>
  </m>
  <m id="m040-d-id83770-punct">
   <w.rf>
    <LM>w#w-d-id83770-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t883-21">
   <w.rf>
    <LM>w#w-d1t883-21</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t883-23">
   <w.rf>
    <LM>w#w-d1t883-23</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t883-24">
   <w.rf>
    <LM>w#w-d1t883-24</LM>
   </w.rf>
   <form>blondýna</form>
   <lemma>blondýna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-120-121">
   <w.rf>
    <LM>w#w-120-121</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t883-26">
   <w.rf>
    <LM>w#w-d1t883-26</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t883-27">
   <w.rf>
    <LM>w#w-d1t883-27</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t883-28">
   <w.rf>
    <LM>w#w-d1t883-28</LM>
   </w.rf>
   <form>pěkná</form>
   <lemma>pěkný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m040-d1t883-29">
   <w.rf>
    <LM>w#w-d1t883-29</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-120-122">
   <w.rf>
    <LM>w#w-120-122</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-123">
  <m id="m040-d1t883-34">
   <w.rf>
    <LM>w#w-d1t883-34</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t883-32">
   <w.rf>
    <LM>w#w-d1t883-32</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m040-d1t883-33">
   <w.rf>
    <LM>w#w-d1t883-33</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t883-35">
   <w.rf>
    <LM>w#w-d1t883-35</LM>
   </w.rf>
   <form>nepříjemné</form>
   <lemma>příjemný_^(všeob.,_poz._emoce)</lemma>
   <tag>AANS1----1N----</tag>
  </m>
  <m id="m040-d-m-d1e878-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e878-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e884-x2">
  <m id="m040-d1t887-1">
   <w.rf>
    <LM>w#w-d1t887-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d-m-d1e884-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e884-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e895-x2">
  <m id="m040-d1t898-1">
   <w.rf>
    <LM>w#w-d1t898-1</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t898-2">
   <w.rf>
    <LM>w#w-d1t898-2</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t898-3">
   <w.rf>
    <LM>w#w-d1t898-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m040-d1t898-4">
   <w.rf>
    <LM>w#w-d1t898-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m040-d1t898-5">
   <w.rf>
    <LM>w#w-d1t898-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m040-d1t898-6">
   <w.rf>
    <LM>w#w-d1t898-6</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m040-d1t898-7">
   <w.rf>
    <LM>w#w-d1t898-7</LM>
   </w.rf>
   <form>povíte</form>
   <lemma>povědět</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m040-d-id84188-punct">
   <w.rf>
    <LM>w#w-d-id84188-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e899-x2">
  <m id="m040-d1t904-5">
   <w.rf>
    <LM>w#w-d1t904-5</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m040-d1e899-x2-133">
   <w.rf>
    <LM>w#w-d1e899-x2-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-134">
  <m id="m040-d1t904-8">
   <w.rf>
    <LM>w#w-d1t904-8</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t904-9">
   <w.rf>
    <LM>w#w-d1t904-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t904-10">
   <w.rf>
    <LM>w#w-d1t904-10</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t904-12">
   <w.rf>
    <LM>w#w-d1t904-12</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m040-d-id84417-punct">
   <w.rf>
    <LM>w#w-d-id84417-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t904-14">
   <w.rf>
    <LM>w#w-d1t904-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t904-15">
   <w.rf>
    <LM>w#w-d1t904-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t904-16">
   <w.rf>
    <LM>w#w-d1t904-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t904-17">
   <w.rf>
    <LM>w#w-d1t904-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t904-19">
   <w.rf>
    <LM>w#w-d1t904-19</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t904-20">
   <w.rf>
    <LM>w#w-d1t904-20</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-134-410">
   <w.rf>
    <LM>w#w-134-410</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-411">
  <m id="m040-d1t904-25">
   <w.rf>
    <LM>w#w-d1t904-25</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t904-23">
   <w.rf>
    <LM>w#w-d1t904-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t904-24">
   <w.rf>
    <LM>w#w-d1t904-24</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t904-26">
   <w.rf>
    <LM>w#w-d1t904-26</LM>
   </w.rf>
   <form>jedli</form>
   <lemma>jíst</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d-id84608-punct">
   <w.rf>
    <LM>w#w-d-id84608-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t904-32">
   <w.rf>
    <LM>w#w-d1t904-32</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t904-29">
   <w.rf>
    <LM>w#w-d1t904-29</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t908-1">
   <w.rf>
    <LM>w#w-d1t908-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t904-30">
   <w.rf>
    <LM>w#w-d1t904-30</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t908-2">
   <w.rf>
    <LM>w#w-d1t908-2</LM>
   </w.rf>
   <form>projít</form>
   <lemma>projít_^(i_uplynout_[o_čase])</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t908-3">
   <w.rf>
    <LM>w#w-d1t908-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t908-4">
   <w.rf>
    <LM>w#w-d1t908-4</LM>
   </w.rf>
   <form>pláži</form>
   <lemma>pláž</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t908-5">
   <w.rf>
    <LM>w#w-d1t908-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t910-1">
   <w.rf>
    <LM>w#w-d1t910-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t910-2">
   <w.rf>
    <LM>w#w-d1t910-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t910-3">
   <w.rf>
    <LM>w#w-d1t910-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t910-4">
   <w.rf>
    <LM>w#w-d1t910-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t910-5">
   <w.rf>
    <LM>w#w-d1t910-5</LM>
   </w.rf>
   <form>hledat</form>
   <lemma>hledat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-411-412">
   <w.rf>
    <LM>w#w-411-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-411-413">
   <w.rf>
    <LM>w#w-411-413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-134-135">
   <w.rf>
    <LM>w#w-134-135</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-136">
  <m id="m040-d1t915-1">
   <w.rf>
    <LM>w#w-d1t915-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t915-2">
   <w.rf>
    <LM>w#w-d1t915-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t915-3">
   <w.rf>
    <LM>w#w-d1t915-3</LM>
   </w.rf>
   <form>šnorchl</form>
   <lemma>šnorchl_,l</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m040-d1t915-4">
   <w.rf>
    <LM>w#w-d1t915-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t915-5">
   <w.rf>
    <LM>w#w-d1t915-5</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d1t915-6">
   <w.rf>
    <LM>w#w-d1t915-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t915-7">
   <w.rf>
    <LM>w#w-d1t915-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t917-1">
   <w.rf>
    <LM>w#w-d1t917-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m040-d1t917-5">
   <w.rf>
    <LM>w#w-d1t917-5</LM>
   </w.rf>
   <form>ježky</form>
   <lemma>ježek</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m040-d1t917-6">
   <w.rf>
    <LM>w#w-d1t917-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t917-7">
   <w.rf>
    <LM>w#w-d1t917-7</LM>
   </w.rf>
   <form>takovéhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m040-d1t917-9">
   <w.rf>
    <LM>w#w-d1t917-9</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m040-d-id85149-punct">
   <w.rf>
    <LM>w#w-d-id85149-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t917-11">
   <w.rf>
    <LM>w#w-d1t917-11</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m040-d1t917-12">
   <w.rf>
    <LM>w#w-d1t917-12</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m040-d1t917-13">
   <w.rf>
    <LM>w#w-d1t917-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t917-14">
   <w.rf>
    <LM>w#w-d1t917-14</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t917-16">
   <w.rf>
    <LM>w#w-d1t917-16</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m040-d1t919-1">
   <w.rf>
    <LM>w#w-d1t919-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t919-3">
   <w.rf>
    <LM>w#w-d1t919-3</LM>
   </w.rf>
   <form>mělčině</form>
   <lemma>mělčina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-136-145">
   <w.rf>
    <LM>w#w-136-145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-146">
  <m id="m040-d1t919-6">
   <w.rf>
    <LM>w#w-d1t919-6</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t919-7">
   <w.rf>
    <LM>w#w-d1t919-7</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m040-d1t919-8">
   <w.rf>
    <LM>w#w-d1t919-8</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t919-9">
   <w.rf>
    <LM>w#w-d1t919-9</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-d-m-d1e899-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e899-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e926-x2">
  <m id="m040-d1t929-1">
   <w.rf>
    <LM>w#w-d1t929-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t929-2">
   <w.rf>
    <LM>w#w-d1t929-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t929-3">
   <w.rf>
    <LM>w#w-d1t929-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t929-4">
   <w.rf>
    <LM>w#w-d1t929-4</LM>
   </w.rf>
   <form>šnorchlovali</form>
   <lemma>šnorchlovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d-id85487-punct">
   <w.rf>
    <LM>w#w-d-id85487-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e930-x2">
  <m id="m040-d1e930-x2-398">
   <w.rf>
    <LM>w#w-d1e930-x2-398</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1e930-x2-399">
   <w.rf>
    <LM>w#w-d1e930-x2-399</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-400">
  <m id="m040-d1t935-3">
   <w.rf>
    <LM>w#w-d1t935-3</LM>
   </w.rf>
   <form>Zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t935-4">
   <w.rf>
    <LM>w#w-d1t935-4</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t935-5">
   <w.rf>
    <LM>w#w-d1t935-5</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d1e930-x2-148">
   <w.rf>
    <LM>w#w-d1e930-x2-148</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t935-6">
   <w.rf>
    <LM>w#w-d1t935-6</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m040-d1t937-1">
   <w.rf>
    <LM>w#w-d1t937-1</LM>
   </w.rf>
   <form>moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t937-2">
   <w.rf>
    <LM>w#w-d1t937-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d-m-d1e930-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e930-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e938-x2">
  <m id="m040-d1t943-1">
   <w.rf>
    <LM>w#w-d1t943-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m040-d1t943-2">
   <w.rf>
    <LM>w#w-d1t943-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m040-d1t943-3">
   <w.rf>
    <LM>w#w-d1t943-3</LM>
   </w.rf>
   <form>viděli</form>
   <lemma>vidět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m040-d-id85792-punct">
   <w.rf>
    <LM>w#w-d-id85792-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e944-x2">
  <m id="m040-d1t949-7">
   <w.rf>
    <LM>w#w-d1t949-7</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t949-8">
   <w.rf>
    <LM>w#w-d1t949-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t949-9">
   <w.rf>
    <LM>w#w-d1t949-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t949-10">
   <w.rf>
    <LM>w#w-d1t949-10</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m040-d1e944-x2-164">
   <w.rf>
    <LM>w#w-d1e944-x2-164</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-166">
  <m id="m040-d1t949-12">
   <w.rf>
    <LM>w#w-d1t949-12</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t949-13">
   <w.rf>
    <LM>w#w-d1t949-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t949-15">
   <w.rf>
    <LM>w#w-d1t949-15</LM>
   </w.rf>
   <form>rybičky</form>
   <lemma>rybička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d-id86033-punct">
   <w.rf>
    <LM>w#w-d-id86033-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t949-18">
   <w.rf>
    <LM>w#w-d1t949-18</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t949-17">
   <w.rf>
    <LM>w#w-d1t949-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-166-427">
   <w.rf>
    <LM>w#w-166-427</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-166-428">
   <w.rf>
    <LM>w#w-166-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-166-429">
   <w.rf>
    <LM>w#w-166-429</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-168">
  <m id="m040-d1t949-24">
   <w.rf>
    <LM>w#w-d1t949-24</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t949-25">
   <w.rf>
    <LM>w#w-d1t949-25</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t949-26">
   <w.rf>
    <LM>w#w-d1t949-26</LM>
   </w.rf>
   <form>nervózní</form>
   <lemma>nervózní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m040-d-id86184-punct">
   <w.rf>
    <LM>w#w-d-id86184-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t949-28">
   <w.rf>
    <LM>w#w-d1t949-28</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t949-29">
   <w.rf>
    <LM>w#w-d1t949-29</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m040-d1t949-30">
   <w.rf>
    <LM>w#w-d1t949-30</LM>
   </w.rf>
   <form>neřeknu</form>
   <lemma>říci</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m040-d-m-d1e944-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e944-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e952-x2">
  <m id="m040-d1t957-5">
   <w.rf>
    <LM>w#w-d1t957-5</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t957-4">
   <w.rf>
    <LM>w#w-d1t957-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t957-2">
   <w.rf>
    <LM>w#w-d1t957-2</LM>
   </w.rf>
   <form>medúzy</form>
   <lemma>medúza</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d-m-d1e952-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e952-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e952-x3">
  <m id="m040-d1t959-1">
   <w.rf>
    <LM>w#w-d1t959-1</LM>
   </w.rf>
   <form>Zkoušel</form>
   <lemma>zkoušet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m040-d1t959-2">
   <w.rf>
    <LM>w#w-d1t959-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t959-3">
   <w.rf>
    <LM>w#w-d1t959-3</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m040-d1t959-4">
   <w.rf>
    <LM>w#w-d1t959-4</LM>
   </w.rf>
   <form>vylovit</form>
   <lemma>vylovit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d-id86398-punct">
   <w.rf>
    <LM>w#w-d-id86398-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e960-x2">
  <m id="m040-d1t965-5">
   <w.rf>
    <LM>w#w-d1t965-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t965-3">
   <w.rf>
    <LM>w#w-d1t965-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m040-d1t965-4">
   <w.rf>
    <LM>w#w-d1t965-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t965-6">
   <w.rf>
    <LM>w#w-d1t965-6</LM>
   </w.rf>
   <form>zakázané</form>
   <lemma>zakázaný_^(*2t)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m040-d-id86548-punct">
   <w.rf>
    <LM>w#w-d-id86548-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t965-8">
   <w.rf>
    <LM>w#w-d1t965-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m040-d1t965-9">
   <w.rf>
    <LM>w#w-d1t965-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m040-d1t965-10">
   <w.rf>
    <LM>w#w-d1t965-10</LM>
   </w.rf>
   <form>nezkoušeli</form>
   <lemma>zkoušet</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m040-d1t965-11">
   <w.rf>
    <LM>w#w-d1t965-11</LM>
   </w.rf>
   <form>vylovit</form>
   <lemma>vylovit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t965-12">
   <w.rf>
    <LM>w#w-d1t965-12</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m040-d1e960-x2-177">
   <w.rf>
    <LM>w#w-d1e960-x2-177</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-178">
  <m id="m040-d1t967-2">
   <w.rf>
    <LM>w#w-d1t967-2</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t967-3">
   <w.rf>
    <LM>w#w-d1t967-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t967-1">
   <w.rf>
    <LM>w#w-d1t967-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t967-5">
   <w.rf>
    <LM>w#w-d1t967-5</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m040-d1t967-6">
   <w.rf>
    <LM>w#w-d1t967-6</LM>
   </w.rf>
   <form>fialové</form>
   <lemma>fialový_;o</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m040-d1t967-4">
   <w.rf>
    <LM>w#w-d1t967-4</LM>
   </w.rf>
   <form>medúzy</form>
   <lemma>medúza</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d1t967-7">
   <w.rf>
    <LM>w#w-d1t967-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m040-d1t967-8">
   <w.rf>
    <LM>w#w-d1t967-8</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m040-d1t967-9">
   <w.rf>
    <LM>w#w-d1t967-9</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m040-d1t967-10">
   <w.rf>
    <LM>w#w-d1t967-10</LM>
   </w.rf>
   <form>nepálily</form>
   <lemma>pálit</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m040-178-180">
   <w.rf>
    <LM>w#w-178-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-181">
  <m id="m040-d1t969-1">
   <w.rf>
    <LM>w#w-d1t969-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m040-d1t969-2">
   <w.rf>
    <LM>w#w-d1t969-2</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m040-d1t969-3">
   <w.rf>
    <LM>w#w-d1t969-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t969-4">
   <w.rf>
    <LM>w#w-d1t969-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d1t969-5">
   <w.rf>
    <LM>w#w-d1t969-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m040-d1t969-6">
   <w.rf>
    <LM>w#w-d1t969-6</LM>
   </w.rf>
   <form>vyhrály</form>
   <lemma>vyhrát</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m040-d1t969-7">
   <w.rf>
    <LM>w#w-d1t969-7</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m040-d-id86897-punct">
   <w.rf>
    <LM>w#w-d-id86897-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t969-9">
   <w.rf>
    <LM>w#w-d1t969-9</LM>
   </w.rf>
   <form>házely</form>
   <lemma>házet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m040-d1t969-10">
   <w.rf>
    <LM>w#w-d1t969-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m040-d1t969-11">
   <w.rf>
    <LM>w#w-d1t969-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t969-12">
   <w.rf>
    <LM>w#w-d1t969-12</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m040-d-m-d1e960-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e960-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e984-x2">
  <m id="m040-d1t987-3">
   <w.rf>
    <LM>w#w-d1t987-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m040-d1t987-2">
   <w.rf>
    <LM>w#w-d1t987-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m040-d1t987-4">
   <w.rf>
    <LM>w#w-d1t987-4</LM>
   </w.rf>
   <form>dál</form>
   <lemma>dál-3_,s_^(také,_za_další)_(^DD**dále-3)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m040-d-m-d1e984-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e984-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e994-x2">
  <m id="m040-d1t997-1">
   <w.rf>
    <LM>w#w-d1t997-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m040-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t997-3">
   <w.rf>
    <LM>w#w-d1t997-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m040-d1t997-4">
   <w.rf>
    <LM>w#w-d1t997-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t997-5">
   <w.rf>
    <LM>w#w-d1t997-5</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m040-d1t997-6">
   <w.rf>
    <LM>w#w-d1t997-6</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d-id87348-punct">
   <w.rf>
    <LM>w#w-d-id87348-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-d1e998-x2">
  <m id="m040-d1t1003-2">
   <w.rf>
    <LM>w#w-d1t1003-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m040-d1t1003-3">
   <w.rf>
    <LM>w#w-d1t1003-3</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m040-d1t1003-4">
   <w.rf>
    <LM>w#w-d1t1003-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m040-d1t1003-5">
   <w.rf>
    <LM>w#w-d1t1003-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m040-d1t1003-6">
   <w.rf>
    <LM>w#w-d1t1003-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m040-d1t1003-7">
   <w.rf>
    <LM>w#w-d1t1003-7</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----3A----</tag>
  </m>
  <m id="m040-d1t1003-8">
   <w.rf>
    <LM>w#w-d1t1003-8</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d-id87542-punct">
   <w.rf>
    <LM>w#w-d-id87542-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1003-10">
   <w.rf>
    <LM>w#w-d1t1003-10</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m040-d1e998-x2-186">
   <w.rf>
    <LM>w#w-d1e998-x2-186</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1005-1">
   <w.rf>
    <LM>w#w-d1t1005-1</LM>
   </w.rf>
   <form>vnuk</form>
   <lemma>vnuk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m040-d-id87591-punct">
   <w.rf>
    <LM>w#w-d-id87591-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m040-d1t1005-3">
   <w.rf>
    <LM>w#w-d1t1005-3</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m040-d1e998-x2-187">
   <w.rf>
    <LM>w#w-d1e998-x2-187</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m040-188">
  <m id="m040-d1t1005-8">
   <w.rf>
    <LM>w#w-d1t1005-8</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m040-d1t1005-6">
   <w.rf>
    <LM>w#w-d1t1005-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m040-d1t1005-7">
   <w.rf>
    <LM>w#w-d1t1005-7</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m040-d1t1005-9">
   <w.rf>
    <LM>w#w-d1t1005-9</LM>
   </w.rf>
   <form>vzít</form>
   <lemma>vzít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m040-d1t1005-10">
   <w.rf>
    <LM>w#w-d1t1005-10</LM>
   </w.rf>
   <form>brýle</form>
   <lemma>brýle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m040-188-189">
   <w.rf>
    <LM>w#w-188-189</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
