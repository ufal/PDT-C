<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ez_126.10.w.gz" />
  </references>
 </head>
 <s id="m126-d1e1760-x2">
  <m id="m126-d1t1765-1">
   <w.rf>
    <LM>w#w-d1t1765-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1767-1">
   <w.rf>
    <LM>w#w-d1t1767-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1767-2">
   <w.rf>
    <LM>w#w-d1t1767-2</LM>
   </w.rf>
   <form>volno</form>
   <lemma>volno-2</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m126-d1t1767-3">
   <w.rf>
    <LM>w#w-d1t1767-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1767-4">
   <w.rf>
    <LM>w#w-d1t1767-4</LM>
   </w.rf>
   <form>mohlo</form>
   <lemma>moci</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1767-5">
   <w.rf>
    <LM>w#w-d1t1767-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1767-6">
   <w.rf>
    <LM>w#w-d1t1767-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1767-7">
   <w.rf>
    <LM>w#w-d1t1767-7</LM>
   </w.rf>
   <form>jezdit</form>
   <lemma>jezdit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d-id149279-punct">
   <w.rf>
    <LM>w#w-d-id149279-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1767-9">
   <w.rf>
    <LM>w#w-d1t1767-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1767-10">
   <w.rf>
    <LM>w#w-d1t1767-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1767-11">
   <w.rf>
    <LM>w#w-d1t1767-11</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d1t1767-12">
   <w.rf>
    <LM>w#w-d1t1767-12</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m126-d1t1767-13">
   <w.rf>
    <LM>w#w-d1t1767-13</LM>
   </w.rf>
   <form>pátek</form>
   <lemma>pátek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d1e1760-x2-814">
   <w.rf>
    <LM>w#w-d1e1760-x2-814</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-815">
  <m id="m126-d1t1769-5">
   <w.rf>
    <LM>w#w-d1t1769-5</LM>
   </w.rf>
   <form>I</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1769-2">
   <w.rf>
    <LM>w#w-d1t1769-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1769-3">
   <w.rf>
    <LM>w#w-d1t1769-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1769-6">
   <w.rf>
    <LM>w#w-d1t1769-6</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d-id149474-punct">
   <w.rf>
    <LM>w#w-d-id149474-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1769-8">
   <w.rf>
    <LM>w#w-d1t1769-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1769-9">
   <w.rf>
    <LM>w#w-d1t1769-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1769-11">
   <w.rf>
    <LM>w#w-d1t1769-11</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m126-d1t1769-12">
   <w.rf>
    <LM>w#w-d1t1769-12</LM>
   </w.rf>
   <form>chatu</form>
   <lemma>chata</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d1t1769-10">
   <w.rf>
    <LM>w#w-d1t1769-10</LM>
   </w.rf>
   <form>opravovali</form>
   <lemma>opravovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d-id149560-punct">
   <w.rf>
    <LM>w#w-d-id149560-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1769-14">
   <w.rf>
    <LM>w#w-d1t1769-14</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1769-15">
   <w.rf>
    <LM>w#w-d1t1769-15</LM>
   </w.rf>
   <form>střídali</form>
   <lemma>střídat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1769-16">
   <w.rf>
    <LM>w#w-d1t1769-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1769-17">
   <w.rf>
    <LM>w#w-d1t1769-17</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1769-18">
   <w.rf>
    <LM>w#w-d1t1769-18</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1769-19">
   <w.rf>
    <LM>w#w-d1t1769-19</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1769-20">
   <w.rf>
    <LM>w#w-d1t1769-20</LM>
   </w.rf>
   <form>jinými</form>
   <lemma>jiný</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m126-d1t1769-21">
   <w.rf>
    <LM>w#w-d1t1769-21</LM>
   </w.rf>
   <form>lidmi</form>
   <lemma>lidé</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m126-815-816">
   <w.rf>
    <LM>w#w-815-816</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-817">
  <m id="m126-d1t1769-26">
   <w.rf>
    <LM>w#w-d1t1769-26</LM>
   </w.rf>
   <form>Aritma</form>
   <lemma>Aritma_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1769-28">
   <w.rf>
    <LM>w#w-d1t1769-28</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1769-29">
   <w.rf>
    <LM>w#w-d1t1769-29</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1769-30">
   <w.rf>
    <LM>w#w-d1t1769-30</LM>
   </w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m126-d1t1769-31">
   <w.rf>
    <LM>w#w-d1t1769-31</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m126-d-id149828-punct">
   <w.rf>
    <LM>w#w-d-id149828-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1769-33">
   <w.rf>
    <LM>w#w-d1t1769-33</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1771-1">
   <w.rf>
    <LM>w#w-d1t1771-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1771-2">
   <w.rf>
    <LM>w#w-d1t1771-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1771-3">
   <w.rf>
    <LM>w#w-d1t1771-3</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1771-4">
   <w.rf>
    <LM>w#w-d1t1771-4</LM>
   </w.rf>
   <form>nával</form>
   <lemma>nával</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m126-817-818">
   <w.rf>
    <LM>w#w-817-818</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-819">
  <m id="m126-d1t1776-2">
   <w.rf>
    <LM>w#w-d1t1776-2</LM>
   </w.rf>
   <form>Jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1776-3">
   <w.rf>
    <LM>w#w-d1t1776-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1776-4">
   <w.rf>
    <LM>w#w-d1t1776-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1776-5">
   <w.rf>
    <LM>w#w-d1t1776-5</LM>
   </w.rf>
   <form>zapsali</form>
   <lemma>zapsat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1776-6">
   <w.rf>
    <LM>w#w-d1t1776-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1776-11">
   <w.rf>
    <LM>w#w-d1t1776-11</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1776-9">
   <w.rf>
    <LM>w#w-d1t1776-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1776-10">
   <w.rf>
    <LM>w#w-d1t1776-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1776-7">
   <w.rf>
    <LM>w#w-d1t1776-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1776-8">
   <w.rf>
    <LM>w#w-d1t1776-8</LM>
   </w.rf>
   <form>týden</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d1t1776-13">
   <w.rf>
    <LM>w#w-d1t1776-13</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1776-15">
   <w.rf>
    <LM>w#w-d1t1776-15</LM>
   </w.rf>
   <form>zimní</form>
   <lemma>zimní</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m126-d1t1776-14">
   <w.rf>
    <LM>w#w-d1t1776-14</LM>
   </w.rf>
   <form>dovolenou</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1760-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1760-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1777-x3">
  <m id="m126-d1t1784-1">
   <w.rf>
    <LM>w#w-d1t1784-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m126-d1t1784-2">
   <w.rf>
    <LM>w#w-d1t1784-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1784-3">
   <w.rf>
    <LM>w#w-d1t1784-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1784-4">
   <w.rf>
    <LM>w#w-d1t1784-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m126-d1t1784-5">
   <w.rf>
    <LM>w#w-d1t1784-5</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d-id150353-punct">
   <w.rf>
    <LM>w#w-d-id150353-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1786-x2">
  <m id="m126-d1t1789-3">
   <w.rf>
    <LM>w#w-d1t1789-3</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m126-d1t1789-4">
   <w.rf>
    <LM>w#w-d1t1789-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1789-5">
   <w.rf>
    <LM>w#w-d1t1789-5</LM>
   </w.rf>
   <form>dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1e1786-x2-457">
   <w.rf>
    <LM>w#w-d1e1786-x2-457</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-459">
  <m id="m126-d1t1791-1">
   <w.rf>
    <LM>w#w-d1t1791-1</LM>
   </w.rf>
   <form>Přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1791-2">
   <w.rf>
    <LM>w#w-d1t1791-2</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d1t1791-3">
   <w.rf>
    <LM>w#w-d1t1791-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1791-4">
   <w.rf>
    <LM>w#w-d1t1791-4</LM>
   </w.rf>
   <form>jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1791-5">
   <w.rf>
    <LM>w#w-d1t1791-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1791-6">
   <w.rf>
    <LM>w#w-d1t1791-6</LM>
   </w.rf>
   <form>běžkách</form>
   <lemma>běžka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-d1e1786-x2-826">
   <w.rf>
    <LM>w#w-d1e1786-x2-826</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-827">
  <m id="m126-d1t1791-10">
   <w.rf>
    <LM>w#w-d1t1791-10</LM>
   </w.rf>
   <form>Myslíte</form>
   <lemma>myslit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1791-12">
   <w.rf>
    <LM>w#w-d1t1791-12</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m126-d1t1791-13">
   <w.rf>
    <LM>w#w-d1t1791-13</LM>
   </w.rf>
   <form>volném</form>
   <lemma>volný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m126-d1t1791-14">
   <w.rf>
    <LM>w#w-d1t1791-14</LM>
   </w.rf>
   <form>čase</form>
   <lemma>čas</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-827-828">
   <w.rf>
    <LM>w#w-827-828</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-829">
  <m id="m126-d1t1791-17">
   <w.rf>
    <LM>w#w-d1t1791-17</LM>
   </w.rf>
   <form>Jezdilo</form>
   <lemma>jezdit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1791-16">
   <w.rf>
    <LM>w#w-d1t1791-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1791-18">
   <w.rf>
    <LM>w#w-d1t1791-18</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1791-19">
   <w.rf>
    <LM>w#w-d1t1791-19</LM>
   </w.rf>
   <form>běžkách</form>
   <lemma>běžka</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m126-d1t1791-21">
   <w.rf>
    <LM>w#w-d1t1791-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1791-22">
   <w.rf>
    <LM>w#w-d1t1791-22</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1791-23">
   <w.rf>
    <LM>w#w-d1t1791-23</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1791-24">
   <w.rf>
    <LM>w#w-d1t1791-24</LM>
   </w.rf>
   <form>popíjelo</form>
   <lemma>popíjet</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-829-830">
   <w.rf>
    <LM>w#w-829-830</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-831">
  <m id="m126-d1t1791-26">
   <w.rf>
    <LM>w#w-d1t1791-26</LM>
   </w.rf>
   <form>Ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1791-27">
   <w.rf>
    <LM>w#w-d1t1791-27</LM>
   </w.rf>
   <form>bolely</form>
   <lemma>bolet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1791-28">
   <w.rf>
    <LM>w#w-d1t1791-28</LM>
   </w.rf>
   <form>hlavy</form>
   <lemma>hlava</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d1t1791-29">
   <w.rf>
    <LM>w#w-d1t1791-29</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1791-30">
   <w.rf>
    <LM>w#w-d1t1791-30</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1791-31">
   <w.rf>
    <LM>w#w-d1t1791-31</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1791-32">
   <w.rf>
    <LM>w#w-d1t1791-32</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m126-d1t1791-33">
   <w.rf>
    <LM>w#w-d1t1791-33</LM>
   </w.rf>
   <form>hodin</form>
   <lemma>hodina</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m126-d1t1791-34">
   <w.rf>
    <LM>w#w-d1t1791-34</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1791-35">
   <w.rf>
    <LM>w#w-d1t1791-35</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1791-36">
   <w.rf>
    <LM>w#w-d1t1791-36</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1791-37">
   <w.rf>
    <LM>w#w-d1t1791-37</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1791-38">
   <w.rf>
    <LM>w#w-d1t1791-38</LM>
   </w.rf>
   <form>vzduch</form>
   <lemma>vzduch</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d-id151076-punct">
   <w.rf>
    <LM>w#w-d-id151076-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1791-40">
   <w.rf>
    <LM>w#w-d1t1791-40</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m126-d1t1791-42">
   <w.rf>
    <LM>w#w-d1t1791-42</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1791-41">
   <w.rf>
    <LM>w#w-d1t1791-41</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1791-43">
   <w.rf>
    <LM>w#w-d1t1791-43</LM>
   </w.rf>
   <form>pokračovat</form>
   <lemma>pokračovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d1t1791-44">
   <w.rf>
    <LM>w#w-d1t1791-44</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1791-45">
   <w.rf>
    <LM>w#w-d1t1791-45</LM>
   </w.rf>
   <form>pití</form>
   <lemma>pití_^(*3ít)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1786-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1786-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1798-x2">
  <m id="m126-d1t1803-1">
   <w.rf>
    <LM>w#w-d1t1803-1</LM>
   </w.rf>
   <form>Hrály</form>
   <lemma>hrát</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1803-2">
   <w.rf>
    <LM>w#w-d1t1803-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1803-3">
   <w.rf>
    <LM>w#w-d1t1803-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1803-4">
   <w.rf>
    <LM>w#w-d1t1803-4</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-d1t1803-5">
   <w.rf>
    <LM>w#w-d1t1803-5</LM>
   </w.rf>
   <form>hry</form>
   <lemma>hra_^(dětská;_v_divadle;...)</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1798-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1798-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1798-x3">
  <m id="m126-d1t1805-1">
   <w.rf>
    <LM>w#w-d1t1805-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m126-d1t1805-2">
   <w.rf>
    <LM>w#w-d1t1805-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m126-d1t1805-3">
   <w.rf>
    <LM>w#w-d1t1805-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1805-4">
   <w.rf>
    <LM>w#w-d1t1805-4</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1805-5">
   <w.rf>
    <LM>w#w-d1t1805-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d-id151440-punct">
   <w.rf>
    <LM>w#w-d-id151440-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1806-x2">
  <m id="m126-d1t1809-2">
   <w.rf>
    <LM>w#w-d1t1809-2</LM>
   </w.rf>
   <form>Někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1809-3">
   <w.rf>
    <LM>w#w-d1t1809-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1809-4">
   <w.rf>
    <LM>w#w-d1t1809-4</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m126-d-id151563-punct">
   <w.rf>
    <LM>w#w-d-id151563-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1809-6">
   <w.rf>
    <LM>w#w-d1t1809-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1809-7">
   <w.rf>
    <LM>w#w-d1t1809-7</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1809-8">
   <w.rf>
    <LM>w#w-d1t1809-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1809-9">
   <w.rf>
    <LM>w#w-d1t1809-9</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1809-10">
   <w.rf>
    <LM>w#w-d1t1809-10</LM>
   </w.rf>
   <form>taková</form>
   <lemma>takový</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1809-11">
   <w.rf>
    <LM>w#w-d1t1809-11</LM>
   </w.rf>
   <form>parta</form>
   <lemma>parta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1e1806-x2-845">
   <w.rf>
    <LM>w#w-d1e1806-x2-845</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-846">
  <m id="m126-d1t1809-13">
   <w.rf>
    <LM>w#w-d1t1809-13</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1809-14">
   <w.rf>
    <LM>w#w-d1t1809-14</LM>
   </w.rf>
   <form>zrovna</form>
   <lemma>zrovna-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1809-15">
   <w.rf>
    <LM>w#w-d1t1809-15</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m126-d1t1809-16">
   <w.rf>
    <LM>w#w-d1t1809-16</LM>
   </w.rf>
   <form>charakteristická</form>
   <lemma>charakteristický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-d1t1809-17">
   <w.rf>
    <LM>w#w-d1t1809-17</LM>
   </w.rf>
   <form>parta</form>
   <lemma>parta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id151752-punct">
   <w.rf>
    <LM>w#w-d-id151752-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1811-1">
   <w.rf>
    <LM>w#w-d1t1811-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1811-9">
   <w.rf>
    <LM>w#w-d1t1811-9</LM>
   </w.rf>
   <form>Petr</form>
   <lemma>Petr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1t1811-11">
   <w.rf>
    <LM>w#w-d1t1811-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m126-d1t1811-12">
   <w.rf>
    <LM>w#w-d1t1811-12</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m126-d1t1811-13">
   <w.rf>
    <LM>w#w-d1t1811-13</LM>
   </w.rf>
   <form>děvčetem</form>
   <lemma>děvče</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m126-d-id151944-punct">
   <w.rf>
    <LM>w#w-d-id151944-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1811-16">
   <w.rf>
    <LM>w#w-d1t1811-16</LM>
   </w.rf>
   <form>Ivanka</form>
   <lemma>Ivanka_;Y_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1811-18">
   <w.rf>
    <LM>w#w-d1t1811-18</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m126-d1t1811-19">
   <w.rf>
    <LM>w#w-d1t1811-19</LM>
   </w.rf>
   <form>svým</form>
   <lemma>svůj-1</lemma>
   <tag>P8ZS7----------</tag>
  </m>
  <m id="m126-d1t1811-20">
   <w.rf>
    <LM>w#w-d1t1811-20</LM>
   </w.rf>
   <form>chlapcem</form>
   <lemma>chlapec</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m126-d-id152032-punct">
   <w.rf>
    <LM>w#w-d-id152032-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1811-23">
   <w.rf>
    <LM>w#w-d1t1811-23</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1811-25">
   <w.rf>
    <LM>w#w-d1t1811-25</LM>
   </w.rf>
   <form>takových</form>
   <lemma>takový</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m126-d1t1811-26">
   <w.rf>
    <LM>w#w-d1t1811-26</LM>
   </w.rf>
   <form>osm</form>
   <lemma>osm`8</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m126-846-847">
   <w.rf>
    <LM>w#w-846-847</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1811-27">
   <w.rf>
    <LM>w#w-d1t1811-27</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m126-d-id152133-punct">
   <w.rf>
    <LM>w#w-d-id152133-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1811-32">
   <w.rf>
    <LM>w#w-d1t1811-32</LM>
   </w.rf>
   <form>obměňovalo</form>
   <lemma>obměňovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m126-d1t1811-30">
   <w.rf>
    <LM>w#w-d1t1811-30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1811-31">
   <w.rf>
    <LM>w#w-d1t1811-31</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d-m-d1e1806-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1806-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1812-x2">
  <m id="m126-d1t1819-1">
   <w.rf>
    <LM>w#w-d1t1819-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m126-d1t1819-2">
   <w.rf>
    <LM>w#w-d1t1819-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1819-3">
   <w.rf>
    <LM>w#w-d1t1819-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1819-4">
   <w.rf>
    <LM>w#w-d1t1819-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m126-d1t1819-5">
   <w.rf>
    <LM>w#w-d1t1819-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d-id152358-punct">
   <w.rf>
    <LM>w#w-d-id152358-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1820-x2">
  <m id="m126-d1e1820-x2-495">
   <w.rf>
    <LM>w#w-d1e1820-x2-495</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1e1820-x2-494">
   <w.rf>
    <LM>w#w-d1e1820-x2-494</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m126-d1e1820-x2-493">
   <w.rf>
    <LM>w#w-d1e1820-x2-493</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d1e1820-x2-492">
   <w.rf>
    <LM>w#w-d1e1820-x2-492</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1e1820-x2-491">
   <w.rf>
    <LM>w#w-d1e1820-x2-491</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m126-d1e1820-x2-490">
   <w.rf>
    <LM>w#w-d1e1820-x2-490</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m126-d1e1820-x2-489">
   <w.rf>
    <LM>w#w-d1e1820-x2-489</LM>
   </w.rf>
   <form>neteř</form>
   <lemma>neteř</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1e1820-x2-488">
   <w.rf>
    <LM>w#w-d1e1820-x2-488</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1e1820-x2-487">
   <w.rf>
    <LM>w#w-d1e1820-x2-487</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-d1e1820-x2-486">
   <w.rf>
    <LM>w#w-d1e1820-x2-486</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1e1820-x2-485">
   <w.rf>
    <LM>w#w-d1e1820-x2-485</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m126-d1e1820-x2-484">
   <w.rf>
    <LM>w#w-d1e1820-x2-484</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m126-d1e1820-x2-483">
   <w.rf>
    <LM>w#w-d1e1820-x2-483</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-856">
  <m id="m126-d1t1823-18">
   <w.rf>
    <LM>w#w-d1t1823-18</LM>
   </w.rf>
   <form>Vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1823-19">
   <w.rf>
    <LM>w#w-d1t1823-19</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m126-d-id152681-punct">
   <w.rf>
    <LM>w#w-d-id152681-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1823-21">
   <w.rf>
    <LM>w#w-d1t1823-21</LM>
   </w.rf>
   <form>vpravo</form>
   <lemma>vpravo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1823-22">
   <w.rf>
    <LM>w#w-d1t1823-22</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m126-d1t1823-23">
   <w.rf>
    <LM>w#w-d1t1823-23</LM>
   </w.rf>
   <form>dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1823-13">
   <w.rf>
    <LM>w#w-d1t1823-13</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m126-d1t1823-14">
   <w.rf>
    <LM>w#w-d1t1823-14</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m126-856-857">
   <w.rf>
    <LM>w#w-856-857</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-858">
  <m id="m126-d1t1825-2">
   <w.rf>
    <LM>w#w-d1t1825-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1825-3">
   <w.rf>
    <LM>w#w-d1t1825-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1825-4">
   <w.rf>
    <LM>w#w-d1t1825-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1825-5">
   <w.rf>
    <LM>w#w-d1t1825-5</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m126-d1t1825-6">
   <w.rf>
    <LM>w#w-d1t1825-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1825-7">
   <w.rf>
    <LM>w#w-d1t1825-7</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-858-859">
   <w.rf>
    <LM>w#w-858-859</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-860">
  <m id="m126-d1t1827-2">
   <w.rf>
    <LM>w#w-d1t1827-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1827-3">
   <w.rf>
    <LM>w#w-d1t1827-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1827-9">
   <w.rf>
    <LM>w#w-d1t1827-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1827-6">
   <w.rf>
    <LM>w#w-d1t1827-6</LM>
   </w.rf>
   <form>možná</form>
   <lemma>možná-1_^(snad)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1827-7">
   <w.rf>
    <LM>w#w-d1t1827-7</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m126-d1t1827-8">
   <w.rf>
    <LM>w#w-d1t1827-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m126-d1t1827-10">
   <w.rf>
    <LM>w#w-d1t1827-10</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-d1t1827-11">
   <w.rf>
    <LM>w#w-d1t1827-11</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-860-861">
   <w.rf>
    <LM>w#w-860-861</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-862">
  <m id="m126-d1t1829-1">
   <w.rf>
    <LM>w#w-d1t1829-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1829-2">
   <w.rf>
    <LM>w#w-d1t1829-2</LM>
   </w.rf>
   <form>ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-862-863">
   <w.rf>
    <LM>w#w-862-863</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-864">
  <m id="m126-d1t1831-2">
   <w.rf>
    <LM>w#w-d1t1831-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1831-1">
   <w.rf>
    <LM>w#w-d1t1831-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1831-3">
   <w.rf>
    <LM>w#w-d1t1831-3</LM>
   </w.rf>
   <form>prima</form>
   <lemma>prima-3_^(výborný)</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m126-d1t1831-4">
   <w.rf>
    <LM>w#w-d1t1831-4</LM>
   </w.rf>
   <form>holky</form>
   <lemma>holka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1820-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1820-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1832-x2">
  <m id="m126-d1t1837-2">
   <w.rf>
    <LM>w#w-d1t1837-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1837-3">
   <w.rf>
    <LM>w#w-d1t1837-3</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1837-4">
   <w.rf>
    <LM>w#w-d1t1837-4</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1832-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1832-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1832-x3">
  <m id="m126-d1t1839-1">
   <w.rf>
    <LM>w#w-d1t1839-1</LM>
   </w.rf>
   <form>Řekněte</form>
   <lemma>říci</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m126-d1t1839-2">
   <w.rf>
    <LM>w#w-d1t1839-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m126-d1t1839-3">
   <w.rf>
    <LM>w#w-d1t1839-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1839-4">
   <w.rf>
    <LM>w#w-d1t1839-4</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP6--3-------</tag>
  </m>
  <m id="m126-d1e1832-x3-865">
   <w.rf>
    <LM>w#w-d1e1832-x3-865</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1839-5">
   <w.rf>
    <LM>w#w-d1t1839-5</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1e1832-x3-866">
   <w.rf>
    <LM>w#w-d1e1832-x3-866</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1839-6">
   <w.rf>
    <LM>w#w-d1t1839-6</LM>
   </w.rf>
   <form>více</form>
   <lemma>více</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m126-d-m-d1e1832-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1832-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1840-x2">
  <m id="m126-d1t1845-2">
   <w.rf>
    <LM>w#w-d1t1845-2</LM>
   </w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m126-d1t1845-3">
   <w.rf>
    <LM>w#w-d1t1845-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1845-4">
   <w.rf>
    <LM>w#w-d1t1845-4</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1845-5">
   <w.rf>
    <LM>w#w-d1t1845-5</LM>
   </w.rf>
   <form>vdané</form>
   <lemma>vdaný_^(*3át)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-d1e1840-x2-880">
   <w.rf>
    <LM>w#w-d1e1840-x2-880</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-881">
  <m id="m126-d1t1847-1">
   <w.rf>
    <LM>w#w-d1t1847-1</LM>
   </w.rf>
   <form>Obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m126-d1t1847-2">
   <w.rf>
    <LM>w#w-d1t1847-2</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1849-1">
   <w.rf>
    <LM>w#w-d1t1849-1</LM>
   </w.rf>
   <form>páreček</form>
   <lemma>páreček</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m126-d-id153592-punct">
   <w.rf>
    <LM>w#w-d-id153592-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1849-3">
   <w.rf>
    <LM>w#w-d1t1849-3</LM>
   </w.rf>
   <form>chlapce</form>
   <lemma>chlapec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m126-d1t1849-4">
   <w.rf>
    <LM>w#w-d1t1849-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1849-5">
   <w.rf>
    <LM>w#w-d1t1849-5</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m126-881-882">
   <w.rf>
    <LM>w#w-881-882</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-883">
  <m id="m126-d1t1854-2">
   <w.rf>
    <LM>w#w-d1t1854-2</LM>
   </w.rf>
   <form>Milenka</form>
   <lemma>Milenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id153729-punct">
   <w.rf>
    <LM>w#w-d-id153729-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1854-5">
   <w.rf>
    <LM>w#w-d1t1854-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1854-6">
   <w.rf>
    <LM>w#w-d1t1854-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1854-7">
   <w.rf>
    <LM>w#w-d1t1854-7</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1854-8">
   <w.rf>
    <LM>w#w-d1t1854-8</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m126-d-id153799-punct">
   <w.rf>
    <LM>w#w-d-id153799-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1854-11">
   <w.rf>
    <LM>w#w-d1t1854-11</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1854-10">
   <w.rf>
    <LM>w#w-d1t1854-10</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1854-12">
   <w.rf>
    <LM>w#w-d1t1854-12</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m126-d-id153855-punct">
   <w.rf>
    <LM>w#w-d-id153855-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1854-14">
   <w.rf>
    <LM>w#w-d1t1854-14</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FP1----------</tag>
  </m>
  <m id="m126-d1t1854-15">
   <w.rf>
    <LM>w#w-d1t1854-15</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1854-16">
   <w.rf>
    <LM>w#w-d1t1854-16</LM>
   </w.rf>
   <form>postižené</form>
   <lemma>postižený</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m126-d1t1854-17">
   <w.rf>
    <LM>w#w-d1t1854-17</LM>
   </w.rf>
   <form>cystickou</form>
   <lemma>cystický</lemma>
   <tag>AAFS7----1A----</tag>
  </m>
  <m id="m126-d1t1854-18">
   <w.rf>
    <LM>w#w-d1t1854-18</LM>
   </w.rf>
   <form>fibrózou</form>
   <lemma>fibróza</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-883-884">
   <w.rf>
    <LM>w#w-883-884</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-885">
  <m id="m126-d1t1858-2">
   <w.rf>
    <LM>w#w-d1t1858-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1858-1">
   <w.rf>
    <LM>w#w-d1t1858-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1858-4">
   <w.rf>
    <LM>w#w-d1t1858-4</LM>
   </w.rf>
   <form>smutné</form>
   <lemma>smutný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m126-d-id154052-punct">
   <w.rf>
    <LM>w#w-d-id154052-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1858-6">
   <w.rf>
    <LM>w#w-d1t1858-6</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1858-7">
   <w.rf>
    <LM>w#w-d1t1858-7</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m126-d1t1858-8">
   <w.rf>
    <LM>w#w-d1t1858-8</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1858-9">
   <w.rf>
    <LM>w#w-d1t1858-9</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1858-10">
   <w.rf>
    <LM>w#w-d1t1858-10</LM>
   </w.rf>
   <form>funguje</form>
   <lemma>fungovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1858-11">
   <w.rf>
    <LM>w#w-d1t1858-11</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d1t1858-12">
   <w.rf>
    <LM>w#w-d1t1858-12</LM>
   </w.rf>
   <form>perfektně</form>
   <lemma>perfektně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m126-d-id154169-punct">
   <w.rf>
    <LM>w#w-d-id154169-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1858-14">
   <w.rf>
    <LM>w#w-d1t1858-14</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m126-d1t1858-15">
   <w.rf>
    <LM>w#w-d1t1858-15</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1t1858-16">
   <w.rf>
    <LM>w#w-d1t1858-16</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-885-887">
   <w.rf>
    <LM>w#w-885-887</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-888">
  <m id="m126-888-931">
   <w.rf>
    <LM>w#w-888-931</LM>
   </w.rf>
   <form>Doufáme</form>
   <lemma>doufat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-888-930">
   <w.rf>
    <LM>w#w-888-930</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-888-929">
   <w.rf>
    <LM>w#w-888-929</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-888-928">
   <w.rf>
    <LM>w#w-888-928</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-888-927">
   <w.rf>
    <LM>w#w-888-927</LM>
   </w.rf>
   <form>přežijou</form>
   <lemma>přežít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m126-888-926">
   <w.rf>
    <LM>w#w-888-926</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m126-888-925">
   <w.rf>
    <LM>w#w-888-925</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-888-924">
   <w.rf>
    <LM>w#w-888-924</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m126-888-923">
   <w.rf>
    <LM>w#w-888-923</LM>
   </w.rf>
   <form>třicet</form>
   <lemma>třicet`30</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m126-888-922">
   <w.rf>
    <LM>w#w-888-922</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m126-888-921">
   <w.rf>
    <LM>w#w-888-921</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-888-920">
   <w.rf>
    <LM>w#w-888-920</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-888-919">
   <w.rf>
    <LM>w#w-888-919</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-888-918">
   <w.rf>
    <LM>w#w-888-918</LM>
   </w.rf>
   <form>píše</form>
   <lemma>psát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-888-917">
   <w.rf>
    <LM>w#w-888-917</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-888-916">
   <w.rf>
    <LM>w#w-888-916</LM>
   </w.rf>
   <form>prospektech</form>
   <lemma>prospekt</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m126-888-932">
   <w.rf>
    <LM>w#w-888-932</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1840-x3">
  <m id="m126-d1t1862-2">
   <w.rf>
    <LM>w#w-d1t1862-2</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1862-3">
   <w.rf>
    <LM>w#w-d1t1862-3</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m126-d1t1862-6">
   <w.rf>
    <LM>w#w-d1t1862-6</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1862-7">
   <w.rf>
    <LM>w#w-d1t1862-7</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1862-8">
   <w.rf>
    <LM>w#w-d1t1862-8</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m126-d1t1862-9">
   <w.rf>
    <LM>w#w-d1t1862-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1862-11">
   <w.rf>
    <LM>w#w-d1t1862-11</LM>
   </w.rf>
   <form>děvče</form>
   <lemma>děvče</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m126-d1e1840-x3-933">
   <w.rf>
    <LM>w#w-d1e1840-x3-933</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-934">
  <m id="m126-d1t1867-1">
   <w.rf>
    <LM>w#w-d1t1867-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1867-2">
   <w.rf>
    <LM>w#w-d1t1867-2</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m126-d1t1867-3">
   <w.rf>
    <LM>w#w-d1t1867-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1867-5">
   <w.rf>
    <LM>w#w-d1t1867-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1867-4">
   <w.rf>
    <LM>w#w-d1t1867-4</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1867-6">
   <w.rf>
    <LM>w#w-d1t1867-6</LM>
   </w.rf>
   <form>nestýkám</form>
   <lemma>stýkat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m126-d-id154789-punct">
   <w.rf>
    <LM>w#w-d-id154789-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-8">
   <w.rf>
    <LM>w#w-d1t1867-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1867-10">
   <w.rf>
    <LM>w#w-d1t1867-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1867-11">
   <w.rf>
    <LM>w#w-d1t1867-11</LM>
   </w.rf>
   <form>zaměstnaná</form>
   <lemma>zaměstnaný_^(*2t)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-934-935">
   <w.rf>
    <LM>w#w-934-935</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-936">
  <m id="m126-d1t1867-13">
   <w.rf>
    <LM>w#w-d1t1867-13</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m126-d-id154890-punct">
   <w.rf>
    <LM>w#w-d-id154890-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-15">
   <w.rf>
    <LM>w#w-d1t1867-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1867-18">
   <w.rf>
    <LM>w#w-d1t1867-18</LM>
   </w.rf>
   <form>Milenka</form>
   <lemma>Milenka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id154963-punct">
   <w.rf>
    <LM>w#w-d-id154963-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-21">
   <w.rf>
    <LM>w#w-d1t1867-21</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1867-22">
   <w.rf>
    <LM>w#w-d1t1867-22</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m126-d1t1867-23">
   <w.rf>
    <LM>w#w-d1t1867-23</LM>
   </w.rf>
   <form>neteř</form>
   <lemma>neteř</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-936-937">
   <w.rf>
    <LM>w#w-936-937</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-24">
   <w.rf>
    <LM>w#w-d1t1867-24</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1867-26">
   <w.rf>
    <LM>w#w-d1t1867-26</LM>
   </w.rf>
   <form>nemocné</form>
   <lemma>nemocný-2_^(vlastnost)</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m126-d1t1867-27">
   <w.rf>
    <LM>w#w-d1t1867-27</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m126-d-id155080-punct">
   <w.rf>
    <LM>w#w-d-id155080-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-29">
   <w.rf>
    <LM>w#w-d1t1867-29</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1867-30">
   <w.rf>
    <LM>w#w-d1t1867-30</LM>
   </w.rf>
   <form>nemůže</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m126-d1t1867-31">
   <w.rf>
    <LM>w#w-d1t1867-31</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d1t1867-32">
   <w.rf>
    <LM>w#w-d1t1867-32</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1867-33">
   <w.rf>
    <LM>w#w-d1t1867-33</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-936-58">
   <w.rf>
    <LM>w#w-936-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-60">
  <m id="m126-d1t1867-35">
   <w.rf>
    <LM>w#w-d1t1867-35</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1867-36">
   <w.rf>
    <LM>w#w-d1t1867-36</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1867-37">
   <w.rf>
    <LM>w#w-d1t1867-37</LM>
   </w.rf>
   <form>přijedeme</form>
   <lemma>přijet</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m126-d1t1867-38">
   <w.rf>
    <LM>w#w-d1t1867-38</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1867-40">
   <w.rf>
    <LM>w#w-d1t1867-40</LM>
   </w.rf>
   <form>Plzně</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-d-id155270-punct">
   <w.rf>
    <LM>w#w-d-id155270-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1867-45">
   <w.rf>
    <LM>w#w-d1t1867-45</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1867-44">
   <w.rf>
    <LM>w#w-d1t1867-44</LM>
   </w.rf>
   <form>samozřejmě</form>
   <lemma>samozřejmě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1867-46">
   <w.rf>
    <LM>w#w-d1t1867-46</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1867-47">
   <w.rf>
    <LM>w#w-d1t1867-47</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS2--3-------</tag>
  </m>
  <m id="m126-936-938">
   <w.rf>
    <LM>w#w-936-938</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-939">
  <m id="m126-d1t1869-1">
   <w.rf>
    <LM>w#w-d1t1869-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1869-3">
   <w.rf>
    <LM>w#w-d1t1869-3</LM>
   </w.rf>
   <form>Alicí</form>
   <lemma>Alice_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-d1t1869-5">
   <w.rf>
    <LM>w#w-d1t1869-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1869-6">
   <w.rf>
    <LM>w#w-d1t1869-6</LM>
   </w.rf>
   <form>jdeme</form>
   <lemma>jít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1869-7">
   <w.rf>
    <LM>w#w-d1t1869-7</LM>
   </w.rf>
   <form>kouknout</form>
   <lemma>kouknout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m126-d1t1869-8">
   <w.rf>
    <LM>w#w-d1t1869-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m126-d1t1869-9">
   <w.rf>
    <LM>w#w-d1t1869-9</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-939-956">
   <w.rf>
    <LM>w#w-939-956</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-957">
  <m id="m126-d1t1869-12">
   <w.rf>
    <LM>w#w-d1t1869-12</LM>
   </w.rf>
   <form>Má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1869-13">
   <w.rf>
    <LM>w#w-d1t1869-13</LM>
   </w.rf>
   <form>takovou</form>
   <lemma>takový</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m126-d1t1869-14">
   <w.rf>
    <LM>w#w-d1t1869-14</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d-id155569-punct">
   <w.rf>
    <LM>w#w-d-id155569-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1869-16">
   <w.rf>
    <LM>w#w-d1t1869-16</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1869-17">
   <w.rf>
    <LM>w#w-d1t1869-17</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1869-22">
   <w.rf>
    <LM>w#w-d1t1869-22</LM>
   </w.rf>
   <form>odejde</form>
   <lemma>odejít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m126-d1t1869-23">
   <w.rf>
    <LM>w#w-d1t1869-23</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1869-24">
   <w.rf>
    <LM>w#w-d1t1869-24</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1869-25">
   <w.rf>
    <LM>w#w-d1t1869-25</LM>
   </w.rf>
   <form>přijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m126-957-958">
   <w.rf>
    <LM>w#w-957-958</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1840-x4">
  <m id="m126-d1t1871-1">
   <w.rf>
    <LM>w#w-d1t1871-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1871-2">
   <w.rf>
    <LM>w#w-d1t1871-2</LM>
   </w.rf>
   <form>tou</form>
   <lemma>ten</lemma>
   <tag>PDFS7----------</tag>
  </m>
  <m id="m126-d1t1871-3">
   <w.rf>
    <LM>w#w-d1t1871-3</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1871-4">
   <w.rf>
    <LM>w#w-d1t1871-4</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1871-6">
   <w.rf>
    <LM>w#w-d1t1871-6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m126-d1t1871-7">
   <w.rf>
    <LM>w#w-d1t1871-7</LM>
   </w.rf>
   <form>styku</form>
   <lemma>styk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m126-d1t1871-5">
   <w.rf>
    <LM>w#w-d1t1871-5</LM>
   </w.rf>
   <form>nejsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m126-d-id155880-punct">
   <w.rf>
    <LM>w#w-d-id155880-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-9">
   <w.rf>
    <LM>w#w-d1t1871-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1871-12">
   <w.rf>
    <LM>w#w-d1t1871-12</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1871-10">
   <w.rf>
    <LM>w#w-d1t1871-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d-id155944-punct">
   <w.rf>
    <LM>w#w-d-id155944-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-14">
   <w.rf>
    <LM>w#w-d1t1871-14</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-d1t1871-15">
   <w.rf>
    <LM>w#w-d1t1871-15</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1871-16">
   <w.rf>
    <LM>w#w-d1t1871-16</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m126-d1t1871-17">
   <w.rf>
    <LM>w#w-d1t1871-17</LM>
   </w.rf>
   <form>narozeniny</form>
   <lemma>narozeniny</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m126-d1e1840-x4-959">
   <w.rf>
    <LM>w#w-d1e1840-x4-959</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-960">
  <m id="m126-d1t1871-20">
   <w.rf>
    <LM>w#w-d1t1871-20</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1871-22">
   <w.rf>
    <LM>w#w-d1t1871-22</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m126-960-961">
   <w.rf>
    <LM>w#w-960-961</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-24">
   <w.rf>
    <LM>w#w-d1t1871-24</LM>
   </w.rf>
   <form>řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d1t1871-23">
   <w.rf>
    <LM>w#w-d1t1871-23</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m126-960-962">
   <w.rf>
    <LM>w#w-960-962</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-21">
   <w.rf>
    <LM>w#w-d1t1871-21</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1871-25">
   <w.rf>
    <LM>w#w-d1t1871-25</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1871-26">
   <w.rf>
    <LM>w#w-d1t1871-26</LM>
   </w.rf>
   <form>pohodě</form>
   <lemma>pohoda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d-id156148-punct">
   <w.rf>
    <LM>w#w-d-id156148-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-28">
   <w.rf>
    <LM>w#w-d1t1871-28</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1871-29">
   <w.rf>
    <LM>w#w-d1t1871-29</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1871-30">
   <w.rf>
    <LM>w#w-d1t1871-30</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m126-d1t1871-31">
   <w.rf>
    <LM>w#w-d1t1871-31</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m126-d-id156219-punct">
   <w.rf>
    <LM>w#w-d-id156219-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1871-35">
   <w.rf>
    <LM>w#w-d1t1871-35</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1871-36">
   <w.rf>
    <LM>w#w-d1t1871-36</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m126-d1t1871-37">
   <w.rf>
    <LM>w#w-d1t1871-37</LM>
   </w.rf>
   <form>nemoc</form>
   <lemma>nemoc</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d-m-d1e1840-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1840-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1872-x2">
  <m id="m126-d1t1875-1">
   <w.rf>
    <LM>w#w-d1t1875-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m126-d1t1875-2">
   <w.rf>
    <LM>w#w-d1t1875-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1875-3">
   <w.rf>
    <LM>w#w-d1t1875-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d-id156397-punct">
   <w.rf>
    <LM>w#w-d-id156397-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1876-x2">
  <m id="m126-d1t1879-1">
   <w.rf>
    <LM>w#w-d1t1879-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1879-2">
   <w.rf>
    <LM>w#w-d1t1879-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-3">
   <w.rf>
    <LM>w#w-d1t1879-3</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m126-d1t1879-4">
   <w.rf>
    <LM>w#w-d1t1879-4</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m126-d1t1879-5">
   <w.rf>
    <LM>w#w-d1t1879-5</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1e1876-x2-983">
   <w.rf>
    <LM>w#w-d1e1876-x2-983</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-984">
  <m id="m126-d1t1879-15">
   <w.rf>
    <LM>w#w-d1t1879-15</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1879-16">
   <w.rf>
    <LM>w#w-d1t1879-16</LM>
   </w.rf>
   <form>čtyřech</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m126-d1t1879-17">
   <w.rf>
    <LM>w#w-d1t1879-17</LM>
   </w.rf>
   <form>letech</form>
   <lemma>léta</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m126-d1t1879-10">
   <w.rf>
    <LM>w#w-d1t1879-10</LM>
   </w.rf>
   <form>vdovství</form>
   <lemma>vdovství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m126-d1t1879-18">
   <w.rf>
    <LM>w#w-d1t1879-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-19">
   <w.rf>
    <LM>w#w-d1t1879-19</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m126-d1t1879-20">
   <w.rf>
    <LM>w#w-d1t1879-20</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d1t1879-21">
   <w.rf>
    <LM>w#w-d1t1879-21</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS4----------</tag>
  </m>
  <m id="m126-d1t1879-22">
   <w.rf>
    <LM>w#w-d1t1879-22</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m126-d-id156780-punct">
   <w.rf>
    <LM>w#w-d-id156780-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-24">
   <w.rf>
    <LM>w#w-d1t1879-24</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-984-150">
   <w.rf>
    <LM>w#w-984-150</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-26">
   <w.rf>
    <LM>w#w-d1t1879-26</LM>
   </w.rf>
   <form>Aritmáka</form>
   <lemma>Aritmák_,h</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m126-984-151">
   <w.rf>
    <LM>w#w-984-151</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-984-985">
   <w.rf>
    <LM>w#w-984-985</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-986">
  <m id="m126-d1t1879-38">
   <w.rf>
    <LM>w#w-d1t1879-38</LM>
   </w.rf>
   <form>Vzadu</form>
   <lemma>vzadu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1879-41">
   <w.rf>
    <LM>w#w-d1t1879-41</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-42">
   <w.rf>
    <LM>w#w-d1t1879-42</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-986-129">
   <w.rf>
    <LM>w#w-986-129</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-44">
   <w.rf>
    <LM>w#w-d1t1879-44</LM>
   </w.rf>
   <form>Aritmáci</form>
   <lemma>Aritmák_,h</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m126-986-130">
   <w.rf>
    <LM>w#w-986-130</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d-id157088-punct">
   <w.rf>
    <LM>w#w-d-id157088-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-47">
   <w.rf>
    <LM>w#w-d1t1879-47</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1879-48">
   <w.rf>
    <LM>w#w-d1t1879-48</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m126-d1t1879-49">
   <w.rf>
    <LM>w#w-d1t1879-49</LM>
   </w.rf>
   <form>stará</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-d1t1879-50">
   <w.rf>
    <LM>w#w-d1t1879-50</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id157159-punct">
   <w.rf>
    <LM>w#w-d-id157159-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-52">
   <w.rf>
    <LM>w#w-d1t1879-52</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m126-d1t1879-53">
   <w.rf>
    <LM>w#w-d1t1879-53</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1879-54">
   <w.rf>
    <LM>w#w-d1t1879-54</LM>
   </w.rf>
   <form>sedí</form>
   <lemma>sedět</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d-id157214-punct">
   <w.rf>
    <LM>w#w-d-id157214-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1879-57">
   <w.rf>
    <LM>w#w-d1t1879-57</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-58">
   <w.rf>
    <LM>w#w-d1t1879-58</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m126-d1t1879-59">
   <w.rf>
    <LM>w#w-d1t1879-59</LM>
   </w.rf>
   <form>tetička</form>
   <lemma>tetička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1879-61">
   <w.rf>
    <LM>w#w-d1t1879-61</LM>
   </w.rf>
   <form>Marta</form>
   <lemma>Marta_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-986-121">
   <w.rf>
    <LM>w#w-986-121</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-124">
  <m id="m126-d1t1879-65">
   <w.rf>
    <LM>w#w-d1t1879-65</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-66">
   <w.rf>
    <LM>w#w-d1t1879-66</LM>
   </w.rf>
   <form>sestrou</form>
   <lemma>sestra</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m126-d1t1879-67">
   <w.rf>
    <LM>w#w-d1t1879-67</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS2-S1------1</tag>
  </m>
  <m id="m126-d1t1879-68">
   <w.rf>
    <LM>w#w-d1t1879-68</LM>
   </w.rf>
   <form>maminky</form>
   <lemma>maminka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m126-986-987">
   <w.rf>
    <LM>w#w-986-987</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-988">
  <m id="m126-d1t1879-70">
   <w.rf>
    <LM>w#w-d1t1879-70</LM>
   </w.rf>
   <form>Taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1879-71">
   <w.rf>
    <LM>w#w-d1t1879-71</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1879-73">
   <w.rf>
    <LM>w#w-d1t1879-73</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1879-72">
   <w.rf>
    <LM>w#w-d1t1879-72</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m126-d1t1879-74">
   <w.rf>
    <LM>w#w-d1t1879-74</LM>
   </w.rf>
   <form>mrtvá</form>
   <lemma>mrtvý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-988-989">
   <w.rf>
    <LM>w#w-988-989</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1876-x3">
  <m id="m126-d1t1883-1">
   <w.rf>
    <LM>w#w-d1t1883-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1883-2">
   <w.rf>
    <LM>w#w-d1t1883-2</LM>
   </w.rf>
   <form>mnou</form>
   <lemma>já</lemma>
   <tag>PP-S7--1-------</tag>
  </m>
  <m id="m126-d1t1883-3">
   <w.rf>
    <LM>w#w-d1t1883-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1883-4">
   <w.rf>
    <LM>w#w-d1t1883-4</LM>
   </w.rf>
   <form>svědek</form>
   <lemma>svědek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1t1883-6">
   <w.rf>
    <LM>w#w-d1t1883-6</LM>
   </w.rf>
   <form>Andulka</form>
   <lemma>Andulka_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id157610-punct">
   <w.rf>
    <LM>w#w-d-id157610-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1883-9">
   <w.rf>
    <LM>w#w-d1t1883-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1883-10">
   <w.rf>
    <LM>w#w-d1t1883-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1883-11">
   <w.rf>
    <LM>w#w-d1t1883-11</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d1t1883-12">
   <w.rf>
    <LM>w#w-d1t1883-12</LM>
   </w.rf>
   <form>mého</form>
   <lemma>můj</lemma>
   <tag>PSZS2-S1-------</tag>
  </m>
  <m id="m126-d1t1883-13">
   <w.rf>
    <LM>w#w-d1t1883-13</LM>
   </w.rf>
   <form>bratra</form>
   <lemma>bratr</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m126-d1e1876-x3-136">
   <w.rf>
    <LM>w#w-d1e1876-x3-136</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-138">
  <m id="m126-d1t1883-15">
   <w.rf>
    <LM>w#w-d1t1883-15</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m126-d1t1883-17">
   <w.rf>
    <LM>w#w-d1t1883-17</LM>
   </w.rf>
   <form>Iljou</form>
   <lemma>Ilja_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m126-d-id157760-punct">
   <w.rf>
    <LM>w#w-d-id157760-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1883-20">
   <w.rf>
    <LM>w#w-d1t1883-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-d1t1883-21">
   <w.rf>
    <LM>w#w-d1t1883-21</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1883-22">
   <w.rf>
    <LM>w#w-d1t1883-22</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m126-d1t1885-1">
   <w.rf>
    <LM>w#w-d1t1885-1</LM>
   </w.rf>
   <form>nynější</form>
   <lemma>nynější</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m126-d1t1883-23">
   <w.rf>
    <LM>w#w-d1t1883-23</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1e1876-x3-1021">
   <w.rf>
    <LM>w#w-d1e1876-x3-1021</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1885-2">
   <w.rf>
    <LM>w#w-d1t1885-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-d1t1885-3">
   <w.rf>
    <LM>w#w-d1t1885-3</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m126-d1t1885-4">
   <w.rf>
    <LM>w#w-d1t1885-4</LM>
   </w.rf>
   <form>bratr</form>
   <lemma>bratr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1t1885-6">
   <w.rf>
    <LM>w#w-d1t1885-6</LM>
   </w.rf>
   <form>Miloš</form>
   <lemma>Miloš_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1e1876-x3-1022">
   <w.rf>
    <LM>w#w-d1e1876-x3-1022</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1023">
  <m id="m126-d1t1885-9">
   <w.rf>
    <LM>w#w-d1t1885-9</LM>
   </w.rf>
   <form>Miloušek</form>
   <lemma>Miloušek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m126-d1e1876-x3-1019">
   <w.rf>
    <LM>w#w-d1e1876-x3-1019</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1020">
  <m id="m126-1020-1037">
   <w.rf>
    <LM>w#w-1020-1037</LM>
   </w.rf>
   <form>Tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-1020-1036">
   <w.rf>
    <LM>w#w-1020-1036</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-1020-1035">
   <w.rf>
    <LM>w#w-1020-1035</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-1020-1034">
   <w.rf>
    <LM>w#w-1020-1034</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-1020-1033">
   <w.rf>
    <LM>w#w-1020-1033</LM>
   </w.rf>
   <form>štíhlá</form>
   <lemma>štíhlý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m126-1020-1032">
   <w.rf>
    <LM>w#w-1020-1032</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-1020-1031">
   <w.rf>
    <LM>w#w-1020-1031</LM>
   </w.rf>
   <form>koukám</form>
   <lemma>koukat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m126-1020-1030">
   <w.rf>
    <LM>w#w-1020-1030</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-1020-1029">
   <w.rf>
    <LM>w#w-1020-1029</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m126-1020-1028">
   <w.rf>
    <LM>w#w-1020-1028</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m126-1020-1027">
   <w.rf>
    <LM>w#w-1020-1027</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m126-1020-1026">
   <w.rf>
    <LM>w#w-1020-1026</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-1020-1025">
   <w.rf>
    <LM>w#w-1020-1025</LM>
   </w.rf>
   <form>sluší</form>
   <lemma>slušet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m126-1020-1024">
   <w.rf>
    <LM>w#w-1020-1024</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1893-x2">
  <m id="m126-d1t1896-1">
   <w.rf>
    <LM>w#w-d1t1896-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1896-2">
   <w.rf>
    <LM>w#w-d1t1896-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m126-d1t1896-3">
   <w.rf>
    <LM>w#w-d1t1896-3</LM>
   </w.rf>
   <form>svého</form>
   <lemma>svůj-1</lemma>
   <tag>P8MS4----------</tag>
  </m>
  <m id="m126-d1t1896-4">
   <w.rf>
    <LM>w#w-d1t1896-4</LM>
   </w.rf>
   <form>druhého</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS4----------</tag>
  </m>
  <m id="m126-d1t1896-5">
   <w.rf>
    <LM>w#w-d1t1896-5</LM>
   </w.rf>
   <form>muže</form>
   <lemma>muž</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m126-d1t1896-6">
   <w.rf>
    <LM>w#w-d1t1896-6</LM>
   </w.rf>
   <form>poznala</form>
   <lemma>poznat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m126-d-id158350-punct">
   <w.rf>
    <LM>w#w-d-id158350-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1898-x2">
  <m id="m126-d1t1905-1">
   <w.rf>
    <LM>w#w-d1t1905-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1905-3">
   <w.rf>
    <LM>w#w-d1t1905-3</LM>
   </w.rf>
   <form>Aritmě</form>
   <lemma>Aritma_;m</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m126-d1e1898-x2-1045">
   <w.rf>
    <LM>w#w-d1e1898-x2-1045</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-1046">
  <m id="m126-d1t1905-8">
   <w.rf>
    <LM>w#w-d1t1905-8</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m126-d1t1905-7">
   <w.rf>
    <LM>w#w-d1t1905-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1905-6">
   <w.rf>
    <LM>w#w-d1t1905-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1905-9">
   <w.rf>
    <LM>w#w-d1t1905-9</LM>
   </w.rf>
   <form>vyslaní</form>
   <lemma>vyslaný_^(*2t)</lemma>
   <tag>AAMP1----1A----</tag>
  </m>
  <m id="m126-d1t1905-10">
   <w.rf>
    <LM>w#w-d1t1905-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m126-d1t1905-11">
   <w.rf>
    <LM>w#w-d1t1905-11</LM>
   </w.rf>
   <form>služební</form>
   <lemma>služební_^(poměr,byt,zbraň,...)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m126-d1t1905-12">
   <w.rf>
    <LM>w#w-d1t1905-12</LM>
   </w.rf>
   <form>cestu</form>
   <lemma>cesta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m126-d-id158596-punct">
   <w.rf>
    <LM>w#w-d-id158596-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m126-d1t1905-14">
   <w.rf>
    <LM>w#w-d1t1905-14</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1905-16">
   <w.rf>
    <LM>w#w-d1t1905-16</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1905-17">
   <w.rf>
    <LM>w#w-d1t1905-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1905-18">
   <w.rf>
    <LM>w#w-d1t1905-18</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m126-d1t1905-19">
   <w.rf>
    <LM>w#w-d1t1905-19</LM>
   </w.rf>
   <form>sobě</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--6----------</tag>
  </m>
  <m id="m126-d1t1905-20">
   <w.rf>
    <LM>w#w-d1t1905-20</LM>
   </w.rf>
   <form>koukali</form>
   <lemma>koukat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m126-d1t1905-21">
   <w.rf>
    <LM>w#w-d1t1905-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m126-d1t1905-22">
   <w.rf>
    <LM>w#w-d1t1905-22</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1905-23">
   <w.rf>
    <LM>w#w-d1t1905-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m126-d1t1905-25">
   <w.rf>
    <LM>w#w-d1t1905-25</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1905-24">
   <w.rf>
    <LM>w#w-d1t1905-24</LM>
   </w.rf>
   <form>začali</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m126-d1t1905-26">
   <w.rf>
    <LM>w#w-d1t1905-26</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m126-d-m-d1e1898-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1898-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m126-d1e1906-x2">
  <m id="m126-d1t1909-1">
   <w.rf>
    <LM>w#w-d1t1909-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m126-d1t1909-2">
   <w.rf>
    <LM>w#w-d1t1909-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m126-d1t1909-3">
   <w.rf>
    <LM>w#w-d1t1909-3</LM>
   </w.rf>
   <form>konala</form>
   <lemma>konat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m126-d1t1909-4">
   <w.rf>
    <LM>w#w-d1t1909-4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHS1-P2-------</tag>
  </m>
  <m id="m126-d1t1909-5">
   <w.rf>
    <LM>w#w-d1t1909-5</LM>
   </w.rf>
   <form>svatba</form>
   <lemma>svatba</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m126-d-id158936-punct">
   <w.rf>
    <LM>w#w-d-id158936-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
