<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="es_139.04.w.gz" />
  </references>
 </head>
 <s id="m139-d1e1655-x2">
  <m id="m139-d1t1658-1">
   <w.rf>
    <LM>w#w-d1t1658-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1658-2">
   <w.rf>
    <LM>w#w-d1t1658-2</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m139-d1t1658-3">
   <w.rf>
    <LM>w#w-d1t1658-3</LM>
   </w.rf>
   <form>radost</form>
   <lemma>radost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1658-4">
   <w.rf>
    <LM>w#w-d1t1658-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1658-5">
   <w.rf>
    <LM>w#w-d1t1658-5</LM>
   </w.rf>
   <form>starost</form>
   <lemma>starost-2_^(*5ý-2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d-id100886-punct">
   <w.rf>
    <LM>w#w-d-id100886-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1659-x2">
  <m id="m139-d1t1666-2">
   <w.rf>
    <LM>w#w-d1t1666-2</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1666-3">
   <w.rf>
    <LM>w#w-d1t1666-3</LM>
   </w.rf>
   <form>obojí</form>
   <lemma>obojí</lemma>
   <tag>CdXS1----------</tag>
  </m>
  <m id="m139-d1e1659-x2-664">
   <w.rf>
    <LM>w#w-d1e1659-x2-664</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1666-5">
   <w.rf>
    <LM>w#w-d1t1666-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1666-6">
   <w.rf>
    <LM>w#w-d1t1666-6</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1e1659-x2-665">
   <w.rf>
    <LM>w#w-d1e1659-x2-665</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1666-7">
   <w.rf>
    <LM>w#w-d1t1666-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1666-8">
   <w.rf>
    <LM>w#w-d1t1666-8</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m139-d1t1666-9">
   <w.rf>
    <LM>w#w-d1t1666-9</LM>
   </w.rf>
   <form>zatím</form>
   <lemma>zatím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1670-1">
   <w.rf>
    <LM>w#w-d1t1670-1</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m139-d1t1670-2">
   <w.rf>
    <LM>w#w-d1t1670-2</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m139-d1t1670-3">
   <w.rf>
    <LM>w#w-d1t1670-3</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d1t1666-10">
   <w.rf>
    <LM>w#w-d1t1666-10</LM>
   </w.rf>
   <form>dělaly</form>
   <lemma>dělat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1666-11">
   <w.rf>
    <LM>w#w-d1t1666-11</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m139-d1t1668-1">
   <w.rf>
    <LM>w#w-d1t1668-1</LM>
   </w.rf>
   <form>radosti</form>
   <lemma>radost</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1e1659-x2-666">
   <w.rf>
    <LM>w#w-d1e1659-x2-666</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-663">
  <m id="m139-d1t1670-5">
   <w.rf>
    <LM>w#w-d1t1670-5</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1670-6">
   <w.rf>
    <LM>w#w-d1t1670-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1670-7">
   <w.rf>
    <LM>w#w-d1t1670-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1670-8">
   <w.rf>
    <LM>w#w-d1t1670-8</LM>
   </w.rf>
   <form>dospělé</form>
   <lemma>dospělý_^(*2t)</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m139-d-id101283-punct">
   <w.rf>
    <LM>w#w-d-id101283-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1670-10">
   <w.rf>
    <LM>w#w-d1t1670-10</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1673-1">
   <w.rf>
    <LM>w#w-d1t1673-1</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1675-1">
   <w.rf>
    <LM>w#w-d1t1675-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1677-1">
   <w.rf>
    <LM>w#w-d1t1677-1</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1677-2">
   <w.rf>
    <LM>w#w-d1t1677-2</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1677-3">
   <w.rf>
    <LM>w#w-d1t1677-3</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1659-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1659-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1684-x2">
  <m id="m139-d1t1687-1">
   <w.rf>
    <LM>w#w-d1t1687-1</LM>
   </w.rf>
   <form>Krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m139-d1t1687-2">
   <w.rf>
    <LM>w#w-d1t1687-2</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1684-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1684-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1688-x2">
  <m id="m139-d1t1695-3">
   <w.rf>
    <LM>w#w-d1t1695-3</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1695-4">
   <w.rf>
    <LM>w#w-d1t1695-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1695-5">
   <w.rf>
    <LM>w#w-d1t1695-5</LM>
   </w.rf>
   <form>dívám</form>
   <lemma>dívat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1695-6">
   <w.rf>
    <LM>w#w-d1t1695-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1695-7">
   <w.rf>
    <LM>w#w-d1t1695-7</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m139-d1t1695-8">
   <w.rf>
    <LM>w#w-d1t1695-8</LM>
   </w.rf>
   <form>fotografie</form>
   <lemma>fotografie</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d-id101675-punct">
   <w.rf>
    <LM>w#w-d-id101675-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1697-1">
   <w.rf>
    <LM>w#w-d1t1697-1</LM>
   </w.rf>
   <form>vybavuju</form>
   <lemma>vybavovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1695-11">
   <w.rf>
    <LM>w#w-d1t1695-11</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1699-2">
   <w.rf>
    <LM>w#w-d1t1699-2</LM>
   </w.rf>
   <form>opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1699-3">
   <w.rf>
    <LM>w#w-d1t1699-3</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m139-d1t1699-4">
   <w.rf>
    <LM>w#w-d1t1699-4</LM>
   </w.rf>
   <form>krásné</form>
   <lemma>krásný</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m139-d1t1699-5">
   <w.rf>
    <LM>w#w-d1t1699-5</LM>
   </w.rf>
   <form>vzpomínky</form>
   <lemma>vzpomínka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1688-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1688-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1705-x2">
  <m id="m139-d1t1708-1">
   <w.rf>
    <LM>w#w-d1t1708-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m139-d1t1708-2">
   <w.rf>
    <LM>w#w-d1t1708-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1708-3">
   <w.rf>
    <LM>w#w-d1t1708-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d-id101938-punct">
   <w.rf>
    <LM>w#w-d-id101938-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1709-x2">
  <m id="m139-d1t1712-1">
   <w.rf>
    <LM>w#w-d1t1712-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1712-2">
   <w.rf>
    <LM>w#w-d1t1712-2</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m139-d1t1712-3">
   <w.rf>
    <LM>w#w-d1t1712-3</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1t1712-4">
   <w.rf>
    <LM>w#w-d1t1712-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1712-7">
   <w.rf>
    <LM>w#w-d1t1712-7</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m139-d1t1712-8">
   <w.rf>
    <LM>w#w-d1t1712-8</LM>
   </w.rf>
   <form>bráška</form>
   <lemma>bráška</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-d-id102124-punct">
   <w.rf>
    <LM>w#w-d-id102124-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1712-10">
   <w.rf>
    <LM>w#w-d1t1712-10</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1712-11">
   <w.rf>
    <LM>w#w-d1t1712-11</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m139-d1t1712-12">
   <w.rf>
    <LM>w#w-d1t1712-12</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1712-13">
   <w.rf>
    <LM>w#w-d1t1712-13</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1714-1">
   <w.rf>
    <LM>w#w-d1t1714-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1714-2">
   <w.rf>
    <LM>w#w-d1t1714-2</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-d1t1714-3">
   <w.rf>
    <LM>w#w-d1t1714-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1716-1">
   <w.rf>
    <LM>w#w-d1t1716-1</LM>
   </w.rf>
   <form>necelý</form>
   <lemma>celý</lemma>
   <tag>AAIS1----1N----</tag>
  </m>
  <m id="m139-d1t1718-1">
   <w.rf>
    <LM>w#w-d1t1718-1</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-d1e1709-x2-1012">
   <w.rf>
    <LM>w#w-d1e1709-x2-1012</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1013">
  <m id="m139-d1t1720-2">
   <w.rf>
    <LM>w#w-d1t1720-2</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1720-3">
   <w.rf>
    <LM>w#w-d1t1720-3</LM>
   </w.rf>
   <form>kočárku</form>
   <lemma>kočárek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1t1720-4">
   <w.rf>
    <LM>w#w-d1t1720-4</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m139-d1t1720-5">
   <w.rf>
    <LM>w#w-d1t1720-5</LM>
   </w.rf>
   <form>vozí</form>
   <lemma>vozit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1720-6">
   <w.rf>
    <LM>w#w-d1t1720-6</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m139-d1t1720-7">
   <w.rf>
    <LM>w#w-d1t1720-7</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d-id102428-punct">
   <w.rf>
    <LM>w#w-d-id102428-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1725-2">
   <w.rf>
    <LM>w#w-d1t1725-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1725-3">
   <w.rf>
    <LM>w#w-d1t1725-3</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m139-d1t1725-4">
   <w.rf>
    <LM>w#w-d1t1725-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1733-1">
   <w.rf>
    <LM>w#w-d1t1733-1</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m139-d1t1733-2">
   <w.rf>
    <LM>w#w-d1t1733-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-d1t1727-2">
   <w.rf>
    <LM>w#w-d1t1727-2</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1e1709-x2-684">
   <w.rf>
    <LM>w#w-d1e1709-x2-684</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-682">
  <m id="m139-d1t1736-1">
   <w.rf>
    <LM>w#w-d1t1736-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1736-2">
   <w.rf>
    <LM>w#w-d1t1736-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1736-3">
   <w.rf>
    <LM>w#w-d1t1736-3</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t1736-4">
   <w.rf>
    <LM>w#w-d1t1736-4</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-682-686">
   <w.rf>
    <LM>w#w-682-686</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-683">
  <m id="m139-d1t1738-1">
   <w.rf>
    <LM>w#w-d1t1738-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1738-2">
   <w.rf>
    <LM>w#w-d1t1738-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1738-3">
   <w.rf>
    <LM>w#w-d1t1738-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1738-4">
   <w.rf>
    <LM>w#w-d1t1738-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1738-5">
   <w.rf>
    <LM>w#w-d1t1738-5</LM>
   </w.rf>
   <form>jedné</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS6----------</tag>
  </m>
  <m id="m139-d1t1738-6">
   <w.rf>
    <LM>w#w-d1t1738-6</LM>
   </w.rf>
   <form>místnosti</form>
   <lemma>místnost</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1738-7">
   <w.rf>
    <LM>w#w-d1t1738-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1738-8">
   <w.rf>
    <LM>w#w-d1t1738-8</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1738-9">
   <w.rf>
    <LM>w#w-d1t1738-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1740-1">
   <w.rf>
    <LM>w#w-d1t1740-1</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m139-d1t1740-2">
   <w.rf>
    <LM>w#w-d1t1740-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-d1t1740-3">
   <w.rf>
    <LM>w#w-d1t1740-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1740-5">
   <w.rf>
    <LM>w#w-d1t1740-5</LM>
   </w.rf>
   <form>družstevní</form>
   <lemma>družstevní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m139-d1t1740-6">
   <w.rf>
    <LM>w#w-d1t1740-6</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d-id102918-punct">
   <w.rf>
    <LM>w#w-d-id102918-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1744-1">
   <w.rf>
    <LM>w#w-d1t1744-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1744-2">
   <w.rf>
    <LM>w#w-d1t1744-2</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d1t1744-3">
   <w.rf>
    <LM>w#w-d1t1744-3</LM>
   </w.rf>
   <form>vyrůstaly</form>
   <lemma>vyrůstat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1746-3">
   <w.rf>
    <LM>w#w-d1t1746-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1746-4">
   <w.rf>
    <LM>w#w-d1t1746-4</LM>
   </w.rf>
   <form>venkově</form>
   <lemma>venkov</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-683-690">
   <w.rf>
    <LM>w#w-683-690</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1709-x3">
  <m id="m139-d1t1746-7">
   <w.rf>
    <LM>w#w-d1t1746-7</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1746-8">
   <w.rf>
    <LM>w#w-d1t1746-8</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1749-1">
   <w.rf>
    <LM>w#w-d1t1749-1</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m139-d1t1749-2">
   <w.rf>
    <LM>w#w-d1t1749-2</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1709-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1709-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1752-x2">
  <m id="m139-d1t1755-1">
   <w.rf>
    <LM>w#w-d1t1755-1</LM>
   </w.rf>
   <form>Kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1755-2">
   <w.rf>
    <LM>w#w-d1t1755-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1755-3">
   <w.rf>
    <LM>w#w-d1t1755-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1755-4">
   <w.rf>
    <LM>w#w-d1t1755-4</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1755-5">
   <w.rf>
    <LM>w#w-d1t1755-5</LM>
   </w.rf>
   <form>odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d-id103291-punct">
   <w.rf>
    <LM>w#w-d-id103291-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1756-x2">
  <m id="m139-d1t1763-1">
   <w.rf>
    <LM>w#w-d1t1763-1</LM>
   </w.rf>
   <form>Odstěhovali</form>
   <lemma>odstěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1763-2">
   <w.rf>
    <LM>w#w-d1t1763-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1763-3">
   <w.rf>
    <LM>w#w-d1t1763-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1763-4">
   <w.rf>
    <LM>w#w-d1t1763-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1763-5">
   <w.rf>
    <LM>w#w-d1t1763-5</LM>
   </w.rf>
   <form>okresního</form>
   <lemma>okresní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m139-d1t1765-1">
   <w.rf>
    <LM>w#w-d1t1765-1</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m139-d-id103473-punct">
   <w.rf>
    <LM>w#w-d-id103473-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1767-1">
   <w.rf>
    <LM>w#w-d1t1767-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1767-3">
   <w.rf>
    <LM>w#w-d1t1767-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1767-4">
   <w.rf>
    <LM>w#w-d1t1767-4</LM>
   </w.rf>
   <form>studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d-id103548-punct">
   <w.rf>
    <LM>w#w-d-id103548-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1770-1">
   <w.rf>
    <LM>w#w-d1t1770-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1770-2">
   <w.rf>
    <LM>w#w-d1t1770-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1770-3">
   <w.rf>
    <LM>w#w-d1t1770-3</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t1770-4">
   <w.rf>
    <LM>w#w-d1t1770-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1770-5">
   <w.rf>
    <LM>w#w-d1t1770-5</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-d1t1770-6">
   <w.rf>
    <LM>w#w-d1t1770-6</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1770-10">
   <w.rf>
    <LM>w#w-d1t1770-10</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1e1756-x2-1031">
   <w.rf>
    <LM>w#w-d1e1756-x2-1031</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1032">
  <m id="m139-d1t1772-2">
   <w.rf>
    <LM>w#w-d1t1772-2</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1772-3">
   <w.rf>
    <LM>w#w-d1t1772-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1772-4">
   <w.rf>
    <LM>w#w-d1t1772-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1772-6">
   <w.rf>
    <LM>w#w-d1t1772-6</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1772-5">
   <w.rf>
    <LM>w#w-d1t1772-5</LM>
   </w.rf>
   <form>skončili</form>
   <lemma>skončit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1772-7">
   <w.rf>
    <LM>w#w-d1t1772-7</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1772-8">
   <w.rf>
    <LM>w#w-d1t1772-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1772-9">
   <w.rf>
    <LM>w#w-d1t1772-9</LM>
   </w.rf>
   <form>bydlením</form>
   <lemma>bydlení_^(*2t)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1756-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1756-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1777-x2">
  <m id="m139-d1t1780-1">
   <w.rf>
    <LM>w#w-d1t1780-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1780-2">
   <w.rf>
    <LM>w#w-d1t1780-2</LM>
   </w.rf>
   <form>kolika</form>
   <lemma>kolik</lemma>
   <tag>Ca--6----------</tag>
  </m>
  <m id="m139-d1t1780-3">
   <w.rf>
    <LM>w#w-d1t1780-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1780-4">
   <w.rf>
    <LM>w#w-d1t1780-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1780-5">
   <w.rf>
    <LM>w#w-d1t1780-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1780-6">
   <w.rf>
    <LM>w#w-d1t1780-6</LM>
   </w.rf>
   <form>mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m139-d1t1780-7">
   <w.rf>
    <LM>w#w-d1t1780-7</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1t1780-8">
   <w.rf>
    <LM>w#w-d1t1780-8</LM>
   </w.rf>
   <form>zpět</form>
   <lemma>zpět</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1780-9">
   <w.rf>
    <LM>w#w-d1t1780-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1780-10">
   <w.rf>
    <LM>w#w-d1t1780-10</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d-id104066-punct">
   <w.rf>
    <LM>w#w-d-id104066-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1781-x2">
  <m id="m139-d1t1786-1">
   <w.rf>
    <LM>w#w-d1t1786-1</LM>
   </w.rf>
   <form>Do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1786-2">
   <w.rf>
    <LM>w#w-d1t1786-2</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t1788-1">
   <w.rf>
    <LM>w#w-d1t1788-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1788-2">
   <w.rf>
    <LM>w#w-d1t1788-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1790-2">
   <w.rf>
    <LM>w#w-d1t1790-2</LM>
   </w.rf>
   <form>vrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1e1781-x2-707">
   <w.rf>
    <LM>w#w-d1e1781-x2-707</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1790-3">
   <w.rf>
    <LM>w#w-d1t1790-3</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1790-4">
   <w.rf>
    <LM>w#w-d1t1790-4</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1795-1">
   <w.rf>
    <LM>w#w-d1t1795-1</LM>
   </w.rf>
   <form>dceři</form>
   <lemma>dcera</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m139-d1t1797-1">
   <w.rf>
    <LM>w#w-d1t1797-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1797-2">
   <w.rf>
    <LM>w#w-d1t1797-2</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m139-d1t1797-3">
   <w.rf>
    <LM>w#w-d1t1797-3</LM>
   </w.rf>
   <form>roků</form>
   <lemma>rok</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m139-d1t1797-4">
   <w.rf>
    <LM>w#w-d1t1797-4</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1797-5">
   <w.rf>
    <LM>w#w-d1t1797-5</LM>
   </w.rf>
   <form>synovi</form>
   <lemma>syn</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m139-d1t1797-6">
   <w.rf>
    <LM>w#w-d1t1797-6</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m139-d-id104405-punct">
   <w.rf>
    <LM>w#w-d-id104405-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1797-8">
   <w.rf>
    <LM>w#w-d1t1797-8</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1799-1">
   <w.rf>
    <LM>w#w-d1t1799-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1799-2">
   <w.rf>
    <LM>w#w-d1t1799-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1799-3">
   <w.rf>
    <LM>w#w-d1t1799-3</LM>
   </w.rf>
   <form>jich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3------1</tag>
  </m>
  <m id="m139-d1t1801-1">
   <w.rf>
    <LM>w#w-d1t1801-1</LM>
   </w.rf>
   <form>užila</form>
   <lemma>užít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1t1801-2">
   <w.rf>
    <LM>w#w-d1t1801-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1e1781-x2-68">
   <w.rf>
    <LM>w#w-d1e1781-x2-68</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-706">
  <m id="m139-d1t1803-2">
   <w.rf>
    <LM>w#w-d1t1803-2</LM>
   </w.rf>
   <form>Předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1803-4">
   <w.rf>
    <LM>w#w-d1t1803-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1803-5">
   <w.rf>
    <LM>w#w-d1t1803-5</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-706-713">
   <w.rf>
    <LM>w#w-706-713</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1805-2">
   <w.rf>
    <LM>w#w-d1t1805-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1810-1">
   <w.rf>
    <LM>w#w-d1t1810-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1810-2">
   <w.rf>
    <LM>w#w-d1t1810-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1812-1">
   <w.rf>
    <LM>w#w-d1t1812-1</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1814-1">
   <w.rf>
    <LM>w#w-d1t1814-1</LM>
   </w.rf>
   <form>dceru</form>
   <lemma>dcera</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-706-1047">
   <w.rf>
    <LM>w#w-706-1047</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1048">
  <m id="m139-d1t1821-1">
   <w.rf>
    <LM>w#w-d1t1821-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1821-2">
   <w.rf>
    <LM>w#w-d1t1821-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1821-3">
   <w.rf>
    <LM>w#w-d1t1821-3</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-706-715">
   <w.rf>
    <LM>w#w-706-715</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1821-5">
   <w.rf>
    <LM>w#w-d1t1821-5</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1821-4">
   <w.rf>
    <LM>w#w-d1t1821-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m139-d1t1821-6">
   <w.rf>
    <LM>w#w-d1t1821-6</LM>
   </w.rf>
   <form>maminka</form>
   <lemma>maminka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1821-7">
   <w.rf>
    <LM>w#w-d1t1821-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1821-8">
   <w.rf>
    <LM>w#w-d1t1821-8</LM>
   </w.rf>
   <form>odpoledne</form>
   <lemma>odpoledne-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-706-716">
   <w.rf>
    <LM>w#w-706-716</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1821-9">
   <w.rf>
    <LM>w#w-d1t1821-9</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1821-10">
   <w.rf>
    <LM>w#w-d1t1821-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1821-11">
   <w.rf>
    <LM>w#w-d1t1821-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1821-12">
   <w.rf>
    <LM>w#w-d1t1821-12</LM>
   </w.rf>
   <form>vrátili</form>
   <lemma>vrátit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-706-717">
   <w.rf>
    <LM>w#w-706-717</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1821-14">
   <w.rf>
    <LM>w#w-d1t1821-14</LM>
   </w.rf>
   <form>tato</form>
   <lemma>tento</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m139-d1t1821-15">
   <w.rf>
    <LM>w#w-d1t1821-15</LM>
   </w.rf>
   <form>babička</form>
   <lemma>babička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1781-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1781-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1828-x2">
  <m id="m139-d1t1831-1">
   <w.rf>
    <LM>w#w-d1t1831-1</LM>
   </w.rf>
   <form>Jaké</form>
   <lemma>jaký</lemma>
   <tag>P4FP4----------</tag>
  </m>
  <m id="m139-d1t1831-2">
   <w.rf>
    <LM>w#w-d1t1831-2</LM>
   </w.rf>
   <form>záliby</form>
   <lemma>záliba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t1831-3">
   <w.rf>
    <LM>w#w-d1t1831-3</LM>
   </w.rf>
   <form>měly</form>
   <lemma>mít</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1831-4">
   <w.rf>
    <LM>w#w-d1t1831-4</LM>
   </w.rf>
   <form>vaše</form>
   <lemma>váš</lemma>
   <tag>PSHP1-P2-------</tag>
  </m>
  <m id="m139-d1t1831-5">
   <w.rf>
    <LM>w#w-d1t1831-5</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d-id105161-punct">
   <w.rf>
    <LM>w#w-d-id105161-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1832-x2">
  <m id="m139-d1t1841-1">
   <w.rf>
    <LM>w#w-d1t1841-1</LM>
   </w.rf>
   <form>Děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d1t1843-1">
   <w.rf>
    <LM>w#w-d1t1843-1</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1848-1">
   <w.rf>
    <LM>w#w-d1t1848-1</LM>
   </w.rf>
   <form>tátou</form>
   <lemma>táta</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m139-d1t1848-2">
   <w.rf>
    <LM>w#w-d1t1848-2</LM>
   </w.rf>
   <form>vychovávány</form>
   <lemma>vychovávat_^(*4at)</lemma>
   <tag>VsTP----X-API--</tag>
  </m>
  <m id="m139-d1t1848-3">
   <w.rf>
    <LM>w#w-d1t1848-3</LM>
   </w.rf>
   <form>sportovně</form>
   <lemma>sportovně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d-id105370-punct">
   <w.rf>
    <LM>w#w-d-id105370-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1848-5">
   <w.rf>
    <LM>w#w-d1t1848-5</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1848-6">
   <w.rf>
    <LM>w#w-d1t1848-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1e1832-x2-741">
   <w.rf>
    <LM>w#w-d1e1832-x2-741</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1848-7">
   <w.rf>
    <LM>w#w-d1t1848-7</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1848-8">
   <w.rf>
    <LM>w#w-d1t1848-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1850-1">
   <w.rf>
    <LM>w#w-d1t1850-1</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1850-2">
   <w.rf>
    <LM>w#w-d1t1850-2</LM>
   </w.rf>
   <form>větší</form>
   <lemma>velký</lemma>
   <tag>AAFP1----2A----</tag>
  </m>
  <m id="m139-d1e1832-x2-742">
   <w.rf>
    <LM>w#w-d1e1832-x2-742</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1852-1">
   <w.rf>
    <LM>w#w-d1t1852-1</LM>
   </w.rf>
   <form>lyžovaly</form>
   <lemma>lyžovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d-id105505-punct">
   <w.rf>
    <LM>w#w-d-id105505-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1852-3">
   <w.rf>
    <LM>w#w-d1t1852-3</LM>
   </w.rf>
   <form>plavaly</form>
   <lemma>plavat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1e1832-x2-740">
   <w.rf>
    <LM>w#w-d1e1832-x2-740</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-739">
  <m id="m139-d1e1832-x2-724">
   <w.rf>
    <LM>w#w-d1e1832-x2-724</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1e1832-x2-725">
   <w.rf>
    <LM>w#w-d1e1832-x2-725</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1e1832-x2-726">
   <w.rf>
    <LM>w#w-d1e1832-x2-726</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m139-d1e1832-x2-727">
   <w.rf>
    <LM>w#w-d1e1832-x2-727</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1e1832-x2-728">
   <w.rf>
    <LM>w#w-d1e1832-x2-728</LM>
   </w.rf>
   <form>vedla</form>
   <lemma>vést</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1e1832-x2-729">
   <w.rf>
    <LM>w#w-d1e1832-x2-729</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m139-d1e1832-x2-730">
   <w.rf>
    <LM>w#w-d1e1832-x2-730</LM>
   </w.rf>
   <form>knížkám</form>
   <lemma>knížka</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m139-d1e1832-x2-731">
   <w.rf>
    <LM>w#w-d1e1832-x2-731</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1e1832-x2-732">
   <w.rf>
    <LM>w#w-d1e1832-x2-732</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-739-746">
   <w.rf>
    <LM>w#w-739-746</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1e1832-x2-733">
   <w.rf>
    <LM>w#w-d1e1832-x2-733</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1e1832-x2-734">
   <w.rf>
    <LM>w#w-d1e1832-x2-734</LM>
   </w.rf>
   <form>četly</form>
   <lemma>číst</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-739-1059">
   <w.rf>
    <LM>w#w-739-1059</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1060">
  <m id="m139-d1e1832-x2-736">
   <w.rf>
    <LM>w#w-d1e1832-x2-736</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1e1832-x2-737">
   <w.rf>
    <LM>w#w-d1e1832-x2-737</LM>
   </w.rf>
   <form>víc</form>
   <lemma>více</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m139-d1e1832-x2-738">
   <w.rf>
    <LM>w#w-d1e1832-x2-738</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1856-1">
   <w.rf>
    <LM>w#w-d1t1856-1</LM>
   </w.rf>
   <form>sportovaly</form>
   <lemma>sportovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-739-747">
   <w.rf>
    <LM>w#w-739-747</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1859-1">
   <w.rf>
    <LM>w#w-d1t1859-1</LM>
   </w.rf>
   <form>zatímco</form>
   <lemma>zatímco</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1859-2">
   <w.rf>
    <LM>w#w-d1t1859-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t1859-3">
   <w.rf>
    <LM>w#w-d1t1859-3</LM>
   </w.rf>
   <form>tolik</form>
   <lemma>tolik-3_^(ve_spojení_s_adj.)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1859-4">
   <w.rf>
    <LM>w#w-d1t1859-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d-m-d1e1832-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1832-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1867-x2">
  <m id="m139-d1t1870-1">
   <w.rf>
    <LM>w#w-d1t1870-1</LM>
   </w.rf>
   <form>Četla</form>
   <lemma>číst</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1870-2">
   <w.rf>
    <LM>w#w-d1t1870-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1870-3">
   <w.rf>
    <LM>w#w-d1t1870-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m139-d1t1870-4">
   <w.rf>
    <LM>w#w-d1t1870-4</LM>
   </w.rf>
   <form>pohádky</form>
   <lemma>pohádka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d-id105762-punct">
   <w.rf>
    <LM>w#w-d-id105762-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1871-x2">
  <m id="m139-d1t1878-2">
   <w.rf>
    <LM>w#w-d1t1878-2</LM>
   </w.rf>
   <form>Četla</form>
   <lemma>číst</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1878-3">
   <w.rf>
    <LM>w#w-d1t1878-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1878-4">
   <w.rf>
    <LM>w#w-d1t1878-4</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m139-d1t1878-5">
   <w.rf>
    <LM>w#w-d1t1878-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1878-8">
   <w.rf>
    <LM>w#w-d1t1878-8</LM>
   </w.rf>
   <form>usnutí</form>
   <lemma>usnutí_^(*3out)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m139-d1t1880-1">
   <w.rf>
    <LM>w#w-d1t1880-1</LM>
   </w.rf>
   <form>pohádky</form>
   <lemma>pohádka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d-id105994-punct">
   <w.rf>
    <LM>w#w-d-id105994-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1882-3">
   <w.rf>
    <LM>w#w-d1t1882-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1885-1">
   <w.rf>
    <LM>w#w-d1t1885-1</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1889-1">
   <w.rf>
    <LM>w#w-d1t1889-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1889-2">
   <w.rf>
    <LM>w#w-d1t1889-2</LM>
   </w.rf>
   <form>dívaly</form>
   <lemma>dívat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1889-3">
   <w.rf>
    <LM>w#w-d1t1889-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1889-4">
   <w.rf>
    <LM>w#w-d1t1889-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1889-5">
   <w.rf>
    <LM>w#w-d1t1889-5</LM>
   </w.rf>
   <form>pohádky</form>
   <lemma>pohádka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t1889-6">
   <w.rf>
    <LM>w#w-d1t1889-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1889-7">
   <w.rf>
    <LM>w#w-d1t1889-7</LM>
   </w.rf>
   <form>televizi</form>
   <lemma>televize</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1e1871-x2-756">
   <w.rf>
    <LM>w#w-d1e1871-x2-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-755">
  <m id="m139-d1t1891-2">
   <w.rf>
    <LM>w#w-d1t1891-2</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d-id106213-punct">
   <w.rf>
    <LM>w#w-d-id106213-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1891-4">
   <w.rf>
    <LM>w#w-d1t1891-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1891-5">
   <w.rf>
    <LM>w#w-d1t1891-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1891-6">
   <w.rf>
    <LM>w#w-d1t1891-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m139-d1t1891-7">
   <w.rf>
    <LM>w#w-d1t1891-7</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1891-8">
   <w.rf>
    <LM>w#w-d1t1891-8</LM>
   </w.rf>
   <form>začaly</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpTP----R-AAP--</tag>
  </m>
  <m id="m139-d1t1891-9">
   <w.rf>
    <LM>w#w-d1t1891-9</LM>
   </w.rf>
   <form>večerníčky</form>
   <lemma>večerníček</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m139-d-id106315-punct">
   <w.rf>
    <LM>w#w-d-id106315-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1893-1">
   <w.rf>
    <LM>w#w-d1t1893-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1893-2">
   <w.rf>
    <LM>w#w-d1t1893-2</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t1893-3">
   <w.rf>
    <LM>w#w-d1t1893-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1893-4">
   <w.rf>
    <LM>w#w-d1t1893-4</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m139-d1t1893-6">
   <w.rf>
    <LM>w#w-d1t1893-6</LM>
   </w.rf>
   <form>četla</form>
   <lemma>číst</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1893-7">
   <w.rf>
    <LM>w#w-d1t1893-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1893-8">
   <w.rf>
    <LM>w#w-d1t1893-8</LM>
   </w.rf>
   <form>nutila</form>
   <lemma>nutit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1893-9">
   <w.rf>
    <LM>w#w-d1t1893-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1893-10">
   <w.rf>
    <LM>w#w-d1t1893-10</LM>
   </w.rf>
   <form>je</form>
   <lemma>on-1</lemma>
   <tag>PEXP4--3-------</tag>
  </m>
  <m id="m139-d1t1893-11">
   <w.rf>
    <LM>w#w-d1t1893-11</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m139-d1t1893-13">
   <w.rf>
    <LM>w#w-d1t1893-13</LM>
   </w.rf>
   <form>četbě</form>
   <lemma>četba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1871-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1871-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1896-x2">
  <m id="m139-d1t1899-1">
   <w.rf>
    <LM>w#w-d1t1899-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m139-d1t1899-2">
   <w.rf>
    <LM>w#w-d1t1899-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t1899-3">
   <w.rf>
    <LM>w#w-d1t1899-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1899-4">
   <w.rf>
    <LM>w#w-d1t1899-4</LM>
   </w.rf>
   <form>mateřské</form>
   <lemma>mateřský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m139-d1t1899-5">
   <w.rf>
    <LM>w#w-d1t1899-5</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1899-6">
   <w.rf>
    <LM>w#w-d1t1899-6</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t1899-7">
   <w.rf>
    <LM>w#w-d1t1899-7</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id106704-punct">
   <w.rf>
    <LM>w#w-d-id106704-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1900-x2">
  <m id="m139-d1t1907-2">
   <w.rf>
    <LM>w#w-d1t1907-2</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1907-3">
   <w.rf>
    <LM>w#w-d1t1907-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1907-4">
   <w.rf>
    <LM>w#w-d1t1907-4</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1907-5">
   <w.rf>
    <LM>w#w-d1t1907-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1907-6">
   <w.rf>
    <LM>w#w-d1t1907-6</LM>
   </w.rf>
   <form>zaměstnání</form>
   <lemma>zaměstnání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m139-d1t1907-7">
   <w.rf>
    <LM>w#w-d1t1907-7</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1907-8">
   <w.rf>
    <LM>w#w-d1t1907-8</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1907-9">
   <w.rf>
    <LM>w#w-d1t1907-9</LM>
   </w.rf>
   <form>obou</form>
   <lemma>oba`2</lemma>
   <tag>CnXP6----------</tag>
  </m>
  <m id="m139-d1t1907-10">
   <w.rf>
    <LM>w#w-d1t1907-10</LM>
   </w.rf>
   <form>dětech</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m139-d-id106939-punct">
   <w.rf>
    <LM>w#w-d-id106939-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1911-4">
   <w.rf>
    <LM>w#w-d1t1911-4</LM>
   </w.rf>
   <form>nevrátila</form>
   <lemma>vrátit</lemma>
   <tag>VpQW----R-NAP--</tag>
  </m>
  <m id="m139-d1t1911-2">
   <w.rf>
    <LM>w#w-d1t1911-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1911-3">
   <w.rf>
    <LM>w#w-d1t1911-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t1911-5">
   <w.rf>
    <LM>w#w-d1t1911-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m139-d1t1911-7">
   <w.rf>
    <LM>w#w-d1t1911-7</LM>
   </w.rf>
   <form>původnímu</form>
   <lemma>původní</lemma>
   <tag>AANS3----1A----</tag>
  </m>
  <m id="m139-d1t1911-8">
   <w.rf>
    <LM>w#w-d1t1911-8</LM>
   </w.rf>
   <form>povolání</form>
   <lemma>povolání_^(*3at)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m139-d1t1911-9">
   <w.rf>
    <LM>w#w-d1t1911-9</LM>
   </w.rf>
   <form>ekonomky</form>
   <lemma>ekonomka_^(*2)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t1911-10">
   <w.rf>
    <LM>w#w-d1t1911-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1911-11">
   <w.rf>
    <LM>w#w-d1t1911-11</LM>
   </w.rf>
   <form>účetní</form>
   <lemma>účetní-3</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d-id107145-punct">
   <w.rf>
    <LM>w#w-d-id107145-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1914-2">
   <w.rf>
    <LM>w#w-d1t1914-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1914-3">
   <w.rf>
    <LM>w#w-d1t1914-3</LM>
   </w.rf>
   <form>nastoupila</form>
   <lemma>nastoupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1t1914-4">
   <w.rf>
    <LM>w#w-d1t1914-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1914-5">
   <w.rf>
    <LM>w#w-d1t1914-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1914-6">
   <w.rf>
    <LM>w#w-d1t1914-6</LM>
   </w.rf>
   <form>knihovny</form>
   <lemma>knihovna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1e1900-x2-13">
   <w.rf>
    <LM>w#w-d1e1900-x2-13</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-12">
  <m id="m139-d1t1916-1">
   <w.rf>
    <LM>w#w-d1t1916-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1916-2">
   <w.rf>
    <LM>w#w-d1t1916-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1916-4">
   <w.rf>
    <LM>w#w-d1t1916-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t1916-5">
   <w.rf>
    <LM>w#w-d1t1916-5</LM>
   </w.rf>
   <form>podmínkou</form>
   <lemma>podmínka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m139-d-id107326-punct">
   <w.rf>
    <LM>w#w-d-id107326-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1918-1">
   <w.rf>
    <LM>w#w-d1t1918-1</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1918-2">
   <w.rf>
    <LM>w#w-d1t1918-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1918-3">
   <w.rf>
    <LM>w#w-d1t1918-3</LM>
   </w.rf>
   <form>dodělám</form>
   <lemma>dodělat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m139-d1t1918-4">
   <w.rf>
    <LM>w#w-d1t1918-4</LM>
   </w.rf>
   <form>knihovnickou</form>
   <lemma>knihovnický</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m139-d1t1918-5">
   <w.rf>
    <LM>w#w-d1t1918-5</LM>
   </w.rf>
   <form>nástavbu</form>
   <lemma>nástavba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id107440-punct">
   <w.rf>
    <LM>w#w-d-id107440-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1924-1">
   <w.rf>
    <LM>w#w-d1t1924-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1927-1">
   <w.rf>
    <LM>w#w-d1t1927-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1929-1">
   <w.rf>
    <LM>w#w-d1t1929-1</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1929-2">
   <w.rf>
    <LM>w#w-d1t1929-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1929-4">
   <w.rf>
    <LM>w#w-d1t1929-4</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t1929-6">
   <w.rf>
    <LM>w#w-d1t1929-6</LM>
   </w.rf>
   <form>studovat</form>
   <lemma>studovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m139-12-15">
   <w.rf>
    <LM>w#w-12-15</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-14">
  <m id="m139-d1t1929-8">
   <w.rf>
    <LM>w#w-d1t1929-8</LM>
   </w.rf>
   <form>Dcera</form>
   <lemma>dcera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1929-9">
   <w.rf>
    <LM>w#w-d1t1929-9</LM>
   </w.rf>
   <form>šla</form>
   <lemma>jít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1929-10">
   <w.rf>
    <LM>w#w-d1t1929-10</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1929-11">
   <w.rf>
    <LM>w#w-d1t1929-11</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m139-d1t1929-12">
   <w.rf>
    <LM>w#w-d1t1929-12</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t1929-13">
   <w.rf>
    <LM>w#w-d1t1929-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t1929-14">
   <w.rf>
    <LM>w#w-d1t1929-14</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1929-15">
   <w.rf>
    <LM>w#w-d1t1929-15</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m139-d1t1929-16">
   <w.rf>
    <LM>w#w-d1t1929-16</LM>
   </w.rf>
   <form>divné</form>
   <lemma>divný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d-id107736-punct">
   <w.rf>
    <LM>w#w-d-id107736-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1929-18">
   <w.rf>
    <LM>w#w-d1t1929-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1929-19">
   <w.rf>
    <LM>w#w-d1t1929-19</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t1929-20">
   <w.rf>
    <LM>w#w-d1t1929-20</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1929-21">
   <w.rf>
    <LM>w#w-d1t1929-21</LM>
   </w.rf>
   <form>chodím</form>
   <lemma>chodit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1929-22">
   <w.rf>
    <LM>w#w-d1t1929-22</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1929-23">
   <w.rf>
    <LM>w#w-d1t1929-23</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-14-1090">
   <w.rf>
    <LM>w#w-14-1090</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1091">
  <m id="m139-d1t1931-3">
   <w.rf>
    <LM>w#w-d1t1931-3</LM>
   </w.rf>
   <form>Zvládly</form>
   <lemma>zvládnout</lemma>
   <tag>VpTP----R-AAP-1</tag>
  </m>
  <m id="m139-d1t1931-4">
   <w.rf>
    <LM>w#w-d1t1931-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1931-5">
   <w.rf>
    <LM>w#w-d1t1931-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t1933-1">
   <w.rf>
    <LM>w#w-d1t1933-1</LM>
   </w.rf>
   <form>obě</form>
   <lemma>oba`2</lemma>
   <tag>CnHP1----------</tag>
  </m>
  <m id="m139-d-m-d1e1900-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1900-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1938-x2">
  <m id="m139-d1t1941-1">
   <w.rf>
    <LM>w#w-d1t1941-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m139-d1t1941-2">
   <w.rf>
    <LM>w#w-d1t1941-2</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1941-3">
   <w.rf>
    <LM>w#w-d1t1941-3</LM>
   </w.rf>
   <form>knihovnice</form>
   <lemma>knihovnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t1941-4">
   <w.rf>
    <LM>w#w-d1t1941-4</LM>
   </w.rf>
   <form>obnáší</form>
   <lemma>obnášet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d-id108086-punct">
   <w.rf>
    <LM>w#w-d-id108086-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1942-x2">
  <m id="m139-d1t1949-2">
   <w.rf>
    <LM>w#w-d1t1949-2</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1949-3">
   <w.rf>
    <LM>w#w-d1t1949-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1949-4">
   <w.rf>
    <LM>w#w-d1t1949-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t1949-5">
   <w.rf>
    <LM>w#w-d1t1949-5</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1949-6">
   <w.rf>
    <LM>w#w-d1t1949-6</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m139-d-id108259-punct">
   <w.rf>
    <LM>w#w-d-id108259-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1949-8">
   <w.rf>
    <LM>w#w-d1t1949-8</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1949-9">
   <w.rf>
    <LM>w#w-d1t1949-9</LM>
   </w.rf>
   <form>knížky</form>
   <lemma>knížka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t1949-10">
   <w.rf>
    <LM>w#w-d1t1949-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1949-12">
   <w.rf>
    <LM>w#w-d1t1949-12</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1949-13">
   <w.rf>
    <LM>w#w-d1t1949-13</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m139-d1t1949-14">
   <w.rf>
    <LM>w#w-d1t1949-14</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1949-15">
   <w.rf>
    <LM>w#w-d1t1949-15</LM>
   </w.rf>
   <form>dětství</form>
   <lemma>dětství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m139-d1e1942-x2-41">
   <w.rf>
    <LM>w#w-d1e1942-x2-41</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-36">
  <m id="m139-d1t1953-1">
   <w.rf>
    <LM>w#w-d1t1953-1</LM>
   </w.rf>
   <form>Dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1953-2">
   <w.rf>
    <LM>w#w-d1t1953-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1953-3">
   <w.rf>
    <LM>w#w-d1t1953-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1953-4">
   <w.rf>
    <LM>w#w-d1t1953-4</LM>
   </w.rf>
   <form>metodičku</form>
   <lemma>metodička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id108480-punct">
   <w.rf>
    <LM>w#w-d-id108480-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1953-8">
   <w.rf>
    <LM>w#w-d1t1953-8</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1953-7">
   <w.rf>
    <LM>w#w-d1t1953-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1953-9">
   <w.rf>
    <LM>w#w-d1t1953-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1953-10">
   <w.rf>
    <LM>w#w-d1t1953-10</LM>
   </w.rf>
   <form>knihovnách</form>
   <lemma>knihovna</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m139-d1t1953-11">
   <w.rf>
    <LM>w#w-d1t1953-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1953-12">
   <w.rf>
    <LM>w#w-d1t1953-12</LM>
   </w.rf>
   <form>okrese</form>
   <lemma>okres</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d-id108598-punct">
   <w.rf>
    <LM>w#w-d-id108598-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1953-14">
   <w.rf>
    <LM>w#w-d1t1953-14</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1953-15">
   <w.rf>
    <LM>w#w-d1t1953-15</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1953-16">
   <w.rf>
    <LM>w#w-d1t1953-16</LM>
   </w.rf>
   <form>poznala</form>
   <lemma>poznat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1t1953-17">
   <w.rf>
    <LM>w#w-d1t1953-17</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t1958-1">
   <w.rf>
    <LM>w#w-d1t1958-1</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSIS4-P1-------</tag>
  </m>
  <m id="m139-d1t1958-2">
   <w.rf>
    <LM>w#w-d1t1958-2</LM>
   </w.rf>
   <form>okres</form>
   <lemma>okres</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-36-1102">
   <w.rf>
    <LM>w#w-36-1102</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1103">
  <m id="m139-d1t1958-4">
   <w.rf>
    <LM>w#w-d1t1958-4</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1958-5">
   <w.rf>
    <LM>w#w-d1t1958-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1958-6">
   <w.rf>
    <LM>w#w-d1t1958-6</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t1958-7">
   <w.rf>
    <LM>w#w-d1t1958-7</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-36-46">
   <w.rf>
    <LM>w#w-36-46</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-37">
  <m id="m139-d1t1960-2">
   <w.rf>
    <LM>w#w-d1t1960-2</LM>
   </w.rf>
   <form>Knížky</form>
   <lemma>knížka</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m139-d1t1960-3">
   <w.rf>
    <LM>w#w-d1t1960-3</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m139-d1t1960-4">
   <w.rf>
    <LM>w#w-d1t1960-4</LM>
   </w.rf>
   <form>kolem</form>
   <lemma>kolem-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m139-d1t1960-5">
   <w.rf>
    <LM>w#w-d1t1960-5</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S2--1-------</tag>
  </m>
  <m id="m139-d-id108881-punct">
   <w.rf>
    <LM>w#w-d-id108881-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1960-7">
   <w.rf>
    <LM>w#w-d1t1960-7</LM>
   </w.rf>
   <form>mohla</form>
   <lemma>moci</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1960-8">
   <w.rf>
    <LM>w#w-d1t1960-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1960-9">
   <w.rf>
    <LM>w#w-d1t1960-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t1960-10">
   <w.rf>
    <LM>w#w-d1t1960-10</LM>
   </w.rf>
   <form>vybrat</form>
   <lemma>vybrat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m139-d-id108961-punct">
   <w.rf>
    <LM>w#w-d-id108961-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1962-2">
   <w.rf>
    <LM>w#w-d1t1962-2</LM>
   </w.rf>
   <form>kterou</form>
   <lemma>který</lemma>
   <tag>P4FS4----------</tag>
  </m>
  <m id="m139-d1t1962-3">
   <w.rf>
    <LM>w#w-d1t1962-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1962-4">
   <w.rf>
    <LM>w#w-d1t1962-4</LM>
   </w.rf>
   <form>chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d1t1962-5">
   <w.rf>
    <LM>w#w-d1t1962-5</LM>
   </w.rf>
   <form>číst</form>
   <lemma>číst</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m139-37-50">
   <w.rf>
    <LM>w#w-37-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-38">
  <m id="m139-d1t1962-7">
   <w.rf>
    <LM>w#w-d1t1962-7</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1962-8">
   <w.rf>
    <LM>w#w-d1t1962-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1962-9">
   <w.rf>
    <LM>w#w-d1t1962-9</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d-m-d1e1942-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1942-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1969-x2">
  <m id="m139-d1t1972-1">
   <w.rf>
    <LM>w#w-d1t1972-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m139-d1e1969-x2-54">
   <w.rf>
    <LM>w#w-d1e1969-x2-54</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-53">
  <m id="m139-d1t1974-1">
   <w.rf>
    <LM>w#w-d1t1974-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m139-d1t1974-2">
   <w.rf>
    <LM>w#w-d1t1974-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m139-d1t1974-3">
   <w.rf>
    <LM>w#w-d1t1974-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1974-4">
   <w.rf>
    <LM>w#w-d1t1974-4</LM>
   </w.rf>
   <form>této</form>
   <lemma>tento</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m139-d1t1974-5">
   <w.rf>
    <LM>w#w-d1t1974-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d-id109248-punct">
   <w.rf>
    <LM>w#w-d-id109248-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e1975-x2">
  <m id="m139-d1t1982-1">
   <w.rf>
    <LM>w#w-d1t1982-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1982-2">
   <w.rf>
    <LM>w#w-d1t1982-2</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m139-d1t1982-4">
   <w.rf>
    <LM>w#w-d1t1982-4</LM>
   </w.rf>
   <form>fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1984-1">
   <w.rf>
    <LM>w#w-d1t1984-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1984-2">
   <w.rf>
    <LM>w#w-d1t1984-2</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m139-d1t1986-1">
   <w.rf>
    <LM>w#w-d1t1986-1</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1e1975-x2-1113">
   <w.rf>
    <LM>w#w-d1e1975-x2-1113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1114">
  <m id="m139-d1t1986-5">
   <w.rf>
    <LM>w#w-d1t1986-5</LM>
   </w.rf>
   <form>Říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t1986-4">
   <w.rf>
    <LM>w#w-d1t1986-4</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m139-d1t1993-1">
   <w.rf>
    <LM>w#w-d1t1993-1</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSHS1-P1-------</tag>
  </m>
  <m id="m139-d1t1993-2">
   <w.rf>
    <LM>w#w-d1t1993-2</LM>
   </w.rf>
   <form>rodinné</form>
   <lemma>rodinný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d1t1993-3">
   <w.rf>
    <LM>w#w-d1t1993-3</LM>
   </w.rf>
   <form>maturitní</form>
   <lemma>maturitní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d1t1995-2">
   <w.rf>
    <LM>w#w-d1t1995-2</LM>
   </w.rf>
   <form>foto</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m139-d-id109644-punct">
   <w.rf>
    <LM>w#w-d-id109644-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t1995-4">
   <w.rf>
    <LM>w#w-d1t1995-4</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t1995-5">
   <w.rf>
    <LM>w#w-d1t1995-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t1995-6">
   <w.rf>
    <LM>w#w-d1t1995-6</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t1995-7">
   <w.rf>
    <LM>w#w-d1t1995-7</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m139-d1t1995-8">
   <w.rf>
    <LM>w#w-d1t1995-8</LM>
   </w.rf>
   <form>dny</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m139-d1t1995-9">
   <w.rf>
    <LM>w#w-d1t1995-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1995-10">
   <w.rf>
    <LM>w#w-d1t1995-10</LM>
   </w.rf>
   <form>mé</form>
   <lemma>můj</lemma>
   <tag>PSFS6-S1------1</tag>
  </m>
  <m id="m139-d1t1995-11">
   <w.rf>
    <LM>w#w-d1t1995-11</LM>
   </w.rf>
   <form>maturitě</form>
   <lemma>maturita</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1t1995-12">
   <w.rf>
    <LM>w#w-d1t1995-12</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t1997-1">
   <w.rf>
    <LM>w#w-d1t1997-1</LM>
   </w.rf>
   <form>knihovnické</form>
   <lemma>knihovnický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m139-d1t1995-13">
   <w.rf>
    <LM>w#w-d1t1995-13</LM>
   </w.rf>
   <form>nástavbě</form>
   <lemma>nástavba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d1e1975-x2-79">
   <w.rf>
    <LM>w#w-d1e1975-x2-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-65">
  <m id="m139-d1t2002-3">
   <w.rf>
    <LM>w#w-d1t2002-3</LM>
   </w.rf>
   <form>Protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2002-4">
   <w.rf>
    <LM>w#w-d1t2002-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m139-d1t2002-5">
   <w.rf>
    <LM>w#w-d1t2002-5</LM>
   </w.rf>
   <form>rodina</form>
   <lemma>rodina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t2002-9">
   <w.rf>
    <LM>w#w-d1t2002-9</LM>
   </w.rf>
   <form>pomohla</form>
   <lemma>pomoci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d-id109993-punct">
   <w.rf>
    <LM>w#w-d-id109993-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2008-1">
   <w.rf>
    <LM>w#w-d1t2008-1</LM>
   </w.rf>
   <form>manžel</form>
   <lemma>manžel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-d1t2008-2">
   <w.rf>
    <LM>w#w-d1t2008-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m139-d1t2008-3">
   <w.rf>
    <LM>w#w-d1t2008-3</LM>
   </w.rf>
   <form>bral</form>
   <lemma>brát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t2008-4">
   <w.rf>
    <LM>w#w-d1t2008-4</LM>
   </w.rf>
   <form>děti</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t2008-5">
   <w.rf>
    <LM>w#w-d1t2008-5</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t2008-6">
   <w.rf>
    <LM>w#w-d1t2008-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t2008-7">
   <w.rf>
    <LM>w#w-d1t2008-7</LM>
   </w.rf>
   <form>víkend</form>
   <lemma>víkend</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m139-d1t2008-8">
   <w.rf>
    <LM>w#w-d1t2008-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t2008-9">
   <w.rf>
    <LM>w#w-d1t2008-9</LM>
   </w.rf>
   <form>hory</form>
   <lemma>hora</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m139-d1t2008-10">
   <w.rf>
    <LM>w#w-d1t2008-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t2008-11">
   <w.rf>
    <LM>w#w-d1t2008-11</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m139-d1t2008-12">
   <w.rf>
    <LM>w#w-d1t2008-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2008-13">
   <w.rf>
    <LM>w#w-d1t2008-13</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t2008-14">
   <w.rf>
    <LM>w#w-d1t2008-14</LM>
   </w.rf>
   <form>učila</form>
   <lemma>učit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d-id110252-punct">
   <w.rf>
    <LM>w#w-d-id110252-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2010-1">
   <w.rf>
    <LM>w#w-d1t2010-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t2010-2">
   <w.rf>
    <LM>w#w-d1t2010-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2010-3">
   <w.rf>
    <LM>w#w-d1t2010-3</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m139-d-id110316-punct">
   <w.rf>
    <LM>w#w-d-id110316-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2010-5">
   <w.rf>
    <LM>w#w-d1t2010-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2010-6">
   <w.rf>
    <LM>w#w-d1t2010-6</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t2010-7">
   <w.rf>
    <LM>w#w-d1t2010-7</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m139-d1t2010-8">
   <w.rf>
    <LM>w#w-d1t2010-8</LM>
   </w.rf>
   <form>podporou</form>
   <lemma>podpora_^(peníze;_tyč;_morální_p.)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m139-d1t2010-9">
   <w.rf>
    <LM>w#w-d1t2010-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t2010-10">
   <w.rf>
    <LM>w#w-d1t2010-10</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2012-1">
   <w.rf>
    <LM>w#w-d1t2012-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t2015-1">
   <w.rf>
    <LM>w#w-d1t2015-1</LM>
   </w.rf>
   <form>dáme</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m139-d1t2015-2">
   <w.rf>
    <LM>w#w-d1t2015-2</LM>
   </w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m139-d1t2015-3">
   <w.rf>
    <LM>w#w-d1t2015-3</LM>
   </w.rf>
   <form>vyfotografovat</form>
   <lemma>vyfotografovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m139-d1t2015-4">
   <w.rf>
    <LM>w#w-d1t2015-4</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2017-1">
   <w.rf>
    <LM>w#w-d1t2017-1</LM>
   </w.rf>
   <form>maturitní</form>
   <lemma>maturitní</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d1t2017-2">
   <w.rf>
    <LM>w#w-d1t2017-2</LM>
   </w.rf>
   <form>foto</form>
   <lemma>foto</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m139-d-m-d1e1975-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1975-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e2024-x3">
  <m id="m139-d1t2031-1">
   <w.rf>
    <LM>w#w-d1t2031-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t2031-2">
   <w.rf>
    <LM>w#w-d1t2031-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m139-d1t2031-3">
   <w.rf>
    <LM>w#w-d1t2031-3</LM>
   </w.rf>
   <form>tuto</form>
   <lemma>tento</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m139-d1t2031-4">
   <w.rf>
    <LM>w#w-d1t2031-4</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1t2031-5">
   <w.rf>
    <LM>w#w-d1t2031-5</LM>
   </w.rf>
   <form>pořídili</form>
   <lemma>pořídit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d-id110723-punct">
   <w.rf>
    <LM>w#w-d-id110723-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e2032-x2">
  <m id="m139-d1t2041-1">
   <w.rf>
    <LM>w#w-d1t2041-1</LM>
   </w.rf>
   <form>Fotografii</form>
   <lemma>fotografie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1t2043-1">
   <w.rf>
    <LM>w#w-d1t2043-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2046-1">
   <w.rf>
    <LM>w#w-d1t2046-1</LM>
   </w.rf>
   <form>uskutečnili</form>
   <lemma>uskutečnit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m139-d1t2046-3">
   <w.rf>
    <LM>w#w-d1t2046-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m139-d1t2046-4">
   <w.rf>
    <LM>w#w-d1t2046-4</LM>
   </w.rf>
   <form>fotografickém</form>
   <lemma>fotografický</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m139-d1t2046-5">
   <w.rf>
    <LM>w#w-d1t2046-5</LM>
   </w.rf>
   <form>ateliéru</form>
   <lemma>ateliér</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m139-d1t2050-1">
   <w.rf>
    <LM>w#w-d1t2050-1</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m139-d1t2050-2">
   <w.rf>
    <LM>w#w-d1t2050-2</LM>
   </w.rf>
   <form>městě</form>
   <lemma>město</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m139-d-id111002-punct">
   <w.rf>
    <LM>w#w-d-id111002-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2050-4">
   <w.rf>
    <LM>w#w-d1t2050-4</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t2050-5">
   <w.rf>
    <LM>w#w-d1t2050-5</LM>
   </w.rf>
   <form>žijeme</form>
   <lemma>žít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1e2032-x2-1123">
   <w.rf>
    <LM>w#w-d1e2032-x2-1123</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2054-1">
   <w.rf>
    <LM>w#w-d1t2054-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m139-d1t2054-2">
   <w.rf>
    <LM>w#w-d1t2054-2</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t2054-3">
   <w.rf>
    <LM>w#w-d1t2054-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t2054-4">
   <w.rf>
    <LM>w#w-d1t2054-4</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m139-d1t2054-5">
   <w.rf>
    <LM>w#w-d1t2054-5</LM>
   </w.rf>
   <form>povedla</form>
   <lemma>povést</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-d1e2032-x2-99">
   <w.rf>
    <LM>w#w-d1e2032-x2-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-98">
  <m id="m139-d1t2054-9">
   <w.rf>
    <LM>w#w-d1t2054-9</LM>
   </w.rf>
   <form>Vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2054-7">
   <w.rf>
    <LM>w#w-d1t2054-7</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m139-d1t2054-10">
   <w.rf>
    <LM>w#w-d1t2054-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t2054-11">
   <w.rf>
    <LM>w#w-d1t2054-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t2054-13">
   <w.rf>
    <LM>w#w-d1t2054-13</LM>
   </w.rf>
   <form>studium</form>
   <lemma>studium</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m139-d1t2054-14">
   <w.rf>
    <LM>w#w-d1t2054-14</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t2054-15">
   <w.rf>
    <LM>w#w-d1t2054-15</LM>
   </w.rf>
   <form>knihovnické</form>
   <lemma>knihovnický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m139-d1t2054-16">
   <w.rf>
    <LM>w#w-d1t2054-16</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m139-d-id111307-punct">
   <w.rf>
    <LM>w#w-d-id111307-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2059-1">
   <w.rf>
    <LM>w#w-d1t2059-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2059-3">
   <w.rf>
    <LM>w#w-d1t2059-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2059-4">
   <w.rf>
    <LM>w#w-d1t2059-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m139-d1t2059-2">
   <w.rf>
    <LM>w#w-d1t2059-2</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t2061-1">
   <w.rf>
    <LM>w#w-d1t2061-1</LM>
   </w.rf>
   <form>seznámila</form>
   <lemma>seznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m139-98-101">
   <w.rf>
    <LM>w#w-98-101</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-98-102">
   <w.rf>
    <LM>w#w-98-102</LM>
   </w.rf>
   <form>dalšími</form>
   <lemma>další</lemma>
   <tag>AAFP7----1A----</tag>
  </m>
  <m id="m139-98-103">
   <w.rf>
    <LM>w#w-98-103</LM>
   </w.rf>
   <form>knížkami</form>
   <lemma>knížka</lemma>
   <tag>NNFP7-----A----</tag>
  </m>
  <m id="m139-98-1128">
   <w.rf>
    <LM>w#w-98-1128</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1129">
  <m id="m139-d1t2065-1">
   <w.rf>
    <LM>w#w-d1t2065-1</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m139-d1t2065-2">
   <w.rf>
    <LM>w#w-d1t2065-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m139-d1t2065-3">
   <w.rf>
    <LM>w#w-d1t2065-3</LM>
   </w.rf>
   <form>výbornou</form>
   <lemma>výborný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m139-d1t2065-4">
   <w.rf>
    <LM>w#w-d1t2065-4</LM>
   </w.rf>
   <form>profesorku</form>
   <lemma>profesorka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d1t2065-5">
   <w.rf>
    <LM>w#w-d1t2065-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t2065-6">
   <w.rf>
    <LM>w#w-d1t2065-6</LM>
   </w.rf>
   <form>světovou</form>
   <lemma>světový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m139-d1t2065-7">
   <w.rf>
    <LM>w#w-d1t2065-7</LM>
   </w.rf>
   <form>literaturu</form>
   <lemma>literatura</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m139-d-id111558-punct">
   <w.rf>
    <LM>w#w-d-id111558-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2067-1">
   <w.rf>
    <LM>w#w-d1t2067-1</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2067-3">
   <w.rf>
    <LM>w#w-d1t2067-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m139-d1t2067-4">
   <w.rf>
    <LM>w#w-d1t2067-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m139-d1t2067-2">
   <w.rf>
    <LM>w#w-d1t2067-2</LM>
   </w.rf>
   <form>ráda</form>
   <lemma>rád-1</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m139-d1t2067-5">
   <w.rf>
    <LM>w#w-d1t2067-5</LM>
   </w.rf>
   <form>vzpomínám</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d-m-d1e2032-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2032-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e2068-x2">
  <m id="m139-d1t2071-1">
   <w.rf>
    <LM>w#w-d1t2071-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t2071-2">
   <w.rf>
    <LM>w#w-d1t2071-2</LM>
   </w.rf>
   <form>dodělání</form>
   <lemma>dodělání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m139-d1t2071-3">
   <w.rf>
    <LM>w#w-d1t2071-3</LM>
   </w.rf>
   <form>maturity</form>
   <lemma>maturita</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t2071-4">
   <w.rf>
    <LM>w#w-d1t2071-4</LM>
   </w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m139-d-id111769-punct">
   <w.rf>
    <LM>w#w-d-id111769-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-d1e2072-x2">
  <m id="m139-d1t2079-3">
   <w.rf>
    <LM>w#w-d1t2079-3</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m139-d-id111894-punct">
   <w.rf>
    <LM>w#w-d-id111894-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2079-5">
   <w.rf>
    <LM>w#w-d1t2079-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2081-1">
   <w.rf>
    <LM>w#w-d1t2081-1</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1t2081-2">
   <w.rf>
    <LM>w#w-d1t2081-2</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m139-d1e2072-x2-1133">
   <w.rf>
    <LM>w#w-d1e2072-x2-1133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-1134">
  <m id="m139-d1t2083-1">
   <w.rf>
    <LM>w#w-d1t2083-1</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m139-d1t2083-2">
   <w.rf>
    <LM>w#w-d1t2083-2</LM>
   </w.rf>
   <form>maturita</form>
   <lemma>maturita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m139-d1t2083-3">
   <w.rf>
    <LM>w#w-d1t2083-3</LM>
   </w.rf>
   <form>dopadla</form>
   <lemma>dopadnout</lemma>
   <tag>VpQW----R-AAP-1</tag>
  </m>
  <m id="m139-d1t2083-4">
   <w.rf>
    <LM>w#w-d1t2083-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m139-d1t2083-5">
   <w.rf>
    <LM>w#w-d1t2083-5</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>vyznamenáním</form>
   <lemma>vyznamenání_^(*3at)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m139-d-id112045-punct">
   <w.rf>
    <LM>w#w-d-id112045-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2083-7">
   <w.rf>
    <LM>w#w-d1t2083-7</LM>
   </w.rf>
   <form>líp</form>
   <lemma>lépe</lemma>
   <tag>Dg-------2A---1</tag>
  </m>
  <m id="m139-d1t2083-8">
   <w.rf>
    <LM>w#w-d1t2083-8</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m139-d1t2083-9">
   <w.rf>
    <LM>w#w-d1t2083-9</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m139-d1t2083-10">
   <w.rf>
    <LM>w#w-d1t2083-10</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m139-d1e2072-x2-130">
   <w.rf>
    <LM>w#w-d1e2072-x2-130</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-128">
  <m id="m139-d1t2086-2">
   <w.rf>
    <LM>w#w-d1t2086-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m139-d1t2086-3">
   <w.rf>
    <LM>w#w-d1t2086-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t2086-4">
   <w.rf>
    <LM>w#w-d1t2086-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m139-d1t2086-5">
   <w.rf>
    <LM>w#w-d1t2086-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m139-d1t2086-6">
   <w.rf>
    <LM>w#w-d1t2086-6</LM>
   </w.rf>
   <form>1969</form>
   <lemma>1969</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m139-d-id112242-punct">
   <w.rf>
    <LM>w#w-d-id112242-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2088-2">
   <w.rf>
    <LM>w#w-d1t2088-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t2088-3">
   <w.rf>
    <LM>w#w-d1t2088-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m139-d1t2088-5">
   <w.rf>
    <LM>w#w-d1t2088-5</LM>
   </w.rf>
   <form>těžký</form>
   <lemma>těžký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m139-d1t2088-6">
   <w.rf>
    <LM>w#w-d1t2088-6</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m139-128-133">
   <w.rf>
    <LM>w#w-128-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m139-127">
  <m id="m139-d1t2090-2">
   <w.rf>
    <LM>w#w-d1t2090-2</LM>
   </w.rf>
   <form>Předsedu</form>
   <lemma>předseda</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m139-d1t2090-3">
   <w.rf>
    <LM>w#w-d1t2090-3</LM>
   </w.rf>
   <form>maturitní</form>
   <lemma>maturitní</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m139-d1t2092-1">
   <w.rf>
    <LM>w#w-d1t2092-1</LM>
   </w.rf>
   <form>komise</form>
   <lemma>komise</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m139-d1t2094-1">
   <w.rf>
    <LM>w#w-d1t2094-1</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m139-d1t2099-1">
   <w.rf>
    <LM>w#w-d1t2099-1</LM>
   </w.rf>
   <form>dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m139-d1t2099-3">
   <w.rf>
    <LM>w#w-d1t2099-3</LM>
   </w.rf>
   <form>Jan</form>
   <lemma>Jan_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-d1t2099-4">
   <w.rf>
    <LM>w#w-d1t2099-4</LM>
   </w.rf>
   <form>Šnobr</form>
   <lemma>Šnobr_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-127-140">
   <w.rf>
    <LM>w#w-127-140</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m139-d1t2103-1">
   <w.rf>
    <LM>w#w-d1t2103-1</LM>
   </w.rf>
   <form>vynikající</form>
   <lemma>vynikající_^(*4t)</lemma>
   <tag>AGMS1-----A----</tag>
  </m>
  <m id="m139-d1t2101-1">
   <w.rf>
    <LM>w#w-d1t2101-1</LM>
   </w.rf>
   <form>básník</form>
   <lemma>básník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m139-127-141">
   <w.rf>
    <LM>w#w-127-141</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
