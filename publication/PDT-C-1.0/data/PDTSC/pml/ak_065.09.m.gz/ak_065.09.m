<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_065.09.w.gz" />
  </references>
 </head>
 <s id="m065-d1e2597-x2">
  <m id="m065-d1t2602-1">
   <w.rf>
    <LM>w#w-d1t2602-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1e2597-x2-530">
   <w.rf>
    <LM>w#w-d1e2597-x2-530</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2602-3">
   <w.rf>
    <LM>w#w-d1t2602-3</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2602-8">
   <w.rf>
    <LM>w#w-d1t2602-8</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2602-4">
   <w.rf>
    <LM>w#w-d1t2602-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2602-5">
   <w.rf>
    <LM>w#w-d1t2602-5</LM>
   </w.rf>
   <form>něčem</form>
   <lemma>něco</lemma>
   <tag>PK--6----------</tag>
  </m>
  <m id="m065-d1t2602-6">
   <w.rf>
    <LM>w#w-d1t2602-6</LM>
   </w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m065-d-m-d1e2597-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2597-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2603-x2">
  <m id="m065-d1t2606-3">
   <w.rf>
    <LM>w#w-d1t2606-3</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m065-d1t2606-2">
   <w.rf>
    <LM>w#w-d1t2606-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2606-4">
   <w.rf>
    <LM>w#w-d1t2606-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2606-5">
   <w.rf>
    <LM>w#w-d1t2606-5</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m065-d1t2606-6">
   <w.rf>
    <LM>w#w-d1t2606-6</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m065-d1t2606-7">
   <w.rf>
    <LM>w#w-d1t2606-7</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d1e2603-x2-533">
   <w.rf>
    <LM>w#w-d1e2603-x2-533</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-534">
  <m id="m065-d1t2608-1">
   <w.rf>
    <LM>w#w-d1t2608-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m065-d1t2608-2">
   <w.rf>
    <LM>w#w-d1t2608-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2608-3">
   <w.rf>
    <LM>w#w-d1t2608-3</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2608-4">
   <w.rf>
    <LM>w#w-d1t2608-4</LM>
   </w.rf>
   <form>zač</form>
   <lemma>co-1</lemma>
   <tag>PQ--4--------z-</tag>
  </m>
  <m id="m065-d-id157320-punct">
   <w.rf>
    <LM>w#w-d-id157320-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2610-x2">
  <m id="m065-d1t2613-3">
   <w.rf>
    <LM>w#w-d1t2613-3</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2613-4">
   <w.rf>
    <LM>w#w-d1t2613-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1e2610-x2-541">
   <w.rf>
    <LM>w#w-d1e2610-x2-541</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2615-1">
   <w.rf>
    <LM>w#w-d1t2615-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2615-2">
   <w.rf>
    <LM>w#w-d1t2615-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2615-6">
   <w.rf>
    <LM>w#w-d1t2615-6</LM>
   </w.rf>
   <form>mluvil</form>
   <lemma>mluvit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2615-7">
   <w.rf>
    <LM>w#w-d1t2615-7</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2615-8">
   <w.rf>
    <LM>w#w-d1t2615-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m065-d1t2615-9">
   <w.rf>
    <LM>w#w-d1t2615-9</LM>
   </w.rf>
   <form>chalupě</form>
   <lemma>chalupa</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1e2610-x2-549">
   <w.rf>
    <LM>w#w-d1e2610-x2-549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1e2610-x2-547">
   <w.rf>
    <LM>w#w-d1e2610-x2-547</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1e2610-x2-548">
   <w.rf>
    <LM>w#w-d1e2610-x2-548</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m065-d-id157530-punct">
   <w.rf>
    <LM>w#w-d-id157530-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2615-11">
   <w.rf>
    <LM>w#w-d1t2615-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2615-12">
   <w.rf>
    <LM>w#w-d1t2615-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2615-13">
   <w.rf>
    <LM>w#w-d1t2615-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2615-14">
   <w.rf>
    <LM>w#w-d1t2615-14</LM>
   </w.rf>
   <form>rád</form>
   <lemma>rád-1</lemma>
   <tag>ACYS------A----</tag>
  </m>
  <m id="m065-d1t2615-15">
   <w.rf>
    <LM>w#w-d1t2615-15</LM>
   </w.rf>
   <form>jezdil</form>
   <lemma>jezdit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1e2610-x2-1367">
   <w.rf>
    <LM>w#w-d1e2610-x2-1367</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-1368">
  <m id="m065-d1t2617-1">
   <w.rf>
    <LM>w#w-d1t2617-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2619-1">
   <w.rf>
    <LM>w#w-d1t2619-1</LM>
   </w.rf>
   <form>pozemku</form>
   <lemma>pozemek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m065-d1t2619-4">
   <w.rf>
    <LM>w#w-d1t2619-4</LM>
   </w.rf>
   <form>kamaráda</form>
   <lemma>kamarád</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m065-d-id157771-punct">
   <w.rf>
    <LM>w#w-d-id157771-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2619-6">
   <w.rf>
    <LM>w#w-d1t2619-6</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m065-d1t2619-7">
   <w.rf>
    <LM>w#w-d1t2619-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2619-11">
   <w.rf>
    <LM>w#w-d1t2619-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2619-12">
   <w.rf>
    <LM>w#w-d1t2619-12</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m065-d1t2619-13">
   <w.rf>
    <LM>w#w-d1t2619-13</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1t2619-9">
   <w.rf>
    <LM>w#w-d1t2619-9</LM>
   </w.rf>
   <form>bydlel</form>
   <lemma>bydlet</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2619-10">
   <w.rf>
    <LM>w#w-d1t2619-10</LM>
   </w.rf>
   <form>nastálo</form>
   <lemma>nastálo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1e2610-x2-542">
   <w.rf>
    <LM>w#w-d1e2610-x2-542</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2621-1">
   <w.rf>
    <LM>w#w-d1t2621-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2621-2">
   <w.rf>
    <LM>w#w-d1t2621-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m065-d1t2621-4">
   <w.rf>
    <LM>w#w-d1t2621-4</LM>
   </w.rf>
   <form>svépomocí</form>
   <lemma>svépomoc</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m065-d1t2621-3">
   <w.rf>
    <LM>w#w-d1t2621-3</LM>
   </w.rf>
   <form>postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2626-1">
   <w.rf>
    <LM>w#w-d1t2626-1</LM>
   </w.rf>
   <form>takovýhle</form>
   <lemma>takovýhle</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m065-d1e2610-x2-74">
   <w.rf>
    <LM>w#w-d1e2610-x2-74</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2626-2">
   <w.rf>
    <LM>w#w-d1t2626-2</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m065-d1t2626-3">
   <w.rf>
    <LM>w#w-d1t2626-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2626-4">
   <w.rf>
    <LM>w#w-d1t2626-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m065-d1e2610-x2-75">
   <w.rf>
    <LM>w#w-d1e2610-x2-75</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2626-5">
   <w.rf>
    <LM>w#w-d1t2626-5</LM>
   </w.rf>
   <form>chudší</form>
   <lemma>chudý-1</lemma>
   <tag>AAIS4----2A----</tag>
  </m>
  <m id="m065-d1t2626-10">
   <w.rf>
    <LM>w#w-d1t2626-10</LM>
   </w.rf>
   <form>tenisový</form>
   <lemma>tenisový</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m065-d1t2626-6">
   <w.rf>
    <LM>w#w-d1t2626-6</LM>
   </w.rf>
   <form>kurt</form>
   <lemma>kurt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-d1e2610-x2-543">
   <w.rf>
    <LM>w#w-d1e2610-x2-543</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-545">
  <m id="m065-d1t2630-1">
   <w.rf>
    <LM>w#w-d1t2630-1</LM>
   </w.rf>
   <form>Začínalo</form>
   <lemma>začínat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-545-550">
   <w.rf>
    <LM>w#w-545-550</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2630-2">
   <w.rf>
    <LM>w#w-d1t2630-2</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m065-d-id158155-punct">
   <w.rf>
    <LM>w#w-d-id158155-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2630-4">
   <w.rf>
    <LM>w#w-d1t2630-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2630-5">
   <w.rf>
    <LM>w#w-d1t2630-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-545-552">
   <w.rf>
    <LM>w#w-545-552</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2630-7">
   <w.rf>
    <LM>w#w-d1t2630-7</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2630-8">
   <w.rf>
    <LM>w#w-d1t2630-8</LM>
   </w.rf>
   <form>akorát</form>
   <lemma>akorát-1_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2630-9">
   <w.rf>
    <LM>w#w-d1t2630-9</LM>
   </w.rf>
   <form>písek</form>
   <lemma>písek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-545-554">
   <w.rf>
    <LM>w#w-545-554</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-555">
  <m id="m065-d1t2632-2">
   <w.rf>
    <LM>w#w-d1t2632-2</LM>
   </w.rf>
   <form>Potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2632-5">
   <w.rf>
    <LM>w#w-d1t2632-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2632-6">
   <w.rf>
    <LM>w#w-d1t2632-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2632-7">
   <w.rf>
    <LM>w#w-d1t2632-7</LM>
   </w.rf>
   <form>přišel</form>
   <lemma>přijít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m065-d1t2632-8">
   <w.rf>
    <LM>w#w-d1t2632-8</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m065-555-572">
   <w.rf>
    <LM>w#w-555-572</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2610-x3">
  <m id="m065-d1t2632-14">
   <w.rf>
    <LM>w#w-d1t2632-14</LM>
   </w.rf>
   <form>Dělal</form>
   <lemma>dělat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2632-13">
   <w.rf>
    <LM>w#w-d1t2632-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2632-15">
   <w.rf>
    <LM>w#w-d1t2632-15</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m065-d1t2632-20">
   <w.rf>
    <LM>w#w-d1t2632-20</LM>
   </w.rf>
   <form>svépomocném</form>
   <lemma>svépomocný</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m065-d1t2632-17">
   <w.rf>
    <LM>w#w-d1t2632-17</LM>
   </w.rf>
   <form>bytovém</form>
   <lemma>bytový</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m065-d1t2632-18">
   <w.rf>
    <LM>w#w-d1t2632-18</LM>
   </w.rf>
   <form>družstvu</form>
   <lemma>družstvo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m065-d-id158523-punct">
   <w.rf>
    <LM>w#w-d-id158523-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2632-22">
   <w.rf>
    <LM>w#w-d1t2632-22</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2634-1">
   <w.rf>
    <LM>w#w-d1t2634-1</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2634-2">
   <w.rf>
    <LM>w#w-d1t2634-2</LM>
   </w.rf>
   <form>mě</form>
   <lemma>já</lemma>
   <tag>PH-S4--1-------</tag>
  </m>
  <m id="m065-d1t2634-3">
   <w.rf>
    <LM>w#w-d1t2634-3</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m065-d1t2634-4">
   <w.rf>
    <LM>w#w-d1t2634-4</LM>
   </w.rf>
   <form>problém</form>
   <lemma>problém</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m065-d1t2637-1">
   <w.rf>
    <LM>w#w-d1t2637-1</LM>
   </w.rf>
   <form>některé</form>
   <lemma>některý</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m065-d1t2637-2">
   <w.rf>
    <LM>w#w-d1t2637-2</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m065-d1t2637-4">
   <w.rf>
    <LM>w#w-d1t2637-4</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2637-5">
   <w.rf>
    <LM>w#w-d1t2637-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m065-d1t2637-6">
   <w.rf>
    <LM>w#w-d1t2637-6</LM>
   </w.rf>
   <form>družstvo</form>
   <lemma>družstvo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m065-d1t2637-3">
   <w.rf>
    <LM>w#w-d1t2637-3</LM>
   </w.rf>
   <form>zajistit</form>
   <lemma>zajistit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m065-d1e2610-x3-583">
   <w.rf>
    <LM>w#w-d1e2610-x3-583</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-584">
  <m id="m065-d1t2643-1">
   <w.rf>
    <LM>w#w-d1t2643-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2643-2">
   <w.rf>
    <LM>w#w-d1t2643-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2643-3">
   <w.rf>
    <LM>w#w-d1t2643-3</LM>
   </w.rf>
   <form>spoustu</form>
   <lemma>spousta</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d1t2643-4">
   <w.rf>
    <LM>w#w-d1t2643-4</LM>
   </w.rf>
   <form>známých</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m065-d1t2645-1">
   <w.rf>
    <LM>w#w-d1t2645-1</LM>
   </w.rf>
   <form>dodavatelů</form>
   <lemma>dodavatel</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m065-584-587">
   <w.rf>
    <LM>w#w-584-587</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-584-588">
   <w.rf>
    <LM>w#w-584-588</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-584-585">
   <w.rf>
    <LM>w#w-584-585</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-586">
  <m id="m065-d1t2650-4">
   <w.rf>
    <LM>w#w-d1t2650-4</LM>
   </w.rf>
   <form>Dokonce</form>
   <lemma>dokonce</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2650-2">
   <w.rf>
    <LM>w#w-d1t2650-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2650-3">
   <w.rf>
    <LM>w#w-d1t2650-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2650-5">
   <w.rf>
    <LM>w#w-d1t2650-5</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2650-6">
   <w.rf>
    <LM>w#w-d1t2650-6</LM>
   </w.rf>
   <form>udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2650-8">
   <w.rf>
    <LM>w#w-d1t2650-8</LM>
   </w.rf>
   <form>antuku</form>
   <lemma>antuka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-586-589">
   <w.rf>
    <LM>w#w-586-589</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2654-3">
   <w.rf>
    <LM>w#w-d1t2654-3</LM>
   </w.rf>
   <form>oplocení</form>
   <lemma>oplocení_^(*4tit)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m065-586-590">
   <w.rf>
    <LM>w#w-586-590</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-591">
  <m id="m065-d1t2660-2">
   <w.rf>
    <LM>w#w-d1t2660-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2660-3">
   <w.rf>
    <LM>w#w-d1t2660-3</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m065-d1t2660-4">
   <w.rf>
    <LM>w#w-d1t2660-4</LM>
   </w.rf>
   <form>protějšku</form>
   <lemma>protějšek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m065-591-608">
   <w.rf>
    <LM>w#w-591-608</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-591-609">
   <w.rf>
    <LM>w#w-591-609</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m065-d1t2660-6">
   <w.rf>
    <LM>w#w-d1t2660-6</LM>
   </w.rf>
   <form>partnerka</form>
   <lemma>partnerka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-591-610">
   <w.rf>
    <LM>w#w-591-610</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2665-2">
   <w.rf>
    <LM>w#w-d1t2665-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2665-3">
   <w.rf>
    <LM>w#w-d1t2665-3</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d-id159366-punct">
   <w.rf>
    <LM>w#w-d-id159366-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2665-5">
   <w.rf>
    <LM>w#w-d1t2665-5</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m065-d1t2665-6">
   <w.rf>
    <LM>w#w-d1t2665-6</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1t2665-7">
   <w.rf>
    <LM>w#w-d1t2665-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2665-8">
   <w.rf>
    <LM>w#w-d1t2665-8</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m065-d1t2665-9">
   <w.rf>
    <LM>w#w-d1t2665-9</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2665-10">
   <w.rf>
    <LM>w#w-d1t2665-10</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m065-591-626">
   <w.rf>
    <LM>w#w-591-626</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2610-x4">
  <m id="m065-d1t2669-1">
   <w.rf>
    <LM>w#w-d1t2669-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1t2669-2">
   <w.rf>
    <LM>w#w-d1t2669-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2669-3">
   <w.rf>
    <LM>w#w-d1t2669-3</LM>
   </w.rf>
   <form>lékárnice</form>
   <lemma>lékárnice_^(*3ík)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d1e2610-x4-627">
   <w.rf>
    <LM>w#w-d1e2610-x4-627</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-628">
  <m id="m065-d1t2671-1">
   <w.rf>
    <LM>w#w-d1t2671-1</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2671-2">
   <w.rf>
    <LM>w#w-d1t2671-2</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m065-d1t2669-6">
   <w.rf>
    <LM>w#w-d1t2669-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2669-11">
   <w.rf>
    <LM>w#w-d1t2669-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2669-14">
   <w.rf>
    <LM>w#w-d1t2669-14</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2669-15">
   <w.rf>
    <LM>w#w-d1t2669-15</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-628-629">
   <w.rf>
    <LM>w#w-628-629</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2673-1">
   <w.rf>
    <LM>w#w-d1t2673-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2673-2">
   <w.rf>
    <LM>w#w-d1t2673-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2673-3">
   <w.rf>
    <LM>w#w-d1t2673-3</LM>
   </w.rf>
   <form>letěli</form>
   <lemma>letět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2673-7">
   <w.rf>
    <LM>w#w-d1t2673-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2673-10">
   <w.rf>
    <LM>w#w-d1t2673-10</LM>
   </w.rf>
   <form>Kypr</form>
   <lemma>Kypr_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-628-630">
   <w.rf>
    <LM>w#w-628-630</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-631">
  <m id="m065-d1t2680-7">
   <w.rf>
    <LM>w#w-d1t2680-7</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2680-10">
   <w.rf>
    <LM>w#w-d1t2680-10</LM>
   </w.rf>
   <form>Kypru</form>
   <lemma>Kypr_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m065-d1t2682-1">
   <w.rf>
    <LM>w#w-d1t2682-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2682-2">
   <w.rf>
    <LM>w#w-d1t2682-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-631-632">
   <w.rf>
    <LM>w#w-631-632</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2682-3">
   <w.rf>
    <LM>w#w-d1t2682-3</LM>
   </w.rf>
   <form>pětihvězdičkový</form>
   <lemma>pětihvězdičkový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m065-d1t2682-7">
   <w.rf>
    <LM>w#w-d1t2682-7</LM>
   </w.rf>
   <form>hotel</form>
   <lemma>hotel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m065-631-633">
   <w.rf>
    <LM>w#w-631-633</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-634">
  <m id="m065-d1t2684-2">
   <w.rf>
    <LM>w#w-d1t2684-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2684-1">
   <w.rf>
    <LM>w#w-d1t2684-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2684-3">
   <w.rf>
    <LM>w#w-d1t2684-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2684-4">
   <w.rf>
    <LM>w#w-d1t2684-4</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m065-d1t2684-5">
   <w.rf>
    <LM>w#w-d1t2684-5</LM>
   </w.rf>
   <form>1976</form>
   <lemma>1976</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m065-634-1413">
   <w.rf>
    <LM>w#w-634-1413</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2689-1">
   <w.rf>
    <LM>w#w-d1t2689-1</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m065-d1t2689-2">
   <w.rf>
    <LM>w#w-d1t2689-2</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m065-d1t2689-3">
   <w.rf>
    <LM>w#w-d1t2689-3</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-636-661">
   <w.rf>
    <LM>w#w-636-661</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2689-4">
   <w.rf>
    <LM>w#w-d1t2689-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2689-5">
   <w.rf>
    <LM>w#w-d1t2689-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-636-662">
   <w.rf>
    <LM>w#w-636-662</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-636-663">
   <w.rf>
    <LM>w#w-636-663</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS4--3-------</tag>
  </m>
  <m id="m065-d1t2689-7">
   <w.rf>
    <LM>w#w-d1t2689-7</LM>
   </w.rf>
   <form>Řekové</form>
   <lemma>Řek_;E</lemma>
   <tag>NNMP1-----A---1</tag>
  </m>
  <m id="m065-d1t2689-17">
   <w.rf>
    <LM>w#w-d1t2689-17</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m065-d1t2689-19">
   <w.rf>
    <LM>w#w-d1t2689-19</LM>
   </w.rf>
   <form>Turky</form>
   <lemma>Turek_;E_;Y</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m065-d1t2689-9">
   <w.rf>
    <LM>w#w-d1t2689-9</LM>
   </w.rf>
   <form>poprali</form>
   <lemma>poprat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-636-691">
   <w.rf>
    <LM>w#w-636-691</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-636-84">
   <w.rf>
    <LM>w#w-636-84</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-3_^(když:_poté/od_té_doby,_co)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2693-2">
   <w.rf>
    <LM>w#w-d1t2693-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2693-3">
   <w.rf>
    <LM>w#w-d1t2693-3</LM>
   </w.rf>
   <form>rozdělil</form>
   <lemma>rozdělit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m065-665-689">
   <w.rf>
    <LM>w#w-665-689</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-690">
  <m id="m065-690-700">
   <w.rf>
    <LM>w#w-690-700</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-690-701">
   <w.rf>
    <LM>w#w-690-701</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2702-12">
   <w.rf>
    <LM>w#w-d1t2702-12</LM>
   </w.rf>
   <form>zájezd</form>
   <lemma>zájezd</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m065-d1t2702-13">
   <w.rf>
    <LM>w#w-d1t2702-13</LM>
   </w.rf>
   <form>od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2702-15">
   <w.rf>
    <LM>w#w-d1t2702-15</LM>
   </w.rf>
   <form>Čedoku</form>
   <lemma>Čedok_;m</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m065-690-703">
   <w.rf>
    <LM>w#w-690-703</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-704">
  <m id="m065-d1t2702-23">
   <w.rf>
    <LM>w#w-d1t2702-23</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2702-20">
   <w.rf>
    <LM>w#w-d1t2702-20</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2702-21">
   <w.rf>
    <LM>w#w-d1t2702-21</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2702-22">
   <w.rf>
    <LM>w#w-d1t2702-22</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2702-25">
   <w.rf>
    <LM>w#w-d1t2702-25</LM>
   </w.rf>
   <form>katalog</form>
   <lemma>katalog</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-704-705">
   <w.rf>
    <LM>w#w-704-705</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2702-26">
   <w.rf>
    <LM>w#w-d1t2702-26</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2706-1">
   <w.rf>
    <LM>w#w-d1t2706-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2706-2">
   <w.rf>
    <LM>w#w-d1t2706-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d-id161282-punct">
   <w.rf>
    <LM>w#w-d-id161282-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2706-14">
   <w.rf>
    <LM>w#w-d1t2706-14</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2706-15">
   <w.rf>
    <LM>w#w-d1t2706-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2706-16">
   <w.rf>
    <LM>w#w-d1t2706-16</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2706-21">
   <w.rf>
    <LM>w#w-d1t2706-21</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2706-23">
   <w.rf>
    <LM>w#w-d1t2706-23</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m065-d1t2706-19">
   <w.rf>
    <LM>w#w-d1t2706-19</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m065-d1t2706-20">
   <w.rf>
    <LM>w#w-d1t2706-20</LM>
   </w.rf>
   <form>dispozici</form>
   <lemma>dispozice</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m065-d1t2706-17">
   <w.rf>
    <LM>w#w-d1t2706-17</LM>
   </w.rf>
   <form>tenisové</form>
   <lemma>tenisový</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m065-d1t2706-18">
   <w.rf>
    <LM>w#w-d1t2706-18</LM>
   </w.rf>
   <form>kurty</form>
   <lemma>kurt</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m065-704-1440">
   <w.rf>
    <LM>w#w-704-1440</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-1441">
  <m id="m065-d1t2706-27">
   <w.rf>
    <LM>w#w-d1t2706-27</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2708-1">
   <w.rf>
    <LM>w#w-d1t2708-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2708-2">
   <w.rf>
    <LM>w#w-d1t2708-2</LM>
   </w.rf>
   <form>vezl</form>
   <lemma>vézt_^(něco/někoho_autem,_vlakem,...)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2708-3">
   <w.rf>
    <LM>w#w-d1t2708-3</LM>
   </w.rf>
   <form>raketu</form>
   <lemma>raketa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d-m-d1e2610-x6-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2610-x6-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2711-x2">
  <m id="m065-d1t2718-2">
   <w.rf>
    <LM>w#w-d1t2718-2</LM>
   </w.rf>
   <form>Viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2718-3">
   <w.rf>
    <LM>w#w-d1t2718-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1e2711-x2-729">
   <w.rf>
    <LM>w#w-d1e2711-x2-729</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1e2711-x2-730">
   <w.rf>
    <LM>w#w-d1e2711-x2-730</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2718-4">
   <w.rf>
    <LM>w#w-d1t2718-4</LM>
   </w.rf>
   <form>paní</form>
   <lemma>paní</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d1t2718-5">
   <w.rf>
    <LM>w#w-d1t2718-5</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2718-6">
   <w.rf>
    <LM>w#w-d1t2718-6</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2718-7">
   <w.rf>
    <LM>w#w-d1t2718-7</LM>
   </w.rf>
   <form>raketu</form>
   <lemma>raketa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d1e2711-x2-731">
   <w.rf>
    <LM>w#w-d1e2711-x2-731</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-732">
  <m id="m065-d1t2718-10">
   <w.rf>
    <LM>w#w-d1t2718-10</LM>
   </w.rf>
   <form>Tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m065-d1t2718-12">
   <w.rf>
    <LM>w#w-d1t2718-12</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m065-732-733">
   <w.rf>
    <LM>w#w-732-733</LM>
   </w.rf>
   <form>tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-732-734">
   <w.rf>
    <LM>w#w-732-734</LM>
   </w.rf>
   <form>seznámení</form>
   <lemma>seznámení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m065-732-735">
   <w.rf>
    <LM>w#w-732-735</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2720-2">
   <w.rf>
    <LM>w#w-d1t2720-2</LM>
   </w.rf>
   <form>přátelství</form>
   <lemma>přátelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m065-732-736">
   <w.rf>
    <LM>w#w-732-736</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-737">
  <m id="m065-d1t2722-4">
   <w.rf>
    <LM>w#w-d1t2722-4</LM>
   </w.rf>
   <form>Říkali</form>
   <lemma>říkat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2722-2">
   <w.rf>
    <LM>w#w-d1t2722-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2722-3">
   <w.rf>
    <LM>w#w-d1t2722-3</LM>
   </w.rf>
   <form>jim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3-------</tag>
  </m>
  <m id="m065-d1t2722-11">
   <w.rf>
    <LM>w#w-d1t2722-11</LM>
   </w.rf>
   <form>Mariolázeňští</form>
   <lemma>Mariolázeňský_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m065-d-m-d1e2711-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2711-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2734-x2">
  <m id="m065-d1t2737-2">
   <w.rf>
    <LM>w#w-d1t2737-2</LM>
   </w.rf>
   <form>Její</form>
   <lemma>jeho</lemma>
   <tag>P9ZS1FS3-------</tag>
  </m>
  <m id="m065-d1t2737-3">
   <w.rf>
    <LM>w#w-d1t2737-3</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m065-d1e2734-x2-754">
   <w.rf>
    <LM>w#w-d1e2734-x2-754</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2739-3">
   <w.rf>
    <LM>w#w-d1t2739-3</LM>
   </w.rf>
   <form>Jarda</form>
   <lemma>Jarda_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m065-d1e2734-x2-755">
   <w.rf>
    <LM>w#w-d1e2734-x2-755</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2739-1">
   <w.rf>
    <LM>w#w-d1t2739-1</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2739-6">
   <w.rf>
    <LM>w#w-d1t2739-6</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2739-7">
   <w.rf>
    <LM>w#w-d1t2739-7</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m065-d1t2739-8">
   <w.rf>
    <LM>w#w-d1t2739-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m065-d1t2739-9">
   <w.rf>
    <LM>w#w-d1t2739-9</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m065-d1t2739-10">
   <w.rf>
    <LM>w#w-d1t2739-10</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2739-11">
   <w.rf>
    <LM>w#w-d1t2739-11</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m065-d1e2734-x2-756">
   <w.rf>
    <LM>w#w-d1e2734-x2-756</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-757">
  <m id="m065-d1t2739-14">
   <w.rf>
    <LM>w#w-d1t2739-14</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m065-d1t2739-15">
   <w.rf>
    <LM>w#w-d1t2739-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2739-17">
   <w.rf>
    <LM>w#w-d1t2739-17</LM>
   </w.rf>
   <form>nehrál</form>
   <lemma>hrát</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m065-757-762">
   <w.rf>
    <LM>w#w-757-762</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-764">
  <m id="m065-d1t2743-1">
   <w.rf>
    <LM>w#w-d1t2743-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2741-1">
   <w.rf>
    <LM>w#w-d1t2741-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2743-2">
   <w.rf>
    <LM>w#w-d1t2743-2</LM>
   </w.rf>
   <form>bývalý</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m065-d1t2743-3">
   <w.rf>
    <LM>w#w-d1t2743-3</LM>
   </w.rf>
   <form>golfista</form>
   <lemma>golfista</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m065-764-765">
   <w.rf>
    <LM>w#w-764-765</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-767">
  <m id="m065-d1t2748-1">
   <w.rf>
    <LM>w#w-d1t2748-1</LM>
   </w.rf>
   <form>Jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2748-2">
   <w.rf>
    <LM>w#w-d1t2748-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m065-d1t2748-3">
   <w.rf>
    <LM>w#w-d1t2748-3</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m065-d1t2750-1">
   <w.rf>
    <LM>w#w-d1t2750-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2750-2">
   <w.rf>
    <LM>w#w-d1t2750-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2750-3">
   <w.rf>
    <LM>w#w-d1t2750-3</LM>
   </w.rf>
   <form>sobotu</form>
   <lemma>sobota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d1t2750-4">
   <w.rf>
    <LM>w#w-d1t2750-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2750-7">
   <w.rf>
    <LM>w#w-d1t2750-7</LM>
   </w.rf>
   <form>aspoň</form>
   <lemma>aspoň-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2750-5">
   <w.rf>
    <LM>w#w-d1t2750-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2750-6">
   <w.rf>
    <LM>w#w-d1t2750-6</LM>
   </w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-767-768">
   <w.rf>
    <LM>w#w-767-768</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-769">
  <m id="m065-d1t2754-3">
   <w.rf>
    <LM>w#w-d1t2754-3</LM>
   </w.rf>
   <form>Vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2754-4">
   <w.rf>
    <LM>w#w-d1t2754-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2754-5">
   <w.rf>
    <LM>w#w-d1t2754-5</LM>
   </w.rf>
   <form>skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m065-769-773">
   <w.rf>
    <LM>w#w-769-773</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d-id162978-punct">
   <w.rf>
    <LM>w#w-d-id162978-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2754-7">
   <w.rf>
    <LM>w#w-d1t2754-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-769-775">
   <w.rf>
    <LM>w#w-769-775</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m065-769-776">
   <w.rf>
    <LM>w#w-769-776</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2761-1">
   <w.rf>
    <LM>w#w-d1t2761-1</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m065-d1t2761-3">
   <w.rf>
    <LM>w#w-d1t2761-3</LM>
   </w.rf>
   <form>druhá</form>
   <lemma>druhý`2</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m065-d1t2761-2">
   <w.rf>
    <LM>w#w-d1t2761-2</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d1t2765-2">
   <w.rf>
    <LM>w#w-d1t2765-2</LM>
   </w.rf>
   <form>poseděli</form>
   <lemma>posedět</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2765-3">
   <w.rf>
    <LM>w#w-d1t2765-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2765-4">
   <w.rf>
    <LM>w#w-d1t2765-4</LM>
   </w.rf>
   <form>sklenky</form>
   <lemma>sklenka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m065-d1t2765-6">
   <w.rf>
    <LM>w#w-d1t2765-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2765-7">
   <w.rf>
    <LM>w#w-d1t2765-7</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m065-d1t2765-8">
   <w.rf>
    <LM>w#w-d1t2765-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2765-9">
   <w.rf>
    <LM>w#w-d1t2765-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m065-d1t2765-10">
   <w.rf>
    <LM>w#w-d1t2765-10</LM>
   </w.rf>
   <form>šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2767-1">
   <w.rf>
    <LM>w#w-d1t2767-1</LM>
   </w.rf>
   <form>zapinkat</form>
   <lemma>zapinkat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m065-d1t2767-2">
   <w.rf>
    <LM>w#w-d1t2767-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2767-3">
   <w.rf>
    <LM>w#w-d1t2767-3</LM>
   </w.rf>
   <form>kurt</form>
   <lemma>kurt</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-769-774">
   <w.rf>
    <LM>w#w-769-774</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2734-x3">
  <m id="m065-d1t2769-10">
   <w.rf>
    <LM>w#w-d1t2769-10</LM>
   </w.rf>
   <form>Hrála</form>
   <lemma>hrát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1e2734-x3-782">
   <w.rf>
    <LM>w#w-d1e2734-x3-782</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m065-d1t2769-13">
   <w.rf>
    <LM>w#w-d1t2769-13</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2769-14">
   <w.rf>
    <LM>w#w-d1t2769-14</LM>
   </w.rf>
   <form>závodně</form>
   <lemma>závodně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m065-d1e2734-x3-783">
   <w.rf>
    <LM>w#w-d1e2734-x3-783</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-784">
  <m id="m065-d1t2771-6">
   <w.rf>
    <LM>w#w-d1t2771-6</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m065-784-785">
   <w.rf>
    <LM>w#w-784-785</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2771-7">
   <w.rf>
    <LM>w#w-d1t2771-7</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2771-8">
   <w.rf>
    <LM>w#w-d1t2771-8</LM>
   </w.rf>
   <form>amatér</form>
   <lemma>amatér</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m065-784-18">
   <w.rf>
    <LM>w#w-784-18</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-35">
  <m id="m065-d1t2774-1">
   <w.rf>
    <LM>w#w-d1t2774-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1t2771-15">
   <w.rf>
    <LM>w#w-d1t2771-15</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2774-5">
   <w.rf>
    <LM>w#w-d1t2774-5</LM>
   </w.rf>
   <form>starší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAFS1----2A----</tag>
  </m>
  <m id="m065-d1t2774-6">
   <w.rf>
    <LM>w#w-d1t2774-6</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2774-7">
   <w.rf>
    <LM>w#w-d1t2774-7</LM>
   </w.rf>
   <form>já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m065-787-789">
   <w.rf>
    <LM>w#w-787-789</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-792">
  <m id="m065-d1t2778-3">
   <w.rf>
    <LM>w#w-d1t2778-3</LM>
   </w.rf>
   <form>Dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m065-d1t2778-4">
   <w.rf>
    <LM>w#w-d1t2778-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2778-2">
   <w.rf>
    <LM>w#w-d1t2778-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2778-5">
   <w.rf>
    <LM>w#w-d1t2778-5</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m065-d-id163944-punct">
   <w.rf>
    <LM>w#w-d-id163944-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2778-7">
   <w.rf>
    <LM>w#w-d1t2778-7</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2778-8">
   <w.rf>
    <LM>w#w-d1t2778-8</LM>
   </w.rf>
   <form>vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m065-d1t2778-9">
   <w.rf>
    <LM>w#w-d1t2778-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m065-d1t2778-10">
   <w.rf>
    <LM>w#w-d1t2778-10</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m065-d-id164001-punct">
   <w.rf>
    <LM>w#w-d-id164001-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2778-12">
   <w.rf>
    <LM>w#w-d1t2778-12</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2778-13">
   <w.rf>
    <LM>w#w-d1t2778-13</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m065-d1t2778-14">
   <w.rf>
    <LM>w#w-d1t2778-14</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1t2778-15">
   <w.rf>
    <LM>w#w-d1t2778-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2778-16">
   <w.rf>
    <LM>w#w-d1t2778-16</LM>
   </w.rf>
   <form>ruce</form>
   <lemma>ruka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-792-793">
   <w.rf>
    <LM>w#w-792-793</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2778-17">
   <w.rf>
    <LM>w#w-d1t2778-17</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2778-18">
   <w.rf>
    <LM>w#w-d1t2778-18</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2778-19">
   <w.rf>
    <LM>w#w-d1t2778-19</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2778-23">
   <w.rf>
    <LM>w#w-d1t2778-23</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2778-24">
   <w.rf>
    <LM>w#w-d1t2778-24</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2778-20">
   <w.rf>
    <LM>w#w-d1t2778-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2778-21">
   <w.rf>
    <LM>w#w-d1t2778-21</LM>
   </w.rf>
   <form>stejné</form>
   <lemma>stejný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m065-d1t2778-22">
   <w.rf>
    <LM>w#w-d1t2778-22</LM>
   </w.rf>
   <form>úrovni</form>
   <lemma>úroveň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d-m-d1e2734-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2734-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2781-x2">
  <m id="m065-d1t2788-1">
   <w.rf>
    <LM>w#w-d1t2788-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2788-2">
   <w.rf>
    <LM>w#w-d1t2788-2</LM>
   </w.rf>
   <form>přátelství</form>
   <lemma>přátelství</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m065-d1e2781-x2-1527">
   <w.rf>
    <LM>w#w-d1e2781-x2-1527</LM>
   </w.rf>
   <form>začalo</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m065-d1t2788-5">
   <w.rf>
    <LM>w#w-d1t2788-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2788-7">
   <w.rf>
    <LM>w#w-d1t2788-7</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1t2788-11">
   <w.rf>
    <LM>w#w-d1t2788-11</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2788-14">
   <w.rf>
    <LM>w#w-d1t2788-14</LM>
   </w.rf>
   <form>Kypru</form>
   <lemma>Kypr_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m065-d-m-d1e2781-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2781-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2793-x2">
  <m id="m065-d1t2796-1">
   <w.rf>
    <LM>w#w-d1t2796-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2796-2">
   <w.rf>
    <LM>w#w-d1t2796-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m065-d1t2796-4">
   <w.rf>
    <LM>w#w-d1t2796-4</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2796-5">
   <w.rf>
    <LM>w#w-d1t2796-5</LM>
   </w.rf>
   <form>společně</form>
   <lemma>společně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m065-d1t2798-2">
   <w.rf>
    <LM>w#w-d1t2798-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2796-6">
   <w.rf>
    <LM>w#w-d1t2796-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2796-7">
   <w.rf>
    <LM>w#w-d1t2796-7</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1t2798-7">
   <w.rf>
    <LM>w#w-d1t2798-7</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m065-d1t2798-9">
   <w.rf>
    <LM>w#w-d1t2798-9</LM>
   </w.rf>
   <form>Španělsku</form>
   <lemma>Španělsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m065-d1t2800-1">
   <w.rf>
    <LM>w#w-d1t2800-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2802-1">
   <w.rf>
    <LM>w#w-d1t2802-1</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2802-3">
   <w.rf>
    <LM>w#w-d1t2802-3</LM>
   </w.rf>
   <form>Černého</form>
   <lemma>černý_;o</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m065-d1t2802-4">
   <w.rf>
    <LM>w#w-d1t2802-4</LM>
   </w.rf>
   <form>moře</form>
   <lemma>moře</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m065-d1t2811-1">
   <w.rf>
    <LM>w#w-d1t2811-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2811-3">
   <w.rf>
    <LM>w#w-d1t2811-3</LM>
   </w.rf>
   <form>Pitsundě</form>
   <lemma>Pitsunda_;G_,s_^(^DD**Picunda)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1e2793-x2-48">
   <w.rf>
    <LM>w#w-d1e2793-x2-48</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-49">
  <m id="m065-d1t2811-7">
   <w.rf>
    <LM>w#w-d1t2811-7</LM>
   </w.rf>
   <form>Nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m065-d-id165004-punct">
   <w.rf>
    <LM>w#w-d-id165004-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2811-9">
   <w.rf>
    <LM>w#w-d1t2811-9</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2811-10">
   <w.rf>
    <LM>w#w-d1t2811-10</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m065-d1t2811-11">
   <w.rf>
    <LM>w#w-d1t2811-11</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2811-12">
   <w.rf>
    <LM>w#w-d1t2811-12</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m065-d1t2811-13">
   <w.rf>
    <LM>w#w-d1t2811-13</LM>
   </w.rf>
   <form>říká</form>
   <lemma>říkat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-49-50">
   <w.rf>
    <LM>w#w-49-50</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-51">
  <m id="m065-51-52">
   <w.rf>
    <LM>w#w-51-52</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-51-53">
   <w.rf>
    <LM>w#w-51-53</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2813-7">
   <w.rf>
    <LM>w#w-d1t2813-7</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2813-8">
   <w.rf>
    <LM>w#w-d1t2813-8</LM>
   </w.rf>
   <form>dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m065-d1t2813-9">
   <w.rf>
    <LM>w#w-d1t2813-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2813-10">
   <w.rf>
    <LM>w#w-d1t2813-10</LM>
   </w.rf>
   <form>jihu</form>
   <lemma>jih</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m065-51-54">
   <w.rf>
    <LM>w#w-51-54</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2813-13">
   <w.rf>
    <LM>w#w-d1t2813-13</LM>
   </w.rf>
   <form>Suchumi</form>
   <lemma>Suchumi_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m065-51-55">
   <w.rf>
    <LM>w#w-51-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-56">
  <m id="m065-d1t2817-2">
   <w.rf>
    <LM>w#w-d1t2817-2</LM>
   </w.rf>
   <form>Udělali</form>
   <lemma>udělat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2817-1">
   <w.rf>
    <LM>w#w-d1t2817-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2817-3">
   <w.rf>
    <LM>w#w-d1t2817-3</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m065-d1t2817-4">
   <w.rf>
    <LM>w#w-d1t2817-4</LM>
   </w.rf>
   <form>rekreační</form>
   <lemma>rekreační</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m065-d1t2817-5">
   <w.rf>
    <LM>w#w-d1t2817-5</LM>
   </w.rf>
   <form>středisko</form>
   <lemma>středisko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m065-56-58">
   <w.rf>
    <LM>w#w-56-58</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-65">
  <m id="m065-d1t2817-7">
   <w.rf>
    <LM>w#w-d1t2817-7</LM>
   </w.rf>
   <form>Postavili</form>
   <lemma>postavit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2817-8">
   <w.rf>
    <LM>w#w-d1t2817-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2817-9">
   <w.rf>
    <LM>w#w-d1t2817-9</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2817-10">
   <w.rf>
    <LM>w#w-d1t2817-10</LM>
   </w.rf>
   <form>sedm</form>
   <lemma>sedm`7</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m065-d1t2817-12">
   <w.rf>
    <LM>w#w-d1t2817-12</LM>
   </w.rf>
   <form>čtrnáctiposchoďových</form>
   <lemma>čtrnáctiposchoďový</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m065-d1t2817-13">
   <w.rf>
    <LM>w#w-d1t2817-13</LM>
   </w.rf>
   <form>hotelů</form>
   <lemma>hotel</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m065-d1e2793-x3-72">
   <w.rf>
    <LM>w#w-d1e2793-x3-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-74">
  <m id="m065-d1t2826-1">
   <w.rf>
    <LM>w#w-d1t2826-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2826-2">
   <w.rf>
    <LM>w#w-d1t2826-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2826-3">
   <w.rf>
    <LM>w#w-d1t2826-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2826-4">
   <w.rf>
    <LM>w#w-d1t2826-4</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m065-d1t2826-5">
   <w.rf>
    <LM>w#w-d1t2826-5</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m065-74-79">
   <w.rf>
    <LM>w#w-74-79</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-80">
  <m id="m065-d1t2826-11">
   <w.rf>
    <LM>w#w-d1t2826-11</LM>
   </w.rf>
   <form>Ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m065-d1t2826-12">
   <w.rf>
    <LM>w#w-d1t2826-12</LM>
   </w.rf>
   <form>chalupa</form>
   <lemma>chalupa</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d1t2828-2">
   <w.rf>
    <LM>w#w-d1t2828-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2828-3">
   <w.rf>
    <LM>w#w-d1t2828-3</LM>
   </w.rf>
   <form>jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m065-d1t2828-5">
   <w.rf>
    <LM>w#w-d1t2828-5</LM>
   </w.rf>
   <form>Nová</form>
   <lemma>nový</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m065-d1t2828-6">
   <w.rf>
    <LM>w#w-d1t2828-6</LM>
   </w.rf>
   <form>ves</form>
   <lemma>ves</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-d-m-d1e2793-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2793-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2831-x2">
  <m id="m065-d1t2836-5">
   <w.rf>
    <LM>w#w-d1t2836-5</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2836-4">
   <w.rf>
    <LM>w#w-d1t2836-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2836-6">
   <w.rf>
    <LM>w#w-d1t2836-6</LM>
   </w.rf>
   <form>kousek</form>
   <lemma>kousek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-d1t2836-7">
   <w.rf>
    <LM>w#w-d1t2836-7</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m065-d1t2836-9">
   <w.rf>
    <LM>w#w-d1t2836-9</LM>
   </w.rf>
   <form>Plzní</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m065-d1t2836-12">
   <w.rf>
    <LM>w#w-d1t2836-12</LM>
   </w.rf>
   <form>směrem</form>
   <lemma>směr</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m065-d1t2836-15">
   <w.rf>
    <LM>w#w-d1t2836-15</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2836-17">
   <w.rf>
    <LM>w#w-d1t2836-17</LM>
   </w.rf>
   <form>Dobřany</form>
   <lemma>Dobřany_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m065-d1e2831-x2-115">
   <w.rf>
    <LM>w#w-d1e2831-x2-115</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-116">
  <m id="m065-d1t2840-1">
   <w.rf>
    <LM>w#w-d1t2840-1</LM>
   </w.rf>
   <form>Kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d-id166308-punct">
   <w.rf>
    <LM>w#w-d-id166308-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2842-1">
   <w.rf>
    <LM>w#w-d1t2842-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2842-2">
   <w.rf>
    <LM>w#w-d1t2842-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2842-5">
   <w.rf>
    <LM>w#w-d1t2842-5</LM>
   </w.rf>
   <form>fungovalo</form>
   <lemma>fungovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2842-6">
   <w.rf>
    <LM>w#w-d1t2842-6</LM>
   </w.rf>
   <form>letiště</form>
   <lemma>letiště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m065-116-133">
   <w.rf>
    <LM>w#w-116-133</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2842-16">
   <w.rf>
    <LM>w#w-d1t2842-16</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m065-d1t2842-8">
   <w.rf>
    <LM>w#w-d1t2842-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m065-d1t2842-11">
   <w.rf>
    <LM>w#w-d1t2842-11</LM>
   </w.rf>
   <form>Nové</form>
   <lemma>nový</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m065-d1t2842-12">
   <w.rf>
    <LM>w#w-d1t2842-12</LM>
   </w.rf>
   <form>vsi</form>
   <lemma>ves</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m065-d1t2842-14">
   <w.rf>
    <LM>w#w-d1t2842-14</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2842-15">
   <w.rf>
    <LM>w#w-d1t2842-15</LM>
   </w.rf>
   <form>hospody</form>
   <lemma>hospoda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m065-d1t2842-17">
   <w.rf>
    <LM>w#w-d1t2842-17</LM>
   </w.rf>
   <form>závora</form>
   <lemma>závora</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m065-116-134">
   <w.rf>
    <LM>w#w-116-134</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2845-3">
   <w.rf>
    <LM>w#w-d1t2845-3</LM>
   </w.rf>
   <form>končilo</form>
   <lemma>končit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2845-2">
   <w.rf>
    <LM>w#w-d1t2845-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2845-1">
   <w.rf>
    <LM>w#w-d1t2845-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-116-135">
   <w.rf>
    <LM>w#w-116-135</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-139">
  <m id="m065-d1t2845-5">
   <w.rf>
    <LM>w#w-d1t2845-5</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2845-6">
   <w.rf>
    <LM>w#w-d1t2845-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2845-8">
   <w.rf>
    <LM>w#w-d1t2845-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2845-9">
   <w.rf>
    <LM>w#w-d1t2845-9</LM>
   </w.rf>
   <form>vojenské</form>
   <lemma>vojenský</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m065-d1t2845-10">
   <w.rf>
    <LM>w#w-d1t2845-10</LM>
   </w.rf>
   <form>letiště</form>
   <lemma>letiště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m065-139-141">
   <w.rf>
    <LM>w#w-139-141</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2853-1">
   <w.rf>
    <LM>w#w-d1t2853-1</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2853-2">
   <w.rf>
    <LM>w#w-d1t2853-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2853-3">
   <w.rf>
    <LM>w#w-d1t2853-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m065-d1t2853-5">
   <w.rf>
    <LM>w#w-d1t2853-5</LM>
   </w.rf>
   <form>nesmělo</form>
   <lemma>smět</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m065-d1e2850-x2-142">
   <w.rf>
    <LM>w#w-d1e2850-x2-142</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-143">
  <m id="m065-d1t2855-3">
   <w.rf>
    <LM>w#w-d1t2855-3</LM>
   </w.rf>
   <form>Tryskáče</form>
   <lemma>tryskáč</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m065-d1t2859-2">
   <w.rf>
    <LM>w#w-d1t2859-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m065-d1t2859-4">
   <w.rf>
    <LM>w#w-d1t2859-4</LM>
   </w.rf>
   <form>přistávaly</form>
   <lemma>přistávat_^(*3t)</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2859-5">
   <w.rf>
    <LM>w#w-d1t2859-5</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2859-6">
   <w.rf>
    <LM>w#w-d1t2859-6</LM>
   </w.rf>
   <form>startovaly</form>
   <lemma>startovat</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m065-d1t2859-7">
   <w.rf>
    <LM>w#w-d1t2859-7</LM>
   </w.rf>
   <form>přesně</form>
   <lemma>přesně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m065-d1t2859-8">
   <w.rf>
    <LM>w#w-d1t2859-8</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2859-9">
   <w.rf>
    <LM>w#w-d1t2859-9</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-143-145">
   <w.rf>
    <LM>w#w-143-145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-146">
  <m id="m065-d1t2866-1">
   <w.rf>
    <LM>w#w-d1t2866-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2866-2">
   <w.rf>
    <LM>w#w-d1t2866-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m065-d1t2866-4">
   <w.rf>
    <LM>w#w-d1t2866-4</LM>
   </w.rf>
   <form>pěkný</form>
   <lemma>pěkný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m065-d1t2866-5">
   <w.rf>
    <LM>w#w-d1t2866-5</LM>
   </w.rf>
   <form>rámus</form>
   <lemma>rámus</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m065-146-150">
   <w.rf>
    <LM>w#w-146-150</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-151">
  <m id="m065-d1t2868-4">
   <w.rf>
    <LM>w#w-d1t2868-4</LM>
   </w.rf>
   <form>Nelítali</form>
   <lemma>lítat</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m065-d1t2868-1">
   <w.rf>
    <LM>w#w-d1t2868-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m065-d1t2868-5">
   <w.rf>
    <LM>w#w-d1t2868-5</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m065-d1t2868-6">
   <w.rf>
    <LM>w#w-d1t2868-6</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m065-151-152">
   <w.rf>
    <LM>w#w-151-152</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-153">
  <m id="m065-d1t2872-11">
   <w.rf>
    <LM>w#w-d1t2872-11</LM>
   </w.rf>
   <form>Ten</form>
   <lemma>ten</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m065-d1t2872-12">
   <w.rf>
    <LM>w#w-d1t2872-12</LM>
   </w.rf>
   <form>tenisový</form>
   <lemma>tenisový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m065-d1t2872-13">
   <w.rf>
    <LM>w#w-d1t2872-13</LM>
   </w.rf>
   <form>kurt</form>
   <lemma>kurt</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m065-d1t2872-3">
   <w.rf>
    <LM>w#w-d1t2872-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2872-5">
   <w.rf>
    <LM>w#w-d1t2872-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m065-d1t2872-6">
   <w.rf>
    <LM>w#w-d1t2872-6</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m065-d1t2872-7">
   <w.rf>
    <LM>w#w-d1t2872-7</LM>
   </w.rf>
   <form>prostředí</form>
   <lemma>prostředí</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m065-153-157">
   <w.rf>
    <LM>w#w-153-157</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-159">
  <m id="m065-d1t2874-1">
   <w.rf>
    <LM>w#w-d1t2874-1</LM>
   </w.rf>
   <form>Dneska</form>
   <lemma>dneska_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2874-2">
   <w.rf>
    <LM>w#w-d1t2874-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2874-4">
   <w.rf>
    <LM>w#w-d1t2874-4</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2874-5">
   <w.rf>
    <LM>w#w-d1t2874-5</LM>
   </w.rf>
   <form>vypadá</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2874-3">
   <w.rf>
    <LM>w#w-d1t2874-3</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2874-6">
   <w.rf>
    <LM>w#w-d1t2874-6</LM>
   </w.rf>
   <form>jinak</form>
   <lemma>jinak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1e2850-x3-172">
   <w.rf>
    <LM>w#w-d1e2850-x3-172</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-d1e2850-x3">
  <m id="m065-d1t2879-8">
   <w.rf>
    <LM>w#w-d1t2879-8</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m065-d1t2879-9">
   <w.rf>
    <LM>w#w-d1t2879-9</LM>
   </w.rf>
   <form>posledních</form>
   <lemma>poslední</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m065-d1t2879-10">
   <w.rf>
    <LM>w#w-d1t2879-10</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m065-d1t2879-11">
   <w.rf>
    <LM>w#w-d1t2879-11</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m065-d1t2881-1">
   <w.rf>
    <LM>w#w-d1t2881-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m065-d1t2879-6">
   <w.rf>
    <LM>w#w-d1t2879-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2879-4">
   <w.rf>
    <LM>w#w-d1t2879-4</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m065-d1t2879-5">
   <w.rf>
    <LM>w#w-d1t2879-5</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m065-d1t2881-2">
   <w.rf>
    <LM>w#w-d1t2881-2</LM>
   </w.rf>
   <form>vybudovali</form>
   <lemma>vybudovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m065-d1t2881-3">
   <w.rf>
    <LM>w#w-d1t2881-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d-id167985-punct">
   <w.rf>
    <LM>w#w-d-id167985-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m065-d1t2881-5">
   <w.rf>
    <LM>w#w-d1t2881-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m065-d1t2881-6">
   <w.rf>
    <LM>w#w-d1t2881-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2881-7">
   <w.rf>
    <LM>w#w-d1t2881-7</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2881-8">
   <w.rf>
    <LM>w#w-d1t2881-8</LM>
   </w.rf>
   <form>profesionální</form>
   <lemma>profesionální</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m065-d1t2881-9">
   <w.rf>
    <LM>w#w-d1t2881-9</LM>
   </w.rf>
   <form>úroveň</form>
   <lemma>úroveň</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m065-d1e2850-x3-184">
   <w.rf>
    <LM>w#w-d1e2850-x3-184</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-200">
  <m id="m065-d1t2883-11">
   <w.rf>
    <LM>w#w-d1t2883-11</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2883-14">
   <w.rf>
    <LM>w#w-d1t2883-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m065-d1t2883-10">
   <w.rf>
    <LM>w#w-d1t2883-10</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2883-13">
   <w.rf>
    <LM>w#w-d1t2883-13</LM>
   </w.rf>
   <form>obklopeno</form>
   <lemma>obklopit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m065-d1t2883-15">
   <w.rf>
    <LM>w#w-d1t2883-15</LM>
   </w.rf>
   <form>lesem</form>
   <lemma>les</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m065-200-201">
   <w.rf>
    <LM>w#w-200-201</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-202">
  <m id="m065-d1t2890-4">
   <w.rf>
    <LM>w#w-d1t2890-4</LM>
   </w.rf>
   <form>Dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m065-d1t2890-6">
   <w.rf>
    <LM>w#w-d1t2890-6</LM>
   </w.rf>
   <form>Plzeňáků</form>
   <lemma>Plzeňák_;E</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m065-d1t2890-8">
   <w.rf>
    <LM>w#w-d1t2890-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m065-d1t2890-9">
   <w.rf>
    <LM>w#w-d1t2890-9</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m065-202-236">
   <w.rf>
    <LM>w#w-202-236</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m065-241">
  <m id="m065-d1t2890-11">
   <w.rf>
    <LM>w#w-d1t2890-11</LM>
   </w.rf>
   <form>Mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m065-d1t2890-12">
   <w.rf>
    <LM>w#w-d1t2890-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m065-d1t2890-13">
   <w.rf>
    <LM>w#w-d1t2890-13</LM>
   </w.rf>
   <form>členské</form>
   <lemma>členský</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m065-d1t2890-14">
   <w.rf>
    <LM>w#w-d1t2890-14</LM>
   </w.rf>
   <form>karty</form>
   <lemma>karta</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m065-241-248">
   <w.rf>
    <LM>w#w-241-248</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
