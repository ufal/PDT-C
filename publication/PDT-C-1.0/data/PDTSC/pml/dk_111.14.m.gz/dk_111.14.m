<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="dk_111.14.w.gz" />
  </references>
 </head>
 <s id="m111-d1e2231-x2">
  <m id="m111-d1t2234-1">
   <w.rf>
    <LM>w#w-d1t2234-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m111-d1t2234-6">
   <w.rf>
    <LM>w#w-d1t2234-6</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t2234-7">
   <w.rf>
    <LM>w#w-d1t2234-7</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m111-d1t2234-5">
   <w.rf>
    <LM>w#w-d1t2234-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m111-d1t2234-2">
   <w.rf>
    <LM>w#w-d1t2234-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m111-d1t2234-3">
   <w.rf>
    <LM>w#w-d1t2234-3</LM>
   </w.rf>
   <form>strašně</form>
   <lemma>strašně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m111-d1t2234-4">
   <w.rf>
    <LM>w#w-d1t2234-4</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m111-d1e2231-x2-1181">
   <w.rf>
    <LM>w#w-d1e2231-x2-1181</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-1182">
  <m id="m111-d1t2234-9">
   <w.rf>
    <LM>w#w-d1t2234-9</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m111-d1t2234-10">
   <w.rf>
    <LM>w#w-d1t2234-10</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m111-d1t2242-1">
   <w.rf>
    <LM>w#w-d1t2242-1</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m111-d1t2242-2">
   <w.rf>
    <LM>w#w-d1t2242-2</LM>
   </w.rf>
   <form>mládence</form>
   <lemma>mládenec</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m111-1182-1185">
   <w.rf>
    <LM>w#w-1182-1185</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e2237-x3">
  <m id="m111-d1t2244-1">
   <w.rf>
    <LM>w#w-d1t2244-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t2244-2">
   <w.rf>
    <LM>w#w-d1t2244-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d-m-d1e2237-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2237-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m111-d1e2245-x2">
  <m id="m111-d1t2248-1">
   <w.rf>
    <LM>w#w-d1t2248-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m111-d1t2248-2">
   <w.rf>
    <LM>w#w-d1t2248-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m111-d-m-d1e2245-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2245-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
