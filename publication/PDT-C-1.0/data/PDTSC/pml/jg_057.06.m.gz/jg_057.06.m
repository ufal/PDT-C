<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="jg_057.06.w.gz" />
  </references>
 </head>
 <s id="m057-d1e2093-x2">
  <m id="m057-d1t2100-1">
   <w.rf>
    <LM>w#w-d1t2100-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2100-2">
   <w.rf>
    <LM>w#w-d1t2100-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2100-3">
   <w.rf>
    <LM>w#w-d1t2100-3</LM>
   </w.rf>
   <form>synovi</form>
   <lemma>syn</lemma>
   <tag>NNMS3-----A----</tag>
  </m>
  <m id="m057-d1t2100-4">
   <w.rf>
    <LM>w#w-d1t2100-4</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m057-d1t2100-5">
   <w.rf>
    <LM>w#w-d1t2100-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m057-d-id117639-punct">
   <w.rf>
    <LM>w#w-d-id117639-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2109-1">
   <w.rf>
    <LM>w#w-d1t2109-1</LM>
   </w.rf>
   <form>stěhovali</form>
   <lemma>stěhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m057-d1t2109-2">
   <w.rf>
    <LM>w#w-d1t2109-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2109-3">
   <w.rf>
    <LM>w#w-d1t2109-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2109-4">
   <w.rf>
    <LM>w#w-d1t2109-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2109-6">
   <w.rf>
    <LM>w#w-d1t2109-6</LM>
   </w.rf>
   <form>Bory</form>
   <lemma>Bor-2_;G</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m057-d1t2109-8">
   <w.rf>
    <LM>w#w-d1t2109-8</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2109-9">
   <w.rf>
    <LM>w#w-d1t2109-9</LM>
   </w.rf>
   <form>věžáku</form>
   <lemma>věžák-2_^(dům)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m057-d1e2093-x2-353">
   <w.rf>
    <LM>w#w-d1e2093-x2-353</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2104-1">
   <w.rf>
    <LM>w#w-d1t2104-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2104-6">
   <w.rf>
    <LM>w#w-d1t2104-6</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2104-2">
   <w.rf>
    <LM>w#w-d1t2104-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2104-3">
   <w.rf>
    <LM>w#w-d1t2104-3</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m057-d1t2104-4">
   <w.rf>
    <LM>w#w-d1t2104-4</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-d1t2120-2">
   <w.rf>
    <LM>w#w-d1t2120-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2120-3">
   <w.rf>
    <LM>w#w-d1t2120-3</LM>
   </w.rf>
   <form>nové</form>
   <lemma>nový</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m057-d1t2120-4">
   <w.rf>
    <LM>w#w-d1t2120-4</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-d1t2120-5">
   <w.rf>
    <LM>w#w-d1t2120-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2120-7">
   <w.rf>
    <LM>w#w-d1t2120-7</LM>
   </w.rf>
   <form>Borech</form>
   <lemma>Bory-2_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2093-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2093-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2121-x2">
  <m id="m057-d1t2124-1">
   <w.rf>
    <LM>w#w-d1t2124-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m057-d1e2121-x2-355">
   <w.rf>
    <LM>w#w-d1e2121-x2-355</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-356">
  <m id="m057-d1t2126-1">
   <w.rf>
    <LM>w#w-d1t2126-1</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m057-d1t2126-2">
   <w.rf>
    <LM>w#w-d1t2126-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2126-3">
   <w.rf>
    <LM>w#w-d1t2126-3</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2126-4">
   <w.rf>
    <LM>w#w-d1t2126-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m057-d1t2126-5">
   <w.rf>
    <LM>w#w-d1t2126-5</LM>
   </w.rf>
   <form>švagrem</form>
   <lemma>švagr</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m057-d1t2126-6">
   <w.rf>
    <LM>w#w-d1t2126-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2126-7">
   <w.rf>
    <LM>w#w-d1t2126-7</LM>
   </w.rf>
   <form>návštěvu</form>
   <lemma>návštěva</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d-id118484-punct">
   <w.rf>
    <LM>w#w-d-id118484-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2127-x2">
  <m id="m057-d1t2132-2">
   <w.rf>
    <LM>w#w-d1t2132-2</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1e2127-x2-364">
   <w.rf>
    <LM>w#w-d1e2127-x2-364</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-362">
  <m id="m057-d1t2138-10">
   <w.rf>
    <LM>w#w-d1t2138-10</LM>
   </w.rf>
   <form>Manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1t2138-11">
   <w.rf>
    <LM>w#w-d1t2138-11</LM>
   </w.rf>
   <form>má</form>
   <lemma>mít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2138-12">
   <w.rf>
    <LM>w#w-d1t2138-12</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m057-d1t2138-13">
   <w.rf>
    <LM>w#w-d1t2138-13</LM>
   </w.rf>
   <form>bratry</form>
   <lemma>bratr</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m057-d-id118800-punct">
   <w.rf>
    <LM>w#w-d-id118800-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2141-1">
   <w.rf>
    <LM>w#w-d1t2141-1</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnYS1----------</tag>
  </m>
  <m id="m057-d1t2141-2">
   <w.rf>
    <LM>w#w-d1t2141-2</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2141-7">
   <w.rf>
    <LM>w#w-d1t2141-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2141-8">
   <w.rf>
    <LM>w#w-d1t2141-8</LM>
   </w.rf>
   <form>tomhle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m057-d1t2141-9">
   <w.rf>
    <LM>w#w-d1t2141-9</LM>
   </w.rf>
   <form>domku</form>
   <lemma>domek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m057-d1t2143-1">
   <w.rf>
    <LM>w#w-d1t2143-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2145-1">
   <w.rf>
    <LM>w#w-d1t2145-1</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrMS1----------</tag>
  </m>
  <m id="m057-d1t2145-2">
   <w.rf>
    <LM>w#w-d1t2145-2</LM>
   </w.rf>
   <form>švagr</form>
   <lemma>švagr</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m057-d1t2149-1">
   <w.rf>
    <LM>w#w-d1t2149-1</LM>
   </w.rf>
   <form>bydlí</form>
   <lemma>bydlet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2149-2">
   <w.rf>
    <LM>w#w-d1t2149-2</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2149-3">
   <w.rf>
    <LM>w#w-d1t2149-3</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m057-d1t2149-4">
   <w.rf>
    <LM>w#w-d1t2149-4</LM>
   </w.rf>
   <form>sta</form>
   <lemma>sto-1`100</lemma>
   <tag>CzNP4----------</tag>
  </m>
  <m id="m057-d1t2149-5">
   <w.rf>
    <LM>w#w-d1t2149-5</LM>
   </w.rf>
   <form>metrů</form>
   <lemma>metr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m057-d1t2151-1">
   <w.rf>
    <LM>w#w-d1t2151-1</LM>
   </w.rf>
   <form>poblíž</form>
   <lemma>poblíž-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-362-367">
   <w.rf>
    <LM>w#w-362-367</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2154-1">
   <w.rf>
    <LM>w#w-d1t2154-1</LM>
   </w.rf>
   <form>mají</form>
   <lemma>mít</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2154-2">
   <w.rf>
    <LM>w#w-d1t2154-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2154-3">
   <w.rf>
    <LM>w#w-d1t2154-3</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2154-4">
   <w.rf>
    <LM>w#w-d1t2154-4</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m057-362-365">
   <w.rf>
    <LM>w#w-362-365</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-366">
  <m id="m057-d1t2156-2">
   <w.rf>
    <LM>w#w-d1t2156-2</LM>
   </w.rf>
   <form>Jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2156-3">
   <w.rf>
    <LM>w#w-d1t2156-3</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m057-d1t2156-4">
   <w.rf>
    <LM>w#w-d1t2156-4</LM>
   </w.rf>
   <form>pohromadě</form>
   <lemma>pohromadě</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d-m-d1e2127-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2127-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2157-x2">
  <m id="m057-d1t2164-1">
   <w.rf>
    <LM>w#w-d1t2164-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2164-2">
   <w.rf>
    <LM>w#w-d1t2164-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2164-3">
   <w.rf>
    <LM>w#w-d1t2164-3</LM>
   </w.rf>
   <form>zvědavá</form>
   <lemma>zvědavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m057-d1t2164-4">
   <w.rf>
    <LM>w#w-d1t2164-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2164-5">
   <w.rf>
    <LM>w#w-d1t2164-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m057-d1t2164-6">
   <w.rf>
    <LM>w#w-d1t2164-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d1e2157-x2-368">
   <w.rf>
    <LM>w#w-d1e2157-x2-368</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-369">
  <m id="m057-d1t2166-1">
   <w.rf>
    <LM>w#w-d1t2166-1</LM>
   </w.rf>
   <form>Podíváme</form>
   <lemma>podívat</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m057-d1t2166-2">
   <w.rf>
    <LM>w#w-d1t2166-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2166-3">
   <w.rf>
    <LM>w#w-d1t2166-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2166-4">
   <w.rf>
    <LM>w#w-d1t2166-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------7</tag>
  </m>
  <m id="m057-369-371">
   <w.rf>
    <LM>w#w-369-371</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2167-x2">
  <m id="m057-d1t2170-2">
   <w.rf>
    <LM>w#w-d1t2170-2</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m057-d-m-d1e2167-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2167-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2171-x2">
  <m id="m057-d1t2174-1">
   <w.rf>
    <LM>w#w-d1t2174-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m057-d1t2174-2">
   <w.rf>
    <LM>w#w-d1t2174-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2174-3">
   <w.rf>
    <LM>w#w-d1t2174-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2174-4">
   <w.rf>
    <LM>w#w-d1t2174-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d-id119737-punct">
   <w.rf>
    <LM>w#w-d-id119737-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2175-x2">
  <m id="m057-d1t2180-6">
   <w.rf>
    <LM>w#w-d1t2180-6</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2180-7">
   <w.rf>
    <LM>w#w-d1t2180-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2180-9">
   <w.rf>
    <LM>w#w-d1t2180-9</LM>
   </w.rf>
   <form>náš</form>
   <lemma>náš</lemma>
   <tag>PSYS1-P1-------</tag>
  </m>
  <m id="m057-d1t2180-10">
   <w.rf>
    <LM>w#w-d1t2180-10</LM>
   </w.rf>
   <form>syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m057-d1e2175-x2-386">
   <w.rf>
    <LM>w#w-d1e2175-x2-386</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-387">
  <m id="m057-d1t2182-7">
   <w.rf>
    <LM>w#w-d1t2182-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2182-8">
   <w.rf>
    <LM>w#w-d1t2182-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2182-9">
   <w.rf>
    <LM>w#w-d1t2182-9</LM>
   </w.rf>
   <form>děláno</form>
   <lemma>dělat</lemma>
   <tag>VsNS----X-API--</tag>
  </m>
  <m id="m057-d1t2184-3">
   <w.rf>
    <LM>w#w-d1t2184-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2184-5">
   <w.rf>
    <LM>w#w-d1t2184-5</LM>
   </w.rf>
   <form>Špičáku</form>
   <lemma>Špičák-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m057-d-id120166-punct">
   <w.rf>
    <LM>w#w-d-id120166-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2189-1">
   <w.rf>
    <LM>w#w-d1t2189-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2195-1">
   <w.rf>
    <LM>w#w-d1t2195-1</LM>
   </w.rf>
   <form>máme</form>
   <lemma>mít</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2195-3">
   <w.rf>
    <LM>w#w-d1t2195-3</LM>
   </w.rf>
   <form>chalupu</form>
   <lemma>chalupa</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d1t2197-6">
   <w.rf>
    <LM>w#w-d1t2197-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2197-7">
   <w.rf>
    <LM>w#w-d1t2197-7</LM>
   </w.rf>
   <form>mém</form>
   <lemma>můj</lemma>
   <tag>PSZS6-S1-------</tag>
  </m>
  <m id="m057-d1t2197-8">
   <w.rf>
    <LM>w#w-d1t2197-8</LM>
   </w.rf>
   <form>otci</form>
   <lemma>otec</lemma>
   <tag>NNMS6-----A----</tag>
  </m>
  <m id="m057-387-388">
   <w.rf>
    <LM>w#w-387-388</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-389">
  <m id="m057-d1t2202-1">
   <w.rf>
    <LM>w#w-d1t2202-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2202-2">
   <w.rf>
    <LM>w#w-d1t2202-2</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m057-d1t2202-3">
   <w.rf>
    <LM>w#w-d1t2202-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m057-d1t2202-4">
   <w.rf>
    <LM>w#w-d1t2202-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m057-d1t2202-5">
   <w.rf>
    <LM>w#w-d1t2202-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2202-6">
   <w.rf>
    <LM>w#w-d1t2202-6</LM>
   </w.rf>
   <form>zajímavé</form>
   <lemma>zajímavý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m057-d1t2202-7">
   <w.rf>
    <LM>w#w-d1t2202-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d-id120486-punct">
   <w.rf>
    <LM>w#w-d-id120486-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2202-9">
   <w.rf>
    <LM>w#w-d1t2202-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2206-1">
   <w.rf>
    <LM>w#w-d1t2206-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m057-d1t2206-2">
   <w.rf>
    <LM>w#w-d1t2206-2</LM>
   </w.rf>
   <form>fotografována</form>
   <lemma>fotografovat</lemma>
   <tag>VsQW----X-API--</tag>
  </m>
  <m id="m057-d1t2212-1">
   <w.rf>
    <LM>w#w-d1t2212-1</LM>
   </w.rf>
   <form>bakelitovým</form>
   <lemma>bakelitový</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m057-d1t2212-2">
   <w.rf>
    <LM>w#w-d1t2212-2</LM>
   </w.rf>
   <form>fotoaparátem</form>
   <lemma>fotoaparát</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m057-d1t2212-4">
   <w.rf>
    <LM>w#w-d1t2212-4</LM>
   </w.rf>
   <form>Pionýr</form>
   <lemma>Pionýr_;m_^(motocykl;_organizace)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m057-d-id120693-punct">
   <w.rf>
    <LM>w#w-d-id120693-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2212-7">
   <w.rf>
    <LM>w#w-d1t2212-7</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m057-d1t2212-9">
   <w.rf>
    <LM>w#w-d1t2212-9</LM>
   </w.rf>
   <form>stál</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2212-8">
   <w.rf>
    <LM>w#w-d1t2212-8</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2212-10">
   <w.rf>
    <LM>w#w-d1t2212-10</LM>
   </w.rf>
   <form>45</form>
   <lemma>45</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m057-d1t2212-12">
   <w.rf>
    <LM>w#w-d1t2212-12</LM>
   </w.rf>
   <form>korun</form>
   <lemma>koruna</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m057-389-395">
   <w.rf>
    <LM>w#w-389-395</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2213-x2">
  <m id="m057-d1t2218-1">
   <w.rf>
    <LM>w#w-d1t2218-1</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2218-2">
   <w.rf>
    <LM>w#w-d1t2218-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2218-4">
   <w.rf>
    <LM>w#w-d1t2218-4</LM>
   </w.rf>
   <form>nejlacinější</form>
   <lemma>laciný</lemma>
   <tag>AAIS1----3A----</tag>
  </m>
  <m id="m057-d1t2218-5">
   <w.rf>
    <LM>w#w-d1t2218-5</LM>
   </w.rf>
   <form>dětský</form>
   <lemma>dětský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m057-d1t2218-6">
   <w.rf>
    <LM>w#w-d1t2218-6</LM>
   </w.rf>
   <form>fotoaparát</form>
   <lemma>fotoaparát</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2213-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2213-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2225-x2">
  <m id="m057-d1t2230-7">
   <w.rf>
    <LM>w#w-d1t2230-7</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2230-8">
   <w.rf>
    <LM>w#w-d1t2230-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m057-d1t2230-9">
   <w.rf>
    <LM>w#w-d1t2230-9</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m057-d1t2230-2">
   <w.rf>
    <LM>w#w-d1t2230-2</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2230-3">
   <w.rf>
    <LM>w#w-d1t2230-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2230-4">
   <w.rf>
    <LM>w#w-d1t2230-4</LM>
   </w.rf>
   <form>kvalitě</form>
   <lemma>kvalita</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d1t2230-6">
   <w.rf>
    <LM>w#w-d1t2230-6</LM>
   </w.rf>
   <form>fotky</form>
   <lemma>fotka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-d1e2225-x2-402">
   <w.rf>
    <LM>w#w-d1e2225-x2-402</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-403">
  <m id="m057-d1t2232-5">
   <w.rf>
    <LM>w#w-d1t2232-5</LM>
   </w.rf>
   <form>Nechali</form>
   <lemma>nechat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m057-d1t2232-2">
   <w.rf>
    <LM>w#w-d1t2232-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2232-3">
   <w.rf>
    <LM>w#w-d1t2232-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m057-d1t2232-4">
   <w.rf>
    <LM>w#w-d1t2232-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m057-d1t2230-11">
   <w.rf>
    <LM>w#w-d1t2230-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2232-7">
   <w.rf>
    <LM>w#w-d1t2232-7</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2232-8">
   <w.rf>
    <LM>w#w-d1t2232-8</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m057-d1t2232-9">
   <w.rf>
    <LM>w#w-d1t2232-9</LM>
   </w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m057-d-id121331-punct">
   <w.rf>
    <LM>w#w-d-id121331-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2232-11">
   <w.rf>
    <LM>w#w-d1t2232-11</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2234-1">
   <w.rf>
    <LM>w#w-d1t2234-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2234-2">
   <w.rf>
    <LM>w#w-d1t2234-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m057-d1t2234-3">
   <w.rf>
    <LM>w#w-d1t2234-3</LM>
   </w.rf>
   <form>podařilo</form>
   <lemma>podařit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2234-5">
   <w.rf>
    <LM>w#w-d1t2234-5</LM>
   </w.rf>
   <form>zachytit</form>
   <lemma>zachytit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m057-d1t2234-7">
   <w.rf>
    <LM>w#w-d1t2234-7</LM>
   </w.rf>
   <form>moment</form>
   <lemma>moment</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m057-d-id121467-punct">
   <w.rf>
    <LM>w#w-d-id121467-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2234-9">
   <w.rf>
    <LM>w#w-d1t2234-9</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m057-d1t2236-1">
   <w.rf>
    <LM>w#w-d1t2236-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2236-2">
   <w.rf>
    <LM>w#w-d1t2236-2</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m057-d1t2236-3">
   <w.rf>
    <LM>w#w-d1t2236-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2236-4">
   <w.rf>
    <LM>w#w-d1t2236-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m057-d1t2236-5">
   <w.rf>
    <LM>w#w-d1t2236-5</LM>
   </w.rf>
   <form>výrazu</form>
   <lemma>výraz</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m057-d1t2236-6">
   <w.rf>
    <LM>w#w-d1t2236-6</LM>
   </w.rf>
   <form>líbil</form>
   <lemma>líbit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2236-7">
   <w.rf>
    <LM>w#w-d1t2236-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2236-8">
   <w.rf>
    <LM>w#w-d1t2236-8</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m057-d1t2236-9">
   <w.rf>
    <LM>w#w-d1t2236-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2236-10">
   <w.rf>
    <LM>w#w-d1t2236-10</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2236-11">
   <w.rf>
    <LM>w#w-d1t2236-11</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2236-12">
   <w.rf>
    <LM>w#w-d1t2236-12</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m057-d1t2236-13">
   <w.rf>
    <LM>w#w-d1t2236-13</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d1t2236-14">
   <w.rf>
    <LM>w#w-d1t2236-14</LM>
   </w.rf>
   <form>typický</form>
   <lemma>typický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m057-d1e2225-x2-400">
   <w.rf>
    <LM>w#w-d1e2225-x2-400</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-401">
  <m id="m057-d1t2239-1">
   <w.rf>
    <LM>w#w-d1t2239-1</LM>
   </w.rf>
   <form>Chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2239-2">
   <w.rf>
    <LM>w#w-d1t2239-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2239-3">
   <w.rf>
    <LM>w#w-d1t2239-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m057-d1t2239-4">
   <w.rf>
    <LM>w#w-d1t2239-4</LM>
   </w.rf>
   <form>starých</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m057-d1t2239-5">
   <w.rf>
    <LM>w#w-d1t2239-5</LM>
   </w.rf>
   <form>teplákách</form>
   <lemma>tepláky</lemma>
   <tag>NNIP6-----A---1</tag>
  </m>
  <m id="m057-d-id121789-punct">
   <w.rf>
    <LM>w#w-d-id121789-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2239-7">
   <w.rf>
    <LM>w#w-d1t2239-7</LM>
   </w.rf>
   <form>vypadal</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2239-8">
   <w.rf>
    <LM>w#w-d1t2239-8</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2239-9">
   <w.rf>
    <LM>w#w-d1t2239-9</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m057-d1t2239-10">
   <w.rf>
    <LM>w#w-d1t2239-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2239-11">
   <w.rf>
    <LM>w#w-d1t2239-11</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m057-d1t2239-12">
   <w.rf>
    <LM>w#w-d1t2239-12</LM>
   </w.rf>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-401-404">
   <w.rf>
    <LM>w#w-401-404</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2241-1">
   <w.rf>
    <LM>w#w-d1t2241-1</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2241-2">
   <w.rf>
    <LM>w#w-d1t2241-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2241-3">
   <w.rf>
    <LM>w#w-d1t2241-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2241-4">
   <w.rf>
    <LM>w#w-d1t2241-4</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2241-5">
   <w.rf>
    <LM>w#w-d1t2241-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2241-6">
   <w.rf>
    <LM>w#w-d1t2241-6</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m057-d1t2243-1">
   <w.rf>
    <LM>w#w-d1t2243-1</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m057-d-m-d1e2225-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2225-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2245-x2">
  <m id="m057-d1t2248-1">
   <w.rf>
    <LM>w#w-d1t2248-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2248-4">
   <w.rf>
    <LM>w#w-d1t2248-4</LM>
   </w.rf>
   <form>Špičáku</form>
   <lemma>Špičák-2_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m057-d1t2248-6">
   <w.rf>
    <LM>w#w-d1t2248-6</LM>
   </w.rf>
   <form>máte</form>
   <lemma>mít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m057-d1t2248-8">
   <w.rf>
    <LM>w#w-d1t2248-8</LM>
   </w.rf>
   <form>domek</form>
   <lemma>domek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m057-d-id122167-punct">
   <w.rf>
    <LM>w#w-d-id122167-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2249-x2">
  <m id="m057-d1t2254-1">
   <w.rf>
    <LM>w#w-d1t2254-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1e2249-x2-426">
   <w.rf>
    <LM>w#w-d1e2249-x2-426</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-427">
  <m id="m057-d1t2254-4">
   <w.rf>
    <LM>w#w-d1t2254-4</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2254-5">
   <w.rf>
    <LM>w#w-d1t2254-5</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2254-6">
   <w.rf>
    <LM>w#w-d1t2254-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2254-7">
   <w.rf>
    <LM>w#w-d1t2254-7</LM>
   </w.rf>
   <form>záběru</form>
   <lemma>záběr</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m057-d1t2254-8">
   <w.rf>
    <LM>w#w-d1t2254-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2254-9">
   <w.rf>
    <LM>w#w-d1t2254-9</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m057-d1t2254-10">
   <w.rf>
    <LM>w#w-d1t2254-10</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-427-428">
   <w.rf>
    <LM>w#w-427-428</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-429">
  <m id="m057-d1t2258-8">
   <w.rf>
    <LM>w#w-d1t2258-8</LM>
   </w.rf>
   <form>Koupil</form>
   <lemma>koupit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-429-436">
   <w.rf>
    <LM>w#w-429-436</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m057-d1t2260-1">
   <w.rf>
    <LM>w#w-d1t2260-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m057-d1t2260-2">
   <w.rf>
    <LM>w#w-d1t2260-2</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m057-d1t2263-5">
   <w.rf>
    <LM>w#w-d1t2263-5</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2263-6">
   <w.rf>
    <LM>w#w-d1t2263-6</LM>
   </w.rf>
   <form>bouračku</form>
   <lemma>bouračka_^(*2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-429-440">
   <w.rf>
    <LM>w#w-429-440</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-441">
  <m id="m057-d1t2273-1">
   <w.rf>
    <LM>w#w-d1t2273-1</LM>
   </w.rf>
   <form>Mělo</form>
   <lemma>mít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2273-2">
   <w.rf>
    <LM>w#w-d1t2273-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2273-3">
   <w.rf>
    <LM>w#w-d1t2273-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2273-4">
   <w.rf>
    <LM>w#w-d1t2273-4</LM>
   </w.rf>
   <form>stodolu</form>
   <lemma>stodola</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-441-442">
   <w.rf>
    <LM>w#w-441-442</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2276-1">
   <w.rf>
    <LM>w#w-d1t2276-1</LM>
   </w.rf>
   <form>zbořil</form>
   <lemma>zbořit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2276-2">
   <w.rf>
    <LM>w#w-d1t2276-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m057-d1t2276-3">
   <w.rf>
    <LM>w#w-d1t2276-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2276-4">
   <w.rf>
    <LM>w#w-d1t2276-4</LM>
   </w.rf>
   <form>získal</form>
   <lemma>získat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2276-5">
   <w.rf>
    <LM>w#w-d1t2276-5</LM>
   </w.rf>
   <form>materiál</form>
   <lemma>materiál</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m057-441-443">
   <w.rf>
    <LM>w#w-441-443</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2286-1">
   <w.rf>
    <LM>w#w-d1t2286-1</LM>
   </w.rf>
   <form>dovopravil</form>
   <lemma>dovopravit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2286-3">
   <w.rf>
    <LM>w#w-d1t2286-3</LM>
   </w.rf>
   <form>chybějící</form>
   <lemma>chybějící_^(*4t)</lemma>
   <tag>AGIP4-----A----</tag>
  </m>
  <m id="m057-d1t2286-4">
   <w.rf>
    <LM>w#w-d1t2286-4</LM>
   </w.rf>
   <form>kusy</form>
   <lemma>kus</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m057-d1t2286-5">
   <w.rf>
    <LM>w#w-d1t2286-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2289-1">
   <w.rf>
    <LM>w#w-d1t2289-1</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2289-2">
   <w.rf>
    <LM>w#w-d1t2289-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m057-d1t2289-3">
   <w.rf>
    <LM>w#w-d1t2289-3</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-441-444">
   <w.rf>
    <LM>w#w-441-444</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-445">
  <m id="m057-d1t2289-5">
   <w.rf>
    <LM>w#w-d1t2289-5</LM>
   </w.rf>
   <form>Kdyby</form>
   <lemma>kdyby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2289-6">
   <w.rf>
    <LM>w#w-d1t2289-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m057-d1e2249-x3-453">
   <w.rf>
    <LM>w#w-d1e2249-x3-453</LM>
   </w.rf>
   <form>tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-445-454">
   <w.rf>
    <LM>w#w-445-454</LM>
   </w.rf>
   <form>nedal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m057-d1t2289-7">
   <w.rf>
    <LM>w#w-d1t2289-7</LM>
   </w.rf>
   <form>dohromady</form>
   <lemma>dohromady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d-id123254-punct">
   <w.rf>
    <LM>w#w-d-id123254-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2289-13">
   <w.rf>
    <LM>w#w-d1t2289-13</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2289-10">
   <w.rf>
    <LM>w#w-d1t2289-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2289-11">
   <w.rf>
    <LM>w#w-d1t2289-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2289-12">
   <w.rf>
    <LM>w#w-d1t2289-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2289-17">
   <w.rf>
    <LM>w#w-d1t2289-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2289-14">
   <w.rf>
    <LM>w#w-d1t2289-14</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2289-15">
   <w.rf>
    <LM>w#w-d1t2289-15</LM>
   </w.rf>
   <form>hromádka</form>
   <lemma>hromádka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1t2289-16">
   <w.rf>
    <LM>w#w-d1t2289-16</LM>
   </w.rf>
   <form>kamení</form>
   <lemma>kamení</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2249-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2249-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2290-x2">
  <m id="m057-d1t2293-1">
   <w.rf>
    <LM>w#w-d1t2293-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2293-2">
   <w.rf>
    <LM>w#w-d1t2293-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2293-3">
   <w.rf>
    <LM>w#w-d1t2293-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2293-4">
   <w.rf>
    <LM>w#w-d1t2293-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2293-5">
   <w.rf>
    <LM>w#w-d1t2293-5</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m057-d-id123525-punct">
   <w.rf>
    <LM>w#w-d-id123525-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2294-x2">
  <m id="m057-d1t2323-4">
   <w.rf>
    <LM>w#w-d1t2323-4</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2323-5">
   <w.rf>
    <LM>w#w-d1t2323-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2323-6">
   <w.rf>
    <LM>w#w-d1t2323-6</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2323-7">
   <w.rf>
    <LM>w#w-d1t2323-7</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2323-8">
   <w.rf>
    <LM>w#w-d1t2323-8</LM>
   </w.rf>
   <form>velké</form>
   <lemma>velký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m057-d1e2294-x2-468">
   <w.rf>
    <LM>w#w-d1e2294-x2-468</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2303-1">
   <w.rf>
    <LM>w#w-d1t2303-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2303-2">
   <w.rf>
    <LM>w#w-d1t2303-2</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2303-3">
   <w.rf>
    <LM>w#w-d1t2303-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2305-1">
   <w.rf>
    <LM>w#w-d1t2305-1</LM>
   </w.rf>
   <form>ubourala</form>
   <lemma>ubourat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m057-d1t2305-3">
   <w.rf>
    <LM>w#w-d1t2305-3</LM>
   </w.rf>
   <form>stodola</form>
   <lemma>stodola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1e2294-x2-464">
   <w.rf>
    <LM>w#w-d1e2294-x2-464</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-465">
  <m id="m057-d1t2316-1">
   <w.rf>
    <LM>w#w-d1t2316-1</LM>
   </w.rf>
   <form>Dole</form>
   <lemma>dole</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2312-1">
   <w.rf>
    <LM>w#w-d1t2312-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2316-2">
   <w.rf>
    <LM>w#w-d1t2316-2</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m057-d1t2316-3">
   <w.rf>
    <LM>w#w-d1t2316-3</LM>
   </w.rf>
   <form>velká</form>
   <lemma>velký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m057-d1t2316-4">
   <w.rf>
    <LM>w#w-d1t2316-4</LM>
   </w.rf>
   <form>místnost</form>
   <lemma>místnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d-id123939-punct">
   <w.rf>
    <LM>w#w-d-id123939-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2316-6">
   <w.rf>
    <LM>w#w-d1t2316-6</LM>
   </w.rf>
   <form>kuchyně</form>
   <lemma>kuchyň</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m057-d1t2316-7">
   <w.rf>
    <LM>w#w-d1t2316-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2316-8">
   <w.rf>
    <LM>w#w-d1t2316-8</LM>
   </w.rf>
   <form>ložnice</form>
   <lemma>ložnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-465-469">
   <w.rf>
    <LM>w#w-465-469</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-470">
  <m id="m057-d1t2316-11">
   <w.rf>
    <LM>w#w-d1t2316-11</LM>
   </w.rf>
   <form>Nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2316-12">
   <w.rf>
    <LM>w#w-d1t2316-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2316-13">
   <w.rf>
    <LM>w#w-d1t2316-13</LM>
   </w.rf>
   <form>hala</form>
   <lemma>hala</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-470-471">
   <w.rf>
    <LM>w#w-470-471</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2318-2">
   <w.rf>
    <LM>w#w-d1t2318-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2318-3">
   <w.rf>
    <LM>w#w-d1t2318-3</LM>
   </w.rf>
   <form>jedna</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS1----------</tag>
  </m>
  <m id="m057-d1t2318-4">
   <w.rf>
    <LM>w#w-d1t2318-4</LM>
   </w.rf>
   <form>ložnice</form>
   <lemma>ložnice</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1t2318-1">
   <w.rf>
    <LM>w#w-d1t2318-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2318-6">
   <w.rf>
    <LM>w#w-d1t2318-6</LM>
   </w.rf>
   <form>předsíň</form>
   <lemma>předsíň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-465-466">
   <w.rf>
    <LM>w#w-465-466</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-467">
  <m id="m057-d1t2318-11">
   <w.rf>
    <LM>w#w-d1t2318-11</LM>
   </w.rf>
   <form>Kolem</form>
   <lemma>kolem-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2318-7">
   <w.rf>
    <LM>w#w-d1t2318-7</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2318-10">
   <w.rf>
    <LM>w#w-d1t2318-10</LM>
   </w.rf>
   <form>kůlničky</form>
   <lemma>kůlnička</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m057-d-id124238-punct">
   <w.rf>
    <LM>w#w-d-id124238-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2321-1">
   <w.rf>
    <LM>w#w-d1t2321-1</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m057-d1t2321-2">
   <w.rf>
    <LM>w#w-d1t2321-2</LM>
   </w.rf>
   <form>jsou</form>
   <lemma>být</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2321-3">
   <w.rf>
    <LM>w#w-d1t2321-3</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2321-4">
   <w.rf>
    <LM>w#w-d1t2321-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2321-5">
   <w.rf>
    <LM>w#w-d1t2321-5</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m057-d1t2321-6">
   <w.rf>
    <LM>w#w-d1t2321-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2321-7">
   <w.rf>
    <LM>w#w-d1t2321-7</LM>
   </w.rf>
   <form>podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d-m-d1e2294-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2294-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2324-x2">
  <m id="m057-d1t2327-1">
   <w.rf>
    <LM>w#w-d1t2327-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2327-2">
   <w.rf>
    <LM>w#w-d1t2327-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2327-3">
   <w.rf>
    <LM>w#w-d1t2327-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2327-5">
   <w.rf>
    <LM>w#w-d1t2327-5</LM>
   </w.rf>
   <form>zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d-id124619-punct">
   <w.rf>
    <LM>w#w-d-id124619-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2328-x2">
  <m id="m057-d1t2335-2">
   <w.rf>
    <LM>w#w-d1t2335-2</LM>
   </w.rf>
   <form>Oplocená</form>
   <lemma>oplocený_^(*4tit)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m057-d1t2335-3">
   <w.rf>
    <LM>w#w-d1t2335-3</LM>
   </w.rf>
   <form>zahrada</form>
   <lemma>zahrada</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1t2335-4">
   <w.rf>
    <LM>w#w-d1t2335-4</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1e2328-x2-496">
   <w.rf>
    <LM>w#w-d1e2328-x2-496</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-497">
  <m id="m057-d1t2337-1">
   <w.rf>
    <LM>w#w-d1t2337-1</LM>
   </w.rf>
   <form>Nejsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-NAI--</tag>
  </m>
  <m id="m057-d1t2339-1">
   <w.rf>
    <LM>w#w-d1t2339-1</LM>
   </w.rf>
   <form>zastánci</form>
   <lemma>zastánce</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m057-d1t2339-2">
   <w.rf>
    <LM>w#w-d1t2339-2</LM>
   </w.rf>
   <form>oplocených</form>
   <lemma>oplocený_^(*4tit)</lemma>
   <tag>AAFP2----1A----</tag>
  </m>
  <m id="m057-d1t2339-3">
   <w.rf>
    <LM>w#w-d1t2339-3</LM>
   </w.rf>
   <form>zahrad</form>
   <lemma>zahrada</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m057-d-id124865-punct">
   <w.rf>
    <LM>w#w-d-id124865-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2339-5">
   <w.rf>
    <LM>w#w-d1t2339-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2344-1">
   <w.rf>
    <LM>w#w-d1t2344-1</LM>
   </w.rf>
   <form>parcela</form>
   <lemma>parcela</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d-id124922-punct">
   <w.rf>
    <LM>w#w-d-id124922-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2344-3">
   <w.rf>
    <LM>w#w-d1t2344-3</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m057-d1t2344-4">
   <w.rf>
    <LM>w#w-d1t2344-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m057-d1t2344-5">
   <w.rf>
    <LM>w#w-d1t2344-5</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m057-d1t2344-6">
   <w.rf>
    <LM>w#w-d1t2344-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-497-498">
   <w.rf>
    <LM>w#w-497-498</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2344-7">
   <w.rf>
    <LM>w#w-d1t2344-7</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2344-8">
   <w.rf>
    <LM>w#w-d1t2344-8</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2344-9">
   <w.rf>
    <LM>w#w-d1t2344-9</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2344-10">
   <w.rf>
    <LM>w#w-d1t2344-10</LM>
   </w.rf>
   <form>rozsáhlá</form>
   <lemma>rozsáhlý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m057-d-m-d1e2328-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2328-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2345-x2">
  <m id="m057-d1t2352-1">
   <w.rf>
    <LM>w#w-d1t2352-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2352-2">
   <w.rf>
    <LM>w#w-d1t2352-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2352-3">
   <w.rf>
    <LM>w#w-d1t2352-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2352-4">
   <w.rf>
    <LM>w#w-d1t2352-4</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m057-d1t2352-5">
   <w.rf>
    <LM>w#w-d1t2352-5</LM>
   </w.rf>
   <form>nepěstujete</form>
   <lemma>pěstovat</lemma>
   <tag>VB-P---2P-NAI--</tag>
  </m>
  <m id="m057-d-id125203-punct">
   <w.rf>
    <LM>w#w-d-id125203-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2353-x2">
  <m id="m057-d1t2360-1">
   <w.rf>
    <LM>w#w-d1t2360-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1e2353-x2-442">
   <w.rf>
    <LM>w#w-d1e2353-x2-442</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2360-2">
   <w.rf>
    <LM>w#w-d1t2360-2</LM>
   </w.rf>
   <form>příliš</form>
   <lemma>příliš</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1e2353-x2-547">
   <w.rf>
    <LM>w#w-d1e2353-x2-547</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-548">
  <m id="m057-d1t2362-9">
   <w.rf>
    <LM>w#w-d1t2362-9</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2362-10">
   <w.rf>
    <LM>w#w-d1t2362-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2362-4">
   <w.rf>
    <LM>w#w-d1t2362-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2364-1">
   <w.rf>
    <LM>w#w-d1t2364-1</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2364-2">
   <w.rf>
    <LM>w#w-d1t2364-2</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2364-3">
   <w.rf>
    <LM>w#w-d1t2364-3</LM>
   </w.rf>
   <form>vysoko</form>
   <lemma>vysoko-1</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-548-566">
   <w.rf>
    <LM>w#w-548-566</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2367-1">
   <w.rf>
    <LM>w#w-d1t2367-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2367-2">
   <w.rf>
    <LM>w#w-d1t2367-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2367-3">
   <w.rf>
    <LM>w#w-d1t2367-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m057-d1t2367-4">
   <w.rf>
    <LM>w#w-d1t2367-4</LM>
   </w.rf>
   <form>výšce</form>
   <lemma>výška</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d-id125607-punct">
   <w.rf>
    <LM>w#w-d-id125607-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2367-6">
   <w.rf>
    <LM>w#w-d1t2367-6</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m057-d1t2367-7">
   <w.rf>
    <LM>w#w-d1t2367-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2367-8">
   <w.rf>
    <LM>w#w-d1t2367-8</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2367-9">
   <w.rf>
    <LM>w#w-d1t2367-9</LM>
   </w.rf>
   <form>blíží</form>
   <lemma>blížit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2367-10">
   <w.rf>
    <LM>w#w-d1t2367-10</LM>
   </w.rf>
   <form>tisíci</form>
   <lemma>tisíc`1000</lemma>
   <tag>CzIS3----------</tag>
  </m>
  <m id="m057-d1t2367-11">
   <w.rf>
    <LM>w#w-d1t2367-11</LM>
   </w.rf>
   <form>metrům</form>
   <lemma>metr</lemma>
   <tag>NNIP3-----A----</tag>
  </m>
  <m id="m057-d1t2367-12">
   <w.rf>
    <LM>w#w-d1t2367-12</LM>
   </w.rf>
   <form>nad</form>
   <lemma>nad-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m057-d1t2367-13">
   <w.rf>
    <LM>w#w-d1t2367-13</LM>
   </w.rf>
   <form>mořem</form>
   <lemma>moře</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m057-550-556">
   <w.rf>
    <LM>w#w-550-556</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-557">
  <m id="m057-d1t2371-2">
   <w.rf>
    <LM>w#w-d1t2371-2</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m057-d1t2371-3">
   <w.rf>
    <LM>w#w-d1t2371-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m057-d1t2371-4">
   <w.rf>
    <LM>w#w-d1t2371-4</LM>
   </w.rf>
   <form>počasí</form>
   <lemma>počasí</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m057-d1t2377-1">
   <w.rf>
    <LM>w#w-d1t2377-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2377-2">
   <w.rf>
    <LM>w#w-d1t2377-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2377-3">
   <w.rf>
    <LM>w#w-d1t2377-3</LM>
   </w.rf>
   <form>dají</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m057-d1t2377-4">
   <w.rf>
    <LM>w#w-d1t2377-4</LM>
   </w.rf>
   <form>pěstovat</form>
   <lemma>pěstovat</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m057-d1t2377-5">
   <w.rf>
    <LM>w#w-d1t2377-5</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2377-7">
   <w.rf>
    <LM>w#w-d1t2377-7</LM>
   </w.rf>
   <form>nenáročné</form>
   <lemma>náročný</lemma>
   <tag>AAFP1----1N----</tag>
  </m>
  <m id="m057-d1t2377-8">
   <w.rf>
    <LM>w#w-d1t2377-8</LM>
   </w.rf>
   <form>květiny</form>
   <lemma>květina</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m057-557-567">
   <w.rf>
    <LM>w#w-557-567</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-568">
  <m id="m057-d1t2380-1">
   <w.rf>
    <LM>w#w-d1t2380-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2380-2">
   <w.rf>
    <LM>w#w-d1t2380-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m057-d1t2380-3">
   <w.rf>
    <LM>w#w-d1t2380-3</LM>
   </w.rf>
   <form>jiné</form>
   <lemma>jiný</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m057-d1t2380-4">
   <w.rf>
    <LM>w#w-d1t2380-4</LM>
   </w.rf>
   <form>využití</form>
   <lemma>využití_^(*3ít)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m057-d1t2380-5">
   <w.rf>
    <LM>w#w-d1t2380-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2380-6">
   <w.rf>
    <LM>w#w-d1t2380-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2380-7">
   <w.rf>
    <LM>w#w-d1t2380-7</LM>
   </w.rf>
   <form>určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2380-8">
   <w.rf>
    <LM>w#w-d1t2380-8</LM>
   </w.rf>
   <form>nehodí</form>
   <lemma>hodit-2_^(bude_se_hodit)</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m057-568-569">
   <w.rf>
    <LM>w#w-568-569</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2382-2">
   <w.rf>
    <LM>w#w-d1t2382-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2382-3">
   <w.rf>
    <LM>w#w-d1t2382-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2382-4">
   <w.rf>
    <LM>w#w-d1t2382-4</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m057-d1t2382-5">
   <w.rf>
    <LM>w#w-d1t2382-5</LM>
   </w.rf>
   <form>účel</form>
   <lemma>účel</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2353-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2353-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2383-x2">
  <m id="m057-d1t2386-1">
   <w.rf>
    <LM>w#w-d1t2386-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m057-d1e2383-x2-571">
   <w.rf>
    <LM>w#w-d1e2383-x2-571</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-572">
  <m id="m057-d1t2388-1">
   <w.rf>
    <LM>w#w-d1t2388-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2388-2">
   <w.rf>
    <LM>w#w-d1t2388-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2388-3">
   <w.rf>
    <LM>w#w-d1t2388-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2388-4">
   <w.rf>
    <LM>w#w-d1t2388-4</LM>
   </w.rf>
   <form>jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m057-d-id126431-punct">
   <w.rf>
    <LM>w#w-d-id126431-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2389-x2">
  <m id="m057-d1t2394-1">
   <w.rf>
    <LM>w#w-d1t2394-1</LM>
   </w.rf>
   <form>Jezdíme</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2394-2">
   <w.rf>
    <LM>w#w-d1t2394-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2394-3">
   <w.rf>
    <LM>w#w-d1t2394-3</LM>
   </w.rf>
   <form>poměrně</form>
   <lemma>poměrně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2394-4">
   <w.rf>
    <LM>w#w-d1t2394-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2394-5">
   <w.rf>
    <LM>w#w-d1t2394-5</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1e2389-x2-581">
   <w.rf>
    <LM>w#w-d1e2389-x2-581</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-582">
  <m id="m057-d1t2396-1">
   <w.rf>
    <LM>w#w-d1t2396-1</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2396-2">
   <w.rf>
    <LM>w#w-d1t2396-2</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2396-3">
   <w.rf>
    <LM>w#w-d1t2396-3</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m057-d1t2396-4">
   <w.rf>
    <LM>w#w-d1t2396-4</LM>
   </w.rf>
   <form>důvodu</form>
   <lemma>důvod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m057-d-id126674-punct">
   <w.rf>
    <LM>w#w-d-id126674-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2398-1">
   <w.rf>
    <LM>w#w-d1t2398-1</LM>
   </w.rf>
   <form>abychom</form>
   <lemma>aby</lemma>
   <tag>J,-----------m-</tag>
  </m>
  <m id="m057-d1t2398-2">
   <w.rf>
    <LM>w#w-d1t2398-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2398-3">
   <w.rf>
    <LM>w#w-d1t2398-3</LM>
   </w.rf>
   <form>pracovali</form>
   <lemma>pracovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m057-582-8">
   <w.rf>
    <LM>w#w-582-8</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-11">
  <m id="m057-d1t2403-7">
   <w.rf>
    <LM>w#w-d1t2403-7</LM>
   </w.rf>
   <form>Jedná</form>
   <lemma>jednat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2403-6">
   <w.rf>
    <LM>w#w-d1t2403-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2403-8">
   <w.rf>
    <LM>w#w-d1t2403-8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2403-9">
   <w.rf>
    <LM>w#w-d1t2403-9</LM>
   </w.rf>
   <form>dřevostavbu</form>
   <lemma>dřevostavba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d-id126913-punct">
   <w.rf>
    <LM>w#w-d-id126913-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2403-11">
   <w.rf>
    <LM>w#w-d1t2403-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2403-12">
   <w.rf>
    <LM>w#w-d1t2403-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2403-13">
   <w.rf>
    <LM>w#w-d1t2403-13</LM>
   </w.rf>
   <form>roubenka</form>
   <lemma>roubenka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-11-14">
   <w.rf>
    <LM>w#w-11-14</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-15">
  <m id="m057-d1t2403-1">
   <w.rf>
    <LM>w#w-d1t2403-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2403-2">
   <w.rf>
    <LM>w#w-d1t2403-2</LM>
   </w.rf>
   <form>nedávné</form>
   <lemma>dávný</lemma>
   <tag>AAFS6----1N----</tag>
  </m>
  <m id="m057-d1t2403-3">
   <w.rf>
    <LM>w#w-d1t2403-3</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d1t2405-2">
   <w.rf>
    <LM>w#w-d1t2405-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m057-d1t2405-3">
   <w.rf>
    <LM>w#w-d1t2405-3</LM>
   </w.rf>
   <form>vyměňovali</form>
   <lemma>vyměňovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m057-d1t2405-4">
   <w.rf>
    <LM>w#w-d1t2405-4</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2405-5">
   <w.rf>
    <LM>w#w-d1t2405-5</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m057-d1t2405-6">
   <w.rf>
    <LM>w#w-d1t2405-6</LM>
   </w.rf>
   <form>obvodové</form>
   <lemma>obvodový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m057-d1t2405-7">
   <w.rf>
    <LM>w#w-d1t2405-7</LM>
   </w.rf>
   <form>zdi</form>
   <lemma>zeď</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m057-15-454">
   <w.rf>
    <LM>w#w-15-454</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2405-10">
   <w.rf>
    <LM>w#w-d1t2405-10</LM>
   </w.rf>
   <form>řadu</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m057-d1t2405-11">
   <w.rf>
    <LM>w#w-d1t2405-11</LM>
   </w.rf>
   <form>stropních</form>
   <lemma>stropní</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m057-d1t2405-12">
   <w.rf>
    <LM>w#w-d1t2405-12</LM>
   </w.rf>
   <form>trámů</form>
   <lemma>trám</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m057-11-12">
   <w.rf>
    <LM>w#w-11-12</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-13">
  <m id="m057-d1t2409-2">
   <w.rf>
    <LM>w#w-d1t2409-2</LM>
   </w.rf>
   <form>Dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2411-1">
   <w.rf>
    <LM>w#w-d1t2411-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2411-2">
   <w.rf>
    <LM>w#w-d1t2411-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2411-3">
   <w.rf>
    <LM>w#w-d1t2411-3</LM>
   </w.rf>
   <form>tedy</form>
   <lemma>tedy-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2411-4">
   <w.rf>
    <LM>w#w-d1t2411-4</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2411-5">
   <w.rf>
    <LM>w#w-d1t2411-5</LM>
   </w.rf>
   <form>vyřešeno</form>
   <lemma>vyřešit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m057-d1t2411-6">
   <w.rf>
    <LM>w#w-d1t2411-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2411-7">
   <w.rf>
    <LM>w#w-d1t2411-7</LM>
   </w.rf>
   <form>statické</form>
   <lemma>statický</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m057-d1t2411-8">
   <w.rf>
    <LM>w#w-d1t2411-8</LM>
   </w.rf>
   <form>stránce</form>
   <lemma>stránka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d-id127362-punct">
   <w.rf>
    <LM>w#w-d-id127362-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2411-10">
   <w.rf>
    <LM>w#w-d1t2411-10</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2416-1">
   <w.rf>
    <LM>w#w-d1t2416-1</LM>
   </w.rf>
   <form>chybí</form>
   <lemma>chybět_^(někde_něco_chybí)</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2416-2">
   <w.rf>
    <LM>w#w-d1t2416-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2416-3">
   <w.rf>
    <LM>w#w-d1t2416-3</LM>
   </w.rf>
   <form>spousta</form>
   <lemma>spousta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d1t2416-4">
   <w.rf>
    <LM>w#w-d1t2416-4</LM>
   </w.rf>
   <form>práce</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-d1t2416-5">
   <w.rf>
    <LM>w#w-d1t2416-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2416-6">
   <w.rf>
    <LM>w#w-d1t2416-6</LM>
   </w.rf>
   <form>vnitřních</form>
   <lemma>vnitřní</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m057-d1t2416-7">
   <w.rf>
    <LM>w#w-d1t2416-7</LM>
   </w.rf>
   <form>úpravách</form>
   <lemma>úprava</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2389-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2389-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2417-x2">
  <m id="m057-d1t2420-1">
   <w.rf>
    <LM>w#w-d1t2420-1</LM>
   </w.rf>
   <form>Jezdíte</form>
   <lemma>jezdit</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m057-d1t2420-2">
   <w.rf>
    <LM>w#w-d1t2420-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2420-3">
   <w.rf>
    <LM>w#w-d1t2420-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2420-4">
   <w.rf>
    <LM>w#w-d1t2420-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m057-d1t2420-5">
   <w.rf>
    <LM>w#w-d1t2420-5</LM>
   </w.rf>
   <form>lyže</form>
   <lemma>lyže</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m057-d-id127643-punct">
   <w.rf>
    <LM>w#w-d-id127643-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2422-x2">
  <m id="m057-d1t2429-1">
   <w.rf>
    <LM>w#w-d1t2429-1</LM>
   </w.rf>
   <form>Určitě</form>
   <lemma>určitě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d-id127737-punct">
   <w.rf>
    <LM>w#w-d-id127737-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2429-3">
   <w.rf>
    <LM>w#w-d1t2429-3</LM>
   </w.rf>
   <form>hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2429-4">
   <w.rf>
    <LM>w#w-d1t2429-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2429-5">
   <w.rf>
    <LM>w#w-d1t2429-5</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d1e2422-x2-29">
   <w.rf>
    <LM>w#w-d1e2422-x2-29</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-33">
  <m id="m057-d1t2429-7">
   <w.rf>
    <LM>w#w-d1t2429-7</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2429-8">
   <w.rf>
    <LM>w#w-d1t2429-8</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2429-9">
   <w.rf>
    <LM>w#w-d1t2429-9</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2431-1">
   <w.rf>
    <LM>w#w-d1t2431-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2431-2">
   <w.rf>
    <LM>w#w-d1t2431-2</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m057-d1t2431-3">
   <w.rf>
    <LM>w#w-d1t2431-3</LM>
   </w.rf>
   <form>fajn</form>
   <lemma>fajn-1</lemma>
   <tag>AAXXX----1A----</tag>
  </m>
  <m id="m057-d-id127948-punct">
   <w.rf>
    <LM>w#w-d-id127948-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2433-4">
   <w.rf>
    <LM>w#w-d1t2433-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2433-5">
   <w.rf>
    <LM>w#w-d1t2433-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2433-6">
   <w.rf>
    <LM>w#w-d1t2433-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2436-1">
   <w.rf>
    <LM>w#w-d1t2436-1</LM>
   </w.rf>
   <form>dá</form>
   <lemma>dát-1</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m057-d1t2436-2">
   <w.rf>
    <LM>w#w-d1t2436-2</LM>
   </w.rf>
   <form>využívat</form>
   <lemma>využívat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m057-d-id128092-punct">
   <w.rf>
    <LM>w#w-d-id128092-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2436-4">
   <w.rf>
    <LM>w#w-d1t2436-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2436-5">
   <w.rf>
    <LM>w#w-d1t2436-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2436-6">
   <w.rf>
    <LM>w#w-d1t2436-6</LM>
   </w.rf>
   <form>zimě</form>
   <lemma>zima-1</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d-id128147-punct">
   <w.rf>
    <LM>w#w-d-id128147-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2436-8">
   <w.rf>
    <LM>w#w-d1t2436-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m057-d1t2436-9">
   <w.rf>
    <LM>w#w-d1t2436-9</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2436-10">
   <w.rf>
    <LM>w#w-d1t2436-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2436-11">
   <w.rf>
    <LM>w#w-d1t2436-11</LM>
   </w.rf>
   <form>letním</form>
   <lemma>letní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m057-d1t2436-12">
   <w.rf>
    <LM>w#w-d1t2436-12</LM>
   </w.rf>
   <form>období</form>
   <lemma>období</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m057-33-35">
   <w.rf>
    <LM>w#w-33-35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-36">
  <m id="m057-d1t2438-1">
   <w.rf>
    <LM>w#w-d1t2438-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2438-2">
   <w.rf>
    <LM>w#w-d1t2438-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d1t2438-3">
   <w.rf>
    <LM>w#w-d1t2438-3</LM>
   </w.rf>
   <form>krásně</form>
   <lemma>krásně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2438-4">
   <w.rf>
    <LM>w#w-d1t2438-4</LM>
   </w.rf>
   <form>pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-d-m-d1e2422-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2422-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2439-x2">
  <m id="m057-d1t2442-1">
   <w.rf>
    <LM>w#w-d1t2442-1</LM>
   </w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m057-d1t2442-2">
   <w.rf>
    <LM>w#w-d1t2442-2</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m057-d1t2442-3">
   <w.rf>
    <LM>w#w-d1t2442-3</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m057-d1t2442-6">
   <w.rf>
    <LM>w#w-d1t2442-6</LM>
   </w.rf>
   <form>může</form>
   <lemma>moci</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2442-7">
   <w.rf>
    <LM>w#w-d1t2442-7</LM>
   </w.rf>
   <form>být</form>
   <lemma>být</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m057-d1t2442-5">
   <w.rf>
    <LM>w#w-d1t2442-5</LM>
   </w.rf>
   <form>tahle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m057-d1t2442-8">
   <w.rf>
    <LM>w#w-d1t2442-8</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m057-d-id128474-punct">
   <w.rf>
    <LM>w#w-d-id128474-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-d1e2443-x2">
  <m id="m057-d1t2448-1">
   <w.rf>
    <LM>w#w-d1t2448-1</LM>
   </w.rf>
   <form>Syn</form>
   <lemma>syn</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m057-d1t2448-2">
   <w.rf>
    <LM>w#w-d1t2448-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m057-d1t2448-3">
   <w.rf>
    <LM>w#w-d1t2448-3</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m057-d1t2450-1">
   <w.rf>
    <LM>w#w-d1t2450-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2450-2">
   <w.rf>
    <LM>w#w-d1t2450-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m057-d1t2450-3">
   <w.rf>
    <LM>w#w-d1t2450-3</LM>
   </w.rf>
   <form>1969</form>
   <lemma>1969</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m057-d1e2443-x2-46">
   <w.rf>
    <LM>w#w-d1e2443-x2-46</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m057-47">
  <m id="m057-d1t2454-7">
   <w.rf>
    <LM>w#w-d1t2454-7</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m057-d1t2454-8">
   <w.rf>
    <LM>w#w-d1t2454-8</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m057-d1t2454-9">
   <w.rf>
    <LM>w#w-d1t2454-9</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m057-d1t2457-5">
   <w.rf>
    <LM>w#w-d1t2457-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2457-6">
   <w.rf>
    <LM>w#w-d1t2457-6</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m057-d1t2457-7">
   <w.rf>
    <LM>w#w-d1t2457-7</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m057-d1t2461-7">
   <w.rf>
    <LM>w#w-d1t2461-7</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m057-d1t2461-8">
   <w.rf>
    <LM>w#w-d1t2461-8</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m057-d-id129162-punct">
   <w.rf>
    <LM>w#w-d-id129162-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2461-10">
   <w.rf>
    <LM>w#w-d1t2461-10</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2463-1">
   <w.rf>
    <LM>w#w-d1t2463-1</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m057-d1t2463-2">
   <w.rf>
    <LM>w#w-d1t2463-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m057-d1t2463-3">
   <w.rf>
    <LM>w#w-d1t2463-3</LM>
   </w.rf>
   <form>těsně</form>
   <lemma>těsně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m057-d1t2463-4">
   <w.rf>
    <LM>w#w-d1t2463-4</LM>
   </w.rf>
   <form>předtím</form>
   <lemma>předtím</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m057-47-472">
   <w.rf>
    <LM>w#w-47-472</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m057-d1t2463-5">
   <w.rf>
    <LM>w#w-d1t2463-5</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m057-d1t2463-6">
   <w.rf>
    <LM>w#w-d1t2463-6</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m057-d1t2463-7">
   <w.rf>
    <LM>w#w-d1t2463-7</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m057-d1t2463-8">
   <w.rf>
    <LM>w#w-d1t2463-8</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m057-d-m-d1e2443-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2443-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
