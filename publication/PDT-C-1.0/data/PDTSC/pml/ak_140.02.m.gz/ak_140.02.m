<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="ak_140.02.w.gz" />
  </references>
 </head>
 <s id="m140-385">
  <m id="m140-d1t385-22">
   <w.rf>
    <LM>w#w-d1t385-22</LM>
   </w.rf>
   <form>Podobně</form>
   <lemma>podobně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t385-23">
   <w.rf>
    <LM>w#w-d1t385-23</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t385-24">
   <w.rf>
    <LM>w#w-d1t385-24</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t385-25">
   <w.rf>
    <LM>w#w-d1t385-25</LM>
   </w.rf>
   <form>exkurze</form>
   <lemma>exkurze</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m140-d1t385-26">
   <w.rf>
    <LM>w#w-d1t385-26</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t385-27">
   <w.rf>
    <LM>w#w-d1t385-27</LM>
   </w.rf>
   <form>pivovaru</form>
   <lemma>pivovar</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-d-id69921-punct">
   <w.rf>
    <LM>w#w-d-id69921-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t387-1">
   <w.rf>
    <LM>w#w-d1t387-1</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t387-2">
   <w.rf>
    <LM>w#w-d1t387-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t387-7">
   <w.rf>
    <LM>w#w-d1t387-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t387-8">
   <w.rf>
    <LM>w#w-d1t387-8</LM>
   </w.rf>
   <form>seznamovali</form>
   <lemma>seznamovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t387-9">
   <w.rf>
    <LM>w#w-d1t387-9</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t387-10">
   <w.rf>
    <LM>w#w-d1t387-10</LM>
   </w.rf>
   <form>výrobou</form>
   <lemma>výroba</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m140-d1t387-11">
   <w.rf>
    <LM>w#w-d1t387-11</LM>
   </w.rf>
   <form>piva</form>
   <lemma>pivo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m140-d-m-d1e356-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e356-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e388-x2">
  <m id="m140-d1t391-1">
   <w.rf>
    <LM>w#w-d1t391-1</LM>
   </w.rf>
   <form>Jaký</form>
   <lemma>jaký</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m140-d1t391-2">
   <w.rf>
    <LM>w#w-d1t391-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t391-3">
   <w.rf>
    <LM>w#w-d1t391-3</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t391-4">
   <w.rf>
    <LM>w#w-d1t391-4</LM>
   </w.rf>
   <form>student</form>
   <lemma>student</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d-id70210-punct">
   <w.rf>
    <LM>w#w-d-id70210-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e392-x2">
  <m id="m140-d1t397-1">
   <w.rf>
    <LM>w#w-d1t397-1</LM>
   </w.rf>
   <form>Normální</form>
   <lemma>normální</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m140-d1e392-x2-397">
   <w.rf>
    <LM>w#w-d1e392-x2-397</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-398">
  <m id="m140-d1t403-1">
   <w.rf>
    <LM>w#w-d1t403-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t403-2">
   <w.rf>
    <LM>w#w-d1t403-2</LM>
   </w.rf>
   <form>létě</form>
   <lemma>léto</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1t403-3">
   <w.rf>
    <LM>w#w-d1t403-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t403-4">
   <w.rf>
    <LM>w#w-d1t403-4</LM>
   </w.rf>
   <form>prázdninách</form>
   <lemma>prázdniny</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m140-d1t403-5">
   <w.rf>
    <LM>w#w-d1t403-5</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t403-6">
   <w.rf>
    <LM>w#w-d1t403-6</LM>
   </w.rf>
   <form>škola</form>
   <lemma>škola</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t403-7">
   <w.rf>
    <LM>w#w-d1t403-7</LM>
   </w.rf>
   <form>povinnou</form>
   <lemma>povinný</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m140-d1t403-8">
   <w.rf>
    <LM>w#w-d1t403-8</LM>
   </w.rf>
   <form>praxi</form>
   <lemma>praxe</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-398-399">
   <w.rf>
    <LM>w#w-398-399</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-400">
  <m id="m140-d1t406-3">
   <w.rf>
    <LM>w#w-d1t406-3</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m140-d1t406-2">
   <w.rf>
    <LM>w#w-d1t406-2</LM>
   </w.rf>
   <form>konkrétně</form>
   <lemma>konkrétně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t406-4">
   <w.rf>
    <LM>w#w-d1t406-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t406-5">
   <w.rf>
    <LM>w#w-d1t406-5</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t406-6">
   <w.rf>
    <LM>w#w-d1t406-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t406-8">
   <w.rf>
    <LM>w#w-d1t406-8</LM>
   </w.rf>
   <form>Luhačovicích</form>
   <lemma>Luhačovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m140-d1t406-10">
   <w.rf>
    <LM>w#w-d1t406-10</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t406-11">
   <w.rf>
    <LM>w#w-d1t406-11</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m140-d1t406-13">
   <w.rf>
    <LM>w#w-d1t406-13</LM>
   </w.rf>
   <form>Alexandria</form>
   <lemma>Alexandrie_;G</lemma>
   <tag>NNFS1-----A---1</tag>
  </m>
  <m id="m140-d1t406-15">
   <w.rf>
    <LM>w#w-d1t406-15</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t406-16">
   <w.rf>
    <LM>w#w-d1t406-16</LM>
   </w.rf>
   <form>číšník</form>
   <lemma>číšník</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t406-17">
   <w.rf>
    <LM>w#w-d1t406-17</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t406-18">
   <w.rf>
    <LM>w#w-d1t406-18</LM>
   </w.rf>
   <form>šest</form>
   <lemma>šest`6</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m140-d1t406-19">
   <w.rf>
    <LM>w#w-d1t406-19</LM>
   </w.rf>
   <form>neděl</form>
   <lemma>neděle</lemma>
   <tag>NNFP2-----A---1</tag>
  </m>
  <m id="m140-d-m-d1e392-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e392-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e413-x2">
  <m id="m140-d1t416-1">
   <w.rf>
    <LM>w#w-d1t416-1</LM>
   </w.rf>
   <form>Měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t416-2">
   <w.rf>
    <LM>w#w-d1t416-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t416-3">
   <w.rf>
    <LM>w#w-d1t416-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t416-4">
   <w.rf>
    <LM>w#w-d1t416-4</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t416-5">
   <w.rf>
    <LM>w#w-d1t416-5</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t416-6">
   <w.rf>
    <LM>w#w-d1t416-6</LM>
   </w.rf>
   <form>kamarádů</form>
   <lemma>kamarád</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m140-d-id70879-punct">
   <w.rf>
    <LM>w#w-d-id70879-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e417-x2">
  <m id="m140-d1t426-2">
   <w.rf>
    <LM>w#w-d1t426-2</LM>
   </w.rf>
   <form>Hlavně</form>
   <lemma>hlavně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t426-3">
   <w.rf>
    <LM>w#w-d1t426-3</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m140-d-id71014-punct">
   <w.rf>
    <LM>w#w-d-id71014-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t428-2">
   <w.rf>
    <LM>w#w-d1t428-2</LM>
   </w.rf>
   <form>Karla</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m140-d1t428-3">
   <w.rf>
    <LM>w#w-d1t428-3</LM>
   </w.rf>
   <form>Bendového</form>
   <lemma>Bendův_;Y</lemma>
   <tag>AUMS2M--------6</tag>
  </m>
  <m id="m140-d1t428-5">
   <w.rf>
    <LM>w#w-d1t428-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t428-7">
   <w.rf>
    <LM>w#w-d1t428-7</LM>
   </w.rf>
   <form>Milana</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m140-d1t428-8">
   <w.rf>
    <LM>w#w-d1t428-8</LM>
   </w.rf>
   <form>Ticháčkového</form>
   <lemma>Ticháčkův_;Y</lemma>
   <tag>AUMS2M--------6</tag>
  </m>
  <m id="m140-d1e417-x2-419">
   <w.rf>
    <LM>w#w-d1e417-x2-419</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-420">
  <m id="m140-d1t431-1">
   <w.rf>
    <LM>w#w-d1t431-1</LM>
   </w.rf>
   <form>Oba</form>
   <lemma>oba`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m140-d1t431-2">
   <w.rf>
    <LM>w#w-d1t431-2</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP1----------</tag>
  </m>
  <m id="m140-d1t431-3">
   <w.rf>
    <LM>w#w-d1t431-3</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t431-4">
   <w.rf>
    <LM>w#w-d1t431-4</LM>
   </w.rf>
   <form>oboru</form>
   <lemma>obor_^(lidské_činnosti)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-420-421">
   <w.rf>
    <LM>w#w-420-421</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-422">
  <m id="m140-d1t433-6">
   <w.rf>
    <LM>w#w-d1t433-6</LM>
   </w.rf>
   <form>Karel</form>
   <lemma>Karel_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t433-9">
   <w.rf>
    <LM>w#w-d1t433-9</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t433-8">
   <w.rf>
    <LM>w#w-d1t433-8</LM>
   </w.rf>
   <form>bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t433-10">
   <w.rf>
    <LM>w#w-d1t433-10</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m140-422-423">
   <w.rf>
    <LM>w#w-422-423</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-424">
  <m id="m140-d1t437-1">
   <w.rf>
    <LM>w#w-d1t437-1</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t437-3">
   <w.rf>
    <LM>w#w-d1t437-3</LM>
   </w.rf>
   <form>Milanem</form>
   <lemma>Milan_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m140-d1t437-5">
   <w.rf>
    <LM>w#w-d1t437-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t437-6">
   <w.rf>
    <LM>w#w-d1t437-6</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t437-7">
   <w.rf>
    <LM>w#w-d1t437-7</LM>
   </w.rf>
   <form>vídáme</form>
   <lemma>vídat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t437-15">
   <w.rf>
    <LM>w#w-d1t437-15</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t437-16">
   <w.rf>
    <LM>w#w-d1t437-16</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d-id71491-punct">
   <w.rf>
    <LM>w#w-d-id71491-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t437-9">
   <w.rf>
    <LM>w#w-d1t437-9</LM>
   </w.rf>
   <form>poněvadž</form>
   <lemma>poněvadž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t437-10">
   <w.rf>
    <LM>w#w-d1t437-10</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t437-11">
   <w.rf>
    <LM>w#w-d1t437-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t437-13">
   <w.rf>
    <LM>w#w-d1t437-13</LM>
   </w.rf>
   <form>Brně</form>
   <lemma>Brno_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d-m-d1e417-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e417-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e438-x3">
  <m id="m140-d1t449-1">
   <w.rf>
    <LM>w#w-d1t449-1</LM>
   </w.rf>
   <form>Děkuji</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI-1</tag>
  </m>
  <m id="m140-d-m-d1e438-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e438-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e450-x2">
  <m id="m140-d1t453-1">
   <w.rf>
    <LM>w#w-d1t453-1</LM>
   </w.rf>
   <form>Prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d-m-d1e450-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e450-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e454-x2">
  <m id="m140-d1t457-1">
   <w.rf>
    <LM>w#w-d1t457-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m140-d1t457-2">
   <w.rf>
    <LM>w#w-d1t457-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t457-3">
   <w.rf>
    <LM>w#w-d1t457-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d-id71957-punct">
   <w.rf>
    <LM>w#w-d-id71957-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e458-x2">
  <m id="m140-d1t461-1">
   <w.rf>
    <LM>w#w-d1t461-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t461-2">
   <w.rf>
    <LM>w#w-d1t461-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t461-5">
   <w.rf>
    <LM>w#w-d1t461-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t461-7">
   <w.rf>
    <LM>w#w-d1t461-7</LM>
   </w.rf>
   <form>Hronově</form>
   <lemma>Hronov_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m140-d1t461-3">
   <w.rf>
    <LM>w#w-d1t461-3</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t461-4">
   <w.rf>
    <LM>w#w-d1t461-4</LM>
   </w.rf>
   <form>nás</form>
   <lemma>my</lemma>
   <tag>PP-P2--1-------</tag>
  </m>
  <m id="m140-d1t461-9">
   <w.rf>
    <LM>w#w-d1t461-9</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t461-10">
   <w.rf>
    <LM>w#w-d1t461-10</LM>
   </w.rf>
   <form>zahradě</form>
   <lemma>zahrada</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t461-11">
   <w.rf>
    <LM>w#w-d1t461-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m140-d1t461-12">
   <w.rf>
    <LM>w#w-d1t461-12</LM>
   </w.rf>
   <form>mojí</form>
   <lemma>můj</lemma>
   <tag>PSFS7-S1-------</tag>
  </m>
  <m id="m140-d1t461-16">
   <w.rf>
    <LM>w#w-d1t461-16</LM>
   </w.rf>
   <form>manželkou</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m140-d1t461-14">
   <w.rf>
    <LM>w#w-d1t461-14</LM>
   </w.rf>
   <form>Věruškou</form>
   <lemma>Věruška_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m140-d1e458-x2-437">
   <w.rf>
    <LM>w#w-d1e458-x2-437</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-438">
  <m id="m140-d1t463-1">
   <w.rf>
    <LM>w#w-d1t463-1</LM>
   </w.rf>
   <form>Tenkrát</form>
   <lemma>tenkrát</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t463-3">
   <w.rf>
    <LM>w#w-d1t463-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t463-2">
   <w.rf>
    <LM>w#w-d1t463-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t463-4">
   <w.rf>
    <LM>w#w-d1t463-4</LM>
   </w.rf>
   <form>svobodná</form>
   <lemma>svobodný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-438-439">
   <w.rf>
    <LM>w#w-438-439</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-440">
  <m id="m140-d1t465-1">
   <w.rf>
    <LM>w#w-d1t465-1</LM>
   </w.rf>
   <form>Později</form>
   <lemma>pozdě</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m140-d1t465-2">
   <w.rf>
    <LM>w#w-d1t465-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t465-3">
   <w.rf>
    <LM>w#w-d1t465-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t465-4">
   <w.rf>
    <LM>w#w-d1t465-4</LM>
   </w.rf>
   <form>vzali</form>
   <lemma>vzít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m140-d-m-d1e458-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e458-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e472-x2">
  <m id="m140-d1t475-1">
   <w.rf>
    <LM>w#w-d1t475-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t475-2">
   <w.rf>
    <LM>w#w-d1t475-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t475-3">
   <w.rf>
    <LM>w#w-d1t475-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t475-4">
   <w.rf>
    <LM>w#w-d1t475-4</LM>
   </w.rf>
   <form>seznámil</form>
   <lemma>seznámit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m140-d1t475-5">
   <w.rf>
    <LM>w#w-d1t475-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m140-d1t475-6">
   <w.rf>
    <LM>w#w-d1t475-6</LM>
   </w.rf>
   <form>svou</form>
   <lemma>svůj-1</lemma>
   <tag>P8FS7---------1</tag>
  </m>
  <m id="m140-d1t475-7">
   <w.rf>
    <LM>w#w-d1t475-7</LM>
   </w.rf>
   <form>ženou</form>
   <lemma>žena</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m140-d-id72560-punct">
   <w.rf>
    <LM>w#w-d-id72560-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e476-x2">
  <m id="m140-d1t483-2">
   <w.rf>
    <LM>w#w-d1t483-2</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t483-3">
   <w.rf>
    <LM>w#w-d1t483-3</LM>
   </w.rf>
   <form>pracovišti</form>
   <lemma>pracoviště</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1e476-x2-459">
   <w.rf>
    <LM>w#w-d1e476-x2-459</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-460">
  <m id="m140-d1t483-7">
   <w.rf>
    <LM>w#w-d1t483-7</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t483-8">
   <w.rf>
    <LM>w#w-d1t483-8</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t483-6">
   <w.rf>
    <LM>w#w-d1t483-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t483-5">
   <w.rf>
    <LM>w#w-d1t483-5</LM>
   </w.rf>
   <form>pracoval</form>
   <lemma>pracovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t485-1">
   <w.rf>
    <LM>w#w-d1t485-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t485-2">
   <w.rf>
    <LM>w#w-d1t485-2</LM>
   </w.rf>
   <form>provozář</form>
   <lemma>provozář</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t485-3">
   <w.rf>
    <LM>w#w-d1t485-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t485-4">
   <w.rf>
    <LM>w#w-d1t485-4</LM>
   </w.rf>
   <form>závodě</form>
   <lemma>závod</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m140-d1t485-7">
   <w.rf>
    <LM>w#w-d1t485-7</LM>
   </w.rf>
   <form>Družba</form>
   <lemma>Družba_;m</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d-id72877-punct">
   <w.rf>
    <LM>w#w-d-id72877-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t485-10">
   <w.rf>
    <LM>w#w-d1t485-10</LM>
   </w.rf>
   <form>kdysi</form>
   <lemma>kdysi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t485-11">
   <w.rf>
    <LM>w#w-d1t485-11</LM>
   </w.rf>
   <form>bývalý</form>
   <lemma>bývalý_^(*2t)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m140-d1t485-13">
   <w.rf>
    <LM>w#w-d1t485-13</LM>
   </w.rf>
   <form>Vašata</form>
   <lemma>Vašata_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-460-461">
   <w.rf>
    <LM>w#w-460-461</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-462">
  <m id="m140-d1t485-16">
   <w.rf>
    <LM>w#w-d1t485-16</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t485-17">
   <w.rf>
    <LM>w#w-d1t485-17</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t485-18">
   <w.rf>
    <LM>w#w-d1t485-18</LM>
   </w.rf>
   <form>velký</form>
   <lemma>velký</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m140-d1t485-19">
   <w.rf>
    <LM>w#w-d1t485-19</LM>
   </w.rf>
   <form>automat</form>
   <lemma>automat</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m140-d1t485-20">
   <w.rf>
    <LM>w#w-d1t485-20</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t485-22">
   <w.rf>
    <LM>w#w-d1t485-22</LM>
   </w.rf>
   <form>Václavském</form>
   <lemma>václavský</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m140-d1t485-23">
   <w.rf>
    <LM>w#w-d1t485-23</LM>
   </w.rf>
   <form>náměstí</form>
   <lemma>náměstí</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-462-463">
   <w.rf>
    <LM>w#w-462-463</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-464">
  <m id="m140-d1t490-3">
   <w.rf>
    <LM>w#w-d1t490-3</LM>
   </w.rf>
   <form>Věruška</form>
   <lemma>Věruška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t490-5">
   <w.rf>
    <LM>w#w-d1t490-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t490-6">
   <w.rf>
    <LM>w#w-d1t490-6</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t490-7">
   <w.rf>
    <LM>w#w-d1t490-7</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t490-8">
   <w.rf>
    <LM>w#w-d1t490-8</LM>
   </w.rf>
   <form>normařka</form>
   <lemma>normařka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-464-465">
   <w.rf>
    <LM>w#w-464-465</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-466">
  <m id="m140-d1t492-6">
   <w.rf>
    <LM>w#w-d1t492-6</LM>
   </w.rf>
   <form>Poznal</form>
   <lemma>poznat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m140-d1t492-3">
   <w.rf>
    <LM>w#w-d1t492-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t492-4">
   <w.rf>
    <LM>w#w-d1t492-4</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m140-d1t492-7">
   <w.rf>
    <LM>w#w-d1t492-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t492-8">
   <w.rf>
    <LM>w#w-d1t492-8</LM>
   </w.rf>
   <form>práci</form>
   <lemma>práce_^(jako_činnost_i_místo)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-466-467">
   <w.rf>
    <LM>w#w-466-467</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-468">
  <m id="m140-d1t496-1">
   <w.rf>
    <LM>w#w-d1t496-1</LM>
   </w.rf>
   <form>Poprvé</form>
   <lemma>poprvé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t496-2">
   <w.rf>
    <LM>w#w-d1t496-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t496-3">
   <w.rf>
    <LM>w#w-d1t496-3</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m140-d1t496-4">
   <w.rf>
    <LM>w#w-d1t496-4</LM>
   </w.rf>
   <form>pozval</form>
   <lemma>pozvat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m140-d1t498-1">
   <w.rf>
    <LM>w#w-d1t498-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t498-3">
   <w.rf>
    <LM>w#w-d1t498-3</LM>
   </w.rf>
   <form>Silvestra</form>
   <lemma>silvestr</lemma>
   <tag>NNIS4-----A---1</tag>
  </m>
  <m id="m140-d-id73616-punct">
   <w.rf>
    <LM>w#w-d-id73616-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t498-6">
   <w.rf>
    <LM>w#w-d1t498-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t498-7">
   <w.rf>
    <LM>w#w-d1t498-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t498-8">
   <w.rf>
    <LM>w#w-d1t498-8</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t498-9">
   <w.rf>
    <LM>w#w-d1t498-9</LM>
   </w.rf>
   <form>noční</form>
   <lemma>noční</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m140-d1t498-10">
   <w.rf>
    <LM>w#w-d1t498-10</LM>
   </w.rf>
   <form>službu</form>
   <lemma>služba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-468-497">
   <w.rf>
    <LM>w#w-468-497</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e476-x3">
  <m id="m140-d1t498-14">
   <w.rf>
    <LM>w#w-d1t498-14</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t498-15">
   <w.rf>
    <LM>w#w-d1t498-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t498-16">
   <w.rf>
    <LM>w#w-d1t498-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t500-1">
   <w.rf>
    <LM>w#w-d1t500-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t500-3">
   <w.rf>
    <LM>w#w-d1t500-3</LM>
   </w.rf>
   <form>domluvili</form>
   <lemma>domluvit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m140-d-id73843-punct">
   <w.rf>
    <LM>w#w-d-id73843-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t500-5">
   <w.rf>
    <LM>w#w-d1t500-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t500-6">
   <w.rf>
    <LM>w#w-d1t500-6</LM>
   </w.rf>
   <form>bychom</form>
   <lemma>být</lemma>
   <tag>Vc----------Im-</tag>
  </m>
  <m id="m140-d1t500-9">
   <w.rf>
    <LM>w#w-d1t500-9</LM>
   </w.rf>
   <form>spolu</form>
   <lemma>spolu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t500-8">
   <w.rf>
    <LM>w#w-d1t500-8</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t500-10">
   <w.rf>
    <LM>w#w-d1t500-10</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m140-d1e476-x3-510">
   <w.rf>
    <LM>w#w-d1e476-x3-510</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-511">
  <m id="m140-d1t503-3">
   <w.rf>
    <LM>w#w-d1t503-3</LM>
   </w.rf>
   <form>Hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t503-4">
   <w.rf>
    <LM>w#w-d1t503-4</LM>
   </w.rf>
   <form>6</form>
   <lemma>6</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m140-511-512">
   <w.rf>
    <LM>w#w-511-512</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t503-5">
   <w.rf>
    <LM>w#w-d1t503-5</LM>
   </w.rf>
   <form>ledna</form>
   <lemma>leden</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-d1t503-6">
   <w.rf>
    <LM>w#w-d1t503-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t503-7">
   <w.rf>
    <LM>w#w-d1t503-7</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t503-8">
   <w.rf>
    <LM>w#w-d1t503-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t503-10">
   <w.rf>
    <LM>w#w-d1t503-10</LM>
   </w.rf>
   <form>Národním</form>
   <lemma>národní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m140-d1t503-11">
   <w.rf>
    <LM>w#w-d1t503-11</LM>
   </w.rf>
   <form>divadle</form>
   <lemma>divadlo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-511-513">
   <w.rf>
    <LM>w#w-511-513</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-514">
  <m id="m140-d1t505-3">
   <w.rf>
    <LM>w#w-d1t505-3</LM>
   </w.rf>
   <form>Teďka</form>
   <lemma>teďka_,h</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t505-4">
   <w.rf>
    <LM>w#w-d1t505-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m140-d1t505-5">
   <w.rf>
    <LM>w#w-d1t505-5</LM>
   </w.rf>
   <form>nemůžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m140-d1t505-6">
   <w.rf>
    <LM>w#w-d1t505-6</LM>
   </w.rf>
   <form>vzpomenout</form>
   <lemma>vzpomenout</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m140-d-id74244-punct">
   <w.rf>
    <LM>w#w-d-id74244-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t505-8">
   <w.rf>
    <LM>w#w-d1t505-8</LM>
   </w.rf>
   <form>jaký</form>
   <lemma>jaký</lemma>
   <tag>P4IS4----------</tag>
  </m>
  <m id="m140-d1t505-9">
   <w.rf>
    <LM>w#w-d1t505-9</LM>
   </w.rf>
   <form>kus</form>
   <lemma>kus</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d1t505-10">
   <w.rf>
    <LM>w#w-d1t505-10</LM>
   </w.rf>
   <form>hráli</form>
   <lemma>hrát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-514-515">
   <w.rf>
    <LM>w#w-514-515</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-516">
  <m id="m140-d1t507-2">
   <w.rf>
    <LM>w#w-d1t507-2</LM>
   </w.rf>
   <form>Hnedka</form>
   <lemma>hnedka</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t507-3">
   <w.rf>
    <LM>w#w-d1t507-3</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t507-4">
   <w.rf>
    <LM>w#w-d1t507-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t507-5">
   <w.rf>
    <LM>w#w-d1t507-5</LM>
   </w.rf>
   <form>loži</form>
   <lemma>lože</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m140-d1t507-6">
   <w.rf>
    <LM>w#w-d1t507-6</LM>
   </w.rf>
   <form>seděl</form>
   <lemma>sedět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t507-7">
   <w.rf>
    <LM>w#w-d1t507-7</LM>
   </w.rf>
   <form>ředitel</form>
   <lemma>ředitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t507-8">
   <w.rf>
    <LM>w#w-d1t507-8</LM>
   </w.rf>
   <form>závodu</form>
   <lemma>závod</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m140-516-517">
   <w.rf>
    <LM>w#w-516-517</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-518">
  <m id="m140-d1t507-12">
   <w.rf>
    <LM>w#w-d1t507-12</LM>
   </w.rf>
   <form>Smál</form>
   <lemma>smát</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t507-11">
   <w.rf>
    <LM>w#w-d1t507-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-518-519">
   <w.rf>
    <LM>w#w-518-519</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-520">
  <m id="m140-d1t507-14">
   <w.rf>
    <LM>w#w-d1t507-14</LM>
   </w.rf>
   <form>Říkal</form>
   <lemma>říkat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-520-521">
   <w.rf>
    <LM>w#w-520-521</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-520-522">
   <w.rf>
    <LM>w#w-520-522</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t509-1">
   <w.rf>
    <LM>w#w-d1t509-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d-id74606-punct">
   <w.rf>
    <LM>w#w-d-id74606-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t509-6">
   <w.rf>
    <LM>w#w-d1t509-6</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t509-7">
   <w.rf>
    <LM>w#w-d1t509-7</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t509-8">
   <w.rf>
    <LM>w#w-d1t509-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t509-9">
   <w.rf>
    <LM>w#w-d1t509-9</LM>
   </w.rf>
   <form>seznámili</form>
   <lemma>seznámit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m140-520-523">
   <w.rf>
    <LM>w#w-520-523</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-520-525">
   <w.rf>
    <LM>w#w-520-525</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-524">
  <m id="m140-d1t509-13">
   <w.rf>
    <LM>w#w-d1t509-13</LM>
   </w.rf>
   <form>Hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t509-16">
   <w.rf>
    <LM>w#w-d1t509-16</LM>
   </w.rf>
   <form>prasklo</form>
   <lemma>prasknout</lemma>
   <tag>VpNS----R-AAP-1</tag>
  </m>
  <m id="m140-d-id74778-punct">
   <w.rf>
    <LM>w#w-d-id74778-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t509-18">
   <w.rf>
    <LM>w#w-d1t509-18</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t509-19">
   <w.rf>
    <LM>w#w-d1t509-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t509-20">
   <w.rf>
    <LM>w#w-d1t509-20</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d-m-d1e476-x4-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e476-x4-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e510-x2">
  <m id="m140-d1t513-1">
   <w.rf>
    <LM>w#w-d1t513-1</LM>
   </w.rf>
   <form>Zamilovali</form>
   <lemma>zamilovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m140-d1t513-2">
   <w.rf>
    <LM>w#w-d1t513-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t513-3">
   <w.rf>
    <LM>w#w-d1t513-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t513-4">
   <w.rf>
    <LM>w#w-d1t513-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t513-5">
   <w.rf>
    <LM>w#w-d1t513-5</LM>
   </w.rf>
   <form>sebe</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--2----------</tag>
  </m>
  <m id="m140-d1t513-6">
   <w.rf>
    <LM>w#w-d1t513-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t513-7">
   <w.rf>
    <LM>w#w-d1t513-7</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m140-d1t513-8">
   <w.rf>
    <LM>w#w-d1t513-8</LM>
   </w.rf>
   <form>pohled</form>
   <lemma>pohled</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d-id75010-punct">
   <w.rf>
    <LM>w#w-d-id75010-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e514-x2">
  <m id="m140-d1t517-1">
   <w.rf>
    <LM>w#w-d1t517-1</LM>
   </w.rf>
   <form>Dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m140-d1t517-2">
   <w.rf>
    <LM>w#w-d1t517-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m140-d1t517-3">
   <w.rf>
    <LM>w#w-d1t517-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t517-4">
   <w.rf>
    <LM>w#w-d1t517-4</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m140-d1e514-x2-541">
   <w.rf>
    <LM>w#w-d1e514-x2-541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-542">
  <m id="m140-d1t517-6">
   <w.rf>
    <LM>w#w-d1t517-6</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t517-7">
   <w.rf>
    <LM>w#w-d1t517-7</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t517-8">
   <w.rf>
    <LM>w#w-d1t517-8</LM>
   </w.rf>
   <form>sympatická</form>
   <lemma>sympatický</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-542-543">
   <w.rf>
    <LM>w#w-542-543</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t517-10">
   <w.rf>
    <LM>w#w-d1t517-10</LM>
   </w.rf>
   <form>milá</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d-m-d1e514-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e514-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e518-x2">
  <m id="m140-d1t521-1">
   <w.rf>
    <LM>w#w-d1t521-1</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t521-2">
   <w.rf>
    <LM>w#w-d1t521-2</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t521-3">
   <w.rf>
    <LM>w#w-d1t521-3</LM>
   </w.rf>
   <form>dlouhé</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m140-d1t521-4">
   <w.rf>
    <LM>w#w-d1t521-4</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t521-5">
   <w.rf>
    <LM>w#w-d1t521-5</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t521-6">
   <w.rf>
    <LM>w#w-d1t521-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m140-d1t521-7">
   <w.rf>
    <LM>w#w-d1t521-7</LM>
   </w.rf>
   <form>oženil</form>
   <lemma>oženit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m140-d-id75375-punct">
   <w.rf>
    <LM>w#w-d-id75375-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e522-x2">
  <m id="m140-d1t529-1">
   <w.rf>
    <LM>w#w-d1t529-1</LM>
   </w.rf>
   <form>Asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t529-2">
   <w.rf>
    <LM>w#w-d1t529-2</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m140-d1t529-3">
   <w.rf>
    <LM>w#w-d1t529-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t529-4">
   <w.rf>
    <LM>w#w-d1t529-4</LM>
   </w.rf>
   <form>třičtvrtě</form>
   <lemma>třičtvrtě</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m140-d1e522-x2-549">
   <w.rf>
    <LM>w#w-d1e522-x2-549</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-550">
  <m id="m140-d1t529-6">
   <w.rf>
    <LM>w#w-d1t529-6</LM>
   </w.rf>
   <form>Svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d1t529-7">
   <w.rf>
    <LM>w#w-d1t529-7</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t529-8">
   <w.rf>
    <LM>w#w-d1t529-8</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t529-9">
   <w.rf>
    <LM>w#w-d1t529-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t529-11">
   <w.rf>
    <LM>w#w-d1t529-11</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-550-551">
   <w.rf>
    <LM>w#w-550-551</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-552">
  <m id="m140-d1t529-14">
   <w.rf>
    <LM>w#w-d1t529-14</LM>
   </w.rf>
   <form>Fůru</form>
   <lemma>fůra</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d1t529-15">
   <w.rf>
    <LM>w#w-d1t529-15</LM>
   </w.rf>
   <form>známých</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m140-d-m-d1e522-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e522-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e538-x2">
  <m id="m140-d1t541-1">
   <w.rf>
    <LM>w#w-d1t541-1</LM>
   </w.rf>
   <form>Vzpomínáte</form>
   <lemma>vzpomínat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m140-d1t541-2">
   <w.rf>
    <LM>w#w-d1t541-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m140-d1t541-3">
   <w.rf>
    <LM>w#w-d1t541-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t541-4">
   <w.rf>
    <LM>w#w-d1t541-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m140-d1t541-5">
   <w.rf>
    <LM>w#w-d1t541-5</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m140-d1t541-6">
   <w.rf>
    <LM>w#w-d1t541-6</LM>
   </w.rf>
   <form>svatby</form>
   <lemma>svatba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m140-d-id75815-punct">
   <w.rf>
    <LM>w#w-d-id75815-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e542-x2">
  <m id="m140-d1t545-1">
   <w.rf>
    <LM>w#w-d1t545-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m140-d1t545-2">
   <w.rf>
    <LM>w#w-d1t545-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t545-9">
   <w.rf>
    <LM>w#w-d1t545-9</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t545-11">
   <w.rf>
    <LM>w#w-d1t545-11</LM>
   </w.rf>
   <form>Restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t545-12">
   <w.rf>
    <LM>w#w-d1t545-12</LM>
   </w.rf>
   <form>Pelikán</form>
   <lemma>pelikán</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t545-15">
   <w.rf>
    <LM>w#w-d1t545-15</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t545-16">
   <w.rf>
    <LM>w#w-d1t545-16</LM>
   </w.rf>
   <form>Příkopech</form>
   <lemma>příkop</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m140-d1e542-x2-572">
   <w.rf>
    <LM>w#w-d1e542-x2-572</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-573">
  <m id="m140-d1t551-9">
   <w.rf>
    <LM>w#w-d1t551-9</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t551-8">
   <w.rf>
    <LM>w#w-d1t551-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t551-1">
   <w.rf>
    <LM>w#w-d1t551-1</LM>
   </w.rf>
   <form>jemná</form>
   <lemma>jemný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d-id76151-punct">
   <w.rf>
    <LM>w#w-d-id76151-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t551-3">
   <w.rf>
    <LM>w#w-d1t551-3</LM>
   </w.rf>
   <form>milá</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-573-574">
   <w.rf>
    <LM>w#w-573-574</LM>
   </w.rf>
   <form>celá</form>
   <lemma>celý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t551-6">
   <w.rf>
    <LM>w#w-d1t551-6</LM>
   </w.rf>
   <form>příbuzenská</form>
   <lemma>příbuzenský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m140-d1t551-7">
   <w.rf>
    <LM>w#w-d1t551-7</LM>
   </w.rf>
   <form>společnost</form>
   <lemma>společnost_^(*3ý)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-573-575">
   <w.rf>
    <LM>w#w-573-575</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-576">
  <m id="m140-d1t553-1">
   <w.rf>
    <LM>w#w-d1t553-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m140-d1t553-2">
   <w.rf>
    <LM>w#w-d1t553-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t553-3">
   <w.rf>
    <LM>w#w-d1t553-3</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t553-4">
   <w.rf>
    <LM>w#w-d1t553-4</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m140-576-577">
   <w.rf>
    <LM>w#w-576-577</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-578">
  <m id="m140-d1t553-6">
   <w.rf>
    <LM>w#w-d1t553-6</LM>
   </w.rf>
   <form>Svatbu</form>
   <lemma>svatba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d1t553-7">
   <w.rf>
    <LM>w#w-d1t553-7</LM>
   </w.rf>
   <form>přímo</form>
   <lemma>přímo</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m140-d1t553-8">
   <w.rf>
    <LM>w#w-d1t553-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t553-9">
   <w.rf>
    <LM>w#w-d1t553-9</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t556-1">
   <w.rf>
    <LM>w#w-d1t556-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t556-3">
   <w.rf>
    <LM>w#w-d1t556-3</LM>
   </w.rf>
   <form>Staroměstské</form>
   <lemma>staroměstský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m140-d1t556-4">
   <w.rf>
    <LM>w#w-d1t556-4</LM>
   </w.rf>
   <form>radnici</form>
   <lemma>radnice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d-m-d1e542-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e542-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e557-x2">
  <m id="m140-d1t560-1">
   <w.rf>
    <LM>w#w-d1t560-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m140-d1t560-2">
   <w.rf>
    <LM>w#w-d1t560-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m140-d1t560-3">
   <w.rf>
    <LM>w#w-d1t560-3</LM>
   </w.rf>
   <form>šel</form>
   <lemma>jít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m140-d1t560-4">
   <w.rf>
    <LM>w#w-d1t560-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m140-d1t560-5">
   <w.rf>
    <LM>w#w-d1t560-5</LM>
   </w.rf>
   <form>svědka</form>
   <lemma>svědek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m140-d-id76616-punct">
   <w.rf>
    <LM>w#w-d-id76616-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e561-x2">
  <m id="m140-d1t568-4">
   <w.rf>
    <LM>w#w-d1t568-4</LM>
   </w.rf>
   <form>Můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m140-d1t568-5">
   <w.rf>
    <LM>w#w-d1t568-5</LM>
   </w.rf>
   <form>strýček</form>
   <lemma>strýček</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t570-2">
   <w.rf>
    <LM>w#w-d1t570-2</LM>
   </w.rf>
   <form>Buďárek</form>
   <lemma>Buďárek_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1t570-3">
   <w.rf>
    <LM>w#w-d1t570-3</LM>
   </w.rf>
   <form>Svatopluk</form>
   <lemma>Svatopluk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m140-d1e561-x2-587">
   <w.rf>
    <LM>w#w-d1e561-x2-587</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-588">
  <m id="m140-588-589">
   <w.rf>
    <LM>w#w-588-589</LM>
   </w.rf>
   <form>Koho</form>
   <lemma>kdo</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m140-d1t572-2">
   <w.rf>
    <LM>w#w-d1t572-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t572-1">
   <w.rf>
    <LM>w#w-d1t572-1</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d-id76888-punct">
   <w.rf>
    <LM>w#w-d-id76888-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t572-6">
   <w.rf>
    <LM>w#w-d1t572-6</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d1t572-7">
   <w.rf>
    <LM>w#w-d1t572-7</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m140-d1t572-8">
   <w.rf>
    <LM>w#w-d1t572-8</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m140-d1t572-9">
   <w.rf>
    <LM>w#w-d1t572-9</LM>
   </w.rf>
   <form>nepovím</form>
   <lemma>povědět</lemma>
   <tag>VB-S---1P-NAP--</tag>
  </m>
  <m id="m140-588-590">
   <w.rf>
    <LM>w#w-588-590</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-591">
  <m id="m140-d1t572-12">
   <w.rf>
    <LM>w#w-d1t572-12</LM>
   </w.rf>
   <form>Mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m140-d1t572-11">
   <w.rf>
    <LM>w#w-d1t572-11</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m140-d1t572-13">
   <w.rf>
    <LM>w#w-d1t572-13</LM>
   </w.rf>
   <form>dojem</form>
   <lemma>dojem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m140-d-id77044-punct">
   <w.rf>
    <LM>w#w-d-id77044-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t572-15">
   <w.rf>
    <LM>w#w-d1t572-15</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m140-d1t572-16">
   <w.rf>
    <LM>w#w-d1t572-16</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m140-d1t572-17">
   <w.rf>
    <LM>w#w-d1t572-17</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t572-18">
   <w.rf>
    <LM>w#w-d1t572-18</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m140-d1t572-19">
   <w.rf>
    <LM>w#w-d1t572-19</LM>
   </w.rf>
   <form>sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d-m-d1e561-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e561-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e580-x2">
  <m id="m140-d1t583-1">
   <w.rf>
    <LM>w#w-d1t583-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m140-d1t583-2">
   <w.rf>
    <LM>w#w-d1t583-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t583-3">
   <w.rf>
    <LM>w#w-d1t583-3</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m140-d-id77230-punct">
   <w.rf>
    <LM>w#w-d-id77230-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-d1e584-x2">
  <m id="m140-d1t598-1">
   <w.rf>
    <LM>w#w-d1t598-1</LM>
   </w.rf>
   <form>Sestra</form>
   <lemma>sestra</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m140-d1t598-2">
   <w.rf>
    <LM>w#w-d1t598-2</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m140-d1t598-3">
   <w.rf>
    <LM>w#w-d1t598-3</LM>
   </w.rf>
   <form>motorku</form>
   <lemma>motorka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m140-d1e584-x2-636">
   <w.rf>
    <LM>w#w-d1e584-x2-636</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m140-d1t598-4">
   <w.rf>
    <LM>w#w-d1t598-4</LM>
   </w.rf>
   <form>skůtra</form>
   <lemma>skůtr_,i_^(^DS**skútr)</lemma>
   <tag>NNIS4-----A---1</tag>
  </m>
  <m id="m140-d1e584-x2-634">
   <w.rf>
    <LM>w#w-d1e584-x2-634</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-635">
  <m id="m140-d1t600-1">
   <w.rf>
    <LM>w#w-d1t600-1</LM>
   </w.rf>
   <form>Dělali</form>
   <lemma>dělat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m140-d1t600-2">
   <w.rf>
    <LM>w#w-d1t600-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m140-d1t600-5">
   <w.rf>
    <LM>w#w-d1t600-5</LM>
   </w.rf>
   <form>výlety</form>
   <lemma>výlet</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m140-d1t600-3">
   <w.rf>
    <LM>w#w-d1t600-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t600-4">
   <w.rf>
    <LM>w#w-d1t600-4</LM>
   </w.rf>
   <form>motorce</form>
   <lemma>motorka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m140-d1t600-6">
   <w.rf>
    <LM>w#w-d1t600-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m140-d1t600-7">
   <w.rf>
    <LM>w#w-d1t600-7</LM>
   </w.rf>
   <form>celých</form>
   <lemma>celý</lemma>
   <tag>AAFP6----1A----</tag>
  </m>
  <m id="m140-d1t600-9">
   <w.rf>
    <LM>w#w-d1t600-9</LM>
   </w.rf>
   <form>Čechách</form>
   <lemma>Čechy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m140-635-637">
   <w.rf>
    <LM>w#w-635-637</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m140-638">
  <m id="m140-d1t602-1">
   <w.rf>
    <LM>w#w-d1t602-1</LM>
   </w.rf>
   <form>Dolejší</form>
   <lemma>dolejší</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m140-d1t602-2">
   <w.rf>
    <LM>w#w-d1t602-2</LM>
   </w.rf>
   <form>záběr</form>
   <lemma>záběr</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m140-d1t602-3">
   <w.rf>
    <LM>w#w-d1t602-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m140-d1t602-4">
   <w.rf>
    <LM>w#w-d1t602-4</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m140-d1t602-6">
   <w.rf>
    <LM>w#w-d1t602-6</LM>
   </w.rf>
   <form>Slovenska</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m140-d1t602-14">
   <w.rf>
    <LM>w#w-d1t602-14</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m140-d1t602-16">
   <w.rf>
    <LM>w#w-d1t602-16</LM>
   </w.rf>
   <form>Malé</form>
   <lemma>malý</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m140-d1t602-17">
   <w.rf>
    <LM>w#w-d1t602-17</LM>
   </w.rf>
   <form>Fatry</form>
   <lemma>Fatra_;G_;Y_;m</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m140-638-639">
   <w.rf>
    <LM>w#w-638-639</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
