<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_059.07.w.gz" />
  </references>
 </head>
 <s id="m059-460">
  <m id="m059-d1t3845-1">
   <w.rf>
    <LM>w#w-d1t3845-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d1t3845-2">
   <w.rf>
    <LM>w#w-d1t3845-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m059-d1t3850-1">
   <w.rf>
    <LM>w#w-d1t3850-1</LM>
   </w.rf>
   <form>včelař</form>
   <lemma>včelař</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m059-460-461">
   <w.rf>
    <LM>w#w-460-461</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3850-2">
   <w.rf>
    <LM>w#w-d1t3850-2</LM>
   </w.rf>
   <form>můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m059-d1t3850-3">
   <w.rf>
    <LM>w#w-d1t3850-3</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m059-460-462">
   <w.rf>
    <LM>w#w-460-462</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3850-4">
   <w.rf>
    <LM>w#w-d1t3850-4</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m059-d1t3850-5">
   <w.rf>
    <LM>w#w-d1t3850-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m059-d1t3850-6">
   <w.rf>
    <LM>w#w-d1t3850-6</LM>
   </w.rf>
   <form>evropské</form>
   <lemma>evropský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m059-d1t3850-7">
   <w.rf>
    <LM>w#w-d1t3850-7</LM>
   </w.rf>
   <form>úrovni</form>
   <lemma>úroveň</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m059-460-468">
   <w.rf>
    <LM>w#w-460-468</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3858-1">
   <w.rf>
    <LM>w#w-d1t3858-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m059-d1t3858-2">
   <w.rf>
    <LM>w#w-d1t3858-2</LM>
   </w.rf>
   <form>jezdí</form>
   <lemma>jezdit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d1t3858-3">
   <w.rf>
    <LM>w#w-d1t3858-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3858-4">
   <w.rf>
    <LM>w#w-d1t3858-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t3858-5">
   <w.rf>
    <LM>w#w-d1t3858-5</LM>
   </w.rf>
   <form>různá</form>
   <lemma>různý</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m059-d1t3858-6">
   <w.rf>
    <LM>w#w-d1t3858-6</LM>
   </w.rf>
   <form>sympozia</form>
   <lemma>sympozium</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m059-d1t3869-1">
   <w.rf>
    <LM>w#w-d1t3869-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3880-3">
   <w.rf>
    <LM>w#w-d1t3880-3</LM>
   </w.rf>
   <form>med</form>
   <lemma>med</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m059-d1t3880-1">
   <w.rf>
    <LM>w#w-d1t3880-1</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m059-d1t3880-2">
   <w.rf>
    <LM>w#w-d1t3880-2</LM>
   </w.rf>
   <form>namíchal</form>
   <lemma>namíchat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m059-d1t3875-1">
   <w.rf>
    <LM>w#w-d1t3875-1</LM>
   </w.rf>
   <form>pomalu</form>
   <lemma>pomalu</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m059-d1t3880-4">
   <w.rf>
    <LM>w#w-d1t3880-4</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3880-5">
   <w.rf>
    <LM>w#w-d1t3880-5</LM>
   </w.rf>
   <form>proti</form>
   <lemma>proti-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m059-d1t3880-6">
   <w.rf>
    <LM>w#w-d1t3880-6</LM>
   </w.rf>
   <form>bolení</form>
   <lemma>bolení_^(*2t)</lemma>
   <tag>NNNS3-----A----</tag>
  </m>
  <m id="m059-d1t3880-8">
   <w.rf>
    <LM>w#w-d1t3880-8</LM>
   </w.rf>
   <form>zubů</form>
   <lemma>zub</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m059-d-m-d1e3866-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3866-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3881-x2">
  <m id="m059-d1t3897-8">
   <w.rf>
    <LM>w#w-d1t3897-8</LM>
   </w.rf>
   <form>Franta</form>
   <lemma>Franta_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m059-d1t3897-10">
   <w.rf>
    <LM>w#w-d1t3897-10</LM>
   </w.rf>
   <form>namíchá</form>
   <lemma>namíchat</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m059-d1e3881-x2-1092">
   <w.rf>
    <LM>w#w-d1e3881-x2-1092</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3897-1">
   <w.rf>
    <LM>w#w-d1t3897-1</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m059-d1t3897-3">
   <w.rf>
    <LM>w#w-d1t3897-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m059-d1t3897-2">
   <w.rf>
    <LM>w#w-d1t3897-2</LM>
   </w.rf>
   <form>kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m059-d1t3897-4">
   <w.rf>
    <LM>w#w-d1t3897-4</LM>
   </w.rf>
   <form>přeje</form>
   <lemma>přát</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d-m-d1e3881-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3881-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3910-x2">
  <m id="m059-d1t3913-1">
   <w.rf>
    <LM>w#w-d1t3913-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m059-d1t3913-2">
   <w.rf>
    <LM>w#w-d1t3913-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d1t3913-3">
   <w.rf>
    <LM>w#w-d1t3913-3</LM>
   </w.rf>
   <form>docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t3913-4">
   <w.rf>
    <LM>w#w-d1t3913-4</LM>
   </w.rf>
   <form>legrace</form>
   <lemma>legrace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m059-d-m-d1e3910-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3910-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3914-x3">
  <m id="m059-d1t3923-1">
   <w.rf>
    <LM>w#w-d1t3923-1</LM>
   </w.rf>
   <form>Vzpomenete</form>
   <lemma>vzpomenout</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m059-d1t3923-2">
   <w.rf>
    <LM>w#w-d1t3923-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m059-d1t3923-3">
   <w.rf>
    <LM>w#w-d1t3923-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t3923-4">
   <w.rf>
    <LM>w#w-d1t3923-4</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m059-d1t3923-5">
   <w.rf>
    <LM>w#w-d1t3923-5</LM>
   </w.rf>
   <form>zvláštní</form>
   <lemma>zvláštní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m059-d1t3923-6">
   <w.rf>
    <LM>w#w-d1t3923-6</LM>
   </w.rf>
   <form>zážitek</form>
   <lemma>zážitek</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m059-d1t3923-7">
   <w.rf>
    <LM>w#w-d1t3923-7</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m059-d1t3923-8">
   <w.rf>
    <LM>w#w-d1t3923-8</LM>
   </w.rf>
   <form>školních</form>
   <lemma>školní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m059-d1t3923-9">
   <w.rf>
    <LM>w#w-d1t3923-9</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m059-d-id144164-punct">
   <w.rf>
    <LM>w#w-d-id144164-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3924-x2">
  <m id="m059-d1t3931-1">
   <w.rf>
    <LM>w#w-d1t3931-1</LM>
   </w.rf>
   <form>Ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m059-d1t3931-2">
   <w.rf>
    <LM>w#w-d1t3931-2</LM>
   </w.rf>
   <form>školních</form>
   <lemma>školní</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m059-d1t3931-3">
   <w.rf>
    <LM>w#w-d1t3931-3</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m059-d1t3933-1">
   <w.rf>
    <LM>w#w-d1t3933-1</LM>
   </w.rf>
   <form>nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m059-d1e3924-x2-523">
   <w.rf>
    <LM>w#w-d1e3924-x2-523</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m059-d1e3924-x2-524">
   <w.rf>
    <LM>w#w-d1e3924-x2-524</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1e3924-x2-525">
   <w.rf>
    <LM>w#w-d1e3924-x2-525</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m059-d1t3938-2">
   <w.rf>
    <LM>w#w-d1t3938-2</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m059-d1t3940-4">
   <w.rf>
    <LM>w#w-d1t3940-4</LM>
   </w.rf>
   <form>vybočovalo</form>
   <lemma>vybočovat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m059-d1e3924-x2-526">
   <w.rf>
    <LM>w#w-d1e3924-x2-526</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-527">
  <m id="m059-d1t3946-1">
   <w.rf>
    <LM>w#w-d1t3946-1</LM>
   </w.rf>
   <form>Zážitky</form>
   <lemma>zážitek</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m059-d1t3946-2">
   <w.rf>
    <LM>w#w-d1t3946-2</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m059-d1t3946-3">
   <w.rf>
    <LM>w#w-d1t3946-3</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP1----1A----</tag>
  </m>
  <m id="m059-d-id144584-punct">
   <w.rf>
    <LM>w#w-d-id144584-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3946-4">
   <w.rf>
    <LM>w#w-d1t3946-4</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-527-528">
   <w.rf>
    <LM>w#w-527-528</LM>
   </w.rf>
   <form>nic</form>
   <lemma>nic</lemma>
   <tag>PY--4----------</tag>
  </m>
  <m id="m059-d1t3946-9">
   <w.rf>
    <LM>w#w-d1t3946-9</LM>
   </w.rf>
   <form>extrémního</form>
   <lemma>extrémní</lemma>
   <tag>AANS2----1A----</tag>
  </m>
  <m id="m059-d1t3951-2">
   <w.rf>
    <LM>w#w-d1t3951-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m059-d1t3951-1">
   <w.rf>
    <LM>w#w-d1t3951-1</LM>
   </w.rf>
   <form>neuvědomuju</form>
   <lemma>uvědomovat</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m059-d-m-d1e3924-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3924-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3953-x2">
  <m id="m059-d1t3960-1">
   <w.rf>
    <LM>w#w-d1t3960-1</LM>
   </w.rf>
   <form>Vídáte</form>
   <lemma>vídat</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m059-d1t3960-2">
   <w.rf>
    <LM>w#w-d1t3960-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t3960-3">
   <w.rf>
    <LM>w#w-d1t3960-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m059-d1t3960-4">
   <w.rf>
    <LM>w#w-d1t3960-4</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m059-d1t3960-5">
   <w.rf>
    <LM>w#w-d1t3960-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3960-6">
   <w.rf>
    <LM>w#w-d1t3960-6</LM>
   </w.rf>
   <form>mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t3960-7">
   <w.rf>
    <LM>w#w-d1t3960-7</LM>
   </w.rf>
   <form>srazy</form>
   <lemma>sraz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m059-d-id144889-punct">
   <w.rf>
    <LM>w#w-d-id144889-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3961-x2">
  <m id="m059-d1t3968-1">
   <w.rf>
    <LM>w#w-d1t3968-1</LM>
   </w.rf>
   <form>Mimo</form>
   <lemma>mimo-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t3968-2">
   <w.rf>
    <LM>w#w-d1t3968-2</LM>
   </w.rf>
   <form>srazy</form>
   <lemma>sraz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m059-d1t3972-1">
   <w.rf>
    <LM>w#w-d1t3972-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t3972-2">
   <w.rf>
    <LM>w#w-d1t3972-2</LM>
   </w.rf>
   <form>vídáváme</form>
   <lemma>vídávat_^(*4at)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d1t3977-1">
   <w.rf>
    <LM>w#w-d1t3977-1</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-2_^(například)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d1t3977-2">
   <w.rf>
    <LM>w#w-d1t3977-2</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1e3961-x2-550">
   <w.rf>
    <LM>w#w-d1e3961-x2-550</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m059-d1t3977-4">
   <w.rf>
    <LM>w#w-d1t3977-4</LM>
   </w.rf>
   <form>Vaškem</form>
   <lemma>Vašek_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m059-d1t3977-5">
   <w.rf>
    <LM>w#w-d1t3977-5</LM>
   </w.rf>
   <form>Bláhou</form>
   <lemma>Bláha_;Y</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m059-d-m-d1e3961-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3961-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3978-x2">
  <m id="m059-d1t3983-4">
   <w.rf>
    <LM>w#w-d1t3983-4</LM>
   </w.rf>
   <form>Pracuje</form>
   <lemma>pracovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d1t3983-5">
   <w.rf>
    <LM>w#w-d1t3983-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t3983-6">
   <w.rf>
    <LM>w#w-d1t3983-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m059-d1t3983-8">
   <w.rf>
    <LM>w#w-d1t3983-8</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m059-d-id145328-punct">
   <w.rf>
    <LM>w#w-d-id145328-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3983-11">
   <w.rf>
    <LM>w#w-d1t3983-11</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m059-d1t3983-14">
   <w.rf>
    <LM>w#w-d1t3983-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t3985-1">
   <w.rf>
    <LM>w#w-d1t3985-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m059-d1t3985-2">
   <w.rf>
    <LM>w#w-d1t3985-2</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m059-d1t3985-4">
   <w.rf>
    <LM>w#w-d1t3985-4</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d-m-d1e3978-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3978-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e3990-x2">
  <m id="m059-d1t3995-3">
   <w.rf>
    <LM>w#w-d1t3995-3</LM>
   </w.rf>
   <form>Pokud</form>
   <lemma>pokud</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m059-d1t3995-4">
   <w.rf>
    <LM>w#w-d1t3995-4</LM>
   </w.rf>
   <form>zajedeme</form>
   <lemma>zajet_^(např._autem)</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m059-d1t3997-5">
   <w.rf>
    <LM>w#w-d1t3997-5</LM>
   </w.rf>
   <form>občas</form>
   <lemma>občas</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t3997-1">
   <w.rf>
    <LM>w#w-d1t3997-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m059-d1t3997-3">
   <w.rf>
    <LM>w#w-d1t3997-3</LM>
   </w.rf>
   <form>Horažďovic</form>
   <lemma>Horažďovice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m059-d-id145685-punct">
   <w.rf>
    <LM>w#w-d-id145685-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t3997-7">
   <w.rf>
    <LM>w#w-d1t3997-7</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3997-9">
   <w.rf>
    <LM>w#w-d1t3997-9</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t3997-8">
   <w.rf>
    <LM>w#w-d1t3997-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t3997-10">
   <w.rf>
    <LM>w#w-d1t3997-10</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t3997-11">
   <w.rf>
    <LM>w#w-d1t3997-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m059-d1t3997-12">
   <w.rf>
    <LM>w#w-d1t3997-12</LM>
   </w.rf>
   <form>některými</form>
   <lemma>některý</lemma>
   <tag>PZXP7----------</tag>
  </m>
  <m id="m059-d1t3997-13">
   <w.rf>
    <LM>w#w-d1t3997-13</LM>
   </w.rf>
   <form>setkám</form>
   <lemma>setkat</lemma>
   <tag>VB-S---1P-AAP--</tag>
  </m>
  <m id="m059-d1t3997-14">
   <w.rf>
    <LM>w#w-d1t3997-14</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t3997-15">
   <w.rf>
    <LM>w#w-d1t3997-15</LM>
   </w.rf>
   <form>vidím</form>
   <lemma>vidět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m059-d-m-d1e3990-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e3990-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4000-x2">
  <m id="m059-d1t4003-1">
   <w.rf>
    <LM>w#w-d1t4003-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4003-8">
   <w.rf>
    <LM>w#w-d1t4003-8</LM>
   </w.rf>
   <form>míváte</form>
   <lemma>mívat_^(*3t)</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m059-d1t4003-7">
   <w.rf>
    <LM>w#w-d1t4003-7</LM>
   </w.rf>
   <form>srazy</form>
   <lemma>sraz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m059-d-id145971-punct">
   <w.rf>
    <LM>w#w-d-id145971-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4000-x3">
  <m id="m059-d1t4005-1">
   <w.rf>
    <LM>w#w-d1t4005-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m059-d1t4005-2">
   <w.rf>
    <LM>w#w-d1t4005-2</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFS6----------</tag>
  </m>
  <m id="m059-d1t4005-3">
   <w.rf>
    <LM>w#w-d1t4005-3</LM>
   </w.rf>
   <form>restauraci</form>
   <lemma>restaurace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m059-d-id146035-punct">
   <w.rf>
    <LM>w#w-d-id146035-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4006-x2">
  <m id="m059-d1t4009-6">
   <w.rf>
    <LM>w#w-d1t4009-6</LM>
   </w.rf>
   <form>Míváme</form>
   <lemma>mívat_^(*3t)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d1t4009-5">
   <w.rf>
    <LM>w#w-d1t4009-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m059-d1t4009-7">
   <w.rf>
    <LM>w#w-d1t4009-7</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4013-3">
   <w.rf>
    <LM>w#w-d1t4013-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m059-d1t4013-5">
   <w.rf>
    <LM>w#w-d1t4013-5</LM>
   </w.rf>
   <form>Horažďovicích</form>
   <lemma>Horažďovice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m059-d1t4013-1">
   <w.rf>
    <LM>w#w-d1t4013-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m059-d1t4013-2">
   <w.rf>
    <LM>w#w-d1t4013-2</LM>
   </w.rf>
   <form>zámku</form>
   <lemma>zámek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m059-d1e4006-x2-602">
   <w.rf>
    <LM>w#w-d1e4006-x2-602</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-604">
  <m id="m059-d1t4017-2">
   <w.rf>
    <LM>w#w-d1t4017-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m059-d1t4017-3">
   <w.rf>
    <LM>w#w-d1t4017-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m059-d1t4017-5">
   <w.rf>
    <LM>w#w-d1t4017-5</LM>
   </w.rf>
   <form>pizzerie</form>
   <lemma>pizzerie</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m059-d1t4024-1">
   <w.rf>
    <LM>w#w-d1t4024-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m059-d1t4026-3">
   <w.rf>
    <LM>w#w-d1t4026-3</LM>
   </w.rf>
   <form>srazy</form>
   <lemma>sraz</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m059-d1t4024-4">
   <w.rf>
    <LM>w#w-d1t4024-4</LM>
   </w.rf>
   <form>míváme</form>
   <lemma>mívat_^(*3t)</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d1t4026-1">
   <w.rf>
    <LM>w#w-d1t4026-1</LM>
   </w.rf>
   <form>většinou</form>
   <lemma>většinou</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4024-3">
   <w.rf>
    <LM>w#w-d1t4024-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d-m-d1e4006-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4006-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4029-x2">
  <m id="m059-d1t4036-1">
   <w.rf>
    <LM>w#w-d1t4036-1</LM>
   </w.rf>
   <form>Rozumím</form>
   <lemma>rozumět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m059-d1e4029-x2-611">
   <w.rf>
    <LM>w#w-d1e4029-x2-611</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-612">
  <m id="m059-d1t4038-1">
   <w.rf>
    <LM>w#w-d1t4038-1</LM>
   </w.rf>
   <form>Chcete</form>
   <lemma>chtít</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m059-d1t4038-2">
   <w.rf>
    <LM>w#w-d1t4038-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m059-d1t4038-3">
   <w.rf>
    <LM>w#w-d1t4038-3</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4038-4">
   <w.rf>
    <LM>w#w-d1t4038-4</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m059-d1t4038-5">
   <w.rf>
    <LM>w#w-d1t4038-5</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m059-d1t4038-6">
   <w.rf>
    <LM>w#w-d1t4038-6</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m059-d1t4038-7">
   <w.rf>
    <LM>w#w-d1t4038-7</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m059-d-id146783-punct">
   <w.rf>
    <LM>w#w-d-id146783-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4039-x2">
  <m id="m059-d1t4042-4">
   <w.rf>
    <LM>w#w-d1t4042-4</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m059-d1t4042-3">
   <w.rf>
    <LM>w#w-d1t4042-3</LM>
   </w.rf>
   <form>by</form>
   <lemma>být</lemma>
   <tag>Vc----------I--</tag>
  </m>
  <m id="m059-d1t4042-2">
   <w.rf>
    <LM>w#w-d1t4042-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m059-d1t4042-5">
   <w.rf>
    <LM>w#w-d1t4042-5</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d1t4042-7">
   <w.rf>
    <LM>w#w-d1t4042-7</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m059-d-m-d1e4039-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4039-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4043-x2">
  <m id="m059-d1t4046-1">
   <w.rf>
    <LM>w#w-d1t4046-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m059-d1e4043-x2-619">
   <w.rf>
    <LM>w#w-d1e4043-x2-619</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-620">
  <m id="m059-d1t4048-1">
   <w.rf>
    <LM>w#w-d1t4048-1</LM>
   </w.rf>
   <form>Bohužel</form>
   <lemma>bohužel</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d1t4048-2">
   <w.rf>
    <LM>w#w-d1t4048-2</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4048-3">
   <w.rf>
    <LM>w#w-d1t4048-3</LM>
   </w.rf>
   <form>musíme</form>
   <lemma>muset</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d1t4048-4">
   <w.rf>
    <LM>w#w-d1t4048-4</LM>
   </w.rf>
   <form>končit</form>
   <lemma>končit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m059-620-621">
   <w.rf>
    <LM>w#w-620-621</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-622">
  <m id="m059-d1t4050-2">
   <w.rf>
    <LM>w#w-d1t4050-2</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m059-d1t4050-3">
   <w.rf>
    <LM>w#w-d1t4050-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m059-d1t4050-4">
   <w.rf>
    <LM>w#w-d1t4050-4</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m059-d1t4050-5">
   <w.rf>
    <LM>w#w-d1t4050-5</LM>
   </w.rf>
   <form>fotka</form>
   <lemma>fotka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m059-d-m-d1e4043-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4043-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4051-x2">
  <m id="m059-d1t4054-1">
   <w.rf>
    <LM>w#w-d1t4054-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d-m-d1e4051-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4051-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4055-x2">
  <m id="m059-d1t4058-1">
   <w.rf>
    <LM>w#w-d1t4058-1</LM>
   </w.rf>
   <form>Děkujeme</form>
   <lemma>děkovat</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m059-d1t4058-2">
   <w.rf>
    <LM>w#w-d1t4058-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m059-d1t4058-3">
   <w.rf>
    <LM>w#w-d1t4058-3</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t4058-4">
   <w.rf>
    <LM>w#w-d1t4058-4</LM>
   </w.rf>
   <form>váš</form>
   <lemma>váš</lemma>
   <tag>PSIS4-P2-------</tag>
  </m>
  <m id="m059-d1t4058-5">
   <w.rf>
    <LM>w#w-d1t4058-5</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m059-d-m-d1e4055-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4055-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4060-x2">
  <m id="m059-d1t4067-1">
   <w.rf>
    <LM>w#w-d1t4067-1</LM>
   </w.rf>
   <form>Rádo</form>
   <lemma>rád-1</lemma>
   <tag>ACNS------A----</tag>
  </m>
  <m id="m059-d1t4067-2">
   <w.rf>
    <LM>w#w-d1t4067-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t4067-3">
   <w.rf>
    <LM>w#w-d1t4067-3</LM>
   </w.rf>
   <form>stalo</form>
   <lemma>stát-2_^(stanu_staneš)</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m059-d-m-d1e4060-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4060-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4060-x3">
  <m id="m059-d1t4069-1">
   <w.rf>
    <LM>w#w-d1t4069-1</LM>
   </w.rf>
   <form>Moc</form>
   <lemma>moc-3_^(moc_hezká,_moc_peněz)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m059-d1t4069-2">
   <w.rf>
    <LM>w#w-d1t4069-2</LM>
   </w.rf>
   <form>hezky</form>
   <lemma>hezky</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m059-d1t4069-3">
   <w.rf>
    <LM>w#w-d1t4069-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m059-d1t4069-4">
   <w.rf>
    <LM>w#w-d1t4069-4</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m059-d1t4069-5">
   <w.rf>
    <LM>w#w-d1t4069-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m059-d1t4069-6">
   <w.rf>
    <LM>w#w-d1t4069-6</LM>
   </w.rf>
   <form>vámi</form>
   <lemma>vy</lemma>
   <tag>PP-P7--2-------</tag>
  </m>
  <m id="m059-d1t4069-7">
   <w.rf>
    <LM>w#w-d1t4069-7</LM>
   </w.rf>
   <form>povídalo</form>
   <lemma>povídat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m059-d-m-d1e4060-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4060-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4070-x2">
  <m id="m059-d1t4075-1">
   <w.rf>
    <LM>w#w-d1t4075-1</LM>
   </w.rf>
   <form>Opravdu</form>
   <lemma>opravdu-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d1e4070-x2-623">
   <w.rf>
    <LM>w#w-d1e4070-x2-623</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4078-x2">
  <m id="m059-d1t4085-1">
   <w.rf>
    <LM>w#w-d1t4085-1</LM>
   </w.rf>
   <form>Počkejte</form>
   <lemma>počkat</lemma>
   <tag>Vi-P---2--A-P--</tag>
  </m>
  <m id="m059-d1t4085-2">
   <w.rf>
    <LM>w#w-d1t4085-2</LM>
   </w.rf>
   <form>chvilku</form>
   <lemma>chvilka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m059-d1e4078-x2-624">
   <w.rf>
    <LM>w#w-d1e4078-x2-624</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t4087-1">
   <w.rf>
    <LM>w#w-d1t4087-1</LM>
   </w.rf>
   <form>kluci</form>
   <lemma>kluk</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m059-d1t4087-2">
   <w.rf>
    <LM>w#w-d1t4087-2</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P4--2-------</tag>
  </m>
  <m id="m059-d1t4087-3">
   <w.rf>
    <LM>w#w-d1t4087-3</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m059-d1t4087-4">
   <w.rf>
    <LM>w#w-d1t4087-4</LM>
   </w.rf>
   <form>vysvobodit</form>
   <lemma>vysvobodit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m059-d-m-d1e4078-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4078-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4088-x2">
  <m id="m059-d1t4091-1">
   <w.rf>
    <LM>w#w-d1t4091-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m059-d1e4088-x2-628">
   <w.rf>
    <LM>w#w-d1e4088-x2-628</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m059-d1t4099-1">
   <w.rf>
    <LM>w#w-d1t4099-1</LM>
   </w.rf>
   <form>děkuju</form>
   <lemma>děkovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m059-d-m-d1e4088-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4088-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-627">
  <m id="m059-d1t4099-3">
   <w.rf>
    <LM>w#w-d1t4099-3</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t4099-4">
   <w.rf>
    <LM>w#w-d1t4099-4</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m059-d-m-d1e4094-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4094-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m059-d1e4094-x3">
  <m id="m059-d1t4101-1">
   <w.rf>
    <LM>w#w-d1t4101-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m059-d1t4101-2">
   <w.rf>
    <LM>w#w-d1t4101-2</LM>
   </w.rf>
   <form>shledanou</form>
   <lemma>shledaná_^(okamžik_shledání;_na_shledanou!)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m059-d-m-d1e4094-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e4094-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
