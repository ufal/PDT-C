<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_006.01.w.gz" />
  </references>
 </head>
 <s id="m006-364">
  <m id="m006-d1t314-12">
   <w.rf>
    <LM>w#w-d1t314-12</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m006-d1t314-10">
   <w.rf>
    <LM>w#w-d1t314-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t314-11">
   <w.rf>
    <LM>w#w-d1t314-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t314-7">
   <w.rf>
    <LM>w#w-d1t314-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m006-d1t314-8">
   <w.rf>
    <LM>w#w-d1t314-8</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m006-d1t314-9">
   <w.rf>
    <LM>w#w-d1t314-9</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m006-d-id64743">
   <w.rf>
    <LM>w#w-d-id64743</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e315-x2">
  <m id="m006-d1t318-1">
   <w.rf>
    <LM>w#w-d1t318-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t318-2">
   <w.rf>
    <LM>w#w-d1t318-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t318-3">
   <w.rf>
    <LM>w#w-d1t318-3</LM>
   </w.rf>
   <form>vlastně</form>
   <lemma>vlastně-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t318-4">
   <w.rf>
    <LM>w#w-d1t318-4</LM>
   </w.rf>
   <form>mluví</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t318-5">
   <w.rf>
    <LM>w#w-d1t318-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t318-7">
   <w.rf>
    <LM>w#w-d1t318-7</LM>
   </w.rf>
   <form>Antverpách</form>
   <lemma>Antverpy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m006-d-id65087">
   <w.rf>
    <LM>w#w-d-id65087</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e319-x2">
  <m id="m006-d1t324-1">
   <w.rf>
    <LM>w#w-d1t324-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t324-3">
   <w.rf>
    <LM>w#w-d1t324-3</LM>
   </w.rf>
   <form>Antverpách</form>
   <lemma>Antverpy_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m006-d1t324-5">
   <w.rf>
    <LM>w#w-d1t324-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t324-6">
   <w.rf>
    <LM>w#w-d1t324-6</LM>
   </w.rf>
   <form>mluví</form>
   <lemma>mluvit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t324-7">
   <w.rf>
    <LM>w#w-d1t324-7</LM>
   </w.rf>
   <form>vlámsky</form>
   <lemma>vlámsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d-id65252">
   <w.rf>
    <LM>w#w-d-id65252</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t324-9">
   <w.rf>
    <LM>w#w-d1t324-9</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t324-10">
   <w.rf>
    <LM>w#w-d1t324-10</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t324-11">
   <w.rf>
    <LM>w#w-d1t324-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t324-12">
   <w.rf>
    <LM>w#w-d1t324-12</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-3</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t324-14">
   <w.rf>
    <LM>w#w-d1t324-14</LM>
   </w.rf>
   <form>Holandska</form>
   <lemma>Holandsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m006-d-id65133">
   <w.rf>
    <LM>w#w-d-id65133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e327-x2">
  <m id="m006-d1t330-1">
   <w.rf>
    <LM>w#w-d1t330-1</LM>
   </w.rf>
   <form>Vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m006-d1t330-2">
   <w.rf>
    <LM>w#w-d1t330-2</LM>
   </w.rf>
   <form>umíte</form>
   <lemma>umět</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m006-d1t330-3">
   <w.rf>
    <LM>w#w-d1t330-3</LM>
   </w.rf>
   <form>vlámsky</form>
   <lemma>vlámsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d-id65458">
   <w.rf>
    <LM>w#w-d-id65458</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e331-x2">
  <m id="m006-d1t336-1">
   <w.rf>
    <LM>w#w-d1t336-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m006-d1t336-2">
   <w.rf>
    <LM>w#w-d1t336-2</LM>
   </w.rf>
   <form>neumím</form>
   <lemma>umět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m006-d1t336-3">
   <w.rf>
    <LM>w#w-d1t336-3</LM>
   </w.rf>
   <form>vlámsky</form>
   <lemma>vlámsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d-id65575">
   <w.rf>
    <LM>w#w-d-id65575</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t336-5">
   <w.rf>
    <LM>w#w-d1t336-5</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t336-6">
   <w.rf>
    <LM>w#w-d1t336-6</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m006-d1t336-7">
   <w.rf>
    <LM>w#w-d1t336-7</LM>
   </w.rf>
   <form>muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m006-d1t336-8">
   <w.rf>
    <LM>w#w-d1t336-8</LM>
   </w.rf>
   <form>uměl</form>
   <lemma>umět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m006-d1t336-9">
   <w.rf>
    <LM>w#w-d1t336-9</LM>
   </w.rf>
   <form>vlámsky</form>
   <lemma>vlámsky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1e331-x2-2376">
   <w.rf>
    <LM>w#w-d1e331-x2-2376</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-2379">
  <m id="m006-d1t338-2">
   <w.rf>
    <LM>w#w-d1t338-2</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t338-3">
   <w.rf>
    <LM>w#w-d1t338-3</LM>
   </w.rf>
   <form>téhleté</form>
   <lemma>tenhleten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m006-d1t338-4">
   <w.rf>
    <LM>w#w-d1t338-4</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m006-d1t338-7">
   <w.rf>
    <LM>w#w-d1t338-7</LM>
   </w.rf>
   <form>moje</form>
   <lemma>můj</lemma>
   <tag>PSHS1-S1-------</tag>
  </m>
  <m id="m006-d1t338-8">
   <w.rf>
    <LM>w#w-d1t338-8</LM>
   </w.rf>
   <form>vnučka</form>
   <lemma>vnučka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m006-d1t338-9">
   <w.rf>
    <LM>w#w-d1t338-9</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t338-10">
   <w.rf>
    <LM>w#w-d1t338-10</LM>
   </w.rf>
   <form>uměla</form>
   <lemma>umět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d1t338-11">
   <w.rf>
    <LM>w#w-d1t338-11</LM>
   </w.rf>
   <form>anglicky</form>
   <lemma>anglicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t338-12">
   <w.rf>
    <LM>w#w-d1t338-12</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t338-13">
   <w.rf>
    <LM>w#w-d1t338-13</LM>
   </w.rf>
   <form>německy</form>
   <lemma>německy_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d-id65868">
   <w.rf>
    <LM>w#w-d-id65868</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t338-15">
   <w.rf>
    <LM>w#w-d1t338-15</LM>
   </w.rf>
   <form>takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t338-16">
   <w.rf>
    <LM>w#w-d1t338-16</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t338-17">
   <w.rf>
    <LM>w#w-d1t338-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t338-19">
   <w.rf>
    <LM>w#w-d1t338-19</LM>
   </w.rf>
   <form>dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t338-18">
   <w.rf>
    <LM>w#w-d1t338-18</LM>
   </w.rf>
   <form>domluvila</form>
   <lemma>domluvit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m006-d1t338-20">
   <w.rf>
    <LM>w#w-d1t338-20</LM>
   </w.rf>
   <form>německy</form>
   <lemma>německy_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t338-21">
   <w.rf>
    <LM>w#w-d1t338-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t338-22">
   <w.rf>
    <LM>w#w-d1t338-22</LM>
   </w.rf>
   <form>anglicky</form>
   <lemma>anglicky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t338-23">
   <w.rf>
    <LM>w#w-d1t338-23</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d-id65504">
   <w.rf>
    <LM>w#w-d-id65504</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e339-x2">
  <m id="m006-d1t342-1">
   <w.rf>
    <LM>w#w-d1t342-1</LM>
   </w.rf>
   <form>Líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m006-d1t342-2">
   <w.rf>
    <LM>w#w-d1t342-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t342-3">
   <w.rf>
    <LM>w#w-d1t342-3</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m006-d1t342-4">
   <w.rf>
    <LM>w#w-d1t342-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t342-6">
   <w.rf>
    <LM>w#w-d1t342-6</LM>
   </w.rf>
   <form>Belgii</form>
   <lemma>Belgie_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m006-d-id66173">
   <w.rf>
    <LM>w#w-d-id66173</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e345-x2">
  <m id="m006-d1t350-2">
   <w.rf>
    <LM>w#w-d1t350-2</LM>
   </w.rf>
   <form>Líbilo</form>
   <lemma>líbit</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m006-d1t350-3">
   <w.rf>
    <LM>w#w-d1t350-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1e345-x2-2491">
   <w.rf>
    <LM>w#w-d1e345-x2-2491</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m006-d1e345-x2-249">
   <w.rf>
    <LM>w#w-d1e345-x2-249</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t350-4">
   <w.rf>
    <LM>w#w-d1t350-4</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d-id66306">
   <w.rf>
    <LM>w#w-d-id66306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t350-8">
   <w.rf>
    <LM>w#w-d1t350-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m006-d1t350-9">
   <w.rf>
    <LM>w#w-d1t350-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t350-10">
   <w.rf>
    <LM>w#w-d1t350-10</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m006-d-id66219">
   <w.rf>
    <LM>w#w-d-id66219</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e353-x2">
  <m id="m006-d1t358-1">
   <w.rf>
    <LM>w#w-d1t358-1</LM>
   </w.rf>
   <form>Hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t358-2">
   <w.rf>
    <LM>w#w-d1t358-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t358-3">
   <w.rf>
    <LM>w#w-d1t358-3</LM>
   </w.rf>
   <form>viděly</form>
   <lemma>vidět</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m006-d-id66435">
   <w.rf>
    <LM>w#w-d-id66435</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e353-x3">
  <m id="m006-d1t360-2">
   <w.rf>
    <LM>w#w-d1t360-2</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d-id66530">
   <w.rf>
    <LM>w#w-d-id66530</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e361-x2">
  <m id="m006-d1t368-2">
   <w.rf>
    <LM>w#w-d1t368-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t368-3">
   <w.rf>
    <LM>w#w-d1t368-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t368-4">
   <w.rf>
    <LM>w#w-d1t368-4</LM>
   </w.rf>
   <form>jiná</form>
   <lemma>jiný</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m006-d1t368-5">
   <w.rf>
    <LM>w#w-d1t368-5</LM>
   </w.rf>
   <form>mentalita</form>
   <lemma>mentalita</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m006-d1t368-6">
   <w.rf>
    <LM>w#w-d1t368-6</LM>
   </w.rf>
   <form>lidí</form>
   <lemma>lidé</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m006-d-id66577">
   <w.rf>
    <LM>w#w-d-id66577</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e371-x2">
  <m id="m006-d1t388-1">
   <w.rf>
    <LM>w#w-d1t388-1</LM>
   </w.rf>
   <form>Rádi</form>
   <lemma>rád-1</lemma>
   <tag>ACMP------A----</tag>
  </m>
  <m id="m006-d1t388-2">
   <w.rf>
    <LM>w#w-d1t388-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t388-4">
   <w.rf>
    <LM>w#w-d1t388-4</LM>
   </w.rf>
   <form>seznamují</form>
   <lemma>seznamovat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m006-d1e383-x2-412">
   <w.rf>
    <LM>w#w-d1e383-x2-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-413">
  <m id="m006-d1t388-8">
   <w.rf>
    <LM>w#w-d1t388-8</LM>
   </w.rf>
   <form>Měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t388-9">
   <w.rf>
    <LM>w#w-d1t388-9</LM>
   </w.rf>
   <form>zájem</form>
   <lemma>zájem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m006-d-id67117">
   <w.rf>
    <LM>w#w-d-id67117</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t390-1">
   <w.rf>
    <LM>w#w-d1t390-1</LM>
   </w.rf>
   <form>chtěli</form>
   <lemma>chtít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t390-7">
   <w.rf>
    <LM>w#w-d1t390-7</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t390-2">
   <w.rf>
    <LM>w#w-d1t390-2</LM>
   </w.rf>
   <form>vyprávět</form>
   <lemma>vyprávět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m006-d1t390-3">
   <w.rf>
    <LM>w#w-d1t390-3</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t390-5">
   <w.rf>
    <LM>w#w-d1t390-5</LM>
   </w.rf>
   <form>Československu</form>
   <lemma>Československo_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m006-d-id67239">
   <w.rf>
    <LM>w#w-d-id67239</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t390-10">
   <w.rf>
    <LM>w#w-d1t390-10</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t390-12">
   <w.rf>
    <LM>w#w-d1t390-12</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m006-d1t390-14">
   <w.rf>
    <LM>w#w-d1t390-14</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t390-15">
   <w.rf>
    <LM>w#w-d1t390-15</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d-id66888">
   <w.rf>
    <LM>w#w-d-id66888</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e392-x2">
  <m id="m006-d1t399-1">
   <w.rf>
    <LM>w#w-d1t399-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t399-2">
   <w.rf>
    <LM>w#w-d1t399-2</LM>
   </w.rf>
   <form>často</form>
   <lemma>často</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t399-3">
   <w.rf>
    <LM>w#w-d1t399-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m006-d1t399-4">
   <w.rf>
    <LM>w#w-d1t399-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t399-5">
   <w.rf>
    <LM>w#w-d1t399-5</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d-id67461">
   <w.rf>
    <LM>w#w-d-id67461</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e400-x2">
  <m id="m006-d1t403-2">
   <w.rf>
    <LM>w#w-d1t403-2</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t403-3">
   <w.rf>
    <LM>w#w-d1t403-3</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m006-d1t403-4">
   <w.rf>
    <LM>w#w-d1t403-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t403-6">
   <w.rf>
    <LM>w#w-d1t403-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t403-7">
   <w.rf>
    <LM>w#w-d1t403-7</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t403-8">
   <w.rf>
    <LM>w#w-d1t403-8</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t403-9">
   <w.rf>
    <LM>w#w-d1t403-9</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t403-10">
   <w.rf>
    <LM>w#w-d1t403-10</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m006-d1t403-11">
   <w.rf>
    <LM>w#w-d1t403-11</LM>
   </w.rf>
   <form>druhý</form>
   <lemma>druhý`2</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m006-d1t403-12">
   <w.rf>
    <LM>w#w-d1t403-12</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m006-d1e400-x2-275">
   <w.rf>
    <LM>w#w-d1e400-x2-275</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-276">
  <m id="m006-d1t403-15">
   <w.rf>
    <LM>w#w-d1t403-15</LM>
   </w.rf>
   <form>Celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t403-16">
   <w.rf>
    <LM>w#w-d1t403-16</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t403-17">
   <w.rf>
    <LM>w#w-d1t403-17</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t403-18">
   <w.rf>
    <LM>w#w-d1t403-18</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-276-277">
   <w.rf>
    <LM>w#w-276-277</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-276-278">
   <w.rf>
    <LM>w#w-276-278</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m006-d1t405-3">
   <w.rf>
    <LM>w#w-d1t405-3</LM>
   </w.rf>
   <form>čtyřikrát</form>
   <lemma>čtyřikrát`4</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m006-d1e400-x2-505">
   <w.rf>
    <LM>w#w-d1e400-x2-505</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t407-1">
   <w.rf>
    <LM>w#w-d1t407-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t407-2">
   <w.rf>
    <LM>w#w-d1t407-2</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-1</lemma>
   <tag>Cv-------------</tag>
  </m>
  <m id="m006-d1t407-3">
   <w.rf>
    <LM>w#w-d1t407-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t407-5">
   <w.rf>
    <LM>w#w-d1t407-5</LM>
   </w.rf>
   <form>vnučkou</form>
   <lemma>vnučka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m006-d1e400-x2-2807">
   <w.rf>
    <LM>w#w-d1e400-x2-2807</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-2810">
  <m id="m006-d1t407-7">
   <w.rf>
    <LM>w#w-d1t407-7</LM>
   </w.rf>
   <form>Od</form>
   <lemma>od-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t407-8">
   <w.rf>
    <LM>w#w-d1t407-8</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m006-d1t407-9">
   <w.rf>
    <LM>w#w-d1t407-9</LM>
   </w.rf>
   <form>doby</form>
   <lemma>doba</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m006-d1t407-10">
   <w.rf>
    <LM>w#w-d1t407-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t407-11">
   <w.rf>
    <LM>w#w-d1t407-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m006-d1t407-12">
   <w.rf>
    <LM>w#w-d1t407-12</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t407-14">
   <w.rf>
    <LM>w#w-d1t407-14</LM>
   </w.rf>
   <form>nejela</form>
   <lemma>jet-1</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m006-d-id67507">
   <w.rf>
    <LM>w#w-d-id67507</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e420-x2">
  <m id="m006-d1t423-1">
   <w.rf>
    <LM>w#w-d1t423-1</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d1t423-2">
   <w.rf>
    <LM>w#w-d1t423-2</LM>
   </w.rf>
   <form>byste</form>
   <lemma>být</lemma>
   <tag>Vc----------Ie-</tag>
  </m>
  <m id="m006-d1t423-4">
   <w.rf>
    <LM>w#w-d1t423-4</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m006-d1t423-5">
   <w.rf>
    <LM>w#w-d1t423-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS3----------</tag>
  </m>
  <m id="m006-d1t423-6">
   <w.rf>
    <LM>w#w-d1t423-6</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m006-d1t423-7">
   <w.rf>
    <LM>w#w-d1t423-7</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t423-8">
   <w.rf>
    <LM>w#w-d1t423-8</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m006-d1t423-9">
   <w.rf>
    <LM>w#w-d1t423-9</LM>
   </w.rf>
   <form>dodat</form>
   <lemma>dodat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m006-d-id68372">
   <w.rf>
    <LM>w#w-d-id68372</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e424-x2">
  <m id="m006-d1t427-2">
   <w.rf>
    <LM>w#w-d1t427-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t427-3">
   <w.rf>
    <LM>w#w-d1t427-3</LM>
   </w.rf>
   <form>již</form>
   <lemma>již-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t427-4">
   <w.rf>
    <LM>w#w-d1t427-4</LM>
   </w.rf>
   <form>stačí</form>
   <lemma>stačit</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d-id68418">
   <w.rf>
    <LM>w#w-d-id68418</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e428-x2">
  <m id="m006-d1t431-1">
   <w.rf>
    <LM>w#w-d1t431-1</LM>
   </w.rf>
   <form>Dobře</form>
   <lemma>dobře</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d-id68566">
   <w.rf>
    <LM>w#w-d-id68566</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e432-x2">
  <m id="m006-d1t427-7">
   <w.rf>
    <LM>w#w-d1t427-7</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t437-1">
   <w.rf>
    <LM>w#w-d1t437-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m006-d1t437-2">
   <w.rf>
    <LM>w#w-d1t437-2</LM>
   </w.rf>
   <form>vyčerpala</form>
   <lemma>vyčerpat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m006-d1t437-3">
   <w.rf>
    <LM>w#w-d1t437-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t437-4">
   <w.rf>
    <LM>w#w-d1t437-4</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m006-d1e432-x2-285">
   <w.rf>
    <LM>w#w-d1e432-x2-285</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e432-x3">
  <m id="m006-d1t441-2">
   <w.rf>
    <LM>w#w-d1t441-2</LM>
   </w.rf>
   <form>Přejdeme</form>
   <lemma>přejít</lemma>
   <tag>VB-P---1P-AAP--</tag>
  </m>
  <m id="m006-d1t441-3">
   <w.rf>
    <LM>w#w-d1t441-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m006-d1t441-4">
   <w.rf>
    <LM>w#w-d1t441-4</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m006-d1t441-5">
   <w.rf>
    <LM>w#w-d1t441-5</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m006-d-id68757">
   <w.rf>
    <LM>w#w-d-id68757</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-292">
  <m id="m006-d1t439-1">
   <w.rf>
    <LM>w#w-d1t439-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-292-293">
   <w.rf>
    <LM>w#w-292-293</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e442-x2">
  <m id="m006-d1t445-1">
   <w.rf>
    <LM>w#w-d1t445-1</LM>
   </w.rf>
   <form>Copak</form>
   <lemma>copak-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m006-d1t445-2">
   <w.rf>
    <LM>w#w-d1t445-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t445-3">
   <w.rf>
    <LM>w#w-d1t445-3</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m006-d1t445-4">
   <w.rf>
    <LM>w#w-d1t445-4</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d-id68929">
   <w.rf>
    <LM>w#w-d-id68929</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e446-x2">
  <m id="m006-d1t453-1">
   <w.rf>
    <LM>w#w-d1t453-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t453-2">
   <w.rf>
    <LM>w#w-d1t453-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t453-3">
   <w.rf>
    <LM>w#w-d1t453-3</LM>
   </w.rf>
   <form>rodinný</form>
   <lemma>rodinný</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m006-d1t453-4">
   <w.rf>
    <LM>w#w-d1t453-4</LM>
   </w.rf>
   <form>dům</form>
   <lemma>dům</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m006-d1t453-6">
   <w.rf>
    <LM>w#w-d1t453-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t453-7">
   <w.rf>
    <LM>w#w-d1t453-7</LM>
   </w.rf>
   <form>čáp</form>
   <lemma>čáp</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m006-d1t453-11">
   <w.rf>
    <LM>w#w-d1t453-11</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t453-12">
   <w.rf>
    <LM>w#w-d1t453-12</LM>
   </w.rf>
   <form>domem</form>
   <lemma>dům</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m006-d-id69181">
   <w.rf>
    <LM>w#w-d-id69181</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t455-1">
   <w.rf>
    <LM>w#w-d1t455-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t455-2">
   <w.rf>
    <LM>w#w-d1t455-2</LM>
   </w.rf>
   <form>očekávají</form>
   <lemma>očekávat</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m006-d1t455-3">
   <w.rf>
    <LM>w#w-d1t455-3</LM>
   </w.rf>
   <form>děťátko</form>
   <lemma>děťátko</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m006-d1e446-x2-3259">
   <w.rf>
    <LM>w#w-d1e446-x2-3259</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-3260">
  <m id="m006-d1t460-1">
   <w.rf>
    <LM>w#w-d1t460-1</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t460-2">
   <w.rf>
    <LM>w#w-d1t460-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t460-3">
   <w.rf>
    <LM>w#w-d1t460-3</LM>
   </w.rf>
   <form>narodí</form>
   <lemma>narodit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m006-d1t460-4">
   <w.rf>
    <LM>w#w-d1t460-4</LM>
   </w.rf>
   <form>brzo</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A---1</tag>
  </m>
  <m id="m006-d1t460-5">
   <w.rf>
    <LM>w#w-d1t460-5</LM>
   </w.rf>
   <form>děťátko</form>
   <lemma>děťátko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m006-3260-3270">
   <w.rf>
    <LM>w#w-3260-3270</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-3273">
  <m id="m006-d1t460-7">
   <w.rf>
    <LM>w#w-d1t460-7</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-3273-305">
   <w.rf>
    <LM>w#w-3273-305</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t460-8">
   <w.rf>
    <LM>w#w-d1t460-8</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t460-9">
   <w.rf>
    <LM>w#w-d1t460-9</LM>
   </w.rf>
   <form>přijde</form>
   <lemma>přijít</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m006-d1t460-10">
   <w.rf>
    <LM>w#w-d1t460-10</LM>
   </w.rf>
   <form>žena</form>
   <lemma>žena</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m006-d1t460-11">
   <w.rf>
    <LM>w#w-d1t460-11</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t460-12">
   <w.rf>
    <LM>w#w-d1t460-12</LM>
   </w.rf>
   <form>jiného</form>
   <lemma>jiný</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m006-d1t460-13">
   <w.rf>
    <LM>w#w-d1t460-13</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m006-d-id69480">
   <w.rf>
    <LM>w#w-d-id69480</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t460-16">
   <w.rf>
    <LM>w#w-d1t460-16</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t460-17">
   <w.rf>
    <LM>w#w-d1t460-17</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t462-2">
   <w.rf>
    <LM>w#w-d1t462-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t462-3">
   <w.rf>
    <LM>w#w-d1t462-3</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P1----------</tag>
  </m>
  <m id="m006-d1t462-4">
   <w.rf>
    <LM>w#w-d1t462-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t462-5">
   <w.rf>
    <LM>w#w-d1t462-5</LM>
   </w.rf>
   <form>pět</form>
   <lemma>pět-1`5</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m006-d1t462-6">
   <w.rf>
    <LM>w#w-d1t462-6</LM>
   </w.rf>
   <form>měsíců</form>
   <lemma>měsíc</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m006-d1t462-7">
   <w.rf>
    <LM>w#w-d1t462-7</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t462-8">
   <w.rf>
    <LM>w#w-d1t462-8</LM>
   </w.rf>
   <form>jiném</form>
   <lemma>jiný</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m006-d1t462-9">
   <w.rf>
    <LM>w#w-d1t462-9</LM>
   </w.rf>
   <form>stavu</form>
   <lemma>stav</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m006-d-id69662">
   <w.rf>
    <LM>w#w-d-id69662</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t464-2">
   <w.rf>
    <LM>w#w-d1t464-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m006-d1t464-3">
   <w.rf>
    <LM>w#w-d1t464-3</LM>
   </w.rf>
   <form>dají</form>
   <lemma>dát-1</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m006-d1t464-4">
   <w.rf>
    <LM>w#w-d1t464-4</LM>
   </w.rf>
   <form>buďto</form>
   <lemma>buďto</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t466-1">
   <w.rf>
    <LM>w#w-d1t466-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t466-4">
   <w.rf>
    <LM>w#w-d1t466-4</LM>
   </w.rf>
   <form>předzahrádky</form>
   <lemma>předzahrádka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m006-d1t466-8">
   <w.rf>
    <LM>w#w-d1t466-8</LM>
   </w.rf>
   <form>sošku</form>
   <lemma>soška</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m006-d1t466-6">
   <w.rf>
    <LM>w#w-d1t466-6</LM>
   </w.rf>
   <form>čápa</form>
   <lemma>čáp</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m006-d1t468-2">
   <w.rf>
    <LM>w#w-d1t468-2</LM>
   </w.rf>
   <form>anebo</form>
   <lemma>anebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t468-3">
   <w.rf>
    <LM>w#w-d1t468-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m006-d1t468-4">
   <w.rf>
    <LM>w#w-d1t468-4</LM>
   </w.rf>
   <form>vylepí</form>
   <lemma>vylepit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m006-d1t470-2">
   <w.rf>
    <LM>w#w-d1t470-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t470-3">
   <w.rf>
    <LM>w#w-d1t470-3</LM>
   </w.rf>
   <form>okna</form>
   <lemma>okno</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m006-d1t470-1">
   <w.rf>
    <LM>w#w-d1t470-1</LM>
   </w.rf>
   <form>čápa</form>
   <lemma>čáp</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m006-d1t468-5">
   <w.rf>
    <LM>w#w-d1t468-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t468-6">
   <w.rf>
    <LM>w#w-d1t468-6</LM>
   </w.rf>
   <form>papíru</form>
   <lemma>papír</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m006-3273-3287">
   <w.rf>
    <LM>w#w-3273-3287</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e446-x3">
  <m id="m006-d1t470-5">
   <w.rf>
    <LM>w#w-d1t470-5</LM>
   </w.rf>
   <form>Aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t470-6">
   <w.rf>
    <LM>w#w-d1t470-6</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m006-d1t470-7">
   <w.rf>
    <LM>w#w-d1t470-7</LM>
   </w.rf>
   <form>viděl</form>
   <lemma>vidět</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m006-d-id70091">
   <w.rf>
    <LM>w#w-d-id70091</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t470-9">
   <w.rf>
    <LM>w#w-d1t470-9</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m006-d1t470-10">
   <w.rf>
    <LM>w#w-d1t470-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t470-11">
   <w.rf>
    <LM>w#w-d1t470-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t470-12">
   <w.rf>
    <LM>w#w-d1t470-12</LM>
   </w.rf>
   <form>narodí</form>
   <lemma>narodit</lemma>
   <tag>VB-S---3P-AAP--</tag>
  </m>
  <m id="m006-d1t470-13">
   <w.rf>
    <LM>w#w-d1t470-13</LM>
   </w.rf>
   <form>děťátko</form>
   <lemma>děťátko</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m006-d-id70218">
   <w.rf>
    <LM>w#w-d-id70218</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e471-x3">
  <m id="m006-d1t478-1">
   <w.rf>
    <LM>w#w-d1t478-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t478-2">
   <w.rf>
    <LM>w#w-d1t478-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t478-3">
   <w.rf>
    <LM>w#w-d1t478-3</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m006-d1t478-4">
   <w.rf>
    <LM>w#w-d1t478-4</LM>
   </w.rf>
   <form>zvyk</form>
   <lemma>zvyk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m006-d-id70307">
   <w.rf>
    <LM>w#w-d-id70307</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e480-x2">
  <m id="m006-d1t485-1">
   <w.rf>
    <LM>w#w-d1t485-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t485-2">
   <w.rf>
    <LM>w#w-d1t485-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t485-3">
   <w.rf>
    <LM>w#w-d1t485-3</LM>
   </w.rf>
   <form>zvyk</form>
   <lemma>zvyk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m006-d-id70417">
   <w.rf>
    <LM>w#w-d-id70417</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t487-5">
   <w.rf>
    <LM>w#w-d1t487-5</LM>
   </w.rf>
   <form>chlubí</form>
   <lemma>chlubit</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m006-d1t487-2">
   <w.rf>
    <LM>w#w-d1t487-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t487-4">
   <w.rf>
    <LM>w#w-d1t487-4</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m006-d-id70353">
   <w.rf>
    <LM>w#w-d-id70353</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e490-x2">
  <m id="m006-d1t493-1">
   <w.rf>
    <LM>w#w-d1t493-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t493-2">
   <w.rf>
    <LM>w#w-d1t493-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t493-3">
   <w.rf>
    <LM>w#w-d1t493-3</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m006-d1e490-x2-3589">
   <w.rf>
    <LM>w#w-d1e490-x2-3589</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e494-x2">
  <m id="m006-d1t499-1">
   <w.rf>
    <LM>w#w-d1t499-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1e494-x2-572">
   <w.rf>
    <LM>w#w-d1e494-x2-572</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t499-2">
   <w.rf>
    <LM>w#w-d1t499-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t499-3">
   <w.rf>
    <LM>w#w-d1t499-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t499-4">
   <w.rf>
    <LM>w#w-d1t499-4</LM>
   </w.rf>
   <form>hezké</form>
   <lemma>hezký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m006-d-id70749">
   <w.rf>
    <LM>w#w-d-id70749</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e494-x3">
  <m id="m006-d1t503-1">
   <w.rf>
    <LM>w#w-d1t503-1</LM>
   </w.rf>
   <form>Ty</form>
   <lemma>ten</lemma>
   <tag>PDMP4----------</tag>
  </m>
  <m id="m006-d1t503-2">
   <w.rf>
    <LM>w#w-d1t503-2</LM>
   </w.rf>
   <form>čápy</form>
   <lemma>čáp</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m006-d1t503-3">
   <w.rf>
    <LM>w#w-d1t503-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t503-4">
   <w.rf>
    <LM>w#w-d1t503-4</LM>
   </w.rf>
   <form>dávají</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m006-d1t503-5">
   <w.rf>
    <LM>w#w-d1t503-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t503-6">
   <w.rf>
    <LM>w#w-d1t503-6</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m006-d1t503-7">
   <w.rf>
    <LM>w#w-d1t503-7</LM>
   </w.rf>
   <form>velkých</form>
   <lemma>velký</lemma>
   <tag>AANP6----1A----</tag>
  </m>
  <m id="m006-d1t503-8">
   <w.rf>
    <LM>w#w-d1t503-8</LM>
   </w.rf>
   <form>městech</form>
   <lemma>město</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m006-d1t503-10">
   <w.rf>
    <LM>w#w-d1t503-10</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t503-11">
   <w.rf>
    <LM>w#w-d1t503-11</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t503-12">
   <w.rf>
    <LM>w#w-d1t503-12</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t503-13">
   <w.rf>
    <LM>w#w-d1t503-13</LM>
   </w.rf>
   <form>zvyk</form>
   <lemma>zvyk</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m006-d1t503-14">
   <w.rf>
    <LM>w#w-d1t503-14</LM>
   </w.rf>
   <form>jen</form>
   <lemma>jen-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t503-15">
   <w.rf>
    <LM>w#w-d1t503-15</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t503-16">
   <w.rf>
    <LM>w#w-d1t503-16</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m006-d1t503-17">
   <w.rf>
    <LM>w#w-d1t503-17</LM>
   </w.rf>
   <form>menších</form>
   <lemma>malý</lemma>
   <tag>AANP6----2A----</tag>
  </m>
  <m id="m006-d-id71067">
   <w.rf>
    <LM>w#w-d-id71067</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e504-x2">
  <m id="m006-d1t509-1">
   <w.rf>
    <LM>w#w-d1t509-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t509-2">
   <w.rf>
    <LM>w#w-d1t509-2</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP6----------</tag>
  </m>
  <m id="m006-d1t509-3">
   <w.rf>
    <LM>w#w-d1t509-3</LM>
   </w.rf>
   <form>větších</form>
   <lemma>velký</lemma>
   <tag>AANP6----2A----</tag>
  </m>
  <m id="m006-d1t509-4">
   <w.rf>
    <LM>w#w-d1t509-4</LM>
   </w.rf>
   <form>městech</form>
   <lemma>město</lemma>
   <tag>NNNP6-----A----</tag>
  </m>
  <m id="m006-d1t511-9">
   <w.rf>
    <LM>w#w-d1t511-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m006-d1t511-12">
   <w.rf>
    <LM>w#w-d1t511-12</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDMS4----------</tag>
  </m>
  <m id="m006-d1t511-13">
   <w.rf>
    <LM>w#w-d1t511-13</LM>
   </w.rf>
   <form>čápa</form>
   <lemma>čáp</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m006-d1t511-3">
   <w.rf>
    <LM>w#w-d1t511-3</LM>
   </w.rf>
   <form>jenom</form>
   <lemma>jenom-2_^(pouze)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t511-11">
   <w.rf>
    <LM>w#w-d1t511-11</LM>
   </w.rf>
   <form>vylepí</form>
   <lemma>vylepit</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m006-d1t511-4">
   <w.rf>
    <LM>w#w-d1t511-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m006-d1t511-5">
   <w.rf>
    <LM>w#w-d1t511-5</LM>
   </w.rf>
   <form>okno</form>
   <lemma>okno</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m006-d-id71113">
   <w.rf>
    <LM>w#w-d-id71113</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e512-x2">
  <m id="m006-d1t517-2">
   <w.rf>
    <LM>w#w-d1t517-2</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t517-3">
   <w.rf>
    <LM>w#w-d1t517-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t517-4">
   <w.rf>
    <LM>w#w-d1t517-4</LM>
   </w.rf>
   <form>tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t517-5">
   <w.rf>
    <LM>w#w-d1t517-5</LM>
   </w.rf>
   <form>vyfocené</form>
   <lemma>vyfocený_^(*4tit)</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m006-d-id71508">
   <w.rf>
    <LM>w#w-d-id71508</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e512-x3">
  <m id="m006-d1t523-1">
   <w.rf>
    <LM>w#w-d1t523-1</LM>
   </w.rf>
   <form>Tohle</form>
   <lemma>tenhle</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t523-2">
   <w.rf>
    <LM>w#w-d1t523-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t526-1">
   <w.rf>
    <LM>w#w-d1t526-1</LM>
   </w.rf>
   <form>blízko</form>
   <lemma>blízko-3</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t526-3">
   <w.rf>
    <LM>w#w-d1t526-3</LM>
   </w.rf>
   <form>Antverp</form>
   <lemma>Antverpy_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m006-d-id71678">
   <w.rf>
    <LM>w#w-d-id71678</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t526-6">
   <w.rf>
    <LM>w#w-d1t526-6</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t526-7">
   <w.rf>
    <LM>w#w-d1t526-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t526-8">
   <w.rf>
    <LM>w#w-d1t526-8</LM>
   </w.rf>
   <form>město</form>
   <lemma>město</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m006-d1t526-10">
   <w.rf>
    <LM>w#w-d1t526-10</LM>
   </w.rf>
   <form>Schelle</form>
   <lemma>Schelle-2_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m006-d-id71517">
   <w.rf>
    <LM>w#w-d-id71517</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e527-x2">
  <m id="m006-d1t532-4">
   <w.rf>
    <LM>w#w-d1t532-4</LM>
   </w.rf>
   <form>Vyslovuje</form>
   <lemma>vyslovovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t532-5">
   <w.rf>
    <LM>w#w-d1t532-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t532-6">
   <w.rf>
    <LM>w#w-d1t532-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1e527-x2-368">
   <w.rf>
    <LM>w#w-d1e527-x2-368</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t532-8">
   <w.rf>
    <LM>w#w-d1t532-8</LM>
   </w.rf>
   <form>Šele</form>
   <lemma>Šele_;G_,i_^(^DS**Schelle)</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m006-d1e527-x2-369">
   <w.rf>
    <LM>w#w-d1e527-x2-369</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d-id71944">
   <w.rf>
    <LM>w#w-d-id71944</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t536-1">
   <w.rf>
    <LM>w#w-d1t536-1</LM>
   </w.rf>
   <form>podle</form>
   <lemma>podle-2</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t536-2">
   <w.rf>
    <LM>w#w-d1t536-2</LM>
   </w.rf>
   <form>řeky</form>
   <lemma>řeka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m006-d1e527-x2-466">
   <w.rf>
    <LM>w#w-d1e527-x2-466</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t536-4">
   <w.rf>
    <LM>w#w-d1t536-4</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Schelde</form>
   <lemma>Schelde_;G_^(řeka)</lemma>
   <tag>NNXXX-----A----</tag>
  </m>
  <m id="m006-d1e527-x2-465">
   <w.rf>
    <LM>w#w-d1e527-x2-465</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d-id71816">
   <w.rf>
    <LM>w#w-d-id71816</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e550-x3">
  <m id="m006-d1t559-5">
   <w.rf>
    <LM>w#w-d1t559-5</LM>
   </w.rf>
   <form>Znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d1t559-2">
   <w.rf>
    <LM>w#w-d1t559-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m006-d1t559-3">
   <w.rf>
    <LM>w#w-d1t559-3</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m006-d1t559-4">
   <w.rf>
    <LM>w#w-d1t559-4</LM>
   </w.rf>
   <form>rodinu</form>
   <lemma>rodina</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m006-d-id72276">
   <w.rf>
    <LM>w#w-d-id72276</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e560-x2">
  <m id="m006-d1t563-1">
   <w.rf>
    <LM>w#w-d1t563-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1e560-x2-4131">
   <w.rf>
    <LM>w#w-d1e560-x2-4131</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t563-2">
   <w.rf>
    <LM>w#w-d1t563-2</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m006-d1t563-3">
   <w.rf>
    <LM>w#w-d1t563-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m006-d1t563-5">
   <w.rf>
    <LM>w#w-d1t563-5</LM>
   </w.rf>
   <form>právě</form>
   <lemma>právě-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t563-4">
   <w.rf>
    <LM>w#w-d1t563-4</LM>
   </w.rf>
   <form>znala</form>
   <lemma>znát</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d1e560-x2-4132">
   <w.rf>
    <LM>w#w-d1e560-x2-4132</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-4135">
  <m id="m006-d1t565-1">
   <w.rf>
    <LM>w#w-d1t565-1</LM>
   </w.rf>
   <form>Muž</form>
   <lemma>muž</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m006-d1t565-2">
   <w.rf>
    <LM>w#w-d1t565-2</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m006-d1t565-3">
   <w.rf>
    <LM>w#w-d1t565-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t565-4">
   <w.rf>
    <LM>w#w-d1t565-4</LM>
   </w.rf>
   <form>ní</form>
   <lemma>on-1</lemma>
   <tag>PEFS7--3-------</tag>
  </m>
  <m id="m006-d1t565-5">
   <w.rf>
    <LM>w#w-d1t565-5</LM>
   </w.rf>
   <form>dopisoval</form>
   <lemma>dopisovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m006-d1t565-7">
   <w.rf>
    <LM>w#w-d1t565-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t565-8">
   <w.rf>
    <LM>w#w-d1t565-8</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t565-9">
   <w.rf>
    <LM>w#w-d1t565-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t565-11">
   <w.rf>
    <LM>w#w-d1t565-11</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t565-13">
   <w.rf>
    <LM>w#w-d1t565-13</LM>
   </w.rf>
   <form>mužem</form>
   <lemma>muž</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m006-d1t565-10">
   <w.rf>
    <LM>w#w-d1t565-10</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t567-1">
   <w.rf>
    <LM>w#w-d1t567-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m006-d1t567-3">
   <w.rf>
    <LM>w#w-d1t567-3</LM>
   </w.rf>
   <form>dovolené</form>
   <lemma>dovolená_^(ze_zaměstnání)</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m006-4135-4143">
   <w.rf>
    <LM>w#w-4135-4143</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-4144">
  <m id="m006-d1t569-2">
   <w.rf>
    <LM>w#w-d1t569-2</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t569-3">
   <w.rf>
    <LM>w#w-d1t569-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m006-d1t569-4">
   <w.rf>
    <LM>w#w-d1t569-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m006-d1t569-5">
   <w.rf>
    <LM>w#w-d1t569-5</LM>
   </w.rf>
   <form>výměna</form>
   <lemma>výměna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m006-d-id72764">
   <w.rf>
    <LM>w#w-d-id72764</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t569-8">
   <w.rf>
    <LM>w#w-d1t569-8</LM>
   </w.rf>
   <form>oni</form>
   <lemma>on-1</lemma>
   <tag>PEMP1--3-------</tag>
  </m>
  <m id="m006-d1t569-9">
   <w.rf>
    <LM>w#w-d1t569-9</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m006-d1t569-10">
   <w.rf>
    <LM>w#w-d1t569-10</LM>
   </w.rf>
   <form>nám</form>
   <lemma>my</lemma>
   <tag>PP-P3--1-------</tag>
  </m>
  <m id="m006-d1t569-11">
   <w.rf>
    <LM>w#w-d1t569-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t569-12">
   <w.rf>
    <LM>w#w-d1t569-12</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m006-d1t569-13">
   <w.rf>
    <LM>w#w-d1t569-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m006-d1t569-14">
   <w.rf>
    <LM>w#w-d1t569-14</LM>
   </w.rf>
   <form>nim</form>
   <lemma>on-1</lemma>
   <tag>PEXP3--3------1</tag>
  </m>
  <m id="m006-d-id72323">
   <w.rf>
    <LM>w#w-d-id72323</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e570-x2">
  <m id="m006-d1t573-1">
   <w.rf>
    <LM>w#w-d1t573-1</LM>
   </w.rf>
   <form>Čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t573-2">
   <w.rf>
    <LM>w#w-d1t573-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t573-3">
   <w.rf>
    <LM>w#w-d1t573-3</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m006-d1t573-4">
   <w.rf>
    <LM>w#w-d1t573-4</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t573-5">
   <w.rf>
    <LM>w#w-d1t573-5</LM>
   </w.rf>
   <form>chlapečka</form>
   <lemma>chlapeček</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m006-d-id73027">
   <w.rf>
    <LM>w#w-d-id73027</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e574-x2">
  <m id="m006-d1t581-1">
   <w.rf>
    <LM>w#w-d1t581-1</LM>
   </w.rf>
   <form>Tohleto</form>
   <lemma>tenhleten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t581-2">
   <w.rf>
    <LM>w#w-d1t581-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m006-d1t581-3">
   <w.rf>
    <LM>w#w-d1t581-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t581-4">
   <w.rf>
    <LM>w#w-d1t581-4</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m006-d1t581-6">
   <w.rf>
    <LM>w#w-d1t581-6</LM>
   </w.rf>
   <form>Schelle</form>
   <lemma>Schelle-2_;G</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m006-d-id73201">
   <w.rf>
    <LM>w#w-d-id73201</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t581-9">
   <w.rf>
    <LM>w#w-d1t581-9</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t581-11">
   <w.rf>
    <LM>w#w-d1t581-11</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m006-d1e574-x2-4306">
   <w.rf>
    <LM>w#w-d1e574-x2-4306</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t581-13">
   <w.rf>
    <LM>w#w-d1t581-13</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m006-d1t581-14">
   <w.rf>
    <LM>w#w-d1t581-14</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t581-15">
   <w.rf>
    <LM>w#w-d1t581-15</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t581-16">
   <w.rf>
    <LM>w#w-d1t581-16</LM>
   </w.rf>
   <form>narodilo</form>
   <lemma>narodit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m006-d1t581-21">
   <w.rf>
    <LM>w#w-d1t581-21</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t581-22">
   <w.rf>
    <LM>w#w-d1t581-22</LM>
   </w.rf>
   <form>koho</form>
   <lemma>kdo</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m006-d1t581-23">
   <w.rf>
    <LM>w#w-d1t581-23</LM>
   </w.rf>
   <form>čekali</form>
   <lemma>čekat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1e574-x2-4307">
   <w.rf>
    <LM>w#w-d1e574-x2-4307</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-4310">
  <m id="m006-d1t583-1">
   <w.rf>
    <LM>w#w-d1t583-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m006-d1t583-2">
   <w.rf>
    <LM>w#w-d1t583-2</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m006-d1t583-5">
   <w.rf>
    <LM>w#w-d1t583-5</LM>
   </w.rf>
   <form>normálně</form>
   <lemma>normálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m006-d1t583-6">
   <w.rf>
    <LM>w#w-d1t583-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t583-7">
   <w.rf>
    <LM>w#w-d1t583-7</LM>
   </w.rf>
   <form>ulici</form>
   <lemma>ulice</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m006-d-id73534">
   <w.rf>
    <LM>w#w-d-id73534</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t585-1">
   <w.rf>
    <LM>w#w-d1t585-1</LM>
   </w.rf>
   <form>ti</form>
   <lemma>ten</lemma>
   <tag>PDMP1----------</tag>
  </m>
  <m id="m006-d1t585-2">
   <w.rf>
    <LM>w#w-d1t585-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t585-3">
   <w.rf>
    <LM>w#w-d1t585-3</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t585-4">
   <w.rf>
    <LM>w#w-d1t585-4</LM>
   </w.rf>
   <form>neznali</form>
   <lemma>znát</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m006-d1t585-5">
   <w.rf>
    <LM>w#w-d1t585-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t585-7">
   <w.rf>
    <LM>w#w-d1t585-7</LM>
   </w.rf>
   <form>našimi</form>
   <lemma>náš</lemma>
   <tag>PSXP7-P1-------</tag>
  </m>
  <m id="m006-d1t585-8">
   <w.rf>
    <LM>w#w-d1t585-8</LM>
   </w.rf>
   <form>známými</form>
   <lemma>známý-1_^(potkat_známého_[člověka])</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m006-4310-4321">
   <w.rf>
    <LM>w#w-4310-4321</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-4322">
  <m id="m006-d1t585-10">
   <w.rf>
    <LM>w#w-d1t585-10</LM>
   </w.rf>
   <form>To</form>
   <lemma>to-9_^(být_s_to)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d1t585-11">
   <w.rf>
    <LM>w#w-d1t585-11</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t585-12">
   <w.rf>
    <LM>w#w-d1t585-12</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t588-4">
   <w.rf>
    <LM>w#w-d1t588-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t588-6">
   <w.rf>
    <LM>w#w-d1t588-6</LM>
   </w.rf>
   <form>vnučkou</form>
   <lemma>vnučka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m006-d1t588-2">
   <w.rf>
    <LM>w#w-d1t588-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t588-3">
   <w.rf>
    <LM>w#w-d1t588-3</LM>
   </w.rf>
   <form>výletě</form>
   <lemma>výlet</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m006-d1t588-7">
   <w.rf>
    <LM>w#w-d1t588-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t588-8">
   <w.rf>
    <LM>w#w-d1t588-8</LM>
   </w.rf>
   <form>kole</form>
   <lemma>kolo</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m006-d-id73073">
   <w.rf>
    <LM>w#w-d-id73073</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e590-x2">
  <m id="m006-d1t597-1">
   <w.rf>
    <LM>w#w-d1t597-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m006-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1t597-4">
   <w.rf>
    <LM>w#w-d1t597-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m006-d1t597-5">
   <w.rf>
    <LM>w#w-d1t597-5</LM>
   </w.rf>
   <form>tomhle</form>
   <lemma>tenhle</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m006-d1t597-6">
   <w.rf>
    <LM>w#w-d1t597-6</LM>
   </w.rf>
   <form>zvyku</form>
   <lemma>zvyk</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m006-d1t597-7">
   <w.rf>
    <LM>w#w-d1t597-7</LM>
   </w.rf>
   <form>dozvěděla</form>
   <lemma>dozvědět</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m006-d-id74068">
   <w.rf>
    <LM>w#w-d-id74068</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e598-x2">
  <m id="m006-d1t605-1">
   <w.rf>
    <LM>w#w-d1t605-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m006-d1t605-2">
   <w.rf>
    <LM>w#w-d1t605-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m006-d1t605-3">
   <w.rf>
    <LM>w#w-d1t605-3</LM>
   </w.rf>
   <form>řekli</form>
   <lemma>říci</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m006-d-id74194">
   <w.rf>
    <LM>w#w-d-id74194</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t607-1">
   <w.rf>
    <LM>w#w-d1t607-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t607-2">
   <w.rf>
    <LM>w#w-d1t607-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m006-d1t607-3">
   <w.rf>
    <LM>w#w-d1t607-3</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m006-d1t607-4">
   <w.rf>
    <LM>w#w-d1t607-4</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m006-d1t607-5">
   <w.rf>
    <LM>w#w-d1t607-5</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m006-d1t607-6">
   <w.rf>
    <LM>w#w-d1t607-6</LM>
   </w.rf>
   <form>rodiny</form>
   <lemma>rodina</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m006-d-id74114">
   <w.rf>
    <LM>w#w-d-id74114</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e614-x3">
  <m id="m006-d1t625-1">
   <w.rf>
    <LM>w#w-d1t625-1</LM>
   </w.rf>
   <form>Narození</form>
   <lemma>narození_^(*4dit)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m006-d1t625-2">
   <w.rf>
    <LM>w#w-d1t625-2</LM>
   </w.rf>
   <form>dítěte</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m006-d1t625-3">
   <w.rf>
    <LM>w#w-d1t625-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m006-d1e614-x3-399">
   <w.rf>
    <LM>w#w-d1e614-x3-399</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1e614-x3-400">
   <w.rf>
    <LM>w#w-d1e614-x3-400</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t628-2">
   <w.rf>
    <LM>w#w-d1t628-2</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t628-3">
   <w.rf>
    <LM>w#w-d1t628-3</LM>
   </w.rf>
   <form>oslavuje</form>
   <lemma>oslavovat</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m006-d1t628-4">
   <w.rf>
    <LM>w#w-d1t628-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m006-d1t628-5">
   <w.rf>
    <LM>w#w-d1t628-5</LM>
   </w.rf>
   <form>sousedy</form>
   <lemma>soused</lemma>
   <tag>NNMP7-----A----</tag>
  </m>
  <m id="m006-d1e614-x3-4495">
   <w.rf>
    <LM>w#w-d1e614-x3-4495</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-d1e629-x2">
  <m id="m006-d1t632-1">
   <w.rf>
    <LM>w#w-d1t632-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m006-d-id74705">
   <w.rf>
    <LM>w#w-d-id74705</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m006-d1t632-5">
   <w.rf>
    <LM>w#w-d1t632-5</LM>
   </w.rf>
   <form>sousedé</form>
   <lemma>soused</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m006-d1t632-6">
   <w.rf>
    <LM>w#w-d1t632-6</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m006-d1t634-1">
   <w.rf>
    <LM>w#w-d1t634-1</LM>
   </w.rf>
   <form>přijdou</form>
   <lemma>přijít</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m006-d1t634-2">
   <w.rf>
    <LM>w#w-d1t634-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m006-d1t634-7">
   <w.rf>
    <LM>w#w-d1t634-7</LM>
   </w.rf>
   <form>křtiny</form>
   <lemma>křtiny</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m006-d1e629-x2-4611">
   <w.rf>
    <LM>w#w-d1e629-x2-4611</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m006-4614">
  <m id="m006-d1t636-4">
   <w.rf>
    <LM>w#w-d1t636-4</LM>
   </w.rf>
   <form>Rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m006-d1t636-5">
   <w.rf>
    <LM>w#w-d1t636-5</LM>
   </w.rf>
   <form>udělají</form>
   <lemma>udělat</lemma>
   <tag>VB-P---3P-AAP--</tag>
  </m>
  <m id="m006-d1t636-6">
   <w.rf>
    <LM>w#w-d1t636-6</LM>
   </w.rf>
   <form>malinké</form>
   <lemma>malinký</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m006-d1t636-7">
   <w.rf>
    <LM>w#w-d1t636-7</LM>
   </w.rf>
   <form>balíčky</form>
   <lemma>balíček</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m006-d1t636-8">
   <w.rf>
    <LM>w#w-d1t636-8</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m006-d1t636-9">
   <w.rf>
    <LM>w#w-d1t636-9</LM>
   </w.rf>
   <form>cukrovím</form>
   <lemma>cukroví</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m006-d1t636-11">
   <w.rf>
    <LM>w#w-d1t636-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m006-d1t636-17">
   <w.rf>
    <LM>w#w-d1t636-17</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m006-d1t636-18">
   <w.rf>
    <LM>w#w-d1t636-18</LM>
   </w.rf>
   <form>balíčky</form>
   <lemma>balíček</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m006-d1t636-16">
   <w.rf>
    <LM>w#w-d1t636-16</LM>
   </w.rf>
   <form>dávají</form>
   <lemma>dávat-1_^(*5t-1)</lemma>
   <tag>VB-P---3P-AAI--</tag>
  </m>
  <m id="m006-d1t636-13">
   <w.rf>
    <LM>w#w-d1t636-13</LM>
   </w.rf>
   <form>maličkým</form>
   <lemma>maličký</lemma>
   <tag>AAFP3----1A----</tag>
  </m>
  <m id="m006-d1t636-14">
   <w.rf>
    <LM>w#w-d1t636-14</LM>
   </w.rf>
   <form>dětem</form>
   <lemma>dítě-2</lemma>
   <tag>NNFP3-----A----</tag>
  </m>
  <m id="m006-4614-4738">
   <w.rf>
    <LM>w#w-4614-4738</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
