<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="hg_714.02.w.gz" />
  </references>
 </head>
 <s id="m714-26171_04-249">
  <m id="m714-d1t393-10">
   <w.rf>
    <LM>w#w-d1t393-10</LM>
   </w.rf>
   <form>Okamžitě</form>
   <lemma>okamžitě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t393-8">
   <w.rf>
    <LM>w#w-d1t393-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t393-9">
   <w.rf>
    <LM>w#w-d1t393-9</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m714-d1t393-11">
   <w.rf>
    <LM>w#w-d1t393-11</LM>
   </w.rf>
   <form>poznala</form>
   <lemma>poznat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-249-250">
   <w.rf>
    <LM>w#w-249-250</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-251">
  <m id="m714-d1t393-14">
   <w.rf>
    <LM>w#w-d1t393-14</LM>
   </w.rf>
   <form>Jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t393-15">
   <w.rf>
    <LM>w#w-d1t393-15</LM>
   </w.rf>
   <form>dítě</form>
   <lemma>dítě-1</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-d-id78149">
   <w.rf>
    <LM>w#w-d-id78149</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t393-17">
   <w.rf>
    <LM>w#w-d1t393-17</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t393-18">
   <w.rf>
    <LM>w#w-d1t393-18</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t393-19">
   <w.rf>
    <LM>w#w-d1t393-19</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t393-20">
   <w.rf>
    <LM>w#w-d1t393-20</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t393-21">
   <w.rf>
    <LM>w#w-d1t393-21</LM>
   </w.rf>
   <form>Praze</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id78228">
   <w.rf>
    <LM>w#w-d-id78228</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t393-13">
   <w.rf>
    <LM>w#w-d1t393-13</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t395-2">
   <w.rf>
    <LM>w#w-d1t395-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t395-3">
   <w.rf>
    <LM>w#w-d1t395-3</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t395-4">
   <w.rf>
    <LM>w#w-d1t395-4</LM>
   </w.rf>
   <form>zamilovala</form>
   <lemma>zamilovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t395-5">
   <w.rf>
    <LM>w#w-d1t395-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t395-6">
   <w.rf>
    <LM>w#w-d1t395-6</LM>
   </w.rf>
   <form>tatínkova</form>
   <lemma>tatínkův_^(*3ek)</lemma>
   <tag>AUMS2M---------</tag>
  </m>
  <m id="m714-d1t395-7">
   <w.rf>
    <LM>w#w-d1t395-7</LM>
   </w.rf>
   <form>kamaráda</form>
   <lemma>kamarád</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m714-d-id78348">
   <w.rf>
    <LM>w#w-d-id78348</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x40">
  <m id="m714-d1t402-1">
   <w.rf>
    <LM>w#w-d1t402-1</LM>
   </w.rf>
   <form>Nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m714-d1t402-2">
   <w.rf>
    <LM>w#w-d1t402-2</LM>
   </w.rf>
   <form>Zdeněk</form>
   <lemma>Zdeněk_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x40-254">
   <w.rf>
    <LM>w#w-d1e24-x40-254</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-255">
  <m id="m714-d1t402-4">
   <w.rf>
    <LM>w#w-d1t402-4</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t402-5">
   <w.rf>
    <LM>w#w-d1t402-5</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t402-6">
   <w.rf>
    <LM>w#w-d1t402-6</LM>
   </w.rf>
   <form>jeho</form>
   <lemma>jeho</lemma>
   <tag>P9XXXZS3-------</tag>
  </m>
  <m id="m714-d1t402-7">
   <w.rf>
    <LM>w#w-d1t402-7</LM>
   </w.rf>
   <form>manželka</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-255-256">
   <w.rf>
    <LM>w#w-255-256</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t402-9">
   <w.rf>
    <LM>w#w-d1t402-9</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m714-d1t402-10">
   <w.rf>
    <LM>w#w-d1t402-10</LM>
   </w.rf>
   <form>zemřel</form>
   <lemma>zemřít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t402-11">
   <w.rf>
    <LM>w#w-d1t402-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t402-12">
   <w.rf>
    <LM>w#w-d1t402-12</LM>
   </w.rf>
   <form>Terezíně</form>
   <lemma>Terezín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t404-1">
   <w.rf>
    <LM>w#w-d1t404-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t404-2">
   <w.rf>
    <LM>w#w-d1t404-2</LM>
   </w.rf>
   <form>ona</form>
   <lemma>on-1</lemma>
   <tag>PEFS1--3-------</tag>
  </m>
  <m id="m714-d1t404-3">
   <w.rf>
    <LM>w#w-d1t404-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t404-4">
   <w.rf>
    <LM>w#w-d1t404-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t404-5">
   <w.rf>
    <LM>w#w-d1t404-5</LM>
   </w.rf>
   <form>návštěvě</form>
   <lemma>návštěva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t404-6">
   <w.rf>
    <LM>w#w-d1t404-6</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t404-8">
   <w.rf>
    <LM>w#w-d1t404-8</LM>
   </w.rf>
   <form>Netlů</form>
   <lemma>Netl_;Y</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m714-d-id78689">
   <w.rf>
    <LM>w#w-d-id78689</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x41">
  <m id="m714-d1t406-4">
   <w.rf>
    <LM>w#w-d1t406-4</LM>
   </w.rf>
   <form>Vykládalo</form>
   <lemma>vykládat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t406-3">
   <w.rf>
    <LM>w#w-d1t406-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1e24-x41-4700">
   <w.rf>
    <LM>w#w-d1e24-x41-4700</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t406-5">
   <w.rf>
    <LM>w#w-d1t406-5</LM>
   </w.rf>
   <form>vykládalo</form>
   <lemma>vykládat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t406-6">
   <w.rf>
    <LM>w#w-d1t406-6</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t406-7">
   <w.rf>
    <LM>w#w-d1t406-7</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t406-9">
   <w.rf>
    <LM>w#w-d1t406-9</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t406-10">
   <w.rf>
    <LM>w#w-d1t406-10</LM>
   </w.rf>
   <form>Netlovi</form>
   <lemma>Netlův_;Y_^(*2)</lemma>
   <tag>AUMP1M---------</tag>
  </m>
  <m id="m714-d-id78861">
   <w.rf>
    <LM>w#w-d-id78861</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t406-13">
   <w.rf>
    <LM>w#w-d1t406-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t406-14">
   <w.rf>
    <LM>w#w-d1t406-14</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t408-1">
   <w.rf>
    <LM>w#w-d1t408-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t408-2">
   <w.rf>
    <LM>w#w-d1t408-2</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t408-3">
   <w.rf>
    <LM>w#w-d1t408-3</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t408-4">
   <w.rf>
    <LM>w#w-d1t408-4</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t408-5">
   <w.rf>
    <LM>w#w-d1t408-5</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t408-6">
   <w.rf>
    <LM>w#w-d1t408-6</LM>
   </w.rf>
   <form>nich</form>
   <lemma>on-1</lemma>
   <tag>PEXP2--3-------</tag>
  </m>
  <m id="m714-d-id79011">
   <w.rf>
    <LM>w#w-d-id79011</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x42">
  <m id="m714-d1t412-1">
   <w.rf>
    <LM>w#w-d1t412-1</LM>
   </w.rf>
   <form>Začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t412-2">
   <w.rf>
    <LM>w#w-d1t412-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t412-3">
   <w.rf>
    <LM>w#w-d1t412-3</LM>
   </w.rf>
   <form>poznávat</form>
   <lemma>poznávat_^(*4at)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t412-4">
   <w.rf>
    <LM>w#w-d1t412-4</LM>
   </w.rf>
   <form>život</form>
   <lemma>život</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d-id79106">
   <w.rf>
    <LM>w#w-d-id79106</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t412-6">
   <w.rf>
    <LM>w#w-d1t412-6</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t412-7">
   <w.rf>
    <LM>w#w-d1t412-7</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t412-8">
   <w.rf>
    <LM>w#w-d1t412-8</LM>
   </w.rf>
   <form>nedělalo</form>
   <lemma>dělat</lemma>
   <tag>VpNS----R-NAI--</tag>
  </m>
  <m id="m714-d1t412-9">
   <w.rf>
    <LM>w#w-d1t412-9</LM>
   </w.rf>
   <form>dobrotu</form>
   <lemma>dobrota</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t412-10">
   <w.rf>
    <LM>w#w-d1t412-10</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t412-11">
   <w.rf>
    <LM>w#w-d1t412-11</LM>
   </w.rf>
   <form>různých</form>
   <lemma>různý</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m714-d1t412-12">
   <w.rf>
    <LM>w#w-d1t412-12</LM>
   </w.rf>
   <form>důvodů</form>
   <lemma>důvod</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m714-d1e24-x42-5027">
   <w.rf>
    <LM>w#w-d1e24-x42-5027</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t412-13">
   <w.rf>
    <LM>w#w-d1t412-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t417-1">
   <w.rf>
    <LM>w#w-d1t417-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t417-2">
   <w.rf>
    <LM>w#w-d1t417-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t417-3">
   <w.rf>
    <LM>w#w-d1t417-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t417-4">
   <w.rf>
    <LM>w#w-d1t417-4</LM>
   </w.rf>
   <form>odstěhovala</form>
   <lemma>odstěhovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x42-5030">
   <w.rf>
    <LM>w#w-d1e24-x42-5030</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-5031">
  <m id="m714-5031-5168">
   <w.rf>
    <LM>w#w-5031-5168</LM>
   </w.rf>
   <form>Ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5166">
   <w.rf>
    <LM>w#w-5031-5166</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-5031-5165">
   <w.rf>
    <LM>w#w-5031-5165</LM>
   </w.rf>
   <form>rodiče</form>
   <lemma>rodič</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m714-5031-5164">
   <w.rf>
    <LM>w#w-5031-5164</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-5031-5163">
   <w.rf>
    <LM>w#w-5031-5163</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-5031-5162">
   <w.rf>
    <LM>w#w-5031-5162</LM>
   </w.rf>
   <form>Jihlavy</form>
   <lemma>Jihlava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-5031-5161">
   <w.rf>
    <LM>w#w-5031-5161</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5160">
   <w.rf>
    <LM>w#w-5031-5160</LM>
   </w.rf>
   <form>tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-5031-5159">
   <w.rf>
    <LM>w#w-5031-5159</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-5031-5158">
   <w.rf>
    <LM>w#w-5031-5158</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-5031-5157">
   <w.rf>
    <LM>w#w-5031-5157</LM>
   </w.rf>
   <form>poslední</form>
   <lemma>poslední</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-5031-5156">
   <w.rf>
    <LM>w#w-5031-5156</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-5031-5155">
   <w.rf>
    <LM>w#w-5031-5155</LM>
   </w.rf>
   <form>tichého</form>
   <lemma>tichý</lemma>
   <tag>AAMS4----1A----</tag>
  </m>
  <m id="m714-5031-5154">
   <w.rf>
    <LM>w#w-5031-5154</LM>
   </w.rf>
   <form>společníka</form>
   <lemma>společník</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m714-5031-5153">
   <w.rf>
    <LM>w#w-5031-5153</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5152">
   <w.rf>
    <LM>w#w-5031-5152</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZMS4----------</tag>
  </m>
  <m id="m714-5031-5151">
   <w.rf>
    <LM>w#w-5031-5151</LM>
   </w.rf>
   <form>pana</form>
   <lemma>pan</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m714-5031-5150">
   <w.rf>
    <LM>w#w-5031-5150</LM>
   </w.rf>
   <form>Rakušana</form>
   <lemma>Rakušan_;E</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m714-5031-267">
   <w.rf>
    <LM>w#w-5031-267</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-268">
  <m id="m714-5031-5148">
   <w.rf>
    <LM>w#w-5031-5148</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-5031-5147">
   <w.rf>
    <LM>w#w-5031-5147</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m714-5031-5146">
   <w.rf>
    <LM>w#w-5031-5146</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-5031-5145">
   <w.rf>
    <LM>w#w-5031-5145</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-5031-5144">
   <w.rf>
    <LM>w#w-5031-5144</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZYS1----------</tag>
  </m>
  <m id="m714-5031-5143">
   <w.rf>
    <LM>w#w-5031-5143</LM>
   </w.rf>
   <form>nábytek</form>
   <lemma>nábytek</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-5031-5142">
   <w.rf>
    <LM>w#w-5031-5142</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-5031-5141">
   <w.rf>
    <LM>w#w-5031-5141</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP1----------</tag>
  </m>
  <m id="m714-5031-5140">
   <w.rf>
    <LM>w#w-5031-5140</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-268-269">
   <w.rf>
    <LM>w#w-268-269</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-270">
  <m id="m714-5031-5136">
   <w.rf>
    <LM>w#w-5031-5136</LM>
   </w.rf>
   <form>Vím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-5031-5135">
   <w.rf>
    <LM>w#w-5031-5135</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5134">
   <w.rf>
    <LM>w#w-5031-5134</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-5031-5133">
   <w.rf>
    <LM>w#w-5031-5133</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5132">
   <w.rf>
    <LM>w#w-5031-5132</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-5031-5131">
   <w.rf>
    <LM>w#w-5031-5131</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-5031-5130">
   <w.rf>
    <LM>w#w-5031-5130</LM>
   </w.rf>
   <form>lednička</form>
   <lemma>lednička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-5031-5129">
   <w.rf>
    <LM>w#w-5031-5129</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5128">
   <w.rf>
    <LM>w#w-5031-5128</LM>
   </w.rf>
   <form>nový</form>
   <lemma>nový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-5031-5127">
   <w.rf>
    <LM>w#w-5031-5127</LM>
   </w.rf>
   <form>elektrický</form>
   <lemma>elektrický</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-5031-5126">
   <w.rf>
    <LM>w#w-5031-5126</LM>
   </w.rf>
   <form>kuchyňský</form>
   <lemma>kuchyňský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-5031-5125">
   <w.rf>
    <LM>w#w-5031-5125</LM>
   </w.rf>
   <form>sporák</form>
   <lemma>sporák</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-5031-5124">
   <w.rf>
    <LM>w#w-5031-5124</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5123">
   <w.rf>
    <LM>w#w-5031-5123</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-5031-5524">
   <w.rf>
    <LM>w#w-5031-5524</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5118">
   <w.rf>
    <LM>w#w-5031-5118</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZIP1----------</tag>
  </m>
  <m id="m714-5031-5117">
   <w.rf>
    <LM>w#w-5031-5117</LM>
   </w.rf>
   <form>koberce</form>
   <lemma>koberec</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m714-5031-5122">
   <w.rf>
    <LM>w#w-5031-5122</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-5031-5121">
   <w.rf>
    <LM>w#w-5031-5121</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP1----1A----</tag>
  </m>
  <m id="m714-5031-5120">
   <w.rf>
    <LM>w#w-5031-5120</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-5031-5525">
   <w.rf>
    <LM>w#w-5031-5525</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-5526">
  <m id="m714-5031-5114">
   <w.rf>
    <LM>w#w-5031-5114</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-5031-5113">
   <w.rf>
    <LM>w#w-5031-5113</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5112">
   <w.rf>
    <LM>w#w-5031-5112</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m714-5031-5111">
   <w.rf>
    <LM>w#w-5031-5111</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5110">
   <w.rf>
    <LM>w#w-5031-5110</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-5031-5109">
   <w.rf>
    <LM>w#w-5031-5109</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-5031-5107">
   <w.rf>
    <LM>w#w-5031-5107</LM>
   </w.rf>
   <form>jednopokojovém</form>
   <lemma>jednopokojový</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m714-5031-5106">
   <w.rf>
    <LM>w#w-5031-5106</LM>
   </w.rf>
   <form>bytě</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-5031-5105">
   <w.rf>
    <LM>w#w-5031-5105</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-5031-5103">
   <w.rf>
    <LM>w#w-5031-5103</LM>
   </w.rf>
   <form>Vladislavově</form>
   <lemma>Vladislavův_;Y_^(*2)</lemma>
   <tag>AUFS6M---------</tag>
  </m>
  <m id="m714-5031-5102">
   <w.rf>
    <LM>w#w-5031-5102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5526-37">
   <w.rf>
    <LM>w#w-5526-37</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5089">
   <w.rf>
    <LM>w#w-5031-5089</LM>
   </w.rf>
   <form>muselo</form>
   <lemma>muset</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-5031-5088">
   <w.rf>
    <LM>w#w-5031-5088</LM>
   </w.rf>
   <form>zůstat</form>
   <lemma>zůstat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-5526-35">
   <w.rf>
    <LM>w#w-5526-35</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-36">
  <m id="m714-5031-5100">
   <w.rf>
    <LM>w#w-5031-5100</LM>
   </w.rf>
   <form>Vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-5031-5099">
   <w.rf>
    <LM>w#w-5031-5099</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-5031-5098">
   <w.rf>
    <LM>w#w-5031-5098</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5097">
   <w.rf>
    <LM>w#w-5031-5097</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-5031-5096">
   <w.rf>
    <LM>w#w-5031-5096</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-5031-5095">
   <w.rf>
    <LM>w#w-5031-5095</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-5031-5094">
   <w.rf>
    <LM>w#w-5031-5094</LM>
   </w.rf>
   <form>tom</form>
   <lemma>ten</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m714-5031-5093">
   <w.rf>
    <LM>w#w-5031-5093</LM>
   </w.rf>
   <form>mluvili</form>
   <lemma>mluvit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-36-38">
   <w.rf>
    <LM>w#w-36-38</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-39">
  <m id="m714-5031-5083">
   <w.rf>
    <LM>w#w-5031-5083</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-5031-5078">
   <w.rf>
    <LM>w#w-5031-5078</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-5031-5077">
   <w.rf>
    <LM>w#w-5031-5077</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-5031-5076">
   <w.rf>
    <LM>w#w-5031-5076</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-5031-5075">
   <w.rf>
    <LM>w#w-5031-5075</LM>
   </w.rf>
   <form>stěhovali</form>
   <lemma>stěhovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-5031-5082">
   <w.rf>
    <LM>w#w-5031-5082</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-5031-5080">
   <w.rf>
    <LM>w#w-5031-5080</LM>
   </w.rf>
   <form>Purkyňovy</form>
   <lemma>Purkyňův_;Y_^(*3ně)</lemma>
   <tag>AUFS2M---------</tag>
  </m>
  <m id="m714-5031-5074">
   <w.rf>
    <LM>w#w-5031-5074</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-5031-5073">
   <w.rf>
    <LM>w#w-5031-5073</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-5031-5072">
   <w.rf>
    <LM>w#w-5031-5072</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-5031-5071">
   <w.rf>
    <LM>w#w-5031-5071</LM>
   </w.rf>
   <form>ty</form>
   <lemma>ten</lemma>
   <tag>PDFP1----------</tag>
  </m>
  <m id="m714-5031-5070">
   <w.rf>
    <LM>w#w-5031-5070</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m714-5031-5069">
   <w.rf>
    <LM>w#w-5031-5069</LM>
   </w.rf>
   <form>byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-5031-5068">
   <w.rf>
    <LM>w#w-5031-5068</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-5031-5067">
   <w.rf>
    <LM>w#w-5031-5067</LM>
   </w.rf>
   <form>něj</form>
   <lemma>on-1</lemma>
   <tag>PEZS2--3-------</tag>
  </m>
  <m id="m714-39-40">
   <w.rf>
    <LM>w#w-39-40</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-42">
  <m id="m714-5031-5065">
   <w.rf>
    <LM>w#w-5031-5065</LM>
   </w.rf>
   <form>Oficiálně</form>
   <lemma>oficiálně_^(*1í)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-5031-5064">
   <w.rf>
    <LM>w#w-5031-5064</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-5031-5063">
   <w.rf>
    <LM>w#w-5031-5063</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m714-5031-5062">
   <w.rf>
    <LM>w#w-5031-5062</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-5031-5061">
   <w.rf>
    <LM>w#w-5031-5061</LM>
   </w.rf>
   <form>prodali</form>
   <lemma>prodat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-5031-5060">
   <w.rf>
    <LM>w#w-5031-5060</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-5031-5059">
   <w.rf>
    <LM>w#w-5031-5059</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m714-5031-5058">
   <w.rf>
    <LM>w#w-5031-5058</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-5031-5057">
   <w.rf>
    <LM>w#w-5031-5057</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-5031-5056">
   <w.rf>
    <LM>w#w-5031-5056</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-5031-5055">
   <w.rf>
    <LM>w#w-5031-5055</LM>
   </w.rf>
   <form>peníze</form>
   <lemma>peníze_^(jako_platidlo)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m714-5031-5054">
   <w.rf>
    <LM>w#w-5031-5054</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-5031-5053">
   <w.rf>
    <LM>w#w-5031-5053</LM>
   </w.rf>
   <form>vázaný</form>
   <lemma>vázaný_^(*2t)</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m714-5031-5052">
   <w.rf>
    <LM>w#w-5031-5052</LM>
   </w.rf>
   <form>vklad</form>
   <lemma>vklad</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-5526-873">
   <w.rf>
    <LM>w#w-5526-873</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-874">
  <m id="m714-5031-5049">
   <w.rf>
    <LM>w#w-5031-5049</LM>
   </w.rf>
   <form>K</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-5031-5048">
   <w.rf>
    <LM>w#w-5031-5048</LM>
   </w.rf>
   <form>těm</form>
   <lemma>ten</lemma>
   <tag>PDXP3----------</tag>
  </m>
  <m id="m714-5031-5047">
   <w.rf>
    <LM>w#w-5031-5047</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-5031-5046">
   <w.rf>
    <LM>w#w-5031-5046</LM>
   </w.rf>
   <form>jezdila</form>
   <lemma>jezdit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t447-1">
   <w.rf>
    <LM>w#w-d1t447-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t447-2">
   <w.rf>
    <LM>w#w-d1t447-2</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t447-3">
   <w.rf>
    <LM>w#w-d1t447-3</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t447-4">
   <w.rf>
    <LM>w#w-d1t447-4</LM>
   </w.rf>
   <form>nějak</form>
   <lemma>nějak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t447-5">
   <w.rf>
    <LM>w#w-d1t447-5</LM>
   </w.rf>
   <form>různě</form>
   <lemma>různě_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-5031-5045">
   <w.rf>
    <LM>w#w-5031-5045</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x43">
  <m id="m714-d1t449-3">
   <w.rf>
    <LM>w#w-d1t449-3</LM>
   </w.rf>
   <form>Nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZFP4----------</tag>
  </m>
  <m id="m714-d1t449-5">
   <w.rf>
    <LM>w#w-d1t449-5</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m714-d1t449-2">
   <w.rf>
    <LM>w#w-d1t449-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t449-6">
   <w.rf>
    <LM>w#w-d1t449-6</LM>
   </w.rf>
   <form>prodala</form>
   <lemma>prodat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t449-8">
   <w.rf>
    <LM>w#w-d1t449-8</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t449-9">
   <w.rf>
    <LM>w#w-d1t449-9</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t449-10">
   <w.rf>
    <LM>w#w-d1t449-10</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t449-11">
   <w.rf>
    <LM>w#w-d1t449-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t449-12">
   <w.rf>
    <LM>w#w-d1t449-12</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1e24-x43-5819">
   <w.rf>
    <LM>w#w-d1e24-x43-5819</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t451-1">
   <w.rf>
    <LM>w#w-d1t451-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t451-3">
   <w.rf>
    <LM>w#w-d1t451-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t451-6">
   <w.rf>
    <LM>w#w-d1t451-6</LM>
   </w.rf>
   <form>nebyla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m714-d1t451-7">
   <w.rf>
    <LM>w#w-d1t451-7</LM>
   </w.rf>
   <form>schopna</form>
   <lemma>schopný</lemma>
   <tag>ACQW------A----</tag>
  </m>
  <m id="m714-d1t451-9">
   <w.rf>
    <LM>w#w-d1t451-9</LM>
   </w.rf>
   <form>sehnat</form>
   <lemma>sehnat_^(shánět)</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t451-10">
   <w.rf>
    <LM>w#w-d1t451-10</LM>
   </w.rf>
   <form>nějaký</form>
   <lemma>nějaký</lemma>
   <tag>PZIS4----------</tag>
  </m>
  <m id="m714-d1t451-11">
   <w.rf>
    <LM>w#w-d1t451-11</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t451-12">
   <w.rf>
    <LM>w#w-d1t451-12</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t451-13">
   <w.rf>
    <LM>w#w-d1t451-13</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m714-d-id81624">
   <w.rf>
    <LM>w#w-d-id81624</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x44">
  <m id="m714-d1t451-16">
   <w.rf>
    <LM>w#w-d1t451-16</LM>
   </w.rf>
   <form>Nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t451-17">
   <w.rf>
    <LM>w#w-d1t451-17</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t451-18">
   <w.rf>
    <LM>w#w-d1t451-18</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t451-19">
   <w.rf>
    <LM>w#w-d1t451-19</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t451-20">
   <w.rf>
    <LM>w#w-d1t451-20</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t451-21">
   <w.rf>
    <LM>w#w-d1t451-21</LM>
   </w.rf>
   <form>hotelu</form>
   <lemma>hotel</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t451-22">
   <w.rf>
    <LM>w#w-d1t451-22</LM>
   </w.rf>
   <form>Opera</form>
   <lemma>opera</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d-id81976">
   <w.rf>
    <LM>w#w-d-id81976</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t456-1">
   <w.rf>
    <LM>w#w-d1t456-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t456-2">
   <w.rf>
    <LM>w#w-d1t456-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t456-3">
   <w.rf>
    <LM>w#w-d1t456-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t456-4">
   <w.rf>
    <LM>w#w-d1t456-4</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t456-5">
   <w.rf>
    <LM>w#w-d1t456-5</LM>
   </w.rf>
   <form>někým</form>
   <lemma>někdo</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m714-d1t456-6">
   <w.rf>
    <LM>w#w-d1t456-6</LM>
   </w.rf>
   <form>seznámila</form>
   <lemma>seznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x44-69">
   <w.rf>
    <LM>w#w-d1e24-x44-69</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-71">
  <m id="m714-d1t460-3">
   <w.rf>
    <LM>w#w-d1t460-3</LM>
   </w.rf>
   <form>Chtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t460-2">
   <w.rf>
    <LM>w#w-d1t460-2</LM>
   </w.rf>
   <form>bych</form>
   <lemma>být</lemma>
   <tag>Vc----------Ic-</tag>
  </m>
  <m id="m714-d1t460-4">
   <w.rf>
    <LM>w#w-d1t460-4</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t460-5">
   <w.rf>
    <LM>w#w-d1t460-5</LM>
   </w.rf>
   <form>vědět</form>
   <lemma>vědět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d-id82193">
   <w.rf>
    <LM>w#w-d-id82193</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t460-7">
   <w.rf>
    <LM>w#w-d1t460-7</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t460-8">
   <w.rf>
    <LM>w#w-d1t460-8</LM>
   </w.rf>
   <form>žije</form>
   <lemma>žít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d-id82232">
   <w.rf>
    <LM>w#w-d-id82232</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x45">
  <m id="m714-d1t467-2">
   <w.rf>
    <LM>w#w-d1t467-2</LM>
   </w.rf>
   <form>Bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t467-3">
   <w.rf>
    <LM>w#w-d1t467-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t467-4">
   <w.rf>
    <LM>w#w-d1t467-4</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t467-5">
   <w.rf>
    <LM>w#w-d1t467-5</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t467-6">
   <w.rf>
    <LM>w#w-d1t467-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t467-7">
   <w.rf>
    <LM>w#w-d1t467-7</LM>
   </w.rf>
   <form>Karlíně</form>
   <lemma>Karlín_;G</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t467-8">
   <w.rf>
    <LM>w#w-d1t467-8</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t467-9">
   <w.rf>
    <LM>w#w-d1t467-9</LM>
   </w.rf>
   <form>podnájmu</form>
   <lemma>podnájem</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t467-12">
   <w.rf>
    <LM>w#w-d1t467-12</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t467-13">
   <w.rf>
    <LM>w#w-d1t467-13</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS7----------</tag>
  </m>
  <m id="m714-d1t467-14">
   <w.rf>
    <LM>w#w-d1t467-14</LM>
   </w.rf>
   <form>kamarádkou</form>
   <lemma>kamarádka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m714-d1e24-x45-222">
   <w.rf>
    <LM>w#w-d1e24-x45-222</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t471-1">
   <w.rf>
    <LM>w#w-d1t471-1</LM>
   </w.rf>
   <form>taky</form>
   <lemma>taky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t471-2">
   <w.rf>
    <LM>w#w-d1t471-2</LM>
   </w.rf>
   <form>zajímavá</form>
   <lemma>zajímavý</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d1t471-3">
   <w.rf>
    <LM>w#w-d1t471-3</LM>
   </w.rf>
   <form>osobnost</form>
   <lemma>osobnost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x45-226">
   <w.rf>
    <LM>w#w-d1e24-x45-226</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t469-1">
   <w.rf>
    <LM>w#w-d1t469-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t469-2">
   <w.rf>
    <LM>w#w-d1t469-2</LM>
   </w.rf>
   <form>odtamtud</form>
   <lemma>odtamtud</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t469-3">
   <w.rf>
    <LM>w#w-d1t469-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t469-4">
   <w.rf>
    <LM>w#w-d1t469-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t467-15">
   <w.rf>
    <LM>w#w-d1t467-15</LM>
   </w.rf>
   <form>potom</form>
   <lemma>potom</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t469-5">
   <w.rf>
    <LM>w#w-d1t469-5</LM>
   </w.rf>
   <form>nastěhovali</form>
   <lemma>nastěhovat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m714-d1t471-4">
   <w.rf>
    <LM>w#w-d1t471-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t471-5">
   <w.rf>
    <LM>w#w-d1t471-5</LM>
   </w.rf>
   <form>Budečskou</form>
   <lemma>Budečská_;G_^(ulice)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t471-6">
   <w.rf>
    <LM>w#w-d1t471-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t471-7">
   <w.rf>
    <LM>w#w-d1t471-7</LM>
   </w.rf>
   <form>Vinohradech</form>
   <lemma>Vinohrady_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m714-d1t473-1">
   <w.rf>
    <LM>w#w-d1t473-1</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t473-2">
   <w.rf>
    <LM>w#w-d1t473-2</LM>
   </w.rf>
   <form>manželce</form>
   <lemma>manželka_^(*2)</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m714-d1t473-3">
   <w.rf>
    <LM>w#w-d1t473-3</LM>
   </w.rf>
   <form>generála</form>
   <lemma>generál</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m714-d1t473-4">
   <w.rf>
    <LM>w#w-d1t473-4</LM>
   </w.rf>
   <form>Syrového</form>
   <lemma>Syrový_;Y</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m714-d-id82775">
   <w.rf>
    <LM>w#w-d-id82775</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x46">
  <m id="m714-d1t480-3">
   <w.rf>
    <LM>w#w-d1t480-3</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t480-4">
   <w.rf>
    <LM>w#w-d1t480-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m714-d1t480-5">
   <w.rf>
    <LM>w#w-d1t480-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1t480-2">
   <w.rf>
    <LM>w#w-d1t480-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t480-6">
   <w.rf>
    <LM>w#w-d1t480-6</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t480-7">
   <w.rf>
    <LM>w#w-d1t480-7</LM>
   </w.rf>
   <form>zavřený</form>
   <lemma>zavřený_^(*3ít)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1e24-x46-80">
   <w.rf>
    <LM>w#w-d1e24-x46-80</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-81">
  <m id="m714-d1t482-1">
   <w.rf>
    <LM>w#w-d1t482-1</LM>
   </w.rf>
   <form>Ani</form>
   <lemma>ani-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t482-2">
   <w.rf>
    <LM>w#w-d1t482-2</LM>
   </w.rf>
   <form>nevím</form>
   <lemma>vědět</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d-id82965">
   <w.rf>
    <LM>w#w-d-id82965</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t482-4">
   <w.rf>
    <LM>w#w-d1t482-4</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t482-5">
   <w.rf>
    <LM>w#w-d1t482-5</LM>
   </w.rf>
   <form>skončil</form>
   <lemma>skončit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d-id83005">
   <w.rf>
    <LM>w#w-d-id83005</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t482-7">
   <w.rf>
    <LM>w#w-d1t482-7</LM>
   </w.rf>
   <form>jestli</form>
   <lemma>jestli</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t482-14">
   <w.rf>
    <LM>w#w-d1t482-14</LM>
   </w.rf>
   <form>vězení</form>
   <lemma>vězení_^(místo_výkonu_trestu)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d1t482-8">
   <w.rf>
    <LM>w#w-d1t482-8</LM>
   </w.rf>
   <form>přežil</form>
   <lemma>přežít</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t482-15">
   <w.rf>
    <LM>w#w-d1t482-15</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t482-16">
   <w.rf>
    <LM>w#w-d1t482-16</LM>
   </w.rf>
   <form>nepřežil</form>
   <lemma>přežít</lemma>
   <tag>VpYS----R-NAP--</tag>
  </m>
  <m id="m714-81-82">
   <w.rf>
    <LM>w#w-81-82</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-83">
  <m id="m714-d1t482-18">
   <w.rf>
    <LM>w#w-d1t482-18</LM>
   </w.rf>
   <form>Myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d-id83166">
   <w.rf>
    <LM>w#w-d-id83166</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t482-20">
   <w.rf>
    <LM>w#w-d1t482-20</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t482-22">
   <w.rf>
    <LM>w#w-d1t482-22</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t482-21">
   <w.rf>
    <LM>w#w-d1t482-21</LM>
   </w.rf>
   <form>dostal</form>
   <lemma>dostat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t482-23">
   <w.rf>
    <LM>w#w-d1t482-23</LM>
   </w.rf>
   <form>dvacet</form>
   <lemma>dvacet`20</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m714-d1t482-24">
   <w.rf>
    <LM>w#w-d1t482-24</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m714-d1e24-x46-412">
   <w.rf>
    <LM>w#w-d1e24-x46-412</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t482-25">
   <w.rf>
    <LM>w#w-d1t482-25</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t482-26">
   <w.rf>
    <LM>w#w-d1t482-26</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m714-d1t482-27">
   <w.rf>
    <LM>w#w-d1t482-27</LM>
   </w.rf>
   <form>dojem</form>
   <lemma>dojem</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x46-414">
   <w.rf>
    <LM>w#w-d1e24-x46-414</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-415">
  <m id="m714-d1t484-3">
   <w.rf>
    <LM>w#w-d1t484-3</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t484-4">
   <w.rf>
    <LM>w#w-d1t484-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t484-5">
   <w.rf>
    <LM>w#w-d1t484-5</LM>
   </w.rf>
   <form>bydlely</form>
   <lemma>bydlet</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t484-6">
   <w.rf>
    <LM>w#w-d1t484-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t484-8">
   <w.rf>
    <LM>w#w-d1t484-8</LM>
   </w.rf>
   <form>Eliškou</form>
   <lemma>Eliška_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m714-415-435">
   <w.rf>
    <LM>w#w-415-435</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t484-10">
   <w.rf>
    <LM>w#w-d1t484-10</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t484-11">
   <w.rf>
    <LM>w#w-d1t484-11</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t484-12">
   <w.rf>
    <LM>w#w-d1t484-12</LM>
   </w.rf>
   <form>Moravy</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d1t484-13">
   <w.rf>
    <LM>w#w-d1t484-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t484-14">
   <w.rf>
    <LM>w#w-d1t484-14</LM>
   </w.rf>
   <form>jezdily</form>
   <lemma>jezdit</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m714-d1t484-15">
   <w.rf>
    <LM>w#w-d1t484-15</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t484-16">
   <w.rf>
    <LM>w#w-d1t484-16</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t484-17">
   <w.rf>
    <LM>w#w-d1t484-17</LM>
   </w.rf>
   <form>jejím</form>
   <lemma>jeho</lemma>
   <tag>P9XP3FS3-------</tag>
  </m>
  <m id="m714-d1t484-18">
   <w.rf>
    <LM>w#w-d1t484-18</LM>
   </w.rf>
   <form>rodičům</form>
   <lemma>rodič</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m714-d1t484-19">
   <w.rf>
    <LM>w#w-d1t484-19</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t484-20">
   <w.rf>
    <LM>w#w-d1t484-20</LM>
   </w.rf>
   <form>Moravu</form>
   <lemma>Morava_;G</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t484-21">
   <w.rf>
    <LM>w#w-d1t484-21</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t484-22">
   <w.rf>
    <LM>w#w-d1t484-22</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t484-23">
   <w.rf>
    <LM>w#w-d1t484-23</LM>
   </w.rf>
   <form>porůznu</form>
   <lemma>porůznu</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d-id83667">
   <w.rf>
    <LM>w#w-d-id83667</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x48">
  <m id="m714-d1t490-1">
   <w.rf>
    <LM>w#w-d1t490-1</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t490-8">
   <w.rf>
    <LM>w#w-d1t490-8</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t490-9">
   <w.rf>
    <LM>w#w-d1t490-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t490-7">
   <w.rf>
    <LM>w#w-d1t490-7</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t490-10">
   <w.rf>
    <LM>w#w-d1t490-10</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jednou-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t490-11">
   <w.rf>
    <LM>w#w-d1t490-11</LM>
   </w.rf>
   <form>zamilovala</form>
   <lemma>zamilovat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t493-1">
   <w.rf>
    <LM>w#w-d1t493-1</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t493-2">
   <w.rf>
    <LM>w#w-d1t493-2</LM>
   </w.rf>
   <form>nějakého</form>
   <lemma>nějaký</lemma>
   <tag>PZZS2----------</tag>
  </m>
  <m id="m714-d1t493-3">
   <w.rf>
    <LM>w#w-d1t493-3</LM>
   </w.rf>
   <form>mladého</form>
   <lemma>mladý</lemma>
   <tag>AAMS2----1A----</tag>
  </m>
  <m id="m714-d1t493-4">
   <w.rf>
    <LM>w#w-d1t493-4</LM>
   </w.rf>
   <form>kluka</form>
   <lemma>kluk</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m714-d-id84044">
   <w.rf>
    <LM>w#w-d-id84044</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t495-1">
   <w.rf>
    <LM>w#w-d1t495-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t495-2">
   <w.rf>
    <LM>w#w-d1t495-2</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m714-d1t495-3">
   <w.rf>
    <LM>w#w-d1t495-3</LM>
   </w.rf>
   <form>potřeboval</form>
   <lemma>potřebovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t495-4">
   <w.rf>
    <LM>w#w-d1t495-4</LM>
   </w.rf>
   <form>jet</form>
   <lemma>jet-1</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d1t495-5">
   <w.rf>
    <LM>w#w-d1t495-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t495-6">
   <w.rf>
    <LM>w#w-d1t495-6</LM>
   </w.rf>
   <form>Slovensko</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d-id84154">
   <w.rf>
    <LM>w#w-d-id84154</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t495-9">
   <w.rf>
    <LM>w#w-d1t495-9</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t495-10">
   <w.rf>
    <LM>w#w-d1t495-10</LM>
   </w.rf>
   <form>ze</form>
   <lemma>z-1</lemma>
   <tag>RV--2----------</tag>
  </m>
  <m id="m714-d1t495-11">
   <w.rf>
    <LM>w#w-d1t495-11</LM>
   </w.rf>
   <form>Slovenska</form>
   <lemma>Slovensko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m714-d-id84204">
   <w.rf>
    <LM>w#w-d-id84204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x49">
  <m id="m714-d1t501-3">
   <w.rf>
    <LM>w#w-d1t501-3</LM>
   </w.rf>
   <form>Zapomněla</form>
   <lemma>zapomenout</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t501-4">
   <w.rf>
    <LM>w#w-d1t501-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x49-107">
   <w.rf>
    <LM>w#w-d1e24-x49-107</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x49-108">
   <w.rf>
    <LM>w#w-d1e24-x49-108</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x49-109">
   <w.rf>
    <LM>w#w-d1e24-x49-109</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-110">
  <m id="m714-d1t501-5">
   <w.rf>
    <LM>w#w-d1t501-5</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-110-111">
   <w.rf>
    <LM>w#w-110-111</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t501-6">
   <w.rf>
    <LM>w#w-d1t501-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>to-1_^(tehdy;to_jsem_byla_ještě_malá)</lemma>
   <tag>PDXXX----------</tag>
  </m>
  <m id="m714-d1t501-7">
   <w.rf>
    <LM>w#w-d1t501-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t501-9">
   <w.rf>
    <LM>w#w-d1t501-9</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m714-d1t501-8">
   <w.rf>
    <LM>w#w-d1t501-8</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t501-10">
   <w.rf>
    <LM>w#w-d1t501-10</LM>
   </w.rf>
   <form>neměla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m714-110-112">
   <w.rf>
    <LM>w#w-110-112</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-114">
  <m id="m714-d1t503-2">
   <w.rf>
    <LM>w#w-d1t503-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m714-d1e24-x49-5371">
   <w.rf>
    <LM>w#w-d1e24-x49-5371</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t503-4">
   <w.rf>
    <LM>w#w-d1t503-4</LM>
   </w.rf>
   <form>horká</form>
   <lemma>horký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m714-d1t503-5">
   <w.rf>
    <LM>w#w-d1t503-5</LM>
   </w.rf>
   <form>hlava</form>
   <lemma>hlava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d-id84476">
   <w.rf>
    <LM>w#w-d-id84476</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t503-8">
   <w.rf>
    <LM>w#w-d1t503-8</LM>
   </w.rf>
   <form>pojedu</form>
   <lemma>jet-1</lemma>
   <tag>VB-S---1F-AAI--</tag>
  </m>
  <m id="m714-d1t503-9">
   <w.rf>
    <LM>w#w-d1t503-9</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t503-10">
   <w.rf>
    <LM>w#w-d1t503-10</LM>
   </w.rf>
   <form>ním</form>
   <lemma>on-1</lemma>
   <tag>PEZS7--3------1</tag>
  </m>
  <m id="m714-d-id84546">
   <w.rf>
    <LM>w#w-d-id84546</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x50">
  <m id="m714-d1t508-1">
   <w.rf>
    <LM>w#w-d1t508-1</LM>
   </w.rf>
   <form>Letadlo</form>
   <lemma>letadlo</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-d1t510-1">
   <w.rf>
    <LM>w#w-d1t510-1</LM>
   </w.rf>
   <form>Dakota</form>
   <lemma>dakota-1_^(typ_letadla)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t510-5">
   <w.rf>
    <LM>w#w-d1t510-5</LM>
   </w.rf>
   <form>hrkalo</form>
   <lemma>hrkat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x50-835">
   <w.rf>
    <LM>w#w-d1e24-x50-835</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t510-7">
   <w.rf>
    <LM>w#w-d1t510-7</LM>
   </w.rf>
   <form>zvracela</form>
   <lemma>zvracet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x50-121">
   <w.rf>
    <LM>w#w-d1e24-x50-121</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x50-836">
   <w.rf>
    <LM>w#w-d1e24-x50-836</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x50-122">
   <w.rf>
    <LM>w#w-d1e24-x50-122</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x50-123">
   <w.rf>
    <LM>w#w-d1e24-x50-123</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m714-d1t516-1">
   <w.rf>
    <LM>w#w-d1t516-1</LM>
   </w.rf>
   <form>zle</form>
   <lemma>zle_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1e24-x50-124">
   <w.rf>
    <LM>w#w-d1e24-x50-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-126">
  <m id="m714-d1t521-4">
   <w.rf>
    <LM>w#w-d1t521-4</LM>
   </w.rf>
   <form>Byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t521-5">
   <w.rf>
    <LM>w#w-d1t521-5</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t521-8">
   <w.rf>
    <LM>w#w-d1t521-8</LM>
   </w.rf>
   <form>Prešova</form>
   <lemma>Prešov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d1t521-10">
   <w.rf>
    <LM>w#w-d1t521-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t521-11">
   <w.rf>
    <LM>w#w-d1t521-11</LM>
   </w.rf>
   <form>letiště</form>
   <lemma>letiště</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m714-d1t521-12">
   <w.rf>
    <LM>w#w-d1t521-12</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t521-13">
   <w.rf>
    <LM>w#w-d1t521-13</LM>
   </w.rf>
   <form>myslím</form>
   <lemma>myslit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x50-841">
   <w.rf>
    <LM>w#w-d1e24-x50-841</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t521-14">
   <w.rf>
    <LM>w#w-d1t521-14</LM>
   </w.rf>
   <form>Košicích</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP6-----A----</tag>
  </m>
  <m id="m714-126-127">
   <w.rf>
    <LM>w#w-126-127</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-129">
  <m id="m714-d1t519-1">
   <w.rf>
    <LM>w#w-d1t519-1</LM>
   </w.rf>
   <form>Přijela</form>
   <lemma>přijet</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t519-2">
   <w.rf>
    <LM>w#w-d1t519-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t519-3">
   <w.rf>
    <LM>w#w-d1t519-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t525-2">
   <w.rf>
    <LM>w#w-d1t525-2</LM>
   </w.rf>
   <form>Košic</form>
   <lemma>Košice_;G</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m714-d1t527-1">
   <w.rf>
    <LM>w#w-d1t527-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t527-2">
   <w.rf>
    <LM>w#w-d1t527-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t527-3">
   <w.rf>
    <LM>w#w-d1t527-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t527-11">
   <w.rf>
    <LM>w#w-d1t527-11</LM>
   </w.rf>
   <form>Prešova</form>
   <lemma>Prešov_;G</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m714-d-id85293">
   <w.rf>
    <LM>w#w-d-id85293</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x52">
  <m id="m714-d1t532-4">
   <w.rf>
    <LM>w#w-d1t532-4</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-5">
   <w.rf>
    <LM>w#w-d1t532-5</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t532-6">
   <w.rf>
    <LM>w#w-d1t532-6</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-d1t532-7">
   <w.rf>
    <LM>w#w-d1t532-7</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-8">
   <w.rf>
    <LM>w#w-d1t532-8</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m714-d1t532-9">
   <w.rf>
    <LM>w#w-d1t532-9</LM>
   </w.rf>
   <form>hudbě</form>
   <lemma>hudba</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m714-d1t532-10">
   <w.rf>
    <LM>w#w-d1t532-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t532-11">
   <w.rf>
    <LM>w#w-d1t532-11</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-12">
   <w.rf>
    <LM>w#w-d1t532-12</LM>
   </w.rf>
   <form>dále</form>
   <lemma>dále-3_^(také,_za_další)</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-13">
   <w.rf>
    <LM>w#w-d1t532-13</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t532-14">
   <w.rf>
    <LM>w#w-d1t532-14</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t532-15">
   <w.rf>
    <LM>w#w-d1t532-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t532-16">
   <w.rf>
    <LM>w#w-d1t532-16</LM>
   </w.rf>
   <form>hrozně</form>
   <lemma>hrozně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t532-17">
   <w.rf>
    <LM>w#w-d1t532-17</LM>
   </w.rf>
   <form>líbila</form>
   <lemma>líbit</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t532-18">
   <w.rf>
    <LM>w#w-d1t532-18</LM>
   </w.rf>
   <form>písnička</form>
   <lemma>písnička</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t532-19">
   <w.rf>
    <LM>w#w-d1t532-19</LM>
   </w.rf>
   <form>Miluška</form>
   <lemma>Miluška_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1t532-20">
   <w.rf>
    <LM>w#w-d1t532-20</LM>
   </w.rf>
   <form>moja</form>
   <lemma>moja-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m714-d1e24-x52-133">
   <w.rf>
    <LM>w#w-d1e24-x52-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-134">
  <m id="m714-d1t532-24">
   <w.rf>
    <LM>w#w-d1t532-24</LM>
   </w.rf>
   <form>Nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t532-22">
   <w.rf>
    <LM>w#w-d1t532-22</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t532-23">
   <w.rf>
    <LM>w#w-d1t532-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t532-25">
   <w.rf>
    <LM>w#w-d1t532-25</LM>
   </w.rf>
   <form>celý</form>
   <lemma>celý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m714-d1t532-26">
   <w.rf>
    <LM>w#w-d1t532-26</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-1</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d1t532-27">
   <w.rf>
    <LM>w#w-d1t532-27</LM>
   </w.rf>
   <form>vyhrávat</form>
   <lemma>vyhrávat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d-id85724">
   <w.rf>
    <LM>w#w-d-id85724</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t532-29">
   <w.rf>
    <LM>w#w-d1t532-29</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-2_^(přijde,_až_to_dodělá)</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t532-30">
   <w.rf>
    <LM>w#w-d1t532-30</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t532-31">
   <w.rf>
    <LM>w#w-d1t532-31</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t532-32">
   <w.rf>
    <LM>w#w-d1t532-32</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-33">
   <w.rf>
    <LM>w#w-d1t532-33</LM>
   </w.rf>
   <form>zprotivila</form>
   <lemma>zprotivit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x52-1123">
   <w.rf>
    <LM>w#w-d1e24-x52-1123</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t532-34">
   <w.rf>
    <LM>w#w-d1t532-34</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t532-35">
   <w.rf>
    <LM>w#w-d1t532-35</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t532-36">
   <w.rf>
    <LM>w#w-d1t532-36</LM>
   </w.rf>
   <form>sem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI-6</tag>
  </m>
  <m id="m714-d1t532-37">
   <w.rf>
    <LM>w#w-d1t532-37</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m714-d1t532-38">
   <w.rf>
    <LM>w#w-d1t532-38</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t532-39">
   <w.rf>
    <LM>w#w-d1t532-39</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t532-40">
   <w.rf>
    <LM>w#w-d1t532-40</LM>
   </w.rf>
   <form>nechtěla</form>
   <lemma>chtít</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m714-d1t532-41">
   <w.rf>
    <LM>w#w-d1t532-41</LM>
   </w.rf>
   <form>slyšet</form>
   <lemma>slyšet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-d-id85908">
   <w.rf>
    <LM>w#w-d-id85908</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x53">
  <m id="m714-d1t536-3">
   <w.rf>
    <LM>w#w-d1t536-3</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t536-4">
   <w.rf>
    <LM>w#w-d1t536-4</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d1e24-x53-1263">
   <w.rf>
    <LM>w#w-d1e24-x53-1263</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t536-5">
   <w.rf>
    <LM>w#w-d1t536-5</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t536-6">
   <w.rf>
    <LM>w#w-d1t536-6</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t536-7">
   <w.rf>
    <LM>w#w-d1t536-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t536-8">
   <w.rf>
    <LM>w#w-d1t536-8</LM>
   </w.rf>
   <form>letěla</form>
   <lemma>letět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d-id86064">
   <w.rf>
    <LM>w#w-d-id86064</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t536-10">
   <w.rf>
    <LM>w#w-d1t536-10</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t536-11">
   <w.rf>
    <LM>w#w-d1t536-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t536-12">
   <w.rf>
    <LM>w#w-d1t536-12</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t536-13">
   <w.rf>
    <LM>w#w-d1t536-13</LM>
   </w.rf>
   <form>seznámila</form>
   <lemma>seznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t536-18">
   <w.rf>
    <LM>w#w-d1t536-18</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t536-19">
   <w.rf>
    <LM>w#w-d1t536-19</LM>
   </w.rf>
   <form>nějakým</form>
   <lemma>nějaký</lemma>
   <tag>PZZS7----------</tag>
  </m>
  <m id="m714-d1t536-20">
   <w.rf>
    <LM>w#w-d1t536-20</LM>
   </w.rf>
   <form>stavitelem</form>
   <lemma>stavitel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m714-d-id86236">
   <w.rf>
    <LM>w#w-d-id86236</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t540-1">
   <w.rf>
    <LM>w#w-d1t540-1</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m714-d1t540-2">
   <w.rf>
    <LM>w#w-d1t540-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t540-3">
   <w.rf>
    <LM>w#w-d1t540-3</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t540-4">
   <w.rf>
    <LM>w#w-d1t540-4</LM>
   </w.rf>
   <form>milý</form>
   <lemma>milý-1_^(příjemný)</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t540-5">
   <w.rf>
    <LM>w#w-d1t540-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t540-7">
   <w.rf>
    <LM>w#w-d1t540-7</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDYS1----------</tag>
  </m>
  <m id="m714-d1t540-6">
   <w.rf>
    <LM>w#w-d1t540-6</LM>
   </w.rf>
   <form>velice</form>
   <lemma>velice</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t542-1">
   <w.rf>
    <LM>w#w-d1t542-1</LM>
   </w.rf>
   <form>přítulný</form>
   <lemma>přítulný</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-d1t542-2">
   <w.rf>
    <LM>w#w-d1t542-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t542-3">
   <w.rf>
    <LM>w#w-d1t542-3</LM>
   </w.rf>
   <form>řeči</form>
   <lemma>řeč</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id86413">
   <w.rf>
    <LM>w#w-d-id86413</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-147">
  <m id="m714-d1t536-14">
   <w.rf>
    <LM>w#w-d1t536-14</LM>
   </w.rf>
   <form>Proč</form>
   <lemma>proč</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t536-15">
   <w.rf>
    <LM>w#w-d1t536-15</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t536-16">
   <w.rf>
    <LM>w#w-d1t536-16</LM>
   </w.rf>
   <form>vykládám</form>
   <lemma>vykládat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-147-149">
   <w.rf>
    <LM>w#w-147-149</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x54">
  <m id="m714-d1e24-x54-1385">
   <w.rf>
    <LM>w#w-d1e24-x54-1385</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t549-1">
   <w.rf>
    <LM>w#w-d1t549-1</LM>
   </w.rf>
   <form>Kdybyste</form>
   <lemma>kdyby</lemma>
   <tag>J,-----------e-</tag>
  </m>
  <m id="m714-d1t549-2">
   <w.rf>
    <LM>w#w-d1t549-2</LM>
   </w.rf>
   <form>hledala</form>
   <lemma>hledat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t549-3">
   <w.rf>
    <LM>w#w-d1t549-3</LM>
   </w.rf>
   <form>někdy</form>
   <lemma>někdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t549-4">
   <w.rf>
    <LM>w#w-d1t549-4</LM>
   </w.rf>
   <form>místo</form>
   <lemma>místo-1_^(fyzické_umístění)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m714-d-id86533">
   <w.rf>
    <LM>w#w-d-id86533</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t549-7">
   <w.rf>
    <LM>w#w-d1t549-7</LM>
   </w.rf>
   <form>potřebuju</form>
   <lemma>potřebovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t549-9">
   <w.rf>
    <LM>w#w-d1t549-9</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t549-10">
   <w.rf>
    <LM>w#w-d1t549-10</LM>
   </w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m714-d1t549-11">
   <w.rf>
    <LM>w#w-d1t549-11</LM>
   </w.rf>
   <form>sekretářku</form>
   <lemma>sekretářka-2_^(*4-2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x54-154">
   <w.rf>
    <LM>w#w-d1e24-x54-154</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x54-1388">
   <w.rf>
    <LM>w#w-d1e24-x54-1388</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-156">
  <m id="m714-d1t549-18">
   <w.rf>
    <LM>w#w-d1t549-18</LM>
   </w.rf>
   <form>Řekla</form>
   <lemma>říci</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t549-17">
   <w.rf>
    <LM>w#w-d1t549-17</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-156-157">
   <w.rf>
    <LM>w#w-156-157</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x54-1389">
   <w.rf>
    <LM>w#w-d1e24-x54-1389</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t549-21">
   <w.rf>
    <LM>w#w-d1t549-21</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1e24-x54-5742">
   <w.rf>
    <LM>w#w-d1e24-x54-5742</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t549-22">
   <w.rf>
    <LM>w#w-d1t549-22</LM>
   </w.rf>
   <form>vůbec</form>
   <lemma>vůbec</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d1t549-23">
   <w.rf>
    <LM>w#w-d1t549-23</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m714-d-id86793">
   <w.rf>
    <LM>w#w-d-id86793</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x54-1390">
   <w.rf>
    <LM>w#w-d1e24-x54-1390</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x55">
  <m id="m714-d1t553-3">
   <w.rf>
    <LM>w#w-d1t553-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t553-4">
   <w.rf>
    <LM>w#w-d1t553-4</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t553-5">
   <w.rf>
    <LM>w#w-d1t553-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t553-2">
   <w.rf>
    <LM>w#w-d1t553-2</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t553-6">
   <w.rf>
    <LM>w#w-d1t553-6</LM>
   </w.rf>
   <form>nedalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-NAP--</tag>
  </m>
  <m id="m714-d-id86912">
   <w.rf>
    <LM>w#w-d-id86912</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t553-8">
   <w.rf>
    <LM>w#w-d1t553-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t553-9">
   <w.rf>
    <LM>w#w-d1t553-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t553-10">
   <w.rf>
    <LM>w#w-d1t553-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t553-12">
   <w.rf>
    <LM>w#w-d1t553-12</LM>
   </w.rf>
   <form>mu</form>
   <lemma>on-1</lemma>
   <tag>P5ZS3--3-------</tag>
  </m>
  <m id="m714-d1t553-13">
   <w.rf>
    <LM>w#w-d1t553-13</LM>
   </w.rf>
   <form>ozvala</form>
   <lemma>ozvat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1e24-x55-162">
   <w.rf>
    <LM>w#w-d1e24-x55-162</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-163">
  <m id="m714-d1t553-15">
   <w.rf>
    <LM>w#w-d1t553-15</LM>
   </w.rf>
   <form>Nakonec</form>
   <lemma>nakonec-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t553-16">
   <w.rf>
    <LM>w#w-d1t553-16</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t553-17">
   <w.rf>
    <LM>w#w-d1t553-17</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m714-d1t553-18">
   <w.rf>
    <LM>w#w-d1t553-18</LM>
   </w.rf>
   <form>něho</form>
   <lemma>on-1</lemma>
   <tag>PEZS2--3------1</tag>
  </m>
  <m id="m714-d1t553-19">
   <w.rf>
    <LM>w#w-d1t553-19</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t553-20">
   <w.rf>
    <LM>w#w-d1t553-20</LM>
   </w.rf>
   <form>sekretářku</form>
   <lemma>sekretářka-2_^(*4-2)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x55-1604">
   <w.rf>
    <LM>w#w-d1e24-x55-1604</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t553-21">
   <w.rf>
    <LM>w#w-d1t553-21</LM>
   </w.rf>
   <form>aniž</form>
   <lemma>aniž</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m714-d1t553-22">
   <w.rf>
    <LM>w#w-d1t553-22</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t553-23">
   <w.rf>
    <LM>w#w-d1t553-23</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t553-24">
   <w.rf>
    <LM>w#w-d1t553-24</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t553-25">
   <w.rf>
    <LM>w#w-d1t553-25</LM>
   </w.rf>
   <form>životě</form>
   <lemma>život</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-d1t553-26">
   <w.rf>
    <LM>w#w-d1t553-26</LM>
   </w.rf>
   <form>dělala</form>
   <lemma>dělat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d-id87181">
   <w.rf>
    <LM>w#w-d-id87181</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t553-29">
   <w.rf>
    <LM>w#w-d1t553-29</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t553-30">
   <w.rf>
    <LM>w#w-d1t553-30</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t553-31">
   <w.rf>
    <LM>w#w-d1t553-31</LM>
   </w.rf>
   <form>není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m714-d1t553-32">
   <w.rf>
    <LM>w#w-d1t553-32</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t553-33">
   <w.rf>
    <LM>w#w-d1t553-33</LM>
   </w.rf>
   <form>těžké</form>
   <lemma>těžký</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m714-d1t553-35">
   <w.rf>
    <LM>w#w-d1t553-35</LM>
   </w.rf>
   <form>naučit</form>
   <lemma>naučit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m714-d1t553-34">
   <w.rf>
    <LM>w#w-d1t553-34</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t553-36">
   <w.rf>
    <LM>w#w-d1t553-36</LM>
   </w.rf>
   <form>takové</form>
   <lemma>takový</lemma>
   <tag>PDFP4----------</tag>
  </m>
  <m id="m714-d1t555-2">
   <w.rf>
    <LM>w#w-d1t555-2</LM>
   </w.rf>
   <form>věci</form>
   <lemma>věc</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m714-163-164">
   <w.rf>
    <LM>w#w-163-164</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-165">
  <m id="m714-d1t555-7">
   <w.rf>
    <LM>w#w-d1t555-7</LM>
   </w.rf>
   <form>Nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t555-8">
   <w.rf>
    <LM>w#w-d1t555-8</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t555-5">
   <w.rf>
    <LM>w#w-d1t555-5</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t555-6">
   <w.rf>
    <LM>w#w-d1t555-6</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t555-9">
   <w.rf>
    <LM>w#w-d1t555-9</LM>
   </w.rf>
   <form>pracovala</form>
   <lemma>pracovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1e24-x55-1613">
   <w.rf>
    <LM>w#w-d1e24-x55-1613</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-1614">
  <m id="m714-1614-1984">
   <w.rf>
    <LM>w#w-1614-1984</LM>
   </w.rf>
   <form>Pořád</form>
   <lemma>pořád</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-1614-1985">
   <w.rf>
    <LM>w#w-1614-1985</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-1614-1983">
   <w.rf>
    <LM>w#w-1614-1983</LM>
   </w.rf>
   <form>bydlela</form>
   <lemma>bydlet</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-1614-1982">
   <w.rf>
    <LM>w#w-1614-1982</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-1614-1981">
   <w.rf>
    <LM>w#w-1614-1981</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-1614-1979">
   <w.rf>
    <LM>w#w-1614-1979</LM>
   </w.rf>
   <form>podnájmu</form>
   <lemma>podnájem</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m714-1614-1978">
   <w.rf>
    <LM>w#w-1614-1978</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-1614-1976">
   <w.rf>
    <LM>w#w-1614-1976</LM>
   </w.rf>
   <form>Eliškou</form>
   <lemma>Eliška_;Y</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m714-1614-179">
   <w.rf>
    <LM>w#w-1614-179</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-182">
  <m id="m714-1614-1973">
   <w.rf>
    <LM>w#w-1614-1973</LM>
   </w.rf>
   <form>On</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m714-1614-1972">
   <w.rf>
    <LM>w#w-1614-1972</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-1614-1971">
   <w.rf>
    <LM>w#w-1614-1971</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m714-1614-1970">
   <w.rf>
    <LM>w#w-1614-1970</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-1614-1969">
   <w.rf>
    <LM>w#w-1614-1969</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-1614-1967">
   <w.rf>
    <LM>w#w-1614-1967</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-1614-1966">
   <w.rf>
    <LM>w#w-1614-1966</LM>
   </w.rf>
   <form>ženatý</form>
   <lemma>ženatý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m714-182-183">
   <w.rf>
    <LM>w#w-182-183</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-184">
  <m id="m714-1614-1964">
   <w.rf>
    <LM>w#w-1614-1964</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-1614-1959">
   <w.rf>
    <LM>w#w-1614-1959</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-1614-1958">
   <w.rf>
    <LM>w#w-1614-1958</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>Vojtěšské</form>
   <lemma>vojtěšský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-1614-1957">
   <w.rf>
    <LM>w#w-1614-1957</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-1614-1956">
   <w.rf>
    <LM>w#w-1614-1956</LM>
   </w.rf>
   <form>mezinárodní</form>
   <lemma>mezinárodní</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m714-1614-1955">
   <w.rf>
    <LM>w#w-1614-1955</LM>
   </w.rf>
   <form>svaz</form>
   <lemma>svaz</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-1614-1954">
   <w.rf>
    <LM>w#w-1614-1954</LM>
   </w.rf>
   <form>studentstva</form>
   <lemma>studentstvo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m714-1614-1953">
   <w.rf>
    <LM>w#w-1614-1953</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-1614-1952">
   <w.rf>
    <LM>w#w-1614-1952</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-1614-1951">
   <w.rf>
    <LM>w#w-1614-1951</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-1614-1950">
   <w.rf>
    <LM>w#w-1614-1950</LM>
   </w.rf>
   <form>celé</form>
   <lemma>celý</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m714-1614-1949">
   <w.rf>
    <LM>w#w-1614-1949</LM>
   </w.rf>
   <form>budově</form>
   <lemma>budova</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-1614-1948">
   <w.rf>
    <LM>w#w-1614-1948</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-1614-1947">
   <w.rf>
    <LM>w#w-1614-1947</LM>
   </w.rf>
   <form>svoje</form>
   <lemma>svůj-1</lemma>
   <tag>P8XP4----------</tag>
  </m>
  <m id="m714-1614-1946">
   <w.rf>
    <LM>w#w-1614-1946</LM>
   </w.rf>
   <form>kanceláře</form>
   <lemma>kancelář</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m714-1614-1944">
   <w.rf>
    <LM>w#w-1614-1944</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-1614-1943">
   <w.rf>
    <LM>w#w-1614-1943</LM>
   </w.rf>
   <form>nahoře</form>
   <lemma>nahoře</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-1614-1942">
   <w.rf>
    <LM>w#w-1614-1942</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-1614-1941">
   <w.rf>
    <LM>w#w-1614-1941</LM>
   </w.rf>
   <form>několik</form>
   <lemma>několik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m714-1614-1940">
   <w.rf>
    <LM>w#w-1614-1940</LM>
   </w.rf>
   <form>garsonek</form>
   <lemma>garsonka</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m714-184-185">
   <w.rf>
    <LM>w#w-184-185</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-186">
  <m id="m714-1614-1937">
   <w.rf>
    <LM>w#w-1614-1937</LM>
   </w.rf>
   <form>Stavitel</form>
   <lemma>stavitel</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-1614-1936">
   <w.rf>
    <LM>w#w-1614-1936</LM>
   </w.rf>
   <form>Červenka</form>
   <lemma>Červenka_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-186-187">
   <w.rf>
    <LM>w#w-186-187</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-186-188">
   <w.rf>
    <LM>w#w-186-188</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-1614-1935">
   <w.rf>
    <LM>w#w-1614-1935</LM>
   </w.rf>
   <form>jednu</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS4----------</tag>
  </m>
  <m id="m714-1614-1934">
   <w.rf>
    <LM>w#w-1614-1934</LM>
   </w.rf>
   <form>garsonku</form>
   <lemma>garsonka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-1614-1933">
   <w.rf>
    <LM>w#w-1614-1933</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x57">
  <m id="m714-d1t584-4">
   <w.rf>
    <LM>w#w-d1t584-4</LM>
   </w.rf>
   <form>Vykládal</form>
   <lemma>vykládat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t584-2">
   <w.rf>
    <LM>w#w-d1t584-2</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t584-3">
   <w.rf>
    <LM>w#w-d1t584-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t584-5">
   <w.rf>
    <LM>w#w-d1t584-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t584-6">
   <w.rf>
    <LM>w#w-d1t584-6</LM>
   </w.rf>
   <form>říkám</form>
   <lemma>říkat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1e24-x57-2263">
   <w.rf>
    <LM>w#w-d1e24-x57-2263</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x57-2262">
   <w.rf>
    <LM>w#w-d1e24-x57-2262</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t584-12">
   <w.rf>
    <LM>w#w-d1t584-12</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t584-13">
   <w.rf>
    <LM>w#w-d1t584-13</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m714-d1t584-14">
   <w.rf>
    <LM>w#w-d1t584-14</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m714-d1t584-15">
   <w.rf>
    <LM>w#w-d1t584-15</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m714-d1t584-16">
   <w.rf>
    <LM>w#w-d1t584-16</LM>
   </w.rf>
   <form>garsonka</form>
   <lemma>garsonka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x57-2264">
   <w.rf>
    <LM>w#w-d1e24-x57-2264</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1e24-x57-2265">
   <w.rf>
    <LM>w#w-d1e24-x57-2265</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-2268">
  <m id="m714-2268-2275">
   <w.rf>
    <LM>w#w-2268-2275</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t584-19">
   <w.rf>
    <LM>w#w-d1t584-19</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m714-d1t584-20">
   <w.rf>
    <LM>w#w-d1t584-20</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-2268-2280">
   <w.rf>
    <LM>w#w-2268-2280</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m714-d1t584-23">
   <w.rf>
    <LM>w#w-d1t584-23</LM>
   </w.rf>
   <form>nějakou</form>
   <lemma>nějaký</lemma>
   <tag>PZFS4----------</tag>
  </m>
  <m id="m714-d1t584-24">
   <w.rf>
    <LM>w#w-d1t584-24</LM>
   </w.rf>
   <form>milenku</form>
   <lemma>milenka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t584-25">
   <w.rf>
    <LM>w#w-d1t584-25</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t584-26">
   <w.rf>
    <LM>w#w-d1t584-26</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-2268-196">
   <w.rf>
    <LM>w#w-2268-196</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-2268-197">
   <w.rf>
    <LM>w#w-2268-197</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-199">
  <m id="m714-d1t584-27">
   <w.rf>
    <LM>w#w-d1t584-27</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t584-30">
   <w.rf>
    <LM>w#w-d1t584-30</LM>
   </w.rf>
   <form>říkala</form>
   <lemma>říkat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t584-29">
   <w.rf>
    <LM>w#w-d1t584-29</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-2268-2285">
   <w.rf>
    <LM>w#w-2268-2285</LM>
   </w.rf>
   <form>:</form>
   <lemma>:</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-2268-2286">
   <w.rf>
    <LM>w#w-2268-2286</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t584-33">
   <w.rf>
    <LM>w#w-d1t584-33</LM>
   </w.rf>
   <form>Není</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-NAI--</tag>
  </m>
  <m id="m714-d1t584-34">
   <w.rf>
    <LM>w#w-d1t584-34</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t584-35">
   <w.rf>
    <LM>w#w-d1t584-35</LM>
   </w.rf>
   <form>škoda</form>
   <lemma>škoda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-199-200">
   <w.rf>
    <LM>w#w-199-200</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-201">
  <m id="m714-d1t584-38">
   <w.rf>
    <LM>w#w-d1t584-38</LM>
   </w.rf>
   <form>Nemám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-NAI--</tag>
  </m>
  <m id="m714-d1t584-39">
   <w.rf>
    <LM>w#w-d1t584-39</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t584-40">
   <w.rf>
    <LM>w#w-d1t584-40</LM>
   </w.rf>
   <form>bydlet</form>
   <lemma>bydlet</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m714-2268-2292">
   <w.rf>
    <LM>w#w-2268-2292</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-2268-2293">
   <w.rf>
    <LM>w#w-2268-2293</LM>
   </w.rf>
   <form>"</form>
   <lemma>"</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-2294">
  <m id="m714-d1t584-46">
   <w.rf>
    <LM>w#w-d1t584-46</LM>
   </w.rf>
   <form>Přesvědčila</form>
   <lemma>přesvědčit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t584-44">
   <w.rf>
    <LM>w#w-d1t584-44</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t584-45">
   <w.rf>
    <LM>w#w-d1t584-45</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m714-d1t586-1">
   <w.rf>
    <LM>w#w-d1t586-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t586-2">
   <w.rf>
    <LM>w#w-d1t586-2</LM>
   </w.rf>
   <form>on</form>
   <lemma>on-1</lemma>
   <tag>PEYS1--3-------</tag>
  </m>
  <m id="m714-d1t586-3">
   <w.rf>
    <LM>w#w-d1t586-3</LM>
   </w.rf>
   <form>mně</form>
   <lemma>já</lemma>
   <tag>PP-S3--1-------</tag>
  </m>
  <m id="m714-d1t586-5">
   <w.rf>
    <LM>w#w-d1t586-5</LM>
   </w.rf>
   <form>tu</form>
   <lemma>ten</lemma>
   <tag>PDFS4----------</tag>
  </m>
  <m id="m714-d1t586-6">
   <w.rf>
    <LM>w#w-d1t586-6</LM>
   </w.rf>
   <form>garsonku</form>
   <lemma>garsonka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1t586-4">
   <w.rf>
    <LM>w#w-d1t586-4</LM>
   </w.rf>
   <form>nechal</form>
   <lemma>nechat</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d-id89331">
   <w.rf>
    <LM>w#w-d-id89331</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t586-8">
   <w.rf>
    <LM>w#w-d1t586-8</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m714-d1t586-9">
   <w.rf>
    <LM>w#w-d1t586-9</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t586-10">
   <w.rf>
    <LM>w#w-d1t586-10</LM>
   </w.rf>
   <form>získala</form>
   <lemma>získat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t586-12">
   <w.rf>
    <LM>w#w-d1t586-12</LM>
   </w.rf>
   <form>svůj</form>
   <lemma>svůj-1</lemma>
   <tag>P8IS4----------</tag>
  </m>
  <m id="m714-d1t586-13">
   <w.rf>
    <LM>w#w-d1t586-13</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrIS4----------</tag>
  </m>
  <m id="m714-d1t586-14">
   <w.rf>
    <LM>w#w-d1t586-14</LM>
   </w.rf>
   <form>byt</form>
   <lemma>byt_^(místo_k_bydlení)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m714-d-id89449">
   <w.rf>
    <LM>w#w-d-id89449</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-d1e24-x58">
  <m id="m714-d1t590-1">
   <w.rf>
    <LM>w#w-d1t590-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t590-2">
   <w.rf>
    <LM>w#w-d1t590-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m714-d1t590-3">
   <w.rf>
    <LM>w#w-d1t590-3</LM>
   </w.rf>
   <form>garsonka</form>
   <lemma>garsonka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-2514">
   <w.rf>
    <LM>w#w-d1e24-x58-2514</LM>
   </w.rf>
   <form>-</form>
   <lemma>-</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t590-5">
   <w.rf>
    <LM>w#w-d1t590-5</LM>
   </w.rf>
   <form>koupelna</form>
   <lemma>koupelna</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-2517">
   <w.rf>
    <LM>w#w-d1e24-x58-2517</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t590-6">
   <w.rf>
    <LM>w#w-d1t590-6</LM>
   </w.rf>
   <form>pokoj</form>
   <lemma>pokoj</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-2518">
   <w.rf>
    <LM>w#w-d1e24-x58-2518</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t590-7">
   <w.rf>
    <LM>w#w-d1t590-7</LM>
   </w.rf>
   <form>předsíň</form>
   <lemma>předsíň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-6016">
   <w.rf>
    <LM>w#w-d1e24-x58-6016</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t590-8">
   <w.rf>
    <LM>w#w-d1t590-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t590-10">
   <w.rf>
    <LM>w#w-d1t590-10</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m714-d1t590-11">
   <w.rf>
    <LM>w#w-d1t590-11</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS1----------</tag>
  </m>
  <m id="m714-d1e24-x58-210">
   <w.rf>
    <LM>w#w-d1e24-x58-210</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-212">
  <m id="m714-d1t592-3">
   <w.rf>
    <LM>w#w-d1t592-3</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t592-4">
   <w.rf>
    <LM>w#w-d1t592-4</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t592-5">
   <w.rf>
    <LM>w#w-d1t592-5</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m714-d1t592-6">
   <w.rf>
    <LM>w#w-d1t592-6</LM>
   </w.rf>
   <form>vzala</form>
   <lemma>vzít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t592-7">
   <w.rf>
    <LM>w#w-d1t592-7</LM>
   </w.rf>
   <form>prvního</form>
   <lemma>první-1</lemma>
   <tag>CrMS4----------</tag>
  </m>
  <m id="m714-d1t592-8">
   <w.rf>
    <LM>w#w-d1t592-8</LM>
   </w.rf>
   <form>pejska</form>
   <lemma>pejsek</lemma>
   <tag>NNMS4-----A----</tag>
  </m>
  <m id="m714-d1t592-9">
   <w.rf>
    <LM>w#w-d1t592-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t592-10">
   <w.rf>
    <LM>w#w-d1t592-10</LM>
   </w.rf>
   <form>válce</form>
   <lemma>válka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m714-d-id89818">
   <w.rf>
    <LM>w#w-d-id89818</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t592-12">
   <w.rf>
    <LM>w#w-d1t592-12</LM>
   </w.rf>
   <form>Grejinku</form>
   <lemma>Grejinka_;Y</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-6077">
   <w.rf>
    <LM>w#w-d1e24-x58-6077</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t594-1">
   <w.rf>
    <LM>w#w-d1t594-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m714-d1t594-2">
   <w.rf>
    <LM>w#w-d1t594-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m714-d1t594-3">
   <w.rf>
    <LM>w#w-d1t594-3</LM>
   </w.rf>
   <form>výjimečně</form>
   <lemma>výjimečně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m714-d1t594-4">
   <w.rf>
    <LM>w#w-d1t594-4</LM>
   </w.rf>
   <form>ovčák</form>
   <lemma>ovčák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d1e24-x58-2521">
   <w.rf>
    <LM>w#w-d1e24-x58-2521</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m714-26171_04-2522">
  <m id="m714-d1t597-2">
   <w.rf>
    <LM>w#w-d1t597-2</LM>
   </w.rf>
   <form>Pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t597-3">
   <w.rf>
    <LM>w#w-d1t597-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m714-d1t597-4">
   <w.rf>
    <LM>w#w-d1t597-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t597-5">
   <w.rf>
    <LM>w#w-d1t597-5</LM>
   </w.rf>
   <form>seznámila</form>
   <lemma>seznámit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m714-d1t597-6">
   <w.rf>
    <LM>w#w-d1t597-6</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m714-d1t597-7">
   <w.rf>
    <LM>w#w-d1t597-7</LM>
   </w.rf>
   <form>mým</form>
   <lemma>můj</lemma>
   <tag>PSZS7-S1-------</tag>
  </m>
  <m id="m714-d1t597-8">
   <w.rf>
    <LM>w#w-d1t597-8</LM>
   </w.rf>
   <form>prvním</form>
   <lemma>první-1</lemma>
   <tag>CrMS7----------</tag>
  </m>
  <m id="m714-d1t597-9">
   <w.rf>
    <LM>w#w-d1t597-9</LM>
   </w.rf>
   <form>manželem</form>
   <lemma>manžel</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m714-d-id90063">
   <w.rf>
    <LM>w#w-d-id90063</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t599-1">
   <w.rf>
    <LM>w#w-d1t599-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m714-d1t599-2">
   <w.rf>
    <LM>w#w-d1t599-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m714-d1t599-3">
   <w.rf>
    <LM>w#w-d1t599-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t599-4">
   <w.rf>
    <LM>w#w-d1t599-4</LM>
   </w.rf>
   <form>bydleli</form>
   <lemma>bydlet</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m714-2522-2533">
   <w.rf>
    <LM>w#w-2522-2533</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t599-5">
   <w.rf>
    <LM>w#w-d1t599-5</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m714-d1t599-6">
   <w.rf>
    <LM>w#w-d1t599-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m714-d1t599-7">
   <w.rf>
    <LM>w#w-d1t599-7</LM>
   </w.rf>
   <form>narodil</form>
   <lemma>narodit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m714-d1t599-8">
   <w.rf>
    <LM>w#w-d1t599-8</LM>
   </w.rf>
   <form>Patrik</form>
   <lemma>Patrik_;Y</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-d-id90204">
   <w.rf>
    <LM>w#w-d-id90204</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t599-10">
   <w.rf>
    <LM>w#w-d1t599-10</LM>
   </w.rf>
   <form>nejstarší</form>
   <lemma>starý-2_^(člověk,_věc)</lemma>
   <tag>AAMS1----3A----</tag>
  </m>
  <m id="m714-d1t599-11">
   <w.rf>
    <LM>w#w-d1t599-11</LM>
   </w.rf>
   <form>kluk</form>
   <lemma>kluk</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m714-2522-2549">
   <w.rf>
    <LM>w#w-2522-2549</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m714-d1t599-12">
   <w.rf>
    <LM>w#w-d1t599-12</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m714-d1t599-14">
   <w.rf>
    <LM>w#w-d1t599-14</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m714-2522-2534">
   <w.rf>
    <LM>w#w-2522-2534</LM>
   </w.rf>
   <form>1947</form>
   <lemma>1947</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m714-2522-2541">
   <w.rf>
    <LM>w#w-2522-2541</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
