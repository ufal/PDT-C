<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="dk_132.07.w.gz" />
  </references>
 </head>
 <s id="m132-263">
  <m id="m132-d1t1977-2">
   <w.rf>
    <LM>w#w-d1t1977-2</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m132-d1t1977-1">
   <w.rf>
    <LM>w#w-d1t1977-1</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t1977-3">
   <w.rf>
    <LM>w#w-d1t1977-3</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t1977-12">
   <w.rf>
    <LM>w#w-d1t1977-12</LM>
   </w.rf>
   <form>patnáct</form>
   <lemma>patnáct`15</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m132-263-264">
   <w.rf>
    <LM>w#w-263-264</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t1977-13">
   <w.rf>
    <LM>w#w-d1t1977-13</LM>
   </w.rf>
   <form>šestnáct</form>
   <lemma>šestnáct`16</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m132-263-265">
   <w.rf>
    <LM>w#w-263-265</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m132-d-m-d1e1970-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1970-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e1978-x2">
  <m id="m132-d1t1981-1">
   <w.rf>
    <LM>w#w-d1t1981-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t1981-2">
   <w.rf>
    <LM>w#w-d1t1981-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t1981-3">
   <w.rf>
    <LM>w#w-d1t1981-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t1981-4">
   <w.rf>
    <LM>w#w-d1t1981-4</LM>
   </w.rf>
   <form>dostala</form>
   <lemma>dostat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d1t1981-5">
   <w.rf>
    <LM>w#w-d1t1981-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t1981-6">
   <w.rf>
    <LM>w#w-d1t1981-6</LM>
   </w.rf>
   <form>týpí</form>
   <lemma>týpí</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m132-d-id117566-punct">
   <w.rf>
    <LM>w#w-d-id117566-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e1984-x2">
  <m id="m132-d1t1991-9">
   <w.rf>
    <LM>w#w-d1t1991-9</LM>
   </w.rf>
   <form>Jeli</form>
   <lemma>jet-1</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t1991-8">
   <w.rf>
    <LM>w#w-d1t1991-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t1993-1">
   <w.rf>
    <LM>w#w-d1t1993-1</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t1993-3">
   <w.rf>
    <LM>w#w-d1t1993-3</LM>
   </w.rf>
   <form>Prahy</form>
   <lemma>Praha_;G</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m132-d1t1991-10">
   <w.rf>
    <LM>w#w-d1t1991-10</LM>
   </w.rf>
   <form>autobusem</form>
   <lemma>autobus</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m132-d1t1993-6">
   <w.rf>
    <LM>w#w-d1t1993-6</LM>
   </w.rf>
   <form>přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t1995-4">
   <w.rf>
    <LM>w#w-d1t1995-4</LM>
   </w.rf>
   <form>NDR</form>
   <lemma>NDR-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m132-d1e1984-x2-24">
   <w.rf>
    <LM>w#w-d1e1984-x2-24</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t1998-5">
   <w.rf>
    <LM>w#w-d1t1998-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t1998-6">
   <w.rf>
    <LM>w#w-d1t1998-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t1998-8">
   <w.rf>
    <LM>w#w-d1t1998-8</LM>
   </w.rf>
   <form>vypadalo</form>
   <lemma>vypadat-1_^(ty_vypadáš)</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t1998-9">
   <w.rf>
    <LM>w#w-d1t1998-9</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t1998-10">
   <w.rf>
    <LM>w#w-d1t1998-10</LM>
   </w.rf>
   <form>NDR</form>
   <lemma>NDR-88</lemma>
   <tag>BNXXX-----A----</tag>
  </m>
  <m id="m132-d1e1984-x2-25">
   <w.rf>
    <LM>w#w-d1e1984-x2-25</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2004-1">
   <w.rf>
    <LM>w#w-d1t2004-1</LM>
   </w.rf>
   <form>trajektem</form>
   <lemma>trajekt</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m132-d1t2004-2">
   <w.rf>
    <LM>w#w-d1t2004-2</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2004-4">
   <w.rf>
    <LM>w#w-d1t2004-4</LM>
   </w.rf>
   <form>Norska</form>
   <lemma>Norsko_;G</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m132-d1e1984-x2-26">
   <w.rf>
    <LM>w#w-d1e1984-x2-26</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-35">
  <m id="m132-d1t2004-7">
   <w.rf>
    <LM>w#w-d1t2004-7</LM>
   </w.rf>
   <form>Tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2004-8">
   <w.rf>
    <LM>w#w-d1t2004-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2004-10">
   <w.rf>
    <LM>w#w-d1t2004-10</LM>
   </w.rf>
   <form>jezdili</form>
   <lemma>jezdit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2004-9">
   <w.rf>
    <LM>w#w-d1t2004-9</LM>
   </w.rf>
   <form>autobusy</form>
   <lemma>autobus</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m132-d1t2006-1">
   <w.rf>
    <LM>w#w-d1t2006-1</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2006-3">
   <w.rf>
    <LM>w#w-d1t2006-3</LM>
   </w.rf>
   <form>Norsku</form>
   <lemma>Norsko_;G</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m132-d1t2006-5">
   <w.rf>
    <LM>w#w-d1t2006-5</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t2006-6">
   <w.rf>
    <LM>w#w-d1t2006-6</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2006-8">
   <w.rf>
    <LM>w#w-d1t2006-8</LM>
   </w.rf>
   <form>Nordkapp</form>
   <lemma>Nordkapp_;G</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-35-36">
   <w.rf>
    <LM>w#w-35-36</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-37">
  <m id="m132-d1t2013-8">
   <w.rf>
    <LM>w#w-d1t2013-8</LM>
   </w.rf>
   <form>Přes</form>
   <lemma>přes-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2013-2">
   <w.rf>
    <LM>w#w-d1t2013-2</LM>
   </w.rf>
   <form>Finsko</form>
   <lemma>Finsko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-d-id118494-punct">
   <w.rf>
    <LM>w#w-d-id118494-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2013-6">
   <w.rf>
    <LM>w#w-d1t2013-6</LM>
   </w.rf>
   <form>Švédsko</form>
   <lemma>Švédsko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-37-38">
   <w.rf>
    <LM>w#w-37-38</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2013-10">
   <w.rf>
    <LM>w#w-d1t2013-10</LM>
   </w.rf>
   <form>Dánsko</form>
   <lemma>Dánsko_;G</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-d1t2013-12">
   <w.rf>
    <LM>w#w-d1t2013-12</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2013-13">
   <w.rf>
    <LM>w#w-d1t2013-13</LM>
   </w.rf>
   <form>zpátky</form>
   <lemma>zpátky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2015-1">
   <w.rf>
    <LM>w#w-d1t2015-1</LM>
   </w.rf>
   <form>domů</form>
   <lemma>domů</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-37-39">
   <w.rf>
    <LM>w#w-37-39</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e1984-x3">
  <m id="m132-d1t2017-1">
   <w.rf>
    <LM>w#w-d1t2017-1</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2017-2">
   <w.rf>
    <LM>w#w-d1t2017-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m132-d1t2017-3">
   <w.rf>
    <LM>w#w-d1t2017-3</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-d1t2019-1">
   <w.rf>
    <LM>w#w-d1t2019-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2019-2">
   <w.rf>
    <LM>w#w-d1t2019-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2019-3">
   <w.rf>
    <LM>w#w-d1t2019-3</LM>
   </w.rf>
   <form>zastavili</form>
   <lemma>zastavit_^(uvést_do_klidu;;zástavní_právo)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2019-4">
   <w.rf>
    <LM>w#w-d1t2019-4</LM>
   </w.rf>
   <form>také</form>
   <lemma>také</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2021-1">
   <w.rf>
    <LM>w#w-d1t2021-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2021-2">
   <w.rf>
    <LM>w#w-d1t2021-2</LM>
   </w.rf>
   <form>muzeu</form>
   <lemma>muzeum</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m132-d1t2021-4">
   <w.rf>
    <LM>w#w-d1t2021-4</LM>
   </w.rf>
   <form>kočovných</form>
   <lemma>kočovný</lemma>
   <tag>AAIP2----1A----</tag>
  </m>
  <m id="m132-d1t2021-5">
   <w.rf>
    <LM>w#w-d1t2021-5</LM>
   </w.rf>
   <form>národů</form>
   <lemma>národ</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m132-d1t2024-1">
   <w.rf>
    <LM>w#w-d1t2024-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2024-2">
   <w.rf>
    <LM>w#w-d1t2024-2</LM>
   </w.rf>
   <form>mohli</form>
   <lemma>moci</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2024-3">
   <w.rf>
    <LM>w#w-d1t2024-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2024-4">
   <w.rf>
    <LM>w#w-d1t2024-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m132-d1t2024-5">
   <w.rf>
    <LM>w#w-d1t2024-5</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2026-1">
   <w.rf>
    <LM>w#w-d1t2026-1</LM>
   </w.rf>
   <form>vyzkoušet</form>
   <lemma>vyzkoušet</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-d1t2024-7">
   <w.rf>
    <LM>w#w-d1t2024-7</LM>
   </w.rf>
   <form>týpí</form>
   <lemma>týpí</lemma>
   <tag>NNNXX-----A----</tag>
  </m>
  <m id="m132-d-m-d1e1984-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1984-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2027-x2">
  <m id="m132-d1t2030-1">
   <w.rf>
    <LM>w#w-d1t2030-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2030-2">
   <w.rf>
    <LM>w#w-d1t2030-2</LM>
   </w.rf>
   <form>dlouhá</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m132-d1t2030-3">
   <w.rf>
    <LM>w#w-d1t2030-3</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2030-4">
   <w.rf>
    <LM>w#w-d1t2030-4</LM>
   </w.rf>
   <form>ta</form>
   <lemma>ten</lemma>
   <tag>PDFS1----------</tag>
  </m>
  <m id="m132-d1t2030-5">
   <w.rf>
    <LM>w#w-d1t2030-5</LM>
   </w.rf>
   <form>cesta</form>
   <lemma>cesta</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m132-d1t2030-6">
   <w.rf>
    <LM>w#w-d1t2030-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2030-7">
   <w.rf>
    <LM>w#w-d1t2030-7</LM>
   </w.rf>
   <form>sever</form>
   <lemma>sever</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-d-id119172-punct">
   <w.rf>
    <LM>w#w-d-id119172-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2031-x2">
  <m id="m132-d1t2034-1">
   <w.rf>
    <LM>w#w-d1t2034-1</LM>
   </w.rf>
   <form>Celkem</form>
   <lemma>celkem</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2034-2">
   <w.rf>
    <LM>w#w-d1t2034-2</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2034-3">
   <w.rf>
    <LM>w#w-d1t2034-3</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m132-d1t2034-4">
   <w.rf>
    <LM>w#w-d1t2034-4</LM>
   </w.rf>
   <form>týdny</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m132-d-m-d1e2031-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2031-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2035-x2">
  <m id="m132-d1t2038-1">
   <w.rf>
    <LM>w#w-d1t2038-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m132-d1t2038-2">
   <w.rf>
    <LM>w#w-d1t2038-2</LM>
   </w.rf>
   <form>všechno</form>
   <lemma>všechen</lemma>
   <tag>PLNS4----------</tag>
  </m>
  <m id="m132-d1t2038-3">
   <w.rf>
    <LM>w#w-d1t2038-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2038-4">
   <w.rf>
    <LM>w#w-d1t2038-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2038-5">
   <w.rf>
    <LM>w#w-d1t2038-5</LM>
   </w.rf>
   <form>navštívila</form>
   <lemma>navštívit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d-id119427-punct">
   <w.rf>
    <LM>w#w-d-id119427-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2040-x2">
  <m id="m132-d1t2047-4">
   <w.rf>
    <LM>w#w-d1t2047-4</LM>
   </w.rf>
   <form>Projeli</form>
   <lemma>projet_^(např._autem)</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2047-3">
   <w.rf>
    <LM>w#w-d1t2047-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2047-2">
   <w.rf>
    <LM>w#w-d1t2047-2</LM>
   </w.rf>
   <form>prakticky</form>
   <lemma>prakticky_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-d1t2047-5">
   <w.rf>
    <LM>w#w-d1t2047-5</LM>
   </w.rf>
   <form>všechny</form>
   <lemma>všechen</lemma>
   <tag>PLYP4----------</tag>
  </m>
  <m id="m132-d1t2047-6">
   <w.rf>
    <LM>w#w-d1t2047-6</LM>
   </w.rf>
   <form>tyto</form>
   <lemma>tento</lemma>
   <tag>PDIP4----------</tag>
  </m>
  <m id="m132-d1t2047-7">
   <w.rf>
    <LM>w#w-d1t2047-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m132-d1t2047-8">
   <w.rf>
    <LM>w#w-d1t2047-8</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d1e2040-x2-78">
   <w.rf>
    <LM>w#w-d1e2040-x2-78</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-77">
  <m id="m132-d1t2049-1">
   <w.rf>
    <LM>w#w-d1t2049-1</LM>
   </w.rf>
   <form>Uvnitř</form>
   <lemma>uvnitř-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2049-2">
   <w.rf>
    <LM>w#w-d1t2049-2</LM>
   </w.rf>
   <form>těch</form>
   <lemma>ten</lemma>
   <tag>PDXP2----------</tag>
  </m>
  <m id="m132-d1t2049-3">
   <w.rf>
    <LM>w#w-d1t2049-3</LM>
   </w.rf>
   <form>zemí</form>
   <lemma>země</lemma>
   <tag>NNFP2-----A----</tag>
  </m>
  <m id="m132-d1t2049-4">
   <w.rf>
    <LM>w#w-d1t2049-4</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2049-5">
   <w.rf>
    <LM>w#w-d1t2049-5</LM>
   </w.rf>
   <form>navštívili</form>
   <lemma>navštívit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2051-1">
   <w.rf>
    <LM>w#w-d1t2051-1</LM>
   </w.rf>
   <form>hlavní</form>
   <lemma>hlavní</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m132-d1t2051-3">
   <w.rf>
    <LM>w#w-d1t2051-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2051-6">
   <w.rf>
    <LM>w#w-d1t2051-6</LM>
   </w.rf>
   <form>známá</form>
   <lemma>známý-2_^(co_známe)</lemma>
   <tag>AANP4----1A----</tag>
  </m>
  <m id="m132-d1t2051-7">
   <w.rf>
    <LM>w#w-d1t2051-7</LM>
   </w.rf>
   <form>města</form>
   <lemma>město</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m132-d1e2040-x2-59">
   <w.rf>
    <LM>w#w-d1e2040-x2-59</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-65">
  <m id="m132-d1t2056-2">
   <w.rf>
    <LM>w#w-d1t2056-2</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2056-3">
   <w.rf>
    <LM>w#w-d1t2056-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2056-4">
   <w.rf>
    <LM>w#w-d1t2056-4</LM>
   </w.rf>
   <form>dost</form>
   <lemma>dost</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-d1t2056-5">
   <w.rf>
    <LM>w#w-d1t2056-5</LM>
   </w.rf>
   <form>náročné</form>
   <lemma>náročný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m132-65-69">
   <w.rf>
    <LM>w#w-65-69</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2056-7">
   <w.rf>
    <LM>w#w-d1t2056-7</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2058-1">
   <w.rf>
    <LM>w#w-d1t2058-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2058-2">
   <w.rf>
    <LM>w#w-d1t2058-2</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2058-3">
   <w.rf>
    <LM>w#w-d1t2058-3</LM>
   </w.rf>
   <form>mít</form>
   <lemma>mít</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m132-d1t2058-4">
   <w.rf>
    <LM>w#w-d1t2058-4</LM>
   </w.rf>
   <form>každý</form>
   <lemma>každý</lemma>
   <tag>AAMS1----1A----</tag>
  </m>
  <m id="m132-d1t2058-5">
   <w.rf>
    <LM>w#w-d1t2058-5</LM>
   </w.rf>
   <form>vlastní</form>
   <lemma>vlastní</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m132-d1t2058-6">
   <w.rf>
    <LM>w#w-d1t2058-6</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-d1t2058-7">
   <w.rf>
    <LM>w#w-d1t2058-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2058-8">
   <w.rf>
    <LM>w#w-d1t2058-8</LM>
   </w.rf>
   <form>zabezpečit</form>
   <lemma>zabezpečit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-d1t2058-9">
   <w.rf>
    <LM>w#w-d1t2058-9</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m132-d1t2060-2">
   <w.rf>
    <LM>w#w-d1t2060-2</LM>
   </w.rf>
   <form>stravu</form>
   <lemma>strava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m132-65-70">
   <w.rf>
    <LM>w#w-65-70</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-68">
  <m id="m132-d1t2060-4">
   <w.rf>
    <LM>w#w-d1t2060-4</LM>
   </w.rf>
   <form>Každý</form>
   <lemma>každý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m132-d1t2060-5">
   <w.rf>
    <LM>w#w-d1t2060-5</LM>
   </w.rf>
   <form>den</form>
   <lemma>den-1_^(jednotka_času)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-d1t2060-7">
   <w.rf>
    <LM>w#w-d1t2060-7</LM>
   </w.rf>
   <form>ráno</form>
   <lemma>ráno-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2060-8">
   <w.rf>
    <LM>w#w-d1t2060-8</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2060-9">
   <w.rf>
    <LM>w#w-d1t2060-9</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-d1t2060-10">
   <w.rf>
    <LM>w#w-d1t2060-10</LM>
   </w.rf>
   <form>složili</form>
   <lemma>složit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2060-11">
   <w.rf>
    <LM>w#w-d1t2060-11</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2060-16">
   <w.rf>
    <LM>w#w-d1t2060-16</LM>
   </w.rf>
   <form>zhruba</form>
   <lemma>zhruba</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2060-12">
   <w.rf>
    <LM>w#w-d1t2060-12</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2060-13">
   <w.rf>
    <LM>w#w-d1t2060-13</LM>
   </w.rf>
   <form>800</form>
   <lemma>800</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m132-d1t2060-15">
   <w.rf>
    <LM>w#w-d1t2060-15</LM>
   </w.rf>
   <form>kilometrů</form>
   <lemma>kilometr</lemma>
   <tag>NNIP2-----A----</tag>
  </m>
  <m id="m132-68-71">
   <w.rf>
    <LM>w#w-68-71</LM>
   </w.rf>
   <form>dál</form>
   <lemma>daleko-1</lemma>
   <tag>Dg-------2A----</tag>
  </m>
  <m id="m132-d1t2060-17">
   <w.rf>
    <LM>w#w-d1t2060-17</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2060-18">
   <w.rf>
    <LM>w#w-d1t2060-18</LM>
   </w.rf>
   <form>ho</form>
   <lemma>on-1</lemma>
   <tag>P5ZS4--3-------</tag>
  </m>
  <m id="m132-d1t2060-19">
   <w.rf>
    <LM>w#w-d1t2060-19</LM>
   </w.rf>
   <form>večer</form>
   <lemma>večer-2</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2060-20">
   <w.rf>
    <LM>w#w-d1t2060-20</LM>
   </w.rf>
   <form>zase</form>
   <lemma>zase-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2062-1">
   <w.rf>
    <LM>w#w-d1t2062-1</LM>
   </w.rf>
   <form>stavěli</form>
   <lemma>stavět</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-68-72">
   <w.rf>
    <LM>w#w-68-72</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-73">
  <m id="m132-d1t2064-11">
   <w.rf>
    <LM>w#w-d1t2064-11</LM>
   </w.rf>
   <form>Vykoupali</form>
   <lemma>vykoupat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2064-9">
   <w.rf>
    <LM>w#w-d1t2064-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2064-10">
   <w.rf>
    <LM>w#w-d1t2064-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-73-109">
   <w.rf>
    <LM>w#w-73-109</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2064-6">
   <w.rf>
    <LM>w#w-d1t2064-6</LM>
   </w.rf>
   <form>kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2064-7">
   <w.rf>
    <LM>w#w-d1t2064-7</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2064-8">
   <w.rf>
    <LM>w#w-d1t2064-8</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m132-73-110">
   <w.rf>
    <LM>w#w-73-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2040-x3">
  <m id="m132-d1t2067-1">
   <w.rf>
    <LM>w#w-d1t2067-1</LM>
   </w.rf>
   <form>Šli</form>
   <lemma>jít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2067-2">
   <w.rf>
    <LM>w#w-d1t2067-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2067-3">
   <w.rf>
    <LM>w#w-d1t2067-3</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2067-4">
   <w.rf>
    <LM>w#w-d1t2067-4</LM>
   </w.rf>
   <form>tundry</form>
   <lemma>tundra</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m132-d1e2040-x3-111">
   <w.rf>
    <LM>w#w-d1e2040-x3-111</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-112">
  <m id="m132-d1t2069-2">
   <w.rf>
    <LM>w#w-d1t2069-2</LM>
   </w.rf>
   <form>Koupali</form>
   <lemma>koupat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2069-3">
   <w.rf>
    <LM>w#w-d1t2069-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2069-4">
   <w.rf>
    <LM>w#w-d1t2069-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2069-5">
   <w.rf>
    <LM>w#w-d1t2069-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2069-7">
   <w.rf>
    <LM>w#w-d1t2069-7</LM>
   </w.rf>
   <form>Atlantském</form>
   <lemma>atlantský</lemma>
   <tag>AAIS6----1A----</tag>
  </m>
  <m id="m132-d1t2069-8">
   <w.rf>
    <LM>w#w-d1t2069-8</LM>
   </w.rf>
   <form>oceánu</form>
   <lemma>oceán</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m132-112-126">
   <w.rf>
    <LM>w#w-112-126</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2069-11">
   <w.rf>
    <LM>w#w-d1t2069-11</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2069-13">
   <w.rf>
    <LM>w#w-d1t2069-13</LM>
   </w.rf>
   <form>Severním</form>
   <lemma>severní</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m132-d1t2071-1">
   <w.rf>
    <LM>w#w-d1t2071-1</LM>
   </w.rf>
   <form>moři</form>
   <lemma>moře</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m132-112-124">
   <w.rf>
    <LM>w#w-112-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-125">
  <m id="m132-d1t2077-2">
   <w.rf>
    <LM>w#w-d1t2077-2</LM>
   </w.rf>
   <form>Navštívili</form>
   <lemma>navštívit</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m132-d1t2077-3">
   <w.rf>
    <LM>w#w-d1t2077-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2077-6">
   <w.rf>
    <LM>w#w-d1t2077-6</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m132-d1t2077-7">
   <w.rf>
    <LM>w#w-d1t2077-7</LM>
   </w.rf>
   <form>národní</form>
   <lemma>národní</lemma>
   <tag>AAIP4----1A----</tag>
  </m>
  <m id="m132-d1t2077-8">
   <w.rf>
    <LM>w#w-d1t2077-8</LM>
   </w.rf>
   <form>parky</form>
   <lemma>park</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m132-125-133">
   <w.rf>
    <LM>w#w-125-133</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-134">
  <m id="m132-d1t2082-1">
   <w.rf>
    <LM>w#w-d1t2082-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2082-2">
   <w.rf>
    <LM>w#w-d1t2082-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2082-3">
   <w.rf>
    <LM>w#w-d1t2082-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t2082-4">
   <w.rf>
    <LM>w#w-d1t2082-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2082-5">
   <w.rf>
    <LM>w#w-d1t2082-5</LM>
   </w.rf>
   <form>ostrovech</form>
   <lemma>ostrov</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m132-d1t2082-7">
   <w.rf>
    <LM>w#w-d1t2082-7</LM>
   </w.rf>
   <form>Lofoty</form>
   <lemma>Lofoty_;G</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m132-d1t2082-9">
   <w.rf>
    <LM>w#w-d1t2082-9</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2082-11">
   <w.rf>
    <LM>w#w-d1t2082-11</LM>
   </w.rf>
   <form>Vesterály</form>
   <lemma>Vesterály_;G</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m132-134-135">
   <w.rf>
    <LM>w#w-134-135</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-136">
  <m id="m132-d1t2084-1">
   <w.rf>
    <LM>w#w-d1t2084-1</LM>
   </w.rf>
   <form>Při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2084-2">
   <w.rf>
    <LM>w#w-d1t2084-2</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m132-d1t2084-3">
   <w.rf>
    <LM>w#w-d1t2084-3</LM>
   </w.rf>
   <form>cestě</form>
   <lemma>cesta</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-d1t2082-15">
   <w.rf>
    <LM>w#w-d1t2082-15</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2082-14">
   <w.rf>
    <LM>w#w-d1t2082-14</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m132-d1t2082-16">
   <w.rf>
    <LM>w#w-d1t2082-16</LM>
   </w.rf>
   <form>krásně</form>
   <lemma>krásně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-d1t2082-18">
   <w.rf>
    <LM>w#w-d1t2082-18</LM>
   </w.rf>
   <form>porovnat</form>
   <lemma>porovnat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-136-137">
   <w.rf>
    <LM>w#w-136-137</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2084-4">
   <w.rf>
    <LM>w#w-d1t2084-4</LM>
   </w.rf>
   <form>jaká</form>
   <lemma>jaký</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m132-d1t2084-9">
   <w.rf>
    <LM>w#w-d1t2084-9</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m132-d1t2084-5">
   <w.rf>
    <LM>w#w-d1t2084-5</LM>
   </w.rf>
   <form>úroveň</form>
   <lemma>úroveň</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m132-d1t2084-6">
   <w.rf>
    <LM>w#w-d1t2084-6</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS2----------</tag>
  </m>
  <m id="m132-d1t2084-7">
   <w.rf>
    <LM>w#w-d1t2084-7</LM>
   </w.rf>
   <form>které</form>
   <lemma>který</lemma>
   <tag>P4FS2----------</tag>
  </m>
  <m id="m132-d1t2084-8">
   <w.rf>
    <LM>w#w-d1t2084-8</LM>
   </w.rf>
   <form>země</form>
   <lemma>země</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m132-d1t2084-10">
   <w.rf>
    <LM>w#w-d1t2084-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2084-11">
   <w.rf>
    <LM>w#w-d1t2084-11</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2084-12">
   <w.rf>
    <LM>w#w-d1t2084-12</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m132-d1t2084-15">
   <w.rf>
    <LM>w#w-d1t2084-15</LM>
   </w.rf>
   <form>přátelská</form>
   <lemma>přátelský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m132-d1t2084-13">
   <w.rf>
    <LM>w#w-d1t2084-13</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m132-d1t2084-14">
   <w.rf>
    <LM>w#w-d1t2084-14</LM>
   </w.rf>
   <form>návštěvníkům</form>
   <lemma>návštěvník</lemma>
   <tag>NNMP3-----A----</tag>
  </m>
  <m id="m132-d-m-d1e2040-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2040-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2085-x2">
  <m id="m132-d1t2088-1">
   <w.rf>
    <LM>w#w-d1t2088-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2088-2">
   <w.rf>
    <LM>w#w-d1t2088-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2088-5">
   <w.rf>
    <LM>w#w-d1t2088-5</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m132-d1t2088-6">
   <w.rf>
    <LM>w#w-d1t2088-6</LM>
   </w.rf>
   <form>cestou</form>
   <lemma>cesta</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m132-d1t2088-3">
   <w.rf>
    <LM>w#w-d1t2088-3</LM>
   </w.rf>
   <form>sháněla</form>
   <lemma>shánět</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2088-4">
   <w.rf>
    <LM>w#w-d1t2088-4</LM>
   </w.rf>
   <form>výbavu</form>
   <lemma>výbava</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m132-d-id121764-punct">
   <w.rf>
    <LM>w#w-d-id121764-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2089-x2">
  <m id="m132-d1t2092-2">
   <w.rf>
    <LM>w#w-d1t2092-2</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2092-10">
   <w.rf>
    <LM>w#w-d1t2092-10</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2092-11">
   <w.rf>
    <LM>w#w-d1t2092-11</LM>
   </w.rf>
   <form>nebyl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-NAI--</tag>
  </m>
  <m id="m132-d1t2092-13">
   <w.rf>
    <LM>w#w-d1t2092-13</LM>
   </w.rf>
   <form>trh</form>
   <lemma>trh</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m132-d1t2094-1">
   <w.rf>
    <LM>w#w-d1t2094-1</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2094-2">
   <w.rf>
    <LM>w#w-d1t2094-2</LM>
   </w.rf>
   <form>zabezpečený</form>
   <lemma>zabezpečený_^(*3it)</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m132-d1t2094-3">
   <w.rf>
    <LM>w#w-d1t2094-3</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2094-4">
   <w.rf>
    <LM>w#w-d1t2094-4</LM>
   </w.rf>
   <form>teď</form>
   <lemma>teď</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1e2089-x2-5">
   <w.rf>
    <LM>w#w-d1e2089-x2-5</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-9">
  <m id="m132-d1t2094-7">
   <w.rf>
    <LM>w#w-d1t2094-7</LM>
   </w.rf>
   <form>Ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2094-8">
   <w.rf>
    <LM>w#w-d1t2094-8</LM>
   </w.rf>
   <form>dal</form>
   <lemma>dát-1</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m132-d1t2094-9">
   <w.rf>
    <LM>w#w-d1t2094-9</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2094-10">
   <w.rf>
    <LM>w#w-d1t2094-10</LM>
   </w.rf>
   <form>už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2096-1">
   <w.rf>
    <LM>w#w-d1t2096-1</LM>
   </w.rf>
   <form>koupit</form>
   <lemma>koupit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-d1t2096-2">
   <w.rf>
    <LM>w#w-d1t2096-2</LM>
   </w.rf>
   <form>dvojplášťový</form>
   <lemma>dvojplášťový</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m132-d1t2096-3">
   <w.rf>
    <LM>w#w-d1t2096-3</LM>
   </w.rf>
   <form>stan</form>
   <lemma>stan</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m132-9-10">
   <w.rf>
    <LM>w#w-9-10</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-16">
  <m id="m132-d1t2103-1">
   <w.rf>
    <LM>w#w-d1t2103-1</LM>
   </w.rf>
   <form>Už</form>
   <lemma>už-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2098-2">
   <w.rf>
    <LM>w#w-d1t2098-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2098-3">
   <w.rf>
    <LM>w#w-d1t2098-3</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2103-2">
   <w.rf>
    <LM>w#w-d1t2103-2</LM>
   </w.rf>
   <form>takový</form>
   <lemma>takový</lemma>
   <tag>PDIS4----------</tag>
  </m>
  <m id="m132-d1t2103-3">
   <w.rf>
    <LM>w#w-d1t2103-3</LM>
   </w.rf>
   <form>malý</form>
   <lemma>malý</lemma>
   <tag>AAIS4----1A----</tag>
  </m>
  <m id="m132-d1t2098-1">
   <w.rf>
    <LM>w#w-d1t2098-1</LM>
   </w.rf>
   <form>vařič</form>
   <lemma>vařič-1_^(přístroj)</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-d1t2103-4">
   <w.rf>
    <LM>w#w-d1t2103-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2103-5">
   <w.rf>
    <LM>w#w-d1t2103-5</LM>
   </w.rf>
   <form>bomby</form>
   <lemma>bomba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-16-17">
   <w.rf>
    <LM>w#w-16-17</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-21">
  <m id="m132-d1t2103-9">
   <w.rf>
    <LM>w#w-d1t2103-9</LM>
   </w.rf>
   <form>Docela</form>
   <lemma>docela</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2103-8">
   <w.rf>
    <LM>w#w-d1t2103-8</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2103-10">
   <w.rf>
    <LM>w#w-d1t2103-10</LM>
   </w.rf>
   <form>šlo</form>
   <lemma>jít</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d-id122518-punct">
   <w.rf>
    <LM>w#w-d-id122518-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2103-12">
   <w.rf>
    <LM>w#w-d1t2103-12</LM>
   </w.rf>
   <form>ale</form>
   <lemma>ale</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2103-13">
   <w.rf>
    <LM>w#w-d1t2103-13</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2103-14">
   <w.rf>
    <LM>w#w-d1t2103-14</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2103-15">
   <w.rf>
    <LM>w#w-d1t2103-15</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2103-16">
   <w.rf>
    <LM>w#w-d1t2103-16</LM>
   </w.rf>
   <form>hodně</form>
   <lemma>hodně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-d1t2103-17">
   <w.rf>
    <LM>w#w-d1t2103-17</LM>
   </w.rf>
   <form>dražší</form>
   <lemma>drahý</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m132-21-22">
   <w.rf>
    <LM>w#w-21-22</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2103-18">
   <w.rf>
    <LM>w#w-d1t2103-18</LM>
   </w.rf>
   <form>než</form>
   <lemma>než-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2103-19">
   <w.rf>
    <LM>w#w-d1t2103-19</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m132-d1t2103-20">
   <w.rf>
    <LM>w#w-d1t2103-20</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2103-21">
   <w.rf>
    <LM>w#w-d1t2103-21</LM>
   </w.rf>
   <form>dnes</form>
   <lemma>dnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d-m-d1e2089-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2089-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2104-x2">
  <m id="m132-d1t2107-1">
   <w.rf>
    <LM>w#w-d1t2107-1</LM>
   </w.rf>
   <form>Jedla</form>
   <lemma>jíst</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2107-2">
   <w.rf>
    <LM>w#w-d1t2107-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2107-3">
   <w.rf>
    <LM>w#w-d1t2107-3</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t2107-4">
   <w.rf>
    <LM>w#w-d1t2107-4</LM>
   </w.rf>
   <form>tamní</form>
   <lemma>tamní</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m132-d1t2107-5">
   <w.rf>
    <LM>w#w-d1t2107-5</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-d-id122812-punct">
   <w.rf>
    <LM>w#w-d-id122812-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2108-x2">
  <m id="m132-d1t2111-1">
   <w.rf>
    <LM>w#w-d1t2111-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d-id122889-punct">
   <w.rf>
    <LM>w#w-d-id122889-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2115-1">
   <w.rf>
    <LM>w#w-d1t2115-1</LM>
   </w.rf>
   <form>nejedla</form>
   <lemma>jíst</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m132-d1e2108-x2-30">
   <w.rf>
    <LM>w#w-d1e2108-x2-30</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-38">
  <m id="m132-d1t2117-1">
   <w.rf>
    <LM>w#w-d1t2117-1</LM>
   </w.rf>
   <form>Měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2117-2">
   <w.rf>
    <LM>w#w-d1t2117-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2117-3">
   <w.rf>
    <LM>w#w-d1t2117-3</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m132-d1t2117-4">
   <w.rf>
    <LM>w#w-d1t2117-4</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m132-d1t2117-5">
   <w.rf>
    <LM>w#w-d1t2117-5</LM>
   </w.rf>
   <form>zásoby</form>
   <lemma>zásoba</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-38-45">
   <w.rf>
    <LM>w#w-38-45</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-46">
  <m id="m132-d1t2119-2">
   <w.rf>
    <LM>w#w-d1t2119-2</LM>
   </w.rf>
   <form>Jednak</form>
   <lemma>jednak</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2119-3">
   <w.rf>
    <LM>w#w-d1t2119-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2119-4">
   <w.rf>
    <LM>w#w-d1t2119-4</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2119-5">
   <w.rf>
    <LM>w#w-d1t2119-5</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2122-2">
   <w.rf>
    <LM>w#w-d1t2122-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2122-3">
   <w.rf>
    <LM>w#w-d1t2122-3</LM>
   </w.rf>
   <form>naše</form>
   <lemma>náš</lemma>
   <tag>PSXP4-P1-------</tag>
  </m>
  <m id="m132-d1t2122-4">
   <w.rf>
    <LM>w#w-d1t2122-4</LM>
   </w.rf>
   <form>koruny</form>
   <lemma>koruna</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d1t2122-7">
   <w.rf>
    <LM>w#w-d1t2122-7</LM>
   </w.rf>
   <form>drahé</form>
   <lemma>drahý</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m132-d1t2124-1">
   <w.rf>
    <LM>w#w-d1t2124-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2124-4">
   <w.rf>
    <LM>w#w-d1t2124-4</LM>
   </w.rf>
   <form>ani</form>
   <lemma>ani-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2124-3">
   <w.rf>
    <LM>w#w-d1t2124-3</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2124-5">
   <w.rf>
    <LM>w#w-d1t2124-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2124-6">
   <w.rf>
    <LM>w#w-d1t2124-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m132-d1t2124-7">
   <w.rf>
    <LM>w#w-d1t2124-7</LM>
   </w.rf>
   <form>neměli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-NAI--</tag>
  </m>
  <m id="m132-d1t2124-8">
   <w.rf>
    <LM>w#w-d1t2124-8</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m132-46-55">
   <w.rf>
    <LM>w#w-46-55</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-56">
  <m id="m132-d1t2126-1">
   <w.rf>
    <LM>w#w-d1t2126-1</LM>
   </w.rf>
   <form>Vzhledem</form>
   <lemma>vzhledem</lemma>
   <tag>RF-------------</tag>
  </m>
  <m id="m132-d1t2126-2">
   <w.rf>
    <LM>w#w-d1t2126-2</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m132-d1t2126-3">
   <w.rf>
    <LM>w#w-d1t2126-3</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m132-d-id123495-punct">
   <w.rf>
    <LM>w#w-d-id123495-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2126-5">
   <w.rf>
    <LM>w#w-d1t2126-5</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2126-6">
   <w.rf>
    <LM>w#w-d1t2126-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2126-7">
   <w.rf>
    <LM>w#w-d1t2126-7</LM>
   </w.rf>
   <form>spali</form>
   <lemma>spát</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2126-8">
   <w.rf>
    <LM>w#w-d1t2126-8</LM>
   </w.rf>
   <form>pod</form>
   <lemma>pod-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m132-d1t2126-9">
   <w.rf>
    <LM>w#w-d1t2126-9</LM>
   </w.rf>
   <form>stany</form>
   <lemma>stan</lemma>
   <tag>NNIP7-----A----</tag>
  </m>
  <m id="m132-d-id123582-punct">
   <w.rf>
    <LM>w#w-d-id123582-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2126-12">
   <w.rf>
    <LM>w#w-d1t2126-12</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2126-14">
   <w.rf>
    <LM>w#w-d1t2126-14</LM>
   </w.rf>
   <form>museli</form>
   <lemma>muset</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2126-13">
   <w.rf>
    <LM>w#w-d1t2126-13</LM>
   </w.rf>
   <form>buď</form>
   <lemma>buď</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2128-1">
   <w.rf>
    <LM>w#w-d1t2128-1</LM>
   </w.rf>
   <form>zaparkovat</form>
   <lemma>zaparkovat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-d1t2128-9">
   <w.rf>
    <LM>w#w-d1t2128-9</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2132-2">
   <w.rf>
    <LM>w#w-d1t2132-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2132-3">
   <w.rf>
    <LM>w#w-d1t2132-3</LM>
   </w.rf>
   <form>divočině</form>
   <lemma>divočina</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-56-57">
   <w.rf>
    <LM>w#w-56-57</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2128-5">
   <w.rf>
    <LM>w#w-d1t2128-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2128-4">
   <w.rf>
    <LM>w#w-d1t2128-4</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m132-d1t2128-3">
   <w.rf>
    <LM>w#w-d1t2128-3</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2128-6">
   <w.rf>
    <LM>w#w-d1t2128-6</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2128-7">
   <w.rf>
    <LM>w#w-d1t2128-7</LM>
   </w.rf>
   <form>obtížné</form>
   <lemma>obtížný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m132-56-58">
   <w.rf>
    <LM>w#w-56-58</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-56-59">
   <w.rf>
    <LM>w#w-56-59</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2137-3">
   <w.rf>
    <LM>w#w-d1t2137-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2137-4">
   <w.rf>
    <LM>w#w-d1t2137-4</LM>
   </w.rf>
   <form>kempu</form>
   <lemma>kemp</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m132-56-60">
   <w.rf>
    <LM>w#w-56-60</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2108-x3">
  <m id="m132-d1t2137-7">
   <w.rf>
    <LM>w#w-d1t2137-7</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m132-d1t2137-6">
   <w.rf>
    <LM>w#w-d1t2137-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2137-8">
   <w.rf>
    <LM>w#w-d1t2137-8</LM>
   </w.rf>
   <form>kempy</form>
   <lemma>kemp</lemma>
   <tag>NNIP1-----A----</tag>
  </m>
  <m id="m132-d1t2137-9">
   <w.rf>
    <LM>w#w-d1t2137-9</LM>
   </w.rf>
   <form>pro</form>
   <lemma>pro-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2137-10">
   <w.rf>
    <LM>w#w-d1t2137-10</LM>
   </w.rf>
   <form>turisty</form>
   <lemma>turista</lemma>
   <tag>NNMP4-----A----</tag>
  </m>
  <m id="m132-d1e2108-x3-67">
   <w.rf>
    <LM>w#w-d1e2108-x3-67</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-78">
  <m id="m132-d1t2137-14">
   <w.rf>
    <LM>w#w-d1t2137-14</LM>
   </w.rf>
   <form>Žádné</form>
   <lemma>žádný</lemma>
   <tag>PWFP1----------</tag>
  </m>
  <m id="m132-d1t2137-15">
   <w.rf>
    <LM>w#w-d1t2137-15</LM>
   </w.rf>
   <form>restaurace</form>
   <lemma>restaurace</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m132-d1t2137-13">
   <w.rf>
    <LM>w#w-d1t2137-13</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2137-16">
   <w.rf>
    <LM>w#w-d1t2137-16</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2137-17">
   <w.rf>
    <LM>w#w-d1t2137-17</LM>
   </w.rf>
   <form>toho</form>
   <lemma>ten</lemma>
   <tag>PDZS2----------</tag>
  </m>
  <m id="m132-d1t2137-18">
   <w.rf>
    <LM>w#w-d1t2137-18</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m132-d-m-d1e2108-x3-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2108-x3-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2138-x2">
  <m id="m132-d1t2141-1">
   <w.rf>
    <LM>w#w-d1t2141-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m132-d1t2141-2">
   <w.rf>
    <LM>w#w-d1t2141-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2141-3">
   <w.rf>
    <LM>w#w-d1t2141-3</LM>
   </w.rf>
   <form>jídlo</form>
   <lemma>jídlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-d1t2141-4">
   <w.rf>
    <LM>w#w-d1t2141-4</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2141-5">
   <w.rf>
    <LM>w#w-d1t2141-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m132-d1t2141-6">
   <w.rf>
    <LM>w#w-d1t2141-6</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m132-d1t2141-7">
   <w.rf>
    <LM>w#w-d1t2141-7</LM>
   </w.rf>
   <form>vezla</form>
   <lemma>vézt_^(něco/někoho_autem,_vlakem,...)</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d-id124322-punct">
   <w.rf>
    <LM>w#w-d-id124322-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2142-x2">
  <m id="m132-d1t2147-1">
   <w.rf>
    <LM>w#w-d1t2147-1</LM>
   </w.rf>
   <form>Převážně</form>
   <lemma>převážně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-d1t2151-1">
   <w.rf>
    <LM>w#w-d1t2151-1</LM>
   </w.rf>
   <form>sáčkové</form>
   <lemma>sáčkový</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m132-d1t2151-2">
   <w.rf>
    <LM>w#w-d1t2151-2</LM>
   </w.rf>
   <form>polévky</form>
   <lemma>polévka</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d-id124457-punct">
   <w.rf>
    <LM>w#w-d-id124457-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2153-1">
   <w.rf>
    <LM>w#w-d1t2153-1</LM>
   </w.rf>
   <form>instantní</form>
   <lemma>instantní</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m132-d1t2153-2">
   <w.rf>
    <LM>w#w-d1t2153-2</LM>
   </w.rf>
   <form>nudle</form>
   <lemma>nudle</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d-id124506-punct">
   <w.rf>
    <LM>w#w-d-id124506-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2160-1">
   <w.rf>
    <LM>w#w-d1t2160-1</LM>
   </w.rf>
   <form>paštiky</form>
   <lemma>paštika</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d-id124557-punct">
   <w.rf>
    <LM>w#w-d-id124557-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2160-3">
   <w.rf>
    <LM>w#w-d1t2160-3</LM>
   </w.rf>
   <form>nějaké</form>
   <lemma>nějaký</lemma>
   <tag>PZNS4----------</tag>
  </m>
  <m id="m132-d1t2160-4">
   <w.rf>
    <LM>w#w-d1t2160-4</LM>
   </w.rf>
   <form>maso</form>
   <lemma>maso_^(jídlo_apod.)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m132-d1t2160-5">
   <w.rf>
    <LM>w#w-d1t2160-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2160-6">
   <w.rf>
    <LM>w#w-d1t2160-6</LM>
   </w.rf>
   <form>konzervě</form>
   <lemma>konzerva</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-d1e2142-x2-86">
   <w.rf>
    <LM>w#w-d1e2142-x2-86</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2160-12">
   <w.rf>
    <LM>w#w-d1t2160-12</LM>
   </w.rf>
   <form>příchutě</form>
   <lemma>příchuť</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-d1t2160-13">
   <w.rf>
    <LM>w#w-d1t2160-13</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2160-14">
   <w.rf>
    <LM>w#w-d1t2160-14</LM>
   </w.rf>
   <form>vody</form>
   <lemma>voda</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m132-d1e2142-x2-87">
   <w.rf>
    <LM>w#w-d1e2142-x2-87</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-91">
  <m id="m132-d1t2160-17">
   <w.rf>
    <LM>w#w-d1t2160-17</LM>
   </w.rf>
   <form>Balená</form>
   <lemma>balený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m132-d1t2160-18">
   <w.rf>
    <LM>w#w-d1t2160-18</LM>
   </w.rf>
   <form>voda</form>
   <lemma>voda</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m132-d1t2160-19">
   <w.rf>
    <LM>w#w-d1t2160-19</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2160-20">
   <w.rf>
    <LM>w#w-d1t2160-20</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2160-21">
   <w.rf>
    <LM>w#w-d1t2160-21</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2160-22">
   <w.rf>
    <LM>w#w-d1t2160-22</LM>
   </w.rf>
   <form>nekupovala</form>
   <lemma>kupovat</lemma>
   <tag>VpQW----R-NAI--</tag>
  </m>
  <m id="m132-91-92">
   <w.rf>
    <LM>w#w-91-92</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-95">
  <m id="m132-d1t2162-1">
   <w.rf>
    <LM>w#w-d1t2162-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m132-95-96">
   <w.rf>
    <LM>w#w-95-96</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2162-2">
   <w.rf>
    <LM>w#w-d1t2162-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m132-d1t2162-3">
   <w.rf>
    <LM>w#w-d1t2162-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2162-5">
   <w.rf>
    <LM>w#w-d1t2162-5</LM>
   </w.rf>
   <form>tady</form>
   <lemma>tady</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2162-6">
   <w.rf>
    <LM>w#w-d1t2162-6</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2162-7">
   <w.rf>
    <LM>w#w-d1t2162-7</LM>
   </w.rf>
   <form>trhu</form>
   <lemma>trh</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m132-d-m-d1e2142-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2142-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2163-x2">
  <m id="m132-d1t2166-1">
   <w.rf>
    <LM>w#w-d1t2166-1</LM>
   </w.rf>
   <form>Chutnalo</form>
   <lemma>chutnat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2166-2">
   <w.rf>
    <LM>w#w-d1t2166-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m132-d1t2166-3">
   <w.rf>
    <LM>w#w-d1t2166-3</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2166-4">
   <w.rf>
    <LM>w#w-d1t2166-4</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2166-5">
   <w.rf>
    <LM>w#w-d1t2166-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2166-6">
   <w.rf>
    <LM>w#w-d1t2166-6</LM>
   </w.rf>
   <form>třech</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P6----------</tag>
  </m>
  <m id="m132-d1t2166-7">
   <w.rf>
    <LM>w#w-d1t2166-7</LM>
   </w.rf>
   <form>týdnech</form>
   <lemma>týden_^(jednotka_času)</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m132-d-id125147-punct">
   <w.rf>
    <LM>w#w-d-id125147-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2167-x2">
  <m id="m132-d1e2167-x2-101">
   <w.rf>
    <LM>w#w-d1e2167-x2-101</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1e2167-x2-102">
   <w.rf>
    <LM>w#w-d1e2167-x2-102</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2170-1">
   <w.rf>
    <LM>w#w-d1t2170-1</LM>
   </w.rf>
   <form>chutnalo</form>
   <lemma>chutnat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1e2167-x2-99">
   <w.rf>
    <LM>w#w-d1e2167-x2-99</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-100">
  <m id="m132-d1t2172-4">
   <w.rf>
    <LM>w#w-d1t2172-4</LM>
   </w.rf>
   <form>Dokázala</form>
   <lemma>dokázat</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d1t2172-2">
   <w.rf>
    <LM>w#w-d1t2172-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2172-3">
   <w.rf>
    <LM>w#w-d1t2172-3</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m132-d1t2172-5">
   <w.rf>
    <LM>w#w-d1t2172-5</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t2172-6">
   <w.rf>
    <LM>w#w-d1t2172-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2172-7">
   <w.rf>
    <LM>w#w-d1t2172-7</LM>
   </w.rf>
   <form>přírodě</form>
   <lemma>příroda</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-d1t2172-8">
   <w.rf>
    <LM>w#w-d1t2172-8</LM>
   </w.rf>
   <form>najít</form>
   <lemma>najít</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-d1t2174-1">
   <w.rf>
    <LM>w#w-d1t2174-1</LM>
   </w.rf>
   <form>různé</form>
   <lemma>různý</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m132-d1t2174-2">
   <w.rf>
    <LM>w#w-d1t2174-2</LM>
   </w.rf>
   <form>zelené</form>
   <lemma>zelený_;o</lemma>
   <tag>AAFP4----1A----</tag>
  </m>
  <m id="m132-d1t2174-3">
   <w.rf>
    <LM>w#w-d1t2174-3</LM>
   </w.rf>
   <form>trávy</form>
   <lemma>tráva</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-100-108">
   <w.rf>
    <LM>w#w-100-108</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2176-2">
   <w.rf>
    <LM>w#w-d1t2176-2</LM>
   </w.rf>
   <form>aby</form>
   <lemma>aby</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2176-3">
   <w.rf>
    <LM>w#w-d1t2176-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2176-4">
   <w.rf>
    <LM>w#w-d1t2176-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m132-d1t2176-5">
   <w.rf>
    <LM>w#w-d1t2176-5</LM>
   </w.rf>
   <form>dalo</form>
   <lemma>dát-1</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m132-d1t2176-6">
   <w.rf>
    <LM>w#w-d1t2176-6</LM>
   </w.rf>
   <form>ochutit</form>
   <lemma>ochutit</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m132-100-109">
   <w.rf>
    <LM>w#w-100-109</LM>
   </w.rf>
   <form>něčím</form>
   <lemma>něco</lemma>
   <tag>PK--7----------</tag>
  </m>
  <m id="m132-d1t2176-7">
   <w.rf>
    <LM>w#w-d1t2176-7</LM>
   </w.rf>
   <form>čerstvým</form>
   <lemma>čerstvý</lemma>
   <tag>AANS7----1A----</tag>
  </m>
  <m id="m132-100-110">
   <w.rf>
    <LM>w#w-100-110</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-107">
  <m id="m132-d1t2178-2">
   <w.rf>
    <LM>w#w-d1t2178-2</LM>
   </w.rf>
   <form>Pokaždé</form>
   <lemma>pokaždé</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2178-3">
   <w.rf>
    <LM>w#w-d1t2178-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2178-4">
   <w.rf>
    <LM>w#w-d1t2178-4</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m132-d1t2178-6">
   <w.rf>
    <LM>w#w-d1t2178-6</LM>
   </w.rf>
   <form>někde</form>
   <lemma>někde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2178-5">
   <w.rf>
    <LM>w#w-d1t2178-5</LM>
   </w.rf>
   <form>koupila</form>
   <lemma>koupit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d1t2178-7">
   <w.rf>
    <LM>w#w-d1t2178-7</LM>
   </w.rf>
   <form>třeba</form>
   <lemma>třeba-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2181-1">
   <w.rf>
    <LM>w#w-d1t2181-1</LM>
   </w.rf>
   <form>čerstvou</form>
   <lemma>čerstvý</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m132-d1t2181-2">
   <w.rf>
    <LM>w#w-d1t2181-2</LM>
   </w.rf>
   <form>papriku</form>
   <lemma>paprika</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m132-d1t2181-3">
   <w.rf>
    <LM>w#w-d1t2181-3</LM>
   </w.rf>
   <form>nebo</form>
   <lemma>nebo</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2181-4">
   <w.rf>
    <LM>w#w-d1t2181-4</LM>
   </w.rf>
   <form>rajčata</form>
   <lemma>rajče</lemma>
   <tag>NNNP4-----A----</tag>
  </m>
  <m id="m132-d1t2181-5">
   <w.rf>
    <LM>w#w-d1t2181-5</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m132-d1t2181-6">
   <w.rf>
    <LM>w#w-d1t2181-6</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m132-d1t2181-7">
   <w.rf>
    <LM>w#w-d1t2181-7</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2181-8">
   <w.rf>
    <LM>w#w-d1t2181-8</LM>
   </w.rf>
   <form>si</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--3----------</tag>
  </m>
  <m id="m132-d1t2181-9">
   <w.rf>
    <LM>w#w-d1t2181-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m132-d1t2181-10">
   <w.rf>
    <LM>w#w-d1t2181-10</LM>
   </w.rf>
   <form>zpestřovala</form>
   <lemma>zpestřovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d-m-d1e2167-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2167-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2182-x2">
  <m id="m132-d1t2185-1">
   <w.rf>
    <LM>w#w-d1t2185-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--4----------</tag>
  </m>
  <m id="m132-d1t2185-2">
   <w.rf>
    <LM>w#w-d1t2185-2</LM>
   </w.rf>
   <form>vidíme</form>
   <lemma>vidět</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2185-3">
   <w.rf>
    <LM>w#w-d1t2185-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2185-4">
   <w.rf>
    <LM>w#w-d1t2185-4</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m132-d1t2185-5">
   <w.rf>
    <LM>w#w-d1t2185-5</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m132-d-id125966-punct">
   <w.rf>
    <LM>w#w-d-id125966-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2186-x2">
  <m id="m132-d1t2193-1">
   <w.rf>
    <LM>w#w-d1t2193-1</LM>
   </w.rf>
   <form>Na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2193-2">
   <w.rf>
    <LM>w#w-d1t2193-2</LM>
   </w.rf>
   <form>tomto</form>
   <lemma>tento</lemma>
   <tag>PDZS6----------</tag>
  </m>
  <m id="m132-d1t2193-3">
   <w.rf>
    <LM>w#w-d1t2193-3</LM>
   </w.rf>
   <form>snímku</form>
   <lemma>snímek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m132-d1t2195-1">
   <w.rf>
    <LM>w#w-d1t2195-1</LM>
   </w.rf>
   <form>mám</form>
   <lemma>mít</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2195-2">
   <w.rf>
    <LM>w#w-d1t2195-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2195-3">
   <w.rf>
    <LM>w#w-d1t2195-3</LM>
   </w.rf>
   <form>klíně</form>
   <lemma>klín</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m132-d1t2195-5">
   <w.rf>
    <LM>w#w-d1t2195-5</LM>
   </w.rf>
   <form>čokoládovou</form>
   <lemma>čokoládový</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m132-d1t2195-4">
   <w.rf>
    <LM>w#w-d1t2195-4</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m132-d1e2186-x2-124">
   <w.rf>
    <LM>w#w-d1e2186-x2-124</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-130">
  <m id="m132-d1t2195-7">
   <w.rf>
    <LM>w#w-d1t2195-7</LM>
   </w.rf>
   <form>Jmenuje</form>
   <lemma>jmenovat</lemma>
   <tag>VB-S---3P-AAB--</tag>
  </m>
  <m id="m132-d1t2195-8">
   <w.rf>
    <LM>w#w-d1t2195-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2195-10">
   <w.rf>
    <LM>w#w-d1t2195-10</LM>
   </w.rf>
   <form>Sára</form>
   <lemma>Sára_;Y</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m132-130-131">
   <w.rf>
    <LM>w#w-130-131</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-133">
  <m id="m132-d1t2200-4">
   <w.rf>
    <LM>w#w-d1t2200-4</LM>
   </w.rf>
   <form>Několik</form>
   <lemma>několik</lemma>
   <tag>Ca--4----------</tag>
  </m>
  <m id="m132-d1t2200-5">
   <w.rf>
    <LM>w#w-d1t2200-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m132-d1t2200-3">
   <w.rf>
    <LM>w#w-d1t2200-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2200-2">
   <w.rf>
    <LM>w#w-d1t2200-2</LM>
   </w.rf>
   <form>ji</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3-------</tag>
  </m>
  <m id="m132-d1t2200-6">
   <w.rf>
    <LM>w#w-d1t2200-6</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-133-134">
   <w.rf>
    <LM>w#w-133-134</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-123">
  <m id="m132-d1t2204-4">
   <w.rf>
    <LM>w#w-d1t2204-4</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m132-d1t2204-5">
   <w.rf>
    <LM>w#w-d1t2204-5</LM>
   </w.rf>
   <form>době</form>
   <lemma>doba</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m132-d-id126464-punct">
   <w.rf>
    <LM>w#w-d-id126464-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2204-7">
   <w.rf>
    <LM>w#w-d1t2204-7</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2204-8">
   <w.rf>
    <LM>w#w-d1t2204-8</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2204-9">
   <w.rf>
    <LM>w#w-d1t2204-9</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m132-d1t2204-10">
   <w.rf>
    <LM>w#w-d1t2204-10</LM>
   </w.rf>
   <form>narodila</form>
   <lemma>narodit</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d-id126535-punct">
   <w.rf>
    <LM>w#w-d-id126535-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m132-d1t2204-1">
   <w.rf>
    <LM>w#w-d1t2204-1</LM>
   </w.rf>
   <form>její</form>
   <lemma>jeho</lemma>
   <tag>P9FXXFS3-------</tag>
  </m>
  <m id="m132-d1t2204-2">
   <w.rf>
    <LM>w#w-d1t2204-2</LM>
   </w.rf>
   <form>matka</form>
   <lemma>matka</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m132-d1t2204-3">
   <w.rf>
    <LM>w#w-d1t2204-3</LM>
   </w.rf>
   <form>studovala</form>
   <lemma>studovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-123-138">
   <w.rf>
    <LM>w#w-123-138</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-140">
  <m id="m132-d1t2204-12">
   <w.rf>
    <LM>w#w-d1t2204-12</LM>
   </w.rf>
   <form>Tatínek</form>
   <lemma>tatínek</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m132-d1t2204-13">
   <w.rf>
    <LM>w#w-d1t2204-13</LM>
   </w.rf>
   <form>zmizel</form>
   <lemma>zmizet</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m132-d1t2204-14">
   <w.rf>
    <LM>w#w-d1t2204-14</LM>
   </w.rf>
   <form>velmi</form>
   <lemma>velmi</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2204-15">
   <w.rf>
    <LM>w#w-d1t2204-15</LM>
   </w.rf>
   <form>brzy</form>
   <lemma>brzy</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m132-140-145">
   <w.rf>
    <LM>w#w-140-145</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-144">
  <m id="m132-d1t2206-4">
   <w.rf>
    <LM>w#w-d1t2206-4</LM>
   </w.rf>
   <form>Potřebovala</form>
   <lemma>potřebovat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d1t2206-5">
   <w.rf>
    <LM>w#w-d1t2206-5</LM>
   </w.rf>
   <form>chodit</form>
   <lemma>chodit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m132-d1t2206-6">
   <w.rf>
    <LM>w#w-d1t2206-6</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m132-d1t2206-7">
   <w.rf>
    <LM>w#w-d1t2206-7</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m132-d1t2206-8">
   <w.rf>
    <LM>w#w-d1t2206-8</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2206-9">
   <w.rf>
    <LM>w#w-d1t2206-9</LM>
   </w.rf>
   <form>přednášky</form>
   <lemma>přednáška</lemma>
   <tag>NNFP4-----A----</tag>
  </m>
  <m id="m132-144-147">
   <w.rf>
    <LM>w#w-144-147</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-148">
  <m id="m132-d1t2208-2">
   <w.rf>
    <LM>w#w-d1t2208-2</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2210-1">
   <w.rf>
    <LM>w#w-d1t2210-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m132-d1t2210-2">
   <w.rf>
    <LM>w#w-d1t2210-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m132-d1t2210-3">
   <w.rf>
    <LM>w#w-d1t2210-3</LM>
   </w.rf>
   <form>holčičku</form>
   <lemma>holčička</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m132-d1t2210-4">
   <w.rf>
    <LM>w#w-d1t2210-4</LM>
   </w.rf>
   <form>hlídala</form>
   <lemma>hlídat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m132-d-m-d1e2186-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2186-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2212-x2">
  <m id="m132-d1t2215-1">
   <w.rf>
    <LM>w#w-d1t2215-1</LM>
   </w.rf>
   <form>Kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2215-2">
   <w.rf>
    <LM>w#w-d1t2215-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2215-3">
   <w.rf>
    <LM>w#w-d1t2215-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m132-d1t2215-4">
   <w.rf>
    <LM>w#w-d1t2215-4</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m132-d1t2215-5">
   <w.rf>
    <LM>w#w-d1t2215-5</LM>
   </w.rf>
   <form>ni</form>
   <lemma>on-1</lemma>
   <tag>PEFS4--3------1</tag>
  </m>
  <m id="m132-d1t2215-6">
   <w.rf>
    <LM>w#w-d1t2215-6</LM>
   </w.rf>
   <form>začala</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d1t2215-7">
   <w.rf>
    <LM>w#w-d1t2215-7</LM>
   </w.rf>
   <form>starat</form>
   <lemma>starat_^(se)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m132-d-id127022-punct">
   <w.rf>
    <LM>w#w-d-id127022-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2216-x2">
  <m id="m132-d1t2219-1">
   <w.rf>
    <LM>w#w-d1t2219-1</LM>
   </w.rf>
   <form>Když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m132-d1t2219-2">
   <w.rf>
    <LM>w#w-d1t2219-2</LM>
   </w.rf>
   <form>jí</form>
   <lemma>on-1</lemma>
   <tag>PEFS3--3------1</tag>
  </m>
  <m id="m132-d1t2219-3">
   <w.rf>
    <LM>w#w-d1t2219-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m132-d1t2219-4">
   <w.rf>
    <LM>w#w-d1t2219-4</LM>
   </w.rf>
   <form>asi</form>
   <lemma>asi</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m132-d1t2219-5">
   <w.rf>
    <LM>w#w-d1t2219-5</LM>
   </w.rf>
   <form>půl</form>
   <lemma>půl-1</lemma>
   <tag>Cl-XX----------</tag>
  </m>
  <m id="m132-d1t2219-6">
   <w.rf>
    <LM>w#w-d1t2219-6</LM>
   </w.rf>
   <form>roku</form>
   <lemma>rok</lemma>
   <tag>NNIS2-----A---1</tag>
  </m>
  <m id="m132-d-m-d1e2216-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e2216-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m132-d1e2220-x2">
  <m id="m132-d1t2223-1">
   <w.rf>
    <LM>w#w-d1t2223-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m132-d1t2223-2">
   <w.rf>
    <LM>w#w-d1t2223-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m132-d1t2223-3">
   <w.rf>
    <LM>w#w-d1t2223-3</LM>
   </w.rf>
   <form>k</form>
   <lemma>k-1</lemma>
   <tag>RR--3----------</tag>
  </m>
  <m id="m132-d1t2223-4">
   <w.rf>
    <LM>w#w-d1t2223-4</LM>
   </w.rf>
   <form>tomu</form>
   <lemma>ten</lemma>
   <tag>PDZS3----------</tag>
  </m>
  <m id="m132-d1t2223-5">
   <w.rf>
    <LM>w#w-d1t2223-5</LM>
   </w.rf>
   <form>přišla</form>
   <lemma>přijít</lemma>
   <tag>VpQW----R-AAP--</tag>
  </m>
  <m id="m132-d-id127307-punct">
   <w.rf>
    <LM>w#w-d-id127307-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
