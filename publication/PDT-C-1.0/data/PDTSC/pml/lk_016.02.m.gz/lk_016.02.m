<?xml version="1.0" encoding="UTF-8"?>
<mdata xmlns="http://ufal.mff.cuni.cz/pdt/pml/">
 <head>
  <schema href="mdata_c_schema.xml" />
  <references>
   <reffile id="w" name="wdata" href="lk_016.02.w.gz" />
  </references>
 </head>
 <s id="m016-d1e938-x2">
  <m id="m016-d1t941-1">
   <w.rf>
    <LM>w#w-d1t941-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t941-2">
   <w.rf>
    <LM>w#w-d1t941-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t941-3">
   <w.rf>
    <LM>w#w-d1t941-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d-id79784-punct">
   <w.rf>
    <LM>w#w-d-id79784-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e942-x2">
  <m id="m016-d1t945-1">
   <w.rf>
    <LM>w#w-d1t945-1</LM>
   </w.rf>
   <form>V</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t945-2">
   <w.rf>
    <LM>w#w-d1t945-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t945-3">
   <w.rf>
    <LM>w#w-d1t945-3</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d-id79907-punct">
   <w.rf>
    <LM>w#w-d-id79907-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t947-1">
   <w.rf>
    <LM>w#w-d1t947-1</LM>
   </w.rf>
   <form>jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t947-2">
   <w.rf>
    <LM>w#w-d1t947-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t947-3">
   <w.rf>
    <LM>w#w-d1t947-3</LM>
   </w.rf>
   <form>podotknul</form>
   <lemma>podotknout</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m016-d1e942-x2-412">
   <w.rf>
    <LM>w#w-d1e942-x2-412</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e950-x2">
  <m id="m016-d1t953-1">
   <w.rf>
    <LM>w#w-d1t953-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d-id80119-punct">
   <w.rf>
    <LM>w#w-d-id80119-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e955-x2">
  <m id="m016-d1t958-1">
   <w.rf>
    <LM>w#w-d1t958-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t958-2">
   <w.rf>
    <LM>w#w-d1t958-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t958-3">
   <w.rf>
    <LM>w#w-d1t958-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t958-5">
   <w.rf>
    <LM>w#w-d1t958-5</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m016-d1t968-1">
   <w.rf>
    <LM>w#w-d1t968-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t976-1">
   <w.rf>
    <LM>w#w-d1t976-1</LM>
   </w.rf>
   <form>kostele</form>
   <lemma>kostel</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t976-2">
   <w.rf>
    <LM>w#w-d1t976-2</LM>
   </w.rf>
   <form>Panny</form>
   <lemma>panna</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d1t976-4">
   <w.rf>
    <LM>w#w-d1t976-4</LM>
   </w.rf>
   <form>Marie</form>
   <lemma>Marie_;Y</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d1t978-2">
   <w.rf>
    <LM>w#w-d1t978-2</LM>
   </w.rf>
   <form>Sněžné</form>
   <lemma>sněžný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d-id80527-punct">
   <w.rf>
    <LM>w#w-d-id80527-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t980-1">
   <w.rf>
    <LM>w#w-d1t980-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t980-2">
   <w.rf>
    <LM>w#w-d1t980-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t980-3">
   <w.rf>
    <LM>w#w-d1t980-3</LM>
   </w.rf>
   <form>chodívali</form>
   <lemma>chodívat_^(*4it)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d1t980-4">
   <w.rf>
    <LM>w#w-d1t980-4</LM>
   </w.rf>
   <form>vždycky</form>
   <lemma>vždycky</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t982-2">
   <w.rf>
    <LM>w#w-d1t982-2</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t982-3">
   <w.rf>
    <LM>w#w-d1t982-3</LM>
   </w.rf>
   <form>neděli</form>
   <lemma>neděle</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t982-4">
   <w.rf>
    <LM>w#w-d1t982-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t982-5">
   <w.rf>
    <LM>w#w-d1t982-5</LM>
   </w.rf>
   <form>dopolední</form>
   <lemma>dopolední</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m016-d1t982-6">
   <w.rf>
    <LM>w#w-d1t982-6</LM>
   </w.rf>
   <form>mši</form>
   <lemma>mše</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-580-582">
   <w.rf>
    <LM>w#w-580-582</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-580">
  <m id="m016-d1t984-3">
   <w.rf>
    <LM>w#w-d1t984-3</LM>
   </w.rf>
   <form>Stáli</form>
   <lemma>stát-3_^(stojím_stojíš)</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d1t984-2">
   <w.rf>
    <LM>w#w-d1t984-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-580-584">
   <w.rf>
    <LM>w#w-580-584</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t984-4">
   <w.rf>
    <LM>w#w-d1t984-4</LM>
   </w.rf>
   <form>špalír</form>
   <lemma>špalír</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m016-d1t987-1">
   <w.rf>
    <LM>w#w-d1t987-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t987-2">
   <w.rf>
    <LM>w#w-d1t987-2</LM>
   </w.rf>
   <form>oltářem</form>
   <lemma>oltář</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m016-d1t991-1">
   <w.rf>
    <LM>w#w-d1t991-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t995-1">
   <w.rf>
    <LM>w#w-d1t995-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t995-2">
   <w.rf>
    <LM>w#w-d1t995-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t995-3">
   <w.rf>
    <LM>w#w-d1t995-3</LM>
   </w.rf>
   <form>pobožnosti</form>
   <lemma>pobožnost_^(*3ý)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d-id80934-punct">
   <w.rf>
    <LM>w#w-d-id80934-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t995-5">
   <w.rf>
    <LM>w#w-d1t995-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t995-6">
   <w.rf>
    <LM>w#w-d1t995-6</LM>
   </w.rf>
   <form>mši</form>
   <lemma>mše</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-580-71">
   <w.rf>
    <LM>w#w-580-71</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t997-1">
   <w.rf>
    <LM>w#w-d1t997-1</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t997-2">
   <w.rf>
    <LM>w#w-d1t997-2</LM>
   </w.rf>
   <form>měli</form>
   <lemma>mít</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d1t1000-1">
   <w.rf>
    <LM>w#w-d1t1000-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1000-2">
   <w.rf>
    <LM>w#w-d1t1000-2</LM>
   </w.rf>
   <form>děkanství</form>
   <lemma>děkanství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m016-d1t1000-3">
   <w.rf>
    <LM>w#w-d1t1000-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1000-5">
   <w.rf>
    <LM>w#w-d1t1000-5</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m016-d1t1000-7">
   <w.rf>
    <LM>w#w-d1t1000-7</LM>
   </w.rf>
   <form>besídku</form>
   <lemma>besídka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d-m-d1e973-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e973-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1003-x2">
  <m id="m016-d1t1008-1">
   <w.rf>
    <LM>w#w-d1t1008-1</LM>
   </w.rf>
   <form>Pamatuju</form>
   <lemma>pamatovat</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1008-2">
   <w.rf>
    <LM>w#w-d1t1008-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d-id81222-punct">
   <w.rf>
    <LM>w#w-d-id81222-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1008-4">
   <w.rf>
    <LM>w#w-d1t1008-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1018-1">
   <w.rf>
    <LM>w#w-d1t1018-1</LM>
   </w.rf>
   <form>můj</form>
   <lemma>můj</lemma>
   <tag>PSYS1-S1-------</tag>
  </m>
  <m id="m016-d1t1018-2">
   <w.rf>
    <LM>w#w-d1t1018-2</LM>
   </w.rf>
   <form>otec</form>
   <lemma>otec</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m016-d1t1018-3">
   <w.rf>
    <LM>w#w-d1t1018-3</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m016-d1t1018-4">
   <w.rf>
    <LM>w#w-d1t1018-4</LM>
   </w.rf>
   <form>vyrobil</form>
   <lemma>vyrobit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m016-d1t1018-5">
   <w.rf>
    <LM>w#w-d1t1018-5</LM>
   </w.rf>
   <form>loutkové</form>
   <lemma>loutkový</lemma>
   <tag>AANS4----1A----</tag>
  </m>
  <m id="m016-d1t1018-6">
   <w.rf>
    <LM>w#w-d1t1018-6</LM>
   </w.rf>
   <form>divadlo</form>
   <lemma>divadlo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m016-d-id81420-punct">
   <w.rf>
    <LM>w#w-d-id81420-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1018-8">
   <w.rf>
    <LM>w#w-d1t1018-8</LM>
   </w.rf>
   <form>tak</form>
   <lemma>tak-2</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1018-10">
   <w.rf>
    <LM>w#w-d1t1018-10</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1018-9">
   <w.rf>
    <LM>w#w-d1t1018-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m016-d1t1018-11">
   <w.rf>
    <LM>w#w-d1t1018-11</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1020-1">
   <w.rf>
    <LM>w#w-d1t1020-1</LM>
   </w.rf>
   <form>jeden</form>
   <lemma>jeden`1</lemma>
   <tag>CnIS4----------</tag>
  </m>
  <m id="m016-d1t1020-2">
   <w.rf>
    <LM>w#w-d1t1020-2</LM>
   </w.rf>
   <form>čas</form>
   <lemma>čas</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m016-d1t1020-3">
   <w.rf>
    <LM>w#w-d1t1020-3</LM>
   </w.rf>
   <form>provozovali</form>
   <lemma>provozovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d-m-d1e1015-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1015-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1021-x2">
  <m id="m016-d1t1024-1">
   <w.rf>
    <LM>w#w-d1t1024-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1024-2">
   <w.rf>
    <LM>w#w-d1t1024-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m016-d1t1024-3">
   <w.rf>
    <LM>w#w-d1t1024-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1024-4">
   <w.rf>
    <LM>w#w-d1t1024-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m016-d1t1024-5">
   <w.rf>
    <LM>w#w-d1t1024-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d-id81670-punct">
   <w.rf>
    <LM>w#w-d-id81670-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1025-x2">
  <m id="m016-d1t1030-1">
   <w.rf>
    <LM>w#w-d1t1030-1</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m016-d1t1030-2">
   <w.rf>
    <LM>w#w-d1t1030-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1030-3">
   <w.rf>
    <LM>w#w-d1t1030-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1030-4">
   <w.rf>
    <LM>w#w-d1t1030-4</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m016-d1t1030-5">
   <w.rf>
    <LM>w#w-d1t1030-5</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1030-6">
   <w.rf>
    <LM>w#w-d1t1030-6</LM>
   </w.rf>
   <form>úplně</form>
   <lemma>úplně_^(*1ý)</lemma>
   <tag>Dg-------1A----</tag>
  </m>
  <m id="m016-d1t1030-7">
   <w.rf>
    <LM>w#w-d1t1030-7</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1032-1">
   <w.rf>
    <LM>w#w-d1t1032-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1032-2">
   <w.rf>
    <LM>w#w-d1t1032-2</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrFS6----------</tag>
  </m>
  <m id="m016-d1t1032-3">
   <w.rf>
    <LM>w#w-d1t1032-3</LM>
   </w.rf>
   <form>řadě</form>
   <lemma>řada_^(linka,zástup,pořadí,...)</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1025-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1025-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1033-x2">
  <m id="m016-d1t1040-1">
   <w.rf>
    <LM>w#w-d1t1040-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m016-d1t1040-3">
   <w.rf>
    <LM>w#w-d1t1040-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1040-2">
   <w.rf>
    <LM>w#w-d1t1040-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1040-6">
   <w.rf>
    <LM>w#w-d1t1040-6</LM>
   </w.rf>
   <form>přijímání</form>
   <lemma>přijímání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m016-d-id82047-punct">
   <w.rf>
    <LM>w#w-d-id82047-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1041-x2">
  <m id="m016-d1t1046-3">
   <w.rf>
    <LM>w#w-d1t1046-3</LM>
   </w.rf>
   <form>První</form>
   <lemma>první-1</lemma>
   <tag>CrNS1----------</tag>
  </m>
  <m id="m016-d1t1046-4">
   <w.rf>
    <LM>w#w-d1t1046-4</LM>
   </w.rf>
   <form>přijímání</form>
   <lemma>přijímání_^(*3at)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m016-d1t1046-5">
   <w.rf>
    <LM>w#w-d1t1046-5</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1050-1">
   <w.rf>
    <LM>w#w-d1t1050-1</LM>
   </w.rf>
   <form>náboženský</form>
   <lemma>náboženský</lemma>
   <tag>AAIS1----1A----</tag>
  </m>
  <m id="m016-d1t1050-2">
   <w.rf>
    <LM>w#w-d1t1050-2</LM>
   </w.rf>
   <form>akt</form>
   <lemma>akt_^(čin;;obraz_nahého_těla)</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m016-d-id82259-punct">
   <w.rf>
    <LM>w#w-d-id82259-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1050-4">
   <w.rf>
    <LM>w#w-d1t1050-4</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1055-1">
   <w.rf>
    <LM>w#w-d1t1055-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1055-2">
   <w.rf>
    <LM>w#w-d1t1055-2</LM>
   </w.rf>
   <form>nejprve</form>
   <lemma>nejprve</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1055-3">
   <w.rf>
    <LM>w#w-d1t1055-3</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1055-4">
   <w.rf>
    <LM>w#w-d1t1055-4</LM>
   </w.rf>
   <form>ke</form>
   <lemma>k-1</lemma>
   <tag>RV--3----------</tag>
  </m>
  <m id="m016-d1t1055-5">
   <w.rf>
    <LM>w#w-d1t1055-5</LM>
   </w.rf>
   <form>zpovědi</form>
   <lemma>zpověď</lemma>
   <tag>NNFS3-----A----</tag>
  </m>
  <m id="m016-d1t1065-1">
   <w.rf>
    <LM>w#w-d1t1065-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1065-2">
   <w.rf>
    <LM>w#w-d1t1065-2</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1065-5">
   <w.rf>
    <LM>w#w-d1t1065-5</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1065-6">
   <w.rf>
    <LM>w#w-d1t1065-6</LM>
   </w.rf>
   <form>jde</form>
   <lemma>jít</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1065-7">
   <w.rf>
    <LM>w#w-d1t1065-7</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1065-8">
   <w.rf>
    <LM>w#w-d1t1065-8</LM>
   </w.rf>
   <form>první</form>
   <lemma>první-1</lemma>
   <tag>CrNS4----------</tag>
  </m>
  <m id="m016-d1t1065-9">
   <w.rf>
    <LM>w#w-d1t1065-9</LM>
   </w.rf>
   <form>přijímání</form>
   <lemma>přijímání_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m016-d1t1067-1">
   <w.rf>
    <LM>w#w-d1t1067-1</LM>
   </w.rf>
   <form>svaté</form>
   <lemma>svatý-1</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d1e1041-x2-606">
   <w.rf>
    <LM>w#w-d1e1041-x2-606</LM>
   </w.rf>
   <form>hostie</form>
   <lemma>hostie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1062-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1062-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1071-x2">
  <m id="m016-d1t1074-1">
   <w.rf>
    <LM>w#w-d1t1074-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1074-2">
   <w.rf>
    <LM>w#w-d1t1074-2</LM>
   </w.rf>
   <form>u</form>
   <lemma>u-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1074-3">
   <w.rf>
    <LM>w#w-d1t1074-3</LM>
   </w.rf>
   <form>vás</form>
   <lemma>vy</lemma>
   <tag>PP-P2--2-------</tag>
  </m>
  <m id="m016-d1t1074-4">
   <w.rf>
    <LM>w#w-d1t1074-4</LM>
   </w.rf>
   <form>bývalo</form>
   <lemma>bývat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1074-5">
   <w.rf>
    <LM>w#w-d1t1074-5</LM>
   </w.rf>
   <form>zvykem</form>
   <lemma>zvyk</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m016-d-id82782-punct">
   <w.rf>
    <LM>w#w-d-id82782-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1075-x2">
  <m id="m016-d1t1082-1">
   <w.rf>
    <LM>w#w-d1t1082-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1082-2">
   <w.rf>
    <LM>w#w-d1t1082-2</LM>
   </w.rf>
   <form>mých</form>
   <lemma>můj</lemma>
   <tag>PSXP2-S1-------</tag>
  </m>
  <m id="m016-d1t1082-3">
   <w.rf>
    <LM>w#w-d1t1082-3</LM>
   </w.rf>
   <form>mladých</form>
   <lemma>mladý</lemma>
   <tag>AANP2----1A----</tag>
  </m>
  <m id="m016-d1t1082-4">
   <w.rf>
    <LM>w#w-d1t1082-4</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m016-d-id82954-punct">
   <w.rf>
    <LM>w#w-d-id82954-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1084-1">
   <w.rf>
    <LM>w#w-d1t1084-1</LM>
   </w.rf>
   <form>když</form>
   <lemma>když</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1084-2">
   <w.rf>
    <LM>w#w-d1t1084-2</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1084-4">
   <w.rf>
    <LM>w#w-d1t1084-4</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1084-5">
   <w.rf>
    <LM>w#w-d1t1084-5</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1084-6">
   <w.rf>
    <LM>w#w-d1t1084-6</LM>
   </w.rf>
   <form>náboženství</form>
   <lemma>náboženství</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m016-d-id83065-punct">
   <w.rf>
    <LM>w#w-d-id83065-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1086-4">
   <w.rf>
    <LM>w#w-d1t1086-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1089-2">
   <w.rf>
    <LM>w#w-d1t1089-2</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1089-3">
   <w.rf>
    <LM>w#w-d1t1089-3</LM>
   </w.rf>
   <form>součást</form>
   <lemma>součást</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1089-4">
   <w.rf>
    <LM>w#w-d1t1089-4</LM>
   </w.rf>
   <form>výuky</form>
   <lemma>výuka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d1t1089-5">
   <w.rf>
    <LM>w#w-d1t1089-5</LM>
   </w.rf>
   <form>katechismu</form>
   <lemma>katechismus_,s_^(^DD**katechizmus)</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1075-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1075-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1090-x2">
  <m id="m016-d1t1093-1">
   <w.rf>
    <LM>w#w-d1t1093-1</LM>
   </w.rf>
   <form>Těšil</form>
   <lemma>těšit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1093-2">
   <w.rf>
    <LM>w#w-d1t1093-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m016-d1t1093-3">
   <w.rf>
    <LM>w#w-d1t1093-3</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1093-4">
   <w.rf>
    <LM>w#w-d1t1093-4</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1093-5">
   <w.rf>
    <LM>w#w-d1t1093-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1093-6">
   <w.rf>
    <LM>w#w-d1t1093-6</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS4----------</tag>
  </m>
  <m id="m016-d-id83377-punct">
   <w.rf>
    <LM>w#w-d-id83377-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1094-x2">
  <m id="m016-d1t1099-5">
   <w.rf>
    <LM>w#w-d1t1099-5</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1099-4">
   <w.rf>
    <LM>w#w-d1t1099-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1099-6">
   <w.rf>
    <LM>w#w-d1t1099-6</LM>
   </w.rf>
   <form>veliká</form>
   <lemma>veliký</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m016-d1t1099-7">
   <w.rf>
    <LM>w#w-d1t1099-7</LM>
   </w.rf>
   <form>událost</form>
   <lemma>událost</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d-id83556-punct">
   <w.rf>
    <LM>w#w-d-id83556-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1101-1">
   <w.rf>
    <LM>w#w-d1t1101-1</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1101-2">
   <w.rf>
    <LM>w#w-d1t1101-2</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1101-3">
   <w.rf>
    <LM>w#w-d1t1101-3</LM>
   </w.rf>
   <form>svatém</form>
   <lemma>svatý-1</lemma>
   <tag>AANS6----1A----</tag>
  </m>
  <m id="m016-d1t1101-4">
   <w.rf>
    <LM>w#w-d1t1101-4</LM>
   </w.rf>
   <form>přijímání</form>
   <lemma>přijímání_^(*3at)</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m016-d1t1103-1">
   <w.rf>
    <LM>w#w-d1t1103-1</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1103-2">
   <w.rf>
    <LM>w#w-d1t1103-2</LM>
   </w.rf>
   <form>obrovská</form>
   <lemma>obrovský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m016-d1t1103-3">
   <w.rf>
    <LM>w#w-d1t1103-3</LM>
   </w.rf>
   <form>slavnostní</form>
   <lemma>slavnostní</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m016-d1t1103-4">
   <w.rf>
    <LM>w#w-d1t1103-4</LM>
   </w.rf>
   <form>hostina</form>
   <lemma>hostina</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1105-1">
   <w.rf>
    <LM>w#w-d1t1105-1</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1105-2">
   <w.rf>
    <LM>w#w-d1t1105-2</LM>
   </w.rf>
   <form>děkanství</form>
   <lemma>děkanství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m016-d1t1105-3">
   <w.rf>
    <LM>w#w-d1t1105-3</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1105-5">
   <w.rf>
    <LM>w#w-d1t1105-5</LM>
   </w.rf>
   <form>Rokycanech</form>
   <lemma>Rokycany_;G</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m016-d1t1105-7">
   <w.rf>
    <LM>w#w-d1t1105-7</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1115-1">
   <w.rf>
    <LM>w#w-d1t1115-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1115-2">
   <w.rf>
    <LM>w#w-d1t1115-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1115-4">
   <w.rf>
    <LM>w#w-d1t1115-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1115-5">
   <w.rf>
    <LM>w#w-d1t1115-5</LM>
   </w.rf>
   <form>nových</form>
   <lemma>nový</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m016-d1t1115-6">
   <w.rf>
    <LM>w#w-d1t1115-6</LM>
   </w.rf>
   <form>šatech</form>
   <lemma>šat</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m016-d1e1094-x2-676">
   <w.rf>
    <LM>w#w-d1e1094-x2-676</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-678">
  <m id="m016-d1t1117-2">
   <w.rf>
    <LM>w#w-d1t1117-2</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-2</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1117-3">
   <w.rf>
    <LM>w#w-d1t1117-3</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1117-4">
   <w.rf>
    <LM>w#w-d1t1117-4</LM>
   </w.rf>
   <form>vidět</form>
   <lemma>vidět</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m016-d1t1117-5">
   <w.rf>
    <LM>w#w-d1t1117-5</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1117-6">
   <w.rf>
    <LM>w#w-d1t1117-6</LM>
   </w.rf>
   <form>obrázku</form>
   <lemma>obrázek</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m016-d-id84122-punct">
   <w.rf>
    <LM>w#w-d-id84122-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1117-8">
   <w.rf>
    <LM>w#w-d1t1117-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1117-9">
   <w.rf>
    <LM>w#w-d1t1117-9</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1117-10">
   <w.rf>
    <LM>w#w-d1t1117-10</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1t1117-11">
   <w.rf>
    <LM>w#w-d1t1117-11</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m016-d1t1117-12">
   <w.rf>
    <LM>w#w-d1t1117-12</LM>
   </w.rf>
   <form>šerpou</form>
   <lemma>šerpa-2</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m016-678-98">
   <w.rf>
    <LM>w#w-678-98</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-99">
  <m id="m016-d1t1121-1">
   <w.rf>
    <LM>w#w-d1t1121-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1121-2">
   <w.rf>
    <LM>w#w-d1t1121-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1121-3">
   <w.rf>
    <LM>w#w-d1t1121-3</LM>
   </w.rf>
   <form>paměť</form>
   <lemma>paměť</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t1121-4">
   <w.rf>
    <LM>w#w-d1t1121-4</LM>
   </w.rf>
   <form>prvního</form>
   <lemma>první-1</lemma>
   <tag>CrNS2----------</tag>
  </m>
  <m id="m016-d1t1121-5">
   <w.rf>
    <LM>w#w-d1t1121-5</LM>
   </w.rf>
   <form>přijímání</form>
   <lemma>přijímání_^(*3at)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m016-d-id84359-punct">
   <w.rf>
    <LM>w#w-d-id84359-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1121-8">
   <w.rf>
    <LM>w#w-d1t1121-8</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1121-7">
   <w.rf>
    <LM>w#w-d1t1121-7</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1121-9">
   <w.rf>
    <LM>w#w-d1t1121-9</LM>
   </w.rf>
   <form>datum</form>
   <lemma>datum-1_^(kalendářní)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m016-d1t1121-10">
   <w.rf>
    <LM>w#w-d1t1121-10</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1121-11">
   <w.rf>
    <LM>w#w-d1t1121-11</LM>
   </w.rf>
   <form>ročník</form>
   <lemma>ročník</lemma>
   <tag>NNIS1-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1112-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1112-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1127-x2">
  <m id="m016-d1t1130-1">
   <w.rf>
    <LM>w#w-d1t1130-1</LM>
   </w.rf>
   <form>Je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1130-2">
   <w.rf>
    <LM>w#w-d1t1130-2</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1130-3">
   <w.rf>
    <LM>w#w-d1t1130-3</LM>
   </w.rf>
   <form>té</form>
   <lemma>ten</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m016-d1t1130-4">
   <w.rf>
    <LM>w#w-d1t1130-4</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1130-5">
   <w.rf>
    <LM>w#w-d1t1130-5</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1130-6">
   <w.rf>
    <LM>w#w-d1t1130-6</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m016-d-id84602-punct">
   <w.rf>
    <LM>w#w-d-id84602-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1130-8">
   <w.rf>
    <LM>w#w-d1t1130-8</LM>
   </w.rf>
   <form>o</form>
   <lemma>o-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1130-9">
   <w.rf>
    <LM>w#w-d1t1130-9</LM>
   </w.rf>
   <form>kom</form>
   <lemma>kdo</lemma>
   <tag>PQ--6----------</tag>
  </m>
  <m id="m016-d1t1130-10">
   <w.rf>
    <LM>w#w-d1t1130-10</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m016-d1t1130-11">
   <w.rf>
    <LM>w#w-d1t1130-11</LM>
   </w.rf>
   <form>něco</form>
   <lemma>něco</lemma>
   <tag>PK--4----------</tag>
  </m>
  <m id="m016-d1t1130-12">
   <w.rf>
    <LM>w#w-d1t1130-12</LM>
   </w.rf>
   <form>řeknete</form>
   <lemma>říci</lemma>
   <tag>VB-P---2P-AAP--</tag>
  </m>
  <m id="m016-d-id84681-punct">
   <w.rf>
    <LM>w#w-d-id84681-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1131-x2">
  <m id="m016-d1t1138-1">
   <w.rf>
    <LM>w#w-d1t1138-1</LM>
   </w.rf>
   <form>Byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d1t1138-2">
   <w.rf>
    <LM>w#w-d1t1138-2</LM>
   </w.rf>
   <form>tam</form>
   <lemma>tam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1140-1">
   <w.rf>
    <LM>w#w-d1t1140-1</LM>
   </w.rf>
   <form>všichni</form>
   <lemma>všechen</lemma>
   <tag>PLMP1----------</tag>
  </m>
  <m id="m016-d1t1140-2">
   <w.rf>
    <LM>w#w-d1t1140-2</LM>
   </w.rf>
   <form>moji</form>
   <lemma>můj</lemma>
   <tag>PSMP1-S1-------</tag>
  </m>
  <m id="m016-d1t1140-3">
   <w.rf>
    <LM>w#w-d1t1140-3</LM>
   </w.rf>
   <form>spolužáci</form>
   <lemma>spolužák</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m016-d1t1140-4">
   <w.rf>
    <LM>w#w-d1t1140-4</LM>
   </w.rf>
   <form>z</form>
   <lemma>z-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1140-5">
   <w.rf>
    <LM>w#w-d1t1140-5</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d1t1140-6">
   <w.rf>
    <LM>w#w-d1t1140-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d-id84924-punct">
   <w.rf>
    <LM>w#w-d-id84924-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1148-1">
   <w.rf>
    <LM>w#w-d1t1148-1</LM>
   </w.rf>
   <form>kam</form>
   <lemma>kam</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1148-2">
   <w.rf>
    <LM>w#w-d1t1148-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1148-3">
   <w.rf>
    <LM>w#w-d1t1148-3</LM>
   </w.rf>
   <form>chodili</form>
   <lemma>chodit</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d-m-d1e1143-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1143-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1155-x2">
  <m id="m016-d1e1155-x2-746">
   <w.rf>
    <LM>w#w-d1e1155-x2-746</LM>
   </w.rf>
   <form>S</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1e1155-x2-748">
   <w.rf>
    <LM>w#w-d1e1155-x2-748</LM>
   </w.rf>
   <form>těmi</form>
   <lemma>ten</lemma>
   <tag>PDXP7----------</tag>
  </m>
  <m id="m016-d1e1155-x2-750">
   <w.rf>
    <LM>w#w-d1e1155-x2-750</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1e1155-x2-752">
   <w.rf>
    <LM>w#w-d1e1155-x2-752</LM>
   </w.rf>
   <form>de</form>
   <lemma>de-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m016-d1e1155-x2-754">
   <w.rf>
    <LM>w#w-d1e1155-x2-754</LM>
   </w.rf>
   <form>facto</form>
   <lemma>facto-77</lemma>
   <tag>F%-------------</tag>
  </m>
  <m id="m016-d1e1155-x2-756">
   <w.rf>
    <LM>w#w-d1e1155-x2-756</LM>
   </w.rf>
   <form>ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1e1155-x2-105">
   <w.rf>
    <LM>w#w-d1e1155-x2-105</LM>
   </w.rf>
   <form>se</form>
   <lemma>s-1</lemma>
   <tag>RV--7----------</tag>
  </m>
  <m id="m016-d1e1155-x2-758">
   <w.rf>
    <LM>w#w-d1e1155-x2-758</LM>
   </w.rf>
   <form>všemi</form>
   <lemma>všechen</lemma>
   <tag>PLXP7----------</tag>
  </m>
  <m id="m016-d1e1155-x2-106">
   <w.rf>
    <LM>w#w-d1e1155-x2-106</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1162-9">
   <w.rf>
    <LM>w#w-d1t1162-9</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1162-10">
   <w.rf>
    <LM>w#w-d1t1162-10</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1162-11">
   <w.rf>
    <LM>w#w-d1t1162-11</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1162-12">
   <w.rf>
    <LM>w#w-d1t1162-12</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1162-8">
   <w.rf>
    <LM>w#w-d1t1162-8</LM>
   </w.rf>
   <form>rozprchli</form>
   <lemma>rozprchnout</lemma>
   <tag>VpMP----R-AAP-1</tag>
  </m>
  <m id="m016-d1e1155-x2-760">
   <w.rf>
    <LM>w#w-d1e1155-x2-760</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-762">
  <m id="m016-d1t1166-1">
   <w.rf>
    <LM>w#w-d1t1166-1</LM>
   </w.rf>
   <form>Někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m016-d1t1166-3">
   <w.rf>
    <LM>w#w-d1t1166-3</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1166-4">
   <w.rf>
    <LM>w#w-d1t1166-4</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m016-d1t1166-5">
   <w.rf>
    <LM>w#w-d1t1166-5</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1166-6">
   <w.rf>
    <LM>w#w-d1t1166-6</LM>
   </w.rf>
   <form>navštěvoval</form>
   <lemma>navštěvovat</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1166-7">
   <w.rf>
    <LM>w#w-d1t1166-7</LM>
   </w.rf>
   <form>gymnázium</form>
   <lemma>gymnázium</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m016-d-id85458-punct">
   <w.rf>
    <LM>w#w-d-id85458-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1171-1">
   <w.rf>
    <LM>w#w-d1t1171-1</LM>
   </w.rf>
   <form>někdo</form>
   <lemma>někdo</lemma>
   <tag>PK--1----------</tag>
  </m>
  <m id="m016-d1t1175-2">
   <w.rf>
    <LM>w#w-d1t1175-2</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1175-4">
   <w.rf>
    <LM>w#w-d1t1175-4</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1175-5">
   <w.rf>
    <LM>w#w-d1t1175-5</LM>
   </w.rf>
   <form>měšťanské</form>
   <lemma>měšťanský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d1t1175-6">
   <w.rf>
    <LM>w#w-d1t1175-6</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d-id85651-punct">
   <w.rf>
    <LM>w#w-d-id85651-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1e1155-x2-744">
   <w.rf>
    <LM>w#w-d1e1155-x2-744</LM>
   </w.rf>
   <form>která</form>
   <lemma>který</lemma>
   <tag>P4FS1----------</tag>
  </m>
  <m id="m016-d1t1175-9">
   <w.rf>
    <LM>w#w-d1t1175-9</LM>
   </w.rf>
   <form>měla</form>
   <lemma>mít</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1175-12">
   <w.rf>
    <LM>w#w-d1t1175-12</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1175-10">
   <w.rf>
    <LM>w#w-d1t1175-10</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m016-d1t1175-11">
   <w.rf>
    <LM>w#w-d1t1175-11</LM>
   </w.rf>
   <form>ročníky</form>
   <lemma>ročník</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1155-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1155-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1185-x2">
  <m id="m016-d1t1190-1">
   <w.rf>
    <LM>w#w-d1t1190-1</LM>
   </w.rf>
   <form>Můžu</form>
   <lemma>moci</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1190-2">
   <w.rf>
    <LM>w#w-d1t1190-2</LM>
   </w.rf>
   <form>říct</form>
   <lemma>říci</lemma>
   <tag>Vf--------A-P-1</tag>
  </m>
  <m id="m016-d-id85916-punct">
   <w.rf>
    <LM>w#w-d-id85916-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1190-4">
   <w.rf>
    <LM>w#w-d1t1190-4</LM>
   </w.rf>
   <form>že</form>
   <lemma>že-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1190-5">
   <w.rf>
    <LM>w#w-d1t1190-5</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1190-6">
   <w.rf>
    <LM>w#w-d1t1190-6</LM>
   </w.rf>
   <form>mnohými</form>
   <lemma>mnohý</lemma>
   <tag>AAMP7----1A----</tag>
  </m>
  <m id="m016-d1t1192-1">
   <w.rf>
    <LM>w#w-d1t1192-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1192-2">
   <w.rf>
    <LM>w#w-d1t1192-2</LM>
   </w.rf>
   <form>scházíme</form>
   <lemma>scházet</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1192-3">
   <w.rf>
    <LM>w#w-d1t1192-3</LM>
   </w.rf>
   <form>dodnes</form>
   <lemma>dodnes</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d-id86026-punct">
   <w.rf>
    <LM>w#w-d-id86026-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1192-5">
   <w.rf>
    <LM>w#w-d1t1192-5</LM>
   </w.rf>
   <form>protože</form>
   <lemma>protože</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1192-6">
   <w.rf>
    <LM>w#w-d1t1192-6</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1194-1">
   <w.rf>
    <LM>w#w-d1t1194-1</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1194-2">
   <w.rf>
    <LM>w#w-d1t1194-2</LM>
   </w.rf>
   <form>dlouhou</form>
   <lemma>dlouhý_^(tyč;doba)</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m016-d1t1194-3">
   <w.rf>
    <LM>w#w-d1t1194-3</LM>
   </w.rf>
   <form>dobu</form>
   <lemma>doba</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t1194-4">
   <w.rf>
    <LM>w#w-d1t1194-4</LM>
   </w.rf>
   <form>skautovali</form>
   <lemma>skautovat</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d-m-d1e1185-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1185-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1195-x2">
  <m id="m016-d1t1200-1">
   <w.rf>
    <LM>w#w-d1t1200-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1200-2">
   <w.rf>
    <LM>w#w-d1t1200-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1200-3">
   <w.rf>
    <LM>w#w-d1t1200-3</LM>
   </w.rf>
   <form>pěkné</form>
   <lemma>pěkný</lemma>
   <tag>AANS1----1A----</tag>
  </m>
  <m id="m016-d1e1195-x2-802">
   <w.rf>
    <LM>w#w-d1e1195-x2-802</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-804">
  <m id="m016-d1t1206-1">
   <w.rf>
    <LM>w#w-d1t1206-1</LM>
   </w.rf>
   <form>Můžeme</form>
   <lemma>moci</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1206-2">
   <w.rf>
    <LM>w#w-d1t1206-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1206-3">
   <w.rf>
    <LM>w#w-d1t1206-3</LM>
   </w.rf>
   <form>podívat</form>
   <lemma>podívat</lemma>
   <tag>Vf--------A-P--</tag>
  </m>
  <m id="m016-d1t1206-4">
   <w.rf>
    <LM>w#w-d1t1206-4</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1206-5">
   <w.rf>
    <LM>w#w-d1t1206-5</LM>
   </w.rf>
   <form>další</form>
   <lemma>další</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m016-d1t1206-6">
   <w.rf>
    <LM>w#w-d1t1206-6</LM>
   </w.rf>
   <form>fotku</form>
   <lemma>fotka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d-id86383-punct">
   <w.rf>
    <LM>w#w-d-id86383-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1207-x2">
  <m id="m016-d1t1210-1">
   <w.rf>
    <LM>w#w-d1t1210-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1e1207-x2-806">
   <w.rf>
    <LM>w#w-d1e1207-x2-806</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1210-2">
   <w.rf>
    <LM>w#w-d1t1210-2</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d-m-d1e1207-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1207-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1211-x2">
  <m id="m016-d1t1214-1">
   <w.rf>
    <LM>w#w-d1t1214-1</LM>
   </w.rf>
   <form>Kdo</form>
   <lemma>kdo</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m016-d1t1214-2">
   <w.rf>
    <LM>w#w-d1t1214-2</LM>
   </w.rf>
   <form>je</form>
   <lemma>být</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1214-3">
   <w.rf>
    <LM>w#w-d1t1214-3</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1214-4">
   <w.rf>
    <LM>w#w-d1t1214-4</LM>
   </w.rf>
   <form>téhle</form>
   <lemma>tenhle</lemma>
   <tag>PDFS6----------</tag>
  </m>
  <m id="m016-d1t1216-1">
   <w.rf>
    <LM>w#w-d1t1216-1</LM>
   </w.rf>
   <form>fotce</form>
   <lemma>fotka</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d-id86614-punct">
   <w.rf>
    <LM>w#w-d-id86614-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1217-x2">
  <m id="m016-d1t1224-1">
   <w.rf>
    <LM>w#w-d1t1224-1</LM>
   </w.rf>
   <form>To</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1224-2">
   <w.rf>
    <LM>w#w-d1t1224-2</LM>
   </w.rf>
   <form>jsme</form>
   <lemma>být</lemma>
   <tag>VB-P---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1224-3">
   <w.rf>
    <LM>w#w-d1t1224-3</LM>
   </w.rf>
   <form>my</form>
   <lemma>my</lemma>
   <tag>PP-P1--1-------</tag>
  </m>
  <m id="m016-d1e1217-x2-814">
   <w.rf>
    <LM>w#w-d1e1217-x2-814</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1224-4">
   <w.rf>
    <LM>w#w-d1t1224-4</LM>
   </w.rf>
   <form>sokolové</form>
   <lemma>sokol-1</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1217-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1217-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1227-x3">
  <m id="m016-d1t1234-1">
   <w.rf>
    <LM>w#w-d1t1234-1</LM>
   </w.rf>
   <form>Kde</form>
   <lemma>kde</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1234-2">
   <w.rf>
    <LM>w#w-d1t1234-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m016-d1t1234-3">
   <w.rf>
    <LM>w#w-d1t1234-3</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m016-d-id86911-punct">
   <w.rf>
    <LM>w#w-d-id86911-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1235-x2">
  <m id="m016-d1t1238-2">
   <w.rf>
    <LM>w#w-d1t1238-2</LM>
   </w.rf>
   <form>Já</form>
   <lemma>já</lemma>
   <tag>PP-S1--1-------</tag>
  </m>
  <m id="m016-d1t1238-3">
   <w.rf>
    <LM>w#w-d1t1238-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1240-1">
   <w.rf>
    <LM>w#w-d1t1240-1</LM>
   </w.rf>
   <form>vlevo</form>
   <lemma>vlevo</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1e1235-x2-824">
   <w.rf>
    <LM>w#w-d1e1235-x2-824</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1238-4">
   <w.rf>
    <LM>w#w-d1t1238-4</LM>
   </w.rf>
   <form>hned</form>
   <lemma>hned-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1240-2">
   <w.rf>
    <LM>w#w-d1t1240-2</LM>
   </w.rf>
   <form>vedle</form>
   <lemma>vedle-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1240-3">
   <w.rf>
    <LM>w#w-d1t1240-3</LM>
   </w.rf>
   <form>děla</form>
   <lemma>dělo</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1235-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1235-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1245-x2">
  <m id="m016-d1t1250-1">
   <w.rf>
    <LM>w#w-d1t1250-1</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1250-2">
   <w.rf>
    <LM>w#w-d1t1250-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1250-4">
   <w.rf>
    <LM>w#w-d1t1250-4</LM>
   </w.rf>
   <form>příprava</form>
   <lemma>příprava</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1263-1">
   <w.rf>
    <LM>w#w-d1t1263-1</LM>
   </w.rf>
   <form>sokolské</form>
   <lemma>sokolský</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d1t1263-2">
   <w.rf>
    <LM>w#w-d1t1263-2</LM>
   </w.rf>
   <form>akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d1t1265-1">
   <w.rf>
    <LM>w#w-d1t1265-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1265-2">
   <w.rf>
    <LM>w#w-d1t1265-2</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1265-3">
   <w.rf>
    <LM>w#w-d1t1265-3</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d-m-d1e1268-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1268-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1268-x3">
  <m id="m016-d1t1279-1">
   <w.rf>
    <LM>w#w-d1t1279-1</LM>
   </w.rf>
   <form>Kolik</form>
   <lemma>kolik</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m016-d1t1279-2">
   <w.rf>
    <LM>w#w-d1t1279-2</LM>
   </w.rf>
   <form>vám</form>
   <lemma>vy</lemma>
   <tag>PP-P3--2-------</tag>
  </m>
  <m id="m016-d1t1279-3">
   <w.rf>
    <LM>w#w-d1t1279-3</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1279-4">
   <w.rf>
    <LM>w#w-d1t1279-4</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1279-5">
   <w.rf>
    <LM>w#w-d1t1279-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m016-d-id87624-punct">
   <w.rf>
    <LM>w#w-d-id87624-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1280-x2">
  <m id="m016-d1t1285-3">
   <w.rf>
    <LM>w#w-d1t1285-3</LM>
   </w.rf>
   <form>Bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1285-2">
   <w.rf>
    <LM>w#w-d1t1285-2</LM>
   </w.rf>
   <form>mi</form>
   <lemma>já</lemma>
   <tag>PH-S3--1-------</tag>
  </m>
  <m id="m016-d1t1285-4">
   <w.rf>
    <LM>w#w-d1t1285-4</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S1----------</tag>
  </m>
  <m id="m016-d1t1285-5">
   <w.rf>
    <LM>w#w-d1t1285-5</LM>
   </w.rf>
   <form>let</form>
   <lemma>léta</lemma>
   <tag>NNNP2-----A----</tag>
  </m>
  <m id="m016-d1t1287-1">
   <w.rf>
    <LM>w#w-d1t1287-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1287-2">
   <w.rf>
    <LM>w#w-d1t1287-2</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1287-3">
   <w.rf>
    <LM>w#w-d1t1287-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1287-4">
   <w.rf>
    <LM>w#w-d1t1287-4</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m016-d1t1287-5">
   <w.rf>
    <LM>w#w-d1t1287-5</LM>
   </w.rf>
   <form>funkci</form>
   <lemma>funkce</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1287-6">
   <w.rf>
    <LM>w#w-d1t1287-6</LM>
   </w.rf>
   <form>dělovoda</form>
   <lemma>dělovod</lemma>
   <tag>NNMS2-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1280-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1280-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1297-x2">
  <m id="m016-d1t1302-1">
   <w.rf>
    <LM>w#w-d1t1302-1</LM>
   </w.rf>
   <form>Jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1302-2">
   <w.rf>
    <LM>w#w-d1t1302-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1e1297-x2-854">
   <w.rf>
    <LM>w#w-d1e1297-x2-854</LM>
   </w.rf>
   <form>tím</form>
   <lemma>ten</lemma>
   <tag>PDZS7----------</tag>
  </m>
  <m id="m016-d1t1302-3">
   <w.rf>
    <LM>w#w-d1t1302-3</LM>
   </w.rf>
   <form>hochem</form>
   <lemma>hoch</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m016-d1e1297-x2-856">
   <w.rf>
    <LM>w#w-d1e1297-x2-856</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1302-4">
   <w.rf>
    <LM>w#w-d1t1302-4</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m016-d1t1302-5">
   <w.rf>
    <LM>w#w-d1t1302-5</LM>
   </w.rf>
   <form>drží</form>
   <lemma>držet</lemma>
   <tag>VB-S---3P-AAI--</tag>
  </m>
  <m id="m016-d1t1304-1">
   <w.rf>
    <LM>w#w-d1t1304-1</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1304-2">
   <w.rf>
    <LM>w#w-d1t1304-2</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m016-d1t1302-6">
   <w.rf>
    <LM>w#w-d1t1302-6</LM>
   </w.rf>
   <form>střelu</form>
   <lemma>střela</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1297-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1297-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1305-x2">
  <m id="m016-d1t1308-1">
   <w.rf>
    <LM>w#w-d1t1308-1</LM>
   </w.rf>
   <form>Co</form>
   <lemma>co-1</lemma>
   <tag>PQ--1----------</tag>
  </m>
  <m id="m016-d1t1308-2">
   <w.rf>
    <LM>w#w-d1t1308-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1308-3">
   <w.rf>
    <LM>w#w-d1t1308-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1308-4">
   <w.rf>
    <LM>w#w-d1t1308-4</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1308-5">
   <w.rf>
    <LM>w#w-d1t1308-5</LM>
   </w.rf>
   <form>akademii</form>
   <lemma>akademie</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d-id88302-punct">
   <w.rf>
    <LM>w#w-d-id88302-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1311-x2">
  <m id="m016-d1t1318-1">
   <w.rf>
    <LM>w#w-d1t1318-1</LM>
   </w.rf>
   <form>Byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1318-2">
   <w.rf>
    <LM>w#w-d1t1318-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1318-3">
   <w.rf>
    <LM>w#w-d1t1318-3</LM>
   </w.rf>
   <form>sokolská</form>
   <lemma>sokolský</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m016-d1t1318-4">
   <w.rf>
    <LM>w#w-d1t1318-4</LM>
   </w.rf>
   <form>akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1322-4">
   <w.rf>
    <LM>w#w-d1t1322-4</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1322-5">
   <w.rf>
    <LM>w#w-d1t1322-5</LM>
   </w.rf>
   <form>sokolským</form>
   <lemma>sokolský</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m016-d1t1322-6">
   <w.rf>
    <LM>w#w-d1t1322-6</LM>
   </w.rf>
   <form>sletem</form>
   <lemma>slet</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m016-d1t1327-4">
   <w.rf>
    <LM>w#w-d1t1327-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1327-5">
   <w.rf>
    <LM>w#w-d1t1327-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1327-6">
   <w.rf>
    <LM>w#w-d1t1327-6</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d-id88548-punct">
   <w.rf>
    <LM>w#w-d-id88548-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1322-8">
   <w.rf>
    <LM>w#w-d1t1322-8</LM>
   </w.rf>
   <form>který</form>
   <lemma>který</lemma>
   <tag>P4YS1----------</tag>
  </m>
  <m id="m016-d1t1322-9">
   <w.rf>
    <LM>w#w-d1t1322-9</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1327-1">
   <w.rf>
    <LM>w#w-d1t1327-1</LM>
   </w.rf>
   <form>číslo</form>
   <lemma>číslo</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m016-d1t1327-2">
   <w.rf>
    <LM>w#w-d1t1327-2</LM>
   </w.rf>
   <form>deset</form>
   <lemma>deset`10</lemma>
   <tag>Cl-S4----------</tag>
  </m>
  <m id="m016-d1t1335-1">
   <w.rf>
    <LM>w#w-d1t1335-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1335-2">
   <w.rf>
    <LM>w#w-d1t1335-2</LM>
   </w.rf>
   <form>kterého</form>
   <lemma>který</lemma>
   <tag>P4ZS2----------</tag>
  </m>
  <m id="m016-d1t1335-3">
   <w.rf>
    <LM>w#w-d1t1335-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1335-4">
   <w.rf>
    <LM>w#w-d1t1335-4</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1335-5">
   <w.rf>
    <LM>w#w-d1t1335-5</LM>
   </w.rf>
   <form>zúčastnil</form>
   <lemma>zúčastnit</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m016-d1t1349-1">
   <w.rf>
    <LM>w#w-d1t1349-1</LM>
   </w.rf>
   <form>jako</form>
   <lemma>jako-1</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1349-2">
   <w.rf>
    <LM>w#w-d1t1349-2</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m016-d1t1349-3">
   <w.rf>
    <LM>w#w-d1t1349-3</LM>
   </w.rf>
   <form>žák</form>
   <lemma>žák</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m016-d1e1311-x2-904">
   <w.rf>
    <LM>w#w-d1e1311-x2-904</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1357-1">
   <w.rf>
    <LM>w#w-d1t1357-1</LM>
   </w.rf>
   <form>mladší</form>
   <lemma>mladý</lemma>
   <tag>AAMS1----2A----</tag>
  </m>
  <m id="m016-d1t1357-2">
   <w.rf>
    <LM>w#w-d1t1357-2</LM>
   </w.rf>
   <form>sokol</form>
   <lemma>sokol-1</lemma>
   <tag>NNMS1-----A----</tag>
  </m>
  <m id="m016-d1t1347-1">
   <w.rf>
    <LM>w#w-d1t1347-1</LM>
   </w.rf>
   <form>s</form>
   <lemma>s-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1347-2">
   <w.rf>
    <LM>w#w-d1t1347-2</LM>
   </w.rf>
   <form>jednou</form>
   <lemma>jeden`1</lemma>
   <tag>CnFS7----------</tag>
  </m>
  <m id="m016-d1t1347-3">
   <w.rf>
    <LM>w#w-d1t1347-3</LM>
   </w.rf>
   <form>šipkou</form>
   <lemma>šipka</lemma>
   <tag>NNFS7-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1352-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1352-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1352-x3">
  <m id="m016-d1t1359-1">
   <w.rf>
    <LM>w#w-d1t1359-1</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1359-2">
   <w.rf>
    <LM>w#w-d1t1359-2</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m016-d1t1359-3">
   <w.rf>
    <LM>w#w-d1t1359-3</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m016-d1t1359-4">
   <w.rf>
    <LM>w#w-d1t1359-4</LM>
   </w.rf>
   <form>byl</form>
   <lemma>být</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1359-5">
   <w.rf>
    <LM>w#w-d1t1359-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1359-6">
   <w.rf>
    <LM>w#w-d1t1359-6</LM>
   </w.rf>
   <form>Sokolu</form>
   <lemma>Sokol-2_;m_^(organizace)</lemma>
   <tag>NNIS6-----A----</tag>
  </m>
  <m id="m016-d-id89298-punct">
   <w.rf>
    <LM>w#w-d-id89298-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1360-x2">
  <m id="m016-d1t1363-1">
   <w.rf>
    <LM>w#w-d1t1363-1</LM>
   </w.rf>
   <form>Ano</form>
   <lemma>ano</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1e1360-x2-922">
   <w.rf>
    <LM>w#w-d1e1360-x2-922</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1363-2">
   <w.rf>
    <LM>w#w-d1t1363-2</LM>
   </w.rf>
   <form>prosím</form>
   <lemma>prosit</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1e1360-x2-918">
   <w.rf>
    <LM>w#w-d1e1360-x2-918</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-920">
  <m id="m016-d1t1367-3">
   <w.rf>
    <LM>w#w-d1t1367-3</LM>
   </w.rf>
   <form>Akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1374-1">
   <w.rf>
    <LM>w#w-d1t1374-1</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1374-2">
   <w.rf>
    <LM>w#w-d1t1374-2</LM>
   </w.rf>
   <form>konala</form>
   <lemma>konat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1374-3">
   <w.rf>
    <LM>w#w-d1t1374-3</LM>
   </w.rf>
   <form>každým</form>
   <lemma>každý</lemma>
   <tag>AAIS7----1A----</tag>
  </m>
  <m id="m016-d1t1374-4">
   <w.rf>
    <LM>w#w-d1t1374-4</LM>
   </w.rf>
   <form>rokem</form>
   <lemma>rok</lemma>
   <tag>NNIS7-----A----</tag>
  </m>
  <m id="m016-d-id89559-punct">
   <w.rf>
    <LM>w#w-d-id89559-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1376-1">
   <w.rf>
    <LM>w#w-d1t1376-1</LM>
   </w.rf>
   <form>ovšem</form>
   <lemma>ovšem</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1t1376-2">
   <w.rf>
    <LM>w#w-d1t1376-2</LM>
   </w.rf>
   <form>tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1376-4">
   <w.rf>
    <LM>w#w-d1t1376-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1376-5">
   <w.rf>
    <LM>w#w-d1t1376-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1376-6">
   <w.rf>
    <LM>w#w-d1t1376-6</LM>
   </w.rf>
   <form>1938</form>
   <lemma>1938</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d1t1376-8">
   <w.rf>
    <LM>w#w-d1t1376-8</LM>
   </w.rf>
   <form>byla</form>
   <lemma>být</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1376-9">
   <w.rf>
    <LM>w#w-d1t1376-9</LM>
   </w.rf>
   <form>zaměřená</form>
   <lemma>zaměřený_^(*3it)</lemma>
   <tag>AAFS1----1A----</tag>
  </m>
  <m id="m016-d1t1376-10">
   <w.rf>
    <LM>w#w-d1t1376-10</LM>
   </w.rf>
   <form>na</form>
   <lemma>na-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1376-11">
   <w.rf>
    <LM>w#w-d1t1376-11</LM>
   </w.rf>
   <form>obranu</form>
   <lemma>obrana_^(proti_nepříteli)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-920-924">
   <w.rf>
    <LM>w#w-920-924</LM>
   </w.rf>
   <form>před</form>
   <lemma>před-1</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1376-15">
   <w.rf>
    <LM>w#w-d1t1376-15</LM>
   </w.rf>
   <form>ohrožením</form>
   <lemma>ohrožení_^(*4zit)</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m016-d1t1376-16">
   <w.rf>
    <LM>w#w-d1t1376-16</LM>
   </w.rf>
   <form>naší</form>
   <lemma>náš</lemma>
   <tag>PSFS2-P1-------</tag>
  </m>
  <m id="m016-d1t1376-17">
   <w.rf>
    <LM>w#w-d1t1376-17</LM>
   </w.rf>
   <form_change>spell</form_change>
   <form>republiky</form>
   <lemma>republika</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-920-926">
   <w.rf>
    <LM>w#w-920-926</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-928">
  <m id="m016-d1t1378-1">
   <w.rf>
    <LM>w#w-d1t1378-1</LM>
   </w.rf>
   <form>Za</form>
   <lemma>za</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1378-2">
   <w.rf>
    <LM>w#w-d1t1378-2</LM>
   </w.rf>
   <form>rok</form>
   <lemma>rok</lemma>
   <tag>NNIS4-----A----</tag>
  </m>
  <m id="m016-d1t1378-3">
   <w.rf>
    <LM>w#w-d1t1378-3</LM>
   </w.rf>
   <form>přišli</form>
   <lemma>přijít</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m016-d1t1378-5">
   <w.rf>
    <LM>w#w-d1t1378-5</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1360-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1360-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1379-x2">
  <m id="m016-d1t1382-1">
   <w.rf>
    <LM>w#w-d1t1382-1</LM>
   </w.rf>
   <form>Byly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-AAI--</tag>
  </m>
  <m id="m016-d1t1382-2">
   <w.rf>
    <LM>w#w-d1t1382-2</LM>
   </w.rf>
   <form>akademie</form>
   <lemma>akademie</lemma>
   <tag>NNFP1-----A----</tag>
  </m>
  <m id="m016-d1t1384-1">
   <w.rf>
    <LM>w#w-d1t1384-1</LM>
   </w.rf>
   <form>i</form>
   <lemma>i-2</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1t1384-2">
   <w.rf>
    <LM>w#w-d1t1384-2</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1384-3">
   <w.rf>
    <LM>w#w-d1t1384-3</LM>
   </w.rf>
   <form>války</form>
   <lemma>válka</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d-id90061-punct">
   <w.rf>
    <LM>w#w-d-id90061-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1379-x3">
  <m id="m016-d1t1386-1">
   <w.rf>
    <LM>w#w-d1t1386-1</LM>
   </w.rf>
   <form>Ne</form>
   <lemma>ne-1</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1e1379-x3-968">
   <w.rf>
    <LM>w#w-d1e1379-x3-968</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1393-2">
   <w.rf>
    <LM>w#w-d1t1393-2</LM>
   </w.rf>
   <form>nebyly</form>
   <lemma>být</lemma>
   <tag>VpTP----R-NAI--</tag>
  </m>
  <m id="m016-d1e1379-x3-972">
   <w.rf>
    <LM>w#w-d1e1379-x3-972</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-974">
  <m id="m016-d1t1395-2">
   <w.rf>
    <LM>w#w-d1t1395-2</LM>
   </w.rf>
   <form>Němci</form>
   <lemma>Němec_;E_;Y</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m016-d1t1395-4">
   <w.rf>
    <LM>w#w-d1t1395-4</LM>
   </w.rf>
   <form>zakázali</form>
   <lemma>zakázat</lemma>
   <tag>VpMP----R-AAP--</tag>
  </m>
  <m id="m016-d1t1395-5">
   <w.rf>
    <LM>w#w-d1t1395-5</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1395-6">
   <w.rf>
    <LM>w#w-d1t1395-6</LM>
   </w.rf>
   <form>okupaci</form>
   <lemma>okupace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1403-1">
   <w.rf>
    <LM>w#w-d1t1403-1</LM>
   </w.rf>
   <form>sokolskou</form>
   <lemma>sokolský</lemma>
   <tag>AAFS4----1A----</tag>
  </m>
  <m id="m016-d1t1403-2">
   <w.rf>
    <LM>w#w-d1t1403-2</LM>
   </w.rf>
   <form>činnost</form>
   <lemma>činnost_^(*3ý)</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t1414-1">
   <w.rf>
    <LM>w#w-d1t1414-1</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1414-2">
   <w.rf>
    <LM>w#w-d1t1414-2</LM>
   </w.rf>
   <form>naopak</form>
   <lemma>naopak-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1416-1">
   <w.rf>
    <LM>w#w-d1t1416-1</LM>
   </w.rf>
   <form>mnoho</form>
   <lemma>mnoho-1</lemma>
   <tag>Ca--1----------</tag>
  </m>
  <m id="m016-d1t1418-1">
   <w.rf>
    <LM>w#w-d1t1418-1</LM>
   </w.rf>
   <form>význačných</form>
   <lemma>význačný</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m016-d1t1420-1">
   <w.rf>
    <LM>w#w-d1t1420-1</LM>
   </w.rf>
   <form>rokycanských</form>
   <lemma>rokycanský</lemma>
   <tag>AAMP2----1A----</tag>
  </m>
  <m id="m016-d1t1418-2">
   <w.rf>
    <LM>w#w-d1t1418-2</LM>
   </w.rf>
   <form>funkcionářů</form>
   <lemma>funkcionář</lemma>
   <tag>NNMP2-----A----</tag>
  </m>
  <m id="m016-d1t1425-1">
   <w.rf>
    <LM>w#w-d1t1425-1</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1425-2">
   <w.rf>
    <LM>w#w-d1t1425-2</LM>
   </w.rf>
   <form>zatčeno</form>
   <lemma>zatknout</lemma>
   <tag>VsNS----X-APP-1</tag>
  </m>
  <m id="m016-d1t1425-3">
   <w.rf>
    <LM>w#w-d1t1425-3</LM>
   </w.rf>
   <form>a</form>
   <lemma>a-1</lemma>
   <tag>J^-------------</tag>
  </m>
  <m id="m016-d1t1425-4">
   <w.rf>
    <LM>w#w-d1t1425-4</LM>
   </w.rf>
   <form>uvězněno</form>
   <lemma>uvěznit</lemma>
   <tag>VsNS----X-APP--</tag>
  </m>
  <m id="m016-d1t1425-5">
   <w.rf>
    <LM>w#w-d1t1425-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1425-6">
   <w.rf>
    <LM>w#w-d1t1425-6</LM>
   </w.rf>
   <form>koncentračních</form>
   <lemma>koncentrační</lemma>
   <tag>AAIP6----1A----</tag>
  </m>
  <m id="m016-d1t1425-7">
   <w.rf>
    <LM>w#w-d1t1425-7</LM>
   </w.rf>
   <form>táborech</form>
   <lemma>tábor-1</lemma>
   <tag>NNIP6-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1411-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1411-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1427-x2">
  <m id="m016-d1t1430-1">
   <w.rf>
    <LM>w#w-d1t1430-1</LM>
   </w.rf>
   <form>Jak</form>
   <lemma>jak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1430-2">
   <w.rf>
    <LM>w#w-d1t1430-2</LM>
   </w.rf>
   <form>jste</form>
   <lemma>být</lemma>
   <tag>VB-P---2P-AAI--</tag>
  </m>
  <m id="m016-d1t1430-3">
   <w.rf>
    <LM>w#w-d1t1430-3</LM>
   </w.rf>
   <form>prožíval</form>
   <lemma>prožívat_^(*3t)</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1430-4">
   <w.rf>
    <LM>w#w-d1t1430-4</LM>
   </w.rf>
   <form>válku</form>
   <lemma>válka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t1430-5">
   <w.rf>
    <LM>w#w-d1t1430-5</LM>
   </w.rf>
   <form>vy</form>
   <lemma>vy</lemma>
   <tag>PP-P1--2-------</tag>
  </m>
  <m id="m016-d-id90844-punct">
   <w.rf>
    <LM>w#w-d-id90844-punct</LM>
   </w.rf>
   <form>?</form>
   <lemma>?</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1431-x2">
  <m id="m016-d1t1436-1">
   <w.rf>
    <LM>w#w-d1t1436-1</LM>
   </w.rf>
   <form>Válku</form>
   <lemma>válka</lemma>
   <tag>NNFS4-----A----</tag>
  </m>
  <m id="m016-d1t1436-3">
   <w.rf>
    <LM>w#w-d1t1436-3</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1438-1">
   <w.rf>
    <LM>w#w-d1t1438-1</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m016-d1t1438-2">
   <w.rf>
    <LM>w#w-d1t1438-2</LM>
   </w.rf>
   <form>prožívat</form>
   <lemma>prožívat_^(*3t)</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m016-d1t1438-4">
   <w.rf>
    <LM>w#w-d1t1438-4</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1438-5">
   <w.rf>
    <LM>w#w-d1t1438-5</LM>
   </w.rf>
   <form>okupaci</form>
   <lemma>okupace</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1438-6">
   <w.rf>
    <LM>w#w-d1t1438-6</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1438-7">
   <w.rf>
    <LM>w#w-d1t1438-7</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1438-8">
   <w.rf>
    <LM>w#w-d1t1438-8</LM>
   </w.rf>
   <form>1939</form>
   <lemma>1939</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d-id91110-punct">
   <w.rf>
    <LM>w#w-d-id91110-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1e1431-x2-980">
   <w.rf>
    <LM>w#w-d1e1431-x2-980</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1438-12">
   <w.rf>
    <LM>w#w-d1t1438-12</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1438-13">
   <w.rf>
    <LM>w#w-d1t1438-13</LM>
   </w.rf>
   <form>ještě</form>
   <lemma>ještě-1</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1438-14">
   <w.rf>
    <LM>w#w-d1t1438-14</LM>
   </w.rf>
   <form>chodil</form>
   <lemma>chodit</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1438-15">
   <w.rf>
    <LM>w#w-d1t1438-15</LM>
   </w.rf>
   <form>do</form>
   <lemma>do-1</lemma>
   <tag>RR--2----------</tag>
  </m>
  <m id="m016-d1t1438-16">
   <w.rf>
    <LM>w#w-d1t1438-16</LM>
   </w.rf>
   <form>páté</form>
   <lemma>pátý</lemma>
   <tag>CrFS2----------</tag>
  </m>
  <m id="m016-d1t1438-17">
   <w.rf>
    <LM>w#w-d1t1438-17</LM>
   </w.rf>
   <form>třídy</form>
   <lemma>třída</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d1t1438-18">
   <w.rf>
    <LM>w#w-d1t1438-18</LM>
   </w.rf>
   <form>obecné</form>
   <lemma>obecný</lemma>
   <tag>AAFS2----1A----</tag>
  </m>
  <m id="m016-d1t1438-19">
   <w.rf>
    <LM>w#w-d1t1438-19</LM>
   </w.rf>
   <form>školy</form>
   <lemma>škola</lemma>
   <tag>NNFS2-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1431-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1431-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1447-x2">
  <m id="m016-d1t1456-3">
   <w.rf>
    <LM>w#w-d1t1456-3</LM>
   </w.rf>
   <form>Okupace</form>
   <lemma>okupace</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1t1456-5">
   <w.rf>
    <LM>w#w-d1t1456-5</LM>
   </w.rf>
   <form>Německem</form>
   <lemma>Německo_;G</lemma>
   <tag>NNNS7-----A----</tag>
  </m>
  <m id="m016-d1t1456-1">
   <w.rf>
    <LM>w#w-d1t1456-1</LM>
   </w.rf>
   <form>trvala</form>
   <lemma>trvat</lemma>
   <tag>VpQW----R-AAI--</tag>
  </m>
  <m id="m016-d1t1450-3">
   <w.rf>
    <LM>w#w-d1t1450-3</LM>
   </w.rf>
   <form>pak</form>
   <lemma>pak</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1454-1">
   <w.rf>
    <LM>w#w-d1t1454-1</LM>
   </w.rf>
   <form>při</form>
   <lemma>při-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1454-4">
   <w.rf>
    <LM>w#w-d1t1454-4</LM>
   </w.rf>
   <form>měšťanské</form>
   <lemma>měšťanský</lemma>
   <tag>AAFS6----1A----</tag>
  </m>
  <m id="m016-d1t1454-2">
   <w.rf>
    <LM>w#w-d1t1454-2</LM>
   </w.rf>
   <form>škole</form>
   <lemma>škola</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1t1456-7">
   <w.rf>
    <LM>w#w-d1t1456-7</LM>
   </w.rf>
   <form>až</form>
   <lemma>až-3_^(až_k_...,_až_dost)</lemma>
   <tag>TT-------------</tag>
  </m>
  <m id="m016-d1t1456-9">
   <w.rf>
    <LM>w#w-d1t1456-9</LM>
   </w.rf>
   <form>po</form>
   <lemma>po-1</lemma>
   <tag>RR--4----------</tag>
  </m>
  <m id="m016-d1t1456-10">
   <w.rf>
    <LM>w#w-d1t1456-10</LM>
   </w.rf>
   <form>absolvování</form>
   <lemma>absolvování_^(*3at)</lemma>
   <tag>NNNS4-----A----</tag>
  </m>
  <m id="m016-d1t1458-1">
   <w.rf>
    <LM>w#w-d1t1458-1</LM>
   </w.rf>
   <form>jednoročního</form>
   <lemma>jednoroční</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m016-d1t1458-2">
   <w.rf>
    <LM>w#w-d1t1458-2</LM>
   </w.rf>
   <form>učebního</form>
   <lemma>učební</lemma>
   <tag>AAIS2----1A----</tag>
  </m>
  <m id="m016-d1t1458-3">
   <w.rf>
    <LM>w#w-d1t1458-3</LM>
   </w.rf>
   <form>kurzu</form>
   <lemma>kurz</lemma>
   <tag>NNIS2-----A----</tag>
  </m>
  <m id="m016-d1e1447-x2-180">
   <w.rf>
    <LM>w#w-d1e1447-x2-180</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-181">
  <m id="m016-d1t1458-5">
   <w.rf>
    <LM>w#w-d1t1458-5</LM>
   </w.rf>
   <form>Tak</form>
   <lemma>tak-3</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1458-6">
   <w.rf>
    <LM>w#w-d1t1458-6</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1458-7">
   <w.rf>
    <LM>w#w-d1t1458-7</LM>
   </w.rf>
   <form>jmenovala</form>
   <lemma>jmenovat</lemma>
   <tag>VpQW----R-AAB--</tag>
  </m>
  <m id="m016-d1t1458-8">
   <w.rf>
    <LM>w#w-d1t1458-8</LM>
   </w.rf>
   <form>čtvrtá</form>
   <lemma>čtvrtý</lemma>
   <tag>CrFS1----------</tag>
  </m>
  <m id="m016-d1t1458-9">
   <w.rf>
    <LM>w#w-d1t1458-9</LM>
   </w.rf>
   <form>měšťanka</form>
   <lemma>měšťanka_^(*2)</lemma>
   <tag>NNFS1-----A----</tag>
  </m>
  <m id="m016-d1e1447-x2-994">
   <w.rf>
    <LM>w#w-d1e1447-x2-994</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-996">
  <m id="m016-996-998">
   <w.rf>
    <LM>w#w-996-998</LM>
   </w.rf>
   <form>Takže</form>
   <lemma>takže</lemma>
   <tag>J,-------------</tag>
  </m>
  <m id="m016-d1t1461-2">
   <w.rf>
    <LM>w#w-d1t1461-2</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1461-3">
   <w.rf>
    <LM>w#w-d1t1461-3</LM>
   </w.rf>
   <form>bylo</form>
   <lemma>být</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1461-4">
   <w.rf>
    <LM>w#w-d1t1461-4</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1461-5">
   <w.rf>
    <LM>w#w-d1t1461-5</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1461-12">
   <w.rf>
    <LM>w#w-d1t1461-12</LM>
   </w.rf>
   <form>1943</form>
   <lemma>1943</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-996-184">
   <w.rf>
    <LM>w#w-996-184</LM>
   </w.rf>
   <form>(</form>
   <lemma>(</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1461-6">
   <w.rf>
    <LM>w#w-d1t1461-6</LM>
   </w.rf>
   <form>1939</form>
   <lemma>1939</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-996-2092">
   <w.rf>
    <LM>w#w-996-2092</LM>
   </w.rf>
   <form>+</form>
   <lemma>+</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-996-2094">
   <w.rf>
    <LM>w#w-996-2094</LM>
   </w.rf>
   <form>4</form>
   <lemma>4</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-996-185">
   <w.rf>
    <LM>w#w-996-185</LM>
   </w.rf>
   <form>)</form>
   <lemma>)</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d-m-d1e1447-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1447-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-d1e1464-x2">
  <m id="m016-d1t1479-2">
   <w.rf>
    <LM>w#w-d1t1479-2</LM>
   </w.rf>
   <form>Po</form>
   <lemma>po-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1479-3">
   <w.rf>
    <LM>w#w-d1t1479-3</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1479-4">
   <w.rf>
    <LM>w#w-d1t1479-4</LM>
   </w.rf>
   <form>1943</form>
   <lemma>1943</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d1t1481-1">
   <w.rf>
    <LM>w#w-d1t1481-1</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1481-2">
   <w.rf>
    <LM>w#w-d1t1481-2</LM>
   </w.rf>
   <form>se</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P7--4----------</tag>
  </m>
  <m id="m016-d1t1481-3">
   <w.rf>
    <LM>w#w-d1t1481-3</LM>
   </w.rf>
   <form>začal</form>
   <lemma>začít-1_^(začnout)</lemma>
   <tag>VpYS----R-AAP--</tag>
  </m>
  <m id="m016-d1t1481-4">
   <w.rf>
    <LM>w#w-d1t1481-4</LM>
   </w.rf>
   <form>učit</form>
   <lemma>učit</lemma>
   <tag>Vf--------A-I--</tag>
  </m>
  <m id="m016-d1t1481-5">
   <w.rf>
    <LM>w#w-d1t1481-5</LM>
   </w.rf>
   <form>radiomechanikem</form>
   <lemma>radiomechanik</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m016-d1t1483-1">
   <w.rf>
    <LM>w#w-d1t1483-1</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1483-3">
   <w.rf>
    <LM>w#w-d1t1483-3</LM>
   </w.rf>
   <form>Plzni</form>
   <lemma>Plzeň_;G</lemma>
   <tag>NNFS6-----A----</tag>
  </m>
  <m id="m016-d1e1464-x2-204">
   <w.rf>
    <LM>w#w-d1e1464-x2-204</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-205">
  <m id="m016-d1t1485-3">
   <w.rf>
    <LM>w#w-d1t1485-3</LM>
   </w.rf>
   <form>Skončilo</form>
   <lemma>skončit</lemma>
   <tag>VpNS----R-AAP--</tag>
  </m>
  <m id="m016-d1t1485-4">
   <w.rf>
    <LM>w#w-d1t1485-4</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1485-5">
   <w.rf>
    <LM>w#w-d1t1485-5</LM>
   </w.rf>
   <form>v</form>
   <lemma>v-1</lemma>
   <tag>RR--6----------</tag>
  </m>
  <m id="m016-d1t1485-6">
   <w.rf>
    <LM>w#w-d1t1485-6</LM>
   </w.rf>
   <form>roce</form>
   <lemma>rok</lemma>
   <tag>NNIS6-----A---1</tag>
  </m>
  <m id="m016-d1t1485-7">
   <w.rf>
    <LM>w#w-d1t1485-7</LM>
   </w.rf>
   <form>1945</form>
   <lemma>1945</lemma>
   <tag>C=-------------</tag>
  </m>
  <m id="m016-d-id92562-punct">
   <w.rf>
    <LM>w#w-d-id92562-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1485-10">
   <w.rf>
    <LM>w#w-d1t1485-10</LM>
   </w.rf>
   <form>kdy</form>
   <lemma>kdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1485-11">
   <w.rf>
    <LM>w#w-d1t1485-11</LM>
   </w.rf>
   <form>jsem</form>
   <lemma>být</lemma>
   <tag>VB-S---1P-AAI--</tag>
  </m>
  <m id="m016-d1t1485-12">
   <w.rf>
    <LM>w#w-d1t1485-12</LM>
   </w.rf>
   <form>měl</form>
   <lemma>mít</lemma>
   <tag>VpYS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1485-13">
   <w.rf>
    <LM>w#w-d1t1485-13</LM>
   </w.rf>
   <form>za</form>
   <lemma>za</lemma>
   <tag>RR--7----------</tag>
  </m>
  <m id="m016-d1t1485-14">
   <w.rf>
    <LM>w#w-d1t1485-14</LM>
   </w.rf>
   <form>sebou</form>
   <lemma>se_^(zvr._zájmeno/částice)</lemma>
   <tag>P6--7----------</tag>
  </m>
  <m id="m016-d1t1485-15">
   <w.rf>
    <LM>w#w-d1t1485-15</LM>
   </w.rf>
   <form>dva</form>
   <lemma>dva`2</lemma>
   <tag>CnYP4----------</tag>
  </m>
  <m id="m016-d1t1485-16">
   <w.rf>
    <LM>w#w-d1t1485-16</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m016-d1t1485-17">
   <w.rf>
    <LM>w#w-d1t1485-17</LM>
   </w.rf>
   <form>učení</form>
   <lemma>učení_^(*3it)</lemma>
   <tag>NNNS2-----A----</tag>
  </m>
  <m id="m016-1040-1042">
   <w.rf>
    <LM>w#w-1040-1042</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-1040">
  <m id="m016-d1t1488-1">
   <w.rf>
    <LM>w#w-d1t1488-1</LM>
   </w.rf>
   <form>Tehdy</form>
   <lemma>tehdy</lemma>
   <tag>Db-------------</tag>
  </m>
  <m id="m016-d1t1492-8">
   <w.rf>
    <LM>w#w-d1t1492-8</LM>
   </w.rf>
   <form>náročnější</form>
   <lemma>náročný</lemma>
   <tag>AANS1----2A----</tag>
  </m>
  <m id="m016-d1t1490-1">
   <w.rf>
    <LM>w#w-d1t1490-1</LM>
   </w.rf>
   <form>učení</form>
   <lemma>učení_^(*3it)</lemma>
   <tag>NNNS1-----A----</tag>
  </m>
  <m id="m016-d1t1490-2">
   <w.rf>
    <LM>w#w-d1t1490-2</LM>
   </w.rf>
   <form>radiomechanikem</form>
   <lemma>radiomechanik</lemma>
   <tag>NNMS7-----A----</tag>
  </m>
  <m id="m016-d1t1492-1">
   <w.rf>
    <LM>w#w-d1t1492-1</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1492-2">
   <w.rf>
    <LM>w#w-d1t1492-2</LM>
   </w.rf>
   <form>čtyři</form>
   <lemma>čtyři`4</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m016-d1t1492-3">
   <w.rf>
    <LM>w#w-d1t1492-3</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m016-1040-219">
   <w.rf>
    <LM>w#w-1040-219</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
 <s id="m016-220">
  <m id="m016-d1t1502-1">
   <w.rf>
    <LM>w#w-d1t1502-1</LM>
   </w.rf>
   <form>Ostatním</form>
   <lemma>ostatní</lemma>
   <tag>AAMP3----1A----</tag>
  </m>
  <m id="m016-d-id93002-punct">
   <w.rf>
    <LM>w#w-d-id93002-punct</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1502-2">
   <w.rf>
    <LM>w#w-d1t1502-2</LM>
   </w.rf>
   <form>co</form>
   <lemma>co-4_^(který:_o_těch,_co_odešli)</lemma>
   <tag>P4XXX----------</tag>
  </m>
  <m id="m016-d1t1516-1">
   <w.rf>
    <LM>w#w-d1t1516-1</LM>
   </w.rf>
   <form>byli</form>
   <lemma>být</lemma>
   <tag>VpMP----R-AAI--</tag>
  </m>
  <m id="m016-d1t1516-2">
   <w.rf>
    <LM>w#w-d1t1516-2</LM>
   </w.rf>
   <form>učni</form>
   <lemma>učeň</lemma>
   <tag>NNMP1-----A----</tag>
  </m>
  <m id="m016-d1t1516-3">
   <w.rf>
    <LM>w#w-d1t1516-3</LM>
   </w.rf>
   <form>ve</form>
   <lemma>v-1</lemma>
   <tag>RV--6----------</tag>
  </m>
  <m id="m016-d1t1516-4">
   <w.rf>
    <LM>w#w-d1t1516-4</LM>
   </w.rf>
   <form>strojírenství</form>
   <lemma>strojírenství</lemma>
   <tag>NNNS6-----A----</tag>
  </m>
  <m id="m016-1040-1088">
   <w.rf>
    <LM>w#w-1040-1088</LM>
   </w.rf>
   <form>,</form>
   <lemma>,</lemma>
   <tag>Z:-------------</tag>
  </m>
  <m id="m016-d1t1516-5">
   <w.rf>
    <LM>w#w-d1t1516-5</LM>
   </w.rf>
   <form>to</form>
   <lemma>ten</lemma>
   <tag>PDNS1----------</tag>
  </m>
  <m id="m016-d1t1516-6">
   <w.rf>
    <LM>w#w-d1t1516-6</LM>
   </w.rf>
   <form>trvalo</form>
   <lemma>trvat</lemma>
   <tag>VpNS----R-AAI--</tag>
  </m>
  <m id="m016-d1t1516-7">
   <w.rf>
    <LM>w#w-d1t1516-7</LM>
   </w.rf>
   <form>tři</form>
   <lemma>tři`3</lemma>
   <tag>Cl-P4----------</tag>
  </m>
  <m id="m016-d1t1516-8">
   <w.rf>
    <LM>w#w-d1t1516-8</LM>
   </w.rf>
   <form>roky</form>
   <lemma>rok</lemma>
   <tag>NNIP4-----A----</tag>
  </m>
  <m id="m016-d-m-d1e1509-x2-punct-punct">
   <w.rf>
    <LM>w#w-d-m-d1e1509-x2-punct-punct</LM>
   </w.rf>
   <form>.</form>
   <lemma>.</lemma>
   <tag>Z:-------------</tag>
  </m>
 </s>
</mdata>
